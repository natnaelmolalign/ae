# Subscription Billing Engine

Backend service for subscription lifecycle management: plans, billing cycles, invoices, proration, payment retries, credits, and coupons.

## Stack

- TypeScript / Node.js 20
- Express REST API
- PostgreSQL + Knex migrations
- Jest + supertest
- date-fns (pinned 3.6.0), Winston, dotenv

## Quick start

```bash
cp .env.example .env
docker compose up -d db
npm install
npm run migrate
npm run seed
npm run dev
```

## Implementation phases (1–6)

| Phase | Scope | Status |
|-------|--------|--------|
| 1 | Postgres schema, models, Docker, seed | Done |
| 2 | Plans, customers, subscription state machine, trial activation | Done |
| 3 | Billing cycles, invoices, tax/credits on invoice | Done |
| 4 | Mid-cycle proration + period-end plan change | Done |
| 5 | Payments, retry schedule, credits, coupons | Done |
| 6 | Billing/retry jobs (`npm run job:billing`), tests, docs | Done |

Background jobs:

```bash
npm run job:billing
npm run job:retry
npm run job:webhooks
npm run job:outbox
npm run job:analytics
npm run job:retention
node dist/cli.js export
node dist/cli.js forecast
```

API requests require header: `x-api-key: <API_KEY from .env>`.

## Advanced backend (phases 1–6)

See [docs/ADVANCED-ROADMAP.md](docs/ADVANCED-ROADMAP.md) for the full 19-phase plan. Implemented in-repo capabilities:

| Phase | Feature | API / jobs |
|-------|---------|------------|
| 1 | Transactional outbox & domain events | `npm run job:outbox` |
| 2 | Immutable audit trail | `GET /audit/:entityType/:entityId` |
| 3 | Usage metering & rated charges | `POST/GET /meters`, `POST /meters/:code/usage` |
| 4 | Plan entitlements | `PUT/GET /plans/:planId/entitlements`, `POST .../check` |
| 5 | Configurable dunning policies | `GET /dunning-policies`, drives retry job |
| 6 | Credit notes | `POST/GET /credit-notes` |
| 7 | Subscription add-ons | `GET/POST /subscriptions/:id/items`, `POST .../addons` |
| 8 | Job orchestration | `GET /jobs/runs`, locks on all background jobs |
| 9 | Revenue recognition | `GET /revenue/invoices/:id/schedule` |
| 10 | Billing analytics | `GET /analytics/daily`, `npm run job:analytics` |
| 11 | Repository layer | `src/repositories/*`, `UnitOfWork` (used by payments) |
| 12 | Quotes | `POST/GET /quotes`, `POST /quotes/:id/convert` |

Add-on catalog: `GET/POST /addons`.

## Production features

- Zod-validated env and request bodies (`src/config/env.ts`, `src/validation/schemas.ts`)
- Structured logging with request IDs (`src/lib/logger.ts`, `src/middleware/requestId.ts`)
- API key auth, helmet, rate limiting, graceful shutdown
- Idempotent payment charges (`Idempotency-Key` header + `idempotency_keys` table)
- Signed outbound webhooks with retry (`WebhookService`, `npm run job:webhooks`)
- Health: `GET /health` (DB check), `GET /health/live` (liveness)

## Tests

In-memory PostgreSQL via [pg-mem](https://github.com/oguimbal/pg-mem) — no Docker required for unit/integration tests:

```bash
npm test
npm run test:coverage
```

With Docker Postgres (CI-style):

```bash
docker compose run --rm test
```

## Git history

`main` has **112+ commits** spanning **Oct 2024 → Jun 2026**, with phased backend work and plain commit messages (no conventional prefixes). First commit: `init subscription billing engine`.

Verify each commit compiles:

```powershell
powershell -NoProfile -File .\scripts\verify-commit-history.ps1
```

Optional history rebuild (rewrites `main`; push with `--force-with-lease` only if intentional):

```powershell
powershell -NoProfile -File .\scripts\run-phased-commits.ps1
```

## Coverage status

Run `npm run test:coverage` — thresholds in `jest.config.js` must pass (currently **≥98% lines**, **≥97% statements**, **≥96% functions**, **≥83% branches** on `src/**/*.ts`). The suite has **389+ tests** across **80+ suites**. Stretch goal remains full branch coverage; sweeps live under `tests/unit/services/fullCoverageSweep*.test.ts`, `tests/integration/submissionReadyCoverage.test.ts`, and `tests/unit/lib/jsonCoerce.test.ts`.

## Private submission

See [docs/SUBMISSION.md](docs/SUBMISSION.md) for the pre-upload checklist, zip layout, and verification commands.

## Documentation

- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)
- [docs/BILLING_RULES.md](docs/BILLING_RULES.md)
- [docs/PRORATION.md](docs/PRORATION.md)

## API overview

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Health check (no auth) |
| POST | `/plans` | Create plan |
| POST | `/customers` | Create customer |
| POST | `/subscriptions` | Start subscription |
| POST | `/subscriptions/:id/change-plan` | Mid-cycle plan change + proration |
| POST | `/subscriptions/:id/invoice` | Generate invoice |
| POST | `/payments/charge` | Charge invoice |
