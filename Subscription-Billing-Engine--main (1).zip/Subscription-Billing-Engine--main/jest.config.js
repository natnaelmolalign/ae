/** @type {import('jest').Config} */
module.exports = {
  projects: [
    {
      displayName: 'unit',
      preset: 'ts-jest',
      testEnvironment: 'node',
      setupFilesAfterEnv: ['<rootDir>/tests/helpers/setupEnv.ts'],
      testMatch: [
        '<rootDir>/tests/unit/utils/**/*.test.ts',
        '<rootDir>/tests/unit/lib/**/*.test.ts',
        '<rootDir>/tests/unit/middleware/**/*.test.ts',
        '<rootDir>/tests/unit/domain/**/*.test.ts',
        '<rootDir>/tests/unit/app/**/*.test.ts',
        '<rootDir>/tests/unit/config/**/*.test.ts',
      ],
    },
    {
      displayName: 'db',
      preset: 'ts-jest',
      testEnvironment: 'node',
      setupFilesAfterEnv: ['<rootDir>/tests/helpers/setup.ts'],
      testMatch: [
        '<rootDir>/tests/unit/services/**/*.test.ts',
        '<rootDir>/tests/integration/**/*.test.ts',
      ],
    },
  ],
  collectCoverageFrom: ['src/**/*.ts'],
  coverageThreshold: {
    global: {
      branches: 83,
      functions: 96,
      lines: 98,
      statements: 97,
    },
  },
};
