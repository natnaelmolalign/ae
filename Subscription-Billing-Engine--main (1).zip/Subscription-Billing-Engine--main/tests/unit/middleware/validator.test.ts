import { Request, Response, NextFunction } from 'express';
import { validateBody } from '../../../src/middleware/validator';
import { AppError } from '../../../src/middleware/errorHandler';

function runMiddleware(
  mw: ReturnType<typeof validateBody>,
  body: Record<string, unknown>
): Promise<{ err?: unknown; nextCalled: boolean }> {
  return new Promise((resolve) => {
    const req = { body } as Request;
    const res = {} as Response;
    const next = (err?: unknown) => resolve({ err, nextCalled: !err });
    mw(req, res, next as NextFunction);
  });
}

describe('validateBody (legacy validator)', () => {
  const mw = validateBody({
    name: { required: true, type: 'string' },
    count: { type: 'number', min: 1 },
    active: { type: 'boolean' },
  });

  it('passes valid body', async () => {
    const r = await runMiddleware(mw, { name: 'x', count: 2, active: true });
    expect(r.nextCalled).toBe(true);
  });

  it('rejects missing required field', async () => {
    const r = await runMiddleware(mw, { count: 2 });
    expect(r.err).toBeInstanceOf(AppError);
    expect((r.err as AppError).statusCode).toBe(400);
  });

  it('rejects wrong types and min', async () => {
    expect((await runMiddleware(mw, { name: 'x', count: 'nope' })).err).toBeInstanceOf(AppError);
    expect((await runMiddleware(mw, { name: 'x', count: 0 })).err).toBeInstanceOf(AppError);
    expect((await runMiddleware(mw, { name: 1 })).err).toBeInstanceOf(AppError);
  });
});
