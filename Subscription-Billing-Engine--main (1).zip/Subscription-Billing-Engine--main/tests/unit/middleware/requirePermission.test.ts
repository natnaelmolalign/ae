import { requirePermission } from '../../../src/middleware/requirePermission';
import { AppError } from '../../../src/lib/errors';

describe('requirePermission middleware', () => {
  it('rejects when principal is missing', async () => {
    const mw = requirePermission('invoices', 'read');
    const next = jest.fn();
    await mw({} as never, {} as never, next);
    expect(next).toHaveBeenCalledWith(expect.any(AppError));
  });
});
