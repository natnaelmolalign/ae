import { createApp } from '../../../src/app';
import request from 'supertest';

describe('auth middleware', () => {
  const app = createApp();

  it('rejects missing api key on protected routes', async () => {
    const res = await request(app).get('/plans');
    expect(res.status).toBe(401);
  });

  it('allows health without api key', async () => {
    const res = await request(app).get('/health/live');
    expect(res.status).toBe(200);
  });
});
