import { Request, Response, NextFunction } from 'express';
import { ZodError, z } from 'zod';
import { validateBody, validateQuery } from '../../../src/middleware/validateZod';
import { errorHandler } from '../../../src/middleware/errorHandler';
import { AppError } from '../../../src/lib/errors';
import { idempotencyMiddleware } from '../../../src/middleware/idempotency';

describe('middleware', () => {
  it('validateBody rejects invalid payloads', () => {
    const schema = z.object({ name: z.string().min(1) });
    const middleware = validateBody(schema);
    const next = jest.fn();
    const req = { body: {} } as Request;
    middleware(req, {} as Response, next);
    expect(next).toHaveBeenCalledWith(expect.any(AppError));
  });

  it('validateQuery rejects invalid query', () => {
    const schema = z.object({ page: z.coerce.number().positive() });
    const middleware = validateQuery(schema);
    const next = jest.fn();
    const req = { query: { page: '-1' } } as unknown as Request;
    middleware(req, {} as Response, next);
    expect(next).toHaveBeenCalledWith(expect.any(AppError));
  });

  it('errorHandler maps AppError, ZodError, and unknown errors', () => {
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    } as unknown as Response;
    const next = jest.fn() as NextFunction;

    errorHandler(new AppError(404, 'missing'), {} as Request, res, next);
    expect(res.status).toHaveBeenCalledWith(404);

    errorHandler(new ZodError([]), {} as Request, res, next);
    expect(res.status).toHaveBeenCalledWith(400);

    errorHandler(new Error('boom'), {} as Request, res, next);
    expect(res.status).toHaveBeenCalledWith(500);
  });

  it('idempotency middleware passes through without header', async () => {
    const middleware = idempotencyMiddleware('POST /x');
    const next = jest.fn();
    await middleware({ header: () => undefined } as unknown as Request, {} as Response, next);
    expect(next).toHaveBeenCalled();
  });
});
