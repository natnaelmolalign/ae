import { runCliCommand } from '../../../src/cli';

describe('runCliCommand', () => {
  it('rejects unknown commands', async () => {
    await expect(runCliCommand('not-a-command')).rejects.toThrow(/Unknown/);
  });

  it('rejects empty command via main guard', async () => {
    await expect(runCliCommand('')).rejects.toThrow(/Missing/);
  });
});
