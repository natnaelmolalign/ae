import { shutdown, startServer } from '../../../src/app';
import { closeDb } from '../../../src/config/database';

jest.mock('../../../src/config/database', () => ({
  closeDb: jest.fn().mockResolvedValue(undefined),
}));

describe('app shutdown', () => {
  const exit = jest.spyOn(process, 'exit').mockImplementation((() => undefined) as never);

  afterEach(() => {
    exit.mockClear();
  });

  it('shutdown without server still closes db', async () => {
    shutdown('SIGTERM');
    await new Promise((r) => setImmediate(r));
    expect(closeDb).toHaveBeenCalled();
    expect(exit).toHaveBeenCalledWith(0);
  });

  it('shutdown closes listening server', (done) => {
    const prev = process.env.PORT;
    process.env.PORT = '0';
    const server = startServer();
    process.env.PORT = prev;
    server.on('listening', () => {
      shutdown('SIGINT');
      server.on('close', () => done());
    });
  });
});
