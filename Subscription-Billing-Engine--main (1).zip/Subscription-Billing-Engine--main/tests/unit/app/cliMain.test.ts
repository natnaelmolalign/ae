import { closeDb } from '../../../src/config/database';
import { main } from '../../../src/cli';

jest.mock('../../../src/config/database', () => ({
  closeDb: jest.fn().mockResolvedValue(undefined),
}));

describe('cli main', () => {
  const exit = jest.spyOn(process, 'exit').mockImplementation((() => undefined) as never);
  const error = jest.spyOn(console, 'error').mockImplementation(() => undefined);

  afterEach(() => {
    exit.mockClear();
    error.mockClear();
  });

  it('prints usage and exits when command missing', async () => {
    await main(['node', 'cli.js']);
    expect(error).toHaveBeenCalledWith(expect.stringContaining('Usage:'));
    expect(exit).toHaveBeenCalledWith(1);
    expect(closeDb).not.toHaveBeenCalled();
  });
});
