import { maxRetryAttempts, nextRetryDate, parseRetryDelays } from '../../../src/utils/retryUtils';

describe('retryUtils', () => {
  it('parses retry delays from env pattern', () => {
    expect(parseRetryDelays('3,5,7')).toEqual([3, 5, 7]);
  });

  it('schedules first retry after cumulative delay, not immediately', () => {
    const failureAt = new Date('2024-06-01T12:00:00Z');
    const first = nextRetryDate(failureAt, 1, [3, 5, 7]);
    expect(first?.getDate()).toBe(4);
  });

  it('returns null when attempts exceed configured delays', () => {
    expect(nextRetryDate(new Date(), 4, [3, 5, 7])).toBeNull();
    expect(maxRetryAttempts([3, 5, 7])).toBe(3);
  });
});
