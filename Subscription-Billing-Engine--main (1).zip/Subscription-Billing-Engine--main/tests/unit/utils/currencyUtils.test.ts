import {
  applyFixedDiscount,
  applyPercentDiscount,
  calculateTax,
  centsToDecimal,
  sumCents,
} from '../../../src/utils/currencyUtils';

describe('currencyUtils', () => {
  it('formats cents to decimal', () => {
    expect(centsToDecimal(1099)).toBe('10.99');
  });

  it('applies percent and fixed discounts', () => {
    expect(applyPercentDiscount(1000, 10)).toBe(900);
    expect(applyFixedDiscount(1000, 200)).toBe(800);
    expect(applyFixedDiscount(100, 500)).toBe(0);
  });

  it('calculates tax from basis points', () => {
    expect(calculateTax(10000, 2000)).toBe(2000);
  });

  it('sums cent amounts', () => {
    expect(sumCents(100, 200, 50)).toBe(350);
  });
});
