import { calculateProration } from '../../../src/utils/prorationUtils';

describe('calculateProration', () => {
  it('credits unused old plan and charges remaining on new plan mid-cycle', () => {
    const result = calculateProration({
      oldPriceCents: 1000,
      newPriceCents: 3000,
      periodStart: '2024-01-01',
      periodEnd: '2024-01-30',
      changeDate: '2024-01-15',
    });
    expect(result.totalDays).toBe(30);
    expect(result.remainingDays).toBe(16);
    expect(result.unusedDays).toBe(14);
    expect(result.creditCents).toBe(Math.round((1000 * 14) / 30));
    expect(result.chargeCents).toBe(Math.round((3000 * 16) / 30));
    expect(result.netCents).toBe(result.chargeCents - result.creditCents);
  });

  it('handles leap year February upgrade', () => {
    const result = calculateProration({
      oldPriceCents: 1000,
      newPriceCents: 3000,
      periodStart: '2024-02-01',
      periodEnd: '2024-02-28',
      changeDate: '2024-02-15',
    });
    expect(result.totalDays).toBe(28);
    expect(result.creditCents).toBeGreaterThan(0);
    expect(result.chargeCents).toBeGreaterThan(0);
  });

  it('returns zero when change is after period end', () => {
    const result = calculateProration({
      oldPriceCents: 1000,
      newPriceCents: 3000,
      periodStart: '2024-01-01',
      periodEnd: '2024-01-30',
      changeDate: '2024-02-01',
    });
    expect(result.remainingDays).toBe(0);
    expect(result.netCents).toBe(0);
  });
});
