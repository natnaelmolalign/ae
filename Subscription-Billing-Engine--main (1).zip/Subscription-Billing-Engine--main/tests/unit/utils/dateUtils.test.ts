import {
  addBillingInterval,
  anchorDayInMonth,
  daysInPeriod,
  daysRemainingInPeriod,
  gracePeriodEnd,
  isExpired,
  isOnOrBefore,
  periodEndFromStart,
  toDateString,
} from '../../../src/utils/dateUtils';

describe('dateUtils', () => {
  it('clamps billing anchor to last day of month', () => {
    expect(anchorDayInMonth(2024, 1, 31)).toBe(29);
    expect(anchorDayInMonth(2024, 0, 31)).toBe(31);
  });

  it('advances monthly interval from Jan 31 to Feb 29 in leap year', () => {
    const start = new Date(2024, 0, 31);
    const next = addBillingInterval(start, 'monthly', 31);
    expect(toDateString(next)).toBe('2024-02-29');
  });

  it('advances yearly interval with anchor clamping', () => {
    const start = new Date(2023, 0, 31);
    const next = addBillingInterval(start, 'yearly', 31);
    expect(toDateString(next)).toBe('2024-01-31');
  });

  it('computes period end as day before next anchor', () => {
    const start = new Date(2024, 0, 1);
    const end = periodEndFromStart(start, 'monthly', 1);
    expect(toDateString(end)).toBe('2024-01-31');
  });

  it('counts days and grace helpers', () => {
    const start = new Date(2024, 0, 1);
    const end = new Date(2024, 0, 10);
    expect(daysInPeriod(start, end)).toBe(10);
    expect(daysRemainingInPeriod(new Date(2024, 0, 5), end)).toBe(6);
    expect(daysRemainingInPeriod(new Date(2024, 0, 15), end)).toBe(0);
    expect(isOnOrBefore(start, end)).toBe(true);
    expect(isExpired(new Date(2024, 0, 20), end)).toBe(true);
    expect(toDateString(gracePeriodEnd(start, 3))).toBe('2024-01-04');
  });
});
