import { coerceJsonArray, coerceJsonValue } from '../../../src/lib/jsonCoerce';

describe('jsonCoerce', () => {
  it('coerces null string and object values', () => {
    expect(coerceJsonValue(null, { a: 1 })).toEqual({ a: 1 });
    expect(coerceJsonValue('{"b":2}', { a: 1 })).toEqual({ b: 2 });
    expect(coerceJsonValue({ c: 3 }, { a: 1 })).toEqual({ c: 3 });
    expect(coerceJsonArray(null)).toEqual([]);
    expect(coerceJsonArray('[1,2]')).toEqual([1, 2]);
    expect(coerceJsonArray([3, 4])).toEqual([3, 4]);
    expect(coerceJsonArray(undefined, [{ x: 1 }])).toEqual([{ x: 1 }]);
  });
});
