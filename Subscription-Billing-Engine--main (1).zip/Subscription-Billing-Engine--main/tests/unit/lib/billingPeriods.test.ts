import {
  monthPeriodKey,
  parseMonthPeriod,
  previousMonth,
  nextMonth,
  monthsBetween,
  fiscalQuarter,
  fiscalYear,
  quarterPeriodKeys,
  daysInMonthPeriod,
  containsDate,
  currentMonthPeriod,
  trailingMonths,
  formatPeriodLabel,
  isValidPeriodKey,
  yearToDateMonths,
  overlapDays,
  sameYear,
  minPeriodKey,
  maxPeriodKey,
  periodKeyFromDate,
} from '../../../src/lib/billingPeriods';

describe('billingPeriods', () => {
  it('parses and navigates months', () => {
    expect(monthPeriodKey(new Date('2026-06-15T00:00:00Z'))).toBe('2026-06');
    const p = parseMonthPeriod('2026-06');
    expect(p.key).toBe('2026-06');
    expect(previousMonth('2026-06')).toBe('2026-05');
    expect(nextMonth('2026-06')).toBe('2026-07');
    expect(monthsBetween('2026-01', '2026-03')).toEqual(['2026-01', '2026-02', '2026-03']);
    expect(fiscalQuarter('2026-06')).toBe(2);
    expect(trailingMonths(3, new Date('2026-06-01T00:00:00Z'))).toContain('2026-06');
    expect(containsDate('2026-06', new Date('2026-06-10T00:00:00Z'))).toBe(true);
    expect(containsDate('2026-06', new Date('2026-07-01T00:00:00Z'))).toBe(false);
  });

  it('rejects invalid period keys and supports fiscal calendar helpers', () => {
    expect(() => parseMonthPeriod('06-2026')).toThrow('YYYY-MM');
    expect(isValidPeriodKey('2026-06')).toBe(true);
    expect(isValidPeriodKey('bad')).toBe(false);

    expect(fiscalQuarter('2026-04', 4)).toBe(1);
    expect(fiscalYear('2026-03', 4)).toBe(2025);
    expect(fiscalYear('2026-05', 4)).toBe(2026);
    expect(quarterPeriodKeys(2026, 2)).toEqual(['2026-04', '2026-05', '2026-06']);
    expect(daysInMonthPeriod('2026-02')).toBe(29);
    expect(formatPeriodLabel('2026-06')).toContain('2026');
    expect(yearToDateMonths('2026-06')).toEqual([
      '2026-01',
      '2026-02',
      '2026-03',
      '2026-04',
      '2026-05',
      '2026-06',
    ]);
    expect(currentMonthPeriod(new Date('2026-06-15T00:00:00Z')).key).toBe('2026-06');
    expect(periodKeyFromDate(new Date('2025-12-01T00:00:00Z'))).toBe('2025-12');
  });

  it('compares periods overlap and min max', () => {
    expect(overlapDays('2026-03', '2026-03')).toBeGreaterThan(0);
    expect(overlapDays('2026-01', '2026-06')).toBe(0);
    expect(sameYear('2026-01', '2026-12')).toBe(true);
    expect(sameYear('2025-12', '2026-01')).toBe(false);
    expect(minPeriodKey([])).toBeNull();
    expect(maxPeriodKey([])).toBeNull();
    expect(minPeriodKey(['2026-06', '2026-02'])).toBe('2026-02');
    expect(maxPeriodKey(['2026-06', '2026-02'])).toBe('2026-06');
  });

  it('caps monthsBetween iteration guard', () => {
    const keys = monthsBetween('1900-01', '2200-12');
    expect(keys.length).toBeLessThanOrEqual(241);
  });

  it('handles empty ranges and boundary date checks', () => {
    expect(monthsBetween('2026-06', '2026-04')).toEqual([]);
    expect(containsDate('2026-06', new Date('2026-05-31T23:59:59Z'))).toBe(false);
    expect(containsDate('2026-06', new Date('2026-07-01T00:00:00Z'))).toBe(false);
    expect(fiscalQuarter('2026-02', 4)).toBe(4);
    expect(fiscalYear('2026-01', 4)).toBe(2025);
    expect(overlapDays('2026-04', '2026-06')).toBe(0);
    expect(overlapDays('2026-06', '2026-04')).toBe(0);
    expect(overlapDays('2026-05', '2026-05')).toBe(daysInMonthPeriod('2026-05'));
    const period = parseMonthPeriod('2026-06');
    expect(containsDate('2026-06', period.start)).toBe(true);
    expect(containsDate('2026-06', period.end)).toBe(true);
    expect(fiscalQuarter('2026-01')).toBe(1);
    expect(fiscalQuarter('2026-04')).toBe(2);
    expect(fiscalQuarter('2026-07')).toBe(3);
    expect(fiscalQuarter('2026-11')).toBe(4);
    expect(fiscalYear('2026-12')).toBe(2026);
    expect(fiscalYear('2026-01')).toBe(2026);
  });
});
