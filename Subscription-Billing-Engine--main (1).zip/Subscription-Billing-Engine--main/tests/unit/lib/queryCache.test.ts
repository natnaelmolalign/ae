import { QueryCache } from '../../../src/lib/queryCache';

describe('QueryCache', () => {
  it('stores and retrieves within TTL', () => {
    const cache = new QueryCache<string>(60_000);
    cache.set('k', 'v');
    expect(cache.get('k')).toBe('v');
    expect(cache.size()).toBe(1);
  });

  it('expires entries', () => {
    const cache = new QueryCache<string>(1);
    cache.set('k', 'v');
    return new Promise<void>((resolve) => {
      setTimeout(() => {
        expect(cache.get('k')).toBeUndefined();
        resolve();
      }, 5);
    });
  });

  it('evicts oldest when over max', () => {
    const cache = new QueryCache<number>(60_000, 2);
    cache.set('a', 1);
    cache.set('b', 2);
    cache.set('c', 3);
    expect(cache.size()).toBeLessThanOrEqual(2);
  });
});
