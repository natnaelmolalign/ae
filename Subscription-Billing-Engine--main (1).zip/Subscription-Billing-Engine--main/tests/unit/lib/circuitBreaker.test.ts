import { CircuitBreaker } from '../../../src/lib/CircuitBreaker';

describe('CircuitBreaker', () => {
  it('opens after repeated failures', async () => {
    const cb = new CircuitBreaker('test', { failureThreshold: 2, resetTimeoutMs: 1000, halfOpenSuccesses: 1 });
    const fail = () => cb.execute(async () => { throw new Error('x'); });
    await expect(fail()).rejects.toBeDefined();
    await expect(fail()).rejects.toBeDefined();
    expect(cb.getState()).toBe('open');
    await expect(fail()).rejects.toThrow(/open/);
  });

  it('resets manually', async () => {
    const cb = new CircuitBreaker('test2', { failureThreshold: 1, resetTimeoutMs: 1000, halfOpenSuccesses: 1 });
    await expect(cb.execute(async () => { throw new Error('x'); })).rejects.toBeDefined();
    cb.reset();
    expect(cb.getState()).toBe('closed');
  });
});
