import { MetricsRegistry, globalMetrics, recordHttpRequest } from '../../../src/lib/metrics';

describe('MetricsRegistry', () => {
  it('increments counters and formats prometheus text with labels', () => {
    const reg = new MetricsRegistry();
    reg.increment('test_counter');
    reg.increment('test_counter', { region: 'us' }, 2);
    reg.observeHistogram('test_hist', 12, { route: '/health' });
    reg.observeHistogram('test_hist', 5000, { route: '/health' });

    const text = reg.toPrometheusText();
    expect(text).toContain('test_counter');
    expect(text).toContain('region="us"');
    expect(text).toContain('test_hist_bucket');
    expect(text).toContain('test_hist_sum');

    const snap = reg.snapshot();
    expect(snap.counters.length).toBeGreaterThan(0);
    expect(snap.histograms.length).toBeGreaterThan(0);
  });

  it('records http metrics on the global registry', () => {
    recordHttpRequest('GET', '/plans', 200, 4.2);
    const snap = globalMetrics.snapshot();
    expect(snap.counters.some((c) => String(c.labels.method) === 'GET')).toBe(true);
    expect(globalMetrics.toPrometheusText()).toContain('http_requests_total');
  });
});
