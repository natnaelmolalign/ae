import { AppError } from '../../../src/lib/errors';

describe('AppError', () => {
  it('carries status and code', () => {
    const err = new AppError(404, 'missing', 'NOT_FOUND');
    expect(err.statusCode).toBe(404);
    expect(err.code).toBe('NOT_FOUND');
    expect(err.message).toBe('missing');
  });
});
