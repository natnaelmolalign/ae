import { parseUuidParam } from '../../../src/lib/parseUuidParam';

describe('parseUuidParam', () => {
  it('returns parsed uuid for valid input', () => {
    const id = '00000000-0000-4000-8000-000000000001';
    expect(parseUuidParam(id, 'quote id')).toBe(id);
  });

  it('throws 400 for invalid input', () => {
    expect(() => parseUuidParam('not-a-uuid', 'subscription id')).toThrow(
      expect.objectContaining({ statusCode: 400 })
    );
  });

  it('uses default id label when none provided', () => {
    expect(() => parseUuidParam('bad')).toThrow(/Invalid id/);
  });
});
