import { runBillingJob } from '../../../src/jobs/billingJob';
import { runAnalyticsJob } from '../../../src/jobs/analyticsJob';
import { JobLockService } from '../../../src/services/JobLockService';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';
import { overlapDays, monthsBetween } from '../../../src/lib/billingPeriods';
import { BillingRulesEngine } from '../../../src/domain/billing/BillingRulesEngine';

describe('Full coverage sweep 7', () => {
  it('billing job renews overdue subscriptions before invoicing', async () => {
    await getTestDb()('job_runs').where({ job_name: 'billing' }).del();
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
      billing_anchor: '2020-06-01',
    });
    await getTestDb()('subscriptions').where({ id: sub.id }).update({
      status: 'active',
      current_period_start: '2020-06-01',
      current_period_end: '2020-06-30',
    });
    const generated = await runBillingJob(new Date('2020-07-05'));
    expect(generated).toBeGreaterThanOrEqual(1);
    const renewed = await getTestDb()('subscriptions').where({ id: sub.id }).first();
    expect(String(renewed?.current_period_start)).not.toBe('2020-06-01');
  });

  it('analytics and billing jobs accept defaults and undefined lock results', async () => {
    await getTestDb()('job_runs').del();
    expect(await runAnalyticsJob()).toBeGreaterThanOrEqual(0);
    expect(await runAnalyticsJob(new Date(), 0)).toBeGreaterThanOrEqual(0);

    const lock = new JobLockService();
    const empty = await lock.runExclusive('billing', async () => undefined);
    expect(empty.skipped).toBe(false);
    expect(empty.result).toBeUndefined();
    expect(await runBillingJob()).toBeGreaterThanOrEqual(0);
  });

  it('billing periods and rules hit alternate comparison branches', () => {
    expect(monthsBetween('2026-06', '2026-06')).toEqual(['2026-06']);
    expect(overlapDays('2026-03', '2026-08')).toBe(0);
    expect(overlapDays('2026-08', '2026-03')).toBe(0);

    const engine = new BillingRulesEngine();
    const withAddons = engine.mergeAddonLines(
      [{ description: 'Core', quantity: 1, unit_amount_cents: 1000 }],
      [{ description: 'Seat', quantity: 3, unit_amount_cents: 200 }]
    );
    expect(withAddons).toHaveLength(2);
    const noMinBump = engine.calculate([
      { description: 'Large', quantity: 1, unit_amount_cents: 20_000 },
    ]);
    expect(noMinBump.minimum_charge_applied).toBe(false);
    expect(
      engine.tieredUsageCharge(15, [
        { up_to: 10, unit_cents: 1 },
        { up_to: 20, unit_cents: 2 },
        { up_to: null, unit_cents: 3 },
      ])
    ).toBe(20);
  });
});
