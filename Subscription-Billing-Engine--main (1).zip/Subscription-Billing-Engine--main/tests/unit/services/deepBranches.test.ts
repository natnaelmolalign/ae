import { DunningService } from '../../../src/services/DunningService';
import { ReportingService } from '../../../src/services/ReportingService';
import { BillingCycleService } from '../../../src/services/BillingCycleService';
import { BillingAnalyticsFacade } from '../../../src/services/BillingAnalyticsFacade';
import { InvoiceReconciliationService } from '../../../src/services/InvoiceReconciliationService';
import { InvoiceDocumentService } from '../../../src/services/InvoiceDocumentService';
import { OutboxService } from '../../../src/services/OutboxService';
import { MeteringService } from '../../../src/services/MeteringService';
import { WorkflowEngine } from '../../../src/services/WorkflowEngine';
import { RevenueRecognitionService } from '../../../src/services/RevenueRecognitionService';
import { BillingForecastEngine } from '../../../src/services/BillingForecastEngine';
import { CustomerService } from '../../../src/services/CustomerService';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { PaymentService } from '../../../src/services/PaymentService';
import { getTestDb } from '../../helpers/pgMemDb';
import { parseDate } from '../../../src/utils/dateUtils';

describe('Deep service branches', () => {
  it('dunning retry scheduling and cancel logic', async () => {
    const dunning = new DunningService();
    const stages = dunning.retryDelaysFromStages([
      { type: 'retry', delay_days: 1 },
      { type: 'retry', delay_days: 3 },
      { type: 'cancel', delay_days: 7 },
    ]);
    expect(stages).toEqual([1, 3]);
    expect(dunning.shouldCancelAfterRetries(
      [
        { type: 'retry', delay_days: 1 },
        { type: 'cancel', delay_days: 1 },
      ],
      1
    )).toBe(true);
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await dunning.scheduleRetriesForPolicy(sub.id, inv.id, plan.id, new Date());
    await dunning.scheduleRetriesForPolicy(sub.id, inv.id, plan.id, new Date());
    await dunning.getPolicyForPlan(plan.id);
  });

  it('reporting AR aging buckets and billing cycles', async () => {
    const customer = await createCustomer();
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await getTestDb()('invoices').where({ id: inv.id }).update({
      status: 'pending',
      due_date: '2020-01-01',
      total_cents: 5000,
    });
    const aging = await new ReportingService().arAging('2026-06-15');
    expect(aging.some((b) => b.bucket === '90_plus' && b.invoice_count >= 1)).toBe(true);
    const cycles = new BillingCycleService();
    await cycles.createForPeriod(
      sub.id,
      parseDate(sub.current_period_start),
      plan.interval,
      plan.billing_anchor_day
    );
    await cycles.getById(
      (await getTestDb()('billing_cycles').where({ subscription_id: sub.id }).first()).id
    );
  });

  it('analytics facade forecast and invoice document', async () => {
    const plan = await createPlan({ price_cents: 4000 });
    const customer = await createCustomer();
    await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const facade = new BillingAnalyticsFacade();
    await facade.monthOverMonth('2026-06');
    await facade.agingAndForecast();
    const engine = new BillingForecastEngine();
    await engine.newLogoImpact(5000, 1000, '2026-06');
    await engine.pipelineWeightedForecast();
    const sub = await new SubscriptionService().create({ customer_id: (await createCustomer()).id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await new PaymentService().chargeInvoice(inv.id, true);
    const text = await new InvoiceDocumentService().renderText(inv.id);
    expect(text.length).toBeGreaterThan(10);
    const rev = await new RevenueRecognitionService();
    await rev.listForInvoice(inv.id);
    await rev.summaryForSubscription(sub.id);
  });

  it('reconciliation unapplied and outbox idempotent usage', async () => {
    const recon = new InvoiceReconciliationService();
    await recon.unappliedPayments('2026-06');
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const dupes = await recon.duplicateLineDetection(inv.id);
    expect(Array.isArray(dupes)).toBe(true);
    const [ev] = await getTestDb()('domain_events')
      .insert({
        event_type: 'test.outbox',
        aggregate_type: 'invoice',
        aggregate_id: inv.id,
        payload: JSON.stringify({ ok: true }),
      })
      .returning('*');
    const [msg] = await getTestDb()('outbox_messages')
      .insert({ domain_event_id: ev.id, status: 'pending' })
      .returning('*');
    await new MeteringService().recordUsage({
      meter_code: 'x',
      subscription_id: sub.id,
      quantity: 1,
      idempotency_key: 'idem-1',
    }).catch(() => undefined);
    const outbox = new OutboxService();
    expect(await outbox.deliverOne(msg.id as string)).toBeDefined();
  });

  it('customer update 404 and workflow invalid trigger', async () => {
    await expect(new CustomerService().getById('00000000-0000-4000-8000-000000000099')).rejects.toBeDefined();
    await expect(new CustomerService().updateCountry('00000000-0000-4000-8000-000000000099', 'US')).rejects.toBeDefined();
    const wf = new WorkflowEngine();
    await wf.seedSubscriptionLifecycle();
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inst = await wf.start('subscription_lifecycle', 'subscription', sub.id, 'trialing', {});
    await expect(wf.trigger(inst.id, 'invalid_trigger', 'system', {})).rejects.toBeDefined();
  });
});
