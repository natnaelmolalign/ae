import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { createCustomer, createPlan } from '../../helpers/factories';

describe('SubscriptionService trial activation', () => {
  const service = new SubscriptionService();

  it('activates trial when trial_end has passed', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await service.create({
      customer_id: customer.id,
      plan_id: plan.id,
      billing_anchor: '2024-01-01',
      trial_days: 7,
    });
    expect(sub.status).toBe('trial');

    const activated = await service.activateEndedTrials(new Date('2024-01-10'));
    expect(activated).toHaveLength(1);
    expect(activated[0].status).toBe('active');
    expect(activated[0].current_period_start).toBeTruthy();
  });
});
