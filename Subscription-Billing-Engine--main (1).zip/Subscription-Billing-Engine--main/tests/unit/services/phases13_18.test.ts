import { BillingScheduleService } from '../../../src/services/BillingScheduleService';
import { ContractService } from '../../../src/services/ContractService';
import { DataExportService } from '../../../src/services/DataExportService';
import { ReportingService } from '../../../src/services/ReportingService';
import { PolicyEvaluationService } from '../../../src/services/PolicyEvaluationService';
import { HealthProbeService } from '../../../src/services/HealthProbeService';
import { PriceBook } from '../../../src/domain/pricing/PriceBook';
import { DiscountEngine } from '../../../src/domain/pricing/DiscountEngine';
import { UsageRatingEngine } from '../../../src/domain/pricing/UsageRatingEngine';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { AddonProductService } from '../../../src/services/AddonProductService';
import { SubscriptionItemService } from '../../../src/services/SubscriptionItemService';

describe('Phases 13-18', () => {
  describe('Billing schedules', () => {
    it('creates schedule and projects MRR', async () => {
      const customer = await createCustomer();
      const svc = new BillingScheduleService();
      const schedule = await svc.create({
        customer_id: customer.id,
        name: 'Enterprise',
        cadence: 'quarterly',
        anchor_day: 15,
        line_templates: [{ description: 'Platform', amount_cents: 30_000, quantity: 1 }],
      });
      expect(schedule.active).toBe(true);
      expect(svc.projectedMonthlyCents(schedule)).toBe(10_000);
    });
  });

  describe('Contracts', () => {
    it('activates and amends contract', async () => {
      const customer = await createCustomer();
      const svc = new ContractService();
      const c = await svc.create({
        customer_id: customer.id,
        reference: `CTR-${Date.now()}`,
        effective_from: '2026-06-01',
        committed_mrr_cents: 50_000,
      });
      const active = await svc.activate(c.id);
      expect(active.status).toBe('active');
      const amended = await svc.amend(c.id, 'mrr_change', { committed_mrr_cents: 60_000 });
      expect(amended.committed_mrr_cents).toBe(60_000);
    });
  });

  describe('Data export', () => {
    it('builds GDPR artifact', async () => {
      const customer = await createCustomer();
      const plan = await createPlan();
      await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
      const svc = new DataExportService();
      const req = await svc.request(customer.id);
      const done = await svc.process(req.id);
      expect(done.status).toBe('completed');
      expect((done.artifact as { customer: { id: string } }).customer.id).toBe(customer.id);
    });
  });

  describe('Reporting', () => {
    it('returns MRR snapshot and AR aging', async () => {
      const reports = new ReportingService();
      const mrr = await reports.mrrSnapshot('2026-06-02');
      expect(mrr.active_subscriptions).toBeGreaterThanOrEqual(0);
      const aging = await reports.arAging('2026-06-02');
      expect(aging.length).toBe(5);
    });
  });

  describe('Policy evaluation', () => {
    it('quotes with tax and discounts', () => {
      const q = new PolicyEvaluationService().quote({
        subtotal_cents: 10_000,
        country: 'DE',
        discount_codes: ['LAUNCH20'],
      });
      expect(q.total_cents).toBeGreaterThan(0);
      expect(q.discount_cents).toBeGreaterThan(0);
    });
  });

  describe('Domain pricing', () => {
    it('rates tiered seats and usage', () => {
      const book = PriceBook.defaultSaas();
      expect(book.unitPriceForQuantity('seat', 25)).toBeGreaterThan(0);
      const rated = new UsageRatingEngine().rate('api', 50_000, [
        { up_to: 10_000, unit_cents: 0 },
        { up_to: null, unit_cents: 1 },
      ]);
      expect(rated.amount_cents).toBe(40_000);
      const { total } = DiscountEngine.standardPromos().apply(20_000, ['CREDIT50']);
      expect(total).toBe(15_000);
    });
  });

  describe('Health probe', () => {
    it('reports database up', async () => {
      const report = await new HealthProbeService().probe();
      expect(report.database).toBe(true);
    });
  });

  describe('Subscription items', () => {
    it('adds addon and changes quantity with proration credit', async () => {
      const plan = await createPlan();
      const customer = await createCustomer();
      const sub = await new SubscriptionService().create({
        customer_id: customer.id,
        plan_id: plan.id,
      });
      const addonSvc = new AddonProductService();
      const code = `addon-${Date.now()}`;
      await addonSvc.create({ code, name: 'Extra seats', price_cents: 1000 });
      const items = new SubscriptionItemService();
      const list = await items.listActive(sub.id);
      const added = await items.addAddon(sub.id, code, 2);
      const changeDate =
        typeof sub.current_period_start === 'string'
          ? sub.current_period_start.slice(0, 10)
          : new Date(sub.current_period_start).toISOString().slice(0, 10);
      const result = await items.changeQuantity(added.id, 1, changeDate);
      expect(result.prorationCents).toBeLessThanOrEqual(0);
      expect(list.length).toBeGreaterThanOrEqual(1);
    });
  });
});
