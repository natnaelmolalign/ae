import { AddonProductService } from '../../../src/services/AddonProductService';
import { SubscriptionItemService } from '../../../src/services/SubscriptionItemService';
import { JobLockService } from '../../../src/services/JobLockService';
import { RevenueRecognitionService } from '../../../src/services/RevenueRecognitionService';
import { AnalyticsRollupService } from '../../../src/services/AnalyticsRollupService';
import { QuoteService } from '../../../src/services/QuoteService';
import { PaymentService } from '../../../src/services/PaymentService';
import { UnitOfWork } from '../../../src/repositories/UnitOfWork';
import { runAnalyticsJob } from '../../../src/jobs/analyticsJob';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { getTestDb } from '../../helpers/pgMemDb';

describe('Advanced phases 7–12', () => {
  describe('Phase 7 — subscription add-ons', () => {
    it('adds add-on and includes in invoice subtotal', async () => {
      const plan = await createPlan({ price_cents: 2000 });
      const customer = await createCustomer();
      const sub = await new SubscriptionService().create({
        customer_id: customer.id,
        plan_id: plan.id,
      });

      await new AddonProductService().create({
        code: 'seats',
        name: 'Extra seats',
        price_cents: 500,
      });
      await new SubscriptionItemService().addAddon(sub.id, 'seats', 2);

      const invoice = await new InvoiceService().generateForSubscription(sub, customer.country);
      expect(invoice.subtotal_cents).toBe(3000);
    });
  });

  describe('Phase 8 — job locks', () => {
    it('skips second concurrent job run', async () => {
      const lock = new JobLockService();
      const first = await lock.runExclusive('billing', async () => {
        const second = await lock.runExclusive('billing', async () => 99);
        expect(second.skipped).toBe(true);
        return 1;
      });
      expect(first.skipped).toBe(false);
      expect(first.result).toBe(1);
    });
  });

  describe('Phase 9 — revenue recognition', () => {
    it('creates schedule when invoice is paid', async () => {
      const plan = await createPlan();
      const customer = await createCustomer();
      const sub = await new SubscriptionService().create({
        customer_id: customer.id,
        plan_id: plan.id,
      });
      const invoice = await new InvoiceService().generateForSubscription(sub, customer.country);
      await new PaymentService().chargeInvoice(invoice.id, true, { flushOutbox: false });

      const rows = await new RevenueRecognitionService().listForInvoice(invoice.id);
      expect(rows.length).toBeGreaterThan(0);
      const total = rows.reduce((s, r) => s + Number(r.amount_cents), 0);
      expect(total).toBe(invoice.total_cents);
    });
  });

  describe('Phase 10 — analytics rollups', () => {
    it('rolls up daily stats', async () => {
      const days = await runAnalyticsJob(new Date(), 1);
      expect(days).toBeGreaterThanOrEqual(1);
      const stats = await new AnalyticsRollupService().listRecent(1);
      expect(stats.length).toBeGreaterThanOrEqual(1);
    });
  });

  describe('Phase 11 — unit of work', () => {
    it('runs transactional work through repositories', async () => {
      const plan = await createPlan();
      const customer = await createCustomer();
      const sub = await new SubscriptionService().create({
        customer_id: customer.id,
        plan_id: plan.id,
      });
      const invoice = await new InvoiceService().generateForSubscription(sub, customer.country);

      await UnitOfWork.run(async (uow) => {
        const inv = await uow.invoices.findByIdForUpdate(invoice.id);
        expect(inv).not.toBeNull();
        await uow.publish({
          eventType: 'test.uow',
          aggregateType: 'invoice',
          aggregateId: invoice.id,
          payload: { ok: true },
        });
      });

      const events = await getTestDb()('domain_events').where({ event_type: 'test.uow' });
      expect(events.length).toBe(1);
    });
  });

  describe('Phase 12 — quotes', () => {
    it('converts quote to subscription and invoice', async () => {
      const plan = await createPlan();
      const customer = await createCustomer();
      const quote = await new QuoteService().create({
        customer_id: customer.id,
        lines: [
          {
            description: `${plan.name} plan`,
            quantity: 1,
            unit_price_cents: plan.price_cents,
            plan_id: plan.id,
          },
        ],
      });

      const result = await new QuoteService().convertToSubscription(quote.id as string);
      expect(result.subscription).toBeDefined();
      expect(result.invoice).toBeDefined();
      const updated = await getTestDb()('quotes').where({ id: quote.id }).first();
      expect(updated?.status).toBe('converted');
    });
  });
});
