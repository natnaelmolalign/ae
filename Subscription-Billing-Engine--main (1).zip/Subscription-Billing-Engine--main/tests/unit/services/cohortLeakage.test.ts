import { CohortAnalysisService } from '../../../src/services/CohortAnalysisService';
import { RevenueLeakageService } from '../../../src/services/RevenueLeakageService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';

describe('Cohort and leakage analytics', () => {
  it('builds cohort retention matrix', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const matrix = await new CohortAnalysisService().buildRetentionMatrix(3, 2);
    expect(Array.isArray(matrix)).toBe(true);
  });

  it('scans revenue leakage', async () => {
    const findings = await new RevenueLeakageService().scan();
    expect(Array.isArray(findings)).toBe(true);
    expect(await new RevenueLeakageService().totalLeakageCents()).toBeGreaterThanOrEqual(0);
  });
});
