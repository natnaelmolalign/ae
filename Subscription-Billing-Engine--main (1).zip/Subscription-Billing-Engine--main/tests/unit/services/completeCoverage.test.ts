import { BillingReconciliationService } from '../../../src/services/BillingReconciliationService';
import { RevenueLeakageService } from '../../../src/services/RevenueLeakageService';
import { BillingDisputeService } from '../../../src/services/BillingDisputeService';
import { EventProjectionService } from '../../../src/services/EventProjectionService';
import { BillingPeriodCloseService } from '../../../src/services/BillingPeriodCloseService';
import { PaymentMethodVaultService } from '../../../src/services/PaymentMethodVaultService';
import { AnalyticsRollupService } from '../../../src/services/AnalyticsRollupService';
import { BillingAlertService } from '../../../src/services/BillingAlertService';
import { DataExportService } from '../../../src/services/DataExportService';
import { InvoiceDocumentService } from '../../../src/services/InvoiceDocumentService';
import { BillingForecastService } from '../../../src/services/BillingForecastService';
import { CustomerInsightsService } from '../../../src/services/CustomerInsightsService';
import { TaxComplianceReportService } from '../../../src/services/TaxComplianceReportService';
import { CustomerLifecycleAnalyticsService } from '../../../src/services/CustomerLifecycleAnalyticsService';
import { InvoiceReconciliationService } from '../../../src/services/InvoiceReconciliationService';
import { ReportingService } from '../../../src/services/ReportingService';
import { AppError } from '../../../src/lib/errors';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { PaymentService } from '../../../src/services/PaymentService';
import { getTestDb } from '../../helpers/pgMemDb';

describe('Complete service branch coverage', () => {
  it('reconciliation assertBalanced throws on mismatch', async () => {
    const plan = await createPlan({ price_cents: 1000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await getTestDb()('invoice_line_items').insert({
      invoice_id: inv.id,
      description: 'extra line',
      amount_cents: 500,
      type: 'adjustment',
    });
    await getTestDb()('invoices').where({ id: inv.id }).update({ status: 'paid', subtotal_cents: 100 });
    const svc = new BillingReconciliationService();
    const report = await svc.reconcileOpenInvoices();
    expect(report.balanced).toBe(false);
    await expect(svc.assertBalanced()).rejects.toMatchObject({ statusCode: 409 });
  });

  it('revenue leakage scan paths', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await getTestDb()('invoices').where({ id: inv.id }).update({
      status: 'pending',
      due_date: '2020-01-01',
    });
    const leakage = new RevenueLeakageService();
    const findings = await leakage.scan();
    expect(findings.length).toBeGreaterThan(0);
    expect(await leakage.totalLeakageCents()).toBeGreaterThanOrEqual(0);
  });

  it('disputes list open and event projections', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const dispute = await new BillingDisputeService().open(inv.id, 50, 'duplicate');
    await new BillingDisputeService().transition(dispute.id, 'won');
    expect((await new BillingDisputeService().listOpen()).length).toBeGreaterThanOrEqual(0);
    await getTestDb()('domain_events').insert({
      event_type: 'subscription.updated',
      aggregate_type: 'subscription',
      aggregate_id: sub.id,
      payload: JSON.stringify({}),
    });
    const proj = new EventProjectionService();
    expect(await proj.rebuildSubscriptionSummary()).toBeGreaterThan(0);
    const timeline = await proj.timeline('subscription', sub.id);
    expect(timeline.length).toBeGreaterThan(0);
  });

  it('period close list and payment vault default swap', async () => {
    const close = new BillingPeriodCloseService();
    const list = await close.list();
    expect(Array.isArray(list)).toBe(true);
    const customer = await createCustomer();
    const vault = new PaymentMethodVaultService();
    await expect(
      vault.store({
        customer_id: customer.id,
        brand: 'visa',
        last4: '12345',
        exp_month: 1,
        exp_year: 2030,
      })
    ).rejects.toBeInstanceOf(AppError);
    const m1 = await vault.store({
      customer_id: customer.id,
      brand: 'visa',
      last4: '1111',
      exp_month: 1,
      exp_year: 2030,
      set_default: true,
    });
    const m2 = await vault.store({
      customer_id: customer.id,
      brand: 'mc',
      last4: '2222',
      exp_month: 2,
      exp_year: 2031,
      set_default: true,
    });
    expect(m2.default_method).toBe(true);
    const defaulted = await vault.setDefault(m1.id, customer.id);
    expect(defaulted.default_method).toBe(true);
    expect(vault.maskForDisplay(m1).last4).toBe('1111');
    await vault.remove(m2.id, customer.id);
    expect(await vault.getDefault(customer.id)).toBeTruthy();
    await expect(vault.remove('00000000-0000-4000-8000-000000000099', customer.id)).rejects.toBeInstanceOf(AppError);
  });

  it('period close already closed and tax compliance paths', async () => {
    const svc = new BillingPeriodCloseService();
    await svc.openPeriod('2099-10-01', '2099-10-31');
    await svc.reconcile('2099-10-01', '2099-10-31');
    const closed = await svc.close('2099-10-01', '2099-10-31');
    expect(closed.status).toBe('closed');
    const again = await svc.openPeriod('2099-10-01', '2099-10-31');
    expect(again.status).toBe('closed');
    await expect(svc.reconcile('2099-12-01', '2099-12-31')).rejects.toBeInstanceOf(AppError);
    const tax = new TaxComplianceReportService();
    const customer = await createCustomer({ country: 'FR' });
    await tax.customerTaxProfile(customer.id);
    await tax.missingTaxInvoices('2026-06');
    await tax.auditTrailForPeriod('2026-06');
    const lifecycle = new CustomerLifecycleAnalyticsService();
    await lifecycle.exportLifecycleCsv();
    const recon = new InvoiceReconciliationService();
    await recon.fixLineSubtotals(
      (
        await new InvoiceService().generateForSubscription(
          await new SubscriptionService().create({
            customer_id: customer.id,
            plan_id: (await createPlan()).id,
          }),
          customer.country
        )
      ).id
    );
    const reports = new ReportingService();
    await reports.arAging('2026-06-15');
    await reports.mrrSnapshot('2026-06-01');
    const rollup = new AnalyticsRollupService();
    expect(await rollup.getDaily('2099-01-01')).toBeNull();
    await rollup.rollupRange(new Date('2026-06-01'), 2);
  });

  it('analytics rollup alerts export document forecast', async () => {
    const customer = await createCustomer();
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await new PaymentService().chargeInvoice(inv.id, true);
    const rollup = new AnalyticsRollupService();
    await rollup.rollupDay(new Date('2026-06-01'));
    const alert = await new BillingAlertService().raise('cov', 'warning', { k: 1 });
    await new BillingAlertService().listOpen('warning');
    await new BillingAlertService().evaluatePaymentFailureSpike(0);
    await new BillingAlertService().evaluatePastDueSubscriptions(0);
    await new BillingAlertService().acknowledge(alert.id);
    const exp = await new DataExportService().request(customer.id);
    await new DataExportService().process(exp.id);
    const text = await new InvoiceDocumentService().renderText(inv.id);
    expect(text).toContain('INVOICE');
    const scenario = await new BillingForecastService().runDefaultScenario('2026-06-01', 2);
    expect(scenario.length).toBe(2);
    const risk = await new CustomerInsightsService().atRiskCustomers();
    expect(Array.isArray(risk)).toBe(true);
  });
});
