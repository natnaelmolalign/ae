import { CouponService } from '../../../src/services/CouponService';
import { createPlan } from '../../helpers/factories';

describe('CouponService', () => {
  const service = new CouponService();

  it('creates and applies coupons', async () => {
    const plan = await createPlan();
    const coupon = await service.create({
      code: 'half',
      discount_type: 'percent',
      discount_value: 50,
      plan_ids: [plan.id],
    });
    const applied = await service.validateAndApply(coupon.code, plan.id, 1000);
    expect(applied.discountCents).toBe(500);
    expect(service.applyDiscount(1000, coupon)).toBe(500);
  });

  it('rejects expired and wrong-plan coupons', async () => {
    const plan = await createPlan();
    await service.create({
      code: 'OLD',
      discount_type: 'fixed',
      discount_value: 100,
      expires_at: new Date('2020-01-01'),
    });
    await expect(service.validateAndApply('OLD', plan.id, 500)).rejects.toThrow('expired');

    await service.create({
      code: 'OTHER',
      discount_type: 'fixed',
      discount_value: 100,
      plan_ids: ['00000000-0000-4000-8000-000000000001'],
    });
    await expect(service.validateAndApply('OTHER', plan.id, 500)).rejects.toThrow('not valid');
  });
});
