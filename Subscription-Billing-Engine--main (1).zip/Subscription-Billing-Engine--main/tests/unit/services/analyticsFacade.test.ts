import request from 'supertest';
import { createApp } from '../../../src/app';
import { BillingAnalyticsFacade } from '../../../src/services/BillingAnalyticsFacade';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('BillingAnalyticsFacade', () => {
  const app = createApp();
  const facade = new BillingAnalyticsFacade();

  it('builds executive dashboard', async () => {
    const plan = await createPlan({ price_cents: 3500 });
    const customer = await createCustomer();
    await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const dash = await facade.executiveDashboard('2026-06');
    expect(dash.mrr_cents).toBeGreaterThan(0);
    const health = await facade.healthScore('2026-06');
    expect(health.score).toBeGreaterThan(0);
    const api = await request(app).get('/analytics-board/2026-06').set('x-api-key', API_KEY);
    expect(api.status).toBe(200);
    const pack = await facade.exportBoardPack('2026-06');
    expect(pack.dashboard.period_key).toBe('2026-06');
    const cohorts = await facade.cohortSummary();
    expect(cohorts.length).toBeGreaterThan(0);
  });
});
