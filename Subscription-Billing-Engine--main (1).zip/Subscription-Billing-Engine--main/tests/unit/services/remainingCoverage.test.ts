import request from 'supertest';
import { createApp } from '../../../src/app';
import { WebhookService } from '../../../src/services/WebhookService';
import { CreditService } from '../../../src/services/CreditService';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { PlanService } from '../../../src/services/PlanService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';
import { resetEnvForTests, loadEnv } from '../../../src/config/env';
import { rateLimiter } from '../../../src/middleware/rateLimiter';
import { toDateString, anchorDayInMonth } from '../../../src/utils/dateUtils';

const API_KEY = 'test-api-key-32chars-minimum';

describe('remaining coverage', () => {
  it('covers credit apply, validation errors, and plan lookup', async () => {
    const credit = new CreditService();
    await expect(
      credit.issue({ customer_id: 'x', amount_cents: 0, reason: 'x' })
    ).rejects.toThrow('positive');

    const customer = await createCustomer();
    await credit.issue({
      customer_id: customer.id,
      amount_cents: 500,
      reason: 'topup',
    });
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const invoices = new InvoiceService();
    const invoice = await invoices.createProrationCharge(sub, 1000, 'manual credit test');
    const applied = await credit.applyToInvoice(customer.id, invoice.id, 200, 'pending');
    expect(applied).toBe(200);
    expect(await credit.applyToInvoice(customer.id, invoice.id, 200, 'void')).toBe(0);

    await expect(credit.refundToCredit(customer.id, 50, 100)).rejects.toThrow('exceed');

    const plans = new PlanService();
    await expect(plans.getById('00000000-0000-4000-8000-000000000099')).rejects.toThrow();
    await plans.list(false);
    await plans.list(true);
    await plans.updatePrice(plan.id, 1500);
  });

  it('covers subscription edge transitions', async () => {
    const subs = new SubscriptionService();
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await subs.create({
      customer_id: customer.id,
      plan_id: plan.id,
      billing_anchor: '2024-03-31',
    });

    await expect(subs.pause(sub.id)).resolves.toBeDefined();
    await expect(
      subs.changePlanAtPeriodEnd(sub.id, plan.id, new Date('2024-01-01'))
    ).rejects.toThrow('Period-end');

    await subs.transition(sub.id, 'cancelled');
    await expect(subs.reactivate(sub.id)).resolves.toBeDefined();

    const trial = await subs.create({
      customer_id: customer.id,
      plan_id: plan.id,
      trial_days: 5,
    });
    await expect(subs.extendTrial(trial.id, 2)).resolves.toBeDefined();
    await subs.renewIfDue(trial.id, new Date('2099-01-01'));
    await subs.expireDue(new Date('2099-01-01'));
    await subs.applyPlanPriceOnRenewal(plan);
  });

  it('delivers webhooks with mocked fetch', async () => {
    const prevUrl = process.env.WEBHOOK_URL;
    process.env.WEBHOOK_URL = 'https://example.com/hook';
    process.env.WEBHOOK_SECRET = 'test-webhook-secret-32chars';
    resetEnvForTests();

    const service = new WebhookService();
    await service.enqueue('invoice.paid', { id: '1' });

    const okFetch = jest.fn().mockResolvedValue({ ok: true });
    global.fetch = okFetch as typeof fetch;
    expect(await service.deliverPending()).toBe(1);

    await service.enqueue('payment.failed', { id: '2' });
    global.fetch = jest.fn().mockResolvedValue({ ok: false, status: 500 }) as typeof fetch;
    expect(await service.deliverPending()).toBe(0);

    process.env.WEBHOOK_URL = prevUrl ?? '';
    resetEnvForTests();
    loadEnv();
  });

  it('rate limits excessive requests', () => {
    const req = { ip: '127.0.0.1' } as Parameters<typeof rateLimiter>[0];
    const res = { status: jest.fn().mockReturnThis(), json: jest.fn() } as unknown as Parameters<
      typeof rateLimiter
    >[1];
    const next = jest.fn();
    for (let i = 0; i < 125; i++) {
      rateLimiter(req, res, next);
    }
    expect(res.status).toHaveBeenCalledWith(429);
  });

  it('hits route validation branches', async () => {
    const app = createApp();
    await request(app)
      .get('/plans/not-a-uuid')
      .set('x-api-key', API_KEY)
      .expect(400);
    await request(app)
      .patch('/plans/00000000-0000-4000-8000-000000000001/price')
      .set('x-api-key', API_KEY)
      .send({ price_cents: -1 })
      .expect(400);
    await request(app)
      .get('/customers/not-a-uuid')
      .set('x-api-key', API_KEY)
      .expect(400);
    await request(app)
      .get('/invoices/not-a-uuid')
      .set('x-api-key', API_KEY)
      .expect(400);
    await request(app)
      .post('/payments/not-a-uuid/refund')
      .set('x-api-key', API_KEY)
      .send({ amount_cents: 10 })
      .expect(400);
  });

  it('covers dateUtils yearly paths', () => {
    expect(anchorDayInMonth(2024, 5, 31)).toBe(30);
    expect(toDateString(new Date(2024, 0, 15))).toMatch(/2024-01-15/);
  });

  it('voids invoice via API', async () => {
    const app = createApp();
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const invoice = await new InvoiceService().generateForSubscription(sub, 'US');
    await request(app)
      .post(`/invoices/${invoice.id}/void`)
      .set('x-api-key', API_KEY)
      .expect(200);
    await getTestDb()('invoices').where({ id: invoice.id }).update({ status: 'paid' });
    await request(app)
      .post('/payments/charge')
      .set('x-api-key', API_KEY)
      .send({ invoice_id: invoice.id })
      .expect(400);
  });
});
