import { EntitlementCacheService } from '../../../src/services/EntitlementCacheService';
import { UsageAggregationService } from '../../../src/services/UsageAggregationService';
import { InvoiceAdjustmentService } from '../../../src/services/InvoiceAdjustmentService';
import { ApiKeyRotationService } from '../../../src/services/ApiKeyRotationService';
import { PrincipalService } from '../../../src/services/RbacService';
import { MeteringService } from '../../../src/services/MeteringService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { PaymentService } from '../../../src/services/PaymentService';
import { getTestDb } from '../../helpers/pgMemDb';
import { runCliCommand } from '../../../src/cli';
import { CircuitBreaker } from '../../../src/lib/CircuitBreaker';
import { getSupportedApiVersions } from '../../../src/middleware/apiVersion';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Coverage gap services', () => {
  beforeAll(async () => {
    await new PrincipalService().bootstrapFromEnvMasterKey(API_KEY);
  });

  it('entitlement cache hit and invalidate', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    await getTestDb()('plan_entitlements').insert({
      plan_id: plan.id,
      feature_key: 'api_calls',
      limit_type: 'count',
      limit_value: 100,
      reset_interval: 'monthly',
    });
    const cache = new EntitlementCacheService();
    const first = await cache.check(sub.id, 'api_calls');
    const second = await cache.check(sub.id, 'api_calls');
    expect(second.cached_at).toBe(first.cached_at);
    cache.invalidate(sub.id, 'api_calls');
    cache.invalidate(sub.id);
    const third = await cache.check(sub.id, 'api_calls');
    expect(third.cached_at).not.toBe(first.cached_at);
  });

  it('usage aggregation with meter', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    await new MeteringService().createMeter({
      code: 'api_calls',
      name: 'API Calls',
      tier_config: [{ up_to: null, unit_price_cents: 1 }],
    });
    const svc = new UsageAggregationService();
    const row = await svc.ingestAndAggregate(sub.id, 'api_calls', 50, '2026-06-02T12:00:00Z');
    expect(row?.quantity).toBe(50);
    const total = await svc.totalRatedCents(sub.id, '2026-06-01', '2026-06-30');
    expect(total).toBeGreaterThan(0);
    const all = await svc.aggregateAllActive('2026-06-01', '2026-06-30');
    expect(all.length).toBeGreaterThan(0);
  });

  it('invoice adjustment on paid invoice', async () => {
    const plan = await createPlan({ price_cents: 5000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await new PaymentService().chargeInvoice(inv.id, true);
    const adj = await new InvoiceAdjustmentService().apply({
      invoice_id: inv.id,
      reason: 'goodwill',
      line_adjustments: [{ description: 'Credit', amount_cents: 500 }],
    });
    expect(adj.total_cents).toBe(500);
    const list = await new InvoiceAdjustmentService().listForInvoice(inv.id);
    expect(list.length).toBeGreaterThan(0);
  });

  it('api key rotation', async () => {
    const principals = new PrincipalService();
    const { principal } = await principals.create('rotate-me', ['billing_readonly']);
    const rotated = await new ApiKeyRotationService().rotate(principal.id);
    expect(rotated.api_key).toMatch(/^sk_/);
    const hist = await new ApiKeyRotationService().history(principal.id);
    expect(hist.length).toBeGreaterThan(0);
    await expect(new ApiKeyRotationService().rotate('00000000-0000-4000-8000-000000000099')).rejects.toBeDefined();
  });

  it('cli commands', async () => {
    expect(await runCliCommand('billing')).toMatch(/billing/);
    expect(await runCliCommand('retry')).toMatch(/retry/);
    expect(await runCliCommand('webhooks')).toMatch(/webhook/);
    expect(await runCliCommand('outbox')).toMatch(/outbox/);
    expect(await runCliCommand('analytics')).toMatch(/analytics/);
    expect(await runCliCommand('retention')).toMatch(/retention/);
    expect(await runCliCommand('export')).toMatch(/export/);
    expect(await runCliCommand('forecast')).toMatch(/forecast/);
  });

  it('circuit breaker recovers after failure', async () => {
    const cb = new CircuitBreaker('cov', { failureThreshold: 1, resetTimeoutMs: 1, halfOpenSuccesses: 1 });
    await expect(cb.execute(async () => { throw new Error('x'); })).rejects.toBeDefined();
    await new Promise((r) => setTimeout(r, 5));
    const result = await cb.execute(async () => 'ok');
    expect(result).toBe('ok');
    expect(cb.getState()).toBe('closed');
  });

  it('api versions', () => {
    expect(getSupportedApiVersions()).toContain('2026-06-01');
  });

  it('cli rejects unknown command', async () => {
    await expect(runCliCommand('not-a-command')).rejects.toThrow(/Unknown command/);
    await expect(runCliCommand('')).rejects.toThrow(/Missing CLI command/);
  });
});
