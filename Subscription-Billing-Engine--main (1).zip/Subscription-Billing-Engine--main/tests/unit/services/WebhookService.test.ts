import { WebhookService } from '../../../src/services/WebhookService';

describe('WebhookService', () => {
  const service = new WebhookService();

  it('signs payload deterministically', () => {
    const sig = service.signPayload('{"a":1}', 'secret-key-32chars-minimum');
    expect(sig).toHaveLength(64);
    expect(service.signPayload('{"a":1}', 'secret-key-32chars-minimum')).toBe(sig);
  });

  it('enqueues webhook events', async () => {
    const id = await service.enqueue('invoice.paid', { invoice_id: 'x' });
    expect(id).toBeTruthy();
  });
});
