import { BillingWaterfallService } from '../../../src/services/BillingWaterfallService';
import { BillingForecastEngine } from '../../../src/services/BillingForecastEngine';
import { BillingAnalyticsFacade } from '../../../src/services/BillingAnalyticsFacade';
import { UsageAggregationService } from '../../../src/services/UsageAggregationService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { CouponService } from '../../../src/services/CouponService';
import { AddonProductService } from '../../../src/services/AddonProductService';
import { SubscriptionItemService } from '../../../src/services/SubscriptionItemService';
import { CreditNoteService } from '../../../src/services/CreditNoteService';
import { MeteringService } from '../../../src/services/MeteringService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { PaymentService } from '../../../src/services/PaymentService';
import type { Subscription } from '../../../src/models/Subscription';
import { InvoiceReconciliationService } from '../../../src/services/InvoiceReconciliationService';

describe('Full coverage sweep 11 — priority branch targets', () => {
  it('InvoiceService stale coupon plan-only zero-line fallback and GB tax', async () => {
    const invoices = new InvoiceService();
    const plan = await createPlan({ price_cents: 3200 });
    const gbCustomer = await createCustomer({ country: 'GB' });

    const code = `SW11-${Date.now()}`;
    await new CouponService().create({
      code,
      discount_type: 'percent',
      discount_value: 10,
      usage_limit: 5,
    });
    const withCoupon = await new SubscriptionService().create({
      customer_id: gbCustomer.id,
      plan_id: plan.id,
      coupon_code: code,
    });
    const gbInv = await invoices.generateForSubscription(withCoupon, 'GB');
    expect(gbInv.tax_cents).toBeGreaterThan(0);

    const staleSub = await new SubscriptionService().create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
    });
    const staleCoupon: Subscription = {
      ...staleSub,
      coupon_id: '00000000-0000-4000-8000-000000000099',
    };
    const noRowDiscount = await invoices.generateForSubscription(staleCoupon, 'US');
    expect(Number(noRowDiscount.discount_cents)).toBe(0);

    const fallbackSub = await new SubscriptionService().create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
    });
    await getTestDb()('subscription_items')
      .where({ subscription_id: fallbackSub.id })
      .update({ unit_price_cents: 0 });
    const fallbackInv = await invoices.generateForSubscription(fallbackSub, 'US');
    expect(Number(fallbackInv.subtotal_cents)).toBe(plan.price_cents);

    const planOnlySub = await new SubscriptionService().create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
    });
    await getTestDb()('subscription_items').where({ subscription_id: planOnlySub.id }).del();
    const planOnly = await invoices.generateForSubscription(planOnlySub, 'US');
    expect(
      (await invoices.getLineItems(planOnly.id)).some((l) => l.type === 'subscription')
    ).toBe(true);

    const addonCode = `sw11-addon-${Date.now()}`;
    await new AddonProductService().create({ code: addonCode, name: 'API', price_cents: 400 });
    const addonSub = await new SubscriptionService().create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
    });
    await new SubscriptionItemService().addAddon(addonSub.id, addonCode, 2);
    const addonInv = await invoices.generateForSubscription(addonSub, 'US');
    expect((await invoices.getLineItems(addonInv.id)).some((l) => l.type === 'addon')).toBe(true);
  });

  it('BillingWaterfallService aging buckets credit notes and top customers', async () => {
    const wf = new BillingWaterfallService();
    const plan = await createPlan({ price_cents: 4000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const db = getTestDb();
    const now = Date.now();
    const bucketDays = [15, 45, 75, 120];
    for (const days of bucketDays) {
      await db('invoices').insert({
        subscription_id: sub.id,
        status: 'pending',
        subtotal_cents: 500,
        tax_cents: 0,
        discount_cents: 0,
        credit_applied_cents: 0,
        total_cents: 500,
        due_date: '2026-06-01',
        issued_at: '2026-06-01',
        created_at: new Date(now - days * 86400000),
      });
    }
    const aging = await wf.agingBuckets(new Date());
    expect(aging.every((b) => b.outstanding_cents >= 0)).toBe(true);
    expect(aging.find((b) => b.bucket === '31-60')?.outstanding_cents).toBeGreaterThan(0);
    expect(aging.find((b) => b.bucket === '90+')?.outstanding_cents).toBeGreaterThan(0);

    await new CreditNoteService().issue({
      invoice_id: inv.id,
      amount_cents: 50,
      reason: 'partial refund',
    });
    await new PaymentService().chargeInvoice(inv.id, true, { flushOutbox: false });
    const report = await wf.buildForPeriod('2026-06', 'EUR');
    expect(report.currency).toBe('EUR');
    expect(report.steps.some((s) => s.label === 'Credit notes')).toBe(true);

    const tops = await wf.topCustomersByRevenue('2026-06', 5);
    expect(tops.length).toBeGreaterThan(0);
    expect(String((tops[0] as { email?: string }).email ?? '')).not.toBe('');
  });

  it('BillingAnalyticsFacade counts only error severities in drill-down', async () => {
    const facade = new BillingAnalyticsFacade();
    const plan = await createPlan({ price_cents: 6000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const db = getTestDb();
    await db('invoices').where({ id: inv.id }).update({
      status: 'paid',
      created_at: new Date('2026-06-03T12:00:00Z'),
    });
    await db('payments').insert({
      invoice_id: inv.id,
      status: 'succeeded',
      amount_cents: 1,
      attempted_at: new Date('2026-06-03T12:00:00Z'),
    });

    const drill = await facade.drillDown('2026-06', 3);
    expect(drill.reconciliation_errors).toBe(0);
    const recon = await new InvoiceReconciliationService().runForPeriod('2026-06');
    expect(recon.mismatches.some((m) => m.severity === 'warning')).toBe(true);

    const engine = new BillingForecastEngine();
    await engine.exportForecastCsv();
    const july = await facade.monthOverMonth('2026-07');
    expect(july.previous.period_key).toBe('2026-06');
    await facade.cohortSummary();
  });

  it('UsageAggregationService unit_cents tiers aggregateAll and totalRated', async () => {
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
    });
    const db = getTestDb();
    const [meter] = await db('meters')
      .insert({
        code: 'sw11-unit-cents',
        name: 'Unit cents',
        aggregation: 'sum',
        tier_config: JSON.stringify([
          { up_to: 100, unit_cents: 4 },
          { up_to: null, unit_cents: 2 },
        ]),
      })
      .returning('*');
    await db('usage_records').insert({
      meter_id: meter.id,
      subscription_id: sub.id,
      quantity: 150,
      recorded_at: new Date('2026-06-12T12:00:00Z'),
    });
    await db('meters').insert({
      code: 'sw11-empty',
      name: 'No usage',
      aggregation: 'sum',
      tier_config: JSON.stringify([{ up_to: null, unit_cents: 1 }]),
    });

    const agg = new UsageAggregationService();
    const rows = await agg.aggregateForSubscription(sub.id, '2026-06-01', '2026-06-30');
    expect(rows.find((r) => r.meter === 'sw11-unit-cents')?.rated_cents).toBeGreaterThan(0);
    expect(rows.some((r) => r.meter === 'sw11-empty')).toBe(false);

    const total = await agg.totalRatedCents(sub.id, '2026-06-01', '2026-06-30');
    expect(total).toBe(rows.reduce((s, r) => s + r.rated_cents, 0));

    await new MeteringService().createMeter({
      code: 'sw11-ingest',
      name: 'Ingest',
      tier_config: [{ up_to: null, unit_price_cents: 3 }],
    });
    const hit = await agg.ingestAndAggregate(sub.id, 'sw11-ingest', 4, '2026-06-14T12:00:00Z');
    expect(hit?.quantity).toBe(4);

    await new MeteringService().createMeter({
      code: 'sw11-price-only',
      name: 'Price only tier',
      tier_config: [{ up_to: 20, unit_price_cents: 6 }, { up_to: null, unit_price_cents: 3 }],
    });
    await new MeteringService().recordUsage({
      subscription_id: sub.id,
      meter_code: 'sw11-price-only',
      quantity: 25,
      recorded_at: new Date('2026-06-13T12:00:00Z'),
    });
    const priceOnly = await agg.aggregateForSubscription(sub.id, '2026-06-01', '2026-06-30');
    expect(priceOnly.find((r) => r.meter === 'sw11-price-only')?.rated_cents).toBeGreaterThan(0);

    const all = await agg.aggregateAllActive('2026-06-01', '2026-06-30');
    expect(all.length).toBeGreaterThanOrEqual(3);

    await agg.ingestAndAggregate(sub.id, 'sw11-ingest', 2, '2026-06-15T12:00:00Z');
    const missing = await agg.ingestAndAggregate(sub.id, 'SW11-INGEST', 1, '2026-06-16T12:00:00Z');
    expect(missing).toBeNull();
  });

  it('BillingForecastEngine empty history branches via mocked deps', async () => {
    const engine = new BillingForecastEngine();
    jest.spyOn(engine, 'trailingMrr').mockResolvedValue([]);
    jest.spyOn(BillingWaterfallService.prototype, 'forecastFromHistory').mockResolvedValue([]);
    const empty = await engine.projectNextMonths(1);
    expect(empty[0].projected_mrr_cents).toBe(0);
    expect(empty[0].projected_collections_cents).toBe(0);
  });
});
