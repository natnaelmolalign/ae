import { ReportingService } from '../../../src/services/ReportingService';
import { InvoiceReconciliationService } from '../../../src/services/InvoiceReconciliationService';
import { runAnalyticsJob } from '../../../src/jobs/analyticsJob';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { getTestDb } from '../../helpers/pgMemDb';

describe('Reporting and reconciliation branches', () => {
  it('AR aging hits every bucket and yearly MRR normalization', async () => {
    const customer = await createCustomer();
    const monthly = await createPlan({ price_cents: 3000, interval: 'monthly' });
    const yearly = await createPlan({ price_cents: 12000, interval: 'yearly' });
    const subM = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: monthly.id,
    });
    await new SubscriptionService().create({ customer_id: customer.id, plan_id: yearly.id });
    const db = getTestDb();
    const asOf = '2026-06-15';
    const buckets: Record<string, string> = {
      current: '2026-06-15',
      '1_30': '2026-06-10',
      '31_60': '2026-05-15',
      '61_90': '2026-04-01',
      '90_plus': '2020-01-01',
    };
    const invoiceIds: string[] = [];
    for (const _bucket of Object.keys(buckets)) {
      const sub = await new SubscriptionService().create({
        customer_id: customer.id,
        plan_id: monthly.id,
      });
      const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
      invoiceIds.push(inv.id);
    }
    let i = 0;
    for (const [, due] of Object.entries(buckets)) {
      await db('invoices').where({ id: invoiceIds[i] }).update({
        status: 'pending',
        due_date: due,
        total_cents: 1000,
      });
      i += 1;
    }
    const aging = await new ReportingService().arAging(asOf);
    for (const key of Object.keys(buckets)) {
      expect(aging.find((b) => b.bucket === key)?.invoice_count).toBeGreaterThanOrEqual(1);
    }
    const mrr = await new ReportingService().mrrSnapshot(asOf);
    expect(mrr.mrr_cents).toBeGreaterThan(3000);
    expect(mrr.arr_cents).toBe(mrr.mrr_cents * 12);
  });

  it('revenue churn and failed payment summaries', async () => {
    const reporting = new ReportingService();
    const customer = await createCustomer();
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await getTestDb()('invoices').where({ id: inv.id }).update({
      status: 'paid',
      updated_at: new Date('2026-06-01T12:00:00Z'),
    });
    const revenue = await reporting.revenueByPlan('2026-05-01', '2026-07-01');
    expect(revenue.some((r) => r.plan_id === plan.id)).toBe(true);
    await getTestDb()('subscriptions').where({ id: sub.id }).update({
      status: 'cancelled',
      updated_at: new Date('2026-06-02T12:00:00Z'),
    });
    const churn = await reporting.churnRate('2026-06-01', '2026-06-30');
    expect(churn.cancelled).toBeGreaterThanOrEqual(1);
    await getTestDb()('payments').insert({
      invoice_id: inv.id,
      status: 'failed',
      amount_cents: 500,
      attempted_at: new Date('2026-06-03T12:00:00Z'),
    });
    const failed = await reporting.failedPaymentSummary('2026-06-01', '2026-06-30');
    expect(failed.count).toBeGreaterThanOrEqual(1);
    expect(failed.total_cents).toBeGreaterThanOrEqual(500);
  });

  it('reconciliation detects mismatches paid gaps and export', async () => {
    const recon = new InvoiceReconciliationService();
    await expect(recon.runForPeriod('not-valid')).rejects.toMatchObject({ statusCode: 400 });
    await expect(
      recon.reconcileInvoice('00000000-0000-4000-8000-000000000099')
    ).rejects.toMatchObject({ statusCode: 404 });

    const customer = await createCustomer();
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const db = getTestDb();
    await db('invoices').where({ id: inv.id }).update({
      subtotal_cents: 9999,
      total_cents: 9999,
      status: 'paid',
      created_at: new Date('2026-06-05T12:00:00Z'),
    });
    await db('payments').insert({
      invoice_id: inv.id,
      status: 'succeeded',
      amount_cents: 1,
      attempted_at: new Date('2026-06-05T12:00:00Z'),
    });
    await db('invoice_line_items').insert({
      invoice_id: inv.id,
      description: 'dup-line',
      type: 'subscription',
      amount_cents: 100,
    });
    await db('invoice_line_items').insert({
      invoice_id: inv.id,
      description: 'dup-line',
      type: 'subscription',
      amount_cents: 100,
    });

    const run = await recon.runForPeriod('2026-06');
    expect(run.mismatches.length).toBeGreaterThan(0);
    expect(run.balanced).toBe(false);
    const dupes = await recon.duplicateLineDetection(inv.id);
    expect(dupes.length).toBeGreaterThanOrEqual(1);
    const summary = await recon.summaryByStatus('2026-06');
    expect(summary.length).toBeGreaterThan(0);
    const csv = await recon.exportReport('2026-06');
    expect(csv).toContain('invoice_id');
    await recon.fixLineSubtotals(inv.id);
    const single = await recon.reconcileInvoice(inv.id);
    expect(Array.isArray(single)).toBe(true);
  });

  it('analytics job returns zero when lock already held', async () => {
    await getTestDb()('job_runs').insert({
      job_name: 'analytics',
      status: 'running',
      started_at: new Date(),
    });
    const days = await runAnalyticsJob(new Date(), 1);
    expect(days).toBe(0);
  });
});
