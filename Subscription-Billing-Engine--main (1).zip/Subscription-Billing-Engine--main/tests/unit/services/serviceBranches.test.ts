import request from 'supertest';
import { createApp } from '../../../src/app';
import { BillingDisputeService } from '../../../src/services/BillingDisputeService';
import { DataExportService } from '../../../src/services/DataExportService';
import { InvoiceAdjustmentService } from '../../../src/services/InvoiceAdjustmentService';
import { ReportingService } from '../../../src/services/ReportingService';
import { QuoteService } from '../../../src/services/QuoteService';
import { CreditNoteService } from '../../../src/services/CreditNoteService';
import { FeatureFlagService } from '../../../src/services/FeatureFlagService';
import { BillingAlertService } from '../../../src/services/BillingAlertService';
import { CustomerLifecycleAnalyticsService } from '../../../src/services/CustomerLifecycleAnalyticsService';
import { DunningService } from '../../../src/services/DunningService';
import { WorkflowEngine } from '../../../src/services/WorkflowEngine';
import { BillingWaterfallService } from '../../../src/services/BillingWaterfallService';
import { TaxComplianceReportService } from '../../../src/services/TaxComplianceReportService';
import { BillingScheduleService } from '../../../src/services/BillingScheduleService';
import { AddonProductService } from '../../../src/services/AddonProductService';
import { HealthProbeService } from '../../../src/services/HealthProbeService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { PaymentService } from '../../../src/services/PaymentService';
import { getTestDb } from '../../helpers/pgMemDb';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Service branch coverage', () => {
  const app = createApp();

  it('quotes validation and lifecycle branches', async () => {
    const customer = await createCustomer();
    const quotes = new QuoteService();
    await expect(
      quotes.create({ customer_id: customer.id, lines: [] })
    ).rejects.toMatchObject({ statusCode: 400 });
    const plan = await createPlan();
    const q = await quotes.create({
      customer_id: customer.id,
      lines: [{ description: 'Annual', quantity: 1, unit_price_cents: 5000, plan_id: plan.id }],
    });
    await quotes.send(q.id as string);
    await expect(quotes.send(q.id as string)).rejects.toMatchObject({ statusCode: 400 });
    const converted = await quotes.convertToSubscription(q.id as string);
    expect(converted.subscription).toBeDefined();
    await expect(quotes.getById('00000000-0000-4000-8000-000000000099')).rejects.toMatchObject({
      statusCode: 404,
    });
    const badQuote = await quotes.create({
      customer_id: customer.id,
      lines: [{ description: 'No plan', quantity: 1, unit_price_cents: 100 }],
    });
    await expect(quotes.convertToSubscription(badQuote.id as string)).rejects.toMatchObject({
      statusCode: 400,
    });
  });

  it('credit notes disputes adjustments and exports', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await expect(new CreditNoteService().issue({ invoice_id: inv.id, amount_cents: 0, reason: 'x' })).rejects.toMatchObject({
      statusCode: 400,
    });
    await expect(
      new CreditNoteService().issue({ invoice_id: inv.id, amount_cents: inv.total_cents + 1, reason: 'x' })
    ).rejects.toMatchObject({ statusCode: 400 });
    const dispute = await new BillingDisputeService().open(inv.id, 100, 'test');
    for (const status of ['under_review', 'won', 'closed'] as const) {
      await new BillingDisputeService().transition(dispute.id, status);
    }
    await expect(
      new BillingDisputeService().transition('00000000-0000-4000-8000-000000000099', 'open')
    ).rejects.toMatchObject({ statusCode: 404 });
    const adj = await new InvoiceAdjustmentService().apply({
      invoice_id: inv.id,
      reason: 'goodwill',
      line_adjustments: [{ description: 'Credit', amount_cents: 50 }],
    });
    expect(adj.total_cents).toBe(50);
    await expect(
      new InvoiceAdjustmentService().apply({
        invoice_id: inv.id,
        reason: 'zero',
        line_adjustments: [{ description: 'x', amount_cents: 0 }],
      })
    ).rejects.toMatchObject({ statusCode: 400 });
    const voidInv = await new InvoiceService().generateForSubscription(
      await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id }),
      customer.country
    );
    await new InvoiceService().voidInvoice(voidInv.id);
    await expect(
      new InvoiceAdjustmentService().apply({
        invoice_id: voidInv.id,
        reason: 'nope',
        line_adjustments: [{ description: 'x', amount_cents: 10 }],
      })
    ).rejects.toMatchObject({ statusCode: 400 });
    const exp = new DataExportService();
    await expect(exp.getById('00000000-0000-4000-8000-000000000099')).rejects.toMatchObject({ statusCode: 404 });
    const req = await exp.request(customer.id);
    const done = await exp.process(req.id);
    expect(done.status).toBe('completed');
    expect((await exp.process(req.id)).status).toBe('completed');
  });

  it('feature flags reporting dunning and lifecycle', async () => {
    const flags = new FeatureFlagService();
    await flags.upsert('plan_only', true, { plan_ids: ['00000000-0000-4000-8000-000000000001'] });
    expect(await flags.isEnabled('plan_only', { plan_id: '00000000-0000-4000-8000-000000000002' })).toBe(false);
    await flags.upsert('rollout', true, { percentage_rollout: 100 });
    expect(await flags.isEnabled('rollout', { user: 'a' })).toBe(true);
    await flags.upsert('rollout', true, { percentage_rollout: 0 });
    await flags.upsert('rollout', true, { percentage_rollout: 0 }, 'updated');
    const flagList = await flags.list();
    expect(flagList.some((f) => f.key === 'rollout')).toBe(true);
    await expect(flags.assertEnabled('missing_flag')).rejects.toMatchObject({ statusCode: 403 });
    const reports = new ReportingService();
    const customer = await createCustomer();
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await new PaymentService().chargeInvoice(inv.id, true);
    await reports.revenueByPlan('2020-01-01', '2030-12-31');
    await reports.arAging('2026-06-15');
    await reports.failedPaymentSummary('2020-01-01', '2030-12-31');
    await getTestDb()('audit_log').insert({
      entity_type: 'subscription',
      entity_id: sub.id,
      action: 'status_changed',
      before_state: JSON.stringify({ status: 'trial' }),
      after_state: JSON.stringify({ status: 'active' }),
    });
    const lifecycle = new CustomerLifecycleAnalyticsService();
    await lifecycle.transitionsLastDays(30);
    await new DunningService().getDefaultPolicy();
    const probe = await new HealthProbeService().probe();
    expect(probe.database).toBeDefined();
  });

  it('schedules addons waterfall tax and route errors', async () => {
    const customer = await createCustomer();
    await expect(
      new BillingScheduleService().create({
        customer_id: customer.id,
        name: 'bad',
        cadence: 'monthly',
        anchor_day: 29,
      })
    ).rejects.toMatchObject({ statusCode: 400 });
    const addon = new AddonProductService();
    const code = `br-${Date.now()}`;
    await addon.create({ code, name: 'X', price_cents: 100 });
    await expect(addon.getByCode('missing-code')).rejects.toBeDefined();
    const wf = new WorkflowEngine();
    await wf.seedSubscriptionLifecycle();
    await expect(wf.getInstance('00000000-0000-4000-8000-000000000099')).rejects.toBeDefined();
    const tax = new TaxComplianceReportService();
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await tax.validateInvoiceTax(inv.id);
    const wfSvc = new BillingWaterfallService();
    await wfSvc.compareWaterfalls('2026-04', '2026-05');
    await wfSvc.topCustomersByRevenue('2026-06', 3);
    expect((await request(app).post('/quotes').set('x-api-key', API_KEY).send({})).status).toBe(400);
    expect((await request(app).get('/coupons/NOPE').set('x-api-key', API_KEY)).status).toBe(404);
    expect(
      [404, 500].includes(
        (await request(app).post('/reconciliation/invoices/not-uuid/fix-subtotals').set('x-api-key', API_KEY)).status
      )
    ).toBe(true);
    const alerts = new BillingAlertService();
    await alerts.evaluatePaymentFailureSpike(1);
    await alerts.evaluatePastDueSubscriptions(1);
  });
});
