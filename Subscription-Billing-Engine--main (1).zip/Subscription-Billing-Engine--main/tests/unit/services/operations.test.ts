import { JobSchedulerService } from '../../../src/services/operations/JobSchedulerService';
import { MaintenanceWindowService } from '../../../src/services/operations/MaintenanceWindowService';

describe('Operations services', () => {
  it('schedules maintenance window', async () => {
    const svc = new MaintenanceWindowService();
    const start = new Date();
    const end = new Date(Date.now() + 3600_000);
    const win = await svc.schedule(start, end, 'db upgrade');
    expect(win.blocks_writes).toBe(true);
    expect(await svc.isActive(start)).toBe(true);
  });

  it('runs billing job via scheduler', async () => {
    const result = await new JobSchedulerService().runJob('billing');
    expect(result.job).toBe('billing');
    expect(typeof result.skipped).toBe('boolean');
  });

  it('lists jobs due by hour', async () => {
    const due = await new JobSchedulerService().jobsDueNow();
    expect(due).toContain('billing');
  });

  it('runs month-end runbook', async () => {
    const exec = await new (await import('../../../src/services/operations/BillingRunbookService')).BillingRunbookService().executeMonthEnd(
      '2026-05-01',
      '2026-05-31'
    );
    expect(exec.steps_completed.length).toBeGreaterThan(3);
  });
});
