import request from 'supertest';
import { createApp } from '../../../src/app';
import { CustomerLifecycleAnalyticsService } from '../../../src/services/CustomerLifecycleAnalyticsService';
import { BillingWaterfallService } from '../../../src/services/BillingWaterfallService';
import { UsageAggregationService } from '../../../src/services/UsageAggregationService';
import { BillingAlertService } from '../../../src/services/BillingAlertService';
import { AnalyticsRollupService } from '../../../src/services/AnalyticsRollupService';
import { ReportingService } from '../../../src/services/ReportingService';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { MeteringService } from '../../../src/services/MeteringService';
import { HealthProbeService } from '../../../src/services/HealthProbeService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';
import * as database from '../../../src/config/database';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Full coverage sweep 2', () => {
  const app = createApp();

  it('lifecycle covers expired trial conversion and object audit states', async () => {
    const lc = new CustomerLifecycleAnalyticsService();
    const plan = await createPlan({ price_cents: 100 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
      trial_days: 7,
    });
    await getTestDb()('subscriptions').where({ id: sub.id }).update({ status: 'expired' });
    const stages = await lc.stageDistribution();
    expect(stages.some((s) => s.stage === 'churned')).toBe(true);

    await getTestDb()('audit_log').insert({
      action: 'status_changed',
      entity_type: 'subscription',
      entity_id: sub.id,
      before_state: { status: 'unknown' },
      after_state: { status: 'active' },
      recorded_at: new Date(),
    });
    expect((await lc.transitionsLastDays(30)).length).toBeGreaterThan(0);

    const lowPlan = await createPlan({ price_cents: 100 });
    const lowSub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: lowPlan.id,
    });
    await getTestDb()('subscriptions').where({ id: lowSub.id }).update({
      failed_payment_count: 1,
      status: 'active',
    });
    const signals = await lc.expansionSignals(10);
    expect(signals.some((s) => s.signal === 'baseline' || s.signal.includes('high_plan'))).toBe(
      true
    );
    expect((await lc.trialConversionRate()).rate).toBeGreaterThanOrEqual(0);
    await lc.exportLifecycleCsv();
  });

  it('waterfall aging buckets and analytics rollup without active plan row', async () => {
    const wf = new BillingWaterfallService();
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await getTestDb()('invoices').where({ id: inv.id }).update({
      status: 'pending',
      created_at: new Date(Date.now() - 40 * 86400000),
    });
    const buckets = await wf.agingBuckets(new Date());
    expect(buckets.some((b) => b.outstanding_cents > 0)).toBe(true);

    await new AnalyticsRollupService().rollupDay(new Date('2026-06-02'));
  });

  it('usage aggregation string tiers and zero quantity skip', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const meter = await new MeteringService().createMeter({
      code: `agg-${Date.now()}`,
      name: 'Agg',
      tier_config: [{ up_to: null, unit_price_cents: 3 }],
    });
    await getTestDb()('meters')
      .where({ id: meter.id })
      .update({ tier_config: JSON.stringify([{ up_to: null, unit_price_cents: 5 }]) });
    const agg = new UsageAggregationService();
    await new MeteringService().recordUsage({
      subscription_id: sub.id,
      meter_code: meter.code,
      quantity: 10,
      recorded_at: new Date('2026-06-01T00:00:00Z'),
    });
    const rows = await agg.aggregateForSubscription(sub.id, '2026-05-01', '2026-07-01');
    expect(rows.length).toBeGreaterThan(0);
    expect(await agg.aggregateAllActive('2026-05-01', '2026-07-01')).toEqual(
      expect.arrayContaining(rows)
    );
    expect(await agg.totalRatedCents(sub.id, '2026-05-01', '2026-07-01')).toBeGreaterThan(0);
    const ingested = await agg.ingestAndAggregate(
      sub.id,
      meter.code,
      2,
      '2026-06-02T00:00:00Z'
    );
    expect(ingested?.rated_cents).toBeGreaterThan(0);
  });

  it('reporting and alerts below thresholds', async () => {
    expect(await new BillingAlertService().evaluatePaymentFailureSpike(10_000)).toBeNull();
    expect(await new BillingAlertService().evaluatePastDueSubscriptions(10_000)).toBeNull();
    const reporting = new ReportingService();
    expect((await reporting.churnRate('2099-01-01', '2099-02-01')).active_start).toBeGreaterThan(0);
    await reporting.mrrSnapshot('2099-06-01');
  });

  it('subscription invalid transition and negative credit guard', async () => {
    const customer = await createCustomer();
    await getTestDb()('customers').where({ id: customer.id }).update({ credit_balance_cents: -1 });
    const plan = await createPlan();
    await expect(
      new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id })
    ).rejects.toMatchObject({ statusCode: 400 });
    const okCustomer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: okCustomer.id,
      plan_id: plan.id,
    });
    const svc = new SubscriptionService();
    expect(() => svc.assertTransition('expired', 'active')).toThrow();
    await svc.transition(sub.id, 'cancelled');
    await expect(svc.transition(sub.id, 'past_due')).rejects.toBeDefined();
  });

  it('health degraded when db raw fails', async () => {
    const raw = jest.spyOn(database, 'getDb').mockReturnValue({
      raw: jest.fn().mockRejectedValue(new Error('db down')),
    } as never);
    const res = await request(app).get('/health');
    expect(res.status).toBe(503);
    raw.mockRestore();
    const probe = new HealthProbeService();
    const report = await probe.probe();
    expect(['ok', 'degraded']).toContain(report.status);
  });

  it('hits admin feature flags schedules contracts and metrics routes', async () => {
    expect([200, 403]).toContain(
      (await request(app).get('/feature-flags').set('x-api-key', API_KEY)).status
    );
    const plan = await createPlan();
    await request(app)
      .put('/feature-flags')
      .set('x-api-key', API_KEY)
      .send({ key: 'sweep2', enabled: true, rules: { percentage_rollout: 0 } });
    const enabled = await request(app)
      .get('/feature-flags/sweep2/enabled')
      .set('x-api-key', API_KEY)
      .query({ plan_id: plan.id });
    expect(enabled.status).toBe(200);
    const customer = await createCustomer();
    expect(
      (await request(app).get(`/schedules/customer/${customer.id}`).set('x-api-key', API_KEY)).status
    ).toBe(200);
    expect(
      (await request(app).get(`/contracts/customer/${customer.id}`).set('x-api-key', API_KEY)).status
    ).toBe(200);
    expect((await request(app).get('/metrics').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/operations/alerts').set('x-api-key', API_KEY)).status).toBe(
      200
    );
  });
});
