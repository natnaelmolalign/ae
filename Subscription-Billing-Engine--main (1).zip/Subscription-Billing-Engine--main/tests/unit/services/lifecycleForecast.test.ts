import request from 'supertest';
import { createApp } from '../../../src/app';
import { CustomerLifecycleAnalyticsService } from '../../../src/services/CustomerLifecycleAnalyticsService';
import { BillingForecastEngine } from '../../../src/services/BillingForecastEngine';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Lifecycle and forecast', () => {
  const app = createApp();

  it('exposes lifecycle and forecast routes', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const stages = await request(app).get('/lifecycle/stages').set('x-api-key', API_KEY);
    expect(stages.status).toBe(200);
    const forecast = await request(app).get('/lifecycle/forecast').set('x-api-key', API_KEY);
    expect(forecast.status).toBe(200);
    expect(forecast.body.length).toBeGreaterThan(0);
  });

  it('computes lifecycle metrics', async () => {
    const lifecycle = new CustomerLifecycleAnalyticsService();
    const dist = await lifecycle.stageDistribution();
    expect(Array.isArray(dist)).toBe(true);
    const arpu = await lifecycle.averageRevenuePerCustomer();
    expect(arpu).toBeGreaterThanOrEqual(0);
    const csv = await lifecycle.exportLifecycleCsv();
    expect(csv).toContain('stage');
    const engine = new BillingForecastEngine();
    const scenarios = await engine.scenarios('2026-06');
    expect(scenarios.length).toBe(4);
    const pipeline = await engine.pipelineWeightedForecast();
    expect(pipeline).toHaveProperty('expected_mrr_cents');
  });
});
