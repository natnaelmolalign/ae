import { InvoiceService } from '../../../src/services/InvoiceService';
import { BillingCycleService } from '../../../src/services/BillingCycleService';
import { runBillingJob } from '../../../src/jobs/billingJob';
import { dispatchWebhook } from '../../../src/utils/webhookUtils';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { CouponService } from '../../../src/services/CouponService';
import { parseDate } from '../../../src/utils/dateUtils';
import { addBillingInterval } from '../../../src/utils/dateUtils';

describe('InvoiceService and jobs', () => {
  it('covers invoice helpers and billing job skip path', async () => {
    const invoices = new InvoiceService();
    const plan = await createPlan();
    const customer = await createCustomer();
    const subs = new SubscriptionService();
    const sub = await subs.create({
      customer_id: customer.id,
      plan_id: plan.id,
      billing_anchor: '2024-05-01',
    });
    const invoice = await invoices.generateForSubscription(sub, customer.country);
    await invoices.markPaid(invoice.id);
    const grace = invoices.computeGraceEnd(invoice, 5);
    expect(grace).toBeTruthy();

    const coupon = await new CouponService().create({
      code: 'PCT',
      discount_type: 'percent',
      discount_value: 10,
    });
    const order = await invoices.applyDiscountOrder(1000, 100, coupon);
    expect(order.total).toBeLessThan(1000);

    await expect(invoices.createProrationCharge(sub, 0, 'x')).rejects.toThrow();

    const cycles = new BillingCycleService();
    const start = parseDate('2024-06-01');
    const end = addBillingInterval(start, 'monthly', 15);
    await cycles.createForPeriod(sub.id, start, 'monthly', 15);
    const advanced = await cycles.advancePeriod('2024-06-30', 'monthly', 15);
    expect(advanced.periodStart).toBeTruthy();

    await runBillingJob(new Date('2024-01-01'));
  });

  it('dispatches webhook when url configured', async () => {
    process.env.WEBHOOK_URL = 'https://hooks.example.com/billing';
    process.env.WEBHOOK_SECRET = 'test-webhook-secret-32chars';
    const { resetEnvForTests } = await import('../../../src/config/env');
    resetEnvForTests();
    global.fetch = jest.fn().mockResolvedValue({ ok: true }) as typeof fetch;
    await dispatchWebhook('test.event', { ok: true });
    process.env.WEBHOOK_URL = '';
    resetEnvForTests();
  });
});
