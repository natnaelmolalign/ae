import { WebhookService } from '../../../src/services/WebhookService';
import { OutboxService } from '../../../src/services/OutboxService';
import { CustomerLifecycleAnalyticsService } from '../../../src/services/CustomerLifecycleAnalyticsService';
import { BillingWaterfallService } from '../../../src/services/BillingWaterfallService';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { BillingAnalyticsFacade } from '../../../src/services/BillingAnalyticsFacade';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { CouponService } from '../../../src/services/CouponService';
import { PaymentService } from '../../../src/services/PaymentService';
import { ReportingService } from '../../../src/services/ReportingService';
import { AnalyticsRollupService } from '../../../src/services/AnalyticsRollupService';
import { BillingForecastEngine } from '../../../src/services/BillingForecastEngine';
import { DunningService } from '../../../src/services/DunningService';
import { MeteringService } from '../../../src/services/MeteringService';
import { UsageAggregationService } from '../../../src/services/UsageAggregationService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';
import { resetEnvForTests } from '../../../src/config/env';

describe('Full coverage sweep 3', () => {
  it('lifecycle hits every status map expansion and audit parse branches', async () => {
    const lc = new CustomerLifecycleAnalyticsService();
    const planHigh = await createPlan({ price_cents: 6000 });
    const planLow = await createPlan({ price_cents: 100 });
    const c1 = await createCustomer();
    const c2 = await createCustomer();
    const c3 = await createCustomer();
    const c4 = await createCustomer();

    await new SubscriptionService().create({ customer_id: c1.id, plan_id: planHigh.id, trial_days: 7 });
    await new SubscriptionService().create({ customer_id: c2.id, plan_id: planLow.id });
    const pastDue = await new SubscriptionService().create({ customer_id: c3.id, plan_id: planLow.id });
    await getTestDb()('subscriptions').where({ id: pastDue.id }).update({ status: 'past_due' });
    const cancelled = await new SubscriptionService().create({ customer_id: c4.id, plan_id: planLow.id });
    await getTestDb()('subscriptions').where({ id: cancelled.id }).update({ status: 'cancelled' });

    const stages = await lc.stageDistribution();
    expect(stages.some((s) => s.stage === 'trial')).toBe(true);
    expect(stages.some((s) => s.stage === 'active')).toBe(true);
    expect(stages.some((s) => s.stage === 'at_risk')).toBe(true);
    expect(stages.some((s) => s.stage === 'churned')).toBe(true);

    await getTestDb()('audit_log').insert({
      action: 'status_changed',
      entity_type: 'subscription',
      entity_id: pastDue.id,
      before_state: JSON.stringify({ status: 'trial' }),
      after_state: JSON.stringify({ status: 'active' }),
      recorded_at: new Date(),
    });
    await getTestDb()('audit_log').insert({
      action: 'status_changed',
      entity_type: 'subscription',
      entity_id: cancelled.id,
      before_state: { status: 'active' },
      after_state: { status: 'cancelled' },
      recorded_at: new Date(),
    });
    expect((await lc.transitionsLastDays(30)).length).toBeGreaterThan(0);

    const trialOnly = await new SubscriptionService().create({
      customer_id: (await createCustomer()).id,
      plan_id: planLow.id,
      trial_days: 14,
    });
    await getTestDb()('subscriptions').where({ id: trialOnly.id }).update({ failed_payment_count: 2 });
    const signals = await lc.expansionSignals(20);
    expect(signals.some((s) => s.signal === 'trial_convert' || s.signal === 'baseline')).toBe(true);

    const rate = await lc.trialConversionRate();
    expect(rate.started).toBeGreaterThan(0);
    expect(await lc.averageRevenuePerCustomer()).toBeGreaterThan(0);
    expect((await lc.customersAtRisk()).length).toBeGreaterThan(0);
    await lc.exportLifecycleCsv();
  });

  it('waterfall aging places invoices in each bucket', async () => {
    const wf = new BillingWaterfallService();
    const asOf = new Date('2026-06-15T12:00:00Z');
    const offsets = [5, 45, 75, 120];
    for (const days of offsets) {
      const plan = await createPlan();
      const customer = await createCustomer();
      const sub = await new SubscriptionService().create({
        customer_id: customer.id,
        plan_id: plan.id,
      });
      const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
      await getTestDb()('invoices').where({ id: inv.id }).update({
        status: 'pending',
        created_at: new Date(asOf.getTime() - days * 86400000),
        total_cents: 1000 + days,
      });
    }
    const buckets = await wf.agingBuckets(asOf);
    expect(buckets.find((b) => b.bucket === '0-30')?.outstanding_cents).toBeGreaterThan(0);
    expect(buckets.find((b) => b.bucket === '31-60')?.outstanding_cents).toBeGreaterThan(0);
    expect(buckets.find((b) => b.bucket === '61-90')?.outstanding_cents).toBeGreaterThan(0);
    expect(buckets.find((b) => b.bucket === '90+')?.outstanding_cents).toBeGreaterThan(0);
    await wf.compareWaterfalls('2026-05', '2026-06');
  });

  it('subscription service pause resume renew expire and coupon paths', async () => {
    const svc = new SubscriptionService();
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await svc.create({ customer_id: customer.id, plan_id: plan.id });

    await svc.pause(sub.id);
    const resumed = await svc.resume(sub.id, '2026-06-10');
    expect(resumed.paused_at).toBeNull();

    const trial = await svc.create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
      trial_days: 3,
    });
    await expect(svc.markPastDue(trial.id)).rejects.toMatchObject({ statusCode: 400 });
    await getTestDb()('subscriptions').where({ id: trial.id }).update({
      trial_end: '2020-01-01',
    });
    expect((await svc.activateEndedTrials(new Date('2026-06-15'))).length).toBeGreaterThan(0);

    const past = await svc.create({ customer_id: customer.id, plan_id: plan.id });
    await svc.transition(past.id, 'past_due');
    expect((await svc.markPastDue(past.id)).status).toBe('past_due');

    const active = await svc.create({ customer_id: (await createCustomer()).id, plan_id: plan.id });
    await svc.bumpFailedPaymentCount(active.id);
    const afterFail = await svc.recordFailedPayment(active.id);
    expect(Number(afterFail.failed_payment_count)).toBeGreaterThanOrEqual(1);

    const cancelled = await svc.create({ customer_id: (await createCustomer()).id, plan_id: plan.id });
    await svc.transition(cancelled.id, 'cancelled');
    await svc.reactivate(cancelled.id);

    const renewSub = await svc.create({ customer_id: (await createCustomer()).id, plan_id: plan.id });
    await getTestDb()('subscriptions').where({ id: renewSub.id }).update({
      current_period_end: '2020-01-01',
      status: 'active',
    });
    expect(await svc.renewIfDue(renewSub.id, new Date('2026-06-15'))).not.toBeNull();
    await getTestDb()('subscriptions').where({ id: renewSub.id }).update({
      current_period_end: '2099-12-31',
    });
    expect(await svc.renewIfDue(renewSub.id, new Date('2026-06-15'))).toBeNull();

    await getTestDb()('subscriptions').where({ id: renewSub.id }).update({
      current_period_end: '2020-01-01',
    });
    expect(await svc.expireDue(new Date('2026-06-15'))).toBeGreaterThanOrEqual(1);

    const code = `CPN-${Date.now()}`;
    await new CouponService().create({
      code,
      discount_type: 'percent',
      discount_value: 10,
      usage_limit: 5,
    });
    await svc.create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
      coupon_code: code,
    });
  });

  it('analytics facade health score applies every penalty factor', async () => {
    const facade = new BillingAnalyticsFacade();
    const bad = await facade.healthScore('2099-01');
    expect(bad.factors.length).toBeGreaterThan(0);
    expect(bad.score).toBeLessThan(100);

    const plan = await createPlan({ price_cents: 8000 });
    const customer = await createCustomer();
    await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const good = await facade.healthScore('2026-06');
    expect(good.score).toBeGreaterThan(0);
  });

  it('outbox delivers webhook success and retries below max attempts', async () => {
    const prevUrl = process.env.WEBHOOK_URL;
    process.env.WEBHOOK_URL = 'http://test';
    resetEnvForTests();
    const mockWebhook = {
      enqueue: jest.fn().mockResolvedValue(undefined),
      deliverPending: jest.fn().mockResolvedValue(1),
    } as unknown as WebhookService;
    const [ev] = await getTestDb()('domain_events')
      .insert({
        event_type: 'pay.ok',
        aggregate_type: 'payment',
        aggregate_id: '00000000-0000-4000-8000-000000000003',
        payload: JSON.stringify({ ok: true }),
      })
      .returning('*');
    const [msg] = await getTestDb()('outbox_messages')
      .insert({
        domain_event_id: ev.id,
        status: 'pending',
        channel: 'webhook',
        attempt_count: 2,
      })
      .returning('*');
    const outbox = new OutboxService(mockWebhook);
    expect(await outbox.deliverOne(msg.id as string)).toBe(true);
    const row = await getTestDb()('outbox_messages').where({ id: msg.id }).first();
    expect(row?.status).toBe('delivered');

    const failMock = {
      enqueue: jest.fn().mockResolvedValue(undefined),
      deliverPending: jest.fn().mockResolvedValue(0),
    } as unknown as WebhookService;
    const [ev2] = await getTestDb()('domain_events')
      .insert({
        event_type: 'pay.fail',
        aggregate_type: 'payment',
        aggregate_id: '00000000-0000-4000-8000-000000000004',
        payload: JSON.stringify({}),
      })
      .returning('*');
    const [msg2] = await getTestDb()('outbox_messages')
      .insert({
        domain_event_id: ev2.id,
        status: 'pending',
        channel: 'webhook',
        attempt_count: 3,
      })
      .returning('*');
    expect(await new OutboxService(failMock).deliverOne(msg2.id as string)).toBe(false);
    const pending = await getTestDb()('outbox_messages').where({ id: msg2.id }).first();
    expect(Number(pending?.attempt_count)).toBe(4);
    process.env.WEBHOOK_URL = prevUrl;
    resetEnvForTests();
  });

  it('dunning reporting forecast and usage skip empty quantity', async () => {
    const dunning = new DunningService();
    expect(dunning.retryDelaysFromStages([{ type: 'cancel', delay_days: 1 }])).toEqual([]);
    expect(
      dunning.shouldCancelAfterRetries(
        [{ type: 'retry', delay_days: 1 }],
        5
      )
    ).toBe(false);

    const reporting = new ReportingService();
    const customer = await createCustomer();
    const plan = await createPlan({ interval: 'yearly', price_cents: 12000 });
    await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    await reporting.mrrSnapshot('2026-06-15');

    const engine = new BillingForecastEngine();
    await engine.newLogoImpact(10_000, 2000, '2026-06');
    await engine.pipelineWeightedForecast();
    await engine.trailingMrr(2);
    await engine.projectNextMonths(2);
    await engine.scenarios('2026-06');
    expect((await engine.exportForecastCsv()).includes('period')).toBe(true);

    const plan2 = await createPlan();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan2.id,
    });
    await new MeteringService().createMeter({
      code: `empty-${Date.now()}`,
      name: 'Empty',
      tier_config: [{ up_to: null, unit_price_cents: 1 }],
    });
    const agg = await new UsageAggregationService();
    expect(
      await agg.aggregateForSubscription(sub.id, '2026-05-01', '2026-07-01')
    ).toEqual([]);
  });
});
