import request from 'supertest';
import { createApp } from '../../../src/app';
import { BillingAnalyticsFacade } from '../../../src/services/BillingAnalyticsFacade';
import { BillingRulesEngine } from '../../../src/domain/billing/BillingRulesEngine';
import { MinimumCommitmentCalculator } from '../../../src/domain/billing/MinimumCommitmentCalculator';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { SubscriptionItemService } from '../../../src/services/SubscriptionItemService';
import { CouponService } from '../../../src/services/CouponService';
import { WorkflowEngine } from '../../../src/services/WorkflowEngine';
import { AddonProductService } from '../../../src/services/AddonProductService';
import { InvoiceReconciliationService } from '../../../src/services/InvoiceReconciliationService';
import { PaymentService } from '../../../src/services/PaymentService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';
import { parseDate, toDateString } from '../../../src/utils/dateUtils';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Full coverage sweep 5', () => {
  it('invoice generation covers trial duplicate coupon credit items and helpers', async () => {
    const invoices = new InvoiceService();
    const plan = await createPlan({ price_cents: 2500 });
    const customer = await createCustomer({ credit_balance_cents: 1500 });

    const trial = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
      trial_days: 7,
    });
    await expect(invoices.generateForSubscription(trial, customer.country)).rejects.toMatchObject({
      statusCode: 400,
    });

    const code = `SW5-${Date.now()}`;
    await new CouponService().create({
      code,
      discount_type: 'percent',
      discount_value: 20,
      usage_limit: 10,
    });
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
      coupon_code: code,
    });
    const addonCode = `addon-${Date.now()}`;
    await new AddonProductService().create({ code: addonCode, name: 'Extra', price_cents: 400 });
    await new SubscriptionItemService().addAddon(sub.id, addonCode, 2);

    const first = await invoices.generateForSubscription(sub, customer.country);
    const dup = await invoices.generateForSubscription(sub, customer.country);
    expect(dup.id).toBe(first.id);
    expect(Number(first.credit_applied_cents)).toBeGreaterThan(0);
    expect(Number(first.discount_cents)).toBeGreaterThan(0);
    const lines = await invoices.getLineItems(first.id);
    expect(lines.some((l) => l.type === 'discount')).toBe(true);

    await expect(invoices.createProrationCharge(sub, 0, 'bad')).rejects.toMatchObject({
      statusCode: 400,
    });
    await expect(invoices.voidInvoice('00000000-0000-4000-8000-000000000099')).rejects.toMatchObject({
      statusCode: 404,
    });
    const proration = await invoices.createProrationCharge(sub, 500, 'upgrade');
    await invoices.markPaid(proration.id);
    expect(invoices.getTaxRateBps('DE')).toBe(1900);
    expect(invoices.getTaxRateBps('XX')).toBe(invoices.getTaxRateBps('US'));
    const couponRow = await getTestDb()('coupons').where({ code }).first();
    const order = await invoices.applyDiscountOrder(10_000, 500, couponRow as never);
    expect(order.discountCents).toBeGreaterThan(0);
    expect(invoices.computeGraceEnd(first)).toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });

  it('subscription service hits pause reactivate change-plan and failed-payment branches', async () => {
    const svc = new SubscriptionService();
    const plan = await createPlan();
    const planB = await createPlan({ name: 'Pro', price_cents: 5000 });
    const customer = await createCustomer();

    const active = await svc.create({ customer_id: customer.id, plan_id: plan.id });
    await svc.pause(active.id);

    const cancelled = await svc.create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
    });
    await svc.transition(cancelled.id, 'cancelled');
    await expect(svc.pause(cancelled.id)).rejects.toMatchObject({ statusCode: 400 });
    await expect(svc.reactivate(active.id)).rejects.toMatchObject({ statusCode: 400 });
    await svc.reactivate(cancelled.id);

    const periodSub = await svc.create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
    });
    const periodEnd = parseDate('2026-06-30');
    await getTestDb()('subscriptions').where({ id: periodSub.id }).update({
      current_period_end: toDateString(periodEnd),
    });
    const changed = await svc.changePlanAtPeriodEnd(periodSub.id, planB.id, periodEnd);
    expect(changed.plan_id).toBe(planB.id);

    const pastDue = await svc.create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
    });
    await svc.transition(pastDue.id, 'past_due');
    const bumped = await svc.recordFailedPayment(pastDue.id);
    expect(bumped.status).toBe('past_due');

    await expect(
      svc.create({
        customer_id: '00000000-0000-4000-8000-000000000099',
        plan_id: plan.id,
      })
    ).rejects.toMatchObject({ statusCode: 404 });
    await getTestDb()('customers').where({ id: customer.id }).update({ credit_balance_cents: -1 });
    await expect(
      svc.create({ customer_id: customer.id, plan_id: plan.id })
    ).rejects.toMatchObject({ statusCode: 400 });
  });

  it('workflow engine validates definitions and wildcard cancel with actor', async () => {
    const engine = new WorkflowEngine();
    await engine.seedSubscriptionLifecycle();
    await engine.registerDefinition('custom_v2', 'entity', ['draft', 'done'], [
      { from: 'draft', to: 'done', trigger: 'finish' },
    ]);

    await expect(engine.registerDefinition('bad_empty', 'x', [], [])).rejects.toMatchObject({
      statusCode: 400,
    });
    await expect(
      engine.registerDefinition('bad_from', 'x', ['a'], [{ from: 'missing', to: 'a', trigger: 't' }])
    ).rejects.toMatchObject({ statusCode: 400 });
    await expect(
      engine.registerDefinition('bad_to', 'x', ['a'], [{ from: 'a', to: 'missing', trigger: 't' }])
    ).rejects.toMatchObject({ statusCode: 400 });

    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inst = await engine.start('subscription_lifecycle', 'subscription', sub.id, 'trialing', {
      note: 'ctx',
    });
    await engine.trigger(inst.id, 'force_cancel', '00000000-0000-4000-8000-000000000010', {
      forced: true,
    });
    const done = await engine.getInstance(inst.id);
    expect(done.current_state).toBe('cancelled');
    expect(done.completed_at).not.toBeNull();
  });

  it('billing rules engine exercises discount tax tier and minimum branches', () => {
    const engine = new BillingRulesEngine(100);
    expect(engine.computeLineAmount(0, 100)).toBe(0);
    expect(() => engine.computeLineAmount(1, -1)).toThrow('negative');
    expect(engine.applyPercentDiscount(1000, 0)).toBe(0);
    expect(() => engine.applyPercentDiscount(1000, 101)).toThrow('100');
    expect(engine.applyPercentDiscount(1000, 50, 100)).toBe(100);
    expect(engine.applyFixedDiscount(500, 0)).toBe(0);
    expect(engine.applyFixedDiscount(500, 200)).toBe(200);
    expect(engine.resolveDiscount(0, { type: 'fixed', value: 10, recurring: false })).toBe(0);
    expect(engine.computeTax(0, { rate_bps: 1900, inclusive: false })).toBe(0);
    expect(engine.applyMinimumCharge(0)).toEqual({ total: 0, applied: false });

    const inclusive = engine.calculate(
      [{ description: 'Base', quantity: 2, unit_amount_cents: 5000 }],
      { type: 'fixed', value: 1000, recurring: false },
      { rate_bps: 1000, inclusive: true }
    );
    expect(inclusive.tax_cents).toBeGreaterThan(0);

    expect(
      engine.tieredUsageCharge(5, [
        { up_to: 0, unit_cents: 99 },
        { up_to: 10, unit_cents: 1 },
      ])
    ).toBe(0);
    expect(engine.prorateLineAmount(1000, new Date('2026-01-01'), new Date('2026-01-01'), new Date(), new Date())).toBe(0);
  });

  it('minimum commitment calculator selectTier and annual projection', () => {
    const calc = new MinimumCommitmentCalculator();
    const tiers = [
      { name: 'starter', minimum_mrr_cents: 0, overage_unit_cents: 10 },
      { name: 'enterprise', minimum_mrr_cents: 500_000, overage_unit_cents: 5 },
    ];
    expect(calc.selectTier(10_000, tiers).name).toBe('starter');
    expect(calc.selectTier(600_000, tiers).name).toBe('enterprise');
    expect(calc.projectAnnualTrueUp([calc.compute({ actual_mrr_cents: 0, usage_overage_units: 0, tier: tiers[0] })])).toBe(0);
  });

  it('analytics facade month-over-month january and health penalty bundle', async () => {
    const facade = new BillingAnalyticsFacade();
    const jan = await facade.monthOverMonth('2026-01');
    expect(jan.previous.period_key).toBe('2025-12');
    expect(jan.mrr_delta_cents).toBeDefined();

    const pack = await facade.exportBoardPack('2026-06');
    expect(pack.health.score).toBeGreaterThanOrEqual(0);
    await facade.cohortSummary();
    await facade.agingAndForecast();

    const customer = await createCustomer();
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const db = getTestDb();
    await db('invoices').where({ id: inv.id }).update({
      subtotal_cents: 8000,
      total_cents: 8000,
      created_at: new Date('2026-06-08T12:00:00Z'),
    });
    await new PaymentService().chargeInvoice(inv.id, true, { flushOutbox: false });
    await db('payments').where({ invoice_id: inv.id }).update({ amount_cents: 1 });
    const { RevenueRecognitionService } = await import('../../../src/services/RevenueRecognitionService');
    await new RevenueRecognitionService().createForPaidInvoice(inv.id);
    for (let i = 0; i < 8; i++) {
      const c = await createCustomer();
      const s = await new SubscriptionService().create({ customer_id: c.id, plan_id: plan.id });
      await db('subscriptions').where({ id: s.id }).update({
        status: 'cancelled',
        updated_at: new Date('2026-06-10T12:00:00Z'),
      });
    }
    await new InvoiceReconciliationService().runForPeriod('2026-06');
    const health = await facade.healthScore('2026-06');
    expect(health.factors.length).toBeGreaterThan(0);
    expect(health.score).toBeLessThan(100);
  });

  it('integration routes for board reconciliation and dunning', async () => {
    const app = createApp();
    expect((await request(app).get('/dunning-policies').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/dunning-policies/default').set('x-api-key', API_KEY)).status).toBe(200);
    expect(
      (await request(app).get('/reconciliation/period/2026-06').set('x-api-key', API_KEY)).status
    ).toBe(200);
    expect(
      (await request(app).get('/reconciliation/period/2026-06/summary').set('x-api-key', API_KEY))
        .status
    ).toBe(200);
    expect(
      (
        await request(app)
          .get('/reconciliation/period/2026-06/export.csv')
          .set('x-api-key', API_KEY)
      ).status
    ).toBe(200);
    expect(
      (await request(app).get('/analytics-board/2026-06/health').set('x-api-key', API_KEY)).status
    ).toBe(200);
    expect(
      (await request(app).get('/analytics-board/2026-06/drill-down?limit=3').set('x-api-key', API_KEY))
        .status
    ).toBe(200);
    expect(
      (await request(app).get('/analytics-board/cohorts/summary').set('x-api-key', API_KEY)).status
    ).toBe(200);

    const customer = await createCustomer();
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await new PaymentService().chargeInvoice(inv.id, true, { flushOutbox: false });
    expect(
      (
        await request(app)
          .get(`/reconciliation/invoices/${inv.id}`)
          .set('x-api-key', API_KEY)
      ).status
    ).toBe(200);
    expect(
      (
        await request(app)
          .post(`/reconciliation/invoices/${inv.id}/fix-subtotals`)
          .set('x-api-key', API_KEY)
      ).status
    ).toBe(200);
  });
});
