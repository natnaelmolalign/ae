import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { createCustomer, createPlan } from '../../helpers/factories';
describe('SubscriptionService', () => {
  const service = new SubscriptionService();

  it('rejects invalid status transitions', () => {
    expect(() => service.assertTransition('expired', 'active')).toThrow();
    expect(() => service.assertTransition('trial', 'past_due')).toThrow();
  });

  it('moves active subscription to past_due on failed payment', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await service.create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const updated = await service.recordFailedPayment(sub.id);
    expect(updated.status).toBe('past_due');
    expect(Number(updated.failed_payment_count)).toBe(1);
  });

  it('blocks customers with negative credit from subscribing', async () => {
    const plan = await createPlan();
    const customer = await createCustomer({ credit_balance_cents: -100 });
    await expect(
      service.create({ customer_id: customer.id, plan_id: plan.id })
    ).rejects.toThrow('negative credit');
  });

  it('extends trial end date', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await service.create({
      customer_id: customer.id,
      plan_id: plan.id,
      trial_days: 7,
    });
    const extended = await service.extendTrial(sub.id, 5);
    expect(extended.trial_end).toBeTruthy();
  });

});
