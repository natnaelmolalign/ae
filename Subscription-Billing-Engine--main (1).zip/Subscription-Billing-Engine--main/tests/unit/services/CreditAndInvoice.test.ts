import { CreditService } from '../../../src/services/CreditService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { getTestDb } from '../../helpers/pgMemDb';

describe('CreditService and InvoiceService', () => {
  it('issues credit and voids invoice', async () => {
    const customer = await createCustomer();
    const credit = new CreditService();
    await credit.issue({
      customer_id: customer.id,
      amount_cents: 500,
      reason: 'goodwill',
    });
    const row = await getTestDb()('customers').where({ id: customer.id }).first();
    expect(Number(row.credit_balance_cents)).toBeGreaterThanOrEqual(500);

    await credit.refundToCredit(customer.id, 1000, 200);
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const invoices = new InvoiceService();
    const invoice = await invoices.generateForSubscription(sub, 'US');
    await invoices.voidInvoice(invoice.id);
    const voided = await invoices.getById(invoice.id);
    expect(voided.status).toBe('void');
  });
});
