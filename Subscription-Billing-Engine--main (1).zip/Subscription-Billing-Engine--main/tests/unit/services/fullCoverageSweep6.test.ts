import request from 'supertest';
import { createApp } from '../../../src/app';
import { runBillingJob } from '../../../src/jobs/billingJob';
import { runAnalyticsJob } from '../../../src/jobs/analyticsJob';
import { EntitlementService } from '../../../src/services/EntitlementService';
import { MeteringService } from '../../../src/services/MeteringService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { globalMetrics } from '../../../src/lib/metrics';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';
const BAD = 'not-a-valid-uuid';

describe('Full coverage sweep 6', () => {
  const app = createApp();

  it('billing job skips lock, future periods, and duplicate invoices', async () => {
    await getTestDb()('job_runs').insert({
      job_name: 'billing',
      status: 'running',
      started_at: new Date(),
    });
    expect(await runBillingJob(new Date('2026-06-01'))).toBe(0);
    await getTestDb()('job_runs').where({ job_name: 'billing' }).del();

    const plan = await createPlan();
    const customer = await createCustomer();
    const subs = new SubscriptionService();
    const sub = await subs.create({
      customer_id: customer.id,
      plan_id: plan.id,
      billing_anchor: '2024-01-01',
    });
    await getTestDb()('subscriptions').where({ id: sub.id }).update({
      status: 'active',
      current_period_start: '2099-01-01',
      current_period_end: '2099-01-31',
    });
    expect(await runBillingJob(new Date('2026-06-01'))).toBe(0);

    await getTestDb()('subscriptions').where({ id: sub.id }).update({
      current_period_start: '2024-01-01',
      current_period_end: '2024-01-31',
    });
    const firstRun = await runBillingJob(new Date('2024-02-01'));
    expect(firstRun).toBeGreaterThanOrEqual(1);
    const secondRun = await runBillingJob(new Date('2024-02-01'));
    expect(secondRun).toBe(0);
  });

  it('analytics job runs successfully when lock is free', async () => {
    await getTestDb()('job_runs').where({ job_name: 'analytics' }).del();
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await new InvoiceService().markPaid(inv.id);
    const days = await runAnalyticsJob(new Date('2026-06-15'), 2);
    expect(days).toBeGreaterThanOrEqual(0);
  });

  it('entitlement routes cover unlimited count-zero and validation errors', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });

    expect(
      (await request(app).put(`/plans/${BAD}/entitlements`).set('x-api-key', API_KEY).send({ entitlements: [] }))
        .status
    ).toBe(400);

    await request(app)
      .put(`/plans/${plan.id}/entitlements`)
      .set('x-api-key', API_KEY)
      .send({
        entitlements: [
          { feature_key: 'api', limit_type: 'unlimited' },
          { feature_key: 'seats', limit_type: 'count', limit_value: 0 },
        ],
      })
      .expect(200);

    const unlimited = await new EntitlementService().check(sub.id, 'api');
    expect(unlimited.allowed).toBe(true);
    expect(unlimited.limit_type).toBe('unlimited');

    const zeroSeats = await new EntitlementService().check(sub.id, 'seats');
    expect(zeroSeats.allowed).toBe(false);

    expect(
      (
        await request(app)
          .post(`/plans/${plan.id}/entitlements/check`)
          .set('x-api-key', API_KEY)
          .send({ subscription_id: BAD, feature_key: 'api' })
      ).status
    ).toBe(400);

    const viaRoute = await request(app)
      .post(`/plans/${plan.id}/entitlements/check`)
      .set('x-api-key', API_KEY)
      .send({ subscription_id: sub.id, feature_key: 'api' });
    expect(viaRoute.status).toBe(200);
    expect(viaRoute.body.allowed).toBe(true);
  });

  it('meters routes record usage with timestamp and idempotency', async () => {
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
    });
    const meter = await new MeteringService().createMeter({
      code: `hl-${Date.now()}`,
      name: 'High leverage',
      tier_config: [{ up_to: null, unit_price_cents: 3 }],
    });

    expect((await request(app).get(`/meters/${meter.code}`).set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/meters/missing-meter-xyz').set('x-api-key', API_KEY)).status).toBe(404);

    const idemKey = `idem-${Date.now()}`;
    const usage = await request(app)
      .post(`/meters/${meter.code}/usage`)
      .set('x-api-key', API_KEY)
      .send({
        subscription_id: sub.id,
        quantity: 4,
        recorded_at: '2026-06-10T12:00:00Z',
        idempotency_key: idemKey,
      });
    expect(usage.status).toBe(204);

    const dup = await request(app)
      .post(`/meters/${meter.code}/usage`)
      .set('x-api-key', API_KEY)
      .send({
        subscription_id: sub.id,
        quantity: 99,
        idempotency_key: idemKey,
      });
    expect(dup.status).toBe(204);
    const rows = await getTestDb()('usage_records').where({ idempotency_key: idemKey });
    expect(rows.length).toBe(1);
  });

  it('metrics routes expose prometheus and snapshot after traffic', async () => {
    globalMetrics.increment('sweep6_probe', { env: 'test' });
    globalMetrics.observeHistogram('sweep6_latency_ms', 42);
    await globalMetrics.persistRecent(120);

    const prom = await request(app).get('/metrics');
    expect(prom.status).toBe(200);
    expect(prom.text).toContain('sweep6_probe');

    const snap = await request(app).get('/metrics/snapshot');
    expect(snap.status).toBe(200);
    expect(snap.body.counters.length).toBeGreaterThan(0);
  });
});
