import { BillingCatalogService } from '../../../src/services/BillingCatalogService';
import { BillingDisputeService } from '../../../src/services/BillingDisputeService';
import { BillingForecastService } from '../../../src/services/BillingForecastService';
import { CustomerInsightsService } from '../../../src/services/CustomerInsightsService';
import { EventProjectionService } from '../../../src/services/EventProjectionService';
import { InvoiceExportService } from '../../../src/services/InvoiceExportService';
import { InvoiceAdjustmentService } from '../../../src/services/InvoiceAdjustmentService';
import { SubscriptionMigrationService } from '../../../src/services/SubscriptionMigrationService';
import { UsageAggregationService } from '../../../src/services/UsageAggregationService';
import { ComplianceReportBuilder } from '../../../src/services/compliance/ComplianceReportBuilder';
import { ContractRepository } from '../../../src/repositories/ContractRepository';
import { ReportingService } from '../../../src/services/ReportingService';
import { BillingReconciliationService } from '../../../src/services/BillingReconciliationService';
import { BillingPeriodCloseService } from '../../../src/services/BillingPeriodCloseService';
import { PaymentMethodVaultService } from '../../../src/services/PaymentMethodVaultService';
import { ApiKeyRotationService } from '../../../src/services/ApiKeyRotationService';
import { WebhookSigningService } from '../../../src/services/WebhookSigningService';
import { RateLimitPolicyService } from '../../../src/services/RateLimitPolicyService';
import { BillingAlertService } from '../../../src/services/BillingAlertService';
import { SagaOrchestrator } from '../../../src/services/SagaOrchestrator';
import { PrincipalService } from '../../../src/services/RbacService';
import { runExportJob } from '../../../src/jobs/exportJob';
import { runForecastJob } from '../../../src/jobs/forecastJob';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { getTestDb } from '../../helpers/pgMemDb';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Extended service coverage', () => {
  beforeAll(async () => {
    await new PrincipalService().bootstrapFromEnvMasterKey(API_KEY);
  });

  it('catalog quotes and snapshots', async () => {
    const catalog = new BillingCatalogService();
    const quote = catalog.quoteBundle('growth', 5, 20_000, 'US');
    expect(quote.total_cents).toBeGreaterThan(0);
    await catalog.persistBundlePriceSnapshot('growth', quote);
    const snaps = await catalog.listSnapshots('growth');
    expect(snaps.length).toBeGreaterThan(0);
    expect(catalog.compareBundles(10, 1000, 'DE').length).toBe(3);
  });

  it('compliance report sections', async () => {
    const report = await new ComplianceReportBuilder().buildFull();
    expect(report.sections.length).toBeGreaterThanOrEqual(6);
  });

  it('forecast and insights', async () => {
    const customer = await createCustomer();
    const plan = await createPlan();
    await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const forecast = await new BillingForecastService().runDefaultScenario('2026-06-02', 3);
    expect(forecast.length).toBe(3);
    const health = await new CustomerInsightsService().healthScore(customer.id);
    expect(health.score).toBeGreaterThanOrEqual(0);
    const ltv = await new CustomerInsightsService().lifetimeValue(customer.id);
    expect(ltv.customer_id).toBe(customer.id);
  });

  it('reporting churn and failed payments', async () => {
    const reports = new ReportingService();
    const churn = await reports.churnRate('2026-01-01', '2026-12-31');
    expect(churn.rate).toBeGreaterThanOrEqual(0);
    const failed = await reports.failedPaymentSummary('2026-01-01', '2026-12-31');
    expect(failed.count).toBeGreaterThanOrEqual(0);
    const byPlan = await reports.revenueByPlan('2026-01-01', '2026-12-31');
    expect(Array.isArray(byPlan)).toBe(true);
  });

  it('event projections', async () => {
    const proj = new EventProjectionService();
    expect(await proj.paymentFailureRate(24)).toBeGreaterThanOrEqual(0);
    const list = await proj.listByAggregate('subscription', 5);
    expect(Array.isArray(list)).toBe(true);
  });

  it('invoice export and disputes', async () => {
    const customer = await createCustomer();
    const json = await new InvoiceExportService().exportCustomerInvoices(customer.id, 'json');
    expect(json).toContain('[');
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const dispute = await new BillingDisputeService().open(inv.id, 100, 'test');
    const updated = await new BillingDisputeService().transition(dispute.id, 'under_review');
    expect(updated.status).toBe('under_review');
  });

  it('subscription migration preview', async () => {
    const plan = await createPlan();
    const plan2 = await createPlan({ name: 'Pro', price_cents: 20_000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const preview = await new SubscriptionMigrationService().preview(
      sub.id,
      plan2.id,
      sub.current_period_start.toString().slice(0, 10)
    );
    expect(preview.to_plan_id).toBe(plan2.id);
  });

  it('contract repository', async () => {
    const customer = await createCustomer();
    const { ContractService } = await import('../../../src/services/ContractService');
    const c = await new ContractService().create({
      customer_id: customer.id,
      reference: `REF-${Date.now()}`,
      effective_from: '2026-06-01',
    });
    await new ContractService().activate(c.id);
    const repo = new ContractRepository(getTestDb());
    const found = await repo.findByReference(c.reference);
    expect(found?.id).toBe(c.id);
    const list = await repo.listActiveForCustomer(customer.id);
    expect(list.length).toBeGreaterThan(0);
  });

  it('period close reconcile and reconciliation', async () => {
    const close = new BillingPeriodCloseService();
    await close.openPeriod('2026-04-01', '2026-04-30');
    const rec = await close.reconcile('2026-04-01', '2026-04-30');
    expect(rec.status).toBe('reconciled');
    const report = await new BillingReconciliationService().reconcileOpenInvoices();
    expect(report.balanced).toBeDefined();
  });

  it('payment vault and rate limits', async () => {
    const customer = await createCustomer();
    const method = await new PaymentMethodVaultService().store({
      customer_id: customer.id,
      brand: 'visa',
      last4: '4242',
      exp_month: 12,
      exp_year: 2030,
      set_default: true,
    });
    expect(method.default_method).toBe(true);
    const principals = await new PrincipalService().list();
    const p = principals[0];
    await new RateLimitPolicyService().setOverride(p.id, 500);
    expect(await new RateLimitPolicyService().getForPrincipal(p.id)).toBe(500);
  });

  it('webhook signing and alerts', async () => {
    const signed = new WebhookSigningService().sign('test.event', { ok: true });
    expect(
      new WebhookSigningService().verify(signed.event_type, signed.payload, signed.timestamp, signed.signature)
    ).toBe(true);
    const alert = await new BillingAlertService().raise('test', 'info', { x: 1 });
    const ack = await new BillingAlertService().acknowledge(alert.id);
    expect(ack.acknowledged).toBe(true);
  });

  it('saga list recent', async () => {
    const saga = new SagaOrchestrator();
    await saga.run('list_test', [{ name: 's', run: async () => undefined }]);
    const recent = await saga.listRecent(5);
    expect(recent.length).toBeGreaterThan(0);
  });

  it('renders invoice document text', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const { InvoiceDocumentService } = await import('../../../src/services/InvoiceDocumentService');
    const text = await new InvoiceDocumentService().renderText(inv.id);
    expect(text).toContain('INVOICE');
    expect(text).toContain(inv.id);
  });

  it('export and forecast jobs', async () => {
    const customer = await createCustomer();
    const { DataExportService } = await import('../../../src/services/DataExportService');
    await new DataExportService().request(customer.id);
    const exports = await runExportJob();
    expect(exports).toBeGreaterThanOrEqual(1);
    const months = await runForecastJob('2026-06-02');
    expect(months).toBe(12);
  });
});
