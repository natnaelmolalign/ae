import request from 'supertest';
import { createApp } from '../../../src/app';
import { BillingAnalyticsFacade } from '../../../src/services/BillingAnalyticsFacade';
import { UsageAggregationService } from '../../../src/services/UsageAggregationService';
import { RevenueRecognitionService } from '../../../src/services/RevenueRecognitionService';
import { SagaOrchestrator } from '../../../src/services/SagaOrchestrator';
import { ProrationService } from '../../../src/services/ProrationService';
import { SubscriptionItemService } from '../../../src/services/SubscriptionItemService';
import { SubscriptionAggregate } from '../../../src/domain/subscription/SubscriptionAggregate';
import { ContractRepository } from '../../../src/repositories/ContractRepository';
import { EventProjectionService } from '../../../src/services/EventProjectionService';
import { BillingWaterfallService } from '../../../src/services/BillingWaterfallService';
import { AddonProductService } from '../../../src/services/AddonProductService';
import { MeteringService } from '../../../src/services/MeteringService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { PaymentService } from '../../../src/services/PaymentService';
import { DomainError } from '../../../src/domain/shared/AggregateRoot';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Full coverage sweep 9', () => {
  it('facade health applies every penalty and drill-down maps customers', async () => {
    const facade = new BillingAnalyticsFacade();
    const zero = await facade.healthScore('2099-02');
    expect(zero.factors).toContain('zero_mrr');

    const plan = await createPlan({ price_cents: 12_000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const db = getTestDb();
    await db('invoices').where({ id: inv.id }).update({
      subtotal_cents: 9000,
      total_cents: 9000,
      status: 'paid',
      created_at: new Date('2026-06-05T12:00:00Z'),
    });
    await db('payments').insert({
      invoice_id: inv.id,
      status: 'succeeded',
      amount_cents: 1,
      attempted_at: new Date('2026-06-05T12:00:00Z'),
    });
    for (let i = 0; i < 6; i++) {
      const c = await createCustomer();
      const s = await new SubscriptionService().create({ customer_id: c.id, plan_id: plan.id });
      await db('subscriptions').where({ id: s.id }).update({
        status: 'cancelled',
        updated_at: new Date('2026-06-12T12:00:00Z'),
      });
    }
    await new InvoiceService().markPaid(inv.id);
    await new RevenueRecognitionService().createForPaidInvoice(inv.id);
    const health = await facade.healthScore('2026-06');
    expect(health.factors.length).toBeGreaterThanOrEqual(2);
    expect(health.score).toBeLessThan(75);

    const drill = await facade.drillDown('2026-06', 2);
    expect(drill.reconciliation_errors).toBeGreaterThan(0);
    expect(drill.waterfall_steps.length).toBeGreaterThan(0);

    const mom = await facade.monthOverMonth('2026-01');
    expect(mom.previous.period_key).toBe('2025-12');
    await facade.agingAndForecast();
  });

  it('usage aggregation parses object tiers and ingest null path', async () => {
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
    });
    const db = getTestDb();
    const [meter] = await db('meters')
      .insert({
        code: 'obj-tier-meter',
        name: 'Object tiers',
        aggregation: 'sum',
        tier_config: JSON.stringify([{ up_to: null, unit_cents: 7 }]),
      })
      .returning('*');
    await db('usage_records').insert({
      meter_id: meter.id,
      subscription_id: sub.id,
      quantity: 10,
      recorded_at: new Date('2026-06-08T12:00:00Z'),
    });
    const agg = new UsageAggregationService();
    const rows = await agg.aggregateForSubscription(sub.id, '2026-06-01', '2026-06-30');
    expect(rows.some((r) => r.meter === 'obj-tier-meter')).toBe(true);

    await new MeteringService().createMeter({
      code: 'ingest-meter',
      name: 'Ingest',
      tier_config: [{ up_to: null, unit_price_cents: 2 }],
    });
    const hit = await agg.ingestAndAggregate(sub.id, 'ingest-meter', 3, '2026-06-10T12:00:00Z');
    expect(hit?.quantity).toBe(3);
    await expect(
      agg.ingestAndAggregate(sub.id, 'missing-meter', 1, '2026-06-10T12:00:00Z')
    ).rejects.toMatchObject({ statusCode: 404 });
  });

  it('revenue recognition duplicate guard remainder and paid guard', async () => {
    const rev = new RevenueRecognitionService();
    const plan = await createPlan({ price_cents: 1000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    await getTestDb()('subscriptions').where({ id: sub.id }).update({
      current_period_start: '2026-06-01',
      current_period_end: '2026-06-03',
    });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await expect(rev.createForPaidInvoice(inv.id)).rejects.toMatchObject({ statusCode: 400 });
    await new InvoiceService().markPaid(inv.id);
    const count = await rev.createForPaidInvoice(inv.id);
    expect(count).toBeGreaterThan(0);
    expect(await rev.createForPaidInvoice(inv.id)).toBe(0);
    const summary = await rev.summaryForSubscription(sub.id);
    expect(summary.pending_cents + summary.recognized_cents).toBeGreaterThan(0);
    await rev.recognizeDue(new Date('2026-06-02'));
    const listed = await rev.listForInvoice(inv.id);
    expect(listed.length).toBeGreaterThan(0);
  });

  it('saga compensates and wraps non-app errors', async () => {
    const saga = new SagaOrchestrator();
    const compensated: string[] = [];
    await expect(
      saga.run('sweep9_fail', [
        {
          name: 'first',
          run: async () => undefined,
          compensate: async () => {
            compensated.push('first');
          },
        },
        {
          name: 'second',
          run: async () => {
            throw new Error('step failed');
          },
        },
      ])
    ).rejects.toMatchObject({ statusCode: 500 });
    expect(compensated).toEqual(['first']);

    const ok = await saga.run('sweep9_ok', [{ name: 'only', run: async () => undefined }], {
      seed: true,
    });
    expect(ok.status).toBe('completed');
    expect(ok.context).toEqual({ seed: true });
    const recent = await saga.listRecent(5);
    expect(recent.some((r) => r.saga_name === 'sweep9_ok')).toBe(true);
  });

  it('proration mid-cycle credit charge and subscription item quantity paths', async () => {
    const cheap = await createPlan({ name: 'Cheap', price_cents: 1000 });
    const premium = await createPlan({ name: 'Premium', price_cents: 8000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: cheap.id,
      billing_anchor: '2026-06-01',
    });
    const proration = new ProrationService();
    const upgraded = await proration.changePlanMidCycle(sub.id, premium.id, '2026-06-05');
    expect(upgraded.proration.netCents).toBeGreaterThan(0);
    expect(upgraded.subscription.plan_id).toBe(premium.id);

    await expect(proration.changePlanMidCycle(sub.id, premium.id, '2026-06-06')).rejects.toMatchObject({
      statusCode: 400,
    });
    await getTestDb()('subscriptions').where({ id: sub.id }).update({ status: 'cancelled' });
    await expect(
      proration.changePlanMidCycle(sub.id, cheap.id, '2026-06-07')
    ).rejects.toMatchObject({ statusCode: 400 });

    const addonCode = `addon-qty-${Date.now()}`;
    await new AddonProductService().create({ code: addonCode, name: 'Seats', price_cents: 500 });
    const items = new SubscriptionItemService();
    const active = await new SubscriptionService().create({
      customer_id: (await createCustomer()).id,
      plan_id: cheap.id,
    });
    const addon = await items.addAddon(active.id, addonCode, 2);
    const increased = await items.changeQuantity(addon.id, 4, '2026-06-10');
    expect(increased.prorationCents).toBeGreaterThan(0);
    const decreased = await items.changeQuantity(addon.id, 1, '2026-06-12');
    expect(decreased.prorationCents).toBeLessThan(0);
    const base = await items.listActive(active.id);
    const baseItem = base.find((i) => i.item_type === 'base_plan');
    await expect(
      items.changeQuantity(baseItem!.id, 2, '2026-06-10')
    ).rejects.toMatchObject({ statusCode: 400 });
  });

  it('subscription aggregate default trial and invalid transition', () => {
    const trial = SubscriptionAggregate.create({
      id: 's-trial',
      customerId: 'c1',
      planId: 'p1',
      trialEndsAt: new Date('2026-07-01'),
      currentPeriodStart: new Date('2026-06-01'),
      currentPeriodEnd: new Date('2026-06-30'),
    });
    expect(trial.snapshot.status).toBe('trial');

    const trialOnly = SubscriptionAggregate.create({
      id: 's-trial2',
      customerId: 'c1',
      planId: 'p1',
      trialEndsAt: new Date('2026-07-01'),
      currentPeriodStart: new Date('2026-06-01'),
      currentPeriodEnd: new Date('2026-06-30'),
    });
    expect(() => trialOnly.transition('past_due', 'invalid')).toThrow(DomainError);
  });

  it('contract repository event projections and waterfall aging', async () => {
    const repo = new ContractRepository(getTestDb());
    expect(await repo.findByReference('missing-ref-xyz')).toBeNull();

    const customer = await createCustomer();
    const [contract] = await getTestDb()('contracts')
      .insert({
        customer_id: customer.id,
        reference: `ref-${Date.now()}`,
        status: 'active',
        effective_from: '2026-01-01',
        terms: JSON.stringify({ seats: 5 }),
        committed_mrr_cents: 50_000,
      })
      .returning('*');
    const found = await repo.findByReference(contract.reference as string);
    expect(found?.terms).toEqual({ seats: 5 });
    expect((await repo.listActiveForCustomer(customer.id)).length).toBeGreaterThan(0);

    await getTestDb()('domain_events').insert({
      event_type: 'subscription.updated',
      aggregate_type: 'subscription',
      aggregate_id: '00000000-0000-4000-8000-000000000099',
      payload: JSON.stringify({ ok: true }),
      occurred_at: new Date(),
    });
    const projections = new EventProjectionService();
    expect(await projections.rebuildSubscriptionSummary()).toBeGreaterThanOrEqual(1);
    expect((await projections.listByAggregate('subscription')).length).toBeGreaterThan(0);

    const wf = new BillingWaterfallService();
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await getTestDb()('invoices').where({ id: inv.id }).update({
      status: 'pending',
      created_at: new Date(Date.now() - 20 * 86400000),
    });
    const aging = await wf.agingBuckets(new Date());
    expect(aging.some((b) => b.outstanding_cents > 0)).toBe(true);
  });

  it('analytics board routes over HTTP', async () => {
    const app = createApp();
    expect(
      (await request(app).get('/analytics-board/2026-06/board-pack').set('x-api-key', API_KEY)).status
    ).toBe(200);
  });
});
