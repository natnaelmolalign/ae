import request from 'supertest';
import { createApp } from '../../../src/app';
import { CustomerInsightsService } from '../../../src/services/CustomerInsightsService';
import { BillingPeriodCloseService } from '../../../src/services/BillingPeriodCloseService';
import { DomainEventPublisher } from '../../../src/services/DomainEventPublisher';
import { WebhookReplayService } from '../../../src/services/WebhookReplayService';
import { BillingScheduleService } from '../../../src/services/BillingScheduleService';
import { PlanService } from '../../../src/services/PlanService';
import { EventProjectionService } from '../../../src/services/EventProjectionService';
import { BillingForecastEngine } from '../../../src/services/BillingForecastEngine';
import { RetentionPolicyService } from '../../../src/services/RetentionPolicyService';
import { CreditNoteService } from '../../../src/services/CreditNoteService';
import { CreditService } from '../../../src/services/CreditService';
import { HealthProbeService } from '../../../src/services/HealthProbeService';
import { DunningService } from '../../../src/services/DunningService';
import { OutboxService } from '../../../src/services/OutboxService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { PaymentService } from '../../../src/services/PaymentService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Full coverage sweep 10', () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('customer insights health ltv at-risk and 404', async () => {
    const insights = new CustomerInsightsService();
    await expect(
      insights.healthScore('00000000-0000-4000-8000-000000000099')
    ).rejects.toMatchObject({ statusCode: 404 });

    const customer = await createCustomer();
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    await getTestDb()('subscriptions').where({ id: sub.id }).update({ status: 'past_due' });
    const health = await insights.healthScore(customer.id);
    expect(health.score).toBeLessThan(100);

    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await new PaymentService().chargeInvoice(inv.id, true, { flushOutbox: false });
    const ltv = await insights.lifetimeValue(customer.id);
    expect(ltv.paid_cents).toBeGreaterThan(0);
    expect(ltv.estimated_ltv_cents).toBeGreaterThan(0);

    const atRisk = await insights.atRiskCustomers(5);
    expect(Array.isArray(atRisk)).toBe(true);
  });

  it('period close unpaid guard and domain event multi-channel publish', async () => {
    const close = new BillingPeriodCloseService();
    const start = '2098-03-01';
    const end = '2098-03-31';
    await close.openPeriod(start, end);
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await getTestDb()('invoices').where({ id: inv.id }).update({
      created_at: new Date('2098-03-10T12:00:00Z'),
    });
    await close.reconcile(start, end);
    await expect(close.close(start, end)).rejects.toMatchObject({ statusCode: 409 });

    const publisher = new DomainEventPublisher();
    const event = await publisher.publish({
      eventType: 'test.multi',
      aggregateType: 'customer',
      aggregateId: customer.id,
      payload: { ok: true },
      channels: ['webhook', 'email'],
    });
    expect(event.payload.ok).toBe(true);
    const outbox = await getTestDb()('outbox_messages').where({ domain_event_id: event.id });
    expect(outbox.length).toBe(2);
  });

  it('webhook replay failure path and dunning map string stages', async () => {
    const db = getTestDb();
    const [policy] = await db('dunning_policies')
      .insert({
        name: 'string-stages',
        is_default: false,
        stages: JSON.stringify([{ type: 'retry', delay_days: 1 }]),
      })
      .returning('*');
    const mapped = await new DunningService().getPolicyForPlan(
      (await createPlan({ dunning_policy_id: policy.id })).id
    );
    expect(mapped.stages[0].type).toBe('retry');

    const replay = new WebhookReplayService();
    await expect(
      replay.replayMessage('00000000-0000-4000-8000-000000000099')
    ).rejects.toMatchObject({ statusCode: 404 });

    const [ev] = await db('domain_events')
      .insert({
        event_type: 'replay.fail',
        aggregate_type: 'payment',
        aggregate_id: '00000000-0000-4000-8000-000000000010',
        payload: JSON.stringify({}),
      })
      .returning('*');
    const [msg] = await db('outbox_messages')
      .insert({
        domain_event_id: ev.id,
        channel: 'webhook',
        status: 'failed',
        attempt_count: 3,
      })
      .returning('*');
    jest.spyOn(OutboxService.prototype, 'deliverOne').mockRejectedValue(new Error('delivery failed'));
    const result = await replay.replayMessage(msg.id as string);
    expect(result.status).toBe('failed');
    expect(result.error).toContain('delivery failed');
    expect((await replay.listReplayLog(1)).length).toBeGreaterThan(0);
  });

  it('billing schedules plan cache retention and projections', async () => {
    const customer = await createCustomer();
    const schedules = new BillingScheduleService();
    await expect(
      schedules.create({
        customer_id: customer.id,
        name: 'Bad anchor',
        cadence: 'monthly',
        anchor_day: 31,
      })
    ).rejects.toMatchObject({ statusCode: 400 });

    const monthly = await schedules.create({
      customer_id: customer.id,
      name: 'Monthly',
      cadence: 'monthly',
      anchor_day: 15,
      line_templates: [{ description: 'Base', amount_cents: 3000, quantity: 1 }],
    });
    expect(schedules.projectedMonthlyCents(monthly)).toBe(3000);

    const quarterly = await schedules.create({
      customer_id: customer.id,
      name: 'Quarterly',
      cadence: 'quarterly',
      anchor_day: 10,
      line_templates: [{ description: 'Q', amount_cents: 9000, quantity: 1 }],
    });
    expect(schedules.projectedMonthlyCents(quarterly)).toBe(3000);

    const annual = await schedules.create({
      customer_id: customer.id,
      name: 'Annual',
      cadence: 'annual',
      anchor_day: 5,
      line_templates: [{ description: 'Y', amount_cents: 12_000, quantity: 1 }],
    });
    expect(schedules.projectedMonthlyCents(annual)).toBe(1000);
    await schedules.deactivate(annual.id);

    const plans = new PlanService();
    const plan = await createPlan();
    const first = await plans.getById(plan.id);
    const cached = await plans.getById(plan.id);
    expect(cached.id).toBe(first.id);
    const page = await plans.listPaginated(1, 10, false);
    expect(page.total).toBeGreaterThan(0);

    const retention = new RetentionPolicyService();
    await retention.upsert('application_metrics', 30, true);
    await retention.upsert('application_metrics', 60, true);
    expect(await retention.purgeEntityType('unknown_entity')).toBe(0);
    await retention.upsert('bad_entity', 1, true);
    await expect(retention.purgeEntityType('bad_entity')).rejects.toMatchObject({ statusCode: 400 });

    const proj = new EventProjectionService();
    expect(await proj.paymentFailureRate(24)).toBe(0);
    await getTestDb()('domain_events').insert([
      {
        event_type: 'payment.failed',
        aggregate_type: 'payment',
        aggregate_id: '00000000-0000-4000-8000-000000000011',
        payload: JSON.stringify({}),
        occurred_at: new Date(),
      },
      {
        event_type: 'payment.succeeded',
        aggregate_type: 'payment',
        aggregate_id: '00000000-0000-4000-8000-000000000012',
        payload: JSON.stringify({}),
        occurred_at: new Date(),
      },
    ]);
    expect(await proj.paymentFailureRate(24)).toBeGreaterThan(0);

    const engine = new BillingForecastEngine();
    const pipeline = await engine.pipelineWeightedForecast();
    expect(pipeline.trial_count).toBeGreaterThanOrEqual(0);
    expect((await engine.exportForecastCsv()).includes('period')).toBe(true);
  });

  it('credit note guards and health probe degraded migrations', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const notes = new CreditNoteService();
    await expect(notes.issue({ invoice_id: inv.id, amount_cents: 0, reason: 'x' })).rejects.toMatchObject({
      statusCode: 400,
    });
    await expect(
      notes.issue({ invoice_id: inv.id, amount_cents: inv.total_cents + 1, reason: 'x' })
    ).rejects.toMatchObject({ statusCode: 400 });
    await new InvoiceService().voidInvoice(inv.id);
    await expect(
      notes.issue({ invoice_id: inv.id, amount_cents: 100, reason: 'x' })
    ).rejects.toMatchObject({ statusCode: 400 });

    const credits = new CreditService();
    expect(await credits.applyToInvoice(customer.id, inv.id, 50, 'void')).toBe(0);

    const probe = new HealthProbeService();
    jest.spyOn(probe as unknown as { pendingMigrations: () => Promise<number> }, 'pendingMigrations').mockResolvedValue(2);
    const report = await probe.probe();
    expect(report.status).toBe('degraded');
    expect(report.migrations.pending).toBe(2);
  });

  it('schedules and period-close routes over HTTP', async () => {
    const app = createApp();
    const customer = await createCustomer();
    expect(
      (
        await request(app)
          .post('/schedules')
          .set('x-api-key', API_KEY)
          .send({
            customer_id: customer.id,
            name: 'Route schedule',
            cadence: 'monthly',
            anchor_day: 12,
            line_templates: [{ description: 'Line', amount_cents: 1000, quantity: 1 }],
          })
      ).status
    ).toBe(201);
    expect((await request(app).get('/period-closes').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).post('/webhook-replay').set('x-api-key', API_KEY)).status).toBe(200);
  });
});
