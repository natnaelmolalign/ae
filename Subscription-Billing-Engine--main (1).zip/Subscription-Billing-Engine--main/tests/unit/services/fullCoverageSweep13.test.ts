import request from 'supertest';
import { createApp } from '../../../src/app';
import { runAnalyticsJob } from '../../../src/jobs/analyticsJob';
import { runBillingJob } from '../../../src/jobs/billingJob';
import { JobLockService } from '../../../src/services/JobLockService';
import { CreditService } from '../../../src/services/CreditService';
import { RevenueRecognitionService } from '../../../src/services/RevenueRecognitionService';
import { CohortAnalysisService } from '../../../src/services/CohortAnalysisService';
import { BillingCatalogService } from '../../../src/services/BillingCatalogService';
import { BillingSnapshotService } from '../../../src/services/BillingSnapshotService';
import { CouponService } from '../../../src/services/CouponService';
import { UsageAggregationService } from '../../../src/services/UsageAggregationService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { PaymentService } from '../../../src/services/PaymentService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Full coverage sweep 13', () => {
  const app = createApp();

  it('analytics job skipped when lock already held', async () => {
    const db = getTestDb();
    await db('job_runs').insert({
      job_name: 'analytics',
      status: 'running',
      started_at: new Date(),
    });
    expect(await runAnalyticsJob(new Date('2026-06-01'), 1)).toBe(0);
  });

  it('billing job skips subscriptions with future period start', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    await getTestDb()('subscriptions').where({ id: sub.id }).update({
      current_period_start: '2099-01-01',
      current_period_end: '2099-02-01',
    });
    expect(await runBillingJob(new Date('2026-06-01'))).toBeGreaterThanOrEqual(0);
  });

  it('JobLockService filters listRecent by job name', async () => {
    const lock = new JobLockService();
    await lock.runExclusive('billing', async () => 1);
    const filtered = await lock.listRecent('billing', 5);
    expect(filtered.every((r) => r.job_name === 'billing')).toBe(true);
  });

  it('CreditService apply and refund branches', async () => {
    const credits = new CreditService();
    await expect(credits.issue({ customer_id: (await createCustomer()).id, amount_cents: 0, reason: 'x' })).rejects.toMatchObject({
      statusCode: 400,
    });
    expect(await credits.applyToInvoice((await createCustomer()).id, 'inv', 100, 'void')).toBe(0);
    expect(await credits.applyToInvoice((await createCustomer()).id, 'inv', 100, 'pending')).toBe(0);

    const rich = await createCustomer({ credit_balance_cents: 0 });
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({ customer_id: rich.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, rich.country);
    await credits.issue({ customer_id: rich.id, amount_cents: 500, reason: 'grant' });
    const applied = await credits.applyToInvoice(rich.id, inv.id, 300, 'pending');
    expect(applied).toBe(300);

    await expect(credits.refundToCredit(rich.id, 100, 200)).rejects.toMatchObject({ statusCode: 400 });
    const refund = await credits.refundToCredit(rich.id, 100, 50);
    expect(refund.amount_cents).toBe(50);
  });

  it('RevenueRecognition remainder distribution and summary', async () => {
    const rev = new RevenueRecognitionService();
    const plan = await createPlan({ price_cents: 1003 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    await getTestDb()('subscriptions').where({ id: sub.id }).update({
      current_period_start: '2026-06-01',
      current_period_end: '2026-06-03',
    });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await new InvoiceService().markPaid(inv.id);
    const count = await rev.createForPaidInvoice(inv.id);
    expect(count).toBe(3);
    expect(await rev.createForPaidInvoice(inv.id)).toBe(0);
    await rev.recognizeDue(new Date('2026-06-30'));
    const summary = await rev.summaryForSubscription(sub.id);
    expect(summary.recognized_cents + summary.pending_cents).toBeGreaterThan(0);
  });

  it('CohortAnalysisService builds matrix and average retention', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    await getTestDb()('subscriptions').where({ id: sub.id }).update({
      created_at: new Date('2026-05-15T12:00:00Z'),
    });
    const cohort = new CohortAnalysisService();
    const matrix = await cohort.buildRetentionMatrix(6, 2);
    expect(matrix.length).toBeGreaterThan(0);
    expect(await cohort.averageRetentionByOffset(0)).toBeGreaterThanOrEqual(0);
  });

  it('BillingCatalogService quotes bundles and custom components', async () => {
    const catalog = new BillingCatalogService();
    expect(catalog.listBundles().length).toBeGreaterThan(0);
    catalog.registerComponent({
      sku: 'extra',
      description: 'Extra',
      currency: 'USD',
      tiers: [{ up_to: null, unit_cents: 100 }],
    });
    expect(catalog.listComponents().some((c) => c.sku === 'extra')).toBe(true);
    const quote = catalog.quoteBundle('growth', 5, 1000, 'DE');
    expect(quote.total_cents).toBeGreaterThan(0);
    expect(() => catalog.quoteBundle('missing', 1, 0, 'US')).toThrow('Bundle not found');
  });

  it('BillingSnapshotService captures usage and collections types', async () => {
    const snaps = new BillingSnapshotService();
    const mrr = await snaps.capture({ snapshot_type: 'mrr', period_key: '2026-06' });
    expect((mrr.metrics as { mrr_cents?: number }).mrr_cents).toBeGreaterThanOrEqual(0);
    const usage = await snaps.capture({ snapshot_type: 'usage', period_key: '2026-06' });
    expect(usage.snapshot_type).toBe('usage');
  });

  it('CouponService fixed amount and usage limits', async () => {
    const coupons = new CouponService();
    const code = `FIX-${Date.now()}`;
    await coupons.create({
      code,
      discount_type: 'fixed',
      discount_value: 500,
      usage_limit: 1,
    });
    const row = await coupons.getByCode(code);
    expect(coupons.applyDiscount(2000, row)).toBe(500);
    await expect(coupons.getByCode('no-such-code')).rejects.toBeDefined();
  });

  it('UsageAggregationService reads object tier_config rows from metering', async () => {
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
    });
    const db = getTestDb();
    const [meter] = await db('meters')
      .insert({
        code: 'obj-tier-sw13',
        name: 'Obj',
        aggregation: 'sum',
        tier_config: JSON.stringify([{ up_to: null, unit_price_cents: 5 }]),
      })
      .returning('*');
    await db('usage_records').insert({
      meter_id: meter.id,
      subscription_id: sub.id,
      quantity: 3,
      recorded_at: new Date('2026-06-11T12:00:00Z'),
    });
    const rows = await new UsageAggregationService().aggregateForSubscription(
      sub.id,
      '2026-06-01',
      '2026-06-30'
    );
    expect(rows.find((r) => r.meter === 'obj-tier-sw13')?.rated_cents).toBe(15);
  });

  it('payments route and feature flag toggle', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const pay = await request(app)
      .post('/payments/charge')
      .set('x-api-key', API_KEY)
      .send({ invoice_id: inv.id, simulate_success: true });
    expect(pay.status).toBe(201);

    const flags = await request(app).get('/feature-flags').set('x-api-key', API_KEY);
    expect(flags.status).toBe(200);
    if (flags.body.length > 0) {
      const key = flags.body[0].key as string;
      expect(
        (
          await request(app)
            .put('/feature-flags')
            .set('x-api-key', API_KEY)
            .send({ key, enabled: false })
        ).status
      ).toBe(200);
    }
  });
});
