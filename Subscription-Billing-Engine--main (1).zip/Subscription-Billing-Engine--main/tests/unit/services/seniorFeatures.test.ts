import { PrincipalService } from '../../../src/services/RbacService';
import { WorkflowEngine } from '../../../src/services/WorkflowEngine';
import { FeatureFlagService } from '../../../src/services/FeatureFlagService';
import { RetentionPolicyService } from '../../../src/services/RetentionPolicyService';
import { BillingPeriodCloseService } from '../../../src/services/BillingPeriodCloseService';
import { TaxCalculationService } from '../../../src/services/TaxCalculationService';
import { SagaOrchestrator } from '../../../src/services/SagaOrchestrator';
import { BillingReconciliationService } from '../../../src/services/BillingReconciliationService';
import { NotificationService } from '../../../src/services/NotificationService';
import { InvoiceAggregate } from '../../../src/domain/invoice/InvoiceAggregate';
import { SubscriptionAggregate } from '../../../src/domain/subscription/SubscriptionAggregate';
import { BillingRulesEngine } from '../../../src/domain/billing/BillingRulesEngine';
import { globalMetrics } from '../../../src/lib/metrics';
import { createPlan, createCustomer } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Senior backend features', () => {
  beforeAll(async () => {
    await new PrincipalService().bootstrapFromEnvMasterKey(API_KEY);
  });

  describe('RBAC', () => {
    it('grants admin full permission to master principal', async () => {
      const principals = new PrincipalService();
      const p = await principals.bootstrapFromEnvMasterKey(API_KEY);
      expect(await principals.hasPermission(p.id, 'admin', 'full')).toBe(true);
      expect(await principals.hasPermission(p.id, 'invoices', 'write')).toBe(true);
    });

    it('creates scoped principal without admin', async () => {
      const principals = new PrincipalService();
      const { principal, apiKey } = await principals.create('readonly-bot', ['billing_readonly']);
      const resolved = await principals.resolveByApiKey(apiKey);
      expect(resolved?.id).toBe(principal.id);
      expect(await principals.hasPermission(principal.id, 'plans', 'read')).toBe(true);
      expect(await principals.hasPermission(principal.id, 'admin', 'full')).toBe(false);
    });
  });

  describe('WorkflowEngine', () => {
    it('runs subscription lifecycle transitions', async () => {
      const engine = new WorkflowEngine();
      await engine.seedSubscriptionLifecycle();
      const plan = await createPlan();
      const customer = await createCustomer();
      const sub = await new SubscriptionService().create({
        customer_id: customer.id,
        plan_id: plan.id,
      });
      const instance = await engine.start(
        'subscription_lifecycle',
        'subscription',
        sub.id,
        'trialing',
        {}
      );
      const active = await engine.trigger(instance.id, 'trial_convert');
      expect(active.current_state).toBe('active');
      const history = await engine.getHistory(instance.id);
      expect(history.length).toBeGreaterThanOrEqual(2);
    });
  });

  describe('Feature flags', () => {
    it('evaluates rollout rules', async () => {
      const flags = new FeatureFlagService();
      await flags.upsert('test_rollout', true, { percentage_rollout: 100 });
      expect(await flags.isEnabled('test_rollout', { plan_id: 'x' })).toBe(true);
      await flags.upsert('test_rollout', true, { percentage_rollout: 0 });
      expect(await flags.isEnabled('test_rollout', { plan_id: 'x' })).toBe(false);
    });
  });

  describe('Retention', () => {
    it('seeds policies', async () => {
      const svc = new RetentionPolicyService();
      await svc.seedDefaults();
      const list = await svc.list();
      expect(list.length).toBeGreaterThanOrEqual(3);
    });
  });

  describe('Tax and billing rules', () => {
    it('calculates EU VAT', () => {
      const tax = new TaxCalculationService();
      const result = tax.computeForCustomer(10000, 'DE');
      expect(result.tax_cents).toBeGreaterThan(0);
      expect(result.jurisdiction).toBe('EU-DE');
    });

    it('applies tiered usage', () => {
      const rules = new BillingRulesEngine();
      const total = rules.tieredUsageCharge(150, [
        { up_to: 100, unit_cents: 10 },
        { up_to: null, unit_cents: 5 },
      ]);
      expect(total).toBe(100 * 10 + 50 * 5);
    });
  });

  describe('Domain aggregates', () => {
    it('invoice lifecycle', () => {
      const inv = InvoiceAggregate.draft('inv-1', 'sub-1', [
        { description: 'Base', quantity: 1, unit_amount_cents: 1000, amount_cents: 1000 },
      ]);
      inv.applyTax(100);
      inv.markOpen();
      inv.markPaid();
      expect(inv.snapshot.status).toBe('paid');
      expect(inv.pullEvents().length).toBeGreaterThan(0);
    });

    it('subscription failed payment transition', () => {
      const agg = SubscriptionAggregate.create({
        id: 's1',
        customerId: 'c1',
        planId: 'p1',
        status: 'active',
        trialEndsAt: null,
        currentPeriodStart: new Date(),
        currentPeriodEnd: new Date(),
      });
      agg.recordFailedPayment();
      expect(agg.snapshot.status).toBe('past_due');
    });
  });

  describe('Saga', () => {
    it('completes happy path', async () => {
      const saga = new SagaOrchestrator();
      let flag = false;
      const run = await saga.run('test_saga', [
        { name: 'step1', run: async () => { flag = true; } },
      ]);
      expect(run.status).toBe('completed');
      expect(flag).toBe(true);
    });

    it('compensates on failure', async () => {
      const saga = new SagaOrchestrator();
      let compensated = false;
      await expect(
        saga.run('fail_saga', [
          { name: 'a', run: async () => undefined, compensate: async () => { compensated = true; } },
          { name: 'b', run: async () => { throw new Error('fail'); } },
        ])
      ).rejects.toBeDefined();
      expect(compensated).toBe(true);
    });
  });

  describe('Metrics', () => {
    it('exports prometheus text', () => {
      globalMetrics.increment('test_counter', { env: 'test' });
      const text = globalMetrics.toPrometheusText();
      expect(text).toContain('test_counter');
    });
  });

  describe('Notifications', () => {
    it('enqueues and processes', async () => {
      const n = new NotificationService();
      await n.enqueue('internal', {
        template: 'test',
        recipient: 'ops@example.com',
        data: { ok: true },
      });
      const sent = await n.processPending();
      expect(sent).toBeGreaterThanOrEqual(1);
    });
  });

  describe('Reconciliation', () => {
    it('returns balanced report for empty ledger', async () => {
      const report = await new BillingReconciliationService().reconcileOpenInvoices();
      expect(report.balanced).toBe(true);
    });
  });

  describe('Period close', () => {
    it('opens and reconciles period', async () => {
      const svc = new BillingPeriodCloseService();
      const open = await svc.openPeriod('2026-06-01', '2026-06-30');
      expect(open.status).toBe('open');
      const rec = await svc.reconcile('2026-06-01', '2026-06-30');
      expect(rec.status).toBe('reconciled');
    });
  });
});
