import request from 'supertest';
import * as database from '../../../src/config/database';
import { createApp } from '../../../src/app';
import { runAnalyticsJob } from '../../../src/jobs/analyticsJob';
import { runBillingJob } from '../../../src/jobs/billingJob';
import { JobLockService } from '../../../src/services/JobLockService';
import { DunningService } from '../../../src/services/DunningService';
import { DataExportService } from '../../../src/services/DataExportService';
import { BillingWaterfallService } from '../../../src/services/BillingWaterfallService';
import { BillingForecastEngine } from '../../../src/services/BillingForecastEngine';
import { HealthProbeService } from '../../../src/services/HealthProbeService';
import { PolicyEvaluationService } from '../../../src/services/PolicyEvaluationService';
import { MinimumCommitmentCalculator } from '../../../src/domain/billing/MinimumCommitmentCalculator';
import { parseUuidParam } from '../../../src/lib/parseUuidParam';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Full coverage sweep 8', () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('analytics and billing jobs honor skipped and undefined lock outcomes', async () => {
    const lockSpy = jest.spyOn(JobLockService.prototype, 'runExclusive');
    lockSpy.mockResolvedValueOnce({ skipped: true });
    expect(await runAnalyticsJob(new Date('2026-06-01'), 2)).toBe(0);

    lockSpy.mockResolvedValueOnce({ skipped: false, result: undefined });
    expect(await runAnalyticsJob()).toBe(0);

    lockSpy.mockResolvedValueOnce({ skipped: false, result: 4 });
    expect(await runAnalyticsJob()).toBe(4);

    lockSpy.mockResolvedValueOnce({ skipped: false, result: undefined });
    expect(await runBillingJob()).toBe(0);
  });

  it('dunning policy plan override scheduling and cancel detection', async () => {
    const dunning = new DunningService();
    const db = getTestDb();
    const [policy] = await db('dunning_policies')
      .insert({
        name: 'custom',
        is_default: false,
        stages: JSON.stringify([{ type: 'retry', delay_days: 2 }]),
      })
      .returning('*');
    const plan = await createPlan({ dunning_policy_id: policy.id });
    const custom = await dunning.getPolicyForPlan(plan.id);
    expect(custom.name).toBe('custom');

    expect(
      dunning.shouldCancelAfterRetries(
        [
          { type: 'retry', delay_days: 1 },
          { type: 'cancel', delay_days: 1 },
        ],
        1
      )
    ).toBe(true);

    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const at = new Date('2026-06-01T12:00:00Z');
    await dunning.scheduleRetriesForPolicy(sub.id, inv.id, plan.id, at);
    await dunning.scheduleRetriesForPolicy(sub.id, inv.id, plan.id, at);
    const retries = await db('payment_retries').where({ invoice_id: inv.id });
    expect(retries.length).toBe(1);
  });

  it('data export early return and failure path', async () => {
    const exp = new DataExportService();
    const customer = await createCustomer();
    const req = await exp.request(customer.id);
    await getTestDb()('data_export_requests').where({ id: req.id }).update({ status: 'completed' });
    const again = await exp.process(req.id);
    expect(again.status).toBe('completed');

    const failReq = await exp.request((await createCustomer()).id);
    jest
      .spyOn(DataExportService.prototype as unknown as { buildArtifact: () => Promise<unknown> }, 'buildArtifact')
      .mockRejectedValue(new Error('export boom'));
    await expect(exp.process(failReq.id)).rejects.toMatchObject({ statusCode: 500 });
    const failed = await exp.getById(failReq.id);
    expect(failed.status).toBe('failed');
  });

  it('waterfall cohort empty months forecast and policy helpers', async () => {
    const wf = new BillingWaterfallService();
    const cohort = await wf.cohortRetention(0);
    expect(cohort.length).toBeGreaterThan(0);
    expect(cohort.some((r) => r.customers === 0)).toBe(true);
    await wf.exportCsv('2026-06');
    await wf.compareWaterfalls('2026-05', '2026-06');
    await expect(wf.buildForPeriod('not-a-period')).rejects.toMatchObject({ statusCode: 400 });

    const engine = new BillingForecastEngine();
    jest.spyOn(engine, 'trailingMrr').mockResolvedValue([]);
    jest.spyOn(BillingWaterfallService.prototype, 'forecastFromHistory').mockResolvedValue([]);
    const points = await engine.projectNextMonths(2);
    expect(points.length).toBe(2);
    expect(points[0].projected_mrr_cents).toBe(0);

    const calc = new MinimumCommitmentCalculator();
    const tiers = [{ name: 'enterprise', minimum_mrr_cents: 500_000, overage_unit_cents: 5 }];
    expect(calc.selectTier(1, tiers).name).toBe('enterprise');
    expect(calc.selectTier(600_000, tiers).name).toBe('enterprise');

    const policy = new PolicyEvaluationService();
    expect(policy.seatPrice(0)).toBeGreaterThanOrEqual(0);
    const quote = policy.quote({
      subtotal_cents: 5000,
      country: 'US',
      usage_quantity: 100,
      usage_tiers: [{ up_to: 50, unit_cents: 10 }, { up_to: null, unit_cents: 5 }],
    });
    expect(quote.total_cents).toBeGreaterThan(5000);
  });

  it('parseUuidParam default label and health root degraded path', async () => {
    expect(() => parseUuidParam('bad')).toThrow(/Invalid id/);

    const app = createApp();
    const raw = jest.spyOn(database, 'getDb').mockReturnValue({
      raw: jest.fn().mockRejectedValue(new Error('db down')),
    } as never);
    const res = await request(app).get('/health');
    raw.mockRestore();
    expect(res.status).toBe(503);
    expect(res.body.database).toBe('down');

    const probe = new HealthProbeService();
    jest.spyOn(probe as unknown as { checkDisk: () => boolean }, 'checkDisk').mockReturnValue(false);
    const report = await probe.probe();
    expect(report.status).toBe('degraded');
    expect(report.disk.ok).toBe(false);
  });

  it('insights forecast default query and policy seat default via HTTP', async () => {
    const app = createApp();
    const customer = await createCustomer();
    expect((await request(app).get('/insights/forecast').set('x-api-key', API_KEY)).status).toBe(200);
    expect(
      (
        await request(app)
          .get(`/insights/customers/${customer.id}/invoices/export`)
          .set('x-api-key', API_KEY)
      ).status
    ).toBe(200);
    const seatsDefault = await request(app).get('/policy/seat-price').set('x-api-key', API_KEY);
    expect(seatsDefault.status).toBe(200);
    expect(seatsDefault.body.seats).toBe(1);
  });
});
