import request from 'supertest';
import * as database from '../../../src/config/database';
import { createApp } from '../../../src/app';
import { shutdown } from '../../../src/app';
import { runAnalyticsJob } from '../../../src/jobs/analyticsJob';
import { runBillingJob } from '../../../src/jobs/billingJob';
import { BillingWaterfallService } from '../../../src/services/BillingWaterfallService';
import { BillingForecastEngine } from '../../../src/services/BillingForecastEngine';
import { BillingAlertService } from '../../../src/services/BillingAlertService';
import { UsageAggregationService } from '../../../src/services/UsageAggregationService';
import { SagaOrchestrator } from '../../../src/services/SagaOrchestrator';
import { DunningService } from '../../../src/services/DunningService';
import { MeteringService } from '../../../src/services/MeteringService';
import { AppError } from '../../../src/lib/errors';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { PaymentService } from '../../../src/services/PaymentService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Full coverage sweep 12 — routes jobs and branch gaps', () => {
  const app = createApp();

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('health root degraded when database raw query fails', async () => {
    jest.spyOn(database, 'getDb').mockReturnValue({
      raw: jest.fn().mockRejectedValue(new Error('db down')),
    } as never);
    const res = await request(createApp()).get('/health');
    expect(res.status).toBe(503);
    expect(res.body.database).toBe('down');
  });

  it('insights routes cover forecast query csv export and projections', async () => {
    const customer = await createCustomer();
    const plan = await createPlan();
    await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });

    expect(
      (await request(app).get('/insights/forecast?as_of=2026-06-01').set('x-api-key', API_KEY)).status
    ).toBe(200);
    expect((await request(app).get('/insights/at-risk').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/insights/cohorts').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/insights/leakage').set('x-api-key', API_KEY)).status).toBe(200);
    expect(
      (await request(app).get(`/insights/customers/${customer.id}/health`).set('x-api-key', API_KEY))
        .status
    ).toBe(200);
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    await new InvoiceService().generateForSubscription(sub, customer.country);
    const csv = await request(app)
      .get(`/insights/customers/${customer.id}/invoices/export?format=csv`)
      .set('x-api-key', API_KEY);
    expect(csv.status).toBe(200);
    expect(csv.text.length).toBeGreaterThan(0);
    expect(
      (await request(app).get('/insights/projections/subscription').set('x-api-key', API_KEY)).status
    ).toBe(200);
  });

  it('dunning policy routes list policies and default', async () => {
    const res = await request(app).get('/dunning-policies').set('x-api-key', API_KEY);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect((await request(app).get('/dunning-policies/default').set('x-api-key', API_KEY)).status).toBe(
      200
    );
  });

  it('feature flags and policy routes respond', async () => {
    expect((await request(app).get('/feature-flags').set('x-api-key', API_KEY)).status).toBe(200);
    expect(
      (
        await request(app)
          .post('/policy/quote')
          .set('x-api-key', API_KEY)
          .send({ subtotal_cents: 1000, country: 'US', usage_quantity: 0, usage_tiers: [] })
      ).status
    ).toBe(200);
  });

  it('runs analytics and billing jobs without lock mocks for positive results', async () => {
    const plan = await createPlan({ price_cents: 3000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await new PaymentService().chargeInvoice(inv.id, true, { flushOutbox: false });
    const analyticsDays = await runAnalyticsJob(new Date('2026-06-10'), 2);
    expect(analyticsDays).toBeGreaterThanOrEqual(1);
    const billed = await runBillingJob(new Date('2099-01-01'));
    expect(billed).toBeGreaterThanOrEqual(0);
  });

  it('BillingWaterfallService handles null aggregates and empty forecast history', async () => {
    const wf = new BillingWaterfallService();
    const db = getTestDb();
    const plan = await createPlan({ price_cents: 1000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await db('invoices').where({ id: inv.id }).update({
      subtotal_cents: 0,
      discount_cents: 0,
      tax_cents: 0,
      created_at: new Date('2026-06-02T12:00:00Z'),
    });

    const report = await wf.buildForPeriod('2026-06');
    expect(report.steps[0].amount_cents).toBeGreaterThanOrEqual(0);

    const emptyForecast = await wf.forecastFromHistory(0);
    expect(emptyForecast).toHaveLength(1);
    expect(emptyForecast[0].projected_cents).toBe(0);

    await db('customers').insert({
      email: `wf-cohort-${Date.now()}@t.com`,
      name: 'Cohort WF',
      country: 'US',
      created_at: new Date('2026-06-05T12:00:00Z'),
    });
    const cohort = await wf.cohortRetention(0);
    expect(cohort.some((r) => r.customers > 0)).toBe(true);
  });

  it('BillingForecastEngine trailingMrr with zero months uses empty history branch', async () => {
    const engine = new BillingForecastEngine();
    expect(await engine.trailingMrr(0)).toEqual([]);
    const scenarios = await engine.scenarios('2099-01');
    expect(scenarios[0].mrr_cents).toBe(0);
    await engine.pipelineWeightedForecast();
  });

  it('BillingAlertService object payload and spike evaluators', async () => {
    const alerts = new BillingAlertService();
    const db = getTestDb();
    const [row] = await db('billing_alerts')
      .insert({
        alert_type: 'test',
        severity: 'info',
        payload: { note: 'object' },
        acknowledged: false,
      })
      .returning('*');
    const open = await alerts.listOpen('info');
    expect(open.some((a) => a.id === row.id)).toBe(true);
    expect(open[0].payload.note).toBe('object');

    for (let i = 0; i < 6; i++) {
      await db('payments').insert({
        invoice_id: (await new InvoiceService().generateForSubscription(
          await new SubscriptionService().create({
            customer_id: (await createCustomer()).id,
            plan_id: (await createPlan()).id,
          }),
          'US'
        )).id,
        status: 'failed',
        amount_cents: 100,
        attempted_at: new Date(),
      });
    }
    const spike = await alerts.evaluatePaymentFailureSpike(5);
    expect(spike?.severity).toBe('critical');

    await db('subscriptions').insert({
      customer_id: (await createCustomer()).id,
      plan_id: (await createPlan()).id,
      status: 'past_due',
      billing_anchor: '2026-06-01',
      current_period_start: '2026-06-01',
      current_period_end: '2026-07-01',
    });
    const pastDue = await alerts.evaluatePastDueSubscriptions(1);
    expect(pastDue?.alert_type).toBe('past_due_subscriptions');
    await expect(alerts.acknowledge('00000000-0000-4000-8000-000000000099')).rejects.toMatchObject({
      statusCode: 404,
    });
  });

  it('SagaOrchestrator compensates and parses object context rows', async () => {
    const saga = new SagaOrchestrator();
    const compensated: string[] = [];
    await expect(
      saga.run('sw12_fail', [
        {
          name: 'first',
          run: async () => undefined,
          compensate: async () => {
            compensated.push('first');
          },
        },
        {
          name: 'boom',
          run: async () => {
            throw new Error('boom');
          },
        },
      ])
    ).rejects.toBeInstanceOf(AppError);
    expect(compensated).toContain('first');

    const db = getTestDb();
    await db('saga_runs').insert({
      saga_name: 'ctx-obj',
      status: 'completed',
      steps: JSON.stringify([]),
      context: { ok: true },
    });
    const recent = await saga.listRecent(5);
    expect(recent.some((r) => r.context.ok === true)).toBe(true);
  });

  it('DunningService plan override and cancel-after-retries branches', async () => {
    const dunning = new DunningService();
    const db = getTestDb();
    const plan = await createPlan();
    const [policy] = await db('dunning_policies')
      .insert({
        name: 'plan-bound',
        is_default: false,
        stages: JSON.stringify([
          { type: 'retry', delay_days: 1 },
          { type: 'cancel', delay_days: 0 },
        ]),
      })
      .returning('*');
    await db('plans').where({ id: plan.id }).update({ dunning_policy_id: policy.id });
    const resolved = await dunning.getPolicyForPlan(plan.id);
    expect(resolved.id).toBe(policy.id);

    const stages = dunning.retryDelaysFromStages(resolved.stages);
    expect(stages).toEqual([1]);
    expect(dunning.shouldCancelAfterRetries(resolved.stages, 1)).toBe(true);
    expect(dunning.shouldCancelAfterRetries(resolved.stages, 0)).toBe(false);
  });

  it('UsageAggregationService empty tier list still rates usage', async () => {
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
    });
    const db = getTestDb();
    const [meter] = await db('meters')
      .insert({
        code: 'empty-tiers',
        name: 'Empty',
        aggregation: 'sum',
        tier_config: '[]',
      })
      .returning('*');
    await db('usage_records').insert({
      meter_id: meter.id,
      subscription_id: sub.id,
      quantity: 5,
      recorded_at: new Date('2026-06-09T12:00:00Z'),
    });
    const agg = new UsageAggregationService();
    const rows = await agg.aggregateForSubscription(sub.id, '2026-06-01', '2026-06-30');
    expect(rows.find((r) => r.meter === 'empty-tiers')?.rated_cents).toBe(0);

    await new MeteringService().createMeter({
      code: 'native-obj-tier',
      name: 'Native',
      tier_config: [{ up_to: null, unit_price_cents: 4 }],
    });
    await new MeteringService().recordUsage({
      subscription_id: sub.id,
      meter_code: 'native-obj-tier',
      quantity: 8,
      recorded_at: new Date('2026-06-10T12:00:00Z'),
    });
    const mapped = await new MeteringService().getByCode('native-obj-tier');
    expect(mapped.tier_config.length).toBeGreaterThan(0);
  });

  it('app shutdown closes database when server was never started', async () => {
    const exit = jest.spyOn(process, 'exit').mockImplementation((() => undefined) as never);
    const closeSpy = jest.spyOn(database, 'closeDb').mockResolvedValue(undefined);
    shutdown('SIGTERM');
    await new Promise((r) => setTimeout(r, 50));
    expect(closeSpy).toHaveBeenCalled();
    exit.mockRestore();
  });
});
