import { BillingForecastService } from '../../../src/services/BillingForecastService';
import { CouponService } from '../../../src/services/CouponService';
import { InvoiceDocumentService } from '../../../src/services/InvoiceDocumentService';
import { WebhookReplayService } from '../../../src/services/WebhookReplayService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';

describe('Full coverage sweep 14', () => {
  it('BillingForecastService yearly MRR empty cohort and project', async () => {
    const forecast = new BillingForecastService();
    const yearlyPlan = await createPlan({ interval: 'yearly', price_cents: 120_000 });
    const customer = await createCustomer();
    await new SubscriptionService().create({ customer_id: customer.id, plan_id: yearlyPlan.id });
    const mrr = await forecast.baselineMrr('2026-06-01');
    expect(mrr).toBe(10_000);

    expect(await forecast.cohortRetention('2099-01')).toEqual([]);

    const projected = forecast.project(
      { name: 'aggressive', growth_rate_monthly: 0.1, churn_rate_monthly: 0.02, months: 2 },
      50_000
    );
    expect(projected).toHaveLength(2);
    expect(projected[1].projected_mrr_cents).toBeGreaterThan(50_000);

    const scenario = await forecast.runDefaultScenario('2026-06-01', 3);
    expect(scenario.length).toBe(3);
  });

  it('CouponService validateAndApply branches', async () => {
    const coupons = new CouponService();
    const plan = await createPlan();
    const planB = await createPlan({ name: 'Other' });
    const code = `EXP-${Date.now()}`;
    await coupons.create({
      code,
      discount_type: 'percent',
      discount_value: 10,
      expires_at: new Date('2099-01-01'),
      plan_ids: [plan.id],
    });
    const ok = await coupons.validateAndApply(code, plan.id, 10_000);
    expect(ok.discountCents).toBeGreaterThan(0);

    const limCode = `LIM-${Date.now()}`;
    await coupons.create({
      code: limCode,
      discount_type: 'fixed',
      discount_value: 100,
      usage_limit: 1,
    });
    await getTestDb()('coupons').where({ code: limCode.toUpperCase() }).update({ usage_count: 1 });
    await expect(coupons.validateAndApply(limCode, plan.id, 1000)).rejects.toMatchObject({
      statusCode: 400,
    });

    const expiredCode = `OLD-${Date.now()}`;
    await coupons.create({
      code: expiredCode,
      discount_type: 'percent',
      discount_value: 5,
      expires_at: new Date('2020-01-01'),
    });
    await expect(coupons.validateAndApply(expiredCode, plan.id, 1000)).rejects.toMatchObject({
      statusCode: 400,
    });

    const planCode = `PLAN-${Date.now()}`;
    await coupons.create({
      code: planCode,
      discount_type: 'percent',
      discount_value: 5,
      plan_ids: [plan.id],
    });
    await expect(coupons.validateAndApply(planCode, planB.id, 1000)).rejects.toMatchObject({
      statusCode: 400,
    });
  });

  it('InvoiceDocumentService and WebhookReplayService edge paths', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const doc = new InvoiceDocumentService();
    const rendered = await doc.renderText(inv.id);
    expect(rendered).toContain('INVOICE');

    const replay = new WebhookReplayService();
    await expect(replay.replayMessage('00000000-0000-4000-8000-000000000099')).rejects.toMatchObject({
      statusCode: 404,
    });
    expect(await replay.replayFailed(5)).toEqual([]);
  });
});
