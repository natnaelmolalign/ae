import { DomainEventPublisher } from '../../../src/services/DomainEventPublisher';
import { OutboxService } from '../../../src/services/OutboxService';
import { AuditService } from '../../../src/services/AuditService';
import { MeteringService } from '../../../src/services/MeteringService';
import { EntitlementService } from '../../../src/services/EntitlementService';
import { DunningService } from '../../../src/services/DunningService';
import { CreditNoteService } from '../../../src/services/CreditNoteService';
import { PaymentService } from '../../../src/services/PaymentService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { getTestDb } from '../../helpers/pgMemDb';

describe('Advanced backend features', () => {
  describe('Phase 1 — outbox & domain events', () => {
    it('persists domain event and outbox row on payment', async () => {
      const plan = await createPlan();
      const customer = await createCustomer();
      const subs = new SubscriptionService();
      const sub = await subs.create({ customer_id: customer.id, plan_id: plan.id });
      const invoice = await new InvoiceService().generateForSubscription(sub, customer.country);

      await new PaymentService().chargeInvoice(invoice.id, true, { flushOutbox: false });

      const events = await getTestDb()('domain_events');
      expect(events.length).toBeGreaterThanOrEqual(1);
      const outbox = await getTestDb()('outbox_messages');
      expect(outbox.length).toBeGreaterThanOrEqual(1);
    });

    it('processes outbox without webhook URL as success', async () => {
      const publisher = new DomainEventPublisher();
      await getTestDb().transaction(async (trx) => {
        await publisher.publish(
          {
            eventType: 'test.event',
            aggregateType: 'test',
            aggregateId: '00000000-0000-4000-8000-000000000001',
            payload: { ok: true },
          },
          trx
        );
      });
      const delivered = await new OutboxService().processPending();
      expect(delivered).toBeGreaterThanOrEqual(1);
    });
  });

  describe('Phase 2 — audit trail', () => {
    it('records audit entries linked to payments', async () => {
      const plan = await createPlan();
      const customer = await createCustomer();
      const subs = new SubscriptionService();
      const sub = await subs.create({ customer_id: customer.id, plan_id: plan.id });
      const invoice = await new InvoiceService().generateForSubscription(sub, customer.country);
      await new PaymentService().chargeInvoice(invoice.id, true, { flushOutbox: false });

      const rows = await new AuditService().listForEntity('invoice', invoice.id);
      expect(rows.some((r) => r.action === 'paid')).toBe(true);
    });
  });

  describe('Phase 3 — metering', () => {
    it('rates tiered usage', async () => {
      const metering = new MeteringService();
      await metering.createMeter({
        code: 'api_calls',
        name: 'API Calls',
        tier_config: [
          { up_to: 1000, unit_price_cents: 1 },
          { up_to: null, unit_price_cents: 0.5 },
        ],
      });

      const plan = await createPlan();
      const customer = await createCustomer();
      const sub = await new SubscriptionService().create({
        customer_id: customer.id,
        plan_id: plan.id,
      });

      await metering.recordUsage({
        meter_code: 'api_calls',
        subscription_id: sub.id,
        quantity: 1500,
        idempotency_key: 'u1',
      });

      const rated = await metering.ratedChargeForPeriod(
        sub.id,
        'api_calls',
        new Date('2020-01-01'),
        new Date('2030-01-01')
      );
      expect(rated.quantity).toBe(1500);
      expect(rated.amount_cents).toBe(1250);
    });
  });

  describe('Phase 4 — entitlements', () => {
    it('evaluates plan entitlements for subscription', async () => {
      const plan = await createPlan();
      await new EntitlementService().upsertForPlan(plan.id, [
        { feature_key: 'exports', limit_type: 'boolean' },
        { feature_key: 'seats', limit_type: 'count', limit_value: 5 },
      ]);

      const customer = await createCustomer();
      const sub = await new SubscriptionService().create({
        customer_id: customer.id,
        plan_id: plan.id,
      });

      const exports = await new EntitlementService().check(sub.id, 'exports');
      expect(exports.allowed).toBe(true);

      const missing = await new EntitlementService().check(sub.id, 'unknown');
      expect(missing.allowed).toBe(false);
    });
  });

  describe('Phase 5 — dunning', () => {
    it('seeds default policy with retry stages', async () => {
      const policy = await new DunningService().getDefaultPolicy();
      expect(policy.stages.filter((s) => s.type === 'retry').length).toBe(3);
    });
  });

  describe('Phase 6 — credit notes', () => {
    it('issues credit note and increases customer balance', async () => {
      const plan = await createPlan();
      const customer = await createCustomer();
      const subs = new SubscriptionService();
      const sub = await subs.create({ customer_id: customer.id, plan_id: plan.id });
      const invoice = await new InvoiceService().generateForSubscription(sub, customer.country);
      await new PaymentService().chargeInvoice(invoice.id, true, { flushOutbox: false });

      const note = await new CreditNoteService().issue({
        invoice_id: invoice.id,
        amount_cents: 100,
        reason: 'Goodwill adjustment',
      });

      expect(note.amount_cents).toBe(100);
      const updated = await getTestDb()('customers').where({ id: customer.id }).first();
      expect(Number(updated?.credit_balance_cents)).toBeGreaterThanOrEqual(100);
    });
  });
});
