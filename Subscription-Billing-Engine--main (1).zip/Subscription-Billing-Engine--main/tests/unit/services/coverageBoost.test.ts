import request from 'supertest';
import { createApp } from '../../../src/app';
import { InvoiceExportService } from '../../../src/services/InvoiceExportService';
import { BillingReconciliationService } from '../../../src/services/BillingReconciliationService';
import { TaxComplianceReportService } from '../../../src/services/TaxComplianceReportService';
import { CustomerLifecycleAnalyticsService } from '../../../src/services/CustomerLifecycleAnalyticsService';
import { BillingScheduleService } from '../../../src/services/BillingScheduleService';
import { CohortAnalysisService } from '../../../src/services/CohortAnalysisService';
import { MaintenanceWindowService } from '../../../src/services/operations/MaintenanceWindowService';
import { BillingOperationsPlaybookService } from '../../../src/services/BillingOperationsPlaybookService';
import { OutboxService } from '../../../src/services/OutboxService';
import { WebhookReplayService } from '../../../src/services/WebhookReplayService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { PaymentService } from '../../../src/services/PaymentService';
import { getTestDb } from '../../helpers/pgMemDb';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Coverage boost', () => {
  const app = createApp();

  it('invoice export all formats', async () => {
    const customer = await createCustomer();
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const svc = new InvoiceExportService();
    const csv = await svc.exportCustomerInvoices(customer.id, 'csv');
    expect(csv).toContain('id');
    const period = await svc.exportPeriod('2020-01-01', '2030-12-31', 'json');
    expect(period).toContain('[');
    const emptyCsv = await svc.exportPeriod('2099-01-01', '2099-01-02', 'csv');
    expect(emptyCsv).toBe('');
    const detail = await svc.exportInvoiceDetail(inv.id);
    expect(detail.invoice).toBeDefined();
    await expect(svc.exportInvoiceDetail('00000000-0000-4000-8000-000000000099')).rejects.toBeDefined();
  });

  it('billing reconciliation and schedules', async () => {
    const report = await new BillingReconciliationService().reconcileOpenInvoices();
    expect(report.invoice_count).toBeGreaterThanOrEqual(0);
    const customer = await createCustomer();
    const sched = await new BillingScheduleService().create({
      customer_id: customer.id,
      name: 'custom',
      cadence: 'monthly',
      anchor_day: 15,
      line_templates: [{ description: 'Fee', amount_cents: 500, quantity: 1 }],
    });
    const listed = await new BillingScheduleService().listForCustomer(customer.id);
    expect(listed.length).toBeGreaterThan(0);
    await new BillingScheduleService().deactivate(sched.id);
  });

  it('tax compliance extended', async () => {
    const svc = new TaxComplianceReportService();
    const pack = await svc.buildPack('2026-06');
    await svc.nexusReport('2026-06');
    await svc.euVatSummary('2026-06');
    await svc.usStateBreakdown('2026-06');
    await svc.estimatedLiability('2026-06');
    await svc.comparePeriods('2026-05', '2026-06');
    await svc.quarterlyRollup(2026, 2);
    await svc.filingChecklist('2026-06');
    await svc.remittanceSchedule(2026);
    await svc.documentRetentionPolicy();
    expect(pack.jurisdictions).toBeDefined();
  });

  it('lifecycle and cohorts', async () => {
    const lifecycle = new CustomerLifecycleAnalyticsService();
    await lifecycle.stageDistribution();
    await lifecycle.transitionsLastDays(90);
    await lifecycle.expansionSignals(5);
    await lifecycle.trialConversionRate();
    await lifecycle.averageRevenuePerCustomer();
    await lifecycle.customersAtRisk();
    const cohorts = new CohortAnalysisService();
    const matrix = await cohorts.buildRetentionMatrix(3, 2);
    expect(Array.isArray(matrix)).toBe(true);
    expect(await cohorts.averageRetentionByOffset(0)).toBeGreaterThanOrEqual(0);
  });

  it('maintenance playbook and outbox', async () => {
    const maint = new MaintenanceWindowService();
    const win = await maint.schedule(
      new Date(),
      new Date(Date.now() + 60000),
      'test'
    );
    expect(await maint.isActive()).toBe(true);
    expect(await maint.activeWindow()).toBeTruthy();
    await maint.listUpcoming();
    const playbook = new BillingOperationsPlaybookService();
    await playbook.validateSystemHealth('2026-06');
    await playbook.documentPlaybook('incident_response');
    const processed = await new OutboxService().processPending(1);
    expect(processed).toBeGreaterThanOrEqual(0);
    expect(win.id).toBeDefined();
  });

  it('route sweep for new analytics APIs', async () => {
    const wf = await request(app).get('/waterfall/compare/2026-05/2026-06').set('x-api-key', API_KEY);
    expect(wf.status).toBe(200);
    const aging = await request(app).get('/waterfall/aging/buckets').set('x-api-key', API_KEY);
    expect(aging.status).toBe(200);
    const recon = await request(app)
      .get('/reconciliation/period/2026-06/summary')
      .set('x-api-key', API_KEY);
    expect(recon.status).toBe(200);
    const board = await request(app).get('/analytics-board/2026-06/health').set('x-api-key', API_KEY);
    expect(board.status).toBe(200);
    const tax = await request(app).get('/tax-compliance/2026-06/nexus').set('x-api-key', API_KEY);
    expect(tax.status).toBe(200);
    const snap = await request(app)
      .get('/snapshots/compare/mrr/2026-05/2026-06')
      .set('x-api-key', API_KEY);
    expect([200, 404]).toContain(snap.status);
  });

  it('webhook replay failed batch', async () => {
    const [ev] = await getTestDb()('domain_events')
      .insert({
        event_type: 'test.batch',
        aggregate_type: 'invoice',
        aggregate_id: '00000000-0000-4000-8000-000000000002',
        payload: JSON.stringify({}),
      })
      .returning('*');
    await getTestDb()('outbox_messages').insert({
      domain_event_id: ev.id,
      status: 'failed',
      attempt_count: 5,
    });
    const results = await new WebhookReplayService().replayFailed(5);
    expect(results.length).toBeGreaterThan(0);
  });
});
