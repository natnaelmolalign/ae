import { InvoiceDocumentService } from '../../../src/services/InvoiceDocumentService';
import { BillingAlertService } from '../../../src/services/BillingAlertService';
import { AnalyticsRollupService } from '../../../src/services/AnalyticsRollupService';
import { OutboxService } from '../../../src/services/OutboxService';
import { BillingWaterfallService } from '../../../src/services/BillingWaterfallService';
import { CustomerLifecycleAnalyticsService } from '../../../src/services/CustomerLifecycleAnalyticsService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { getTestDb } from '../../helpers/pgMemDb';

describe('Service branch boost', () => {
  it('invoice documents handle missing rows batch render and unknown jurisdiction', async () => {
    const docs = new InvoiceDocumentService();
    await expect(docs.build('00000000-0000-4000-8000-000000000099')).rejects.toMatchObject({
      statusCode: 404,
    });

    const plan = await createPlan();
    const customer = await createCustomer({ country: 'ZZ' });
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const built = await docs.build(inv.id);
    expect(built.jurisdiction).toBe('ZZ');

    const inv2 = await new InvoiceService().generateForSubscription(sub, customer.country);
    const batch = await docs.renderBatch([inv.id, inv2.id]);
    expect(batch).toHaveLength(2);
    expect(batch[0]).toContain('INVOICE');
  });

  it('billing alerts raise on spikes past due and 404 acknowledge', async () => {
    const alerts = new BillingAlertService();
    expect(await alerts.evaluatePaymentFailureSpike(999)).toBeNull();
    expect(await alerts.evaluatePastDueSubscriptions(999)).toBeNull();

    const db = getTestDb();
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    for (let i = 0; i < 5; i++) {
      await db('payments').insert({
        invoice_id: inv.id,
        status: 'failed',
        amount_cents: 100,
        attempted_at: new Date(),
      });
    }
    const spike = await alerts.evaluatePaymentFailureSpike(5);
    expect(spike?.alert_type).toBe('payment_failure_spike');

    await db('subscriptions').where({ id: sub.id }).update({ status: 'past_due' });
    const sub3 = await new SubscriptionService().create({
      customer_id: (await createCustomer()).id,
      plan_id: plan.id,
    });
    await db('subscriptions').where({ id: sub3.id }).update({ status: 'past_due' });
    const pastDue = await alerts.evaluatePastDueSubscriptions(2);
    expect(pastDue?.alert_type).toBe('past_due_subscriptions');

    const manual = await alerts.raise('manual_check', 'warning', { ok: true });
    const acked = await alerts.acknowledge(manual.id);
    expect(acked.acknowledged).toBe(true);
    expect((await alerts.listOpen()).every((a) => a.id !== manual.id)).toBe(true);
    await expect(
      alerts.acknowledge('00000000-0000-4000-8000-000000000099')
    ).rejects.toMatchObject({ statusCode: 404 });
  });

  it('analytics rollup yearly addons and update path', async () => {
    const yearly = await createPlan({ interval: 'yearly', price_cents: 12000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: yearly.id,
    });
    await getTestDb()('subscription_items').insert({
      subscription_id: sub.id,
      item_type: 'addon',
      description: 'Extra seats',
      quantity: 2,
      unit_price_cents: 500,
      active: true,
    });
    const rollup = new AnalyticsRollupService();
    const day = new Date('2026-06-01T12:00:00Z');
    const first = await rollup.rollupDay(day);
    expect(first.mrr_cents).toBeGreaterThan(1000);
    const second = await rollup.rollupDay(day);
    expect(second.stat_date).toBe(first.stat_date);
    expect(await rollup.getDaily('2026-06-01')).not.toBeNull();
    expect((await rollup.rollupRange(day, 2))).toBe(2);
  });

  it('outbox skips non-webhook channels', async () => {
    const [ev] = await getTestDb()('domain_events')
      .insert({
        event_type: 'test.email',
        aggregate_type: 'invoice',
        aggregate_id: '00000000-0000-4000-8000-000000000001',
        payload: JSON.stringify({ ok: true }),
      })
      .returning('*');
    const [msg] = await getTestDb()('outbox_messages')
      .insert({
        domain_event_id: ev.id,
        status: 'pending',
        channel: 'email',
      })
      .returning('*');
    const outbox = new OutboxService();
    expect(await outbox.processPending(5)).toBe(0);
    expect(await outbox.deliverOne(msg.id as string)).toBe(false);
  });

  it('waterfall rejects invalid period and cohort with customers', async () => {
    const wf = new BillingWaterfallService();
    await expect(wf.buildForPeriod('bad')).rejects.toMatchObject({ statusCode: 400 });
    const customer = await createCustomer();
    await getTestDb()('customers').where({ id: customer.id }).update({
      created_at: new Date(),
    });
    const cohorts = await wf.cohortRetention(1);
    expect(cohorts.some((c) => c.customers > 0)).toBe(true);
  });

  it('lifecycle maps statuses transitions and expansion signals', async () => {
    const lc = new CustomerLifecycleAnalyticsService();
    const plan = await createPlan({ price_cents: 6000 });
    const c1 = await createCustomer();
    const c2 = await createCustomer();
    const active = await new SubscriptionService().create({
      customer_id: c1.id,
      plan_id: plan.id,
    });
    const trial = await new SubscriptionService().create({
      customer_id: c1.id,
      plan_id: plan.id,
      trial_days: 14,
    });
    await getTestDb()('subscriptions').where({ id: trial.id }).update({ status: 'past_due' });
    const cancelled = await new SubscriptionService().create({
      customer_id: c2.id,
      plan_id: plan.id,
    });
    await getTestDb()('subscriptions').where({ id: cancelled.id }).update({ status: 'cancelled' });
    expect(active.status).toBe('active');

    const stages = await lc.stageDistribution();
    expect(stages.some((s) => s.stage === 'at_risk')).toBe(true);
    expect(stages.some((s) => s.stage === 'churned')).toBe(true);

    await getTestDb()('audit_log').insert({
      action: 'status_changed',
      entity_type: 'subscription',
      entity_id: trial.id,
      before_state: JSON.stringify({ status: 'trial' }),
      after_state: JSON.stringify({ status: 'active' }),
      recorded_at: new Date(),
    });
    const transitions = await lc.transitionsLastDays(30);
    expect(transitions.some((t) => t.from_status === 'trial')).toBe(true);

    const signals = await lc.expansionSignals(5);
    expect(signals.length).toBeGreaterThan(0);
    expect(signals[0].signal).not.toBe('');

    const trialRate = await lc.trialConversionRate();
    expect(trialRate.rate).toBeGreaterThanOrEqual(0);
    expect(await lc.averageRevenuePerCustomer()).toBeGreaterThan(0);
    const atRisk = await lc.customersAtRisk();
    expect(atRisk.length).toBeGreaterThan(0);
    expect((await lc.exportLifecycleCsv()).startsWith('stage')).toBe(true);
  });
});
