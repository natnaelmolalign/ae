import request from 'supertest';
import { createApp } from '../../../src/app';
import { TaxComplianceReportService } from '../../../src/services/TaxComplianceReportService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('TaxComplianceReportService', () => {
  const app = createApp();
  const svc = new TaxComplianceReportService();

  it('builds compliance pack', async () => {
    const plan = await createPlan({ price_cents: 2000 });
    const customer = await createCustomer({ country: 'DE' });
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const pack = await svc.buildPack('2026-06');
    expect(pack.period_key).toBe('2026-06');
    const validation = await svc.validateInvoiceTax(inv.id);
    expect(validation).toHaveProperty('valid');
    const api = await request(app).get('/tax-compliance/2026-06').set('x-api-key', API_KEY);
    expect(api.status).toBe(200);
    const eu = await svc.euVatSummary('2026-06');
    expect(eu).toHaveProperty('tax_cents');
  });
});
