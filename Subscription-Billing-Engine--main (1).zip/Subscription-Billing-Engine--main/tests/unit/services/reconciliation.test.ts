import request from 'supertest';
import { createApp } from '../../../src/app';
import { InvoiceReconciliationService } from '../../../src/services/InvoiceReconciliationService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { PaymentService } from '../../../src/services/PaymentService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('InvoiceReconciliationService', () => {
  const app = createApp();
  const svc = new InvoiceReconciliationService();

  it('runs period reconciliation after paid invoice', async () => {
    const plan = await createPlan({ price_cents: 4000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await new PaymentService().chargeInvoice(inv.id, true);
    const key = `${new Date().getUTCFullYear()}-${String(new Date().getUTCMonth() + 1).padStart(2, '0')}`;
    const run = await svc.runForPeriod(key);
    expect(run.invoices_checked).toBeGreaterThan(0);
    const summary = await svc.summaryByStatus(key);
    expect(summary.length).toBeGreaterThan(0);
    const api = await request(app).get(`/reconciliation/period/${key}`).set('x-api-key', API_KEY);
    expect(api.status).toBe(200);
    const dupes = await svc.duplicateLineDetection(inv.id);
    expect(Array.isArray(dupes)).toBe(true);
    const csv = await svc.exportReport(key);
    expect(csv).toContain('checked');
  });
});
