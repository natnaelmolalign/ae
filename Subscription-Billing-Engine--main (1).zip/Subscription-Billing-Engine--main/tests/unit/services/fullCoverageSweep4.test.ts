import request from 'supertest';
import { createApp } from '../../../src/app';
import { BillingSnapshotService } from '../../../src/services/BillingSnapshotService';
import { PaymentService } from '../../../src/services/PaymentService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { getTestDb } from '../../helpers/pgMemDb';
import { MeteringService } from '../../../src/services/MeteringService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Full coverage sweep 4', () => {
  it('billing snapshots cover all metric types and period formats', async () => {
    const snap = new BillingSnapshotService();
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    await snap.capture({ snapshot_type: 'mrr', period_key: '2026-06' });
    await snap.capture({ snapshot_type: 'arr', period_key: '2026-06' });
    await snap.capture({
      snapshot_type: 'mrr',
      period_key: '2026-06',
      customer_id: customer.id,
    });
    const meter = await new MeteringService().createMeter({
      code: `snap-${Date.now()}`,
      name: 'Snap',
      tier_config: [{ up_to: null, unit_price_cents: 2 }],
    });
    await new MeteringService().recordUsage({
      subscription_id: sub.id,
      meter_code: meter.code,
      quantity: 5,
      recorded_at: new Date('2026-06-05T12:00:00Z'),
    });
    await snap.capture({ snapshot_type: 'usage', period_key: '2026-06' });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await new PaymentService().chargeInvoice(inv.id, true, { flushOutbox: false });
    await snap.capture({ snapshot_type: 'collections', period_key: '2026-06' });
    await snap.capture({ snapshot_type: 'mrr', period_key: '2026-06-05' });
    await snap.capture({ snapshot_type: 'mrr', period_key: '2026-06' });
    await snap.capture({ snapshot_type: 'mrr', period_key: '2026-05' });
    await snap.list('2026-06', 'mrr', 10);
    const cmp = await snap.comparePeriods('mrr', '2026-05', '2026-06');
    expect(cmp.delta).toBeDefined();
    await snap.rollupArr('2026-06');
    await expect(snap.get('mrr', '2099-01', null)).rejects.toMatchObject({ statusCode: 404 });
    await expect(snap.capture({ snapshot_type: 'mrr', period_key: 'bad' })).rejects.toMatchObject({
      statusCode: 400,
    });
  });

  it('payment service covers charge guards idempotency and refund errors', async () => {
    const pay = new PaymentService();
    const plan = await createPlan();

    const idemCustomer = await createCustomer();
    const idemSub = await new SubscriptionService().create({
      customer_id: idemCustomer.id,
      plan_id: plan.id,
    });
    const idemInv = await new InvoiceService().generateForSubscription(idemSub, idemCustomer.country);
    const key = `idem-${Date.now()}`;
    const p1 = await pay.chargeInvoice(idemInv.id, true, {
      idempotencyKey: key,
      flushOutbox: false,
    });
    const p2 = await pay.chargeInvoice(idemInv.id, true, {
      idempotencyKey: key,
      flushOutbox: false,
    });
    expect(p2.id).toBe(p1.id);

    const voidCustomer = await createCustomer();
    const voidSub = await new SubscriptionService().create({
      customer_id: voidCustomer.id,
      plan_id: plan.id,
    });
    const voidInv = await new InvoiceService().generateForSubscription(voidSub, voidCustomer.country);
    await new InvoiceService().voidInvoice(voidInv.id);
    await expect(pay.chargeInvoice(voidInv.id, true, { flushOutbox: false })).rejects.toMatchObject({
      statusCode: 400,
    });

    const paidCustomer = await createCustomer();
    const paidSub = await new SubscriptionService().create({
      customer_id: paidCustomer.id,
      plan_id: plan.id,
    });
    const paidInv = await new InvoiceService().generateForSubscription(paidSub, paidCustomer.country);
    await pay.chargeInvoice(paidInv.id, true, { flushOutbox: false });
    await expect(pay.chargeInvoice(paidInv.id, true, { flushOutbox: false })).rejects.toMatchObject({
      statusCode: 400,
    });

    const pastCustomer = await createCustomer();
    const pastSub = await new SubscriptionService().create({
      customer_id: pastCustomer.id,
      plan_id: plan.id,
    });
    await getTestDb()('subscriptions').where({ id: pastSub.id }).update({ status: 'past_due' });
    const pastInv = await new InvoiceService().generateForSubscription(pastSub, pastCustomer.country);
    await pay.chargeInvoice(pastInv.id, true, { flushOutbox: false });
    expect((await getTestDb()('subscriptions').where({ id: pastSub.id }).first())?.status).toBe('active');

    const failCustomer = await createCustomer();
    const failSub = await new SubscriptionService().create({
      customer_id: failCustomer.id,
      plan_id: plan.id,
    });
    const failInv = await new InvoiceService().generateForSubscription(failSub, failCustomer.country);
    await pay.chargeInvoice(failInv.id, false, { scheduleRetries: false, flushOutbox: false });

    await expect(
      pay.refundPayment('00000000-0000-4000-8000-000000000099', 100)
    ).rejects.toMatchObject({ statusCode: 404 });
    const failedPay = await getTestDb()('payments').where({ invoice_id: failInv.id }).first();
    await expect(pay.refundPayment(failedPay.id as string, 50)).rejects.toMatchObject({
      statusCode: 400,
    });
  });

  it('dunning policies route parses string stages JSON', async () => {
    await getTestDb()('dunning_policies').insert({
      name: 'string-stages',
      is_default: false,
      stages: JSON.stringify([{ type: 'retry', delay_days: 2 }]),
    });
    const app = createApp();
    const list = await request(app).get('/dunning-policies').set('x-api-key', API_KEY);
    expect(list.status).toBe(200);
    expect(list.body.some((p: { name: string }) => p.name === 'string-stages')).toBe(true);
    expect((await request(app).get('/dunning-policies/default').set('x-api-key', API_KEY)).status).toBe(200);
  });
});
