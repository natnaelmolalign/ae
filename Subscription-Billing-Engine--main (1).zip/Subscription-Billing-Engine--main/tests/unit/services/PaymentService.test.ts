import { PaymentService } from '../../../src/services/PaymentService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';

describe('PaymentService', () => {
  const payments = new PaymentService();
  const subs = new SubscriptionService();
  const invoices = new InvoiceService();

  it('marks subscription past_due on first failed charge', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await subs.create({ customer_id: customer.id, plan_id: plan.id });
    const invoice = await invoices.generateForSubscription(sub, customer.country);

    await payments.chargeInvoice(invoice.id, false, { scheduleRetries: false });
    const updated = await subs.getById(sub.id);
    expect(updated.status).toBe('past_due');
    expect(Number(updated.failed_payment_count)).toBe(1);
  });

  it('returns same payment for duplicate idempotency key', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await subs.create({ customer_id: customer.id, plan_id: plan.id });
    const invoice = await invoices.generateForSubscription(sub, customer.country);

    const p1 = await payments.chargeInvoice(invoice.id, true, { idempotencyKey: 'key-1' });
    const p2 = await payments.chargeInvoice(invoice.id, true, { idempotencyKey: 'key-1' });
    expect(p2.id).toBe(p1.id);
  });
});
