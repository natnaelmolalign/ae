import request from 'supertest';
import { createApp } from '../../../src/app';
import { BillingWaterfallService } from '../../../src/services/BillingWaterfallService';
import { WebhookReplayService } from '../../../src/services/WebhookReplayService';
import { SubscriptionMigrationService } from '../../../src/services/SubscriptionMigrationService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { getTestDb } from '../../helpers/pgMemDb';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Waterfall and replay coverage', () => {
  const app = createApp();
  const waterfall = new BillingWaterfallService();

  it('builds waterfall report via API', async () => {
    const res = await request(app).get('/waterfall/2026-06').set('x-api-key', API_KEY);
    expect(res.status).toBe(200);
    expect(res.body.steps.length).toBeGreaterThan(0);
  });

  it('cohorts aging forecast and csv', async () => {
    const cohorts = await waterfall.cohortRetention(2);
    expect(Array.isArray(cohorts)).toBe(true);
    const aging = await waterfall.agingBuckets();
    expect(aging.length).toBe(4);
    const forecast = await waterfall.forecastFromHistory(2);
    expect(forecast.length).toBeGreaterThan(0);
    const csv = await waterfall.exportCsv('2026-06');
    expect(csv).toContain('label');
    const cmp = await waterfall.compareWaterfalls('2026-05', '2026-06');
    expect(cmp).toHaveProperty('delta_cents');
  });

  it('webhook replay logs failures', async () => {
    const [ev] = await getTestDb()('domain_events')
      .insert({
        event_type: 'invoice.paid',
        aggregate_type: 'invoice',
        aggregate_id: '00000000-0000-4000-8000-000000000001',
        payload: JSON.stringify({ id: 'x' }),
      })
      .returning('*');
    const [msg] = await getTestDb()('outbox_messages')
      .insert({
        domain_event_id: ev.id,
        status: 'failed',
        attempt_count: 3,
      })
      .returning('*');
    const replay = new WebhookReplayService();
    const result = await replay.replayMessage(msg.id as string);
    expect(['delivered', 'failed']).toContain(result.status);
    const log = await replay.listReplayLog(5);
    expect(log.length).toBeGreaterThan(0);
    await expect(replay.replayMessage('00000000-0000-4000-8000-000000000099')).rejects.toBeDefined();
  });

  it('subscription migration preview and eligible', async () => {
    const planA = await createPlan({ price_cents: 1000, name: 'A' });
    const planB = await createPlan({ price_cents: 2000, name: 'B' });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: planA.id });
    const mig = new SubscriptionMigrationService();
    const preview = await mig.preview(sub.id, planB.id, sub.current_period_start);
    expect(preview.to_plan_id).toBe(planB.id);
    await expect(mig.execute(sub.id, planB.id, sub.current_period_start)).resolves.toMatchObject({
      subscription_id: sub.id,
      new_plan_id: planB.id,
    });
  });
});
