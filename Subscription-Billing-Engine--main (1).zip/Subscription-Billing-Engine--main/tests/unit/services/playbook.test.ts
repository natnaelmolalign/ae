import { BillingOperationsPlaybookService } from '../../../src/services/BillingOperationsPlaybookService';

describe('BillingOperationsPlaybookService', () => {
  const svc = new BillingOperationsPlaybookService();

  it('runs month-end and incident playbooks', async () => {
    const close = await svc.runMonthEndClose('2026-06');
    expect(close.steps_completed).toBeGreaterThan(0);
    const incident = await svc.runIncidentResponse();
    expect(incident.playbook).toBe('incident_response');
    const forecast = await svc.forecastRefreshPlaybook();
    expect(forecast.notes.length).toBeGreaterThan(0);
    const doc = await svc.documentPlaybook('month_end_close');
    expect(doc.steps.length).toBe(6);
  });
});
