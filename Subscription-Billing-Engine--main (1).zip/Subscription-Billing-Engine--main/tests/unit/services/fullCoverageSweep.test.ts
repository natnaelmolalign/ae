import { WebhookService } from '../../../src/services/WebhookService';
import { OutboxService } from '../../../src/services/OutboxService';
import { InvoiceReconciliationService } from '../../../src/services/InvoiceReconciliationService';
import { InvoiceDocumentService } from '../../../src/services/InvoiceDocumentService';
import { RateLimitPolicyService } from '../../../src/services/RateLimitPolicyService';
import { BillingAnalyticsFacade } from '../../../src/services/BillingAnalyticsFacade';
import { ContractService } from '../../../src/services/ContractService';
import { TaxComplianceReportService } from '../../../src/services/TaxComplianceReportService';
import { CohortAnalysisService } from '../../../src/services/CohortAnalysisService';
import { NotificationService } from '../../../src/services/NotificationService';
import { TaxCalculationService } from '../../../src/services/TaxCalculationService';
import { JobLockService } from '../../../src/services/JobLockService';
import { getDb } from '../../../src/config/database';
import { resetEnvForTests } from '../../../src/config/env';
import {
  MinimumCommitmentCalculator,
  defaultCommitmentTiers,
} from '../../../src/domain/billing/MinimumCommitmentCalculator';
import { SagaOrchestrator } from '../../../src/services/SagaOrchestrator';
import { WorkflowEngine } from '../../../src/services/WorkflowEngine';
import { FeatureFlagService } from '../../../src/services/FeatureFlagService';
import { PaymentService } from '../../../src/services/PaymentService';
import { PrincipalService } from '../../../src/services/RbacService';
import { globalMetrics } from '../../../src/lib/metrics';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { getTestDb } from '../../helpers/pgMemDb';

describe('Full coverage sweep', () => {
  describe('OutboxService', () => {
    const prevWebhookUrl = process.env.WEBHOOK_URL;

    afterEach(() => {
      process.env.WEBHOOK_URL = prevWebhookUrl;
      resetEnvForTests();
    });

    it('marks webhook delivery failed at max attempts with mocked deliverPending', async () => {
      process.env.WEBHOOK_URL = 'http://test';
      resetEnvForTests();
      const mockWebhook = {
        enqueue: jest.fn().mockResolvedValue(undefined),
        deliverPending: jest.fn().mockResolvedValue(0),
      } as unknown as WebhookService;

      const [ev] = await getTestDb()('domain_events')
        .insert({
          event_type: 'invoice.paid',
          aggregate_type: 'invoice',
          aggregate_id: '00000000-0000-4000-8000-000000000001',
          payload: JSON.stringify({ ok: true }),
        })
        .returning('*');
      const [msg] = await getTestDb()('outbox_messages')
        .insert({
          domain_event_id: ev.id,
          status: 'pending',
          channel: 'webhook',
          attempt_count: 7,
        })
        .returning('*');

      const outbox = new OutboxService(mockWebhook);
      expect(await outbox.deliverOne(msg.id as string)).toBe(false);
      const row = await getTestDb()('outbox_messages').where({ id: msg.id }).first();
      expect(row?.status).toBe('failed');
      expect(Number(row?.attempt_count)).toBe(8);
    });

    it('skips non-webhook channel in processPending', async () => {
      const [ev] = await getTestDb()('domain_events')
        .insert({
          event_type: 'notify.email',
          aggregate_type: 'customer',
          aggregate_id: '00000000-0000-4000-8000-000000000002',
          payload: JSON.stringify({}),
        })
        .returning('*');
      await getTestDb()('outbox_messages').insert({
        domain_event_id: ev.id,
        status: 'pending',
        channel: 'email',
      });
      expect(await new OutboxService().processPending(10)).toBe(0);
    });
  });

  describe('InvoiceReconciliationService', () => {
    const recon = new InvoiceReconciliationService();

    it('rejects invalid period and missing invoice', async () => {
      await expect(recon.runForPeriod('2026/06')).rejects.toMatchObject({ statusCode: 400 });
      await expect(
        recon.reconcileInvoice('00000000-0000-4000-8000-000000000099')
      ).rejects.toMatchObject({ statusCode: 404 });
    });

    it('detects subtotal total and payment mismatches', async () => {
      const customer = await createCustomer();
      const plan = await createPlan();
      const sub = await new SubscriptionService().create({
        customer_id: customer.id,
        plan_id: plan.id,
      });
      const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
      const db = getTestDb();
      await db('invoices').where({ id: inv.id }).update({
        subtotal_cents: 5000,
        total_cents: 9999,
        tax_cents: 0,
        discount_cents: 0,
        status: 'paid',
        created_at: new Date('2026-06-10T12:00:00Z'),
      });
      await db('invoice_line_items').where({ invoice_id: inv.id }).update({ amount_cents: 100 });
      await db('payments').insert({
        invoice_id: inv.id,
        status: 'succeeded',
        amount_cents: 1,
        attempted_at: new Date('2026-06-10T12:00:00Z'),
      });

      const run = await recon.runForPeriod('2026-06');
      const fields = run.mismatches.map((m) => m.field);
      expect(fields).toContain('subtotal_cents');
      expect(fields).toContain('total_cents');
      expect(fields).toContain('payments');
      expect(run.balanced).toBe(false);
      await recon.unappliedPayments('2026-06');
      await recon.exportReport('2026-06');
    });
  });

  describe('InvoiceDocumentService', () => {
    it('returns 404 for unknown invoice', async () => {
      await expect(
        new InvoiceDocumentService().build('00000000-0000-4000-8000-000000000099')
      ).rejects.toMatchObject({ statusCode: 404 });
    });
  });

  describe('RateLimitPolicyService', () => {
    it('covers default insert update clear and validation', async () => {
      const principals = await new PrincipalService().list();
      const principalId = principals[0]?.id as string;
      const svc = new RateLimitPolicyService();

      expect(await svc.getForPrincipal(principalId)).toBe(120);
      await svc.setOverride(principalId, 250);
      expect(await svc.getForPrincipal(principalId)).toBe(250);
      await svc.setOverride(principalId, 300);
      const overrides = await svc.listOverrides();
      expect(overrides.some((o) => o.principal_id === principalId)).toBe(true);
      await expect(svc.setOverride(principalId, 5)).rejects.toMatchObject({ statusCode: 400 });
      await svc.clearOverride(principalId);
      expect(await svc.getForPrincipal(principalId)).toBe(120);
    });
  });

  describe('BillingAnalyticsFacade', () => {
    it('exercises dashboard drill-down MoM health and exports', async () => {
      const plan = await createPlan({ price_cents: 5000 });
      const customer = await createCustomer();
      await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
      const facade = new BillingAnalyticsFacade();

      await facade.executiveDashboard('2026-06');
      await facade.drillDown('2026-06', 3);
      await facade.monthOverMonth('2026-01');
      const health = await facade.healthScore('2026-06');
      expect(health.score).toBeGreaterThanOrEqual(0);
      const pack = await facade.exportBoardPack('2026-06');
      expect(pack.mom.current.period_key).toBe('2026-06');
      await facade.cohortSummary();
      const aging = await facade.agingAndForecast();
      expect(aging.aging).toBeDefined();
      expect(aging.forecast).toBeDefined();
    });
  });

  describe('ContractService', () => {
    it('covers create activate amend list expire and error branches', async () => {
      const customer = await createCustomer();
      const svc = new ContractService();
      const ref = `SWEEP-${Date.now()}`;
      const draft = await svc.create({
        customer_id: customer.id,
        reference: ref,
        effective_from: '2026-06-01',
        committed_mrr_cents: 40_000,
        terms: { tier: 'growth' },
      });
      await expect(
        svc.create({
          customer_id: customer.id,
          reference: ref,
          effective_from: '2026-06-01',
        })
      ).rejects.toMatchObject({ statusCode: 409 });

      const active = await svc.activate(draft.id);
      expect(active.status).toBe('active');
      await expect(svc.activate(active.id)).rejects.toMatchObject({ statusCode: 400 });

      const amended = await svc.amend(active.id, 'uplift', { committed_mrr_cents: 55_000, note: 'uplift' });
      expect(amended.committed_mrr_cents).toBe(55_000);
      expect(amended.status).toBe('amended');

      const listed = await svc.listForCustomer(customer.id);
      expect(listed.length).toBeGreaterThan(0);

      await expect(svc.getById('00000000-0000-4000-8000-000000000099')).rejects.toMatchObject({
        statusCode: 404,
      });
      const draftOnly = await svc.create({
        customer_id: customer.id,
        reference: `${ref}-draft`,
        effective_from: '2026-06-01',
      });
      await expect(svc.amend(draftOnly.id, 'x', {})).rejects.toMatchObject({ statusCode: 400 });

      const expired = await svc.expire(amended.id);
      expect(expired.status).toBe('expired');
      await expect(svc.expire('00000000-0000-4000-8000-000000000099')).rejects.toMatchObject({
        statusCode: 404,
      });
    });
  });

  describe('TaxComplianceReportService', () => {
    it('runs compliance helpers and EU exempt path', async () => {
      const svc = new TaxComplianceReportService();
      const plan = await createPlan({ price_cents: 3000 });
      const euCustomer = await createCustomer({ country: 'DE' });
      const sub = await new SubscriptionService().create({
        customer_id: euCustomer.id,
        plan_id: plan.id,
      });
      const inv = await new InvoiceService().generateForSubscription(sub, euCustomer.country);
      await getTestDb()('invoices').where({ id: inv.id }).update({
        tax_cents: 0,
        created_at: new Date('2026-06-08T12:00:00Z'),
      });

      const pack = await svc.buildPack('2026-06');
      expect(pack.exempt_customers).toBeGreaterThanOrEqual(1);
      await svc.euVatSummary('2026-06');
      await svc.nexusReport('2026-06');
      await svc.usStateBreakdown('2026-06');
      await svc.exportPackCsv('2026-06');
      await svc.comparePeriods('2026-05', '2026-06');
      await svc.auditTrailForPeriod('2026-06');
      await svc.missingTaxInvoices('2026-06');
      expect(await svc.standardRateForCountry('DE')).toBe(1900);
      expect(await svc.standardRateForCountry('GB')).toBe(2000);
      expect(await svc.standardRateForCountry('US')).toBe(0);
      expect(await svc.standardRateForCountry('AU')).toBe(1000);
      await svc.estimatedLiability('2026-06');
      await svc.customerTaxProfile(euCustomer.id);
      await svc.quarterlyRollup(2026, 2);
      await svc.filingChecklist('2026-06');
      await svc.remittanceSchedule(2026);
      await svc.documentRetentionPolicy();
      await expect(svc.buildPack('bad')).rejects.toMatchObject({ statusCode: 400 });
      await expect(
        svc.validateInvoiceTax('00000000-0000-4000-8000-000000000099')
      ).rejects.toMatchObject({ statusCode: 404 });
      const validation = await svc.validateInvoiceTax(inv.id);
      expect(validation).toHaveProperty('valid');
    });
  });

  describe('CohortAnalysisService NotificationService TaxCalculationService', () => {
    it('builds cohort matrix and average retention', async () => {
      const plan = await createPlan();
      const customer = await createCustomer();
      await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
      const cohort = new CohortAnalysisService();
      const matrix = await cohort.buildRetentionMatrix(2, 2);
      expect(Array.isArray(matrix)).toBe(true);
      expect(await cohort.averageRetentionByOffset(0)).toBeGreaterThanOrEqual(0);
    });

    it('enqueues processes and payment-failed notification', async () => {
      const notifications = new NotificationService();
      await notifications.enqueue('internal', {
        template: 'sweep',
        recipient: 'ops@test.com',
        data: { ok: true },
      });
      expect(await notifications.processPending(5)).toBeGreaterThanOrEqual(1);
      const customer = await createCustomer();
      const plan = await createPlan();
      const sub = await new SubscriptionService().create({
        customer_id: customer.id,
        plan_id: plan.id,
      });
      const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
      await notifications.notifyPaymentFailed(sub.id, inv.id, customer.email as string);
      expect(await notifications.processPending(5)).toBeGreaterThanOrEqual(1);
    });

    it('lists jurisdictions and computes US region tax', () => {
      const tax = new TaxCalculationService();
      const eu = tax.computeForCustomer(10_000, 'DE');
      expect(eu.inclusive).toBe(true);
      expect(eu.tax_cents).toBeGreaterThan(0);
      const ca = tax.computeForCustomer(10_000, 'US', 'CA');
      expect(ca.jurisdiction).toBe('US-CA');
      expect(ca.tax_cents).toBeGreaterThan(0);
      const rules = tax.listSupportedJurisdictions();
      expect(rules.length).toBeGreaterThan(0);
    });
  });

  describe('JobLockService', () => {
    it('records failed run when handler throws', async () => {
      const lock = new JobLockService();
      await expect(
        lock.runExclusive('retry', async () => {
          throw new Error('handler_failed');
        })
      ).rejects.toThrow('handler_failed');
      const recent = await lock.listRecent('retry', 5);
      expect(recent.some((r) => r.status === 'failed')).toBe(true);
    });
  });

  describe('MinimumCommitmentCalculator', () => {
    it('selects tier and computes shortfall and no shortfall', () => {
      const calc = new MinimumCommitmentCalculator();
      const withShortfall = calc.compute({
        actual_mrr_cents: 10_000,
        usage_overage_units: 5,
        tier: defaultCommitmentTiers[2],
      });
      expect(withShortfall.shortfall_cents).toBeGreaterThan(0);
      expect(withShortfall.overage_cents).toBeGreaterThan(0);

      const noShortfall = calc.compute({
        actual_mrr_cents: 600_000,
        usage_overage_units: 0,
        tier: defaultCommitmentTiers[2],
      });
      expect(noShortfall.shortfall_cents).toBe(0);

      const growth = calc.selectTier(150_000, defaultCommitmentTiers);
      expect(growth.name).toBe('growth');
      const starter = calc.selectTier(1, defaultCommitmentTiers);
      expect(starter.name).toBe('starter');
    });
  });

  describe('SagaOrchestrator', () => {
    it('compensates and marks saga failed on step error', async () => {
      const saga = new SagaOrchestrator();
      let compensated = false;
      await expect(
        saga.run('sweep_fail', [
          { name: 'a', run: async () => undefined, compensate: async () => { compensated = true; } },
          { name: 'b', run: async () => { throw new Error('step_b_failed'); } },
        ])
      ).rejects.toBeDefined();
      expect(compensated).toBe(true);
      const recent = await saga.listRecent(3);
      expect(recent.some((r) => r.status === 'compensated')).toBe(true);
    });
  });

  describe('WorkflowEngine', () => {
    it('runs subscription lifecycle transitions and validation errors', async () => {
      const engine = new WorkflowEngine();
      await engine.seedSubscriptionLifecycle();
      await engine.seedSubscriptionLifecycle();

      const plan = await createPlan();
      const customer = await createCustomer();

      async function instanceAt(initial: string) {
        const sub = await new SubscriptionService().create({
          customer_id: customer.id,
          plan_id: plan.id,
        });
        return engine.start('subscription_lifecycle', 'subscription', sub.id, initial, {});
      }

      const fromDraftTrial = await instanceAt('draft');
      await engine.trigger(fromDraftTrial.id, 'start_trial');
      const fromDraftActive = await instanceAt('draft');
      await engine.trigger(fromDraftActive.id, 'activate');

      const trialing = await instanceAt('trialing');
      await engine.trigger(trialing.id, 'trial_convert');
      const trialExpire = await instanceAt('trialing');
      await engine.trigger(trialExpire.id, 'trial_expire');

      const active = await instanceAt('active');
      await engine.trigger(active.id, 'payment_failed');
      const pastDue = await instanceAt('past_due');
      await engine.trigger(pastDue.id, 'payment_recovered');
      const dunning = await instanceAt('past_due');
      await engine.trigger(dunning.id, 'dunning_exhausted');

      const cancelActive = await instanceAt('active');
      await engine.trigger(cancelActive.id, 'cancel');
      const force = await instanceAt('active');
      await engine.trigger(force.id, 'force_cancel');

      await expect(
        engine.registerDefinition('bad_wf', 'x', [], [{ from: 'a', to: 'b', trigger: 't' }])
      ).rejects.toMatchObject({ statusCode: 400 });

      const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
      await expect(
        engine.start('subscription_lifecycle', 'subscription', sub.id, 'not_a_state', {})
      ).rejects.toMatchObject({ statusCode: 400 });

      const open = await engine.start('subscription_lifecycle', 'subscription', sub.id, 'active', {});
      await expect(engine.start('subscription_lifecycle', 'subscription', sub.id, 'active', {})).rejects.toMatchObject({
        statusCode: 409,
      });
      await expect(engine.trigger(open.id, 'bogus_trigger')).rejects.toMatchObject({ statusCode: 400 });
      await engine.trigger(open.id, 'cancel');
      await expect(engine.trigger(open.id, 'payment_failed')).rejects.toMatchObject({ statusCode: 400 });
      await expect(engine.getInstance('00000000-0000-4000-8000-000000000099')).rejects.toMatchObject({
        statusCode: 404,
      });
      expect((await engine.getHistory(open.id)).length).toBeGreaterThan(0);
    });
  });

  describe('FeatureFlagService', () => {
    it('evaluates partial percentage rollout', async () => {
      const flags = new FeatureFlagService();
      await flags.upsert('partial_rollout', true, { percentage_rollout: 50 });
      let enabled = 0;
      let disabled = 0;
      for (let i = 0; i < 40; i++) {
        if (await flags.isEnabled('partial_rollout', { user_id: `user-${i}` })) enabled += 1;
        else disabled += 1;
      }
      expect(enabled).toBeGreaterThan(0);
      expect(disabled).toBeGreaterThan(0);
    });
  });

  describe('PaymentService', () => {
    it('fails charge when simulateSuccess is false', async () => {
      const plan = await createPlan();
      const customer = await createCustomer();
      const sub = await new SubscriptionService().create({
        customer_id: customer.id,
        plan_id: plan.id,
      });
      const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
      const payment = await new PaymentService().chargeInvoice(inv.id, false, {
        scheduleRetries: false,
        flushOutbox: false,
      });
      expect(payment.status).toBe('failed');
      const updated = await new SubscriptionService().getById(sub.id);
      expect(updated.status).toBe('past_due');
    });
  });

  describe('globalMetrics', () => {
    it('persists recent counters to application_metrics', async () => {
      globalMetrics.increment('sweep_counter', { lane: 'test' });
      const inserted = await globalMetrics.persistRecent(120);
      expect(inserted).toBeGreaterThanOrEqual(1);
      const rows = await getTestDb()('application_metrics').where({ name: 'sweep_counter' });
      expect(rows.length).toBeGreaterThanOrEqual(1);
    });
  });

  describe('database config', () => {
    it('getDb returns the injected pg-mem knex instance', () => {
      expect(getDb()).toBe(getTestDb());
    });
  });
});
