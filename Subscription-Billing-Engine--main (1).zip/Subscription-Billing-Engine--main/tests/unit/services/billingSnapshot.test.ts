import request from 'supertest';
import { createApp } from '../../../src/app';
import { BillingSnapshotService } from '../../../src/services/BillingSnapshotService';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('BillingSnapshotService', () => {
  const app = createApp();
  const svc = new BillingSnapshotService();

  it('captures MRR and lists via API', async () => {
    const plan = await createPlan({ price_cents: 2500 });
    const customer = await createCustomer();
    await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const snap = await svc.capture({ snapshot_type: 'mrr', period_key: '2026-06' });
    expect(Number((snap.metrics as { mrr_cents?: number }).mrr_cents)).toBeGreaterThan(0);
    const listed = await request(app)
      .get('/snapshots?period_key=2026-06&type=mrr')
      .set('x-api-key', API_KEY);
    expect(listed.status).toBe(200);
    expect(listed.body.length).toBeGreaterThan(0);
  });

  it('compares periods and collections snapshot', async () => {
    await svc.capture({ snapshot_type: 'mrr', period_key: '2026-05' });
    await svc.capture({ snapshot_type: 'mrr', period_key: '2026-06' });
    const cmp = await svc.comparePeriods('mrr', '2026-05', '2026-06');
    expect(cmp.delta).toBeDefined();
    const coll = await svc.capture({ snapshot_type: 'collections', period_key: '2026-06' });
    expect(coll.metrics).toBeDefined();
    const arr = await svc.rollupArr('2026-06');
    expect(arr).toBeGreaterThanOrEqual(0);
  });

  it('route capture and get', async () => {
    const cap = await request(app)
      .post('/snapshots/capture')
      .set('x-api-key', API_KEY)
      .send({ snapshot_type: 'usage', period_key: '2026-06-01' });
    expect(cap.status).toBe(201);
    const get = await request(app).get('/snapshots/usage/2026-06-01').set('x-api-key', API_KEY);
    expect(get.status).toBe(200);
  });
});
