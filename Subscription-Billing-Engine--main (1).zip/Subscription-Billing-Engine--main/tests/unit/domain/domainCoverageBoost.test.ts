import {
  resolveJurisdiction,
  calculateTaxCents,
  listTaxRules,
} from '../../../src/domain/tax/TaxRules';
import { PriceBook } from '../../../src/domain/pricing/PriceBook';
import { UsageRatingEngine } from '../../../src/domain/pricing/UsageRatingEngine';
import { SubscriptionStateMachine } from '../../../src/domain/subscription/SubscriptionStateMachine';
import {
  monthPeriodKey,
  parseMonthPeriod,
  previousMonth,
  nextMonth,
  monthsBetween,
  fiscalQuarter,
  fiscalYear,
  quarterPeriodKeys,
  daysInMonthPeriod,
  containsDate,
  currentMonthPeriod,
  trailingMonths,
  formatPeriodLabel,
  isValidPeriodKey,
  yearToDateMonths,
  overlapDays,
  sameYear,
  minPeriodKey,
  maxPeriodKey,
  periodKeyFromDate,
} from '../../../src/lib/billingPeriods';

describe('Domain and lib coverage boost', () => {
  it('tax rules for all jurisdictions', () => {
    expect(resolveJurisdiction('US', 'CA')).toBe('US-CA');
    expect(resolveJurisdiction('US', 'NY')).toBe('US-NY');
    expect(resolveJurisdiction('DE')).toBe('EU-DE');
    expect(resolveJurisdiction('FR')).toBe('EU-FR');
    expect(resolveJurisdiction('GB')).toBe('GB');
    expect(resolveJurisdiction('CA')).toBe('CA');
    expect(resolveJurisdiction('XX')).toBe('US');
    const inclusive = calculateTaxCents(10_000, 'EU-DE');
    expect(inclusive.inclusive).toBe(true);
    expect(inclusive.taxCents).toBeGreaterThan(0);
    const exclusive = calculateTaxCents(10_000, 'US-CA');
    expect(exclusive.inclusive).toBe(false);
    expect(listTaxRules().length).toBeGreaterThan(5);
  });

  it('price book tiers and usage rating batch', () => {
    const book = PriceBook.defaultSaas();
    expect(book.list().length).toBe(2);
    expect(book.unitPriceForQuantity('seat', 5)).toBe(6000);
    expect(book.unitPriceForQuantity('seat', 100)).toBeGreaterThan(0);
    expect(() => book.unitPriceForQuantity('missing', 1)).toThrow(/Unknown SKU/);
    const engine = new UsageRatingEngine();
    const batch = engine.rateBatch(
      [{ meter: 'api', quantity: 50_000, period_start: '2026-01-01', period_end: '2026-01-31' }],
      { api: [{ up_to: 10_000, unit_cents: 0 }, { up_to: null, unit_cents: 2 }] }
    );
    expect(batch[0].amount_cents).toBeGreaterThan(0);
    expect(() =>
      engine.rateBatch(
        [{ meter: 'missing', quantity: 1, period_start: '2026-01-01', period_end: '2026-01-31' }],
        {}
      )
    ).toThrow(/No tiers/);
  });

  it('subscription state machine edges', () => {
    const sm = new SubscriptionStateMachine('trial');
    expect(SubscriptionStateMachine.billable('trial')).toBe(true);
    expect(SubscriptionStateMachine.allowedTriggers('cancelled')).toEqual([]);
    sm.trigger('convert');
    expect(sm.current()).toBe('active');
    sm.trigger('pause');
    sm.trigger('resume');
    expect(() => sm.trigger('payment_failed')).not.toThrow();
  });

  it('billing period utilities', () => {
    expect(isValidPeriodKey('2026-06')).toBe(true);
    expect(isValidPeriodKey('bad')).toBe(false);
    expect(() => parseMonthPeriod('bad')).toThrow();
    expect(previousMonth('2026-06')).toBe('2026-05');
    expect(nextMonth('2026-06')).toBe('2026-07');
    expect(monthsBetween('2026-01', '2026-03').length).toBe(3);
    expect(fiscalQuarter('2026-06')).toBe(2);
    expect(fiscalYear('2026-06')).toBe(2026);
    expect(quarterPeriodKeys(2026, 2)).toHaveLength(3);
    expect(daysInMonthPeriod('2026-06')).toBeGreaterThanOrEqual(30);
    expect(containsDate('2026-06', new Date('2026-06-15T00:00:00Z'))).toBe(true);
    expect(currentMonthPeriod().key).toMatch(/^\d{4}-\d{2}$/);
    expect(trailingMonths(2).length).toBe(2);
    expect(formatPeriodLabel('2026-06')).toContain('2026');
    expect(yearToDateMonths('2026-06').length).toBe(6);
    expect(overlapDays('2026-06', '2026-06')).toBeGreaterThan(0);
    expect(sameYear('2026-05', '2026-06')).toBe(true);
    expect(minPeriodKey(['2026-06', '2026-05'])).toBe('2026-05');
    expect(maxPeriodKey(['2026-06', '2026-05'])).toBe('2026-06');
    expect(periodKeyFromDate(new Date('2026-03-01T00:00:00Z'))).toBe('2026-03');
  });
});
