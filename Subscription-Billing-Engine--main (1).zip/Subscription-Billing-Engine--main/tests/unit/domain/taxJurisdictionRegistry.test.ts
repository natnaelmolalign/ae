import { TaxJurisdictionRegistry } from '../../../src/domain/tax/TaxJurisdictionRegistry';

describe('TaxJurisdictionRegistry', () => {
  const registry = new TaxJurisdictionRegistry();

  it('lists jurisdictions and resolves rates', () => {
    expect(registry.list().length).toBeGreaterThan(5);
    expect(registry.get('de')?.code).toBe('DE');
    expect(registry.defaultRateBps('DE')).toBe(1900);
    expect(registry.defaultRateBps('ZZ')).toBe(0);
    expect(registry.isEu('FR')).toBe(true);
    expect(registry.isEu('US')).toBe(false);
  });

  it('validates VAT requirements and reverse charge', () => {
    expect(registry.validateVatRequirement('US')).toEqual({ valid: true });
    expect(registry.validateVatRequirement('DE')).toMatchObject({
      valid: false,
      reason: expect.stringContaining('VAT'),
    });
    expect(registry.validateVatRequirement('DE', 'DE123')).toEqual({ valid: true });
    expect(registry.validateVatRequirement('XX')).toEqual({ valid: true });

    expect(registry.reverseChargeApplies('DE', 'FR', 'FR-VAT')).toBe(true);
    expect(registry.reverseChargeApplies('DE', 'DE', 'DE-VAT')).toBe(false);
    expect(registry.reverseChargeApplies('US', 'DE', 'VAT')).toBe(false);
    expect(registry.reverseChargeApplies('DE', 'US', 'VAT')).toBe(false);
    expect(registry.reverseChargeApplies('DE', 'FR')).toBe(false);
  });
});
