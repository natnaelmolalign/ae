import { InvoiceStateMachine } from '../../../src/domain/invoice/InvoiceStateMachine';
import { SubscriptionStateMachine } from '../../../src/domain/subscription/SubscriptionStateMachine';

describe('State machines', () => {
  it('invoice transitions', () => {
    const sm = new InvoiceStateMachine('draft');
    expect(sm.can('finalize')).toBe(true);
    sm.trigger('finalize');
    expect(sm.current()).toBe('open');
    sm.trigger('pay');
    expect(sm.current()).toBe('paid');
  });

  it('subscription transitions', () => {
    const sm = new SubscriptionStateMachine('trial');
    sm.trigger('convert');
    expect(sm.current()).toBe('active');
    expect(SubscriptionStateMachine.billable('active')).toBe(true);
  });
});
