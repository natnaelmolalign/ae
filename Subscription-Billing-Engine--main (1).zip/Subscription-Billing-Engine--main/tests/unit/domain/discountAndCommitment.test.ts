import { DiscountEngine } from '../../../src/domain/pricing/DiscountEngine';
import {
  MinimumCommitmentCalculator,
  defaultCommitmentTiers,
} from '../../../src/domain/billing/MinimumCommitmentCalculator';

describe('DiscountEngine and commitments', () => {
  it('applies percent fixed and tiered discounts', () => {
    const engine = DiscountEngine.standardPromos();
    const launch = engine.apply(100_000, ['LAUNCH20']);
    expect(launch.lines.length).toBe(1);
    const loyalty = engine.apply(10_000, ['LOYALTY']);
    expect(loyalty.total).toBeLessThan(10_000);
    const credit = engine.apply(6000, ['CREDIT50']);
    expect(credit.total).toBe(1000);
    const stacked = engine.apply(200_000, ['LOYALTY', 'CREDIT50']);
    expect(stacked.lines.length).toBeGreaterThan(0);
    const none = engine.apply(1000, ['MISSING']);
    expect(none.total).toBe(1000);
  });

  it('commitment tiers shortfall and overage', () => {
    const calc = new MinimumCommitmentCalculator();
    const below = calc.compute({
      actual_mrr_cents: 50_000,
      usage_overage_units: 10,
      tier: defaultCommitmentTiers[2],
    });
    expect(below.shortfall_cents).toBeGreaterThan(0);
    expect(below.overage_cents).toBeGreaterThan(0);
    const met = calc.compute({
      actual_mrr_cents: 600_000,
      usage_overage_units: 0,
      tier: defaultCommitmentTiers[2],
    });
    expect(met.shortfall_cents).toBe(0);
    const tier = calc.selectTier(0, defaultCommitmentTiers);
    expect(tier.name).toBe('starter');
    expect(calc.projectAnnualTrueUp([below, met])).toBeGreaterThan(0);
  });
});
