import { SubscriptionAggregate } from '../../../src/domain/subscription/SubscriptionAggregate';
import { DomainError } from '../../../src/domain/shared/AggregateRoot';

describe('SubscriptionAggregate branches', () => {
  const base = {
    id: '00000000-0000-4000-8000-000000000010',
    customerId: '00000000-0000-4000-8000-000000000011',
    planId: '00000000-0000-4000-8000-000000000012',
    trialEndsAt: null,
    currentPeriodStart: new Date('2026-06-01'),
    currentPeriodEnd: new Date('2026-06-30'),
  };

  it('create defaults to trial and allows explicit status', () => {
    const trial = SubscriptionAggregate.create(base);
    expect(trial.snapshot.status).toBe('trial');
    const active = SubscriptionAggregate.create({ ...base, status: 'active' });
    expect(active.snapshot.status).toBe('active');
  });

  it('rejects invalid transitions and cancelled side-effect', () => {
    const agg = SubscriptionAggregate.create({ ...base, status: 'active' });
    expect(() => agg.transition('trial', 'nope')).toThrow(DomainError);
    agg.transition('cancelled', 'user');
    expect(agg.snapshot.status).toBe('cancelled');
    const events = agg.pullEvents();
    expect(events.some((e) => e.type === 'subscription.cancelled')).toBe(true);
  });

  it('recordFailedPayment moves active to past_due only', () => {
    const active = SubscriptionAggregate.create({ ...base, status: 'active' });
    active.recordFailedPayment();
    expect(active.snapshot.status).toBe('past_due');
    expect(active.snapshot.failedPaymentCount).toBe(1);

    const trial = SubscriptionAggregate.create(base);
    trial.recordFailedPayment();
    expect(trial.snapshot.status).toBe('trial');
    expect(trial.snapshot.failedPaymentCount).toBe(1);
  });

  it('recoverFromPastDue and changePlan update state', () => {
    const agg = SubscriptionAggregate.create({ ...base, status: 'active' });
    agg.recordFailedPayment();
    agg.recoverFromPastDue();
    expect(agg.snapshot.status).toBe('active');
    expect(agg.snapshot.failedPaymentCount).toBe(0);

    expect(() => agg.recoverFromPastDue()).toThrow(/not past due/);
    agg.changePlan('00000000-0000-4000-8000-000000000099', new Date('2026-07-01'), new Date('2026-07-31'));
    expect(agg.snapshot.planId).toContain('099');
  });
});
