import { InvoiceAggregate } from '../../../src/domain/invoice/InvoiceAggregate';
import { InvoiceStateMachine } from '../../../src/domain/invoice/InvoiceStateMachine';
import { SubscriptionAggregate } from '../../../src/domain/subscription/SubscriptionAggregate';
import { SubscriptionStateMachine } from '../../../src/domain/subscription/SubscriptionStateMachine';
import { BillingRulesEngine } from '../../../src/domain/billing/BillingRulesEngine';
import { MinimumCommitmentCalculator, defaultCommitmentTiers } from '../../../src/domain/billing/MinimumCommitmentCalculator';
import { AggregateRoot } from '../../../src/domain/shared/AggregateRoot';
import { DomainError } from '../../../src/domain/shared/AggregateRoot';

class TestAgg extends AggregateRoot {
  constructor(id: string) {
    super(id);
    this.recordEvent('test', {});
  }
}

describe('Full domain coverage', () => {
  describe('InvoiceAggregate', () => {
    const line = { description: 'Base', quantity: 1, unit_amount_cents: 1000, amount_cents: 1000 };

    it('full lifecycle and errors', () => {
      const inv = InvoiceAggregate.draft('i1', 's1', [line]);
      inv.applyDiscount(100);
      inv.applyTax(50);
      inv.markOpen();
      inv.markPaid();
      expect(inv.snapshot.status).toBe('paid');
      expect(inv.pullEvents().length).toBeGreaterThan(2);
    });

    it('rejects invalid transitions', () => {
      const paid = InvoiceAggregate.draft('i2', 's1', [line]);
      paid.markOpen();
      paid.markPaid();
      expect(() => paid.applyTax(10)).toThrow(DomainError);
      expect(() => paid.markOpen()).toThrow(DomainError);
      expect(() => paid.markPaid()).toThrow(DomainError);

      const draft = InvoiceAggregate.draft('i3', 's1', [line]);
      expect(() => draft.applyDiscount(2000)).toThrow(DomainError);

      const open = InvoiceAggregate.draft('i4', 's1', [line]);
      open.markOpen();
      open.voidInvoice('test');
      expect(() => open.markPaid()).toThrow(DomainError);
      expect(open.snapshot.status).toBe('void');

      const paidVoid = InvoiceAggregate.draft('i5b', 's1', [line]);
      paidVoid.markOpen();
      paidVoid.markPaid();
      expect(() => paidVoid.voidInvoice('too late')).toThrow(DomainError);

      const forVoid = InvoiceAggregate.draft('i5', 's1', [line]);
      forVoid.markOpen();
      forVoid.voidInvoice('cancel');
      expect(forVoid.snapshot.status).toBe('void');
    });
  });

  describe('InvoiceStateMachine', () => {
    it('covers describe and terminal', () => {
      expect(InvoiceStateMachine.describe('paid')).toContain('Settled');
      expect(InvoiceStateMachine.isTerminal('void')).toBe(true);
      expect(InvoiceStateMachine.allowedTriggers('draft')).toContain('finalize');
    });

    it('invalid transition throws', () => {
      const sm = new InvoiceStateMachine('void');
      expect(() => sm.trigger('pay')).toThrow(/Invalid transition/);
    });
  });

  describe('SubscriptionAggregate', () => {
    it('lifecycle events', () => {
      const agg = SubscriptionAggregate.create({
        id: 's1',
        customerId: 'c1',
        planId: 'p1',
        status: 'trial',
        trialEndsAt: new Date(),
        currentPeriodStart: new Date(),
        currentPeriodEnd: new Date(),
      });
      agg.transition('active', 'trial_ended');
      agg.recordFailedPayment();
      expect(agg.snapshot.status).toBe('past_due');
      agg.recoverFromPastDue();
      expect(agg.snapshot.status).toBe('active');
      agg.transition('cancelled', 'user_request');
      expect(agg.snapshot.status).toBe('cancelled');
      expect(() => agg.recoverFromPastDue()).toThrow(DomainError);
    });
  });

  describe('SubscriptionStateMachine', () => {
    it('pause resume cancel', () => {
      const sm = new SubscriptionStateMachine('active');
      sm.trigger('pause');
      expect(sm.current()).toBe('paused');
      sm.trigger('resume');
      sm.trigger('payment_failed');
      expect(() => sm.trigger('resume')).toThrow(/Invalid/);
    });
  });

  describe('BillingRulesEngine', () => {
    const engine = new BillingRulesEngine(100);

    it('calculate with percent discount and inclusive tax', () => {
      const r = engine.calculate(
        [{ description: 'A', quantity: 2, unit_amount_cents: 500 }],
        { type: 'percent', value: 10, recurring: true },
        { rate_bps: 1900, inclusive: true }
      );
      expect(r.total_cents).toBeGreaterThan(0);
      expect(r.minimum_charge_applied).toBe(false);
    });

    it('fixed discount and minimum charge', () => {
      const tiny = engine.calculate([{ description: 'T', quantity: 1, unit_amount_cents: 10 }]);
      expect(tiny.minimum_charge_applied).toBe(true);
      expect(tiny.total_cents).toBe(100);

      const fixed = engine.resolveDiscount(1000, { type: 'fixed', value: 200, recurring: false });
      expect(fixed).toBe(200);
      expect(engine.computeLineAmount(0, 100)).toBe(0);
      expect(() => engine.computeLineAmount(1, -1)).toThrow();
      expect(() => engine.applyPercentDiscount(100, 101)).toThrow();
    });

    it('merge and prorate', () => {
      const merged = engine.mergeAddonLines(
        [{ description: 'B', quantity: 1, unit_amount_cents: 100 }],
        [{ description: 'A', quantity: 0, unit_amount_cents: 50 }]
      );
      expect(merged).toHaveLength(1);
      const start = new Date('2026-01-01');
      const end = new Date('2026-01-31');
      const pr = engine.prorateLineAmount(3100, start, end, new Date('2026-01-16'), end);
      expect(pr).toBeGreaterThan(0);
      expect(engine.tieredUsageCharge(150, [{ up_to: 100, unit_cents: 10 }, { up_to: null, unit_cents: 5 }])).toBe(1250);
    });
  });

  describe('MinimumCommitmentCalculator', () => {
    it('tier selection and annual projection', () => {
      const calc = new MinimumCommitmentCalculator();
      const tier = calc.selectTier(200_000, defaultCommitmentTiers);
      expect(tier.name).toBe('growth');
      const annual = calc.projectAnnualTrueUp([
        calc.compute({ actual_mrr_cents: 80_000, usage_overage_units: 5, tier: defaultCommitmentTiers[1] }),
      ]);
      expect(annual).toBeGreaterThan(0);
    });
  });

  describe('AggregateRoot', () => {
    it('records events', () => {
      const a = new TestAgg('x');
      expect(a.pullEvents()).toHaveLength(1);
      expect(a.pullEvents()).toHaveLength(0);
    });
  });
});
