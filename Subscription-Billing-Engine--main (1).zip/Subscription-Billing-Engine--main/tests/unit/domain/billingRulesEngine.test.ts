import { BillingRulesEngine } from '../../../src/domain/billing/BillingRulesEngine';
import { MinimumCommitmentCalculator } from '../../../src/domain/billing/MinimumCommitmentCalculator';

describe('BillingRulesEngine', () => {
  const engine = new BillingRulesEngine(100);

  it('calculates invoice with discount and tax', () => {
    const result = engine.calculate(
      [{ description: 'Base', quantity: 1, unit_amount_cents: 10_000 }],
      { type: 'percent', value: 10, recurring: true },
      { rate_bps: 1900, inclusive: false }
    );
    expect(result.subtotal_cents).toBe(10_000);
    expect(result.discount_cents).toBe(1000);
    expect(result.tax_cents).toBeGreaterThan(0);
    expect(result.total_cents).toBeGreaterThan(9000);
  });

  it('applies minimum charge', () => {
    const result = engine.calculate([{ description: 'Tiny', quantity: 1, unit_amount_cents: 10 }]);
    expect(result.minimum_charge_applied).toBe(true);
    expect(result.total_cents).toBe(100);
  });

  it('prorates line amount', () => {
    const start = new Date('2026-06-01');
    const end = new Date('2026-06-30');
    const mid = new Date('2026-06-15');
    const amount = engine.prorateLineAmount(3000, start, end, mid, end);
    expect(amount).toBeGreaterThan(0);
    expect(amount).toBeLessThan(3000);
  });

  it('merges addon lines', () => {
    const merged = engine.mergeAddonLines(
      [{ description: 'Base', quantity: 1, unit_amount_cents: 1000 }],
      [{ description: 'Addon', quantity: 0, unit_amount_cents: 500 }]
    );
    expect(merged).toHaveLength(1);
  });

  it('covers percent cap fixed discount and tiered usage edge paths', () => {
    expect(engine.applyPercentDiscount(1000, 25)).toBe(250);
    expect(engine.sumSubtotal([{ description: 'x', quantity: 2, unit_amount_cents: 100 }])).toBe(200);
    const fixed = engine.calculate(
      [{ description: 'Line', quantity: 1, unit_amount_cents: 5000 }],
      { type: 'fixed', value: 6000, recurring: false }
    );
    expect(fixed.discount_cents).toBe(5000);
    expect(
      engine.tieredUsageCharge(250, [
        { up_to: 100, unit_cents: 10 },
        { up_to: 200, unit_cents: 8 },
        { up_to: null, unit_cents: 5 },
      ])
    ).toBeGreaterThan(0);
  });
});

describe('MinimumCommitmentCalculator', () => {
  it('computes shortfall true-up', () => {
    const calc = new MinimumCommitmentCalculator();
    const result = calc.compute({
      actual_mrr_cents: 80_000,
      usage_overage_units: 10,
      tier: { name: 'growth', minimum_mrr_cents: 100_000, overage_unit_cents: 8 },
    });
    expect(result.shortfall_cents).toBe(20_000);
    expect(result.true_up_cents).toBe(20_080);
  });
});
