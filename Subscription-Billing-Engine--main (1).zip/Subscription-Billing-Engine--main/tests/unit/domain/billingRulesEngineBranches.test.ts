import { BillingRulesEngine } from '../../../src/domain/billing/BillingRulesEngine';

describe('BillingRulesEngine branch coverage', () => {
  const engine = new BillingRulesEngine(50);

  it('calculates subtotal-only and exclusive-tax totals without minimum bump', () => {
    const plain = engine.calculate([{ description: 'Only', quantity: 3, unit_amount_cents: 2000 }]);
    expect(plain.discount_cents).toBe(0);
    expect(plain.tax_cents).toBe(0);
    expect(plain.minimum_charge_applied).toBe(false);
    expect(plain.total_cents).toBe(6000);

    const taxed = engine.calculate(
      [{ description: 'Taxed', quantity: 1, unit_amount_cents: 10_000 }],
      undefined,
      { rate_bps: 500, inclusive: false }
    );
    expect(taxed.tax_cents).toBe(500);
    expect(taxed.total_cents).toBe(10_500);
  });

  it('covers discount resolution and percent cap paths', () => {
    expect(engine.resolveDiscount(1000)).toBe(0);
    expect(engine.resolveDiscount(0, { type: 'fixed', value: 50, recurring: false })).toBe(0);
    expect(
      engine.resolveDiscount(2000, {
        type: 'percent',
        value: 50,
        recurring: true,
        max_discount_cents: 300,
      })
    ).toBe(300);
    expect(engine.applyPercentDiscount(100, 100)).toBe(100);
  });

  it('merges positive addon lines and tiered usage early exits', () => {
    const merged = engine.mergeAddonLines(
      [{ description: 'Base', quantity: 1, unit_amount_cents: 100 }],
      [
        { description: 'Addon', quantity: 2, unit_amount_cents: 50 },
        { description: 'Skip', quantity: 0, unit_amount_cents: 99 },
      ]
    );
    expect(merged).toHaveLength(2);
    expect(engine.tieredUsageCharge(0, [{ up_to: 10, unit_cents: 1 }])).toBe(0);
    expect(
      engine.tieredUsageCharge(5, [
        { up_to: 3, unit_cents: 10 },
        { up_to: null, unit_cents: 2 },
      ])
    ).toBe(34);
  });

  it('calculate without tax uses exclusive total path', () => {
    const engine = new BillingRulesEngine(10);
    const result = engine.calculate(
      [{ description: 'Line', quantity: 2, unit_amount_cents: 3000 }],
      { type: 'percent', value: 10, recurring: false }
    );
    expect(result.tax_cents).toBe(0);
    expect(result.minimum_charge_applied).toBe(false);
    expect(result.total_cents).toBe(5400);
  });

  it('prorates partial overlap inside the billing window', () => {
    const periodStart = new Date('2026-01-01T00:00:00Z');
    const periodEnd = new Date('2026-01-31T23:59:59Z');
    const effectiveStart = new Date('2026-01-20T00:00:00Z');
    const effectiveEnd = new Date('2026-01-25T23:59:59Z');
    const amount = engine.prorateLineAmount(
      3100,
      periodStart,
      periodEnd,
      effectiveStart,
      effectiveEnd
    );
    expect(amount).toBeGreaterThan(0);
    expect(amount).toBeLessThan(3100);
  });
});
