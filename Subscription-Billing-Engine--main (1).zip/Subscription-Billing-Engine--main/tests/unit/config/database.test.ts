import knex from 'knex';
import config from '../../../src/config/knexConfig';
import { getDb, setDbForTests, closeDb } from '../../../src/config/database';

describe('database config', () => {
  afterEach(async () => {
    await closeDb();
  });

  it('lazy-initializes knex and reuses the same instance', () => {
    const a = getDb();
    const b = getDb();
    expect(a).toBe(b);
  });

  it('closeDb is safe when no connection was opened', async () => {
    await closeDb();
    await expect(closeDb()).resolves.toBeUndefined();
  });

  it('setDbForTests replaces the singleton', async () => {
    const mem = knex(config);
    setDbForTests(mem);
    expect(getDb()).toBe(mem);
    await closeDb();
  });
});
