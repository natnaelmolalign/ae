import request from 'supertest';
import { createApp } from '../../src/app';
import { runBillingJob } from '../../src/jobs/billingJob';
import { runRetryJob } from '../../src/jobs/retryJob';
import { getTestDb } from '../helpers/pgMemDb';
import { createCustomer, createPlan } from '../helpers/factories';
import { SubscriptionService } from '../../src/services/SubscriptionService';
import { IdempotencyService } from '../../src/services/IdempotencyService';
import { WebhookService } from '../../src/services/WebhookService';
import { resetEnvForTests } from '../../src/config/env';

const API_KEY = 'test-api-key-32chars-minimum';

describe('billing engine flows', () => {
  const app = createApp();

  it('exercises plans, customers, subscriptions, invoices, payments, coupons', async () => {
    const planRes = await request(app)
      .post('/plans')
      .set('x-api-key', API_KEY)
      .send({ name: 'Starter', price_cents: 2000, interval: 'monthly', features: ['a'] });
    expect(planRes.status).toBe(201);
    const planId = planRes.body.id;

    const listPlans = await request(app).get('/plans?page=1&limit=5').set('x-api-key', API_KEY);
    expect(listPlans.status).toBe(200);
    expect(Array.isArray(listPlans.body.data)).toBe(true);

    const patchPrice = await request(app)
      .patch(`/plans/${planId}/price`)
      .set('x-api-key', API_KEY)
      .send({ price_cents: 2500 });
    expect(patchPrice.status).toBe(200);

    const customerRes = await request(app)
      .post('/customers')
      .set('x-api-key', API_KEY)
      .send({ email: 'flow@test.com', name: 'Flow User', country: 'US' });
    expect(customerRes.status).toBe(201);

    await request(app)
      .patch(`/customers/${customerRes.body.id}/country`)
      .set('x-api-key', API_KEY)
      .send({ country: 'CA' })
      .expect(200);

    const couponRes = await request(app)
      .post('/coupons')
      .set('x-api-key', API_KEY)
      .send({
        code: 'SAVE10',
        discount_type: 'percent',
        discount_value: 10,
        recurring: true,
      });
    expect(couponRes.status).toBe(201);

    await request(app).get('/coupons/SAVE10').set('x-api-key', API_KEY).expect(200);

    const subRes = await request(app)
      .post('/subscriptions')
      .set('x-api-key', API_KEY)
      .send({
        customer_id: customerRes.body.id,
        plan_id: planId,
        billing_anchor: '2024-06-01',
        coupon_code: 'SAVE10',
      });
    expect(subRes.status).toBe(201);
    const subId = subRes.body.id;

    await request(app).get(`/subscriptions/${subId}`).set('x-api-key', API_KEY).expect(200);

    await request(app)
      .post(`/subscriptions/${subId}/extend-trial`)
      .set('x-api-key', API_KEY)
      .send({ extra_days: 3 })
      .expect(400);

    const invoiceRes = await request(app)
      .post(`/subscriptions/${subId}/invoice`)
      .set('x-api-key', API_KEY);
    expect(invoiceRes.status).toBe(201);
    const invoiceId = invoiceRes.body.id;

    const invoiceGet = await request(app)
      .get(`/invoices/${invoiceId}`)
      .set('x-api-key', API_KEY);
    expect(invoiceGet.status).toBe(200);
    expect(invoiceGet.body.line_items.length).toBeGreaterThan(0);

    const charge = await request(app)
      .post('/payments/charge')
      .set('x-api-key', API_KEY)
      .set('idempotency-key', 'charge-key-1')
      .send({ invoice_id: invoiceId, simulate_success: true });
    expect(charge.status).toBe(201);

    const chargeDup = await request(app)
      .post('/payments/charge')
      .set('x-api-key', API_KEY)
      .set('idempotency-key', 'charge-key-1')
      .send({ invoice_id: invoiceId, simulate_success: true });
    expect(chargeDup.status).toBe(201);
    expect(chargeDup.body.id).toBe(charge.body.id);

    const refund = await request(app)
      .post(`/payments/${charge.body.id}/refund`)
      .set('x-api-key', API_KEY)
      .send({ amount_cents: 100 });
    expect(refund.status).toBe(200);
  });

  it('handles subscription lifecycle and proration', async () => {
    const plan = await createPlan({ price_cents: 3000 });
    const upgrade = await createPlan({ name: 'Pro', price_cents: 6000 });
    const customer = await createCustomer();
    const subs = new SubscriptionService();
    const sub = await subs.create({
      customer_id: customer.id,
      plan_id: plan.id,
      billing_anchor: '2024-01-15',
    });

    await request(app)
      .post(`/subscriptions/${sub.id}/pause`)
      .set('x-api-key', API_KEY)
      .expect(200);

    await request(app)
      .post(`/subscriptions/${sub.id}/resume`)
      .set('x-api-key', API_KEY)
      .send({ resume_date: '2024-02-01' })
      .expect(200);

    const changePlan = await request(app)
      .post(`/subscriptions/${sub.id}/change-plan`)
      .set('x-api-key', API_KEY)
      .send({ plan_id: upgrade.id, change_date: '2024-01-20' });
    expect(changePlan.status).toBe(200);

    await request(app)
      .post(`/subscriptions/${sub.id}/cancel`)
      .set('x-api-key', API_KEY)
      .expect(200);

    await request(app)
      .post(`/subscriptions/${sub.id}/reactivate`)
      .set('x-api-key', API_KEY)
      .expect(200);
  });

  it('runs billing and retry jobs', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const subs = new SubscriptionService();
    const sub = await subs.create({
      customer_id: customer.id,
      plan_id: plan.id,
      billing_anchor: '2024-01-01',
    });
    await getTestDb()('subscriptions')
      .where({ id: sub.id })
      .update({
        status: 'active',
        current_period_start: '2024-01-01',
        current_period_end: '2024-01-31',
      });

    const generated = await runBillingJob(new Date('2024-02-01'));
    expect(generated).toBeGreaterThanOrEqual(0);

    const invoice = await getTestDb()('invoices').where({ subscription_id: sub.id }).first();
    const { PaymentService } = await import('../../src/services/PaymentService');
    const { RetryService } = await import('../../src/services/RetryService');
    await new PaymentService().chargeInvoice(invoice.id, false, { scheduleRetries: false });
    await new RetryService().scheduleRetries(sub.id, invoice.id, new Date('2024-02-02'));
    await getTestDb()('payment_retries')
      .where({ invoice_id: invoice.id })
      .update({ scheduled_at: new Date('2024-02-01') });

    const retried = await runRetryJob(new Date('2024-02-05'));
    expect(retried).toBeGreaterThanOrEqual(0);
  });

  it('validates bad input and auth', async () => {
    await request(app).post('/plans').send({ name: '' }).expect(401);
    await request(app)
      .post('/plans')
      .set('x-api-key', API_KEY)
      .send({ name: '', price_cents: -1, interval: 'monthly' })
      .expect(400);

    await request(app).get('/health').expect(200);
    await request(app).get('/health/live').expect(200);
  });

  it('covers idempotency middleware cache', async () => {
    const idem = new IdempotencyService();
    await idem.store('POST /test', 'k1', 201, { ok: true });
    const cached = await idem.getCached('POST /test', 'k1');
    expect(cached?.status).toBe(201);
  });

  it('skips webhook delivery when url unset', async () => {
    const count = await new WebhookService().deliverPending();
    expect(count).toBe(0);
  });

  it('rejects invalid environment on load', () => {
    const prev = process.env.API_KEY;
    process.env.API_KEY = 'x';
    resetEnvForTests();
    expect(() => {
      const { loadEnv } = require('../../src/config/env');
      loadEnv();
    }).toThrow('Invalid environment');
    process.env.API_KEY = prev;
    resetEnvForTests();
  });
});
