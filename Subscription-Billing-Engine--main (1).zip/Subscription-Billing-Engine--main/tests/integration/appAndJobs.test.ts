import request from 'supertest';
import createApp, { startServer } from '../../src/app';
import { runCliCommand } from '../../src/cli';
import { runOutboxJob } from '../../src/jobs/outboxJob';
import { runRetentionJob } from '../../src/jobs/retentionJob';
import { runExportJob } from '../../src/jobs/exportJob';
import { runForecastJob } from '../../src/jobs/forecastJob';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('app bootstrap', () => {
  it('createApp mounts health and protected routes', async () => {
    const app = createApp();
    const health = await request(app).get('/health/live');
    expect(health.status).toBe(200);
    const plans = await request(app).get('/plans').set('x-api-key', API_KEY);
    expect(plans.status).toBe(200);
  });

  it('startServer binds when invoked', (done) => {
    const prev = process.env.PORT;
    process.env.PORT = '0';
    const server = startServer();
    process.env.PORT = prev;
    server.close(() => done());
  });
});

describe('jobs', () => {
  it('runs outbox job', async () => {
    const n = await runOutboxJob(5);
    expect(n).toBeGreaterThanOrEqual(0);
  });

  it('runs retention job', async () => {
    const result = await runRetentionJob();
    expect(result).toBeDefined();
  });

  it('runs export and forecast jobs', async () => {
    expect(await runExportJob()).toBeGreaterThanOrEqual(0);
    expect(await runForecastJob()).toBe(12);
  });

  it('runCliCommand executes metrics-persist', async () => {
    const msg = await runCliCommand('metrics-persist');
    expect(msg).toMatch(/metrics persisted/);
  });

  it('runCliCommand runs billing retry webhooks outbox analytics retention export forecast', async () => {
    expect((await runCliCommand('billing'))).toMatch(/billing job done/);
    expect((await runCliCommand('retry'))).toMatch(/retry job done/);
    expect((await runCliCommand('webhooks'))).toMatch(/webhook job done/);
    expect((await runCliCommand('outbox'))).toMatch(/outbox job done/);
    expect((await runCliCommand('analytics'))).toMatch(/analytics job done/);
    expect((await runCliCommand('retention'))).toMatch(/retention job done/);
    expect((await runCliCommand('export'))).toMatch(/export job done/);
    expect((await runCliCommand('forecast'))).toMatch(/forecast job done/);
  });

  it('exposes operations and api version header', async () => {
    const app = createApp();
    const res = await request(app)
      .get('/health/ready')
      .set('x-api-version', '2026-06-01');
    expect([200, 503]).toContain(res.status);
  });
});
