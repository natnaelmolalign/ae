import request from 'supertest';
import { createApp } from '../../src/app';
import { createCustomer, createPlan } from '../helpers/factories';

const API_KEY = 'test-api-key-32chars-minimum';

describe('subscription routes', () => {
  const app = createApp();

  it('validates params and bodies on subscription actions', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await request(app)
      .post('/subscriptions')
      .set('x-api-key', API_KEY)
      .send({ customer_id: customer.id, plan_id: plan.id })
      .expect(201);

    const id = sub.body.id;
    await request(app).get(`/subscriptions/${id}`).set('x-api-key', API_KEY).expect(200);
    await request(app).get('/subscriptions/not-uuid').set('x-api-key', API_KEY).expect(400);

    await request(app)
      .post(`/subscriptions/${id}/change-plan`)
      .set('x-api-key', API_KEY)
      .send({ plan_id: plan.id })
      .expect(400);

    await request(app)
      .post(`/subscriptions/${id}/extend-trial`)
      .set('x-api-key', API_KEY)
      .send({ extra_days: 0 })
      .expect(400);

    await request(app)
      .post(`/subscriptions/${id}/resume`)
      .set('x-api-key', API_KEY)
      .send({ resume_date: 'bad' })
      .expect(400);

    await request(app)
      .post(`/subscriptions/${id}/change-plan-at-period-end`)
      .set('x-api-key', API_KEY)
      .send({ plan_id: 'not-uuid' })
      .expect(400);
  });
});
