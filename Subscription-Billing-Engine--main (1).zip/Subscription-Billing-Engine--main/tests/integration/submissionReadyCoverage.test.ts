import request from 'supertest';
import * as database from '../../src/config/database';
import { createApp, shutdown } from '../../src/app';
import { runAnalyticsJob } from '../../src/jobs/analyticsJob';
import { runBillingJob } from '../../src/jobs/billingJob';
import { authMiddleware } from '../../src/middleware/auth';
import { MinimumCommitmentCalculator } from '../../src/domain/billing/MinimumCommitmentCalculator';
import { InvoiceRepository } from '../../src/repositories/InvoiceRepository';
import { BillingAlertService } from '../../src/services/BillingAlertService';
import { BillingForecastService } from '../../src/services/BillingForecastService';
import { PrincipalService } from '../../src/services/RbacService';
import { createCustomer, createPlan } from '../helpers/factories';
import { getTestDb } from '../helpers/pgMemDb';
import { SubscriptionService } from '../../src/services/SubscriptionService';
import { InvoiceService } from '../../src/services/InvoiceService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Submission-ready coverage sweep', () => {
  const app = createApp();

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('auth middleware covers principal bootstrap and rejection paths', async () => {
    const principals = new PrincipalService();
    const { apiKey } = await principals.create('readonly-bot', ['billing_readonly']);

    const req = {
      header: (name: string) => (name === 'x-api-key' ? apiKey : undefined),
    } as unknown as Parameters<typeof authMiddleware>[0];
    const next = jest.fn();
    await authMiddleware(req, {} as never, next);
    expect(next).toHaveBeenCalledWith();
    expect(req.principalId).toBeDefined();

    const badReq = {
      header: (name: string) => (name === 'x-api-key' ? 'invalid-key-not-in-db' : undefined),
    } as unknown as Parameters<typeof authMiddleware>[0];
    const badNext = jest.fn();
    await authMiddleware(badReq, {} as never, badNext);
    expect(badNext.mock.calls[0][0]).toMatchObject({ statusCode: 401 });
  });

  it('policy seat-price default and custom seats', async () => {
    expect((await request(app).get('/policy/seat-price').set('x-api-key', API_KEY)).status).toBe(200);
    const custom = await request(app).get('/policy/seat-price?seats=12').set('x-api-key', API_KEY);
    expect(custom.body.seats).toBe(12);
  });

  it('feature flag enabled probe and insights ltv json export', async () => {
    const flags = await request(app).get('/feature-flags').set('x-api-key', API_KEY);
    if (flags.body.length > 0) {
      const key = flags.body[0].key as string;
      expect(
        (await request(app).get(`/feature-flags/${key}/enabled`).set('x-api-key', API_KEY)).status
      ).toBe(200);
    }
    const customer = await createCustomer();
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    await new InvoiceService().generateForSubscription(sub, customer.country);
    expect(
      (await request(app).get(`/insights/customers/${customer.id}/ltv`).set('x-api-key', API_KEY)).status
    ).toBe(200);
    const jsonExport = await request(app)
      .get(`/insights/customers/${customer.id}/invoices/export?format=json`)
      .set('x-api-key', API_KEY);
    expect(jsonExport.status).toBe(200);
  });

  it('health root ok path when database is up', async () => {
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
    expect(res.body.database).toBe('up');
  });

  it('minimum commitment calculator shortfall and tier selection', () => {
    const calc = new MinimumCommitmentCalculator();
    const tiers = [
      { name: 'starter', minimum_mrr_cents: 0, overage_unit_cents: 10 },
      { name: 'growth', minimum_mrr_cents: 100_000, overage_unit_cents: 8 },
    ];
    expect(calc.selectTier(150_000, tiers).name).toBe('growth');
    expect(calc.selectTier(10, tiers).name).toBe('starter');
    const result = calc.compute({
      actual_mrr_cents: 50_000,
      usage_overage_units: 2,
      tier: tiers[1],
    });
    expect(result.shortfall_cents).toBeGreaterThan(0);
    expect(result.overage_cents).toBe(16);
  });

  it('invoice repository update paths', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const repo = new InvoiceRepository(getTestDb());
    expect(await repo.findByIdForUpdate('00000000-0000-4000-8000-000000000099')).toBeNull();
    const paid = await repo.markPaid(inv.id);
    expect(paid.status).toBe('paid');
  });

  it('billing alert payload object and listOpen without filter', async () => {
    const alerts = new BillingAlertService();
    const db = getTestDb();
    await db('billing_alerts').insert({
      alert_type: 'obj-payload',
      severity: 'warning',
      payload: { nested: true },
      acknowledged: false,
    });
    const open = await alerts.listOpen();
    expect(open.some((a) => (a.payload as { nested?: boolean }).nested === true)).toBe(true);
    await alerts.evaluatePaymentFailureSpike(10_000);
    await alerts.evaluatePastDueSubscriptions(10_000);
  });

  it('billing forecast yearly baseline and empty cohort', async () => {
    const yearly = await createPlan({ interval: 'yearly', price_cents: 24_000 });
    const customer = await createCustomer();
    await new SubscriptionService().create({ customer_id: customer.id, plan_id: yearly.id });
    const svc = new BillingForecastService();
    expect(await svc.baselineMrr('2026-06-15')).toBe(2000);
    expect(await svc.cohortRetention('2099-12')).toEqual([]);
  });

  it('analytics job returns rollup count on real lock path', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    await new InvoiceService().markPaid(inv.id);
    expect(await runAnalyticsJob(new Date('2026-06-12'), 1)).toBeGreaterThanOrEqual(1);
    expect(await runBillingJob(new Date('2099-12-31'))).toBeGreaterThanOrEqual(0);
  });

  it('app shutdown without listening server closes database', async () => {
    const exit = jest.spyOn(process, 'exit').mockImplementation((() => undefined) as never);
    const closeSpy = jest.spyOn(database, 'closeDb').mockResolvedValue(undefined);
    shutdown('SIGINT');
    await new Promise((r) => setTimeout(r, 30));
    expect(closeSpy).toHaveBeenCalled();
    exit.mockRestore();
  });
});
