import request from 'supertest';
import { createApp } from '../../../src/app';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { PaymentService } from '../../../src/services/PaymentService';
import { PrincipalService } from '../../../src/services/RbacService';
import { AddonProductService } from '../../../src/services/AddonProductService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Route matrix — success and validation branches', () => {
  const app = createApp();

  it('plans and customers validation', async () => {
    expect((await request(app).get('/plans/not-uuid').set('x-api-key', API_KEY)).status).toBe(400);
    const list = await request(app).get('/plans?page=1&limit=5').set('x-api-key', API_KEY);
    expect(list.status).toBe(200);
    const customer = await createCustomer();
    expect((await request(app).patch(`/customers/${customer.id}/country`).set('x-api-key', API_KEY).send({ country: 'USA' })).status).toBe(400);
    expect((await request(app).patch(`/customers/${customer.id}/country`).set('x-api-key', API_KEY).send({ country: 'DE' })).status).toBe(200);
    const plan = await createPlan();
    expect((await request(app).patch(`/plans/${plan.id}/price`).set('x-api-key', API_KEY).send({ price_cents: -1 })).status).toBe(400);
    expect((await request(app).patch(`/plans/${plan.id}/price`).set('x-api-key', API_KEY).send({ price_cents: 1500 })).status).toBe(200);
  });

  it('subscription lifecycle routes', async () => {
    const plan = await createPlan();
    const plan2 = await createPlan({ name: 'Tier2', price_cents: 8000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const code = `addon-${Date.now()}`;
    await new AddonProductService().create({ code, name: 'Seats', price_cents: 300 });
    expect((await request(app).get(`/subscriptions/${sub.id}/items`).set('x-api-key', API_KEY)).status).toBe(200);
    const extend = await request(app)
      .post(`/subscriptions/${sub.id}/extend-trial`)
      .set('x-api-key', API_KEY)
      .send({ extra_days: 3 });
    expect([200, 400]).toContain(extend.status);
    const addon = await request(app)
      .post(`/subscriptions/${sub.id}/addons`)
      .set('x-api-key', API_KEY)
      .send({ addon_code: code, quantity: 2 });
    expect(addon.status).toBe(201);
    const itemId = addon.body.id as string;
    expect(
      (
        await request(app)
          .patch(`/subscriptions/${sub.id}/items/${itemId}/quantity`)
          .set('x-api-key', API_KEY)
          .send({ quantity: 3 })
      ).status
    ).toBe(200);
    const changePlan = await request(app)
      .post(`/subscriptions/${sub.id}/change-plan`)
      .set('x-api-key', API_KEY)
      .send({ plan_id: plan2.id, change_date: sub.current_period_start });
    expect([200, 400]).toContain(changePlan.status);
    expect((await request(app).post(`/subscriptions/${sub.id}/cancel`).set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).post(`/subscriptions/${sub.id}/reactivate`).set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).post('/subscriptions/not-uuid/invoice').set('x-api-key', API_KEY)).status).toBe(400);
  });

  it('payments charge refund and analytics daily by date', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const charge = await request(app)
      .post('/payments/charge')
      .set('x-api-key', API_KEY)
      .set('idempotency-key', `idem-${Date.now()}`)
      .send({ invoice_id: inv.id, simulate_success: true });
    expect(charge.status).toBe(201);
    const refund = await request(app)
      .post(`/payments/${charge.body.id}/refund`)
      .set('x-api-key', API_KEY)
      .send({ amount_cents: 100 });
    expect(refund.status).toBe(200);
    const daily = await request(app).get('/analytics/daily?date=2026-06-01').set('x-api-key', API_KEY);
    expect(daily.status).toBe(200);
  });

  it('operations vault list rotate and workflows history', async () => {
    const customer = await createCustomer();
    const stored = await request(app)
      .post('/operations/vault')
      .set('x-api-key', API_KEY)
      .send({ customer_id: customer.id, brand: 'visa', last4: '4242', exp_month: 12, exp_year: 2030, set_default: true });
    expect(stored.status).toBe(201);
    expect((await request(app).get(`/operations/vault/customer/${customer.id}`).set('x-api-key', API_KEY)).status).toBe(200);
    const principals = new PrincipalService();
    const { principal } = await principals.create('matrix-user', ['billing_admin']);
    const rotated = await request(app)
      .post(`/operations/rbac/principals/${principal.id}/rotate-key`)
      .set('x-api-key', API_KEY);
    expect(rotated.status).toBe(200);
    const plan = await createPlan();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const { WorkflowEngine } = await import('../../../src/services/WorkflowEngine');
    const engine = new WorkflowEngine();
    await engine.seedSubscriptionLifecycle();
    const instance = await engine.start('subscription_lifecycle', 'subscription', sub.id, 'trialing', {});
    expect((await request(app).get(`/workflows/instances/${instance.id}`).set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get(`/workflows/instances/${instance.id}/history`).set('x-api-key', API_KEY)).status).toBe(200);
  });

  it('exports process contracts amend and period reconcile', async () => {
    const customer = await createCustomer();
    const exp = await request(app).post('/exports').set('x-api-key', API_KEY).send({ customer_id: customer.id });
    expect(exp.status).toBe(201);
    const processed = await request(app).post(`/exports/${exp.body.id}/process`).set('x-api-key', API_KEY);
    expect(processed.status).toBe(200);
    expect((await request(app).get(`/exports/customer/${customer.id}`).set('x-api-key', API_KEY)).status).toBe(200);
    const contract = await request(app)
      .post('/contracts')
      .set('x-api-key', API_KEY)
      .send({ customer_id: customer.id, reference: `M-${Date.now()}`, effective_from: '2026-01-01' });
    await request(app).post(`/contracts/${contract.body.id}/activate`).set('x-api-key', API_KEY);
    const amended = await request(app)
      .post(`/contracts/${contract.body.id}/amend`)
      .set('x-api-key', API_KEY)
      .send({ amendment_type: 'price', payload: { mrr_cents: 50000 } });
    expect([200, 400]).toContain(amended.status);
    await request(app)
      .post('/period-closes/open')
      .set('x-api-key', API_KEY)
      .send({ period_start: '2026-07-01', period_end: '2026-07-31' });
    const recon = await request(app)
      .post('/period-closes/reconcile')
      .set('x-api-key', API_KEY)
      .send({ period_start: '2026-07-01', period_end: '2026-07-31' });
    expect(recon.status).toBe(200);
  });

  it('webhook replay by id and feature flag enabled check', async () => {
    await request(app)
      .put('/feature-flags')
      .set('x-api-key', API_KEY)
      .send({ key: 'matrix_flag', enabled: true, rules: { percentage_rollout: 0 } });
    expect((await request(app).get('/feature-flags/matrix_flag/enabled').set('x-api-key', API_KEY)).status).toBe(200);
    const log = await request(app).get('/webhook-replay/log').set('x-api-key', API_KEY);
    expect(log.status).toBe(200);
    if (log.body[0]?.outbox_message_id) {
      const one = await request(app)
        .post(`/webhook-replay/${log.body[0].outbox_message_id}`)
        .set('x-api-key', API_KEY);
      expect([200, 404]).toContain(one.status);
    }
  });
});
