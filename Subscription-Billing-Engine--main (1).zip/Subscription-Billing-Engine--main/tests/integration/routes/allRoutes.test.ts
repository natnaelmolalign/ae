import request from 'supertest';
import { createApp } from '../../../src/app';
import { createCustomer, createPlan } from '../../helpers/factories';
import { PrincipalService } from '../../../src/services/RbacService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Route smoke coverage', () => {
  const app = createApp();

  it('hits analytics revenue quotes and jobs', async () => {
    const daily = await request(app).get('/analytics/daily').set('x-api-key', API_KEY);
    expect(daily.status).toBe(200);
    const revenue = await request(app)
      .get('/revenue/subscriptions/00000000-0000-4000-8000-000000000099/summary')
      .set('x-api-key', API_KEY);
    expect([200, 404]).toContain(revenue.status);
    const jobs = await request(app).get('/jobs/runs').set('x-api-key', API_KEY);
    expect(jobs.status).toBe(200);
  });

  it('hits insights and operations', async () => {
    const customer = await createCustomer();
    const health = await request(app)
      .get(`/insights/customers/${customer.id}/health`)
      .set('x-api-key', API_KEY);
    expect(health.status).toBe(200);
    const compliance = await request(app)
      .get('/operations/compliance/report')
      .set('x-api-key', API_KEY);
    expect(compliance.status).toBe(200);
    const alerts = await request(app).post('/operations/alerts/evaluate').set('x-api-key', API_KEY);
    expect(alerts.status).toBe(200);
  });

  it('hits reports churn and webhook replay log', async () => {
    const churn = await request(app)
      .get('/reports/churn?from=2026-01-01&to=2026-12-31')
      .set('x-api-key', API_KEY);
    expect(churn.status).toBe(200);
    const log = await request(app).get('/webhook-replay/log').set('x-api-key', API_KEY);
    expect(log.status).toBe(200);
  });

  it('stores payment method in vault', async () => {
    const customer = await createCustomer();
    const res = await request(app)
      .post('/operations/vault')
      .set('x-api-key', API_KEY)
      .send({
        customer_id: customer.id,
        brand: 'visa',
        last4: '1111',
        exp_month: 1,
        exp_year: 2031,
      });
    expect(res.status).toBe(201);
  });

  it('lists rbac principals', async () => {
    const list = await new PrincipalService().list();
    expect(list.length).toBeGreaterThan(0);
    const res = await request(app).get('/rbac/principals').set('x-api-key', API_KEY);
    expect(res.status).toBe(200);
  });

  it('feature flag upsert', async () => {
    const res = await request(app)
      .put('/feature-flags')
      .set('x-api-key', API_KEY)
      .send({ key: 'smoke_test', enabled: true, rules: { percentage_rollout: 50 } });
    expect([200, 201]).toContain(res.status);
  });

  it('workflow trigger path', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const { SubscriptionService } = await import('../../../src/services/SubscriptionService');
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const { WorkflowEngine } = await import('../../../src/services/WorkflowEngine');
    const engine = new WorkflowEngine();
    await engine.seedSubscriptionLifecycle();
    const instance = await engine.start(
      'subscription_lifecycle',
      'subscription',
      sub.id,
      'trialing',
      {}
    );
    const triggered = await request(app)
      .post(`/workflows/instances/${instance.id}/trigger`)
      .set('x-api-key', API_KEY)
      .send({ trigger: 'trial_convert' });
    expect(triggered.status).toBe(200);
  });
});
