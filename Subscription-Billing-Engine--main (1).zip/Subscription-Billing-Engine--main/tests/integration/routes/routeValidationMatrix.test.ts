import request from 'supertest';
import { createApp } from '../../../src/app';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { MeteringService } from '../../../src/services/MeteringService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';
const BAD = 'not-a-valid-uuid';

describe('Route validation matrix', () => {
  const app = createApp();

  const expect400 = async (method: 'get' | 'post' | 'patch', path: string, body?: object) => {
    const req = request(app)[method](path).set('x-api-key', API_KEY);
    if (body) req.send(body);
    expect((await req).status).toBe(400);
  };

  it('subscription invalid id on every mutating route', async () => {
    await expect400('get', `/subscriptions/${BAD}`);
    await expect400('post', `/subscriptions/${BAD}/cancel`);
    await expect400('post', `/subscriptions/${BAD}/reactivate`);
    await expect400('post', `/subscriptions/${BAD}/pause`);
    await expect400('post', `/subscriptions/${BAD}/resume`, {});
    await expect400('post', `/subscriptions/${BAD}/change-plan-at-period-end`, { plan_id: BAD });
    await expect400('post', `/subscriptions/${BAD}/change-plan`, { plan_id: BAD });
    await expect400('post', `/subscriptions/${BAD}/extend-trial`, { extra_days: 1 });
    await expect400('get', `/subscriptions/${BAD}/items`);
    await expect400('post', `/subscriptions/${BAD}/addons`, { addon_code: 'x', quantity: 1 });
    await expect400('patch', `/subscriptions/${BAD}/items/${BAD}/quantity`, { quantity: 1 });
    await expect400('post', `/subscriptions/${BAD}/invoice`);
  });

  it('subscription validation bodies', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    await expect400('post', `/subscriptions/${sub.id}/extend-trial`, { extra_days: 0 });
    await expect400('post', `/subscriptions/${sub.id}/change-plan-at-period-end`, { plan_id: 'bad' });
    await expect400('patch', `/subscriptions/${sub.id}/items/${BAD}/quantity`, { quantity: 1 });
    await expect400('post', `/subscriptions/${sub.id}/resume`, { resume_date: 'not-a-date' });
    const otherPlan = await createPlan();
    const scheduled = await request(app)
      .post(`/subscriptions/${sub.id}/change-plan-at-period-end`)
      .set('x-api-key', API_KEY)
      .send({ plan_id: otherPlan.id, as_of: '2026-12-01' });
    expect([200, 400]).toContain(scheduled.status);
  });

  it('subscription invalid item id with valid subscription', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    await expect400('patch', `/subscriptions/${sub.id}/items/${BAD}/quantity`, { quantity: 2 });
  });

  it('policy meters payments customers plans', async () => {
    await expect400('post', '/policy/quote', { subtotal_cents: -1, country: 'US' });
    const seats = await request(app).get('/policy/seat-price?seats=10').set('x-api-key', API_KEY);
    expect(seats.status).toBe(200);
    const unknownMeter = await request(app)
      .get('/meters/unknown-meter-code-xyz')
      .set('x-api-key', API_KEY);
    expect(unknownMeter.status).toBe(404);
    await expect400('post', '/meters/x/usage', { subscription_id: BAD, quantity: 1 });
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const meter = await new MeteringService().createMeter({
      code: `v-${Date.now()}`,
      name: 'V',
      tier_config: [{ up_to: null, unit_price_cents: 1 }],
    });
    const usage = await request(app)
      .post(`/meters/${meter.code}/usage`)
      .set('x-api-key', API_KEY)
      .send({ subscription_id: sub.id, quantity: 5, recorded_at: '2026-06-01T00:00:00Z' });
    expect(usage.status).toBe(204);
    await expect400('post', '/payments/charge', { invoice_id: BAD });
    await expect400('post', `/payments/${BAD}/refund`, { amount_cents: 10 });
    await expect400('get', `/customers/${BAD}`);
    await expect400('get', `/plans/${BAD}`);
    await expect400('patch', `/plans/${BAD}/price`, { price_cents: 100 });
  });

  it('rbac principals and feature flag rollout context', async () => {
    const perms = await request(app).get('/rbac/permissions').set('x-api-key', API_KEY);
    expect(perms.status).toBe(200);
    const roles = await request(app).get('/rbac/roles').set('x-api-key', API_KEY);
    expect(roles.status).toBe(200);
    const created = await request(app)
      .post('/rbac/principals')
      .set('x-api-key', API_KEY)
      .send({ name: `val-${Date.now()}`, roles: ['billing_readonly'] });
    expect(created.status).toBe(201);
    await expect400('post', '/rbac/principals', { name: '', roles: [] });
    await request(app)
      .put('/feature-flags')
      .set('x-api-key', API_KEY)
      .send({ key: 'plan_gate', enabled: true, rules: { plan_ids: [(await createPlan()).id] } });
    const enabled = await request(app)
      .get('/feature-flags/plan_gate/enabled')
      .set('x-api-key', API_KEY)
      .query({ plan_id: (await createPlan()).id });
    expect(enabled.status).toBe(200);
  });

  it('quote send and convert reject invalid ids', async () => {
    expect(
      (await request(app).post(`/quotes/${BAD}/send`).set('x-api-key', API_KEY)).status
    ).toBe(400);
    expect(
      (await request(app).post(`/quotes/${BAD}/convert`).set('x-api-key', API_KEY)).status
    ).toBe(400);
  });

  it('snapshots tax and reconciliation invalid period', async () => {
    const badPeriod = await request(app)
      .post('/snapshots/capture')
      .set('x-api-key', API_KEY)
      .send({ snapshot_type: 'mrr', period_key: 'bad' });
    expect(badPeriod.status).toBe(400);
    const taxBad = await request(app).get('/tax-compliance/not-valid').set('x-api-key', API_KEY);
    expect([400, 404]).toContain(taxBad.status);
  });
});
