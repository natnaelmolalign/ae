import request from 'supertest';
import { createApp } from '../../../src/app';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { MeteringService } from '../../../src/services/MeteringService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Full route coverage', () => {
  const app = createApp();

  it('addons CRUD', async () => {
    const code = `addon-${Date.now()}`;
    const created = await request(app)
      .post('/addons')
      .set('x-api-key', API_KEY)
      .send({ code, name: 'Extra seats', price_cents: 500 });
    expect(created.status).toBe(201);
    const list = await request(app).get('/addons').set('x-api-key', API_KEY);
    expect(list.status).toBe(200);
    const one = await request(app).get(`/addons/${code}`).set('x-api-key', API_KEY);
    expect(one.status).toBe(200);
  });

  it('quotes lifecycle', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const created = await request(app)
      .post('/quotes')
      .set('x-api-key', API_KEY)
      .send({
        customer_id: customer.id,
        expires_at: '2026-12-31',
        lines: [{ description: 'Annual', quantity: 1, unit_price_cents: 12000, plan_id: plan.id }],
      });
    expect(created.status).toBe(201);
    const id = created.body.id;
    const get = await request(app).get(`/quotes/${id}`).set('x-api-key', API_KEY);
    expect(get.status).toBe(200);
    const sent = await request(app).post(`/quotes/${id}/send`).set('x-api-key', API_KEY);
    expect(sent.status).toBe(200);
    const converted = await request(app).post(`/quotes/${id}/convert`).set('x-api-key', API_KEY);
    expect(converted.status).toBe(201);
  });

  it('meters and entitlements', async () => {
    const plan = await createPlan();
    const meter = await new MeteringService().createMeter({
      code: `m-${Date.now()}`,
      name: 'Events',
      tier_config: [{ up_to: null, unit_price_cents: 2 }],
    });
    const meterGet = await request(app).get(`/meters/${meter.code}`).set('x-api-key', API_KEY);
    expect(meterGet.status).toBe(200);
    const sub = await new SubscriptionService().create({ customer_id: (await createCustomer()).id, plan_id: plan.id });
    const usage = await request(app)
      .post(`/meters/${meter.code}/usage`)
      .set('x-api-key', API_KEY)
      .send({ subscription_id: sub.id, quantity: 10 });
    expect(usage.status).toBe(204);
    const ent = await request(app)
      .put(`/plans/${plan.id}/entitlements`)
      .set('x-api-key', API_KEY)
      .send({
        entitlements: [
          {
            feature_key: 'events',
            limit_type: 'count',
            limit_value: 1000,
            reset_interval: 'monthly',
          },
        ],
      });
    expect(ent.status).toBe(200);
    const list = await request(app).get(`/plans/${plan.id}/entitlements`).set('x-api-key', API_KEY);
    expect(list.status).toBe(200);
    const check = await request(app)
      .post(`/plans/${plan.id}/entitlements/check`)
      .set('x-api-key', API_KEY)
      .send({ subscription_id: sub.id, feature_key: 'events' });
    expect(check.status).toBe(200);
  });

  it('credit notes dunning audit coupons', async () => {
    const plan = await createPlan({ price_cents: 3000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const { InvoiceService } = await import('../../../src/services/InvoiceService');
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    const cn = await request(app)
      .post('/credit-notes')
      .set('x-api-key', API_KEY)
      .send({ invoice_id: inv.id, reason: 'goodwill', amount_cents: 100 });
    expect(cn.status).toBe(201);
    const cnGet = await request(app).get(`/credit-notes/${cn.body.id}`).set('x-api-key', API_KEY);
    expect(cnGet.status).toBe(200);
    const dunning = await request(app).get('/dunning-policies/default').set('x-api-key', API_KEY);
    expect(dunning.status).toBe(200);
    const audit = await request(app).get(`/audit/subscription/${sub.id}`).set('x-api-key', API_KEY);
    expect(audit.status).toBe(200);
    const coupon = await request(app)
      .post('/coupons')
      .set('x-api-key', API_KEY)
      .send({ code: `c-${Date.now()}`, discount_type: 'percent', discount_value: 10 });
    expect(coupon.status).toBe(201);
  });

  it('period closes exports contracts schedules policy', async () => {
    const opened = await request(app)
      .post('/period-closes/open')
      .set('x-api-key', API_KEY)
      .send({ period_start: '2026-05-01', period_end: '2026-05-31' });
    expect(opened.status).toBe(201);
    const customer = await createCustomer();
    const exp = await request(app)
      .post('/exports')
      .set('x-api-key', API_KEY)
      .send({ customer_id: customer.id });
    expect(exp.status).toBe(201);
    const contract = await request(app)
      .post('/contracts')
      .set('x-api-key', API_KEY)
      .send({
        customer_id: customer.id,
        reference: `ENT-${Date.now()}`,
        effective_from: '2026-01-01',
        effective_to: '2027-01-01',
        committed_mrr_cents: 100000,
      });
    expect(contract.status).toBe(201);
    const sched = await request(app)
      .post('/schedules')
      .set('x-api-key', API_KEY)
      .send({
        customer_id: customer.id,
        name: 'nightly-billing',
        cadence: 'monthly',
        anchor_day: 1,
      });
    expect(sched.status).toBe(201);
    const policy = await request(app)
      .post('/policy/quote')
      .set('x-api-key', API_KEY)
      .send({ subtotal_cents: 5000, country: 'US' });
    expect(policy.status).toBe(200);
    const seats = await request(app).get('/policy/seat-price?seats=5').set('x-api-key', API_KEY);
    expect(seats.status).toBe(200);
  });

  it('invalid quote id returns 400', async () => {
    const bad = await request(app).get('/quotes/not-a-uuid').set('x-api-key', API_KEY);
    expect(bad.status).toBe(400);
  });
});
