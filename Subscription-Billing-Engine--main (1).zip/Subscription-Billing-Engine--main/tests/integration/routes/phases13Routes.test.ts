import request from 'supertest';
import { createApp } from '../../../src/app';
import { createCustomer } from '../../helpers/factories';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Phase 13-18 API routes', () => {
  const app = createApp();

  it('returns deep health ready probe', async () => {
    const res = await request(app).get('/health/ready');
    expect([200, 503]).toContain(res.status);
    expect(res.body.database).toBeDefined();
  });

  it('quotes policy preview', async () => {
    const res = await request(app)
      .post('/policy/quote')
      .set('x-api-key', API_KEY)
      .send({ subtotal_cents: 5000, country: 'US' });
    expect(res.status).toBe(200);
    expect(res.body.total_cents).toBeGreaterThan(0);
  });

  it('reports MRR snapshot', async () => {
    const res = await request(app)
      .get('/reports/mrr?as_of=2026-06-02')
      .set('x-api-key', API_KEY);
    expect(res.status).toBe(200);
    expect(res.body.mrr_cents).toBeDefined();
  });

  it('creates billing schedule', async () => {
    const customer = await createCustomer();
    const res = await request(app)
      .post('/schedules')
      .set('x-api-key', API_KEY)
      .send({
        customer_id: customer.id,
        name: 'Monthly platform',
        cadence: 'monthly',
        anchor_day: 1,
        line_templates: [{ description: 'Base', amount_cents: 9900, quantity: 1 }],
      });
    expect(res.status).toBe(201);
  });

  it('requests data export', async () => {
    const customer = await createCustomer();
    const res = await request(app)
      .post('/exports')
      .set('x-api-key', API_KEY)
      .send({ customer_id: customer.id });
    expect(res.status).toBe(201);
  });
});
