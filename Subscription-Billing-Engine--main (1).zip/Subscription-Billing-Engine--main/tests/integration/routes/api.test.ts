import request from 'supertest';
import { createApp } from '../../../src/app';

const API_KEY = 'test-api-key-32chars-minimum';

describe('API integration', () => {
  const app = createApp();

  it('creates plan, customer, subscription, and invoice', async () => {
    const planRes = await request(app)
      .post('/plans')
      .set('x-api-key', API_KEY)
      .send({ name: 'Pro', price_cents: 9900, interval: 'monthly' });
    expect(planRes.status).toBe(201);

    const customerRes = await request(app)
      .post('/customers')
      .set('x-api-key', API_KEY)
      .send({ email: 'api@test.com', name: 'API User' });
    expect(customerRes.status).toBe(201);

    const subRes = await request(app)
      .post('/subscriptions')
      .set('x-api-key', API_KEY)
      .send({
        customer_id: customerRes.body.id,
        plan_id: planRes.body.id,
        billing_anchor: '2024-03-01',
      });
    expect(subRes.status).toBe(201);

    const invoiceRes = await request(app)
      .post(`/subscriptions/${subRes.body.id}/invoice`)
      .set('x-api-key', API_KEY);
    expect(invoiceRes.status).toBe(201);
    expect(invoiceRes.body.total_cents).toBeGreaterThanOrEqual(0);
  });

  it('returns request id header', async () => {
    const res = await request(app)
      .get('/health/live')
      .set('x-request-id', 'trace-123');
    expect(res.headers['x-request-id']).toBe('trace-123');
  });
});
