import request from 'supertest';
import { createApp } from '../../../src/app';
import { createCustomer, createPlan } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';
import { InvoiceService } from '../../../src/services/InvoiceService';
import { PrincipalService } from '../../../src/services/RbacService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Route branch coverage', () => {
  const app = createApp();

  it('rejects bad api key and invalid uuids', async () => {
    expect((await request(app).get('/plans')).status).toBe(401);
    expect((await request(app).get('/plans').set('x-api-key', 'wrong-key-32chars-minimumxx')).status).toBe(401);
    expect((await request(app).get('/revenue/invoices/not-uuid/schedule').set('x-api-key', API_KEY)).status).toBe(400);
    expect((await request(app).get('/revenue/subscriptions/not-uuid/summary').set('x-api-key', API_KEY)).status).toBe(400);
    expect((await request(app).get('/credit-notes/not-uuid').set('x-api-key', API_KEY)).status).toBe(400);
    expect((await request(app).get('/quotes/not-uuid').set('x-api-key', API_KEY)).status).toBe(400);
    expect((await request(app).get('/invoices/not-uuid').set('x-api-key', API_KEY)).status).toBe(400);
    expect((await request(app).put('/plans/not-uuid/entitlements').set('x-api-key', API_KEY).send({ entitlements: [] })).status).toBe(400);
  });

  it('insights and export branches', async () => {
    const customer = await createCustomer();
    const plan = await createPlan();
    await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    expect((await request(app).get(`/insights/customers/${customer.id}/health`).set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get(`/insights/customers/${customer.id}/ltv`).set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/insights/at-risk').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/insights/forecast?as_of=2026-06-01').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/insights/projections/subscription').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/insights/cohorts').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/insights/leakage').set('x-api-key', API_KEY)).status).toBe(200);
    const csv = await request(app)
      .get(`/insights/customers/${customer.id}/invoices/export?format=csv`)
      .set('x-api-key', API_KEY);
    expect(csv.status).toBe(200);
    expect(typeof csv.text).toBe('string');
  });

  it('jobs feature flags and webhook replay', async () => {
    expect((await request(app).get('/jobs/runs?job=billing').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/feature-flags').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/feature-flags/smoke/enabled').set('x-api-key', API_KEY)).status).toBe(200);
    const replayAll = await request(app).post('/webhook-replay').set('x-api-key', API_KEY);
    expect(replayAll.status).toBe(200);
  });

  it('reports revenue dunning and analytics', async () => {
    expect((await request(app).get('/reports/ar-aging').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/reports/mrr?as_of=2026-06-01').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/reports/revenue-by-plan').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/dunning-policies').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/dunning-policies/default').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/analytics/daily').set('x-api-key', API_KEY)).status).toBe(200);
  });

  it('waterfall lifecycle board and tax routes', async () => {
    expect((await request(app).get('/waterfall/2026-06').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/waterfall/cohorts/retention').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/waterfall/forecast/history').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/waterfall/2026-06/top-customers').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/waterfall/2026-06/export.csv').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/lifecycle/stages').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/lifecycle/expansion-signals').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/lifecycle/at-risk').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/lifecycle/forecast/scenarios?period=2026-06').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/analytics-board/2026-06/drill-down').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/analytics-board/2026-06/board-pack').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/analytics-board/cohorts/summary').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/tax-compliance/2026-06/eu-vat').set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get('/tax-compliance/2026-06/export.csv').set('x-api-key', API_KEY)).status).toBe(200);
  });

  it('period close close path and rbac principal key', async () => {
    await request(app)
      .post('/period-closes/open')
      .set('x-api-key', API_KEY)
      .send({ period_start: '2026-03-01', period_end: '2026-03-31' });
    const closed = await request(app)
      .post('/period-closes/close')
      .set('x-api-key', API_KEY)
      .send({ period_start: '2026-03-01', period_end: '2026-03-31' });
    expect([200, 409]).toContain(closed.status);
    const principals = new PrincipalService();
    const { principal, apiKey } = await principals.create('route-branch-user', ['billing_admin']);
    expect((await request(app).get('/rbac/principals').set('x-api-key', apiKey)).status).toBe(200);
    expect(principal.id).toBeDefined();
  });

  it('subscriptions and payments edge routes', async () => {
    const plan = await createPlan();
    const plan2 = await createPlan({ name: 'Upgrade', price_cents: 5000 });
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({ customer_id: customer.id, plan_id: plan.id });
    const inv = await new InvoiceService().generateForSubscription(sub, customer.country);
    expect((await request(app).get(`/invoices/${inv.id}`).set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get(`/revenue/invoices/${inv.id}/schedule`).set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).get(`/revenue/subscriptions/${sub.id}/summary`).set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).post(`/subscriptions/${sub.id}/pause`).set('x-api-key', API_KEY)).status).toBe(200);
    expect((await request(app).post(`/subscriptions/${sub.id}/resume`).set('x-api-key', API_KEY).send({})).status).toBe(200);
    const changePlan = await request(app)
      .post(`/subscriptions/${sub.id}/change-plan-at-period-end`)
      .set('x-api-key', API_KEY)
      .send({ plan_id: plan2.id, as_of: sub.current_period_start });
    expect([200, 400]).toContain(changePlan.status);
    expect((await request(app).post(`/subscriptions/not-uuid/cancel`).set('x-api-key', API_KEY)).status).toBe(400);
    expect((await request(app).post(`/invoices/${inv.id}/void`).set('x-api-key', API_KEY)).status).toBe(200);
  });
});
