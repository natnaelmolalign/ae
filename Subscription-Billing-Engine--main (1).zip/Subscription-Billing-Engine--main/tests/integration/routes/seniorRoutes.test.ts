import request from 'supertest';
import { createApp } from '../../../src/app';
import { createPlan, createCustomer } from '../../helpers/factories';
import { SubscriptionService } from '../../../src/services/SubscriptionService';

const API_KEY = process.env.API_KEY ?? 'test-api-key-32chars-minimum';

describe('Senior API routes', () => {
  const app = createApp();

  it('exposes metrics without api key', async () => {
    const res = await request(app).get('/metrics');
    expect(res.status).toBe(200);
    expect(res.text).toBeDefined();
  });

  it('lists rbac permissions for admin', async () => {
    const res = await request(app).get('/rbac/permissions').set('x-api-key', API_KEY);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it('creates workflow instance', async () => {
    const plan = await createPlan();
    const customer = await createCustomer();
    const sub = await new SubscriptionService().create({
      customer_id: customer.id,
      plan_id: plan.id,
    });
    const res = await request(app)
      .post('/workflows/instances')
      .set('x-api-key', API_KEY)
      .send({
        definition_name: 'subscription_lifecycle',
        entity_type: 'subscription',
        entity_id: sub.id,
        initial_state: 'trialing',
      });
    expect(res.status).toBe(201);
    expect(res.body.current_state).toBe('trialing');
  });

  it('lists feature flags', async () => {
    const res = await request(app).get('/feature-flags').set('x-api-key', API_KEY);
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it('opens billing period', async () => {
    const res = await request(app)
      .post('/period-closes/open')
      .set('x-api-key', API_KEY)
      .send({ period_start: '2026-05-01', period_end: '2026-05-31' });
    expect(res.status).toBe(201);
    expect(res.body.status).toBe('open');
  });
});
