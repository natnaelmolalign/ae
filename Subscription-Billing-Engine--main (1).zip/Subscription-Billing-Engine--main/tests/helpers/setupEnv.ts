import dotenv from 'dotenv';

dotenv.config({ path: '.env.test' });
dotenv.config();

process.env.NODE_ENV = 'test';
process.env.API_KEY = 'test-api-key-32chars-minimum';
process.env.LOG_LEVEL = 'error';
process.env.WEBHOOK_URL = '';
process.env.WEBHOOK_SECRET = 'test-webhook-secret-32chars';

import { resetEnvForTests } from '../../src/config/env';

resetEnvForTests();
