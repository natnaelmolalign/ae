﻿import path from 'path';
import { DataType, newDb, IMemoryDb } from 'pg-mem';
import knex, { Knex } from 'knex';
import { v4 as uuidv4 } from 'uuid';
import { setDbForTests, closeDb } from '../../src/config/database';

let memDb: IMemoryDb | null = null;
let memKnex: Knex | null = null;
let backup: ReturnType<IMemoryDb['backup']> | null = null;

function registerPgFunctions(db: IMemoryDb): void {
  db.public.registerFunction({
    name: 'gen_random_uuid',
    returns: DataType.uuid,
    implementation: () => uuidv4(),
    impure: true,
  });
  db.public.registerFunction({
    name: 'now',
    returns: DataType.timestamp,
    implementation: () => new Date(),
    impure: true,
  });
}

export async function setupTestDb(): Promise<Knex> {
  memDb = newDb({ autoCreateForeignKeyIndices: true });
  memDb.registerExtension('pgcrypto', () => undefined);
  registerPgFunctions(memDb);

  memKnex = memDb.adapters.createKnex(undefined, {
    migrations: {
      directory: path.join(__dirname, '../../migrations'),
      extension: 'ts',
    },
  }) as Knex;

  await memKnex.migrate.latest();
  setDbForTests(memKnex);

  const { PrincipalService } = await import('../../src/services/RbacService');
  const { FeatureFlagService } = await import('../../src/services/FeatureFlagService');
  const { RetentionPolicyService } = await import('../../src/services/RetentionPolicyService');
  const { WorkflowEngine } = await import('../../src/services/WorkflowEngine');
  const apiKey = process.env.API_KEY ?? 'test-api-key-32chars-minimum';
  await new PrincipalService().bootstrapFromEnvMasterKey(apiKey);
  await new FeatureFlagService().seedDefaults();
  await new RetentionPolicyService().seedDefaults();
  await new WorkflowEngine().seedSubscriptionLifecycle();
  backup = memDb.backup();
  return memKnex;
}

export function getTestDb(): Knex {
  if (!memKnex) {
    throw new Error('Test database not initialized');
  }
  return memKnex;
}

export async function teardownTestDb(): Promise<void> {
  await closeDb();
  memKnex = null;
  memDb = null;
  backup = null;
}

export async function resetTestDb(): Promise<void> {
  if (!backup) return;
  backup.restore();
}
