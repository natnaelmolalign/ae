import './setupEnv';
import { setupTestDb, teardownTestDb, resetTestDb } from './pgMemDb';

beforeAll(async () => {
  await setupTestDb();
});

beforeEach(async () => {
  await resetTestDb();
});

afterAll(async () => {
  await teardownTestDb();
});
