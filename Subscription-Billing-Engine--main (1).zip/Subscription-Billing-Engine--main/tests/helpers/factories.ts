import { getTestDb } from './pgMemDb';

export async function createPlan(overrides: Record<string, unknown> = {}) {
  const db = getTestDb();
  const [plan] = await db('plans')
    .insert({
      name: 'Basic',
      price_cents: 1000,
      interval: 'monthly',
      features: JSON.stringify(['feature-a']),
      ...overrides,
    })
    .returning('*');
  return plan;
}

export async function createCustomer(overrides: Record<string, unknown> = {}) {
  const db = getTestDb();
  const [customer] = await db('customers')
    .insert({
      email: `user-${Date.now()}@test.com`,
      name: 'Test User',
      country: 'US',
      ...overrides,
    })
    .returning('*');
  return customer;
}

export async function truncateAll(): Promise<void> {
  const db = getTestDb();
  await db.raw(
    'TRUNCATE payment_retries, webhook_events, payments, invoice_line_items, invoices, billing_cycles, credits, subscriptions, coupons, customers, plans RESTART IDENTITY CASCADE'
  );
}
