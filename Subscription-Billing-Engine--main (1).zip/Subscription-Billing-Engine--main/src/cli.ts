import dotenv from 'dotenv';
import { closeDb } from './config/database';
import { runBillingJob } from './jobs/billingJob';
import { runAnalyticsJob } from './jobs/analyticsJob';
import { runOutboxJob } from './jobs/outboxJob';
import { runRetryJob } from './jobs/retryJob';
import { runRetentionJob } from './jobs/retentionJob';
import { runExportJob } from './jobs/exportJob';
import { runForecastJob } from './jobs/forecastJob';
import { WebhookService } from './services/WebhookService';
import { globalMetrics } from './lib/metrics';

dotenv.config();

export async function runCliCommand(command: string): Promise<string> {
  if (!command) {
    throw new Error('Missing CLI command');
  }
  if (command === 'billing') {
    const count = await runBillingJob();
    return `billing job done, invoices generated: ${count}`;
  }
  if (command === 'retry') {
    const count = await runRetryJob();
    return `retry job done, attempts processed: ${count}`;
  }
  if (command === 'webhooks') {
    const count = await new WebhookService().deliverPending();
    return `webhook job done, delivered: ${count}`;
  }
  if (command === 'outbox') {
    const count = await runOutboxJob();
    return `outbox job done, delivered: ${count}`;
  }
  if (command === 'analytics') {
    const days = await runAnalyticsJob(new Date(), 1);
    return `analytics job done, days: ${days}`;
  }
  if (command === 'retention') {
    const result = await runRetentionJob();
    return `retention job done ${JSON.stringify(result)}`;
  }
  if (command === 'metrics-persist') {
    const count = await globalMetrics.persistRecent();
    return `metrics persisted: ${count}`;
  }
  if (command === 'export') {
    const count = await runExportJob();
    return `export job done, processed: ${count}`;
  }
  if (command === 'forecast') {
    const months = await runForecastJob();
    return `forecast job done, months: ${months}`;
  }
  throw new Error(`Unknown command: ${command}`);
}

export async function main(argv: string[] = process.argv): Promise<void> {
  const command = argv[2];
  if (!command) {
    console.error(
      'Usage: node dist/cli.js <billing|retry|webhooks|outbox|analytics|retention|export|forecast|metrics-persist>'
    );
    process.exit(1);
    return;
  }

  try {
    console.log(await runCliCommand(command));
  } finally {
    await closeDb();
  }
}

/* istanbul ignore next */
if (require.main === module) {
  main().catch((err) => {
    console.error(err);
    process.exit(1);
  });
}
