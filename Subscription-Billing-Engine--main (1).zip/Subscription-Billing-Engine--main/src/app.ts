import dotenv from 'dotenv';
import express from 'express';
import helmet from 'helmet';
import { loadEnv } from './config/env';
import { closeDb } from './config/database';
import { logger } from './lib/logger';
import { authMiddleware } from './middleware/auth';
import { errorHandler } from './middleware/errorHandler';
import { rateLimiter } from './middleware/rateLimiter';
import { requestIdMiddleware } from './middleware/requestId';
import { requestLogger } from './middleware/requestLogger';
import { metricsMiddleware } from './middleware/metricsMiddleware';
import { apiVersionMiddleware } from './middleware/apiVersion';
import healthRouter from './routes/health';
import plansRouter from './routes/plans';
import customersRouter from './routes/customers';
import subscriptionsRouter from './routes/subscriptions';
import invoicesRouter from './routes/invoices';
import paymentsRouter from './routes/payments';
import couponsRouter from './routes/coupons';
import metersRouter from './routes/meters';
import entitlementsRouter from './routes/entitlements';
import auditRouter from './routes/audit';
import creditNotesRouter from './routes/creditNotes';
import dunningRouter from './routes/dunning';
import addonsRouter from './routes/addons';
import quotesRouter from './routes/quotes';
import analyticsRouter from './routes/analytics';
import revenueRouter from './routes/revenue';
import jobsRouter from './routes/jobs';
import rbacRouter from './routes/rbac';
import workflowsRouter from './routes/workflows';
import metricsRouter from './routes/metrics';
import featureFlagsRouter from './routes/featureFlags';
import periodClosesRouter from './routes/periodCloses';
import reportsRouter from './routes/reports';
import exportsRouter from './routes/exports';
import contractsRouter from './routes/contracts';
import schedulesRouter from './routes/schedules';
import policyRouter from './routes/policy';
import webhookReplayRouter from './routes/webhookReplay';
import insightsRouter from './routes/insights';
import operationsRouter from './routes/operations';
import snapshotsRouter from './routes/snapshots';
import waterfallRouter from './routes/waterfall';
import reconciliationRouter from './routes/reconciliation';
import analyticsBoardRouter from './routes/analyticsBoard';
import lifecycleRouter from './routes/lifecycle';
import taxComplianceRouter from './routes/taxCompliance';

dotenv.config();
loadEnv();

export function createApp() {
  const app = express();
  app.use(helmet());
  app.use(express.json({ limit: '1mb' }));
  app.use(requestIdMiddleware);
  app.use(requestLogger);
  app.use(metricsMiddleware);
  app.use(apiVersionMiddleware);
  app.use(rateLimiter);

  app.use('/health', healthRouter);
  app.use('/metrics', metricsRouter);

  app.use(authMiddleware);
  app.use('/plans', plansRouter);
  app.use('/customers', customersRouter);
  app.use('/subscriptions', subscriptionsRouter);
  app.use('/invoices', invoicesRouter);
  app.use('/payments', paymentsRouter);
  app.use('/coupons', couponsRouter);
  app.use('/meters', metersRouter);
  app.use('/plans/:planId/entitlements', entitlementsRouter);
  app.use('/audit', auditRouter);
  app.use('/credit-notes', creditNotesRouter);
  app.use('/dunning-policies', dunningRouter);
  app.use('/addons', addonsRouter);
  app.use('/quotes', quotesRouter);
  app.use('/analytics', analyticsRouter);
  app.use('/revenue', revenueRouter);
  app.use('/jobs', jobsRouter);
  app.use('/rbac', rbacRouter);
  app.use('/workflows', workflowsRouter);
  app.use('/feature-flags', featureFlagsRouter);
  app.use('/period-closes', periodClosesRouter);
  app.use('/reports', reportsRouter);
  app.use('/exports', exportsRouter);
  app.use('/contracts', contractsRouter);
  app.use('/schedules', schedulesRouter);
  app.use('/policy', policyRouter);
  app.use('/webhook-replay', webhookReplayRouter);
  app.use('/insights', insightsRouter);
  app.use('/operations', operationsRouter);
  app.use('/snapshots', snapshotsRouter);
  app.use('/waterfall', waterfallRouter);
  app.use('/reconciliation', reconciliationRouter);
  app.use('/analytics-board', analyticsBoardRouter);
  app.use('/lifecycle', lifecycleRouter);
  app.use('/tax-compliance', taxComplianceRouter);

  app.use(errorHandler);
  return app;
}

let server: ReturnType<express.Application['listen']> | null = null;

export function startServer() {
  const listenPort = Number(process.env.PORT || 3000);
  const app = createApp();
  server = app.listen(listenPort, () => {
    logger.info('server_started', { port: listenPort });
  });
  return server;
}

/** Exposed for graceful shutdown tests only. */
export function shutdown(signal: string) {
  logger.info('shutdown_signal', { signal });
  if (server) {
    server.close(async () => {
      await closeDb();
      process.exit(0);
    });
  } else {
    void closeDb().then(() => process.exit(0));
  }
}

/* istanbul ignore next */
if (require.main === module) {
  startServer();
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

export default createApp;
