import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface WaterfallStep {
  label: string;
  amount_cents: number;
  cumulative_cents: number;
  category: 'gross' | 'discount' | 'tax' | 'refund' | 'net';
}

export interface WaterfallReport {
  period_key: string;
  currency: string;
  steps: WaterfallStep[];
  net_revenue_cents: number;
  invoice_count: number;
  subscription_count: number;
}

export interface CohortRow {
  cohort_month: string;
  customers: number;
  mrr_cents: number;
  retained_pct: number;
}

/**
 * Builds revenue waterfall and cohort retention views from invoice/payment facts.
 */
export class BillingWaterfallService {
  async buildForPeriod(periodKey: string, currency = 'USD'): Promise<WaterfallReport> {
    const { start, end } = this.parsePeriod(periodKey);
    const invoices = await getDb()('invoices')
      .whereBetween('created_at', [start, end])
      .select('subtotal_cents', 'tax_cents', 'discount_cents', 'total_cents', 'status');
    const payments = await getDb()('payments')
      .whereBetween('attempted_at', [start, end])
      .where({ status: 'succeeded' })
      .sum({ collected: 'amount_cents' })
      .first();
    const creditNotes = await getDb()('credit_notes')
      .whereBetween('created_at', [start, end])
      .sum({ refunded: 'amount_cents' })
      .first();

    const gross = invoices.reduce((s, i) => s + Number(i.subtotal_cents ?? 0), 0);
    const discounts = invoices.reduce((s, i) => s + Number(i.discount_cents ?? 0), 0);
    const tax = invoices.reduce((s, i) => s + Number(i.tax_cents ?? 0), 0);
    const refunds = Number(creditNotes?.refunded ?? 0);
    const collected = Number(payments?.collected ?? 0);

    const steps: WaterfallStep[] = [];
    let cumulative = 0;
    const push = (label: string, amount: number, category: WaterfallStep['category']) => {
      cumulative += amount;
      steps.push({ label, amount_cents: amount, cumulative_cents: cumulative, category });
    };

    push('Gross subtotal', gross, 'gross');
    push('Discounts', -discounts, 'discount');
    push('Tax', tax, 'tax');
    push('Credit notes', -refunds, 'refund');
    push('Cash collected', collected - cumulative, 'net');

    const subs = await getDb()('subscriptions')
      .whereBetween('created_at', [start, end])
      .count({ c: 'id' })
      .first();

    return {
      period_key: periodKey,
      currency,
      steps,
      net_revenue_cents: cumulative,
      invoice_count: invoices.length,
      subscription_count: Number(subs?.c ?? 0),
    };
  }

  async compareWaterfalls(fromKey: string, toKey: string) {
    const from = await this.buildForPeriod(fromKey);
    const to = await this.buildForPeriod(toKey);
    return {
      from: from.net_revenue_cents,
      to: to.net_revenue_cents,
      delta_cents: to.net_revenue_cents - from.net_revenue_cents,
      invoice_delta: to.invoice_count - from.invoice_count,
    };
  }

  async cohortRetention(monthsBack = 6): Promise<CohortRow[]> {
    const rows: CohortRow[] = [];
    const now = new Date();
    for (let i = monthsBack; i >= 0; i--) {
      const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
      const key = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
      const { start, end } = this.parsePeriod(key);
      const created = await getDb()('customers').whereBetween('created_at', [start, end]).pluck('id');
      if (created.length === 0) {
        rows.push({ cohort_month: key, customers: 0, mrr_cents: 0, retained_pct: 0 });
        continue;
      }
      const active = await getDb()('subscriptions')
        .whereIn('customer_id', created)
        .whereIn('status', ['active', 'trial', 'past_due'])
        .count({ c: 'id' })
        .first();
      const mrrRow = await getDb()('subscriptions as s')
        .join('plans as p', 'p.id', 's.plan_id')
        .whereIn('s.customer_id', created)
        .whereIn('s.status', ['active', 'trial', 'past_due'])
        .sum({ mrr: 'p.price_cents' })
        .first();
      rows.push({
        cohort_month: key,
        customers: created.length,
        mrr_cents: Number(mrrRow?.mrr ?? 0),
        retained_pct: Math.round((Number(active?.c ?? 0) / created.length) * 100),
      });
    }
    return rows;
  }

  async exportCsv(periodKey: string): Promise<string> {
    const report = await this.buildForPeriod(periodKey);
    const header = 'label,amount_cents,cumulative_cents,category';
    const lines = report.steps.map(
      (s) => `${s.label},${s.amount_cents},${s.cumulative_cents},${s.category}`
    );
    return [header, ...lines, `net,${report.net_revenue_cents},,`].join('\n');
  }

  async topCustomersByRevenue(periodKey: string, limit = 10) {
    const { start, end } = this.parsePeriod(periodKey);
    return getDb()('payments as pay')
      .join('invoices as inv', 'inv.id', 'pay.invoice_id')
      .join('subscriptions as sub', 'sub.id', 'inv.subscription_id')
      .join('customers as c', 'c.id', 'sub.customer_id')
      .whereBetween('pay.attempted_at', [start, end])
      .where('pay.status', 'succeeded')
      .groupBy('c.id', 'c.email', 'c.name')
      .select('c.id', 'c.email', 'c.name')
      .sum({ revenue_cents: 'pay.amount_cents' })
      .orderBy('revenue_cents', 'desc')
      .limit(limit);
  }

  async agingBuckets(asOf = new Date()) {
    const buckets = [
      { label: '0-30', min: 0, max: 30 },
      { label: '31-60', min: 31, max: 60 },
      { label: '61-90', min: 61, max: 90 },
      { label: '90+', min: 91, max: 9999 },
    ];
    const open = await getDb()('invoices').whereIn('status', ['pending', 'open']).select('total_cents', 'created_at');
    return buckets.map((b) => {
      const amount = open
        .filter((inv) => {
          const days = Math.floor((asOf.getTime() - new Date(inv.created_at as string).getTime()) / 86400000);
          return days >= b.min && days <= b.max;
        })
        .reduce((s, inv) => s + Number(inv.total_cents), 0);
      return { bucket: b.label, outstanding_cents: amount };
    });
  }

  async forecastFromHistory(months = 3): Promise<{ month: string; projected_cents: number }[]> {
    const history: { month: string; projected_cents: number }[] = [];
    const now = new Date();
    for (let i = months; i >= 1; i--) {
      const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
      const key = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
      const report = await this.buildForPeriod(key);
      history.push({ month: key, projected_cents: report.net_revenue_cents });
    }
    const avg =
      history.length === 0 ? 0 : Math.round(history.reduce((s, h) => s + h.projected_cents, 0) / history.length);
    const next = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
    const nextKey = `${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, '0')}`;
    return [...history, { month: nextKey, projected_cents: avg }];
  }

  private parsePeriod(periodKey: string): { start: Date; end: Date } {
    if (/^\d{4}-\d{2}$/.test(periodKey)) {
      const [y, m] = periodKey.split('-').map(Number);
      return {
        start: new Date(Date.UTC(y, m - 1, 1)),
        end: new Date(Date.UTC(y, m, 0, 23, 59, 59, 999)),
      };
    }
    throw new AppError(400, 'period_key must be YYYY-MM');
  }
}
