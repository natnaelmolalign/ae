import { getDb } from '../config/database';
import path from 'path';
import fs from 'fs';

export interface HealthReport {
  status: 'ok' | 'degraded';
  database: boolean;
  migrations: { pending: number; latest: string | null };
  disk: { ok: boolean };
  version: string;
}

export class HealthProbeService {
  async probe(): Promise<HealthReport> {
    let database = false;
    try {
      await getDb().raw('SELECT 1');
      database = true;
    } catch {
      database = false;
    }

    const pending = await this.pendingMigrations();
    const latest = await this.latestAppliedMigration();
    const diskOk = this.checkDisk();

    const status = database && pending === 0 && diskOk ? 'ok' : 'degraded';
    return {
      status,
      database,
      migrations: { pending, latest },
      disk: { ok: diskOk },
      version: process.env.npm_package_version ?? '0.0.0',
    };
  }

  private async pendingMigrations(): Promise<number> {
    try {
      const list = await getDb().migrate.list();
      const pending = (list[1] as { file: string }[]) ?? [];
      return pending.length;
    } catch {
      return -1;
    }
  }

  private async latestAppliedMigration(): Promise<string | null> {
    const row = await getDb()('knex_migrations').orderBy('id', 'desc').first();
    return row ? (row.name as string) : null;
  }

  private checkDisk(): boolean {
    try {
      const dir = path.join(process.cwd(), 'migrations');
      return fs.existsSync(dir);
    } catch {
      return false;
    }
  }
}
