import { getDb } from '../config/database';

export interface LeakageFinding {
  type: string;
  entity_id: string;
  amount_cents: number;
  description: string;
}

export class RevenueLeakageService {
  async scan(): Promise<LeakageFinding[]> {
    const findings: LeakageFinding[] = [];
    findings.push(...(await this.unbilledActiveSubscriptions()));
    findings.push(...(await this.openInvoicesPastDue()));
    findings.push(...(await this.failedPaymentsWithoutRetry()));
    return findings;
  }

  private async unbilledActiveSubscriptions(): Promise<LeakageFinding[]> {
    const monthStart = new Date();
    monthStart.setDate(1);
    const monthStartStr = monthStart.toISOString().slice(0, 10);
    const active = await getDb()('subscriptions')
      .whereIn('status', ['active', 'past_due'])
      .select('id', 'plan_id');
    const findings: LeakageFinding[] = [];
    for (const s of active) {
      const inv = await getDb()('invoices')
        .where({ subscription_id: s.id })
        .andWhere('issued_at', '>=', monthStartStr)
        .first();
      if (!inv) {
        findings.push({
          type: 'unbilled_subscription',
          entity_id: s.id as string,
          amount_cents: 0,
          description: 'Active subscription with no invoice this month',
        });
      }
    }
    return findings;
  }

  private async openInvoicesPastDue(): Promise<LeakageFinding[]> {
    const today = new Date().toISOString().slice(0, 10);
    const rows = await getDb()('invoices')
      .where('status', 'pending')
      .andWhere('due_date', '<', today);
    return rows.map((i) => ({
      type: 'past_due_invoice',
      entity_id: i.id as string,
      amount_cents: Number(i.total_cents),
      description: `Open invoice past due ${i.due_date}`,
    }));
  }

  private async failedPaymentsWithoutRetry(): Promise<LeakageFinding[]> {
    const rows = await getDb()('payments as p')
      .leftJoin('payment_retries as r', 'r.invoice_id', 'p.invoice_id')
      .where('p.status', 'failed')
      .whereNull('r.id')
      .select('p.id', 'p.amount_cents', 'p.invoice_id');
    return rows.map((p) => ({
      type: 'failed_payment_no_retry',
      entity_id: p.id as string,
      amount_cents: Number(p.amount_cents),
      description: `Failed payment on invoice ${p.invoice_id}`,
    }));
  }

  async totalLeakageCents(): Promise<number> {
    const findings = await this.scan();
    return findings.reduce((s, f) => s + f.amount_cents, 0);
  }
}
