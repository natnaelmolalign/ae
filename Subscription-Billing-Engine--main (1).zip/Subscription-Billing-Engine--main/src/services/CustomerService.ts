import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import type { CreateCustomerInput, Customer } from '../models/Customer';

export class CustomerService {
  async create(input: CreateCustomerInput): Promise<Customer> {
    const [row] = await getDb()('customers')
      .insert({
        email: input.email.toLowerCase(),
        name: input.name,
        country: input.country || 'US',
      })
      .returning('*');
    return row as Customer;
  }

  async getById(id: string): Promise<Customer> {
    const row = await getDb()('customers').where({ id }).first();
    if (!row) throw new AppError(404, 'Customer not found');
    return row as Customer;
  }

  async updateCountry(id: string, country: string): Promise<Customer> {
    const [row] = await getDb()('customers')
      .where({ id })
      .update({ country, updated_at: getDb().fn.now() })
      .returning('*');
    if (!row) throw new AppError(404, 'Customer not found');
    return row as Customer;
  }
}
