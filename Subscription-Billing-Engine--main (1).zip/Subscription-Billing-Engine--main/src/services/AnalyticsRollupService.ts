import { getDb } from '../config/database';
import { toDateString } from '../utils/dateUtils';
import { subDays } from 'date-fns';

export interface DailyStats {
  stat_date: string;
  mrr_cents: number;
  new_subscriptions: number;
  cancelled_subscriptions: number;
  failed_payments: number;
  invoices_issued: number;
  revenue_recognized_cents: number;
}

export class AnalyticsRollupService {
  async rollupDay(statDate: Date): Promise<DailyStats> {
    const db = getDb();
    const dayStr = toDateString(statDate);

    const activeSubs = await db('subscriptions').where({ status: 'active' });
    let mrrCents = 0;
    for (const sub of activeSubs) {
      const plan = await db('plans').where({ id: sub.plan_id }).first();
      if (!plan) continue;
      const price = Number(plan.price_cents);
      mrrCents += plan.interval === 'yearly' ? Math.round(price / 12) : price;
      const items = await db('subscription_items')
        .where({ subscription_id: sub.id, active: true, item_type: 'addon' });
      for (const item of items) {
        mrrCents += Number(item.unit_price_cents) * Number(item.quantity);
      }
    }

    const dayStart = `${dayStr}T00:00:00.000Z`;
    const dayEnd = `${dayStr}T23:59:59.999Z`;
    const newSubsRow = await db('subscriptions')
      .where('created_at', '>=', dayStart)
      .andWhere('created_at', '<=', dayEnd)
      .count('* as c');
    const cancelledRow = await db('subscriptions')
      .where('cancelled_at', dayStr)
      .count('* as c');
    const failedRow = await db('payments')
      .where({ status: 'failed' })
      .where('attempted_at', '>=', dayStart)
      .andWhere('attempted_at', '<=', dayEnd)
      .count('* as c');
    const invoicesRow = await db('invoices')
      .where('issued_at', dayStr)
      .count('* as c');
    const recognizedRow = await db('revenue_schedules')
      .where({ status: 'recognized', schedule_date: dayStr })
      .sum('amount_cents as total');

    const stats: DailyStats = {
      stat_date: dayStr,
      mrr_cents: mrrCents,
      new_subscriptions: Number((newSubsRow[0] as { c: string }).c),
      cancelled_subscriptions: Number((cancelledRow[0] as { c: string }).c),
      failed_payments: Number((failedRow[0] as { c: string }).c),
      invoices_issued: Number((invoicesRow[0] as { c: string }).c),
      revenue_recognized_cents: Number((recognizedRow[0] as { total: string })?.total ?? 0),
    };

    const existing = await db('billing_daily_stats').where({ stat_date: dayStr }).first();
    if (existing) {
      await db('billing_daily_stats').where({ stat_date: dayStr }).update({
        ...stats,
        updated_at: db.fn.now(),
      });
    } else {
      await db('billing_daily_stats').insert(stats);
    }

    return stats;
  }

  async rollupRange(endDate: Date, daysBack = 1): Promise<number> {
    let count = 0;
    for (let i = 0; i < daysBack; i++) {
      const d = subDays(endDate, i);
      await this.rollupDay(d);
      count += 1;
    }
    return count;
  }

  async getDaily(statDate: string): Promise<DailyStats | null> {
    const row = await getDb()('billing_daily_stats').where({ stat_date: statDate }).first();
    return row ? (row as DailyStats) : null;
  }

  async listRecent(limit = 30): Promise<DailyStats[]> {
    return getDb()('billing_daily_stats').orderBy('stat_date', 'desc').limit(limit);
  }
}
