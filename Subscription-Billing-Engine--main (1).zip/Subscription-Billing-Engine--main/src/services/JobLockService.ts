import type { Knex } from 'knex';
import { getDb } from '../config/database';
import { childLogger } from '../lib/logger';

const log = childLogger({ component: 'job_lock' });

export type JobName = 'billing' | 'retry' | 'outbox' | 'analytics';

export interface JobRunResult<T> {
  skipped: boolean;
  runId?: string;
  result?: T;
}

export class JobLockService {
  async runExclusive<T>(jobName: JobName, fn: () => Promise<T>): Promise<JobRunResult<T>> {
    const db = getDb();
    const running = await db('job_runs')
      .where({ job_name: jobName, status: 'running' })
      .andWhere('started_at', '>', new Date(Date.now() - 2 * 60 * 60 * 1000))
      .first();

    if (running) {
      await this.recordRun(db, jobName, 'skipped', { reason: 'already_running' });
      log.warn('job_skipped', { jobName });
      return { skipped: true, runId: running.id as string };
    }

    const runId = await this.recordRun(db, jobName, 'running');
    try {
      const result = await fn();
      await db('job_runs').where({ id: runId }).update({
        status: 'completed',
        finished_at: new Date(),
        result_json: JSON.stringify({ ok: true }),
        last_error: null,
      });
      return { skipped: false, runId, result };
    } catch (err) {
      await db('job_runs').where({ id: runId }).update({
        status: 'failed',
        finished_at: new Date(),
        last_error: err instanceof Error ? err.message : String(err),
      });
      throw err;
    }
  }

  private async recordRun(
    db: Knex,
    jobName: string,
    status: string,
    result?: Record<string, unknown>
  ): Promise<string> {
    const [row] = await db('job_runs')
      .insert({
        job_name: jobName,
        status,
        result_json: result ? JSON.stringify(result) : null,
      })
      .returning('id');
    return row.id as string;
  }

  async listRecent(jobName?: string, limit = 20): Promise<Record<string, unknown>[]> {
    const q = getDb()('job_runs').orderBy('started_at', 'desc').limit(limit);
    if (jobName) q.where({ job_name: jobName });
    return q;
  }
}
