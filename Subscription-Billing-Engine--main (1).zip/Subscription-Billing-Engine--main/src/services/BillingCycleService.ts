import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import type { BillingInterval } from '../models/Plan';
import {
  addBillingInterval,
  parseDate,
  periodEndFromStart,
  toDateString,
} from '../utils/dateUtils';

export interface BillingCycle {
  id: string;
  subscription_id: string;
  period_start: string;
  period_end: string;
}

export class BillingCycleService {
  async createForPeriod(
    subscriptionId: string,
    periodStart: Date,
    interval: BillingInterval,
    anchorDay: number
  ): Promise<BillingCycle> {
    const periodEnd = periodEndFromStart(periodStart, interval, anchorDay);
    const db = getDb();
    const existing = await db('billing_cycles')
      .where({
        subscription_id: subscriptionId,
        period_start: toDateString(periodStart),
      })
      .first();
    if (existing) {
      return existing as BillingCycle;
    }
    const [cycle] = await db('billing_cycles')
      .insert({
        subscription_id: subscriptionId,
        period_start: toDateString(periodStart),
        period_end: toDateString(periodEnd),
      })
      .returning('*');
    return cycle as BillingCycle;
  }

  async advancePeriod(
    currentPeriodEnd: string,
    interval: BillingInterval,
    anchorDay: number
  ): Promise<{ periodStart: string; periodEnd: string }> {
    const nextStart = addBillingInterval(parseDate(currentPeriodEnd), interval, anchorDay);
    const nextEnd = periodEndFromStart(nextStart, interval, anchorDay);
    return {
      periodStart: toDateString(nextStart),
      periodEnd: toDateString(nextEnd),
    };
  }

  async getById(id: string): Promise<BillingCycle> {
    const row = await getDb()('billing_cycles').where({ id }).first();
    if (!row) throw new AppError(404, 'Billing cycle not found');
    return row as BillingCycle;
  }
}
