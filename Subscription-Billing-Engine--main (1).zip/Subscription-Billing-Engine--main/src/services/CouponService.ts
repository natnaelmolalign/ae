import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import type { Coupon, DiscountType } from '../models/Coupon';
import { applyFixedDiscount, applyPercentDiscount } from '../utils/currencyUtils';

export class CouponService {
  async create(input: {
    code: string;
    discount_type: DiscountType;
    discount_value: number;
    recurring?: boolean;
    expires_at?: Date;
    usage_limit?: number;
    plan_ids?: string[];
  }): Promise<Coupon> {
    const [row] = await getDb()('coupons')
      .insert({
        code: input.code.toUpperCase(),
        discount_type: input.discount_type,
        discount_value: input.discount_value,
        recurring: input.recurring ?? false,
        expires_at: input.expires_at ?? null,
        usage_limit: input.usage_limit ?? null,
        plan_ids: input.plan_ids ? JSON.stringify(input.plan_ids) : null,
      })
      .returning('*');
    return this.map(row);
  }

  async validateAndApply(
    code: string,
    planId: string,
    subtotalCents: number
  ): Promise<{ coupon: Coupon; discountCents: number }> {
    const coupon = await this.getByCode(code);
    if (coupon.expires_at && new Date() > coupon.expires_at) {
      throw new AppError(400, 'Coupon expired', 'COUPON_EXPIRED');
    }
    if (coupon.usage_limit !== null && coupon.usage_count >= coupon.usage_limit) {
      throw new AppError(400, 'Coupon usage limit reached', 'COUPON_LIMIT');
    }
    if (coupon.plan_ids && !coupon.plan_ids.includes(planId)) {
      throw new AppError(400, 'Coupon not valid for this plan', 'COUPON_PLAN');
    }

    const after =
      coupon.discount_type === 'percent'
        ? applyPercentDiscount(subtotalCents, coupon.discount_value)
        : applyFixedDiscount(subtotalCents, coupon.discount_value);
    const discountCents = subtotalCents - after;
    return { coupon, discountCents };
  }

  async redeem(couponId: string, trx = getDb()): Promise<void> {
    const row = await trx('coupons').where({ id: couponId }).forUpdate().first();
    if (!row) throw new AppError(404, 'Coupon not found');
    if (row.usage_limit !== null && row.usage_count >= row.usage_limit) {
      throw new AppError(400, 'Coupon usage limit reached', 'COUPON_LIMIT');
    }
    const nextUsage = Number(row.usage_count) + 1;
    await trx('coupons').where({ id: couponId }).update({ usage_count: nextUsage });
  }

  async getByCode(code: string): Promise<Coupon> {
    const row = await getDb()('coupons').where({ code: code.toUpperCase() }).first();
    if (!row) throw new AppError(404, 'Coupon not found');
    return this.map(row);
  }

  applyDiscount(subtotalCents: number, coupon: Coupon): number {
    if (coupon.discount_type === 'percent') {
      return subtotalCents - (subtotalCents - applyPercentDiscount(subtotalCents, coupon.discount_value));
    }
    return subtotalCents - applyFixedDiscount(subtotalCents, coupon.discount_value);
  }

  private map(row: Record<string, unknown>): Coupon {
    const planIds =
      row.plan_ids == null
        ? null
        : typeof row.plan_ids === 'string'
          ? JSON.parse(row.plan_ids as string)
          : (row.plan_ids as string[]);
    return {
      id: row.id as string,
      code: row.code as string,
      discount_type: row.discount_type as DiscountType,
      discount_value: row.discount_value as number,
      recurring: row.recurring as boolean,
      expires_at: row.expires_at as Date | null,
      usage_limit: row.usage_limit as number | null,
      usage_count: row.usage_count as number,
      plan_ids: planIds,
      created_at: row.created_at as Date,
      updated_at: row.updated_at as Date,
    };
  }
}
