import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { CreditService } from './CreditService';
import { InvoiceService } from './InvoiceService';
import { AuditService } from './AuditService';
import { DomainEventPublisher } from './DomainEventPublisher';

export class CreditNoteService {
  constructor(
    private invoiceService = new InvoiceService(),
    private creditService = new CreditService(),
    private audit = new AuditService(),
    private events = new DomainEventPublisher()
  ) {}

  async issue(input: {
    invoice_id: string;
    amount_cents: number;
    reason: string;
  }): Promise<Record<string, unknown>> {
    if (input.amount_cents <= 0) {
      throw new AppError(400, 'Credit note amount must be positive');
    }

    const invoice = await this.invoiceService.getById(input.invoice_id);
    if (invoice.status === 'void') {
      throw new AppError(400, 'Cannot issue credit note for void invoice');
    }
    if (input.amount_cents > invoice.total_cents) {
      throw new AppError(400, 'Credit note cannot exceed invoice total');
    }

    const sub = await getDb()('subscriptions').where({ id: invoice.subscription_id }).first();
    if (!sub) throw new AppError(404, 'Subscription not found');

    return getDb().transaction(async (trx) => {
      const [note] = await trx('credit_notes')
        .insert({
          customer_id: sub.customer_id,
          invoice_id: invoice.id,
          amount_cents: input.amount_cents,
          reason: input.reason,
          status: 'applied',
          issued_at: trx.fn.now(),
        })
        .returning('*');

      await this.creditService.issue(
        {
          customer_id: sub.customer_id as string,
          amount_cents: input.amount_cents,
          reason: `Credit note ${note.id}: ${input.reason}`,
          subscription_id: sub.id as string,
        },
        trx
      );

      const event = await this.events.publish(
        {
          eventType: 'credit_note.issued',
          aggregateType: 'credit_note',
          aggregateId: note.id as string,
          payload: {
            credit_note_id: note.id,
            invoice_id: invoice.id,
            amount_cents: input.amount_cents,
          },
        },
        trx
      );

      await this.audit.record(
        {
          entityType: 'credit_note',
          entityId: note.id as string,
          action: 'issued',
          afterState: note as Record<string, unknown>,
          domainEventId: event.id,
        },
        trx
      );

      return note as Record<string, unknown>;
    });
  }

  async getById(id: string): Promise<Record<string, unknown>> {
    const row = await getDb()('credit_notes').where({ id }).first();
    if (!row) throw new AppError(404, 'Credit note not found');
    return row;
  }
}
