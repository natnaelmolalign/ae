import type { Knex } from 'knex';
import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface UsageTier {
  up_to: number | null;
  unit_price_cents: number;
}

export interface Meter {
  id: string;
  code: string;
  name: string;
  aggregation: string;
  tier_config: UsageTier[];
  active: boolean;
}

export class MeteringService {
  async createMeter(input: {
    code: string;
    name: string;
    aggregation?: string;
    tier_config: UsageTier[];
  }): Promise<Meter> {
    const [row] = await getDb()('meters')
      .insert({
        code: input.code.toLowerCase(),
        name: input.name,
        aggregation: input.aggregation ?? 'sum',
        tier_config: JSON.stringify(input.tier_config),
      })
      .returning('*');
    return this.map(row);
  }

  async recordUsage(
    input: {
      meter_code: string;
      subscription_id: string;
      quantity: number;
      recorded_at?: Date;
      idempotency_key?: string;
    },
    trx: Knex.Transaction | Knex = getDb()
  ): Promise<void> {
    const meter = await trx('meters').where({ code: input.meter_code.toLowerCase() }).first();
    if (!meter) throw new AppError(404, 'Meter not found');

    const existing = input.idempotency_key
      ? await trx('usage_records')
          .where({
            meter_id: meter.id,
            subscription_id: input.subscription_id,
            idempotency_key: input.idempotency_key,
          })
          .first()
      : null;
    if (existing) return;

    await trx('usage_records').insert({
      meter_id: meter.id,
      subscription_id: input.subscription_id,
      quantity: input.quantity,
      recorded_at: input.recorded_at ?? new Date(),
      idempotency_key: input.idempotency_key ?? null,
    });
  }

  async aggregateForPeriod(
    subscriptionId: string,
    meterCode: string,
    periodStart: Date,
    periodEnd: Date
  ): Promise<number> {
    const meter = await getDb()('meters').where({ code: meterCode.toLowerCase() }).first();
    if (!meter) throw new AppError(404, 'Meter not found');

    const rows = await getDb()('usage_records')
      .where({ subscription_id: subscriptionId, meter_id: meter.id })
      .andWhere('recorded_at', '>=', periodStart)
      .andWhere('recorded_at', '<=', periodEnd);

    if (rows.length === 0) return 0;
    if (meter.aggregation === 'max') {
      return Math.max(...rows.map((r) => Number(r.quantity)));
    }
    return rows.reduce((sum, r) => sum + Number(r.quantity), 0);
  }

  rateQuantity(tiers: UsageTier[], quantity: number): number {
    let remaining = quantity;
    let totalCents = 0;
    let prevCap = 0;

    for (const tier of tiers) {
      const cap = tier.up_to === null ? Infinity : tier.up_to;
      const band = Math.min(remaining, cap - prevCap);
      if (band <= 0) break;
      totalCents += Math.round(band * tier.unit_price_cents);
      remaining -= band;
      prevCap = cap;
      if (remaining <= 0) break;
    }
    return totalCents;
  }

  async ratedChargeForPeriod(
    subscriptionId: string,
    meterCode: string,
    periodStart: Date,
    periodEnd: Date
  ): Promise<{ quantity: number; amount_cents: number }> {
    const meter = await this.getByCode(meterCode);
    const quantity = await this.aggregateForPeriod(
      subscriptionId,
      meterCode,
      periodStart,
      periodEnd
    );
    return {
      quantity,
      amount_cents: this.rateQuantity(meter.tier_config, quantity),
    };
  }

  async getByCode(code: string): Promise<Meter> {
    const row = await getDb()('meters').where({ code: code.toLowerCase() }).first();
    if (!row) throw new AppError(404, 'Meter not found');
    return this.map(row);
  }

  private map(row: Record<string, unknown>): Meter {
    const tiers =
      typeof row.tier_config === 'string'
        ? JSON.parse(row.tier_config as string)
        : (row.tier_config as UsageTier[]);
    return {
      id: row.id as string,
      code: row.code as string,
      name: row.name as string,
      aggregation: row.aggregation as string,
      tier_config: tiers,
      active: row.active as boolean,
    };
  }
}
