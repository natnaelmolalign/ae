import { getDb } from '../config/database';

export interface LifecycleStage {
  stage: 'trial' | 'active' | 'at_risk' | 'churned' | 'won_back';
  customer_count: number;
  mrr_cents: number;
}

export interface TransitionMetric {
  from_status: string;
  to_status: string;
  count: number;
}

export interface ExpansionSignal {
  customer_id: string;
  email: string;
  signal: string;
  score: number;
}

/**
 * Analyzes subscription lifecycle stages and expansion/contraction signals for GTM teams.
 */
export class CustomerLifecycleAnalyticsService {
  async stageDistribution(): Promise<LifecycleStage[]> {
    const rows = await getDb()('subscriptions as s')
      .join('customers as c', 'c.id', 's.customer_id')
      .join('plans as p', 'p.id', 's.plan_id')
      .groupBy('s.status')
      .select('s.status')
      .count({ customer_count: 'c.id' })
      .sum({ mrr_cents: 'p.price_cents' });

    const mapStatus = (status: string): LifecycleStage['stage'] => {
      if (status === 'trial') return 'trial';
      if (status === 'past_due') return 'at_risk';
      if (status === 'cancelled' || status === 'expired') return 'churned';
      return 'active';
    };

    const buckets = new Map<LifecycleStage['stage'], LifecycleStage>();
    for (const row of rows) {
      const r = row as Record<string, unknown>;
      const stage = mapStatus(String(r.status));
      const prev = buckets.get(stage) ?? { stage, customer_count: 0, mrr_cents: 0 };
      prev.customer_count += Number(r.customer_count);
      prev.mrr_cents += Number(r.mrr_cents);
      buckets.set(stage, prev);
    }
    return [...buckets.values()];
  }

  async transitionsLastDays(days = 30): Promise<TransitionMetric[]> {
    const since = new Date(Date.now() - days * 86400000);
    const logs = await getDb()('audit_log')
      .where('action', 'status_changed')
      .andWhere('recorded_at', '>=', since)
      .select('before_state', 'after_state');

    const counts = new Map<string, number>();
    for (const log of logs) {
      const before =
        typeof log.before_state === 'string'
          ? JSON.parse(log.before_state as string)
          : (log.before_state as Record<string, unknown>);
      const after =
        typeof log.after_state === 'string'
          ? JSON.parse(log.after_state as string)
          : (log.after_state as Record<string, unknown>);
      const key = `${before?.status ?? 'unknown'}->${after?.status ?? 'unknown'}`;
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    return [...counts.entries()].map(([k, count]) => {
      const [from_status, to_status] = k.split('->');
      return { from_status, to_status, count };
    });
  }

  async expansionSignals(limit = 20): Promise<ExpansionSignal[]> {
    const subs = await getDb()('subscriptions as s')
      .join('customers as c', 'c.id', 's.customer_id')
      .join('plans as p', 'p.id', 's.plan_id')
      .whereIn('s.status', ['active', 'trial'])
      .select('s.customer_id', 'c.email', 's.failed_payment_count', 'p.price_cents', 's.status')
      .limit(200);

    const signals: ExpansionSignal[] = [];
    for (const sub of subs) {
      let score = 50;
      const parts: string[] = [];
      if (Number(sub.failed_payment_count) === 0) {
        score += 15;
        parts.push('clean_payments');
      }
      if (Number(sub.price_cents) >= 5000) {
        score += 10;
        parts.push('high_plan');
      }
      if (sub.status === 'trial') {
        score += 5;
        parts.push('trial_convert');
      }
      signals.push({
        customer_id: sub.customer_id as string,
        email: sub.email as string,
        signal: parts.join(',') || 'baseline',
        score,
      });
    }
    return signals.sort((a, b) => b.score - a.score).slice(0, limit);
  }

  async trialConversionRate(): Promise<{ started: number; converted: number; rate: number }> {
    const started = await getDb()('subscriptions').whereNotNull('trial_end').count({ c: 'id' }).first();
    const converted = await getDb()('audit_log')
      .where({ action: 'status_changed' })
      .andWhereRaw("after_state::text LIKE '%active%'")
      .count({ c: 'id' })
      .first();
    const s = Number(started?.c ?? 0);
    const c = Number(converted?.c ?? 0);
    return { started: s, converted: c, rate: s === 0 ? 0 : c / s };
  }

  async averageRevenuePerCustomer(): Promise<number> {
    const row = await getDb()('subscriptions as s')
      .join('plans as p', 'p.id', 's.plan_id')
      .whereIn('s.status', ['active', 'trial'])
      .avg({ avg: 'p.price_cents' })
      .first();
    return Math.round(Number(row?.avg ?? 0));
  }

  async customersAtRisk(): Promise<{ customer_id: string; email: string; failed_payments: number }[]> {
    return getDb()('subscriptions as s')
      .join('customers as c', 'c.id', 's.customer_id')
      .where('s.status', 'past_due')
      .orWhere('s.failed_payment_count', '>', 0)
      .select('s.customer_id', 'c.email', 's.failed_payment_count as failed_payments');
  }

  async exportLifecycleCsv(): Promise<string> {
    const stages = await this.stageDistribution();
    const header = 'stage,customers,mrr_cents';
    const lines = stages.map((s) => `${s.stage},${s.customer_count},${s.mrr_cents}`);
    return [header, ...lines].join('\n');
  }
}
