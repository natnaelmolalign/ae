import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface ReconciliationMismatch {
  invoice_id: string;
  field: string;
  expected: number | string;
  actual: number | string;
  severity: 'warning' | 'error';
}

export interface ReconciliationRun {
  period_key: string;
  invoices_checked: number;
  mismatches: ReconciliationMismatch[];
  balanced: boolean;
  total_expected_cents: number;
  total_actual_cents: number;
}

/**
 * Validates invoice line totals, tax, and payment allocation consistency for finance close.
 */
export class InvoiceReconciliationService {
  async runForPeriod(periodKey: string): Promise<ReconciliationRun> {
    const { start, end } = this.parsePeriod(periodKey);
    const invoices = await getDb()('invoices').whereBetween('created_at', [start, end]);
    const mismatches: ReconciliationMismatch[] = [];
    let expected = 0;
    let actual = 0;

    for (const inv of invoices) {
      const lines = await getDb()('invoice_line_items').where({ invoice_id: inv.id });
      const lineSum = lines.reduce((s, l) => s + Number(l.amount_cents), 0);
      const subtotal = Number(inv.subtotal_cents);
      expected += Number(inv.total_cents);
      actual += lineSum + Number(inv.tax_cents) - Number(inv.discount_cents);

      if (lineSum !== subtotal) {
        mismatches.push({
          invoice_id: inv.id as string,
          field: 'subtotal_cents',
          expected: lineSum,
          actual: subtotal,
          severity: 'error',
        });
      }

      const computedTotal = subtotal - Number(inv.discount_cents) + Number(inv.tax_cents);
      if (computedTotal !== Number(inv.total_cents)) {
        mismatches.push({
          invoice_id: inv.id as string,
          field: 'total_cents',
          expected: computedTotal,
          actual: Number(inv.total_cents),
          severity: 'error',
        });
      }

      if (inv.status === 'paid') {
        const paid = await getDb()('payments')
          .where({ invoice_id: inv.id, status: 'succeeded' })
          .sum({ total: 'amount_cents' })
          .first();
        const paidTotal = Number(paid?.total ?? 0);
        if (paidTotal < Number(inv.total_cents)) {
          mismatches.push({
            invoice_id: inv.id as string,
            field: 'payments',
            expected: inv.total_cents,
            actual: paidTotal,
            severity: 'warning',
          });
        }
      }
    }

    return {
      period_key: periodKey,
      invoices_checked: invoices.length,
      mismatches,
      balanced: mismatches.filter((m) => m.severity === 'error').length === 0,
      total_expected_cents: expected,
      total_actual_cents: actual,
    };
  }

  async reconcileInvoice(invoiceId: string): Promise<ReconciliationMismatch[]> {
    const inv = await getDb()('invoices').where({ id: invoiceId }).first();
    if (!inv) throw new AppError(404, 'Invoice not found');
    const createdAt =
      inv.created_at instanceof Date ? inv.created_at.toISOString() : String(inv.created_at);
    const run = await this.runForPeriod(this.monthKey(createdAt));
    return run.mismatches.filter((m) => m.invoice_id === invoiceId);
  }

  async fixLineSubtotals(invoiceId: string): Promise<{ updated: boolean; subtotal_cents: number }> {
    const lines = await getDb()('invoice_line_items').where({ invoice_id: invoiceId });
    const subtotal = lines.reduce((s, l) => s + Number(l.amount_cents), 0);
    await getDb()('invoices').where({ id: invoiceId }).update({ subtotal_cents: subtotal });
    const inv = await getDb()('invoices').where({ id: invoiceId }).first();
    const total = subtotal - Number(inv?.discount_cents ?? 0) + Number(inv?.tax_cents ?? 0);
    await getDb()('invoices').where({ id: invoiceId }).update({ total_cents: total });
    return { updated: true, subtotal_cents: subtotal };
  }

  async summaryByStatus(periodKey: string) {
    const { start, end } = this.parsePeriod(periodKey);
    const rows = await getDb()('invoices')
      .whereBetween('created_at', [start, end])
      .groupBy('status')
      .select('status')
      .count({ count: 'id' })
      .sum({ total: 'total_cents' });
    return rows.map((r: Record<string, unknown>) => ({
      status: String(r.status),
      count: Number(r.count),
      total_cents: Number(r.total),
    }));
  }

  async unappliedPayments(periodKey: string) {
    const { start, end } = this.parsePeriod(periodKey);
    return getDb()('payments')
      .whereBetween('attempted_at', [start, end])
      .where({ status: 'succeeded' })
      .whereNull('invoice_id')
      .select('id', 'amount_cents', 'attempted_at');
  }

  async duplicateLineDetection(invoiceId: string) {
    const lines = await getDb()('invoice_line_items').where({ invoice_id: invoiceId });
    const seen = new Map<string, number>();
    const dupes: string[] = [];
    for (const line of lines) {
      const key = `${line.description}:${line.unit_amount_cents}`;
      const n = (seen.get(key) ?? 0) + 1;
      seen.set(key, n);
      if (n === 2) dupes.push(key);
    }
    return dupes;
  }

  async exportReport(periodKey: string): Promise<string> {
    const run = await this.runForPeriod(periodKey);
    const header = 'invoice_id,field,expected,actual,severity';
    const body = run.mismatches.map(
      (m) => `${m.invoice_id},${m.field},${m.expected},${m.actual},${m.severity}`
    );
    return [header, ...body, `checked,${run.invoices_checked},balanced,${run.balanced}`].join('\n');
  }

  private monthKey(iso: string): string {
    const d = new Date(iso);
    return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
  }

  private parsePeriod(periodKey: string): { start: Date; end: Date } {
    if (/^\d{4}-\d{2}$/.test(periodKey)) {
      const [y, m] = periodKey.split('-').map(Number);
      return {
        start: new Date(Date.UTC(y, m - 1, 1)),
        end: new Date(Date.UTC(y, m, 0, 23, 59, 59, 999)),
      };
    }
    throw new AppError(400, 'period_key must be YYYY-MM');
  }
}
