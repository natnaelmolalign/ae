import { QueryCache } from '../lib/queryCache';
import { EntitlementService } from './EntitlementService';

export interface CachedEntitlementResult {
  allowed: boolean;
  limit: number | null;
  used: number;
  cached_at: number;
}

export class EntitlementCacheService {
  private readonly cache = new QueryCache<CachedEntitlementResult>(15_000, 2000);

  constructor(private readonly entitlements = new EntitlementService()) {}

  private key(subscriptionId: string, feature: string): string {
    return `${subscriptionId}:${feature}`;
  }

  async check(subscriptionId: string, feature: string): Promise<CachedEntitlementResult> {
    const k = this.key(subscriptionId, feature);
    const hit = this.cache.get(k);
    if (hit) return hit;

    const result = await this.entitlements.check(subscriptionId, feature);
    const entry: CachedEntitlementResult = {
      allowed: result.allowed,
      limit: result.limit_value ?? null,
      used: result.current_usage ?? 0,
      cached_at: Date.now(),
    };
    this.cache.set(k, entry);
    return entry;
  }

  invalidate(subscriptionId: string, feature?: string): void {
    if (feature) {
      this.cache.invalidate(this.key(subscriptionId, feature));
      return;
    }
    this.cache.clear();
  }
}
