import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import type { Coupon } from '../models/Coupon';
import type { Invoice, InvoiceLineItem } from '../models/Invoice';
import type { Subscription } from '../models/Subscription';
import { calculateTax, sumCents } from '../utils/currencyUtils';
import { gracePeriodEnd, parseDate, toDateString } from '../utils/dateUtils';
import { BillingCycleService } from './BillingCycleService';
import { CouponService } from './CouponService';
import { PlanService } from './PlanService';
import { SubscriptionItemService } from './SubscriptionItemService';

const TAX_RATES: Record<string, number> = {
  US: Number(process.env.DEFAULT_TAX_RATE_BPS || 0),
  DE: 1900,
  GB: 2000,
};

export class InvoiceService {
  constructor(
    private planService = new PlanService(),
    private couponService = new CouponService(),
    private billingCycleService = new BillingCycleService(),
    private subscriptionItems = new SubscriptionItemService()
  ) {}

  getTaxRateBps(country: string): number {
    return TAX_RATES[country] ?? TAX_RATES.US;
  }

  async generateForSubscription(
    subscription: Subscription,
    customerCountry: string
  ): Promise<Invoice> {
    if (subscription.status === 'trial') {
      throw new AppError(400, 'Cannot invoice trial subscription before trial ends');
    }

    const plan = await this.planService.getById(subscription.plan_id);
    const anchorDay = parseDate(subscription.billing_anchor).getDate();
    const cycle = await this.billingCycleService.createForPeriod(
      subscription.id,
      parseDate(subscription.current_period_start),
      plan.interval,
      anchorDay
    );

    const duplicate = await getDb()('invoices')
      .where({ billing_cycle_id: cycle.id })
      .whereNot('status', 'void')
      .first();
    if (duplicate) {
      return duplicate as Invoice;
    }

    let subtotalCents = await this.subscriptionItems.computeRecurringSubtotalCents(
      subscription.id
    );
    if (subtotalCents <= 0) subtotalCents = plan.price_cents;
    let discountCents = 0;
    if (subscription.coupon_id) {
      const row = await getDb()('coupons').where({ id: subscription.coupon_id }).first();
      if (row) {
        const coupon = await this.couponService.getByCode(row.code as string);
        discountCents = subtotalCents - this.couponService.applyDiscount(subtotalCents, coupon);
      }
    }

    const taxable = subtotalCents - discountCents;
    const taxCents = calculateTax(taxable, this.getTaxRateBps(customerCountry));
    const totalBeforeCredit = sumCents(taxable, taxCents);

    const customer = await getDb()('customers')
      .where({ id: subscription.customer_id })
      .first();
    const creditApplied = Math.min(
      customer?.credit_balance_cents || 0,
      totalBeforeCredit
    );
    const totalCents = Math.max(0, totalBeforeCredit - creditApplied);
    const issuedAt = toDateString(new Date());
    const dueDate = issuedAt;

    const db = getDb();
    const invoice = await db.transaction(async (trx) => {
      const [inv] = await trx('invoices')
        .insert({
          subscription_id: subscription.id,
          billing_cycle_id: cycle.id,
          status: 'pending',
          subtotal_cents: subtotalCents,
          tax_cents: taxCents,
          discount_cents: discountCents,
          credit_applied_cents: creditApplied,
          total_cents: totalCents,
          due_date: dueDate,
          issued_at: issuedAt,
        })
        .returning('*');

      if (creditApplied > 0) {
        const locked = await trx('customers')
          .where({ id: subscription.customer_id })
          .forUpdate()
          .first();
        await trx('customers')
          .where({ id: subscription.customer_id })
          .update({
            credit_balance_cents:
              Number(locked?.credit_balance_cents ?? 0) - Number(creditApplied),
          });
        await trx('credits').insert({
          customer_id: subscription.customer_id,
          amount_cents: -creditApplied,
          reason: `Applied to invoice ${inv.id}`,
          invoice_id: inv.id,
          applied: true,
        });
      }

      const items = await this.subscriptionItems.listActive(subscription.id);
      if (items.length > 0) {
        for (const item of items) {
          await trx('invoice_line_items').insert({
            invoice_id: inv.id,
            description: item.description,
            amount_cents: Number(item.unit_price_cents) * Number(item.quantity),
            type: item.item_type === 'addon' ? 'addon' : 'subscription',
          });
        }
      } else {
        await trx('invoice_line_items').insert({
          invoice_id: inv.id,
          description: `${plan.name} subscription`,
          amount_cents: subtotalCents,
          type: 'subscription',
        });
      }
      if (discountCents > 0) {
        await trx('invoice_line_items').insert({
          invoice_id: inv.id,
          description: 'Discount',
          amount_cents: -discountCents,
          type: 'discount',
        });
      }
      return inv as Invoice;
    });

    return invoice;
  }

  async createProrationCharge(
    subscription: Subscription,
    amountCents: number,
    description: string
  ): Promise<Invoice> {
    if (amountCents <= 0) {
      throw new AppError(400, 'Proration charge must be positive');
    }
    const issuedAt = toDateString(new Date());
    const db = getDb();
    const [inv] = await db('invoices')
      .insert({
        subscription_id: subscription.id,
        billing_cycle_id: null,
        status: 'pending',
        subtotal_cents: amountCents,
        tax_cents: 0,
        discount_cents: 0,
        credit_applied_cents: 0,
        total_cents: amountCents,
        due_date: issuedAt,
        issued_at: issuedAt,
      })
      .returning('*');
    await db('invoice_line_items').insert({
      invoice_id: inv.id,
      description,
      amount_cents: amountCents,
      type: 'proration',
    });
    return inv as Invoice;
  }

  async voidInvoice(id: string): Promise<Invoice> {
    const [row] = await getDb()('invoices')
      .where({ id })
      .update({ status: 'void', updated_at: getDb().fn.now() })
      .returning('*');
    if (!row) throw new AppError(404, 'Invoice not found');
    return row as Invoice;
  }

  async markPaid(id: string): Promise<Invoice> {
    const [row] = await getDb()('invoices')
      .where({ id })
      .update({ status: 'paid', updated_at: getDb().fn.now() })
      .returning('*');
    if (!row) throw new AppError(404, 'Invoice not found');
    return row as Invoice;
  }

  async getById(id: string): Promise<Invoice> {
    const row = await getDb()('invoices').where({ id }).first();
    if (!row) throw new AppError(404, 'Invoice not found');
    return row as Invoice;
  }

  async getLineItems(invoiceId: string): Promise<InvoiceLineItem[]> {
    return getDb()('invoice_line_items').where({ invoice_id: invoiceId });
  }

  computeGraceEnd(invoice: Invoice, graceDays = 3): string {
    return toDateString(gracePeriodEnd(parseDate(invoice.due_date), graceDays));
  }

  async applyDiscountOrder(
    subtotalCents: number,
    fixedCreditCents: number,
    percentCoupon: Coupon
  ): Promise<{ discountCents: number; total: number }> {
    const afterCredit = Math.max(0, subtotalCents - fixedCreditCents);
    const discounted = this.couponService.applyDiscount(afterCredit, percentCoupon);
    const discountCents = subtotalCents - discounted;
    return { discountCents, total: discounted };
  }
}
