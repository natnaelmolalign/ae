import { addHours } from 'date-fns';
import { getDb } from '../config/database';
import { loadEnv } from '../config/env';

export class IdempotencyService {
  async getCached(route: string, key: string): Promise<{ status: number; body: unknown } | null> {
    const row = await getDb()('idempotency_keys')
      .where({ route, key })
      .andWhere('expires_at', '>', new Date())
      .first();
    if (!row) return null;
    return {
      status: row.response_status as number,
      body: typeof row.response_body === 'string'
        ? JSON.parse(row.response_body as string)
        : row.response_body,
    };
  }

  async store(
    route: string,
    key: string,
    status: number,
    body: unknown
  ): Promise<void> {
    const { IDEMPOTENCY_TTL_HOURS } = loadEnv();
    await getDb()('idempotency_keys')
      .insert({
        route,
        key,
        response_status: status,
        response_body: JSON.stringify(body),
        expires_at: addHours(new Date(), IDEMPOTENCY_TTL_HOURS),
      })
      .onConflict(['key', 'route'])
      .ignore();
  }
}
