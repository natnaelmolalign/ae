import type { Knex } from 'knex';
import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface RetentionPolicy {
  id: string;
  entity_type: string;
  retain_days: number;
  purge_enabled: boolean;
}

export class RetentionPolicyService {
  async upsert(entityType: string, retainDays: number, purgeEnabled = true): Promise<RetentionPolicy> {
    const db = getDb();
    const existing = await db('retention_policies').where({ entity_type: entityType }).first();
    if (existing) {
      const [row] = await db('retention_policies')
        .where({ id: existing.id })
        .update({ retain_days: retainDays, purge_enabled: purgeEnabled, updated_at: db.fn.now() })
        .returning('*');
      return row as RetentionPolicy;
    }
    const [row] = await db('retention_policies')
      .insert({ entity_type: entityType, retain_days: retainDays, purge_enabled: purgeEnabled })
      .returning('*');
    return row as RetentionPolicy;
  }

  async list(): Promise<RetentionPolicy[]> {
    return getDb()('retention_policies').orderBy('entity_type');
  }

  async purgeEntityType(entityType: string, asOf = new Date()): Promise<number> {
    const db = getDb();
    const policy = await db('retention_policies').where({ entity_type: entityType }).first();
    if (!policy || !policy.purge_enabled) return 0;

    const cutoff = new Date(asOf);
    cutoff.setDate(cutoff.getDate() - policy.retain_days);

    const [run] = await db('purge_runs')
      .insert({ entity_type: entityType, started_at: asOf, status: 'running' })
      .returning('*');

    let deleted = 0;
    try {
      deleted = await this.purgeTable(db, entityType, cutoff);
      await db('purge_runs').where({ id: run.id }).update({
        rows_deleted: deleted,
        finished_at: db.fn.now(),
        status: 'completed',
      });
    } catch (err) {
      await db('purge_runs').where({ id: run.id }).update({
        finished_at: db.fn.now(),
        status: 'failed',
      });
      throw err;
    }
    return deleted;
  }

  private async purgeTable(db: Knex, entityType: string, cutoff: Date): Promise<number> {
    switch (entityType) {
      case 'application_metrics':
        return db('application_metrics').where('recorded_at', '<', cutoff).del();
      case 'workflow_history':
        return db('workflow_history').where('created_at', '<', cutoff).del();
      case 'webhook_events':
        return db('webhook_events').where('created_at', '<', cutoff).del();
      default:
        throw new AppError(400, `Unsupported purge entity ${entityType}`);
    }
  }

  async runAllEnabled(asOf = new Date()): Promise<Record<string, number>> {
    const policies = await this.list();
    const result: Record<string, number> = {};
    for (const p of policies) {
      if (p.purge_enabled) {
        result[p.entity_type] = await this.purgeEntityType(p.entity_type, asOf);
      }
    }
    return result;
  }

  async seedDefaults(): Promise<void> {
    await this.upsert('application_metrics', 90);
    await this.upsert('workflow_history', 365);
    await this.upsert('webhook_events', 30);
  }
}
