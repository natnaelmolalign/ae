import type { Knex } from 'knex';
import { getDb } from '../config/database';

export interface AuditEntryInput {
  entityType: string;
  entityId: string;
  action: string;
  actor?: string;
  beforeState?: Record<string, unknown> | null;
  afterState?: Record<string, unknown> | null;
  domainEventId?: string;
}

export class AuditService {
  async record(entry: AuditEntryInput, trx: Knex.Transaction | Knex = getDb()): Promise<void> {
    await trx('audit_log').insert({
      entity_type: entry.entityType,
      entity_id: entry.entityId,
      action: entry.action,
      actor: entry.actor ?? 'system',
      before_state: entry.beforeState ? JSON.stringify(entry.beforeState) : null,
      after_state: entry.afterState ? JSON.stringify(entry.afterState) : null,
      domain_event_id: entry.domainEventId ?? null,
    });
  }

  async listForEntity(
    entityType: string,
    entityId: string,
    limit = 50
  ): Promise<Record<string, unknown>[]> {
    return getDb()('audit_log')
      .where({ entity_type: entityType, entity_id: entityId })
      .orderBy('recorded_at', 'desc')
      .limit(limit);
  }
}
