import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface RateLimitPolicy {
  principal_id: string;
  requests_per_minute: number;
}

const DEFAULT_RPM = 120;

export class RateLimitPolicyService {
  async getForPrincipal(principalId: string): Promise<number> {
    const row = await getDb()('rate_limit_overrides').where({ principal_id: principalId }).first();
    return row ? Number(row.requests_per_minute) : DEFAULT_RPM;
  }

  async setOverride(principalId: string, requestsPerMinute: number): Promise<RateLimitPolicy> {
    if (requestsPerMinute < 10 || requestsPerMinute > 10_000) {
      throw new AppError(400, 'RPM out of range', 'INVALID_RPM');
    }
    const existing = await getDb()('rate_limit_overrides').where({ principal_id: principalId }).first();
    if (existing) {
      const [row] = await getDb()('rate_limit_overrides')
        .where({ principal_id: principalId })
        .update({ requests_per_minute: requestsPerMinute })
        .returning('*');
      return row as RateLimitPolicy;
    }
    const [row] = await getDb()('rate_limit_overrides')
      .insert({ principal_id: principalId, requests_per_minute: requestsPerMinute })
      .returning('*');
    return row as RateLimitPolicy;
  }

  async clearOverride(principalId: string): Promise<void> {
    await getDb()('rate_limit_overrides').where({ principal_id: principalId }).del();
  }

  async listOverrides(): Promise<RateLimitPolicy[]> {
    return getDb()('rate_limit_overrides').orderBy('requests_per_minute', 'desc');
  }
}
