import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { CustomerService } from './CustomerService';
import crypto from 'crypto';

export interface VaultedPaymentMethod {
  id: string;
  customer_id: string;
  token_ref: string;
  brand: string;
  last4: string;
  exp_month: number;
  exp_year: number;
  default_method: boolean;
}

export class PaymentMethodVaultService {
  constructor(private readonly customers = new CustomerService()) {}

  async store(input: {
    customer_id: string;
    brand: string;
    last4: string;
    exp_month: number;
    exp_year: number;
    set_default?: boolean;
  }): Promise<VaultedPaymentMethod> {
    await this.customers.getById(input.customer_id);
    if (input.last4.length !== 4) throw new AppError(400, 'last4 must be 4 digits', 'INVALID_LAST4');
    const tokenRef = `tok_${crypto.randomBytes(16).toString('hex')}`;
    const db = getDb();
    return db.transaction(async (trx) => {
      if (input.set_default) {
        await trx('payment_method_vault')
          .where({ customer_id: input.customer_id })
          .update({ default_method: false, updated_at: trx.fn.now() });
      }
      const [row] = await trx('payment_method_vault')
        .insert({
          customer_id: input.customer_id,
          token_ref: tokenRef,
          brand: input.brand,
          last4: input.last4,
          exp_month: input.exp_month,
          exp_year: input.exp_year,
          default_method: input.set_default ?? false,
        })
        .returning('*');
      return row as VaultedPaymentMethod;
    });
  }

  async listForCustomer(customerId: string): Promise<VaultedPaymentMethod[]> {
    return getDb()('payment_method_vault')
      .where({ customer_id: customerId })
      .orderBy('default_method', 'desc');
  }

  async getDefault(customerId: string): Promise<VaultedPaymentMethod | null> {
    const row = await getDb()('payment_method_vault')
      .where({ customer_id: customerId, default_method: true })
      .first();
    return row ? (row as VaultedPaymentMethod) : null;
  }

  async setDefault(id: string, customerId: string): Promise<VaultedPaymentMethod> {
    const db = getDb();
    return db.transaction(async (trx) => {
      await trx('payment_method_vault')
        .where({ customer_id: customerId })
        .update({ default_method: false, updated_at: trx.fn.now() });
      const [row] = await trx('payment_method_vault')
        .where({ id, customer_id: customerId })
        .update({ default_method: true, updated_at: trx.fn.now() })
        .returning('*');
      if (!row) throw new AppError(404, 'Payment method not found');
      return row as VaultedPaymentMethod;
    });
  }

  async remove(id: string, customerId: string): Promise<void> {
    const deleted = await getDb()('payment_method_vault').where({ id, customer_id: customerId }).del();
    if (!deleted) throw new AppError(404, 'Payment method not found');
  }

  maskForDisplay(method: VaultedPaymentMethod): { brand: string; last4: string; exp: string } {
    return {
      brand: method.brand,
      last4: method.last4,
      exp: `${String(method.exp_month).padStart(2, '0')}/${method.exp_year}`,
    };
  }
}
