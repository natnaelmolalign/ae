import { addDays } from 'date-fns';
import type { Knex } from 'knex';
import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import type { Plan } from '../models/Plan';
import {
  ALLOWED_TRANSITIONS,
  CreateSubscriptionInput,
  Subscription,
  SubscriptionStatus,
} from '../models/Subscription';
import {
  parseDate,
  periodEndFromStart,
  toDateString,
} from '../utils/dateUtils';
import { BillingCycleService } from './BillingCycleService';
import { CouponService } from './CouponService';
import { PlanService } from './PlanService';
import { SubscriptionItemService } from './SubscriptionItemService';

export class SubscriptionService {
  constructor(
    private planService = new PlanService(),
    private couponService = new CouponService(),
    private billingCycleService = new BillingCycleService()
  ) {}

  assertTransition(from: SubscriptionStatus, to: SubscriptionStatus): void {
    if (!ALLOWED_TRANSITIONS[from].includes(to)) {
      throw new AppError(
        400,
        `Invalid status transition from ${from} to ${to}`,
        'INVALID_TRANSITION'
      );
    }
  }

  async create(input: CreateSubscriptionInput): Promise<Subscription> {
    const customer = await getDb()('customers').where({ id: input.customer_id }).first();
    if (!customer) throw new AppError(404, 'Customer not found');
    if (customer.credit_balance_cents < 0) {
      throw new AppError(400, 'Customer has negative credit balance');
    }

    const plan = await this.planService.getById(input.plan_id);
    const anchor = input.billing_anchor
      ? parseDate(input.billing_anchor)
      : new Date();
    const anchorDay = anchor.getDate();
    const periodStart = toDateString(anchor);
    const periodEnd = toDateString(
      periodEndFromStart(anchor, plan.interval, anchorDay)
    );

    let status: SubscriptionStatus = 'active';
    let trialEnd: string | null = null;
    if (input.trial_days && input.trial_days > 0) {
      status = 'trial';
      trialEnd = toDateString(addDays(anchor, input.trial_days));
    }

    let couponId: string | null = null;
    if (input.coupon_code) {
      const { coupon } = await this.couponService.validateAndApply(
        input.coupon_code,
        plan.id,
        plan.price_cents
      );
      couponId = coupon.id;
    }

    const db = getDb();
    const sub = await db.transaction(async (trx) => {
      const [row] = await trx('subscriptions')
        .insert({
          customer_id: input.customer_id,
          plan_id: plan.id,
          status,
          billing_anchor: periodStart,
          current_period_start: periodStart,
          current_period_end: periodEnd,
          trial_end: trialEnd,
          coupon_id: couponId,
        })
        .returning('*');
      if (couponId) await this.couponService.redeem(couponId, trx);
      await new SubscriptionItemService().syncBasePlanItem(row as Subscription, trx);
      return row;
    });

    await this.billingCycleService.createForPeriod(
      sub.id,
      parseDate(periodStart),
      plan.interval,
      anchorDay
    );

    return sub as Subscription;
  }

  async transition(
    id: string,
    to: SubscriptionStatus
  ): Promise<Subscription> {
    const sub = await this.getById(id);
    this.assertTransition(sub.status, to);
    const patch: Partial<Subscription> = { status: to };
    if (to === 'cancelled') {
      patch.cancelled_at = toDateString(new Date());
    }
    const [updated] = await getDb()('subscriptions')
      .where({ id })
      .update({ ...patch, updated_at: getDb().fn.now() })
      .returning('*');
    return updated as Subscription;
  }

  async markPastDue(id: string): Promise<Subscription> {
    const sub = await this.getById(id);
    if (sub.status === 'active') {
      return this.transition(id, 'past_due');
    }
    if (sub.status === 'past_due') return sub;
    throw new AppError(400, 'Cannot mark past due from current status');
  }

  async bumpFailedPaymentCount(
    subscriptionId: string,
    trx?: Knex.Transaction
  ): Promise<Subscription> {
    const runner = trx ?? getDb();
    const sub = await runner('subscriptions').where({ id: subscriptionId }).first();
    if (!sub) throw new AppError(404, 'Subscription not found');
    const nextCount = Number(sub.failed_payment_count) + 1;
    const [updated] = await runner('subscriptions')
      .where({ id: subscriptionId })
      .update({ failed_payment_count: nextCount, updated_at: runner.fn.now() })
      .returning('*');
    return updated as Subscription;
  }

  async recordFailedPayment(id: string): Promise<Subscription> {
    const updated = await this.bumpFailedPaymentCount(id);
    if (Number(updated.failed_payment_count) >= 1 && updated.status === 'active') {
      return this.markPastDue(id);
    }
    return updated;
  }

  async pause(id: string): Promise<Subscription> {
    const sub = await this.getById(id);
    if (sub.status !== 'active') {
      throw new AppError(400, 'Only active subscriptions can be paused');
    }
    const [updated] = await getDb()('subscriptions')
      .where({ id })
      .update({ paused_at: toDateString(new Date()), updated_at: getDb().fn.now() })
      .returning('*');
    return updated as Subscription;
  }

  async resume(id: string, resumeDate?: string): Promise<Subscription> {
    const sub = await this.getById(id);
    if (!sub.paused_at) throw new AppError(400, 'Subscription is not paused');
    const plan = await this.planService.getById(sub.plan_id);
    const anchor = parseDate(sub.billing_anchor);
    const anchorDay = anchor.getDate();
    const resumeAt = resumeDate ? parseDate(resumeDate) : new Date();
    const periodEnd = toDateString(
      periodEndFromStart(resumeAt, plan.interval, anchorDay)
    );
    const [updated] = await getDb()('subscriptions')
      .where({ id })
      .update({
        paused_at: null,
        current_period_start: toDateString(resumeAt),
        current_period_end: periodEnd,
        billing_anchor: sub.billing_anchor,
        updated_at: getDb().fn.now(),
      })
      .returning('*');
    return updated as Subscription;
  }

  async reactivate(id: string): Promise<Subscription> {
    const sub = await this.getById(id);
    if (sub.status !== 'cancelled') {
      throw new AppError(400, 'Only cancelled subscriptions can be reactivated');
    }
    const plan = await this.planService.getById(sub.plan_id);
    const anchor = parseDate(sub.billing_anchor);
    const anchorDay = anchor.getDate();
    const now = new Date();
    const periodEnd = toDateString(
      periodEndFromStart(now, plan.interval, anchorDay)
    );
    const [updated] = await getDb()('subscriptions')
      .where({ id })
      .update({
        status: 'active',
        cancelled_at: null,
        current_period_start: toDateString(now),
        current_period_end: periodEnd,
        billing_anchor: sub.billing_anchor,
        failed_payment_count: 0,
        updated_at: getDb().fn.now(),
      })
      .returning('*');
    return updated as Subscription;
  }

  async activateEndedTrials(asOf = new Date()): Promise<Subscription[]> {
    const dateStr = toDateString(asOf);
    const rows = await getDb()('subscriptions')
      .where({ status: 'trial' })
      .whereNotNull('trial_end')
      .andWhere('trial_end', '<=', dateStr);

    const activated: Subscription[] = [];
    for (const sub of rows) {
      const plan = await this.planService.getById(sub.plan_id);
      const anchor = parseDate(sub.billing_anchor);
      const anchorDay = anchor.getDate();
      const start = parseDate(sub.trial_end as string);
      const periodEnd = toDateString(
        periodEndFromStart(start, plan.interval, anchorDay)
      );

      const [updated] = await getDb()('subscriptions')
        .where({ id: sub.id })
        .update({
          status: 'active',
          current_period_start: toDateString(start),
          current_period_end: periodEnd,
          updated_at: getDb().fn.now(),
        })
        .returning('*');

      await this.billingCycleService.createForPeriod(
        sub.id,
        start,
        plan.interval,
        anchorDay
      );
      activated.push(updated as Subscription);
    }
    return activated;
  }

  async changePlanAtPeriodEnd(
    subscriptionId: string,
    newPlanId: string,
    asOf = new Date()
  ): Promise<Subscription> {
    const sub = await this.getById(subscriptionId);
    if (!['active', 'past_due'].includes(sub.status)) {
      throw new AppError(400, 'Cannot change plan in current status');
    }
    const rawPeriodEnd = sub.current_period_end as unknown;
    const periodEndKey =
      rawPeriodEnd instanceof Date
        ? toDateString(rawPeriodEnd)
        : String(rawPeriodEnd).slice(0, 10);
    if (toDateString(asOf) !== periodEndKey) {
      throw new AppError(400, 'Period-end plan change must run on last day of billing period');
    }
    await this.planService.getById(newPlanId);
    const [updated] = await getDb()('subscriptions')
      .where({ id: subscriptionId })
      .update({ plan_id: newPlanId, updated_at: getDb().fn.now() })
      .returning('*');
    return updated as Subscription;
  }

  async extendTrial(id: string, extraDays: number): Promise<Subscription> {
    const sub = await this.getById(id);
    if (sub.status !== 'trial' || !sub.trial_end) {
      throw new AppError(400, 'Subscription is not in trial');
    }
    const newTrialEnd = toDateString(addDays(parseDate(sub.trial_end), extraDays));
    const [updated] = await getDb()('subscriptions')
      .where({ id })
      .update({ trial_end: newTrialEnd, updated_at: getDb().fn.now() })
      .returning('*');
    return updated as Subscription;
  }

  async renewIfDue(subscriptionId: string, asOf = new Date()): Promise<Subscription | null> {
    const sub = await this.getById(subscriptionId);
    if (sub.status !== 'active' && sub.status !== 'past_due') return null;
    if (asOf <= parseDate(sub.current_period_end)) return null;

    const plan = await this.planService.getById(sub.plan_id);
    const anchor = parseDate(sub.billing_anchor);
    const { periodStart, periodEnd } = await this.billingCycleService.advancePeriod(
      sub.current_period_end,
      plan.interval,
      anchor.getDate()
    );
    const [updated] = await getDb()('subscriptions')
      .where({ id: subscriptionId })
      .update({
        current_period_start: periodStart,
        current_period_end: periodEnd,
        updated_at: getDb().fn.now(),
      })
      .returning('*');
    await this.billingCycleService.createForPeriod(
      subscriptionId,
      parseDate(periodStart),
      plan.interval,
      anchor.getDate()
    );
    return updated as Subscription;
  }

  async applyPlanPriceOnRenewal(plan: Plan): Promise<number> {
    const result = await getDb()('subscriptions')
      .where({ plan_id: plan.id, status: 'active' })
      .update({ updated_at: getDb().fn.now() });
    return result;
  }

  async expireDue(asOf = new Date()): Promise<number> {
    const dateStr = toDateString(asOf);
    const rows = await getDb()('subscriptions')
      .whereIn('status', ['active', 'past_due'])
      .andWhere('current_period_end', '<', dateStr);
    let count = 0;
    for (const row of rows) {
      await this.transition(row.id, 'expired');
      count += 1;
    }
    return count;
  }

  async getById(id: string): Promise<Subscription> {
    const row = await getDb()('subscriptions').where({ id }).first();
    if (!row) throw new AppError(404, 'Subscription not found');
    return row as Subscription;
  }
}
