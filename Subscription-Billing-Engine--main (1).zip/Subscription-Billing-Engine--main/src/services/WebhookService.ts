import { createHmac } from 'crypto';
import { addMinutes } from 'date-fns';
import { getDb } from '../config/database';
import { loadEnv } from '../config/env';
import { childLogger } from '../lib/logger';

export class WebhookService {
  private log = childLogger({ component: 'webhook' });

  signPayload(payload: string, secret: string): string {
    return createHmac('sha256', secret).update(payload).digest('hex');
  }

  async enqueue(eventType: string, payload: Record<string, unknown>): Promise<string> {
    const [row] = await getDb()('webhook_events')
      .insert({
        event_type: eventType,
        payload: JSON.stringify(payload),
        delivered: false,
        attempt_count: 0,
        next_retry_at: new Date(),
      })
      .returning('id');
    return row.id as string;
  }

  async deliverPending(limit = 50): Promise<number> {
    const { WEBHOOK_URL, WEBHOOK_SECRET } = loadEnv();
    if (!WEBHOOK_URL) {
      this.log.warn('webhook_skip_no_url');
      return 0;
    }

    const rows = await getDb()('webhook_events')
      .where({ delivered: false })
      .andWhere('next_retry_at', '<=', new Date())
      .orderBy('created_at', 'asc')
      .limit(limit);

    let delivered = 0;
    for (const row of rows) {
      const body = JSON.stringify({
        id: row.id,
        type: row.event_type,
        data: typeof row.payload === 'string' ? JSON.parse(row.payload) : row.payload,
        created_at: row.created_at,
      });

      try {
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (WEBHOOK_SECRET) {
          headers['x-webhook-signature'] = this.signPayload(body, WEBHOOK_SECRET);
        }

        const res = await fetch(WEBHOOK_URL, { method: 'POST', headers, body });
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }

        await getDb()('webhook_events').where({ id: row.id }).update({
          delivered: true,
          last_error: null,
        });
        delivered += 1;
      } catch (err) {
        const attempt = (row.attempt_count as number) + 1;
        const delayMinutes = Math.min(60, Math.pow(2, attempt));
        await getDb()('webhook_events').where({ id: row.id }).update({
          attempt_count: attempt,
          next_retry_at: addMinutes(new Date(), delayMinutes),
          last_error: err instanceof Error ? err.message : String(err),
        });
        this.log.warn('webhook_delivery_failed', {
          eventId: row.id,
          attempt,
          error: err instanceof Error ? err.message : err,
        });
      }
    }
    return delivered;
  }
}

export async function dispatchWebhook(
  eventType: string,
  payload: Record<string, unknown>
): Promise<void> {
  const service = new WebhookService();
  await service.enqueue(eventType, payload);
  const { WEBHOOK_URL } = loadEnv();
  if (WEBHOOK_URL) {
    await service.deliverPending(1);
  }
}
