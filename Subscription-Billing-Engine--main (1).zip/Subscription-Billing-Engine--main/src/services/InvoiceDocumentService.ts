import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { TaxJurisdictionRegistry } from '../domain/tax/TaxJurisdictionRegistry';
import { centsToDecimal } from '../utils/currencyUtils';

function formatMoney(cents: number, currency: string): string {
  return `${currency} ${centsToDecimal(cents)}`;
}

export interface InvoiceDocument {
  invoice_id: string;
  customer_name: string;
  customer_email: string;
  lines: { description: string; amount: string }[];
  subtotal: string;
  tax: string;
  total: string;
  jurisdiction: string;
  footer: string;
}

export class InvoiceDocumentService {
  constructor(private readonly taxRegistry = new TaxJurisdictionRegistry()) {}

  async renderText(invoiceId: string): Promise<string> {
    const doc = await this.build(invoiceId);
    const lineBlock = doc.lines.map((l) => `  ${l.description.padEnd(40)} ${l.amount}`).join('\n');
    return [
      'INVOICE',
      `Invoice ID: ${doc.invoice_id}`,
      `Bill to: ${doc.customer_name} <${doc.customer_email}>`,
      `Jurisdiction: ${doc.jurisdiction}`,
      '',
      lineBlock,
      '',
      `Subtotal: ${doc.subtotal}`,
      `Tax:      ${doc.tax}`,
      `Total:    ${doc.total}`,
      '',
      doc.footer,
    ].join('\n');
  }

  async build(invoiceId: string): Promise<InvoiceDocument> {
    const invoice = await getDb()('invoices').where({ id: invoiceId }).first();
    if (!invoice) throw new AppError(404, 'Invoice not found');
    const sub = await getDb()('subscriptions').where({ id: invoice.subscription_id }).first();
    const customer = await getDb()('customers').where({ id: sub?.customer_id }).first();
    if (!customer) throw new AppError(404, 'Customer not found');

    const lineRows = await getDb()('invoice_line_items').where({ invoice_id: invoiceId });
    const country = (customer.country as string) || 'US';
    const jurisdiction = this.taxRegistry.get(country)?.name ?? country;

    return {
      invoice_id: invoiceId,
      customer_name: customer.name as string,
      customer_email: customer.email as string,
      lines: lineRows.map((l) => ({
        description: l.description as string,
        amount: formatMoney(Number(l.amount_cents), invoice.currency as string),
      })),
      subtotal: formatMoney(Number(invoice.subtotal_cents), invoice.currency as string),
      tax: formatMoney(Number(invoice.tax_cents), invoice.currency as string),
      total: formatMoney(Number(invoice.total_cents), invoice.currency as string),
      jurisdiction,
      footer: 'Thank you for your business.',
    };
  }

  async renderBatch(invoiceIds: string[]): Promise<string[]> {
    const out: string[] = [];
    for (const id of invoiceIds) {
      out.push(await this.renderText(id));
    }
    return out;
  }
}
