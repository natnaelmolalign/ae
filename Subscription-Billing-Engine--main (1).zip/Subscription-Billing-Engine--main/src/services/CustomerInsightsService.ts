import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface CustomerHealthScore {
  customer_id: string;
  score: number;
  factors: { name: string; weight: number; value: number }[];
}

export interface CustomerLifetimeValue {
  customer_id: string;
  paid_cents: number;
  invoice_count: number;
  months_active: number;
  estimated_ltv_cents: number;
}

export class CustomerInsightsService {
  async healthScore(customerId: string): Promise<CustomerHealthScore> {
    const customer = await getDb()('customers').where({ id: customerId }).first();
    if (!customer) throw new AppError(404, 'Customer not found');

    const subs = await getDb()('subscriptions').where({ customer_id: customerId });
    const active = subs.filter((s) => ['active', 'trial'].includes(s.status as string)).length;
    const pastDue = subs.filter((s) => s.status === 'past_due').length;
    const failedPayments = await getDb()('payments as p')
      .join('invoices as i', 'i.id', 'p.invoice_id')
      .join('subscriptions as s', 's.id', 'i.subscription_id')
      .where('s.customer_id', customerId)
      .andWhere('p.status', 'failed')
      .count('* as c')
      .first();

    const factors = [
      { name: 'active_subscriptions', weight: 40, value: active },
      { name: 'past_due_penalty', weight: -25, value: pastDue * 10 },
      { name: 'failed_payments', weight: -15, value: Number((failedPayments as { c: string }).c) * 5 },
      { name: 'tenure_bonus', weight: 20, value: Math.min(20, subs.length * 5) },
    ];
    const score = Math.max(0, Math.min(100, factors.reduce((s, f) => s + f.weight * (f.value > 0 ? 1 : 0) + f.value, 50)));
    return { customer_id: customerId, score, factors };
  }

  async lifetimeValue(customerId: string): Promise<CustomerLifetimeValue> {
    const paid = await getDb()('payments as p')
      .join('invoices as i', 'i.id', 'p.invoice_id')
      .join('subscriptions as s', 's.id', 'i.subscription_id')
      .where('s.customer_id', customerId)
      .andWhere('p.status', 'succeeded')
      .sum('p.amount_cents as total')
      .count('p.id as cnt')
      .first();

    const paidCents = Number((paid as { total: string }).total ?? 0);
    const invoiceCount = Number((paid as { cnt: string }).cnt ?? 0);
    const firstSub = await getDb()('subscriptions')
      .where({ customer_id: customerId })
      .orderBy('created_at', 'asc')
      .first();
    const monthsActive = firstSub
      ? Math.max(
          1,
          Math.ceil(
            (Date.now() - new Date(firstSub.created_at as string).getTime()) / (30 * 86_400_000)
          )
        )
      : 1;
    const monthlyAvg = paidCents / monthsActive;
    return {
      customer_id: customerId,
      paid_cents: paidCents,
      invoice_count: invoiceCount,
      months_active: monthsActive,
      estimated_ltv_cents: Math.round(monthlyAvg * 24),
    };
  }

  async atRiskCustomers(limit = 20): Promise<{ customer_id: string; score: number }[]> {
    const customers = await getDb()('customers').select('id').limit(200);
    const scored: { customer_id: string; score: number }[] = [];
    for (const c of customers) {
      const h = await this.healthScore(c.id as string);
      if (h.score < 50) scored.push({ customer_id: h.customer_id, score: h.score });
    }
    return scored.sort((a, b) => a.score - b.score).slice(0, limit);
  }
}
