import { createHash, randomBytes } from 'crypto';
import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface Permission {
  id: string;
  resource: string;
  action: string;
  description: string | null;
}

export interface Role {
  id: string;
  name: string;
  description: string | null;
  system_role: boolean;
}

export interface ApiPrincipal {
  id: string;
  name: string;
  api_key_hash: string;
  active: boolean;
}

export function hashApiKey(raw: string): string {
  return createHash('sha256').update(raw).digest('hex');
}

export function generateApiKey(): string {
  return `sk_${randomBytes(24).toString('hex')}`;
}

export class PermissionService {
  async seedDefaults(): Promise<void> {
    const defaults: Array<[string, string, string]> = [
      ['plans', 'read', 'List and view pricing plans'],
      ['plans', 'write', 'Create and update plans'],
      ['customers', 'read', 'View customer records'],
      ['customers', 'write', 'Create and update customers'],
      ['subscriptions', 'read', 'View subscriptions'],
      ['subscriptions', 'write', 'Create and modify subscriptions'],
      ['invoices', 'read', 'View invoices'],
      ['invoices', 'write', 'Generate and void invoices'],
      ['payments', 'read', 'View payments'],
      ['payments', 'write', 'Charge and refund payments'],
      ['audit', 'read', 'View audit trail'],
      ['jobs', 'run', 'Trigger background jobs'],
      ['admin', 'full', 'Full administrative access'],
    ];
    const db = getDb();
    for (const [resource, action, description] of defaults) {
      const existing = await db('permissions').where({ resource, action }).first();
      if (!existing) {
        await db('permissions').insert({ resource, action, description });
      }
    }
  }

  async list(): Promise<Permission[]> {
    return getDb()('permissions').orderBy(['resource', 'action']);
  }

  async findByResourceAction(resource: string, action: string): Promise<Permission | undefined> {
    return getDb()('permissions').where({ resource, action }).first();
  }

  formatKey(resource: string, action: string): string {
    return `${resource}:${action}`;
  }
}

export class RoleService {
  constructor(private permissions = new PermissionService()) {}

  async ensureRole(name: string, permissionKeys: string[], system = false): Promise<Role> {
    const db = getDb();
    let role = await db('roles').where({ name }).first();
    if (!role) {
      [role] = await db('roles')
        .insert({ name, description: `${name} role`, system_role: system })
        .returning('*');
    }
    for (const key of permissionKeys) {
      const [resource, action] = key.split(':');
      const perm = await this.permissions.findByResourceAction(resource, action);
      if (!perm) continue;
      const link = await db('role_permissions')
        .where({ role_id: role.id, permission_id: perm.id })
        .first();
      if (!link) {
        await db('role_permissions').insert({ role_id: role.id, permission_id: perm.id });
      }
    }
    return role as Role;
  }

  async list(): Promise<Role[]> {
    return getDb()('roles').orderBy('name');
  }

  async getPermissionsForRole(roleId: string): Promise<Permission[]> {
    return getDb()('permissions as p')
      .join('role_permissions as rp', 'rp.permission_id', 'p.id')
      .where('rp.role_id', roleId)
      .select('p.*');
  }
}

export class PrincipalService {
  constructor(
    private roles = new RoleService(),
    private permissions = new PermissionService()
  ) {}

  async bootstrapFromEnvMasterKey(masterKey: string): Promise<ApiPrincipal> {
    await this.permissions.seedDefaults();
    await this.roles.ensureRole('billing_admin', [
      'plans:read', 'plans:write', 'customers:read', 'customers:write',
      'subscriptions:read', 'subscriptions:write', 'invoices:read', 'invoices:write',
      'payments:read', 'payments:write', 'audit:read', 'jobs:run', 'admin:full',
    ], true);
    await this.roles.ensureRole('billing_readonly', [
      'plans:read', 'customers:read', 'subscriptions:read', 'invoices:read', 'payments:read',
    ], true);

    const hash = hashApiKey(masterKey);
    const db = getDb();
    let principal = await db('api_principals').where({ api_key_hash: hash }).first();
    if (!principal) {
      [principal] = await db('api_principals')
        .insert({ name: 'master-api-key', api_key_hash: hash, active: true })
        .returning('*');
      const adminRole = await db('roles').where({ name: 'billing_admin' }).first();
      if (adminRole) {
        await db('principal_roles').insert({
          principal_id: principal.id,
          role_id: adminRole.id,
        });
      }
    }
    return principal as ApiPrincipal;
  }

  async create(name: string, roleNames: string[]): Promise<{ principal: ApiPrincipal; apiKey: string }> {
    const apiKey = generateApiKey();
    const db = getDb();
    const [principal] = await db('api_principals')
      .insert({ name, api_key_hash: hashApiKey(apiKey), active: true })
      .returning('*');
    for (const roleName of roleNames) {
      const role = await db('roles').where({ name: roleName }).first();
      if (role) {
        await db('principal_roles').insert({ principal_id: principal.id, role_id: role.id });
      }
    }
    return { principal: principal as ApiPrincipal, apiKey };
  }

  async resolveByApiKey(rawKey: string): Promise<ApiPrincipal | null> {
    const row = await getDb()('api_principals')
      .where({ api_key_hash: hashApiKey(rawKey), active: true })
      .first();
    return row ?? null;
  }

  async hasPermission(principalId: string, resource: string, action: string): Promise<boolean> {
    const db = getDb();
    const match = await db('permissions as p')
      .join('role_permissions as rp', 'rp.permission_id', 'p.id')
      .join('principal_roles as pr', 'pr.role_id', 'rp.role_id')
      .where('pr.principal_id', principalId)
      .where(function () {
        this.where({ 'p.resource': resource, 'p.action': action })
          .orWhere({ 'p.resource': 'admin', 'p.action': 'full' });
      })
      .first();
    return Boolean(match);
  }

  async assertPermission(principalId: string, resource: string, action: string): Promise<void> {
    const ok = await this.hasPermission(principalId, resource, action);
    if (!ok) {
      throw new AppError(403, `Missing permission ${resource}:${action}`, 'FORBIDDEN');
    }
  }

  async list(): Promise<Array<ApiPrincipal & { roles: string[] }>> {
    const db = getDb();
    const principals = await db('api_principals').orderBy('name');
    const result = [];
    for (const p of principals) {
      const roles = await db('roles as r')
        .join('principal_roles as pr', 'pr.role_id', 'r.id')
        .where('pr.principal_id', p.id)
        .pluck('r.name');
      result.push({ ...p, roles });
    }
    return result;
  }
}
