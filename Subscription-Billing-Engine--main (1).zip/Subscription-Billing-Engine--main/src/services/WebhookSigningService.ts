import crypto from 'crypto';
import { loadEnv } from '../config/env';

export interface SignedWebhookPayload {
  event_type: string;
  payload: Record<string, unknown>;
  timestamp: number;
  signature: string;
}

export class WebhookSigningService {
  sign(eventType: string, payload: Record<string, unknown>, timestamp = Date.now()): SignedWebhookPayload {
    const { WEBHOOK_SECRET } = loadEnv();
    const secret = WEBHOOK_SECRET ?? 'dev-webhook-secret-min-32-chars!!';
    const body = JSON.stringify({ event_type: eventType, payload, timestamp });
    const signature = crypto.createHmac('sha256', secret).update(body).digest('hex');
    return { event_type: eventType, payload, timestamp, signature };
  }

  verify(eventType: string, payload: Record<string, unknown>, timestamp: number, signature: string): boolean {
    const expected = this.sign(eventType, payload, timestamp).signature;
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  }

  buildDeliveryHeaders(signed: SignedWebhookPayload): Record<string, string> {
    return {
      'Content-Type': 'application/json',
      'X-Webhook-Event': signed.event_type,
      'X-Webhook-Timestamp': String(signed.timestamp),
      'X-Webhook-Signature': signed.signature,
    };
  }
}
