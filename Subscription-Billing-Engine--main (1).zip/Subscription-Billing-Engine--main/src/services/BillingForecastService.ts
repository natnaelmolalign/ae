import { getDb } from '../config/database';
import { addMonths, format, parseISO, subMonths } from 'date-fns';

export interface ForecastMonth {
  month: string;
  projected_mrr_cents: number;
  projected_churn_cents: number;
  net_mrr_cents: number;
  active_subscriptions: number;
}

export interface ForecastScenario {
  name: string;
  growth_rate_monthly: number;
  churn_rate_monthly: number;
  months: number;
}

/**
 * Projects MRR forward from active subscriptions and historical churn.
 */
export class BillingForecastService {
  async baselineMrr(asOf: string): Promise<number> {
    const subs = await getDb()('subscriptions as s')
      .join('plans as p', 'p.id', 's.plan_id')
      .whereIn('s.status', ['active', 'trial', 'past_due'])
      .select('p.price_cents', 'p.interval');
    return subs.reduce((sum, row) => {
      const price = Number(row.price_cents);
      return sum + (row.interval === 'yearly' ? Math.round(price / 12) : price);
    }, 0);
  }

  async historicalChurnRate(monthsBack = 6): Promise<number> {
    const from = format(subMonths(new Date(), monthsBack), 'yyyy-MM-dd');
    const cancelled = await getDb()('subscriptions')
      .where('status', 'cancelled')
      .andWhere('updated_at', '>=', from)
      .count('* as c')
      .first();
    const active = await getDb()('subscriptions')
      .whereIn('status', ['active', 'trial'])
      .count('* as c')
      .first();
    const c = Number((cancelled as { c: string }).c);
    const a = Number((active as { c: string }).c) || 1;
    return c / a;
  }

  project(scenario: ForecastScenario, startMrrCents: number): ForecastMonth[] {
    const out: ForecastMonth[] = [];
    let mrr = startMrrCents;
    let subs = Math.max(1, Math.round(startMrrCents / 5000));
    const start = new Date();
    for (let i = 0; i < scenario.months; i++) {
      const growth = Math.round(mrr * scenario.growth_rate_monthly);
      const churn = Math.round(mrr * scenario.churn_rate_monthly);
      mrr = mrr + growth - churn;
      subs = Math.max(0, subs + Math.round(subs * scenario.growth_rate_monthly) - Math.round(subs * scenario.churn_rate_monthly));
      out.push({
        month: format(addMonths(start, i), 'yyyy-MM'),
        projected_mrr_cents: mrr,
        projected_churn_cents: churn,
        net_mrr_cents: growth - churn,
        active_subscriptions: subs,
      });
    }
    return out;
  }

  async runDefaultScenario(asOf: string, months = 12): Promise<ForecastMonth[]> {
    const mrr = await this.baselineMrr(asOf);
    const churn = await this.historicalChurnRate();
    return this.project(
      {
        name: 'baseline',
        growth_rate_monthly: 0.03,
        churn_rate_monthly: Math.min(0.15, churn),
        months,
      },
      mrr
    );
  }

  async cohortRetention(cohortMonth: string): Promise<{ month: string; retained_pct: number }[]> {
    const cohortStart = `${cohortMonth}-01`;
    const cohortEnd = format(addMonths(parseISO(cohortStart), 1), 'yyyy-MM-dd');
    const cohortIds = await getDb()('subscriptions')
      .whereBetween('created_at', [cohortStart, cohortEnd])
      .pluck('id');
    if (cohortIds.length === 0) return [];

    const results: { month: string; retained_pct: number }[] = [];
    for (let m = 0; m < 6; m++) {
      const checkDate = format(addMonths(parseISO(cohortStart), m), 'yyyy-MM-dd');
      const active = await getDb()('subscriptions')
        .whereIn('id', cohortIds)
        .whereIn('status', ['active', 'trial', 'past_due'])
        .andWhere('current_period_end', '>=', checkDate)
        .count('* as c')
        .first();
      const retained = Number((active as { c: string }).c) / cohortIds.length;
      results.push({ month: format(addMonths(parseISO(cohortStart), m), 'yyyy-MM'), retained_pct: retained });
    }
    return results;
  }
}
