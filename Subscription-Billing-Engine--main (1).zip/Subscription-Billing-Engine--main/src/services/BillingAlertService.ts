import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { coerceJsonValue } from '../lib/jsonCoerce';

export type AlertSeverity = 'info' | 'warning' | 'critical';

export interface BillingAlert {
  id: string;
  alert_type: string;
  severity: AlertSeverity;
  payload: Record<string, unknown>;
  acknowledged: boolean;
}

export class BillingAlertService {
  async raise(
    alertType: string,
    severity: AlertSeverity,
    payload: Record<string, unknown> = {}
  ): Promise<BillingAlert> {
    const [row] = await getDb()('billing_alerts')
      .insert({
        alert_type: alertType,
        severity,
        payload: JSON.stringify(payload),
      })
      .returning('*');
    return this.parse(row);
  }

  async acknowledge(id: string): Promise<BillingAlert> {
    const [row] = await getDb()('billing_alerts')
      .where({ id })
      .update({ acknowledged: true, updated_at: getDb().fn.now() })
      .returning('*');
    if (!row) throw new AppError(404, 'Alert not found');
    return this.parse(row);
  }

  async listOpen(severity?: AlertSeverity): Promise<BillingAlert[]> {
    const q = getDb()('billing_alerts').where({ acknowledged: false }).orderBy('created_at', 'desc');
    if (severity) q.andWhere({ severity });
    const rows = await q;
    return rows.map((r) => this.parse(r));
  }

  async evaluatePaymentFailureSpike(threshold = 5): Promise<BillingAlert | null> {
    const since = new Date(Date.now() - 3600_000);
    const row = await getDb()('payments')
      .where('status', 'failed')
      .andWhere('attempted_at', '>=', since)
      .count('* as c')
      .first();
    const count = Number((row as { c: string }).c);
    if (count < threshold) return null;
    return this.raise('payment_failure_spike', 'critical', { count, window_hours: 1 });
  }

  async evaluatePastDueSubscriptions(threshold = 3): Promise<BillingAlert | null> {
    const row = await getDb()('subscriptions').where({ status: 'past_due' }).count('* as c').first();
    const count = Number((row as { c: string }).c);
    if (count < threshold) return null;
    return this.raise('past_due_subscriptions', 'warning', { count });
  }

  private parse(row: Record<string, unknown>): BillingAlert {
    return {
      ...row,
      payload: coerceJsonValue(row.payload, {} as Record<string, unknown>),
    } as BillingAlert;
  }
}
