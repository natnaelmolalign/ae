import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { nextRetryDate } from '../utils/retryUtils';
import { coerceJsonArray } from '../lib/jsonCoerce';
import { PlanService } from './PlanService';

export interface DunningStage {
  type: 'retry' | 'cancel';
  delay_days: number;
}

export interface DunningPolicy {
  id: string;
  name: string;
  is_default: boolean;
  stages: DunningStage[];
}

export class DunningService {
  constructor(private planService = new PlanService()) {}

  async getDefaultPolicy(): Promise<DunningPolicy> {
    const row = await getDb()('dunning_policies').where({ is_default: true }).first();
    if (!row) throw new AppError(500, 'No default dunning policy configured');
    return this.map(row);
  }

  async getPolicyForPlan(planId: string): Promise<DunningPolicy> {
    const plan = await this.planService.getById(planId);
    if (plan.dunning_policy_id) {
      const row = await getDb()('dunning_policies').where({ id: plan.dunning_policy_id }).first();
      if (row) return this.map(row);
    }
    return this.getDefaultPolicy();
  }

  retryDelaysFromStages(stages: DunningStage[]): number[] {
    return stages.filter((s) => s.type === 'retry').map((s) => s.delay_days);
  }

  shouldCancelAfterRetries(stages: DunningStage[], completedRetries: number): boolean {
    const retryCount = stages.filter((s) => s.type === 'retry').length;
    return completedRetries >= retryCount && stages.some((s) => s.type === 'cancel');
  }

  async scheduleRetriesForPolicy(
    subscriptionId: string,
    invoiceId: string,
    planId: string,
    firstFailureAt: Date
  ): Promise<void> {
    const db = getDb();
    const existing = await db('payment_retries').where({ invoice_id: invoiceId }).first();
    if (existing) return;

    const policy = await this.getPolicyForPlan(planId);
    const delays = this.retryDelaysFromStages(policy.stages);
    let cumulative = 0;
    const delayOffsets: number[] = [];
    for (const d of delays) {
      cumulative += d;
      delayOffsets.push(cumulative);
    }

    for (let i = 1; i <= delayOffsets.length; i++) {
      const scheduledAt = nextRetryDate(firstFailureAt, i, delayOffsets);
      if (!scheduledAt) continue;
      await db('payment_retries').insert({
        subscription_id: subscriptionId,
        invoice_id: invoiceId,
        attempt_number: i,
        scheduled_at: scheduledAt,
        status: 'pending',
      });
    }
  }

  private map(row: Record<string, unknown>): DunningPolicy {
    const stages = coerceJsonArray<DunningStage>(row.stages);
    return {
      id: row.id as string,
      name: row.name as string,
      is_default: row.is_default as boolean,
      stages,
    };
  }
}
