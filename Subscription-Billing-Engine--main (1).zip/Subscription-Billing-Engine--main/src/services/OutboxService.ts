import { addMinutes } from 'date-fns';
import { getDb } from '../config/database';
import { WebhookService } from './WebhookService';

export class OutboxService {
  constructor(private webhookService = new WebhookService()) {}

  async processPending(limit = 50): Promise<number> {
    const db = getDb();
    const rows = await db('outbox_messages as o')
      .join('domain_events as e', 'e.id', 'o.domain_event_id')
      .where('o.status', 'pending')
      .andWhere(function () {
        this.whereNull('o.next_attempt_at').orWhere('o.next_attempt_at', '<=', new Date());
      })
      .orderBy('o.created_at', 'asc')
      .limit(limit)
      .select(
        'o.id as outbox_id',
        'o.channel',
        'o.attempt_count',
        'e.event_type',
        'e.payload'
      );

    let delivered = 0;
    for (const row of rows) {
      if (row.channel !== 'webhook') continue;

      const payload =
        typeof row.payload === 'string'
          ? JSON.parse(row.payload as string)
          : (row.payload as Record<string, unknown>);

      const ok = await this.deliverWebhook(
        row.event_type as string,
        payload as Record<string, unknown>
      );
      if (ok) {
        await db('outbox_messages').where({ id: row.outbox_id }).update({
          status: 'delivered',
          delivered_at: new Date(),
          last_error: null,
        });
        delivered += 1;
      } else {
        const attempt = Number(row.attempt_count) + 1;
        await db('outbox_messages').where({ id: row.outbox_id }).update({
          status: attempt >= 8 ? 'failed' : 'pending',
          attempt_count: attempt,
          next_attempt_at: addMinutes(new Date(), Math.min(60, Math.pow(2, attempt))),
          last_error: 'webhook delivery failed',
        });
      }
    }
    return delivered;
  }

  async deliverOne(outboxId: string): Promise<boolean> {
    const db = getDb();
    const row = await db('outbox_messages as o')
      .join('domain_events as e', 'e.id', 'o.domain_event_id')
      .where('o.id', outboxId)
      .select('o.id as outbox_id', 'o.channel', 'o.attempt_count', 'e.event_type', 'e.payload')
      .first();
    if (!row || row.channel !== 'webhook') return false;

    const payload =
      typeof row.payload === 'string'
        ? JSON.parse(row.payload as string)
        : (row.payload as Record<string, unknown>);

    const ok = await this.deliverWebhook(row.event_type as string, payload);
    if (ok) {
      await db('outbox_messages').where({ id: outboxId }).update({
        status: 'delivered',
        delivered_at: new Date(),
        last_error: null,
      });
      return true;
    }
    const attempt = Number(row.attempt_count) + 1;
    await db('outbox_messages').where({ id: outboxId }).update({
      status: attempt >= 8 ? 'failed' : 'pending',
      attempt_count: attempt,
      next_attempt_at: addMinutes(new Date(), Math.min(60, Math.pow(2, attempt))),
      last_error: 'webhook delivery failed',
    });
    return false;
  }

  private async deliverWebhook(
    eventType: string,
    payload: Record<string, unknown>
  ): Promise<boolean> {
    const { loadEnv } = await import('../config/env');
    const { WEBHOOK_URL } = loadEnv();
    if (!WEBHOOK_URL) return true;

    await this.webhookService.enqueue(eventType, payload);
    const count = await this.webhookService.deliverPending(1);
    return count > 0;
  }
}
