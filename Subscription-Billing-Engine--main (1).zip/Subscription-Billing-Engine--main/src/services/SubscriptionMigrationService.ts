import { AppError } from '../lib/errors';
import { SubscriptionService } from './SubscriptionService';
import { PlanService } from './PlanService';
import { ProrationService } from './ProrationService';
import { SubscriptionItemService } from './SubscriptionItemService';
import { SubscriptionStateMachine } from '../domain/subscription/SubscriptionStateMachine';
import { AuditService } from './AuditService';

export interface MigrationPreview {
  subscription_id: string;
  from_plan_id: string;
  to_plan_id: string;
  proration_cents: number;
  effective_date: string;
  billable: boolean;
}

export interface MigrationResult {
  subscription_id: string;
  new_plan_id: string;
  proration_invoice_id: string | null;
  credit_issued_cents: number;
}

export class SubscriptionMigrationService {
  constructor(
    private readonly subscriptions = new SubscriptionService(),
    private readonly plans = new PlanService(),
    private readonly proration = new ProrationService(),
    private readonly items = new SubscriptionItemService(),
    private readonly audit = new AuditService()
  ) {}

  async preview(
    subscriptionId: string,
    targetPlanId: string,
    effectiveDate: string
  ): Promise<MigrationPreview> {
    const sub = await this.subscriptions.getById(subscriptionId);
    const sm = new SubscriptionStateMachine(sub.status as 'trial' | 'active' | 'past_due' | 'cancelled' | 'paused');
    const fromPlan = await this.plans.getById(sub.plan_id);
    const toPlan = await this.plans.getById(targetPlanId);
    const result = this.proration.compute(fromPlan, toPlan, sub, effectiveDate);
    return {
      subscription_id: subscriptionId,
      from_plan_id: sub.plan_id,
      to_plan_id: targetPlanId,
      proration_cents: result.netCents,
      effective_date: effectiveDate,
      billable: SubscriptionStateMachine.billable(sm.current()),
    };
  }

  async execute(
    subscriptionId: string,
    targetPlanId: string,
    effectiveDate: string
  ): Promise<MigrationResult> {
    const preview = await this.preview(subscriptionId, targetPlanId, effectiveDate);
    if (!preview.billable) {
      throw new AppError(400, 'Subscription not billable for migration', 'NOT_BILLABLE');
    }

    const result = await this.proration.changePlanMidCycle(subscriptionId, targetPlanId, effectiveDate);
    const { getDb } = await import('../config/database');
    await getDb().transaction(async (trx) => {
      await this.items.syncBasePlanItem(result.subscription, trx);
    });

    await this.audit.record({
      entityType: 'subscription',
      entityId: subscriptionId,
      action: 'plan_migrated',
      actor: 'system',
      afterState: { plan_id: targetPlanId, proration: result.proration },
    });

    const invoice = (result as { proration_invoice?: { id: string } }).proration_invoice;

    return {
      subscription_id: subscriptionId,
      new_plan_id: targetPlanId,
      proration_invoice_id: invoice?.id ?? null,
      credit_issued_cents: result.proration.creditCents,
    };
  }

  async listEligible(subscriptionId: string) {
    const sub = await this.subscriptions.getById(subscriptionId);
    const plans = await this.plans.list(true);
    return plans.filter((p) => p.id !== sub.plan_id).map((p) => ({
      id: p.id,
      name: p.name,
      price_cents: p.price_cents,
    }));
  }
}
