import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { planCache } from '../lib/queryCache';
import type { CreatePlanInput, Plan } from '../models/Plan';

export class PlanService {
  async create(input: CreatePlanInput): Promise<Plan> {
    const db = getDb();
    const [plan] = await db('plans')
      .insert({
        name: input.name,
        price_cents: input.price_cents,
        interval: input.interval,
        features: JSON.stringify(input.features || []),
      })
      .returning('*');
    return this.map(plan);
  }

  async getById(id: string): Promise<Plan> {
    const cached = planCache.get(id);
    if (cached) return this.map(cached);
    const row = await getDb()('plans').where({ id }).first();
    if (!row) throw new AppError(404, 'Plan not found');
    planCache.set(id, row as Record<string, unknown>);
    return this.map(row);
  }

  async list(activeOnly = true): Promise<Plan[]> {
    const q = getDb()('plans').orderBy('created_at', 'desc');
    if (activeOnly) q.where({ active: true });
    const rows = await q;
    return rows.map((r) => this.map(r));
  }

  async listPaginated(
    page: number,
    limit: number,
    activeOnly = true
  ): Promise<{ data: Plan[]; page: number; limit: number; total: number }> {
    const offset = (page - 1) * limit;
    let countQ = getDb()('plans');
    if (activeOnly) countQ = countQ.where({ active: true });
    const countRow = await countQ.count('* as count').first();
    let q = getDb()('plans').orderBy('created_at', 'desc').limit(limit).offset(offset);
    if (activeOnly) q = q.where({ active: true });
    const rows = await q;
    return {
      data: rows.map((r) => this.map(r)),
      page,
      limit,
      total: Number((countRow as { count: string }).count),
    };
  }

  async updatePrice(id: string, priceCents: number): Promise<Plan> {
    const [row] = await getDb()('plans')
      .where({ id })
      .update({ price_cents: priceCents, updated_at: getDb().fn.now() })
      .returning('*');
    if (!row) throw new AppError(404, 'Plan not found');
    planCache.invalidate(id);
    return this.map(row);
  }

  private map(row: Record<string, unknown>): Plan {
    const features =
      typeof row.features === 'string'
        ? JSON.parse(row.features as string)
        : (row.features as string[]) || [];
    return {
      id: row.id as string,
      name: row.name as string,
      price_cents: row.price_cents as number,
      interval: row.interval as Plan['interval'],
      features,
      active: row.active as boolean,
      dunning_policy_id: (row.dunning_policy_id as string | null) ?? null,
      created_at: row.created_at as Date,
      updated_at: row.updated_at as Date,
    };
  }
}
