import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { InvoiceStateMachine } from '../domain/invoice/InvoiceStateMachine';
import { CreditNoteService } from './CreditNoteService';

export interface AdjustmentRequest {
  invoice_id: string;
  reason: string;
  line_adjustments: { description: string; amount_cents: number }[];
}

export class InvoiceAdjustmentService {
  async apply(request: AdjustmentRequest): Promise<{ credit_note_id: string; total_cents: number }> {
    const invoice = await getDb()('invoices').where({ id: request.invoice_id }).first();
    if (!invoice) throw new AppError(404, 'Invoice not found');
    const sm = new InvoiceStateMachine(invoice.status as 'draft' | 'open' | 'paid' | 'void' | 'uncollectible');
    const adjustable = ['open', 'paid', 'pending'];
    if (!adjustable.includes(invoice.status as string) && !adjustable.includes(sm.current())) {
      throw new AppError(400, 'Invoice not adjustable', 'NOT_ADJUSTABLE');
    }
    const total = request.line_adjustments.reduce((s, l) => s + l.amount_cents, 0);
    if (total <= 0) throw new AppError(400, 'Adjustment total must be positive');
    const creditNote = await new CreditNoteService().issue({
      invoice_id: request.invoice_id,
      reason: `${request.reason}: ${request.line_adjustments.map((l) => l.description).join(', ')}`,
      amount_cents: total,
    });
    return { credit_note_id: creditNote.id as string, total_cents: total };
  }

  async listForInvoice(invoiceId: string) {
    return getDb()('credit_notes').where({ invoice_id: invoiceId }).orderBy('created_at', 'desc');
  }
}
