import { getDb } from '../config/database';
import { coerceJsonArray } from '../lib/jsonCoerce';
import { MeteringService } from './MeteringService';
import { UsageRatingEngine } from '../domain/pricing/UsageRatingEngine';

export interface AggregatedUsage {
  subscription_id: string;
  meter: string;
  period_start: string;
  period_end: string;
  quantity: number;
  rated_cents: number;
}

export class UsageAggregationService {
  constructor(
    private readonly metering = new MeteringService(),
    private readonly rater = new UsageRatingEngine()
  ) {}

  async aggregateForSubscription(
    subscriptionId: string,
    periodStart: string,
    periodEnd: string
  ): Promise<AggregatedUsage[]> {
    const meters = await getDb()('meters').select('id', 'code', 'tier_config');
    const results: AggregatedUsage[] = [];
    for (const meter of meters) {
      const records = await getDb()('usage_records')
        .where({ subscription_id: subscriptionId, meter_id: meter.id })
        .andWhereBetween('recorded_at', [periodStart, periodEnd]);
      const quantity = records.reduce((s, r) => s + Number(r.quantity), 0);
      if (quantity === 0) continue;
      const raw = coerceJsonArray<{
        up_to: number | null;
        unit_cents?: number;
        unit_price_cents?: number;
      }>(meter.tier_config);
      const tiers = (raw as { up_to: number | null; unit_cents?: number; unit_price_cents?: number }[]).map(
        (t) => ({
          up_to: t.up_to,
          unit_cents: t.unit_cents ?? t.unit_price_cents ?? 0,
        })
      );
      const rated = this.rater.rate(meter.code as string, quantity, tiers);
      results.push({
        subscription_id: subscriptionId,
        meter: meter.code as string,
        period_start: periodStart,
        period_end: periodEnd,
        quantity,
        rated_cents: rated.amount_cents,
      });
    }
    return results;
  }

  async aggregateAllActive(periodStart: string, periodEnd: string): Promise<AggregatedUsage[]> {
    const subs = await getDb()('subscriptions')
      .whereIn('status', ['active', 'trial', 'past_due'])
      .pluck('id');
    const all: AggregatedUsage[] = [];
    for (const id of subs) {
      const rows = await this.aggregateForSubscription(id as string, periodStart, periodEnd);
      all.push(...rows);
    }
    return all;
  }

  async totalRatedCents(subscriptionId: string, periodStart: string, periodEnd: string): Promise<number> {
    const rows = await this.aggregateForSubscription(subscriptionId, periodStart, periodEnd);
    return rows.reduce((s, r) => s + r.rated_cents, 0);
  }

  async ingestAndAggregate(
    subscriptionId: string,
    meterCode: string,
    quantity: number,
    recordedAt: string
  ): Promise<AggregatedUsage | null> {
    await this.metering.recordUsage({
      subscription_id: subscriptionId,
      meter_code: meterCode,
      quantity,
      recorded_at: new Date(recordedAt),
    });
    const periodEnd = recordedAt;
    const periodStart = recordedAt.slice(0, 8) + '01';
    const rows = await this.aggregateForSubscription(subscriptionId, periodStart, periodEnd);
    return rows.find((r) => r.meter === meterCode) ?? null;
  }
}
