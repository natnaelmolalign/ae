import { getDb } from '../config/database';

export interface ProjectionRow {
  aggregate_type: string;
  aggregate_id: string;
  event_count: number;
  last_event_type: string | null;
  last_occurred_at: string | null;
}

/**
 * Read-side projections over domain_events for dashboards and support tooling.
 */
export class EventProjectionService {
  async rebuildSubscriptionSummary(): Promise<number> {
    const events = await getDb()('domain_events')
      .where({ aggregate_type: 'subscription' })
      .orderBy('occurred_at', 'asc');

    const summary = new Map<string, { count: number; last_type: string; last_at: Date }>();
    for (const e of events) {
      const id = e.aggregate_id as string;
      const prev = summary.get(id) ?? { count: 0, last_type: '', last_at: new Date(0) };
      summary.set(id, {
        count: prev.count + 1,
        last_type: e.event_type as string,
        last_at: new Date(e.occurred_at as string),
      });
    }
    return summary.size;
  }

  async listByAggregate(aggregateType: string, limit = 50): Promise<ProjectionRow[]> {
    const rows = await getDb()('domain_events')
      .where({ aggregate_type: aggregateType })
      .groupBy('aggregate_id')
      .select('aggregate_id')
      .count('* as event_count')
      .max('occurred_at as last_occurred_at')
      .limit(limit);

    return rows.map((r) => ({
      aggregate_type: aggregateType,
      aggregate_id: r.aggregate_id as string,
      event_count: Number(r.event_count),
      last_event_type: null,
      last_occurred_at: r.last_occurred_at as string | null,
    }));
  }

  async paymentFailureRate(hours = 24): Promise<number> {
    const since = new Date(Date.now() - hours * 3600_000);
    const failed = await getDb()('domain_events')
      .where({ event_type: 'payment.failed' })
      .andWhere('occurred_at', '>=', since)
      .count('* as c')
      .first();
    const succeeded = await getDb()('domain_events')
      .where({ event_type: 'payment.succeeded' })
      .andWhere('occurred_at', '>=', since)
      .count('* as c')
      .first();
    const f = Number((failed as { c: string }).c);
    const s = Number((succeeded as { c: string }).c);
    const total = f + s;
    return total === 0 ? 0 : f / total;
  }

  async timeline(aggregateType: string, aggregateId: string) {
    return getDb()('domain_events')
      .where({ aggregate_type: aggregateType, aggregate_id: aggregateId })
      .orderBy('occurred_at', 'asc');
  }
}
