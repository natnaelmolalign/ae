import { getDb } from '../config/database';
import { PlanService } from './PlanService';
import { SubscriptionService } from './SubscriptionService';

export type LimitType = 'boolean' | 'count' | 'unlimited';

export interface PlanEntitlement {
  id: string;
  plan_id: string;
  feature_key: string;
  limit_value: number | null;
  limit_type: LimitType;
  reset_interval: string | null;
}

export interface EntitlementCheck {
  feature_key: string;
  allowed: boolean;
  limit_value: number | null;
  limit_type: LimitType;
  current_usage?: number;
}

export class EntitlementService {
  constructor(
    private planService = new PlanService(),
    private subscriptionService = new SubscriptionService()
  ) {}

  async upsertForPlan(
    planId: string,
    entitlements: Array<{
      feature_key: string;
      limit_type: LimitType;
      limit_value?: number | null;
      reset_interval?: string | null;
    }>
  ): Promise<PlanEntitlement[]> {
    await this.planService.getById(planId);
    await getDb()('plan_entitlements').where({ plan_id: planId }).del();

    const rows: PlanEntitlement[] = [];
    for (const e of entitlements) {
      const [row] = await getDb()('plan_entitlements')
        .insert({
          plan_id: planId,
          feature_key: e.feature_key,
          limit_type: e.limit_type,
          limit_value: e.limit_value ?? null,
          reset_interval: e.reset_interval ?? null,
        })
        .returning('*');
      rows.push(row as PlanEntitlement);
    }
    return rows;
  }

  async check(subscriptionId: string, featureKey: string): Promise<EntitlementCheck> {
    const sub = await this.subscriptionService.getById(subscriptionId);
    const row = await getDb()('plan_entitlements')
      .where({ plan_id: sub.plan_id, feature_key: featureKey })
      .first();

    if (!row) {
      return {
        feature_key: featureKey,
        allowed: false,
        limit_value: null,
        limit_type: 'boolean',
      };
    }

    const limitType = row.limit_type as LimitType;
    if (limitType === 'unlimited') {
      return {
        feature_key: featureKey,
        allowed: true,
        limit_value: null,
        limit_type: limitType,
      };
    }
    if (limitType === 'boolean') {
      return {
        feature_key: featureKey,
        allowed: true,
        limit_value: 1,
        limit_type: limitType,
      };
    }

    const limit = row.limit_value as number;
    return {
      feature_key: featureKey,
      allowed: limit > 0,
      limit_value: limit,
      limit_type: limitType,
      current_usage: 0,
    };
  }

  async listForPlan(planId: string): Promise<PlanEntitlement[]> {
    return getDb()('plan_entitlements').where({ plan_id: planId });
  }
}
