import { getDb } from '../config/database';
import { format, parseISO, addMonths } from 'date-fns';

export interface CohortRow {
  cohort_month: string;
  month_offset: number;
  retained_count: number;
  cohort_size: number;
  retention_rate: number;
}

export class CohortAnalysisService {
  async buildRetentionMatrix(monthsBack = 6, offsets = 6): Promise<CohortRow[]> {
    const rows: CohortRow[] = [];
    const start = addMonths(new Date(), -monthsBack);
    for (let m = 0; m < monthsBack; m++) {
      const cohortMonth = format(addMonths(start, m), 'yyyy-MM');
      const cohortStart = `${cohortMonth}-01`;
      const cohortEnd = format(addMonths(parseISO(cohortStart), 1), 'yyyy-MM-dd');
      const ids = await getDb()('subscriptions')
        .whereBetween('created_at', [cohortStart, cohortEnd])
        .pluck('id');
      const size = ids.length;
      if (size === 0) continue;
      for (let offset = 0; offset < offsets; offset++) {
        const check = format(addMonths(parseISO(cohortStart), offset), 'yyyy-MM-dd');
        const active = await getDb()('subscriptions')
          .whereIn('id', ids)
          .whereIn('status', ['active', 'trial', 'past_due'])
          .andWhere('current_period_end', '>=', check)
          .count('* as c')
          .first();
        const count = Number((active as { c: string }).c);
        rows.push({
          cohort_month: cohortMonth,
          month_offset: offset,
          retained_count: count,
          cohort_size: size,
          retention_rate: Math.round((count / size) * 10000) / 10000,
        });
      }
    }
    return rows;
  }

  async averageRetentionByOffset(offset: number): Promise<number> {
    const matrix = await this.buildRetentionMatrix(6, offset + 1);
    const atOffset = matrix.filter((r) => r.month_offset === offset);
    if (atOffset.length === 0) return 0;
    const sum = atOffset.reduce((s, r) => s + r.retention_rate, 0);
    return sum / atOffset.length;
  }
}
