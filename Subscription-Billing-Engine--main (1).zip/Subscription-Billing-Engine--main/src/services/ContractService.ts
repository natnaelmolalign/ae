import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export type ContractStatus = 'draft' | 'active' | 'amended' | 'expired' | 'terminated';

export interface Contract {
  id: string;
  customer_id: string;
  reference: string;
  status: ContractStatus;
  effective_from: string;
  effective_to: string | null;
  committed_mrr_cents: number;
  terms: Record<string, unknown>;
}

export class ContractService {
  async create(input: {
    customer_id: string;
    reference: string;
    effective_from: string;
    effective_to?: string;
    committed_mrr_cents?: number;
    terms?: Record<string, unknown>;
  }): Promise<Contract> {
    const existing = await getDb()('contracts').where({ reference: input.reference }).first();
    if (existing) throw new AppError(409, 'Contract reference exists', 'CONTRACT_EXISTS');
    const [row] = await getDb()('contracts')
      .insert({
        customer_id: input.customer_id,
        reference: input.reference,
        status: 'draft',
        effective_from: input.effective_from,
        effective_to: input.effective_to ?? null,
        committed_mrr_cents: input.committed_mrr_cents ?? 0,
        terms: JSON.stringify(input.terms ?? {}),
      })
      .returning('*');
    return this.parse(row);
  }

  async activate(id: string): Promise<Contract> {
    const c = await this.getById(id);
    if (c.status !== 'draft') {
      throw new AppError(400, 'Only draft contracts can activate', 'INVALID_STATUS');
    }
    const [row] = await getDb()('contracts')
      .where({ id })
      .update({ status: 'active', updated_at: getDb().fn.now() })
      .returning('*');
    return this.parse(row!);
  }

  async amend(id: string, amendmentType: string, payload: Record<string, unknown>): Promise<Contract> {
    const c = await this.getById(id);
    if (!['active', 'amended'].includes(c.status)) {
      throw new AppError(400, 'Contract not amendable', 'INVALID_STATUS');
    }
    await getDb()('contract_amendments').insert({
      contract_id: id,
      amendment_type: amendmentType,
      payload: JSON.stringify(payload),
    });
    const terms = { ...c.terms, ...payload };
    let mrr = c.committed_mrr_cents;
    if (typeof payload.committed_mrr_cents === 'number') mrr = payload.committed_mrr_cents;
    const [row] = await getDb()('contracts')
      .where({ id })
      .update({
        status: 'amended',
        terms: JSON.stringify(terms),
        committed_mrr_cents: mrr,
        updated_at: getDb().fn.now(),
      })
      .returning('*');
    return this.parse(row!);
  }

  async getById(id: string): Promise<Contract> {
    const row = await getDb()('contracts').where({ id }).first();
    if (!row) throw new AppError(404, 'Contract not found');
    return this.parse(row);
  }

  async listForCustomer(customerId: string): Promise<Contract[]> {
    const rows = await getDb()('contracts').where({ customer_id: customerId }).orderBy('created_at', 'desc');
    return rows.map((r) => this.parse(r));
  }

  async expire(id: string): Promise<Contract> {
    const [row] = await getDb()('contracts')
      .where({ id })
      .update({ status: 'expired', updated_at: getDb().fn.now() })
      .returning('*');
    if (!row) throw new AppError(404, 'Contract not found');
    return this.parse(row);
  }

  private parse(row: Record<string, unknown>): Contract {
    return {
      ...row,
      terms: typeof row.terms === 'string' ? JSON.parse(row.terms) : (row.terms as Record<string, unknown>),
    } as Contract;
  }
}
