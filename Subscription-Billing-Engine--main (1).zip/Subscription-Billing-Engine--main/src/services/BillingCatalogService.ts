import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { PriceBook, type PriceComponent } from '../domain/pricing/PriceBook';
import { DiscountEngine } from '../domain/pricing/DiscountEngine';

export interface CatalogBundle {
  code: string;
  name: string;
  skus: string[];
  discount_codes: string[];
}

export interface CatalogQuote {
  bundle_code: string;
  seat_count: number;
  usage_quantity: number;
  country: string;
  subtotal_cents: number;
  discount_cents: number;
  total_cents: number;
}

const DEFAULT_BUNDLES: CatalogBundle[] = [
  { code: 'starter', name: 'Starter', skus: ['seat'], discount_codes: [] },
  { code: 'growth', name: 'Growth', skus: ['seat', 'api_call'], discount_codes: ['LAUNCH20'] },
  { code: 'enterprise', name: 'Enterprise', skus: ['seat', 'api_call'], discount_codes: ['LOYALTY'] },
];

/**
 * Product catalog composition over PriceBook and promotional rules.
 */
export class BillingCatalogService {
  private readonly book = PriceBook.defaultSaas();
  private readonly discounts = DiscountEngine.standardPromos();
  private customComponents: PriceComponent[] = [];

  listBundles(): CatalogBundle[] {
    return DEFAULT_BUNDLES;
  }

  registerComponent(component: PriceComponent): void {
    this.book.register(component);
    this.customComponents.push(component);
  }

  listComponents(): PriceComponent[] {
    return [...this.book.list(), ...this.customComponents];
  }

  quoteBundle(
    bundleCode: string,
    seatCount: number,
    usageQuantity: number,
    country: string
  ): CatalogQuote {
    const bundle = DEFAULT_BUNDLES.find((b) => b.code === bundleCode);
    if (!bundle) throw new AppError(404, 'Bundle not found', 'BUNDLE_NOT_FOUND');

    let subtotal = 0;
    for (const sku of bundle.skus) {
      if (sku === 'seat') subtotal += this.book.unitPriceForQuantity('seat', seatCount);
      if (sku === 'api_call') subtotal += this.book.unitPriceForQuantity('api_call', usageQuantity);
    }

    const { total, lines } = this.discounts.apply(subtotal, bundle.discount_codes);
    const discountCents = lines.reduce((s, l) => s + l.amount_cents, 0);

    return {
      bundle_code: bundleCode,
      seat_count: seatCount,
      usage_quantity: usageQuantity,
      country,
      subtotal_cents: subtotal,
      discount_cents: discountCents,
      total_cents: total,
    };
  }

  async persistBundlePriceSnapshot(bundleCode: string, quote: CatalogQuote): Promise<void> {
    await getDb()('catalog_price_snapshots').insert({
      bundle_code: bundleCode,
      quote: JSON.stringify(quote),
    });
  }

  async listSnapshots(bundleCode?: string, limit = 20) {
    const q = getDb()('catalog_price_snapshots').orderBy('created_at', 'desc').limit(limit);
    if (bundleCode) q.where({ bundle_code: bundleCode });
    const rows = await q;
    return rows.map((r) => ({
      ...r,
      quote: typeof r.quote === 'string' ? JSON.parse(r.quote) : r.quote,
    }));
  }

  compareBundles(
    seatCount: number,
    usageQuantity: number,
    country: string
  ): CatalogQuote[] {
    return DEFAULT_BUNDLES.map((b) => this.quoteBundle(b.code, seatCount, usageQuantity, country));
  }
}
