import type { Knex } from 'knex';
import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import type { Credit } from '../models/Credit';

export class CreditService {
  async issue(
    input: {
      customer_id: string;
      amount_cents: number;
      reason: string;
      subscription_id?: string;
    },
    trx?: Knex.Transaction
  ): Promise<Credit> {
    if (input.amount_cents <= 0) {
      throw new AppError(400, 'Credit amount must be positive');
    }
    const run = async (t: Knex.Transaction) => {
      const [credit] = await t('credits')
        .insert({
          customer_id: input.customer_id,
          subscription_id: input.subscription_id ?? null,
          amount_cents: input.amount_cents,
          reason: input.reason,
        })
        .returning('*');
      const customer = await t('customers')
        .where({ id: input.customer_id })
        .forUpdate()
        .first();
      if (!customer) throw new AppError(404, 'Customer not found');
      await t('customers')
        .where({ id: input.customer_id })
        .update({
          credit_balance_cents:
            Number(customer.credit_balance_cents) + input.amount_cents,
        });
      return credit as Credit;
    };

    if (trx) return run(trx);
    return getDb().transaction(run);
  }

  async applyToInvoice(
    customerId: string,
    invoiceId: string,
    maxCents: number,
    invoiceStatus: string
  ): Promise<number> {
    if (invoiceStatus === 'void') {
      return 0;
    }
    const db = getDb();
    const customer = await db('customers').where({ id: customerId }).first();
    if (!customer || customer.credit_balance_cents <= 0) {
      return 0;
    }
    const applied = Math.min(customer.credit_balance_cents, maxCents);
    if (applied <= 0) return 0;

    await db.transaction(async (trx) => {
      const locked = await trx('customers').where({ id: customerId }).forUpdate().first();
      if (!locked) return;
      await trx('customers')
        .where({ id: customerId })
        .update({
          credit_balance_cents: Number(locked.credit_balance_cents) - applied,
        });
      await trx('credits').insert({
        customer_id: customerId,
        amount_cents: -applied,
        reason: `Applied to invoice ${invoiceId}`,
        invoice_id: invoiceId,
        applied: true,
      });
    });
    return applied;
  }

  async refundToCredit(
    customerId: string,
    paymentAmountCents: number,
    refundCents: number
  ): Promise<Credit> {
    if (refundCents > paymentAmountCents) {
      throw new AppError(400, 'Refund cannot exceed payment amount');
    }
    return this.issue({
      customer_id: customerId,
      amount_cents: refundCents,
      reason: 'refund',
    });
  }
}
