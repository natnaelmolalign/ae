import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { OutboxService } from './OutboxService';
import { webhookCircuit } from '../lib/CircuitBreaker';

export interface ReplayResult {
  outbox_message_id: string;
  status: 'delivered' | 'skipped' | 'failed';
  error?: string;
}

export class WebhookReplayService {
  constructor(private readonly outbox = new OutboxService()) {}

  async replayMessage(outboxId: string): Promise<ReplayResult> {
    const row = await getDb()('outbox_messages').where({ id: outboxId }).first();
    if (!row) throw new AppError(404, 'Outbox message not found');

    try {
      await webhookCircuit.execute(async () => {
        await this.outbox.deliverOne(outboxId);
      });
      await this.log(outboxId, 'delivered');
      return { outbox_message_id: outboxId, status: 'delivered' };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      await this.log(outboxId, 'failed', msg);
      return { outbox_message_id: outboxId, status: 'failed', error: msg };
    }
  }

  async replayFailed(limit = 20): Promise<ReplayResult[]> {
    const rows = await getDb()('outbox_messages')
      .where({ status: 'failed' })
      .orderBy('created_at', 'asc')
      .limit(limit);
    const results: ReplayResult[] = [];
    for (const row of rows) {
      results.push(await this.replayMessage(row.id as string));
    }
    return results;
  }

  async listReplayLog(limit = 50) {
    return getDb()('webhook_replay_log').orderBy('replayed_at', 'desc').limit(limit);
  }

  private async log(outboxId: string, status: string, error?: string): Promise<void> {
    await getDb()('webhook_replay_log').insert({
      outbox_message_id: outboxId,
      status,
      error_message: error ?? null,
    });
  }
}
