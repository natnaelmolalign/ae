import { BillingSnapshotService } from './BillingSnapshotService';
import { BillingWaterfallService } from './BillingWaterfallService';
import { InvoiceReconciliationService } from './InvoiceReconciliationService';
import { RevenueRecognitionService } from './RevenueRecognitionService';
import { ReportingService } from './ReportingService';

export interface ExecutiveDashboard {
  period_key: string;
  mrr_cents: number;
  arr_cents: number;
  net_waterfall_cents: number;
  reconciliation_balanced: boolean;
  churn_rate_pct: number;
  recognized_revenue_cents: number;
}

export interface DrillDownBundle {
  waterfall_steps: { label: string; amount_cents: number }[];
  snapshot_metrics: Record<string, unknown>;
  reconciliation_errors: number;
  top_customers: { email: string; revenue_cents: number }[];
}

/**
 * Facade composing snapshot, waterfall, reconciliation, and reporting for finance dashboards.
 */
export class BillingAnalyticsFacade {
  constructor(
    private readonly snapshots = new BillingSnapshotService(),
    private readonly waterfall = new BillingWaterfallService(),
    private readonly reconciliation = new InvoiceReconciliationService(),
    private readonly recognition = new RevenueRecognitionService(),
    private readonly reporting = new ReportingService()
  ) {}

  async executiveDashboard(periodKey: string): Promise<ExecutiveDashboard> {
    const mrrSnap = await this.snapshots.capture({ snapshot_type: 'mrr', period_key: periodKey });
    const wf = await this.waterfall.buildForPeriod(periodKey);
    const recon = await this.reconciliation.runForPeriod(periodKey);
    const churn = await this.reporting.churnRate(`${periodKey}-01`, `${periodKey}-28`);
    const recognizedCount = await this.recognition.recognizeDue(new Date(`${periodKey}-15T12:00:00Z`));
    const metrics = mrrSnap.metrics as { mrr_cents?: number; arr_cents?: number };
    return {
      period_key: periodKey,
      mrr_cents: Number(metrics.mrr_cents ?? 0),
      arr_cents: Number(metrics.arr_cents ?? 0),
      net_waterfall_cents: wf.net_revenue_cents,
      reconciliation_balanced: recon.balanced,
      churn_rate_pct: Math.round(churn.rate * 100),
      recognized_revenue_cents: recognizedCount * 100,
    };
  }

  async drillDown(periodKey: string, topLimit = 5): Promise<DrillDownBundle> {
    const wf = await this.waterfall.buildForPeriod(periodKey);
    const snap = await this.snapshots.capture({ snapshot_type: 'collections', period_key: periodKey });
    const recon = await this.reconciliation.runForPeriod(periodKey);
    const tops = await this.waterfall.topCustomersByRevenue(periodKey, topLimit);
    return {
      waterfall_steps: wf.steps.map((s) => ({ label: s.label, amount_cents: s.amount_cents })),
      snapshot_metrics: snap.metrics as Record<string, unknown>,
      reconciliation_errors: recon.mismatches.filter((m) => m.severity === 'error').length,
      top_customers: tops.map((t: Record<string, unknown>) => ({
        email: String(t.email ?? ''),
        revenue_cents: Number(t.revenue_cents ?? 0),
      })),
    };
  }

  async monthOverMonth(periodKey: string) {
    const [y, m] = periodKey.split('-').map(Number);
    const prev = m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, '0')}`;
    const current = await this.executiveDashboard(periodKey);
    const previous = await this.executiveDashboard(prev);
    return {
      current,
      previous,
      mrr_delta_cents: current.mrr_cents - previous.mrr_cents,
      waterfall_delta_cents: current.net_waterfall_cents - previous.net_waterfall_cents,
    };
  }

  async healthScore(periodKey: string): Promise<{ score: number; factors: string[] }> {
    const dash = await this.executiveDashboard(periodKey);
    const factors: string[] = [];
    let score = 100;
    if (!dash.reconciliation_balanced) {
      score -= 25;
      factors.push('reconciliation_mismatch');
    }
    if (dash.churn_rate_pct > 5) {
      score -= 15;
      factors.push('elevated_churn');
    }
    if (dash.mrr_cents === 0) {
      score -= 20;
      factors.push('zero_mrr');
    }
    if (dash.net_waterfall_cents < dash.recognized_revenue_cents * 0.5) {
      score -= 10;
      factors.push('collections_lag');
    }
    return { score: Math.max(0, score), factors };
  }

  async exportBoardPack(periodKey: string): Promise<{
    dashboard: ExecutiveDashboard;
    drill_down: DrillDownBundle;
    health: { score: number; factors: string[] };
    mom: Awaited<ReturnType<BillingAnalyticsFacade['monthOverMonth']>>;
  }> {
    const [dashboard, drill_down, health, mom] = await Promise.all([
      this.executiveDashboard(periodKey),
      this.drillDown(periodKey),
      this.healthScore(periodKey),
      this.monthOverMonth(periodKey),
    ]);
    return { dashboard, drill_down, health, mom };
  }

  async cohortSummary() {
    return this.waterfall.cohortRetention(12);
  }

  async agingAndForecast() {
    const [aging, forecast] = await Promise.all([
      this.waterfall.agingBuckets(),
      this.waterfall.forecastFromHistory(6),
    ]);
    return { aging, forecast };
  }
}
