import crypto from 'crypto';
import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { hashApiKey } from './RbacService';

export interface RotationResult {
  principal_id: string;
  api_key: string;
  rotated_at: string;
}

export class ApiKeyRotationService {
  async rotate(principalId: string): Promise<RotationResult> {
    const principal = await getDb()('api_principals').where({ id: principalId }).first();
    if (!principal) throw new AppError(404, 'Principal not found');
    if (!principal.active) throw new AppError(400, 'Principal inactive', 'PRINCIPAL_INACTIVE');

    const oldHash = principal.api_key_hash as string;
    const apiKey = `sk_${crypto.randomBytes(24).toString('hex')}`;
    const newHash = hashApiKey(apiKey);

    await getDb().transaction(async (trx) => {
      await trx('api_key_rotation_log').insert({
        principal_id: principalId,
        old_hash_prefix: oldHash.slice(0, 16),
      });
      await trx('api_principals')
        .where({ id: principalId })
        .update({ api_key_hash: newHash, updated_at: trx.fn.now() });
    });

    return {
      principal_id: principalId,
      api_key: apiKey,
      rotated_at: new Date().toISOString(),
    };
  }

  async history(principalId: string, limit = 10) {
    return getDb()('api_key_rotation_log')
      .where({ principal_id: principalId })
      .orderBy('rotated_at', 'desc')
      .limit(limit);
  }
}
