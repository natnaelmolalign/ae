import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import type { Plan } from '../models/Plan';
import type { Subscription } from '../models/Subscription';
import { calculateProration, ProrationResult } from '../utils/prorationUtils';
import { CreditService } from './CreditService';
import { InvoiceService } from './InvoiceService';
import { PlanService } from './PlanService';

export class ProrationService {
  constructor(
    private planService = new PlanService(),
    private creditService = new CreditService(),
    private invoiceService = new InvoiceService()
  ) {}

  compute(
    oldPlan: Plan,
    newPlan: Plan,
    subscription: Subscription,
    changeDate: string
  ): ProrationResult {
    return calculateProration({
      oldPriceCents: oldPlan.price_cents,
      newPriceCents: newPlan.price_cents,
      periodStart: subscription.current_period_start,
      periodEnd: subscription.current_period_end,
      changeDate,
    });
  }

  async changePlanMidCycle(
    subscriptionId: string,
    newPlanId: string,
    changeDate: string
  ): Promise<{ subscription: Subscription; proration: ProrationResult }> {
    const db = getDb();
    return db.transaction(async (trx) => {
      const sub = await trx('subscriptions').where({ id: subscriptionId }).forUpdate().first();
      if (!sub) throw new AppError(404, 'Subscription not found');
      if (!['active', 'trial'].includes(sub.status)) {
        throw new AppError(400, 'Cannot change plan in current status');
      }
      if (sub.plan_id === newPlanId) {
        throw new AppError(400, 'Already on this plan');
      }

      const oldPlan = await this.planService.getById(sub.plan_id);
      const newPlan = await this.planService.getById(newPlanId);
      const proration = this.compute(oldPlan, newPlan, sub as Subscription, changeDate);

      if (proration.creditCents > 0) {
        await this.creditService.issue({
          customer_id: sub.customer_id,
          amount_cents: proration.creditCents,
          reason: 'proration_credit',
          subscription_id: subscriptionId,
        });
      }

      const [updated] = await trx('subscriptions')
        .where({ id: subscriptionId })
        .update({ plan_id: newPlanId, updated_at: trx.fn.now() })
        .returning('*');

      let prorationInvoice = null;
      if (proration.netCents > 0) {
        prorationInvoice = await this.invoiceService.createProrationCharge(
          updated as Subscription,
          proration.netCents,
          `Plan change proration (${oldPlan.name} → ${newPlan.name})`
        );
      }

      return {
        subscription: updated as Subscription,
        proration,
        proration_invoice: prorationInvoice,
      };
    });
  }
}
