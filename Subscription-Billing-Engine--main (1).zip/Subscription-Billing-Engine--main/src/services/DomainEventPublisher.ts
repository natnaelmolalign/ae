import type { Knex } from 'knex';
import { getDb } from '../config/database';

export interface PublishEventInput {
  eventType: string;
  aggregateType: string;
  aggregateId: string;
  payload: Record<string, unknown>;
  channels?: string[];
}

export interface DomainEvent {
  id: string;
  event_type: string;
  aggregate_type: string;
  aggregate_id: string;
  payload: Record<string, unknown>;
  occurred_at: Date;
}

export class DomainEventPublisher {
  async publish(
    input: PublishEventInput,
    trx: Knex.Transaction | Knex = getDb()
  ): Promise<DomainEvent> {
    const channels = input.channels ?? ['webhook'];
    const [event] = await trx('domain_events')
      .insert({
        event_type: input.eventType,
        aggregate_type: input.aggregateType,
        aggregate_id: input.aggregateId,
        payload: JSON.stringify(input.payload),
      })
      .returning('*');

    for (const channel of channels) {
      await trx('outbox_messages').insert({
        domain_event_id: event.id,
        channel,
        status: 'pending',
        next_attempt_at: trx.fn.now(),
      });
    }

    return {
      id: event.id as string,
      event_type: event.event_type as string,
      aggregate_type: event.aggregate_type as string,
      aggregate_id: event.aggregate_id as string,
      payload:
        typeof event.payload === 'string'
          ? JSON.parse(event.payload as string)
          : (event.payload as Record<string, unknown>),
      occurred_at: event.occurred_at as Date,
    };
  }
}
