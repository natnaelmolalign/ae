import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { CustomerService } from './CustomerService';

export interface DataExportRequest {
  id: string;
  customer_id: string;
  status: 'pending' | 'completed' | 'failed';
  artifact: Record<string, unknown>;
  completed_at: string | null;
}

export class DataExportService {
  async request(customerId: string): Promise<DataExportRequest> {
    await new CustomerService().getById(customerId);
    const [row] = await getDb()('data_export_requests')
      .insert({ customer_id: customerId, status: 'pending', artifact: JSON.stringify({}) })
      .returning('*');
    return this.parse(row);
  }

  async process(requestId: string): Promise<DataExportRequest> {
    const req = await this.getById(requestId);
    if (req.status !== 'pending') return req;

    try {
      const artifact = await this.buildArtifact(req.customer_id);
      const [row] = await getDb()('data_export_requests')
        .where({ id: requestId })
        .update({
          status: 'completed',
          artifact: JSON.stringify(artifact),
          completed_at: getDb().fn.now(),
          updated_at: getDb().fn.now(),
        })
        .returning('*');
      return this.parse(row!);
    } catch (err) {
      await getDb()('data_export_requests').where({ id: requestId }).update({
        status: 'failed',
        artifact: JSON.stringify({ error: String(err) }),
        updated_at: getDb().fn.now(),
      });
      throw err instanceof AppError ? err : new AppError(500, 'Export failed', 'EXPORT_FAILED');
    }
  }

  async getById(id: string): Promise<DataExportRequest> {
    const row = await getDb()('data_export_requests').where({ id }).first();
    if (!row) throw new AppError(404, 'Export request not found');
    return this.parse(row);
  }

  async listForCustomer(customerId: string): Promise<DataExportRequest[]> {
    const rows = await getDb()('data_export_requests')
      .where({ customer_id: customerId })
      .orderBy('created_at', 'desc');
    return rows.map((r) => this.parse(r));
  }

  private async buildArtifact(customerId: string): Promise<Record<string, unknown>> {
    const customer = await new CustomerService().getById(customerId);
    const subs = await getDb()('subscriptions').where({ customer_id: customerId });
    const invoices = await getDb()('invoices').whereIn(
      'subscription_id',
      subs.map((s) => s.id)
    );
    const payments = await getDb()('payments').whereIn(
      'invoice_id',
      invoices.map((i) => i.id)
    );
    return {
      exported_at: new Date().toISOString(),
      customer: { id: customer.id, email: customer.email, name: customer.name },
      subscriptions: subs,
      invoices,
      payments,
      subscription_count: subs.length,
      invoice_count: invoices.length,
    };
  }

  private parse(row: Record<string, unknown>): DataExportRequest {
    return {
      ...row,
      artifact:
        typeof row.artifact === 'string' ? JSON.parse(row.artifact) : (row.artifact as Record<string, unknown>),
    } as DataExportRequest;
  }
}
