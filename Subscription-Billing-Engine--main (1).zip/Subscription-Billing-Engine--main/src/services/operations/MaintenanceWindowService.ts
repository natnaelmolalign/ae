import { getDb } from '../../config/database';

export interface MaintenanceWindow {
  id: string;
  starts_at: string;
  ends_at: string;
  reason: string;
  blocks_writes: boolean;
}

export class MaintenanceWindowService {
  async schedule(startsAt: Date, endsAt: Date, reason: string, blocksWrites = true): Promise<MaintenanceWindow> {
    if (endsAt <= startsAt) throw new Error('ends_at must be after starts_at');
    const [row] = await getDb()('maintenance_windows')
      .insert({
        starts_at: startsAt,
        ends_at: endsAt,
        reason,
        blocks_writes: blocksWrites,
      })
      .returning('*');
    return row as MaintenanceWindow;
  }

  async isActive(at = new Date()): Promise<boolean> {
    const row = await getDb()('maintenance_windows')
      .where('starts_at', '<=', at)
      .andWhere('ends_at', '>=', at)
      .first();
    return Boolean(row);
  }

  async activeWindow(at = new Date()): Promise<MaintenanceWindow | null> {
    const row = await getDb()('maintenance_windows')
      .where('starts_at', '<=', at)
      .andWhere('ends_at', '>=', at)
      .first();
    return row ? (row as MaintenanceWindow) : null;
  }

  async listUpcoming(limit = 10): Promise<MaintenanceWindow[]> {
    return getDb()('maintenance_windows')
      .where('ends_at', '>=', new Date())
      .orderBy('starts_at', 'asc')
      .limit(limit);
  }
}
