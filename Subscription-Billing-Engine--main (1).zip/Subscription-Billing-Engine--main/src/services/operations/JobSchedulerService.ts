import { getDb } from '../../config/database';
import { runBillingJob } from '../../jobs/billingJob';
import { runRetryJob } from '../../jobs/retryJob';
import { runOutboxJob } from '../../jobs/outboxJob';
import { runAnalyticsJob } from '../../jobs/analyticsJob';
import { runRetentionJob } from '../../jobs/retentionJob';
import { runExportJob } from '../../jobs/exportJob';
import { runForecastJob } from '../../jobs/forecastJob';
import { JobLockService, type JobName } from '../JobLockService';

export type ScheduledJobName =
  | 'billing'
  | 'retry'
  | 'outbox'
  | 'analytics'
  | 'retention'
  | 'export'
  | 'forecast';

export interface ScheduleResult {
  job: ScheduledJobName;
  skipped: boolean;
  output?: number | Record<string, unknown>;
}

const ORDER: ScheduledJobName[] = [
  'billing',
  'retry',
  'outbox',
  'analytics',
  'retention',
  'export',
  'forecast',
];

const LOCKABLE: JobName[] = ['billing', 'retry', 'outbox', 'analytics'];

export class JobSchedulerService {
  constructor(private readonly locks = new JobLockService()) {}

  async runJob(name: ScheduledJobName): Promise<ScheduleResult> {
    const run = async () => this.execute(name);
    if (LOCKABLE.includes(name as JobName)) {
      const result = await this.locks.runExclusive(name as JobName, run);
      return {
        job: name,
        skipped: result.skipped,
        output: result.result,
      };
    }
    const output = await run();
    return { job: name, skipped: false, output };
  }

  async runNightlyBundle(): Promise<ScheduleResult[]> {
    const results: ScheduleResult[] = [];
    for (const job of ORDER) {
      results.push(await this.runJob(job));
    }
    return results;
  }

  private async execute(name: ScheduledJobName): Promise<number | Record<string, unknown>> {
    switch (name) {
      case 'billing':
        return runBillingJob();
      case 'retry':
        return runRetryJob();
      case 'outbox':
        return runOutboxJob();
      case 'analytics':
        return runAnalyticsJob(new Date(), 1);
      case 'retention':
        return runRetentionJob();
      case 'export':
        return runExportJob();
      case 'forecast':
        return runForecastJob();
      default:
        return 0;
    }
  }

  async lastRuns(limit = 20) {
    return getDb()('job_runs').orderBy('started_at', 'desc').limit(limit);
  }

  async jobsDueNow(): Promise<ScheduledJobName[]> {
    const hour = new Date().getUTCHours();
    const due: ScheduledJobName[] = ['billing', 'retry', 'outbox'];
    if (hour === 2) due.push('analytics', 'retention');
    if (hour === 3) due.push('export', 'forecast');
    return due;
  }
}
