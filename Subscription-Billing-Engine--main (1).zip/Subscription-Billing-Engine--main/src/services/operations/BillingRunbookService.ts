import { BillingAlertService } from '../BillingAlertService';
import { BillingReconciliationService } from '../BillingReconciliationService';
import { BillingPeriodCloseService } from '../BillingPeriodCloseService';
import { ComplianceReportBuilder } from '../compliance/ComplianceReportBuilder';
import { JobSchedulerService } from './JobSchedulerService';
import { MaintenanceWindowService } from './MaintenanceWindowService';

export interface RunbookStep {
  id: string;
  title: string;
  automated: boolean;
}

export interface RunbookExecution {
  runbook: string;
  steps_completed: string[];
  findings: Record<string, unknown>;
}

const MONTH_END_STEPS: RunbookStep[] = [
  { id: 'reconcile', title: 'Reconcile open invoices', automated: true },
  { id: 'period_close', title: 'Close billing period', automated: true },
  { id: 'compliance', title: 'Generate compliance snapshot', automated: true },
  { id: 'alerts', title: 'Evaluate billing alerts', automated: true },
  { id: 'scheduler', title: 'Run nightly job bundle', automated: true },
];

/**
 * Encodes month-end and incident runbooks as executable checklists.
 */
export class BillingRunbookService {
  listMonthEndSteps(): RunbookStep[] {
    return [...MONTH_END_STEPS];
  }

  async executeMonthEnd(periodStart: string, periodEnd: string): Promise<RunbookExecution> {
    const steps: string[] = [];
    const findings: Record<string, unknown> = {};

    const recon = await new BillingReconciliationService().reconcileOpenInvoices();
    steps.push('reconcile');
    findings.reconciliation = recon;

    const close = new BillingPeriodCloseService();
    await close.openPeriod(periodStart, periodEnd);
    const closed = await close.reconcile(periodStart, periodEnd);
    steps.push('period_close');
    findings.period_close = closed;

    findings.compliance = await new ComplianceReportBuilder().buildFull();
    steps.push('compliance');

    const alerts = new BillingAlertService();
    findings.payment_alert = await alerts.evaluatePaymentFailureSpike(0);
    findings.past_due_alert = await alerts.evaluatePastDueSubscriptions(0);
    steps.push('alerts');

    const maintenance = new MaintenanceWindowService();
    if (await maintenance.isActive()) {
      findings.scheduler = { skipped: true, reason: 'maintenance_window' };
    } else {
      findings.scheduler = await new JobSchedulerService().runNightlyBundle();
    }
    steps.push('scheduler');

    return { runbook: 'month_end', steps_completed: steps, findings };
  }

  async executeIncidentResponse(): Promise<RunbookExecution> {
    const alerts = await new BillingAlertService().listOpen('critical');
    const recon = await new BillingReconciliationService().reconcileOpenInvoices();
    return {
      runbook: 'incident_response',
      steps_completed: ['triage_alerts', 'reconcile'],
      findings: { open_critical_alerts: alerts.length, reconciliation: recon },
    };
  }
}
