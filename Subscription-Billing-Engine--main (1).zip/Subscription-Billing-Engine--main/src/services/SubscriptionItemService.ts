import type { Knex } from 'knex';
import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import type { Subscription } from '../models/Subscription';
import { daysInPeriod, daysRemainingInPeriod, parseDate } from '../utils/dateUtils';
import { AddonProductService } from './AddonProductService';
import { PlanService } from './PlanService';
import { SubscriptionService } from './SubscriptionService';
import { CreditService } from './CreditService';

export interface SubscriptionItem {
  id: string;
  subscription_id: string;
  item_type: 'base_plan' | 'addon';
  plan_id: string | null;
  addon_product_id: string | null;
  description: string;
  unit_price_cents: number;
  quantity: number;
  active: boolean;
}

export class SubscriptionItemService {
  constructor(
    private subscriptionService = new SubscriptionService(),
    private planService = new PlanService(),
    private addonService = new AddonProductService(),
    private creditService = new CreditService()
  ) {}

  async syncBasePlanItem(subscription: Subscription, trx: Knex.Transaction): Promise<void> {
    const plan = await this.planService.getById(subscription.plan_id);
    const existing = await trx('subscription_items')
      .where({ subscription_id: subscription.id, item_type: 'base_plan', active: true })
      .first();

    if (existing) {
      await trx('subscription_items').where({ id: existing.id }).update({
        plan_id: plan.id,
        description: `${plan.name} (base)`,
        unit_price_cents: plan.price_cents,
        updated_at: trx.fn.now(),
      });
      return;
    }

    await trx('subscription_items').insert({
      subscription_id: subscription.id,
      item_type: 'base_plan',
      plan_id: plan.id,
      addon_product_id: null,
      description: `${plan.name} (base)`,
      unit_price_cents: plan.price_cents,
      quantity: 1,
      active: true,
    });
  }

  async addAddon(
    subscriptionId: string,
    addonCode: string,
    quantity = 1
  ): Promise<SubscriptionItem> {
    const sub = await this.subscriptionService.getById(subscriptionId);
    if (!['active', 'trial', 'past_due'].includes(sub.status)) {
      throw new AppError(400, 'Cannot add add-on in current status');
    }
    const addon = await this.addonService.getByCode(addonCode);
    const [row] = await getDb()('subscription_items')
      .insert({
        subscription_id: subscriptionId,
        item_type: 'addon',
        plan_id: null,
        addon_product_id: addon.id,
        description: addon.name,
        unit_price_cents: addon.price_cents,
        quantity,
        active: true,
      })
      .returning('*');
    return row as SubscriptionItem;
  }

  async listActive(subscriptionId: string): Promise<SubscriptionItem[]> {
    return getDb()('subscription_items')
      .where({ subscription_id: subscriptionId, active: true })
      .orderBy('created_at', 'asc');
  }

  async computeRecurringSubtotalCents(subscriptionId: string): Promise<number> {
    const items = await this.listActive(subscriptionId);
    return items.reduce(
      (sum, item) => sum + Number(item.unit_price_cents) * Number(item.quantity),
      0
    );
  }

  async changeQuantity(
    itemId: string,
    newQuantity: number,
    changeDate: string
  ): Promise<{ item: SubscriptionItem; prorationCents: number }> {
    if (newQuantity < 1) throw new AppError(400, 'Quantity must be at least 1');

    const db = getDb();
    return db.transaction(async (trx) => {
      const item = await trx('subscription_items').where({ id: itemId }).forUpdate().first();
      if (!item || !item.active) throw new AppError(404, 'Subscription item not found');
      if (item.item_type !== 'addon') {
        throw new AppError(400, 'Only add-on quantities can be changed');
      }

      const sub = await this.subscriptionService.getById(item.subscription_id as string);
      const oldQty = Number(item.quantity);
      const deltaQty = newQuantity - oldQty;
      const unitPrice = Number(item.unit_price_cents);

      let prorationCents = 0;
      if (deltaQty !== 0) {
        const remaining = daysRemainingInPeriod(
          parseDate(changeDate),
          parseDate(sub.current_period_end)
        );
        const totalDays =
          daysInPeriod(
            parseDate(sub.current_period_start),
            parseDate(sub.current_period_end)
          ) || 1;
        const daily = (unitPrice * Math.abs(deltaQty)) / totalDays;
        prorationCents = Math.round(daily * remaining) * Math.sign(deltaQty);
      }

      const [updated] = await trx('subscription_items')
        .where({ id: itemId })
        .update({ quantity: newQuantity, updated_at: trx.fn.now() })
        .returning('*');

      if (prorationCents > 0) {
        const { InvoiceService } = await import('./InvoiceService');
        await new InvoiceService().createProrationCharge(
          sub,
          prorationCents,
          `Add-on quantity increase (${item.description})`
        );
      } else if (prorationCents < 0) {
        await this.creditService.issue({
          customer_id: sub.customer_id,
          amount_cents: Math.abs(prorationCents),
          reason: `Add-on quantity decrease (${item.description})`,
          subscription_id: sub.id,
        });
      }

      return { item: updated as SubscriptionItem, prorationCents };
    });
  }
}
