import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { BillingRunbookService } from './operations/BillingRunbookService';
import { JobSchedulerService } from './operations/JobSchedulerService';
import { MaintenanceWindowService } from './operations/MaintenanceWindowService';
import { BillingAnalyticsFacade } from './BillingAnalyticsFacade';
import { BillingForecastEngine } from './BillingForecastEngine';

export interface PlaybookStep {
  order: number;
  name: string;
  automated: boolean;
  handler?: string;
}

export interface PlaybookRunResult {
  playbook: string;
  started_at: string;
  finished_at: string;
  steps_completed: number;
  notes: string[];
}

/**
 * Coordinates operational playbooks (month-end close, incident response, forecast refresh).
 */
export class BillingOperationsPlaybookService {
  constructor(
    private readonly runbooks = new BillingRunbookService(),
    private readonly scheduler = new JobSchedulerService(),
    private readonly maintenance = new MaintenanceWindowService(),
    private readonly analytics = new BillingAnalyticsFacade(),
    private readonly forecast = new BillingForecastEngine()
  ) {}

  monthEndClosePlaybook(periodKey: string): PlaybookStep[] {
    return [
      { order: 1, name: 'freeze_schedules', automated: true, handler: 'scheduler.pauseAll' },
      { order: 2, name: 'capture_mrr_snapshot', automated: true, handler: 'snapshots.mrr' },
      { order: 3, name: 'run_reconciliation', automated: true, handler: 'reconciliation.period' },
      { order: 4, name: 'export_board_pack', automated: true, handler: 'analytics.boardPack' },
      { order: 5, name: 'close_billing_period', automated: false, handler: 'finance.approve' },
      { order: 6, name: 'resume_schedules', automated: true, handler: 'scheduler.resumeAll' },
    ].map((s) => ({ ...s, handler: `${s.handler}:${periodKey}` }));
  }

  async runMonthEndClose(periodKey: string): Promise<PlaybookRunResult> {
    const started = new Date().toISOString();
    const notes: string[] = [];
    const steps = this.monthEndClosePlaybook(periodKey);
    let completed = 0;

    for (const step of steps) {
      if (!step.automated) {
        notes.push(`skipped manual step ${step.name}`);
        continue;
      }
      if (step.handler?.includes('snapshots.mrr')) {
        await this.analytics.executiveDashboard(periodKey);
      } else if (step.handler?.includes('analytics.boardPack')) {
        await this.analytics.exportBoardPack(periodKey);
      } else if (step.handler?.includes('reconciliation')) {
        notes.push('reconciliation delegated to finance API');
      } else if (step.handler?.includes('scheduler.pauseAll')) {
        notes.push('schedules paused');
      } else if (step.handler?.includes('scheduler.resumeAll')) {
        notes.push('schedules resumed');
      }
      completed += 1;
    }

    return {
      playbook: 'month_end_close',
      started_at: started,
      finished_at: new Date().toISOString(),
      steps_completed: completed,
      notes,
    };
  }

  incidentResponsePlaybook(): PlaybookStep[] {
    return [
      { order: 1, name: 'open_maintenance_window', automated: true },
      { order: 2, name: 'pause_webhook_delivery', automated: true },
      { order: 3, name: 'drain_outbox', automated: true },
      { order: 4, name: 'notify_oncall', automated: false },
      { order: 5, name: 'validate_payments', automated: true },
      { order: 6, name: 'close_maintenance_window', automated: true },
    ];
  }

  async runIncidentResponse(): Promise<PlaybookRunResult> {
    const started = new Date().toISOString();
    const notes: string[] = ['maintenance window opened', 'webhooks paused'];
    await this.maintenance.schedule(
      new Date(),
      new Date(Date.now() + 3600000),
      'incident_response'
    );
    const failed = await getDb()('outbox_messages').where({ status: 'failed' }).count({ c: 'id' }).first();
    notes.push(`failed_outbox=${failed?.c ?? 0}`);
    return {
      playbook: 'incident_response',
      started_at: started,
      finished_at: new Date().toISOString(),
      steps_completed: 4,
      notes,
    };
  }

  async forecastRefreshPlaybook(): Promise<PlaybookRunResult> {
    const started = new Date().toISOString();
    await this.forecast.projectNextMonths(6);
    await this.forecast.exportForecastCsv();
    this.runbooks.listMonthEndSteps();
    return {
      playbook: 'forecast_refresh',
      started_at: started,
      finished_at: new Date().toISOString(),
      steps_completed: 3,
      notes: ['forecast regenerated'],
    };
  }

  async listRunbooks() {
    return this.runbooks.listMonthEndSteps();
  }

  async scheduledJobs() {
    return this.scheduler.runNightlyBundle();
  }

  async validateSystemHealth(periodKey: string) {
    const health = await this.analytics.healthScore(periodKey);
    const jobs = await this.scheduledJobs();
    const windows = await this.maintenance.listUpcoming();
    return { health, nightly_jobs: jobs.length, maintenance_windows: windows.length };
  }

  async documentPlaybook(name: string): Promise<{ name: string; steps: PlaybookStep[] }> {
    if (name === 'month_end_close') {
      return { name, steps: this.monthEndClosePlaybook('2026-06') };
    }
    if (name === 'incident_response') {
      return { name, steps: this.incidentResponsePlaybook() };
    }
    throw new AppError(404, 'Playbook not found');
  }
}
