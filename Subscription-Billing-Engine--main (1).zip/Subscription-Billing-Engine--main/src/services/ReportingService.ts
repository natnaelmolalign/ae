import { getDb } from '../config/database';

export interface ArAgingBucket {
  bucket: string;
  invoice_count: number;
  total_cents: number;
}

export interface MrrSnapshot {
  as_of: string;
  active_subscriptions: number;
  mrr_cents: number;
  arr_cents: number;
}

export interface RevenueByPlanRow {
  plan_id: string;
  plan_name: string;
  paid_cents: number;
  invoice_count: number;
}

export class ReportingService {
  async arAging(asOf: string): Promise<ArAgingBucket[]> {
    const rows = await getDb()('invoices')
      .whereIn('status', ['pending', 'open'])
      .andWhere('due_date', '<=', asOf)
      .select('id', 'total_cents', 'due_date');

    const buckets: Record<string, ArAgingBucket> = {
      current: { bucket: 'current', invoice_count: 0, total_cents: 0 },
      '1_30': { bucket: '1_30', invoice_count: 0, total_cents: 0 },
      '31_60': { bucket: '31_60', invoice_count: 0, total_cents: 0 },
      '61_90': { bucket: '61_90', invoice_count: 0, total_cents: 0 },
      '90_plus': { bucket: '90_plus', invoice_count: 0, total_cents: 0 },
    };

    const asOfDate = new Date(asOf);
    for (const inv of rows) {
      const due = new Date(inv.due_date as string);
      const days = Math.floor((asOfDate.getTime() - due.getTime()) / 86_400_000);
      let key = 'current';
      if (days > 90) key = '90_plus';
      else if (days > 60) key = '61_90';
      else if (days > 30) key = '31_60';
      else if (days > 0) key = '1_30';
      buckets[key].invoice_count += 1;
      buckets[key].total_cents += Number(inv.total_cents);
    }
    return Object.values(buckets);
  }

  async mrrSnapshot(asOf: string): Promise<MrrSnapshot> {
    const subs = await getDb()('subscriptions as s')
      .join('plans as p', 'p.id', 's.plan_id')
      .whereIn('s.status', ['active', 'trial'])
      .andWhere('s.current_period_start', '<=', asOf)
      .select('s.id', 'p.price_cents', 'p.interval');

    let mrr = 0;
    for (const sub of subs) {
      const price = Number(sub.price_cents);
      mrr += sub.interval === 'yearly' ? Math.round(price / 12) : price;
    }
    return {
      as_of: asOf,
      active_subscriptions: subs.length,
      mrr_cents: mrr,
      arr_cents: mrr * 12,
    };
  }

  async revenueByPlan(from: string, to: string): Promise<RevenueByPlanRow[]> {
    const rows = await getDb()('invoices as i')
      .join('subscriptions as s', 's.id', 'i.subscription_id')
      .join('plans as p', 'p.id', 's.plan_id')
      .where('i.status', 'paid')
      .andWhereBetween('i.updated_at', [from, to])
      .groupBy('p.id', 'p.name')
      .select('p.id as plan_id', 'p.name as plan_name')
      .sum('i.total_cents as paid_cents')
      .count('i.id as invoice_count');

    return rows.map((r) => ({
      plan_id: r.plan_id as string,
      plan_name: r.plan_name as string,
      paid_cents: Number(r.paid_cents ?? 0),
      invoice_count: Number(r.invoice_count ?? 0),
    }));
  }

  async churnRate(from: string, to: string): Promise<{ cancelled: number; active_start: number; rate: number }> {
    const cancelled = await getDb()('subscriptions')
      .where('status', 'cancelled')
      .andWhereBetween('updated_at', [from, to])
      .count('* as count')
      .first();
    const activeStart = await getDb()('subscriptions')
      .whereIn('status', ['active', 'trial', 'past_due'])
      .andWhere('created_at', '<', from)
      .count('* as count')
      .first();
    const c = Number((cancelled as { count: string }).count);
    const a = Number((activeStart as { count: string }).count) || 1;
    return { cancelled: c, active_start: a, rate: Math.round((c / a) * 10000) / 10000 };
  }

  async failedPaymentSummary(from: string, to: string): Promise<{ count: number; total_cents: number }> {
    const row = await getDb()('payments')
      .where('status', 'failed')
      .andWhereBetween('attempted_at', [from, to])
      .select(getDb().raw('count(*) as count'), getDb().raw('coalesce(sum(amount_cents),0) as total'))
      .first();
    return {
      count: Number(row?.count ?? 0),
      total_cents: Number(row?.total ?? 0),
    };
  }
}
