import {
  calculateTaxCents,
  listTaxRules,
  resolveJurisdiction,
  type TaxJurisdictionCode,
} from '../domain/tax/TaxRules';

export interface TaxBreakdown {
  jurisdiction: TaxJurisdictionCode;
  subtotal_cents: number;
  tax_cents: number;
  total_cents: number;
  rate_bps: number;
  inclusive: boolean;
}

export class TaxCalculationService {
  computeForCustomer(
    subtotalCents: number,
    country: string,
    region?: string
  ): TaxBreakdown {
    const jurisdiction = resolveJurisdiction(country, region);
    const { taxCents, rateBps, inclusive } = calculateTaxCents(subtotalCents, jurisdiction);
    const total = inclusive ? subtotalCents : subtotalCents + taxCents;
    return {
      jurisdiction,
      subtotal_cents: subtotalCents,
      tax_cents: taxCents,
      total_cents: total,
      rate_bps: rateBps,
      inclusive,
    };
  }

  listSupportedJurisdictions() {
    return listTaxRules();
  }
}
