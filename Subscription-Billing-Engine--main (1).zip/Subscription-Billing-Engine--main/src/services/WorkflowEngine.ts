import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface WorkflowTransition {
  from: string | '*';
  to: string;
  trigger: string;
  guards?: string[];
}

export interface WorkflowDefinitionRow {
  id: string;
  name: string;
  entity_type: string;
  states: string[];
  transitions: WorkflowTransition[];
  version: number;
}

export interface WorkflowInstanceRow {
  id: string;
  definition_id: string;
  entity_type: string;
  entity_id: string;
  current_state: string;
  context: Record<string, unknown>;
  completed_at: Date | null;
}

export class WorkflowEngine {
  async registerDefinition(
    name: string,
    entityType: string,
    states: string[],
    transitions: WorkflowTransition[]
  ): Promise<WorkflowDefinitionRow> {
    this.validateDefinition(states, transitions);
    const db = getDb();
    const existing = await db('workflow_definitions').where({ name }).first();
    if (existing) {
      const [updated] = await db('workflow_definitions')
        .where({ id: existing.id })
        .update({
          entity_type: entityType,
          states: JSON.stringify(states),
          transitions: JSON.stringify(transitions),
          version: existing.version + 1,
          updated_at: db.fn.now(),
        })
        .returning('*');
      return this.parseDefinition(updated);
    }
    const [row] = await db('workflow_definitions')
      .insert({
        name,
        entity_type: entityType,
        states: JSON.stringify(states),
        transitions: JSON.stringify(transitions),
      })
      .returning('*');
    return this.parseDefinition(row);
  }

  private validateDefinition(states: string[], transitions: WorkflowTransition[]): void {
    if (states.length === 0) throw new AppError(400, 'Workflow requires at least one state');
    for (const t of transitions) {
      if (t.from !== '*' && !states.includes(t.from)) {
        throw new AppError(400, `Unknown from state ${t.from}`);
      }
      if (!states.includes(t.to)) {
        throw new AppError(400, `Unknown to state ${t.to}`);
      }
    }
  }

  private parseDefinition(row: Record<string, unknown>): WorkflowDefinitionRow {
    return {
      ...row,
      states: typeof row.states === 'string' ? JSON.parse(row.states) : row.states,
      transitions: typeof row.transitions === 'string' ? JSON.parse(row.transitions) : row.transitions,
    } as WorkflowDefinitionRow;
  }

  async start(
    definitionName: string,
    entityType: string,
    entityId: string,
    initialState: string,
    context: Record<string, unknown> = {}
  ): Promise<WorkflowInstanceRow> {
    const db = getDb();
    const def = await db('workflow_definitions').where({ name: definitionName }).first();
    if (!def) throw new AppError(404, 'Workflow definition not found');
    const parsed = this.parseDefinition(def);
    if (!parsed.states.includes(initialState)) {
      throw new AppError(400, `Invalid initial state ${initialState}`);
    }
    const open = await db('workflow_instances')
      .where({ entity_type: entityType, entity_id: entityId })
      .whereNull('completed_at')
      .first();
    if (open) throw new AppError(409, 'Active workflow already exists for entity');

    const [instance] = await db('workflow_instances')
      .insert({
        definition_id: def.id,
        entity_type: entityType,
        entity_id: entityId,
        current_state: initialState,
        context: JSON.stringify(context),
      })
      .returning('*');
    await db('workflow_history').insert({
      instance_id: instance.id,
      from_state: null,
      to_state: initialState,
      trigger: 'start',
    });
    return this.parseInstance(instance);
  }

  private parseInstance(row: Record<string, unknown>): WorkflowInstanceRow {
    return {
      ...row,
      context: typeof row.context === 'string' ? JSON.parse(row.context) : row.context,
    } as WorkflowInstanceRow;
  }

  async trigger(
    instanceId: string,
    trigger: string,
    actorPrincipalId?: string,
    contextPatch: Record<string, unknown> = {}
  ): Promise<WorkflowInstanceRow> {
    const db = getDb();
    const instance = await db('workflow_instances').where({ id: instanceId }).first();
    if (!instance) throw new AppError(404, 'Workflow instance not found');
    if (instance.completed_at) throw new AppError(400, 'Workflow already completed');

    const def = await db('workflow_definitions').where({ id: instance.definition_id }).first();
    const parsed = this.parseDefinition(def);
    const transition = parsed.transitions.find(
      (t) =>
        t.trigger === trigger &&
        (t.from === '*' || t.from === instance.current_state)
    );
    if (!transition) {
      throw new AppError(400, `No transition for trigger ${trigger} from ${instance.current_state}`);
    }

    const context = {
      ...this.parseInstance(instance).context,
      ...contextPatch,
    };
    const isTerminal = !parsed.transitions.some((t) => t.from === transition.to);
    const [updated] = await db('workflow_instances')
      .where({ id: instanceId })
      .update({
        current_state: transition.to,
        context: JSON.stringify(context),
        completed_at: isTerminal ? db.fn.now() : null,
        updated_at: db.fn.now(),
      })
      .returning('*');

    await db('workflow_history').insert({
      instance_id: instanceId,
      from_state: instance.current_state,
      to_state: transition.to,
      trigger,
      actor_principal_id: actorPrincipalId ?? null,
    });
    return this.parseInstance(updated);
  }

  async getInstance(instanceId: string): Promise<WorkflowInstanceRow> {
    const row = await getDb()('workflow_instances').where({ id: instanceId }).first();
    if (!row) throw new AppError(404, 'Workflow instance not found');
    return this.parseInstance(row);
  }

  async getHistory(instanceId: string) {
    return getDb()('workflow_history')
      .where({ instance_id: instanceId })
      .orderBy('created_at', 'asc');
  }

  async seedSubscriptionLifecycle(): Promise<WorkflowDefinitionRow> {
    return this.registerDefinition(
      'subscription_lifecycle',
      'subscription',
      ['draft', 'trialing', 'active', 'past_due', 'cancelled', 'expired'],
      [
        { from: 'draft', to: 'trialing', trigger: 'start_trial' },
        { from: 'draft', to: 'active', trigger: 'activate' },
        { from: 'trialing', to: 'active', trigger: 'trial_convert' },
        { from: 'trialing', to: 'expired', trigger: 'trial_expire' },
        { from: 'active', to: 'past_due', trigger: 'payment_failed' },
        { from: 'past_due', to: 'active', trigger: 'payment_recovered' },
        { from: 'past_due', to: 'cancelled', trigger: 'dunning_exhausted' },
        { from: 'active', to: 'cancelled', trigger: 'cancel' },
        { from: '*', to: 'cancelled', trigger: 'force_cancel' },
      ]
    );
  }
}
