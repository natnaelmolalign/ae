import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { logger } from '../lib/logger';

export type SagaStepStatus = 'pending' | 'completed' | 'compensated' | 'failed';

export interface SagaStep {
  name: string;
  run: () => Promise<void>;
  compensate?: () => Promise<void>;
}

export interface SagaRunRecord {
  id: string;
  saga_name: string;
  status: string;
  context: Record<string, unknown>;
}

/**
 * In-process saga coordinator with persisted run log for crash recovery inspection.
 */
export class SagaOrchestrator {
  async run(name: string, steps: SagaStep[], context: Record<string, unknown> = {}): Promise<SagaRunRecord> {
    const db = getDb();
    const completed: string[] = [];
    const [run] = await db('saga_runs')
      .insert({
        saga_name: name,
        status: 'running',
        steps: JSON.stringify([]),
        context: JSON.stringify(context),
      })
      .returning('*');

    try {
      for (const step of steps) {
        await step.run();
        completed.push(step.name);
        await db('saga_runs').where({ id: run.id }).update({
          steps: JSON.stringify(completed),
          updated_at: db.fn.now(),
        });
      }
      const [done] = await db('saga_runs')
        .where({ id: run.id })
        .update({ status: 'completed', updated_at: db.fn.now() })
        .returning('*');
      return this.parseRun(done);
    } catch (err) {
      logger.error('saga_step_failed', { saga: name, completed, err });
      for (let i = completed.length - 1; i >= 0; i--) {
        const step = steps.find((s) => s.name === completed[i]);
        if (step?.compensate) {
          await step.compensate();
        }
      }
      await db('saga_runs').where({ id: run.id }).update({ status: 'compensated', updated_at: db.fn.now() });
      throw err instanceof AppError ? err : new AppError(500, 'Saga failed', 'SAGA_FAILED');
    }
  }

  private parseRun(row: Record<string, unknown>): SagaRunRecord {
    return {
      id: row.id as string,
      saga_name: row.saga_name as string,
      status: row.status as string,
      context: typeof row.context === 'string' ? JSON.parse(row.context) : (row.context as Record<string, unknown>),
    };
  }

  async listRecent(limit = 20): Promise<SagaRunRecord[]> {
    const rows = await getDb()('saga_runs').orderBy('created_at', 'desc').limit(limit);
    return rows.map((r) => this.parseRun(r));
  }
}
