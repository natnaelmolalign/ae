import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface BillingSchedule {
  id: string;
  customer_id: string;
  name: string;
  cadence: 'monthly' | 'quarterly' | 'annual';
  anchor_day: number;
  line_templates: { description: string; amount_cents: number; quantity: number }[];
  active: boolean;
}

export class BillingScheduleService {
  async create(input: {
    customer_id: string;
    name: string;
    cadence: BillingSchedule['cadence'];
    anchor_day: number;
    line_templates?: BillingSchedule['line_templates'];
  }): Promise<BillingSchedule> {
    if (input.anchor_day < 1 || input.anchor_day > 28) {
      throw new AppError(400, 'anchor_day must be 1-28', 'INVALID_ANCHOR');
    }
    const [row] = await getDb()('billing_schedules')
      .insert({
        customer_id: input.customer_id,
        name: input.name,
        cadence: input.cadence,
        anchor_day: input.anchor_day,
        line_templates: JSON.stringify(input.line_templates ?? []),
        active: true,
      })
      .returning('*');
    return this.parse(row);
  }

  async getById(id: string): Promise<BillingSchedule> {
    const row = await getDb()('billing_schedules').where({ id }).first();
    if (!row) throw new AppError(404, 'Schedule not found');
    return this.parse(row);
  }

  async listForCustomer(customerId: string): Promise<BillingSchedule[]> {
    const rows = await getDb()('billing_schedules')
      .where({ customer_id: customerId })
      .orderBy('created_at', 'desc');
    return rows.map((r) => this.parse(r));
  }

  async deactivate(id: string): Promise<BillingSchedule> {
    const [row] = await getDb()('billing_schedules')
      .where({ id })
      .update({ active: false, updated_at: getDb().fn.now() })
      .returning('*');
    if (!row) throw new AppError(404, 'Schedule not found');
    return this.parse(row);
  }

  projectedMonthlyCents(schedule: BillingSchedule): number {
    const subtotal = schedule.line_templates.reduce(
      (s, l) => s + l.amount_cents * l.quantity,
      0
    );
    if (schedule.cadence === 'monthly') return subtotal;
    if (schedule.cadence === 'quarterly') return Math.round(subtotal / 3);
    return Math.round(subtotal / 12);
  }

  private parse(row: Record<string, unknown>): BillingSchedule {
    return {
      ...row,
      line_templates:
        typeof row.line_templates === 'string'
          ? JSON.parse(row.line_templates)
          : (row.line_templates as BillingSchedule['line_templates']),
    } as BillingSchedule;
  }
}
