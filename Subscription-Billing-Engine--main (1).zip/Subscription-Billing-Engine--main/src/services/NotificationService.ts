import { getDb } from '../config/database';
import { logger } from '../lib/logger';

export type NotificationChannel = 'email' | 'webhook' | 'internal';

export interface NotificationPayload {
  template: string;
  recipient: string;
  data: Record<string, unknown>;
}

export class NotificationService {
  async enqueue(
    channel: NotificationChannel,
    payload: NotificationPayload
  ): Promise<{ id: string }> {
    const [row] = await getDb()('notification_queue')
      .insert({
        channel,
        template: payload.template,
        recipient: payload.recipient,
        payload: JSON.stringify(payload.data),
        status: 'pending',
      })
      .returning('id');
    return { id: row.id as string };
  }

  async processPending(limit = 50): Promise<number> {
    const db = getDb();
    const pending = await db('notification_queue')
      .where({ status: 'pending' })
      .orderBy('created_at', 'asc')
      .limit(limit);
    let sent = 0;
    for (const row of pending) {
      logger.info('notification_dispatch', {
        channel: row.channel,
        template: row.template,
        recipient: row.recipient,
      });
      await db('notification_queue').where({ id: row.id }).update({
        status: 'sent',
        sent_at: db.fn.now(),
      });
      sent += 1;
    }
    return sent;
  }

  async notifyPaymentFailed(subscriptionId: string, invoiceId: string, email: string): Promise<void> {
    await this.enqueue('email', {
      template: 'payment_failed',
      recipient: email,
      data: { subscription_id: subscriptionId, invoice_id: invoiceId },
    });
  }
}
