import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export type DisputeStatus = 'open' | 'under_review' | 'won' | 'lost' | 'closed';

export interface Dispute {
  id: string;
  invoice_id: string;
  amount_cents: number;
  status: DisputeStatus;
  reason: string;
}

export class BillingDisputeService {
  async open(invoiceId: string, amountCents: number, reason: string): Promise<Dispute> {
    const invoice = await getDb()('invoices').where({ id: invoiceId }).first();
    if (!invoice) throw new AppError(404, 'Invoice not found');
    const [row] = await getDb()('billing_disputes')
      .insert({
        invoice_id: invoiceId,
        amount_cents: amountCents,
        status: 'open',
        reason,
      })
      .returning('*');
    return row as Dispute;
  }

  async transition(id: string, status: DisputeStatus): Promise<Dispute> {
    const [row] = await getDb()('billing_disputes')
      .where({ id })
      .update({ status, updated_at: getDb().fn.now() })
      .returning('*');
    if (!row) throw new AppError(404, 'Dispute not found');
    return row as Dispute;
  }

  async listOpen(): Promise<Dispute[]> {
    return getDb()('billing_disputes').where({ status: 'open' }).orderBy('created_at', 'desc');
  }
}
