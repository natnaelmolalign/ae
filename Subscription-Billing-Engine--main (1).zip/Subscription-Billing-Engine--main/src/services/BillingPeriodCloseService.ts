import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface PeriodCloseSummary {
  id: string;
  period_start: string;
  period_end: string;
  status: string;
  invoice_count: number;
  total_cents: number;
  closed_at: Date | null;
}

export class BillingPeriodCloseService {
  async openPeriod(periodStart: string, periodEnd: string): Promise<PeriodCloseSummary> {
    const db = getDb();
    const existing = await db('billing_period_closes')
      .where({ period_start: periodStart, period_end: periodEnd })
      .first();
    if (existing) return existing as PeriodCloseSummary;

    const [row] = await db('billing_period_closes')
      .insert({
        period_start: periodStart,
        period_end: periodEnd,
        status: 'open',
      })
      .returning('*');
    return row as PeriodCloseSummary;
  }

  async reconcile(periodStart: string, periodEnd: string): Promise<PeriodCloseSummary> {
    const db = getDb();
    const period = await db('billing_period_closes')
      .where({ period_start: periodStart, period_end: periodEnd })
      .first();
    if (!period) throw new AppError(404, 'Billing period not found');

    const invoices = await db('invoices')
      .where('created_at', '>=', periodStart)
      .andWhere('created_at', '<=', `${periodEnd}T23:59:59.999Z`);

    const paid = invoices.filter((i: { status: string }) => i.status === 'paid');
    const total = paid.reduce((s: number, i: { total_cents: number }) => s + Number(i.total_cents), 0);

    const [updated] = await db('billing_period_closes')
      .where({ id: period.id })
      .update({
        status: 'reconciled',
        invoice_count: invoices.length,
        total_cents: total,
        updated_at: db.fn.now(),
      })
      .returning('*');
    return updated as PeriodCloseSummary;
  }

  async close(periodStart: string, periodEnd: string): Promise<PeriodCloseSummary> {
    const db = getDb();
    const reconciled = await this.reconcile(periodStart, periodEnd);
    if (reconciled.status === 'closed') {
      throw new AppError(400, 'Period already closed');
    }
    const unpaid = await db('invoices')
      .where('created_at', '>=', periodStart)
      .andWhere('created_at', '<=', `${periodEnd}T23:59:59.999Z`)
      .whereNot('status', 'paid')
      .count('* as c');
    const unpaidCount = Number((unpaid[0] as { c: string }).c);
    if (unpaidCount > 0) {
      throw new AppError(409, `${unpaidCount} invoices still unpaid in period`, 'PERIOD_NOT_READY');
    }
    const [updated] = await db('billing_period_closes')
      .where({ period_start: periodStart, period_end: periodEnd })
      .update({ status: 'closed', closed_at: db.fn.now(), updated_at: db.fn.now() })
      .returning('*');
    return updated as PeriodCloseSummary;
  }

  async list(limit = 12): Promise<PeriodCloseSummary[]> {
    return getDb()('billing_period_closes')
      .orderBy('period_end', 'desc')
      .limit(limit);
  }
}
