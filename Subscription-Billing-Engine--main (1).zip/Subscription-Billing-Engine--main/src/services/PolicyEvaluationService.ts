import { BillingRulesEngine } from '../domain/billing/BillingRulesEngine';
import { DiscountEngine } from '../domain/pricing/DiscountEngine';
import { PriceBook } from '../domain/pricing/PriceBook';
import { TaxCalculationService } from './TaxCalculationService';

export interface PolicyQuoteInput {
  subtotal_cents: number;
  country: string;
  discount_codes?: string[];
  usage_quantity?: number;
  usage_tiers?: { up_to: number | null; unit_cents: number }[];
}

export interface PolicyQuoteResult {
  subtotal_cents: number;
  discount_cents: number;
  usage_cents: number;
  tax_cents: number;
  total_cents: number;
  jurisdiction: string;
}

/**
 * Composes domain pricing engines for quote previews without persisting invoices.
 */
export class PolicyEvaluationService {
  constructor(
    private readonly billingRules = new BillingRulesEngine(),
    private readonly discounts = DiscountEngine.standardPromos(),
    private readonly tax = new TaxCalculationService(),
    private readonly priceBook = PriceBook.defaultSaas()
  ) {}

  quote(input: PolicyQuoteInput): PolicyQuoteResult {
    let subtotal = input.subtotal_cents;
    let usageCents = 0;
    if (input.usage_quantity != null && input.usage_tiers) {
      usageCents = this.billingRules.tieredUsageCharge(input.usage_quantity, input.usage_tiers);
      subtotal += usageCents;
    }

    const { total: afterDiscount, lines } = this.discounts.apply(
      subtotal,
      input.discount_codes ?? []
    );
    const discountCents = lines.reduce((s, l) => s + l.amount_cents, 0);
    const taxResult = this.tax.computeForCustomer(afterDiscount, input.country);

    return {
      subtotal_cents: input.subtotal_cents,
      discount_cents: discountCents,
      usage_cents: usageCents,
      tax_cents: taxResult.tax_cents,
      total_cents: afterDiscount + taxResult.tax_cents,
      jurisdiction: taxResult.jurisdiction,
    };
  }

  seatPrice(seats: number): number {
    return this.priceBook.unitPriceForQuantity('seat', seats);
  }
}
