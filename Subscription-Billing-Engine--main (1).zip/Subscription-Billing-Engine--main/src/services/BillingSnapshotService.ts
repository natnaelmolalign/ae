import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export type SnapshotType = 'mrr' | 'arr' | 'usage' | 'collections';

export interface SnapshotMetrics {
  mrr_cents?: number;
  arr_cents?: number;
  active_subscriptions?: number;
  churned_subscriptions?: number;
  usage_rated_cents?: number;
  collected_cents?: number;
  outstanding_cents?: number;
  failed_payments?: number;
}

export interface SnapshotBreakdownRow {
  dimension: string;
  key: string;
  amount_cents: number;
  count?: number;
}

export interface CaptureSnapshotInput {
  snapshot_type: SnapshotType;
  period_key: string;
  customer_id?: string | null;
  currency?: string;
}

export class BillingSnapshotService {
  async capture(input: CaptureSnapshotInput): Promise<Record<string, unknown>> {
    const metrics = await this.computeMetrics(input.snapshot_type, input.period_key, input.customer_id);
    const breakdown = await this.computeBreakdown(input.snapshot_type, input.period_key, input.customer_id);
    const [row] = await getDb()('billing_revenue_snapshots')
      .insert({
        snapshot_type: input.snapshot_type,
        period_key: input.period_key,
        customer_id: input.customer_id ?? null,
        metrics: JSON.stringify(metrics),
        breakdown: JSON.stringify(breakdown),
        currency: input.currency ?? 'USD',
        captured_at: new Date(),
      })
      .onConflict(['snapshot_type', 'period_key', 'customer_id'])
      .merge({
        metrics: JSON.stringify(metrics),
        breakdown: JSON.stringify(breakdown),
        captured_at: new Date(),
      })
      .returning('*');
    return this.map(row);
  }

  async get(snapshotType: SnapshotType, periodKey: string, customerId?: string | null) {
    const q = getDb()('billing_revenue_snapshots')
      .where({ snapshot_type: snapshotType, period_key: periodKey });
    if (customerId) q.andWhere({ customer_id: customerId });
    else q.whereNull('customer_id');
    const row = await q.first();
    if (!row) throw new AppError(404, 'Snapshot not found');
    return this.map(row);
  }

  async list(periodKey?: string, snapshotType?: SnapshotType, limit = 50) {
    const q = getDb()('billing_revenue_snapshots').orderBy('captured_at', 'desc').limit(limit);
    if (periodKey) q.andWhere({ period_key: periodKey });
    if (snapshotType) q.andWhere({ snapshot_type: snapshotType });
    const rows = await q;
    return rows.map((r) => this.map(r));
  }

  async comparePeriods(
    snapshotType: SnapshotType,
    fromKey: string,
    toKey: string
  ): Promise<{ from: SnapshotMetrics; to: SnapshotMetrics; delta: SnapshotMetrics }> {
    const from = (await this.get(snapshotType, fromKey)).metrics as SnapshotMetrics;
    const to = (await this.get(snapshotType, toKey)).metrics as SnapshotMetrics;
    const delta: SnapshotMetrics = {};
    const keys = new Set([...Object.keys(from), ...Object.keys(to)]) as Set<keyof SnapshotMetrics>;
    for (const k of keys) {
      const a = Number(from[k] ?? 0);
      const b = Number(to[k] ?? 0);
      delta[k] = b - a;
    }
    return { from, to, delta };
  }

  async rollupArr(periodKey: string): Promise<number> {
    const snap = await this.capture({ snapshot_type: 'mrr', period_key: periodKey });
    const mrr = Number((snap.metrics as SnapshotMetrics).mrr_cents ?? 0);
    return mrr * 12;
  }

  private async computeMetrics(
    type: SnapshotType,
    periodKey: string,
    customerId?: string | null
  ): Promise<SnapshotMetrics> {
    const db = getDb();
    const period = this.parsePeriod(periodKey);
    if (type === 'mrr' || type === 'arr') {
      const q = db('subscriptions as s')
        .join('plans as p', 'p.id', 's.plan_id')
        .whereIn('s.status', ['active', 'trial', 'past_due'])
        .sum({ mrr: db.raw('p.price_cents') })
        .count({ active: 's.id' });
      if (customerId) q.andWhere('s.customer_id', customerId);
      const row = await q.first();
      const mrr = Number(row?.mrr ?? 0);
      return {
        mrr_cents: mrr,
        arr_cents: mrr * 12,
        active_subscriptions: Number(row?.active ?? 0),
      };
    }
    if (type === 'usage') {
      const q = db('usage_records')
        .whereBetween('recorded_at', [period.start, period.end])
        .sum({ qty: 'quantity' });
      const row = await q.first();
      return { usage_rated_cents: Number(row?.qty ?? 0) };
    }
    const payQ = db('payments').whereBetween('attempted_at', [period.start, period.end]);
    const collected = await payQ.clone().where({ status: 'succeeded' }).sum({ total: 'amount_cents' }).first();
    const failed = await payQ.clone().where({ status: 'failed' }).count({ c: 'id' }).first();
    const openInv = await db('invoices')
      .whereIn('status', ['pending', 'open'])
      .sum({ outstanding: 'total_cents' })
      .first();
    return {
      collected_cents: Number(collected?.total ?? 0),
      failed_payments: Number(failed?.c ?? 0),
      outstanding_cents: Number(openInv?.outstanding ?? 0),
    };
  }

  private async computeBreakdown(
    type: SnapshotType,
    periodKey: string,
    customerId?: string | null
  ): Promise<SnapshotBreakdownRow[]> {
    if (type !== 'mrr' && type !== 'arr') return [];
    const q = getDb()('subscriptions as s')
      .join('plans as p', 'p.id', 's.plan_id')
      .select('p.interval as dimension')
      .sum({ amount_cents: 'p.price_cents' })
      .count({ count: 's.id' })
      .whereIn('s.status', ['active', 'trial', 'past_due'])
      .groupBy('p.interval');
    if (customerId) q.andWhere('s.customer_id', customerId);
    const rows = await q;
    return rows.map((r: Record<string, unknown>) => ({
      dimension: 'interval',
      key: String(r.dimension),
      amount_cents: Number(r.amount_cents),
      count: Number(r.count),
    }));
  }

  private parsePeriod(periodKey: string): { start: Date; end: Date } {
    if (/^\d{4}-\d{2}$/.test(periodKey)) {
      const [y, m] = periodKey.split('-').map(Number);
      const start = new Date(Date.UTC(y, m - 1, 1));
      const end = new Date(Date.UTC(y, m, 0, 23, 59, 59, 999));
      return { start, end };
    }
    if (/^\d{4}-\d{2}-\d{2}$/.test(periodKey)) {
      const start = new Date(`${periodKey}T00:00:00Z`);
      const end = new Date(`${periodKey}T23:59:59Z`);
      return { start, end };
    }
    throw new AppError(400, 'period_key must be YYYY-MM or YYYY-MM-DD');
  }

  private map(row: Record<string, unknown>) {
    const metrics =
      typeof row.metrics === 'string' ? JSON.parse(row.metrics as string) : (row.metrics as SnapshotMetrics);
    const breakdown =
      typeof row.breakdown === 'string'
        ? JSON.parse(row.breakdown as string)
        : (row.breakdown as SnapshotBreakdownRow[]);
    return { ...row, metrics, breakdown };
  }
}
