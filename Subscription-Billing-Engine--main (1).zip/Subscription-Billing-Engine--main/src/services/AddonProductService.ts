import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface AddonProduct {
  id: string;
  code: string;
  name: string;
  price_cents: number;
  active: boolean;
}

export class AddonProductService {
  async create(input: {
    code: string;
    name: string;
    price_cents: number;
  }): Promise<AddonProduct> {
    const [row] = await getDb()('addon_products')
      .insert({
        code: input.code.toLowerCase(),
        name: input.name,
        price_cents: input.price_cents,
      })
      .returning('*');
    return row as AddonProduct;
  }

  async getByCode(code: string): Promise<AddonProduct> {
    const row = await getDb()('addon_products').where({ code: code.toLowerCase() }).first();
    if (!row) throw new AppError(404, 'Add-on product not found');
    return row as AddonProduct;
  }

  async list(): Promise<AddonProduct[]> {
    return getDb()('addon_products').where({ active: true }).orderBy('name', 'asc');
  }
}
