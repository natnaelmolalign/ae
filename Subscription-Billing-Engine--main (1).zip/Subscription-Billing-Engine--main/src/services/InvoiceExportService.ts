import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export type ExportFormat = 'json' | 'csv';

export class InvoiceExportService {
  async exportCustomerInvoices(
    customerId: string,
    format: ExportFormat = 'json'
  ): Promise<string> {
    const rows = await getDb()('invoices as i')
      .join('subscriptions as s', 's.id', 'i.subscription_id')
      .where('s.customer_id', customerId)
      .orderBy('i.created_at', 'desc')
      .select('i.*');

    if (format === 'json') {
      return JSON.stringify(rows, null, 2);
    }
    return this.toCsv(rows);
  }

  async exportPeriod(from: string, to: string, format: ExportFormat = 'csv'): Promise<string> {
    const rows = await getDb()('invoices')
      .whereBetween('created_at', [from, to])
      .orderBy('created_at', 'asc');
    if (format === 'json') return JSON.stringify(rows);
    return this.toCsv(rows);
  }

  private toCsv(rows: Record<string, unknown>[]): string {
    if (rows.length === 0) return '';
    const keys = ['id', 'subscription_id', 'status', 'total_cents', 'currency', 'due_date', 'paid_at'];
    const header = keys.join(',');
    const lines = rows.map((r) =>
      keys.map((k) => JSON.stringify(r[k] ?? '')).join(',')
    );
    return [header, ...lines].join('\n');
  }

  async exportInvoiceDetail(invoiceId: string): Promise<Record<string, unknown>> {
    const invoice = await getDb()('invoices').where({ id: invoiceId }).first();
    if (!invoice) throw new AppError(404, 'Invoice not found');
    const lines = await getDb()('invoice_line_items').where({ invoice_id: invoiceId });
    const payments = await getDb()('payments').where({ invoice_id: invoiceId });
    return { invoice, lines, payments };
  }
}
