import type { Knex } from 'knex';
import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { daysInPeriod, parseDate, toDateString } from '../utils/dateUtils';
import { addDays } from 'date-fns';
import { InvoiceService } from './InvoiceService';
import { SubscriptionService } from './SubscriptionService';

export class RevenueRecognitionService {
  constructor(
    private invoiceService = new InvoiceService(),
    private subscriptionService = new SubscriptionService()
  ) {}

  async createForPaidInvoice(
    invoiceId: string,
    trx: Knex.Transaction | Knex = getDb()
  ): Promise<number> {
    const existing = await trx('revenue_schedules').where({ invoice_id: invoiceId }).first();
    if (existing) return 0;

    const invoice = await trx('invoices').where({ id: invoiceId }).first();
    if (!invoice || invoice.status !== 'paid') {
      throw new AppError(400, 'Invoice must be paid to recognize revenue');
    }

    const sub = await this.subscriptionService.getById(invoice.subscription_id as string);
    const periodStart = parseDate(sub.current_period_start);
    const periodEnd = parseDate(sub.current_period_end);
    const totalDays = daysInPeriod(periodStart, periodEnd);
    const totalCents = Number(invoice.total_cents);
    const dailyBase = Math.floor(totalCents / totalDays);
    let remainder = totalCents - dailyBase * totalDays;

    const rows: Array<Record<string, unknown>> = [];
    for (let i = 0; i < totalDays; i++) {
      const scheduleDate = toDateString(addDays(periodStart, i));
      let amount = dailyBase;
      if (remainder > 0) {
        amount += 1;
        remainder -= 1;
      }
      rows.push({
        invoice_id: invoiceId,
        subscription_id: sub.id,
        schedule_date: scheduleDate,
        amount_cents: amount,
        status: 'pending',
      });
    }

    if (rows.length > 0) {
      await trx('revenue_schedules').insert(rows);
    }
    return rows.length;
  }

  async recognizeDue(asOf = new Date()): Promise<number> {
    const dateStr = toDateString(asOf);
    const updated = await getDb()('revenue_schedules')
      .where({ status: 'pending' })
      .andWhere('schedule_date', '<=', dateStr)
      .update({ status: 'recognized', updated_at: getDb().fn.now() });
    return typeof updated === 'number' ? updated : Number(updated);
  }

  async listForInvoice(invoiceId: string): Promise<Record<string, unknown>[]> {
    return getDb()('revenue_schedules')
      .where({ invoice_id: invoiceId })
      .orderBy('schedule_date', 'asc');
  }

  async summaryForSubscription(subscriptionId: string): Promise<{
    pending_cents: number;
    recognized_cents: number;
  }> {
    const rows = await getDb()('revenue_schedules').where({ subscription_id: subscriptionId });
    let pending = 0;
    let recognized = 0;
    for (const r of rows) {
      const amt = Number(r.amount_cents);
      if (r.status === 'recognized') recognized += amt;
      else pending += amt;
    }
    return { pending_cents: pending, recognized_cents: recognized };
  }
}
