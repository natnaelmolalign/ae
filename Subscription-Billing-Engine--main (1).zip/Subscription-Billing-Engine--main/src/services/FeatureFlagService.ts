import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface FeatureFlag {
  key: string;
  enabled: boolean;
  rules: Record<string, unknown>;
  description: string | null;
}

export class FeatureFlagService {
  async upsert(key: string, enabled: boolean, rules: Record<string, unknown> = {}, description?: string) {
    const db = getDb();
    const existing = await db('feature_flags').where({ key }).first();
    if (existing) {
      const [row] = await db('feature_flags')
        .where({ key })
        .update({ enabled, rules: JSON.stringify(rules), description: description ?? existing.description, updated_at: db.fn.now() })
        .returning('*');
      return this.parse(row);
    }
    const [row] = await db('feature_flags')
      .insert({ key, enabled, rules: JSON.stringify(rules), description: description ?? null })
      .returning('*');
    return this.parse(row);
  }

  private parse(row: Record<string, unknown>): FeatureFlag {
    return {
      ...row,
      rules: typeof row.rules === 'string' ? JSON.parse(row.rules) : row.rules,
    } as FeatureFlag;
  }

  async isEnabled(key: string, context: Record<string, unknown> = {}): Promise<boolean> {
    const row = await getDb()('feature_flags').where({ key }).first();
    if (!row) return false;
    const flag = this.parse(row);
    if (!flag.enabled) return false;
    const planId = context.plan_id as string | undefined;
    if (flag.rules.plan_ids && planId) {
      const allowed = flag.rules.plan_ids as string[];
      return allowed.includes(planId);
    }
    if (typeof flag.rules.percentage_rollout === 'number') {
      const pct = flag.rules.percentage_rollout;
      const bucket = Math.abs(this.hashContext(context)) % 100;
      return bucket < pct;
    }
    return true;
  }

  private hashContext(ctx: Record<string, unknown>): number {
    const s = JSON.stringify(ctx);
    let h = 0;
    for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
    return h;
  }

  async assertEnabled(key: string, context: Record<string, unknown> = {}): Promise<void> {
    if (!(await this.isEnabled(key, context))) {
      throw new AppError(403, `Feature ${key} is disabled`, 'FEATURE_DISABLED');
    }
  }

  async list(): Promise<FeatureFlag[]> {
    const rows = await getDb()('feature_flags').orderBy('key');
    return rows.map((r) => this.parse(r));
  }

  async seedDefaults(): Promise<void> {
    await this.upsert('usage_metering', true, {}, 'Enable usage-based metering APIs');
    await this.upsert('advanced_analytics', true, {}, 'Expose analytics rollup endpoints');
    await this.upsert('quote_conversion', true, {}, 'Allow quote to subscription conversion');
  }
}
