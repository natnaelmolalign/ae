import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface JurisdictionSummary {
  country: string;
  taxable_cents: number;
  tax_collected_cents: number;
  invoice_count: number;
}

export interface VatReturnLine {
  rate_bps: number;
  net_cents: number;
  tax_cents: number;
}

export interface CompliancePack {
  period_key: string;
  jurisdictions: JurisdictionSummary[];
  vat_lines: VatReturnLine[];
  exempt_customers: number;
  reverse_charge_cents: number;
}

const EU_COUNTRIES = new Set([
  'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE', 'IT',
  'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE',
]);

/**
 * Builds tax and compliance reporting packs from invoice and customer country data.
 */
export class TaxComplianceReportService {
  async buildPack(periodKey: string): Promise<CompliancePack> {
    const { start, end } = this.parsePeriod(periodKey);
    const invoices = await getDb()('invoices as i')
      .join('subscriptions as s', 's.id', 'i.subscription_id')
      .join('customers as c', 'c.id', 's.customer_id')
      .whereBetween('i.created_at', [start, end])
      .select(
        'c.country',
        'i.subtotal_cents',
        'i.tax_cents',
        'i.total_cents',
        'i.status'
      );

    const byCountry = new Map<string, JurisdictionSummary>();
    const vatMap = new Map<number, VatReturnLine>();
    let exempt = 0;
    let reverseCharge = 0;

    for (const inv of invoices) {
      const country = String(inv.country ?? 'US');
      const prev = byCountry.get(country) ?? {
        country,
        taxable_cents: 0,
        tax_collected_cents: 0,
        invoice_count: 0,
      };
      prev.taxable_cents += Number(inv.subtotal_cents);
      prev.tax_collected_cents += Number(inv.tax_cents);
      prev.invoice_count += 1;
      byCountry.set(country, prev);

      const rate = this.inferRateBps(Number(inv.tax_cents), Number(inv.subtotal_cents));
      const vat = vatMap.get(rate) ?? { rate_bps: rate, net_cents: 0, tax_cents: 0 };
      vat.net_cents += Number(inv.subtotal_cents);
      vat.tax_cents += Number(inv.tax_cents);
      vatMap.set(rate, vat);

      if (Number(inv.tax_cents) === 0 && EU_COUNTRIES.has(country)) {
        exempt += 1;
        reverseCharge += Number(inv.subtotal_cents);
      }
    }

    return {
      period_key: periodKey,
      jurisdictions: [...byCountry.values()],
      vat_lines: [...vatMap.values()].sort((a, b) => a.rate_bps - b.rate_bps),
      exempt_customers: exempt,
      reverse_charge_cents: reverseCharge,
    };
  }

  async nexusReport(periodKey: string) {
    const pack = await this.buildPack(periodKey);
    return pack.jurisdictions
      .filter((j) => j.taxable_cents >= 100_000_00)
      .map((j) => ({
        country: j.country,
        taxable_cents: j.taxable_cents,
        nexus_triggered: true,
        recommendation: 'register_for_sales_tax',
      }));
  }

  async euVatSummary(periodKey: string) {
    const pack = await this.buildPack(periodKey);
    const eu = pack.jurisdictions.filter((j) => EU_COUNTRIES.has(j.country));
    const totalTax = eu.reduce((s, j) => s + j.tax_collected_cents, 0);
    const totalNet = eu.reduce((s, j) => s + j.taxable_cents, 0);
    return { period_key: periodKey, eu_countries: eu.length, net_cents: totalNet, tax_cents: totalTax };
  }

  async usStateBreakdown(periodKey: string) {
    const { start, end } = this.parsePeriod(periodKey);
    const rows = await getDb()('customers')
      .where({ country: 'US' })
      .whereBetween('created_at', [start, end])
      .count({ c: 'id' })
      .first();
    return {
      period_key: periodKey,
      us_customers: Number(rows?.c ?? 0),
      note: 'State-level breakdown requires billing address dimension',
    };
  }

  async validateInvoiceTax(invoiceId: string) {
    const inv = await getDb()('invoices').where({ id: invoiceId }).first();
    if (!inv) throw new AppError(404, 'Invoice not found');
    const subtotal = Number(inv.subtotal_cents);
    const tax = Number(inv.tax_cents);
    const expectedMax = Math.round(subtotal * 0.25);
    return {
      invoice_id: invoiceId,
      valid: tax <= expectedMax,
      subtotal_cents: subtotal,
      tax_cents: tax,
      implied_rate_bps: subtotal === 0 ? 0 : Math.round((tax / subtotal) * 10000),
    };
  }

  async exportPackCsv(periodKey: string): Promise<string> {
    const pack = await this.buildPack(periodKey);
    const lines = [
      'country,taxable_cents,tax_collected_cents,invoice_count',
      ...pack.jurisdictions.map(
        (j) => `${j.country},${j.taxable_cents},${j.tax_collected_cents},${j.invoice_count}`
      ),
      `exempt,${pack.exempt_customers},,,`,
      `reverse_charge,${pack.reverse_charge_cents},,,`,
    ];
    return lines.join('\n');
  }

  async comparePeriods(a: string, b: string) {
    const packA = await this.buildPack(a);
    const packB = await this.buildPack(b);
    const taxA = packA.jurisdictions.reduce((s, j) => s + j.tax_collected_cents, 0);
    const taxB = packB.jurisdictions.reduce((s, j) => s + j.tax_collected_cents, 0);
    return { period_a: a, period_b: b, tax_delta_cents: taxB - taxA };
  }

  async auditTrailForPeriod(periodKey: string) {
    const { start, end } = this.parsePeriod(periodKey);
    return getDb()('audit_log')
      .whereBetween('recorded_at', [start, end])
      .whereIn('action', ['tax_applied', 'invoice_created', 'credit_issued'])
      .orderBy('recorded_at', 'desc')
      .limit(100);
  }

  async missingTaxInvoices(periodKey: string) {
    const { start, end } = this.parsePeriod(periodKey);
    return getDb()('invoices as i')
      .join('subscriptions as s', 's.id', 'i.subscription_id')
      .join('customers as c', 'c.id', 's.customer_id')
      .whereBetween('i.created_at', [start, end])
      .where('i.tax_cents', 0)
      .whereNotIn('c.country', ['US', 'CA'])
      .select('i.id', 'c.country', 'i.total_cents');
  }

  async standardRateForCountry(country: string): Promise<number> {
    if (EU_COUNTRIES.has(country)) return 1900;
    if (country === 'GB') return 2000;
    if (country === 'US') return 0;
    return 1000;
  }

  async estimatedLiability(periodKey: string) {
    const pack = await this.buildPack(periodKey);
    const collected = pack.jurisdictions.reduce((s, j) => s + j.tax_collected_cents, 0);
    const taxable = pack.jurisdictions.reduce((s, j) => s + j.taxable_cents, 0);
    return {
      period_key: periodKey,
      taxable_cents: taxable,
      collected_cents: collected,
      estimated_remittance_cents: collected,
      variance_cents: 0,
    };
  }

  async customerTaxProfile(customerId: string) {
    const customer = await getDb()('customers').where({ id: customerId }).first();
    if (!customer) throw new AppError(404, 'Customer not found');
    const rate = await this.standardRateForCountry(String(customer.country));
    return {
      customer_id: customerId,
      country: customer.country,
      standard_rate_bps: rate,
      eu: EU_COUNTRIES.has(String(customer.country)),
    };
  }

  async quarterlyRollup(year: number, quarter: 1 | 2 | 3 | 4) {
    const startMonth = (quarter - 1) * 3 + 1;
    const keys = [0, 1, 2].map((i) => {
      const m = startMonth + i;
      return `${year}-${String(m).padStart(2, '0')}`;
    });
    const packs = await Promise.all(keys.map((k) => this.buildPack(k)));
    const tax = packs.reduce(
      (s, p) => s + p.jurisdictions.reduce((t, j) => t + j.tax_collected_cents, 0),
      0
    );
    return { year, quarter, months: keys, total_tax_collected_cents: tax };
  }

  async filingChecklist(periodKey: string) {
    const pack = await this.buildPack(periodKey);
    const nexus = await this.nexusReport(periodKey);
    const missing = await this.missingTaxInvoices(periodKey);
    return {
      period_key: periodKey,
      steps: [
        { id: 'review_jurisdictions', done: pack.jurisdictions.length > 0 },
        { id: 'review_nexus', done: nexus.length >= 0 },
        { id: 'fix_missing_tax', done: missing.length === 0 },
        { id: 'export_csv', done: true },
      ],
      missing_tax_invoices: missing.length,
    };
  }

  private inferRateBps(taxCents: number, subtotalCents: number): number {
    if (subtotalCents <= 0 || taxCents <= 0) return 0;
    return Math.round((taxCents / subtotalCents) * 10000);
  }

  async remittanceSchedule(year: number) {
    const quarters: { quarter: number; due_date: string; period_keys: string[] }[] = [];
    for (let q = 1 as 1 | 2 | 3 | 4; q <= 4; q++) {
      const startMonth = (q - 1) * 3 + 1;
      const period_keys = [0, 1, 2].map((i) => `${year}-${String(startMonth + i).padStart(2, '0')}`);
      const dueMonth = startMonth + 3;
      quarters.push({
        quarter: q,
        due_date: `${year}-${String(dueMonth).padStart(2, '0')}-20`,
        period_keys,
      });
    }
    return { year, quarters };
  }

  async documentRetentionPolicy() {
    return {
      tax_records_years: 7,
      invoice_pdf_years: 7,
      audit_log_years: 3,
      jurisdictions_supported: [...EU_COUNTRIES, 'US', 'GB', 'CA'],
    };
  }

  private parsePeriod(periodKey: string): { start: Date; end: Date } {
    if (/^\d{4}-\d{2}$/.test(periodKey)) {
      const [y, m] = periodKey.split('-').map(Number);
      return {
        start: new Date(Date.UTC(y, m - 1, 1)),
        end: new Date(Date.UTC(y, m, 0, 23, 59, 59, 999)),
      };
    }
    throw new AppError(400, 'period_key must be YYYY-MM');
  }
}
