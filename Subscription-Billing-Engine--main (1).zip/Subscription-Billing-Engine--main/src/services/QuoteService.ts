import { addDays } from 'date-fns';
import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import { toDateString, parseDate } from '../utils/dateUtils';
import type { Subscription } from '../models/Subscription';
import { CustomerService } from './CustomerService';
import { InvoiceService } from './InvoiceService';
import { PlanService } from './PlanService';
import { SubscriptionItemService } from './SubscriptionItemService';
import { SubscriptionService } from './SubscriptionService';

export interface QuoteLineInput {
  description: string;
  quantity: number;
  unit_price_cents: number;
  plan_id?: string;
}

export class QuoteService {
  constructor(
    private customerService = new CustomerService(),
    private planService = new PlanService(),
    private subscriptionService = new SubscriptionService(),
    private subscriptionItems = new SubscriptionItemService(),
    private invoiceService = new InvoiceService()
  ) {}

  async create(input: {
    customer_id: string;
    expires_at?: string;
    lines: QuoteLineInput[];
  }): Promise<Record<string, unknown>> {
    await this.customerService.getById(input.customer_id);
    if (!input.lines.length) throw new AppError(400, 'Quote requires at least one line');

    const expiresAt =
      input.expires_at ?? toDateString(addDays(new Date(), 30));

    return getDb().transaction(async (trx) => {
      const [quote] = await trx('quotes')
        .insert({
          customer_id: input.customer_id,
          status: 'draft',
          expires_at: expiresAt,
        })
        .returning('*');

      for (const line of input.lines) {
        if (line.plan_id) await this.planService.getById(line.plan_id);
        await trx('quote_line_items').insert({
          quote_id: quote.id,
          description: line.description,
          quantity: line.quantity,
          unit_price_cents: line.unit_price_cents,
          plan_id: line.plan_id ?? null,
        });
      }

      return this.getById(quote.id as string, trx);
    });
  }

  async getById(id: string, trx = getDb()): Promise<Record<string, unknown>> {
    const quote = await trx('quotes').where({ id }).first();
    if (!quote) throw new AppError(404, 'Quote not found');
    const lines = await trx('quote_line_items').where({ quote_id: id });
    return { ...quote, lines };
  }

  async send(id: string): Promise<Record<string, unknown>> {
    const quote = await this.getById(id);
    if (quote.status !== 'draft') {
      throw new AppError(400, 'Only draft quotes can be sent');
    }
    const [updated] = await getDb()('quotes')
      .where({ id })
      .update({ status: 'sent', updated_at: getDb().fn.now() })
      .returning('*');
    return { ...updated, lines: (quote as { lines: unknown[] }).lines };
  }

  async convertToSubscription(id: string): Promise<{
    quote: Record<string, unknown>;
    subscription: Record<string, unknown>;
    invoice?: Record<string, unknown>;
  }> {
    const quote = await this.getById(id);
    if (!['draft', 'sent', 'accepted'].includes(quote.status as string)) {
      throw new AppError(400, 'Quote cannot be converted in current status');
    }
    if (parseDate(quote.expires_at as string) < new Date()) {
      await getDb()('quotes').where({ id }).update({ status: 'expired' });
      throw new AppError(400, 'Quote has expired');
    }

    const lines = (quote as { lines: Array<Record<string, unknown>> }).lines;
    const primary = lines.find((l) => l.plan_id) ?? lines[0];
    if (!primary?.plan_id) {
      throw new AppError(400, 'Quote must include a plan line to convert');
    }

    const sub: Subscription = await this.subscriptionService.create({
      customer_id: quote.customer_id as string,
      plan_id: primary.plan_id as string,
    });

    await getDb().transaction(async (trx) => {
      await this.subscriptionItems.syncBasePlanItem(sub, trx);
      await trx('quotes')
        .where({ id })
        .update({
          status: 'converted',
          converted_subscription_id: sub.id,
          updated_at: trx.fn.now(),
        });
    });

    const customer = await this.customerService.getById(sub.customer_id);
    const invoice = await this.invoiceService.generateForSubscription(sub, customer.country);

    return {
      quote: await this.getById(id),
      subscription: sub as unknown as Record<string, unknown>,
      invoice: invoice as unknown as Record<string, unknown>,
    };
  }
}
