import { getDb } from '../config/database';
import { AppError } from '../lib/errors';

export interface ReconciliationMismatch {
  entity_type: string;
  entity_id: string;
  field: string;
  expected: number | string;
  actual: number | string;
}

export interface ReconciliationReport {
  checked_at: Date;
  invoice_count: number;
  payment_count: number;
  mismatches: ReconciliationMismatch[];
  balanced: boolean;
}

export class BillingReconciliationService {
  async reconcileOpenInvoices(asOf = new Date()): Promise<ReconciliationReport> {
    const db = getDb();
    const mismatches: ReconciliationMismatch[] = [];

    const invoices = await db('invoices')
      .whereIn('status', ['pending', 'open', 'paid'])
      .andWhere('created_at', '<=', asOf);

    for (const inv of invoices) {
      const lineSum = await db('invoice_line_items')
        .where({ invoice_id: inv.id })
        .sum('amount_cents as total');
      const linesTotal = Number((lineSum[0] as { total: string | null })?.total ?? 0);
      const expectedSubtotal = Number(inv.subtotal_cents);
      if (linesTotal !== expectedSubtotal && linesTotal > 0) {
        mismatches.push({
          entity_type: 'invoice',
          entity_id: inv.id,
          field: 'subtotal_cents',
          expected: linesTotal,
          actual: expectedSubtotal,
        });
      }
      const computedTotal =
        expectedSubtotal - Number(inv.discount_cents) + Number(inv.tax_cents);
      if (Number(inv.total_cents) !== computedTotal) {
        mismatches.push({
          entity_type: 'invoice',
          entity_id: inv.id,
          field: 'total_cents',
          expected: computedTotal,
          actual: Number(inv.total_cents),
        });
      }
      if (inv.status === 'paid') {
        const payments = await db('payments')
          .where({ invoice_id: inv.id, status: 'succeeded' })
          .sum('amount_cents as paid');
        const paid = Number((payments[0] as { paid: string | null })?.paid ?? 0);
        if (paid !== Number(inv.total_cents)) {
          mismatches.push({
            entity_type: 'invoice',
            entity_id: inv.id,
            field: 'paid_vs_total',
            expected: Number(inv.total_cents),
            actual: paid,
          });
        }
      }
    }

    const paymentCount = await db('payments').count('* as c');
    return {
      checked_at: asOf,
      invoice_count: invoices.length,
      payment_count: Number((paymentCount[0] as { c: string }).c),
      mismatches,
      balanced: mismatches.length === 0,
    };
  }

  async assertBalanced(asOf = new Date()): Promise<ReconciliationReport> {
    const report = await this.reconcileOpenInvoices(asOf);
    if (!report.balanced) {
      throw new AppError(
        409,
        `Reconciliation found ${report.mismatches.length} mismatches`,
        'RECONCILIATION_FAILED'
      );
    }
    return report;
  }
}
