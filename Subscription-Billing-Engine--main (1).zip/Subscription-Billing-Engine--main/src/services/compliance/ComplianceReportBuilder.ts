import { getDb } from '../../config/database';

export interface ComplianceSection {
  title: string;
  rows: Record<string, unknown>[];
  summary: Record<string, number | string>;
}

export interface ComplianceReport {
  generated_at: string;
  sections: ComplianceSection[];
}

/**
 * Builds read-only compliance snapshots from billing tables (SOX-style controls).
 */
export class ComplianceReportBuilder {
  async buildFull(): Promise<ComplianceReport> {
    const sections = await Promise.all([
      this.segregationOfDuties(),
      this.auditTrailCoverage(),
      this.periodCloseStatus(),
      this.retentionCompliance(),
      this.failedPaymentExposure(),
      this.creditNoteActivity(),
      this.rbacPrincipalInventory(),
      this.outboxDeliveryLag(),
    ]);
    return { generated_at: new Date().toISOString(), sections };
  }

  async segregationOfDuties(): Promise<ComplianceSection> {
    const principals = await getDb()('api_principals').count('* as c').first();
    const adminRoles = await getDb()('principal_roles as pr')
      .join('roles as r', 'r.id', 'pr.role_id')
      .where('r.name', 'billing_admin')
      .count('* as c')
      .first();
    return {
      title: 'Segregation of duties',
      rows: [],
      summary: {
        total_principals: Number((principals as { c: string }).c),
        admin_bindings: Number((adminRoles as { c: string }).c),
      },
    };
  }

  async auditTrailCoverage(): Promise<ComplianceSection> {
    const rows = await getDb()('audit_log')
      .select('entity_type')
      .count('* as events')
      .groupBy('entity_type');
    return {
      title: 'Audit trail coverage',
      rows: rows as Record<string, unknown>[],
      summary: { entity_types: rows.length },
    };
  }

  async periodCloseStatus(): Promise<ComplianceSection> {
    const rows = await getDb()('billing_period_closes').orderBy('period_end', 'desc').limit(6);
    const open = rows.filter((r) => r.status === 'open').length;
    return {
      title: 'Period close status',
      rows: rows as Record<string, unknown>[],
      summary: { open_periods: open, listed: rows.length },
    };
  }

  async retentionCompliance(): Promise<ComplianceSection> {
    const policies = await getDb()('retention_policies').select('*');
    const runs = await getDb()('purge_runs').orderBy('started_at', 'desc').limit(10);
    return {
      title: 'Retention compliance',
      rows: runs as Record<string, unknown>[],
      summary: { policies: policies.length },
    };
  }

  async failedPaymentExposure(): Promise<ComplianceSection> {
    const row = await getDb()('payments')
      .where('status', 'failed')
      .andWhere('attempted_at', '>=', new Date(Date.now() - 30 * 86_400_000))
      .sum('amount_cents as total')
      .count('* as cnt')
      .first();
    return {
      title: 'Failed payment exposure (30d)',
      rows: [],
      summary: {
        count: Number(row?.cnt ?? 0),
        total_cents: Number(row?.total ?? 0),
      },
    };
  }

  async creditNoteActivity(): Promise<ComplianceSection> {
    const rows = await getDb()('credit_notes')
      .orderBy('created_at', 'desc')
      .limit(20)
      .select('id', 'invoice_id', 'amount_cents', 'reason', 'created_at');
    const total = rows.reduce((s, r) => s + Number(r.amount_cents), 0);
    return {
      title: 'Credit note activity',
      rows: rows as Record<string, unknown>[],
      summary: { recent_count: rows.length, total_cents: total },
    };
  }

  async rbacPrincipalInventory(): Promise<ComplianceSection> {
    const rows = await getDb()('api_principals as p')
      .leftJoin('principal_roles as pr', 'pr.principal_id', 'p.id')
      .select('p.id', 'p.name', 'p.active')
      .count('pr.role_id as role_count')
      .groupBy('p.id', 'p.name', 'p.active');
    return {
      title: 'API principal inventory',
      rows: rows as Record<string, unknown>[],
      summary: { principals: rows.length },
    };
  }

  async outboxDeliveryLag(): Promise<ComplianceSection> {
    const pending = await getDb()('outbox_messages').where({ status: 'pending' }).count('* as c').first();
    const failed = await getDb()('outbox_messages').where({ status: 'failed' }).count('* as c').first();
    return {
      title: 'Outbox delivery lag',
      rows: [],
      summary: {
        pending: Number((pending as { c: string }).c),
        failed: Number((failed as { c: string }).c),
      },
    };
  }
}
