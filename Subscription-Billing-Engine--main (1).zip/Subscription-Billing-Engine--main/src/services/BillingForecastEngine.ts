import { getDb } from '../config/database';
import { BillingWaterfallService } from './BillingWaterfallService';
import { BillingSnapshotService } from './BillingSnapshotService';

export interface ForecastPoint {
  period_key: string;
  projected_mrr_cents: number;
  projected_collections_cents: number;
  confidence: number;
}

export interface ScenarioResult {
  name: string;
  mrr_cents: number;
  delta_from_base_pct: number;
}

/**
 * Projects MRR and collections using trailing history and simple scenario modeling.
 */
export class BillingForecastEngine {
  constructor(
    private readonly waterfall = new BillingWaterfallService(),
    private readonly snapshots = new BillingSnapshotService()
  ) {}

  async trailingMrr(months = 6): Promise<{ period_key: string; mrr_cents: number }[]> {
    const points: { period_key: string; mrr_cents: number }[] = [];
    const now = new Date();
    for (let i = months; i >= 1; i--) {
      const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
      const key = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
      const snap = await this.snapshots.capture({ snapshot_type: 'mrr', period_key: key });
      points.push({
        period_key: key,
        mrr_cents: Number((snap.metrics as { mrr_cents?: number }).mrr_cents ?? 0),
      });
    }
    return points;
  }

  async projectNextMonths(count = 3): Promise<ForecastPoint[]> {
    const history = await this.trailingMrr(6);
    const avgMrr =
      history.length === 0
        ? 0
        : Math.round(history.reduce((s, h) => s + h.mrr_cents, 0) / history.length);
    const wfHistory = await this.waterfall.forecastFromHistory(3);
    const avgCollections =
      wfHistory.length === 0
        ? 0
        : Math.round(
            wfHistory.reduce((s, h) => s + h.projected_cents, 0) / Math.max(1, wfHistory.length)
          );

    const results: ForecastPoint[] = [];
    const now = new Date();
    for (let i = 1; i <= count; i++) {
      const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + i, 1));
      const key = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
      const growth = 1 + i * 0.01;
      results.push({
        period_key: key,
        projected_mrr_cents: Math.round(avgMrr * growth),
        projected_collections_cents: Math.round(avgCollections * growth),
        confidence: Math.max(0.5, 0.9 - i * 0.1),
      });
    }
    return results;
  }

  async scenarios(basePeriod: string): Promise<ScenarioResult[]> {
    const base = await this.snapshots.capture({ snapshot_type: 'mrr', period_key: basePeriod });
    const mrr = Number((base.metrics as { mrr_cents?: number }).mrr_cents ?? 0);
    return [
      { name: 'base', mrr_cents: mrr, delta_from_base_pct: 0 },
      { name: 'expansion_10', mrr_cents: Math.round(mrr * 1.1), delta_from_base_pct: 10 },
      { name: 'contraction_5', mrr_cents: Math.round(mrr * 0.95), delta_from_base_pct: -5 },
      { name: 'churn_shock_15', mrr_cents: Math.round(mrr * 0.85), delta_from_base_pct: -15 },
    ];
  }

  async newLogoImpact(addedMrrCents: number, churnMrrCents: number, periodKey: string) {
    const snap = await this.snapshots.capture({ snapshot_type: 'mrr', period_key: periodKey });
    const current = Number((snap.metrics as { mrr_cents?: number }).mrr_cents ?? 0);
    return {
      period_key: periodKey,
      current_mrr_cents: current,
      projected_mrr_cents: current + addedMrrCents - churnMrrCents,
      net_new_mrr_cents: addedMrrCents - churnMrrCents,
    };
  }

  async pipelineWeightedForecast() {
    const trials = await getDb()('subscriptions').where({ status: 'trial' }).count({ c: 'id' }).first();
    const avg = await getDb()('plans').avg({ price: 'price_cents' }).first();
    const trialCount = Number(trials?.c ?? 0);
    const avgPrice = Number(avg?.price ?? 0);
    const conversion = 0.25;
    return {
      trial_count: trialCount,
      expected_conversions: Math.round(trialCount * conversion),
      expected_mrr_cents: Math.round(trialCount * conversion * avgPrice),
    };
  }

  async exportForecastCsv(): Promise<string> {
    const points = await this.projectNextMonths(6);
    const header = 'period,projected_mrr_cents,projected_collections_cents,confidence';
    const lines = points.map(
      (p) => `${p.period_key},${p.projected_mrr_cents},${p.projected_collections_cents},${p.confidence}`
    );
    return [header, ...lines].join('\n');
  }
}
