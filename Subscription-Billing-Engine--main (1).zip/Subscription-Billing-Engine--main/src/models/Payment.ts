export type PaymentStatus = 'succeeded' | 'failed' | 'refunded';

export interface Payment {
  id: string;
  invoice_id: string;
  amount_cents: number;
  status: PaymentStatus;
  attempted_at: Date;
  failure_reason: string | null;
}
