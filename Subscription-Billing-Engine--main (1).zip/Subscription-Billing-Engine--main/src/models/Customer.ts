export interface Customer {
  id: string;
  email: string;
  name: string;
  country: string;
  credit_balance_cents: number;
  created_at: Date;
  updated_at: Date;
}

export interface CreateCustomerInput {
  email: string;
  name: string;
  country?: string;
}
