export type InvoiceStatus = 'pending' | 'paid' | 'void' | 'uncollectible';

export interface Invoice {
  id: string;
  subscription_id: string;
  billing_cycle_id: string | null;
  status: InvoiceStatus;
  subtotal_cents: number;
  tax_cents: number;
  discount_cents: number;
  credit_applied_cents: number;
  total_cents: number;
  due_date: string;
  issued_at: string;
  currency: string;
  created_at: Date;
  updated_at: Date;
}

export interface InvoiceLineItem {
  id: string;
  invoice_id: string;
  description: string;
  amount_cents: number;
  type: string;
}
