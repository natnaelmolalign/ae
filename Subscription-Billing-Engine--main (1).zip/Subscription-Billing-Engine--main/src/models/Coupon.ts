export type DiscountType = 'percent' | 'fixed';

export interface Coupon {
  id: string;
  code: string;
  discount_type: DiscountType;
  discount_value: number;
  recurring: boolean;
  expires_at: Date | null;
  usage_limit: number | null;
  usage_count: number;
  plan_ids: string[] | null;
  created_at: Date;
  updated_at: Date;
}
