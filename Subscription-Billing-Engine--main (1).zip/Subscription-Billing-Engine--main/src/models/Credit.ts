export interface Credit {
  id: string;
  customer_id: string;
  subscription_id: string | null;
  amount_cents: number;
  reason: string;
  invoice_id: string | null;
  applied: boolean;
  created_at: Date;
  updated_at: Date;
}
