export type SubscriptionStatus =
  | 'trial'
  | 'active'
  | 'past_due'
  | 'cancelled'
  | 'expired';

export interface Subscription {
  id: string;
  customer_id: string;
  plan_id: string;
  status: SubscriptionStatus;
  billing_anchor: string;
  current_period_start: string;
  current_period_end: string;
  trial_end: string | null;
  cancelled_at: string | null;
  paused_at: string | null;
  failed_payment_count: number;
  coupon_id: string | null;
  created_at: Date;
  updated_at: Date;
}

export interface CreateSubscriptionInput {
  customer_id: string;
  plan_id: string;
  billing_anchor?: string;
  trial_days?: number;
  coupon_code?: string;
}

export const ALLOWED_TRANSITIONS: Record<
  SubscriptionStatus,
  SubscriptionStatus[]
> = {
  trial: ['active', 'cancelled', 'expired'],
  active: ['past_due', 'cancelled', 'expired'],
  past_due: ['active', 'cancelled', 'expired'],
  cancelled: ['active'],
  expired: [],
};
