export type BillingInterval = 'monthly' | 'yearly';

export interface Plan {
  id: string;
  name: string;
  price_cents: number;
  interval: BillingInterval;
  features: string[];
  active: boolean;
  dunning_policy_id?: string | null;
  created_at: Date;
  updated_at: Date;
}

export interface CreatePlanInput {
  name: string;
  price_cents: number;
  interval: BillingInterval;
  features?: string[];
}
