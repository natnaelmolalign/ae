import knex, { Knex } from 'knex';
import config from './knexConfig';

let db: Knex | null = null;

export function getDb(): Knex {
  if (!db) {
    db = knex(config);
  }
  return db;
}

export function setDbForTests(instance: Knex): void {
  db = instance;
}

export async function closeDb(): Promise<void> {
  if (db) {
    await db.destroy();
    db = null;
  }
}
