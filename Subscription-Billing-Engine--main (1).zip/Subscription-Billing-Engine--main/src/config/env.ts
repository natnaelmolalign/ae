import { z } from 'zod';

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().default(3000),
  DATABASE_URL: z.string().optional(),
  DB_HOST: z.string().default('localhost'),
  DB_PORT: z.coerce.number().default(5432),
  DB_USER: z.string().default('billing'),
  DB_PASSWORD: z.string().default('billing'),
  DB_NAME: z.string().default('billing_engine'),
  API_KEY: z.string().min(8).default('dev-api-key-change-me'),
  LOG_LEVEL: z.enum(['error', 'warn', 'info', 'debug']).default('info'),
  RETRY_DELAYS_DAYS: z.string().default('3,5,7'),
  DEFAULT_TAX_RATE_BPS: z.coerce.number().default(0),
  WEBHOOK_URL: z.string().url().optional().or(z.literal('')),
  WEBHOOK_SECRET: z.string().min(16).optional(),
  GRACE_PERIOD_DAYS: z.coerce.number().default(3),
  IDEMPOTENCY_TTL_HOURS: z.coerce.number().default(24),
});

export type Env = z.infer<typeof envSchema>;

let cached: Env | null = null;

export function loadEnv(): Env {
  if (!cached) {
    const parsed = envSchema.safeParse(process.env);
    if (!parsed.success) {
      const msg = parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ');
      throw new Error(`Invalid environment: ${msg}`);
    }
    cached = parsed.data;
  }
  return cached;
}

export function resetEnvForTests(): void {
  cached = null;
}
