import type { Knex } from 'knex';
import dotenv from 'dotenv';

dotenv.config();

const config: Knex.Config = {
  client: 'pg',
  connection: process.env.DATABASE_URL || {
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT || 5432),
    user: process.env.DB_USER || 'billing',
    password: process.env.DB_PASSWORD || 'billing',
    database: process.env.DB_NAME || 'billing_engine',
  },
  migrations: {
    directory: `${__dirname}/../../migrations`,
    extension: 'ts',
  },
  pool: { min: 0, max: 10 },
};

export default config;
