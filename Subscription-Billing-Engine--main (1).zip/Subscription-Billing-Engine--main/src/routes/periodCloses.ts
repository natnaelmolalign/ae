import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { BillingPeriodCloseService } from '../services/BillingPeriodCloseService';
import { requirePermission } from '../middleware/requirePermission';
import { validateBody } from '../middleware/validateZod';
import { z } from 'zod';

const router = Router();
const service = new BillingPeriodCloseService();

const periodSchema = z.object({
  period_start: z.string(),
  period_end: z.string(),
});

router.get(
  '/',
  requirePermission('invoices', 'read'),
  asyncHandler(async (_req, res) => {
    res.json(await service.list());
  })
);

router.post(
  '/open',
  requirePermission('invoices', 'write'),
  validateBody(periodSchema),
  asyncHandler(async (req, res) => {
    const body = req.body as z.infer<typeof periodSchema>;
    res.status(201).json(await service.openPeriod(body.period_start, body.period_end));
  })
);

router.post(
  '/reconcile',
  requirePermission('invoices', 'write'),
  validateBody(periodSchema),
  asyncHandler(async (req, res) => {
    const body = req.body as z.infer<typeof periodSchema>;
    res.json(await service.reconcile(body.period_start, body.period_end));
  })
);

router.post(
  '/close',
  requirePermission('invoices', 'write'),
  validateBody(periodSchema),
  asyncHandler(async (req, res) => {
    const body = req.body as z.infer<typeof periodSchema>;
    res.json(await service.close(body.period_start, body.period_end));
  })
);

export default router;
