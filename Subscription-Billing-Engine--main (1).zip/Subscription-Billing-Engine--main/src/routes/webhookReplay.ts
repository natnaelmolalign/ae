import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { WebhookReplayService } from '../services/WebhookReplayService';

const router = Router();
const replay = new WebhookReplayService();

router.post(
  '/:outboxId',
  asyncHandler(async (req, res) => {
    res.json(await replay.replayMessage(req.params.outboxId));
  })
);

router.post(
  '/',
  asyncHandler(async (_req, res) => {
    res.json(await replay.replayFailed(20));
  })
);

router.get(
  '/log',
  asyncHandler(async (_req, res) => {
    res.json(await replay.listReplayLog());
  })
);

export default router;
