import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { parseUuidParam } from '../lib/parseUuidParam';
import { validateBody } from '../middleware/validateZod';
import { createCustomerSchema } from '../validation/schemas';
import { CustomerService } from '../services/CustomerService';
import { AppError } from '../lib/errors';

const router = Router();
const customerService = new CustomerService();

router.post(
  '/',
  validateBody(createCustomerSchema),
  asyncHandler(async (req, res) => {
    res.status(201).json(await customerService.create(req.body));
  })
);

router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'customer id');
    res.json(await customerService.getById(id));
  })
);

router.patch(
  '/:id/country',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'customer id');
    const country = req.body.country;
    if (typeof country !== 'string' || country.length !== 2) {
      throw new AppError(400, 'country must be a 2-letter code');
    }
    res.json(await customerService.updateCountry(id, country));
  })
);

export default router;
