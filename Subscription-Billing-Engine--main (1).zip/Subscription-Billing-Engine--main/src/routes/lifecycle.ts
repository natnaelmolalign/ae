import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { CustomerLifecycleAnalyticsService } from '../services/CustomerLifecycleAnalyticsService';
import { BillingForecastEngine } from '../services/BillingForecastEngine';

const router = Router();
const lifecycle = new CustomerLifecycleAnalyticsService();
const forecast = new BillingForecastEngine();

router.get(
  '/stages',
  asyncHandler(async (_req, res) => {
    res.json(await lifecycle.stageDistribution());
  })
);

router.get(
  '/expansion-signals',
  asyncHandler(async (req, res) => {
    res.json(await lifecycle.expansionSignals(Number(req.query.limit ?? 20)));
  })
);

router.get(
  '/at-risk',
  asyncHandler(async (_req, res) => {
    res.json(await lifecycle.customersAtRisk());
  })
);

router.get(
  '/forecast',
  asyncHandler(async (_req, res) => {
    res.json(await forecast.projectNextMonths(6));
  })
);

router.get(
  '/forecast/scenarios',
  asyncHandler(async (req, res) => {
    res.json(await forecast.scenarios((req.query.period as string) ?? '2026-06'));
  })
);

export default router;
