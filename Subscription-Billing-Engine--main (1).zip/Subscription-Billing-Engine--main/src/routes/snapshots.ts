import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { validateBody } from '../middleware/validateZod';
import { z } from 'zod';
import { BillingSnapshotService } from '../services/BillingSnapshotService';

const router = Router();
const snapshots = new BillingSnapshotService();

const captureSchema = z.object({
  snapshot_type: z.enum(['mrr', 'arr', 'usage', 'collections']),
  period_key: z.string().min(7).max(10),
  customer_id: z.string().uuid().optional(),
  currency: z.string().length(3).optional(),
});

router.post(
  '/capture',
  validateBody(captureSchema),
  asyncHandler(async (req, res) => {
    res.status(201).json(await snapshots.capture(req.body));
  })
);

router.get(
  '/',
  asyncHandler(async (req, res) => {
    const periodKey = req.query.period_key as string | undefined;
    const type = req.query.type as 'mrr' | 'arr' | 'usage' | 'collections' | undefined;
    res.json(await snapshots.list(periodKey, type, Number(req.query.limit ?? 50)));
  })
);

router.get(
  '/compare/:type/:fromKey/:toKey',
  asyncHandler(async (req, res) => {
    res.json(
      await snapshots.comparePeriods(
        req.params.type as 'mrr' | 'arr' | 'usage' | 'collections',
        req.params.fromKey,
        req.params.toKey
      )
    );
  })
);

router.get(
  '/:type/:periodKey',
  asyncHandler(async (req, res) => {
    res.json(
      await snapshots.get(
        req.params.type as 'mrr' | 'arr' | 'usage' | 'collections',
        req.params.periodKey,
        (req.query.customer_id as string) || null
      )
    );
  })
);

export default router;
