import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { BillingWaterfallService } from '../services/BillingWaterfallService';

const router = Router();
const waterfall = new BillingWaterfallService();

router.get(
  '/cohorts/retention',
  asyncHandler(async (_req, res) => {
    res.json(await waterfall.cohortRetention(6));
  })
);

router.get(
  '/aging/buckets',
  asyncHandler(async (_req, res) => {
    res.json(await waterfall.agingBuckets());
  })
);

router.get(
  '/forecast/history',
  asyncHandler(async (_req, res) => {
    res.json(await waterfall.forecastFromHistory(3));
  })
);

router.get(
  '/compare/:fromKey/:toKey',
  asyncHandler(async (req, res) => {
    res.json(await waterfall.compareWaterfalls(req.params.fromKey, req.params.toKey));
  })
);

router.get(
  '/:periodKey/top-customers',
  asyncHandler(async (req, res) => {
    res.json(await waterfall.topCustomersByRevenue(req.params.periodKey, Number(req.query.limit ?? 10)));
  })
);

router.get(
  '/:periodKey/export.csv',
  asyncHandler(async (req, res) => {
    const csv = await waterfall.exportCsv(req.params.periodKey);
    res.type('text/csv').send(csv);
  })
);

router.get(
  '/:periodKey',
  asyncHandler(async (req, res) => {
    res.json(await waterfall.buildForPeriod(req.params.periodKey));
  })
);

export default router;
