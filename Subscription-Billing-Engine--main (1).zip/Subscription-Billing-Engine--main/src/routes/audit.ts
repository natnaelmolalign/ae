import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { AuditService } from '../services/AuditService';

const router = Router();
const audit = new AuditService();

router.get(
  '/:entityType/:entityId',
  asyncHandler(async (req, res) => {
    res.json(
      await audit.listForEntity(req.params.entityType, req.params.entityId)
    );
  })
);

export default router;
