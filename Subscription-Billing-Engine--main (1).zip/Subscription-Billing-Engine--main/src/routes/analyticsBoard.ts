import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { BillingAnalyticsFacade } from '../services/BillingAnalyticsFacade';

const router = Router();
const board = new BillingAnalyticsFacade();

router.get(
  '/:periodKey',
  asyncHandler(async (req, res) => {
    res.json(await board.executiveDashboard(req.params.periodKey));
  })
);

router.get(
  '/:periodKey/drill-down',
  asyncHandler(async (req, res) => {
    res.json(await board.drillDown(req.params.periodKey, Number(req.query.limit ?? 5)));
  })
);

router.get(
  '/:periodKey/health',
  asyncHandler(async (req, res) => {
    res.json(await board.healthScore(req.params.periodKey));
  })
);

router.get(
  '/:periodKey/board-pack',
  asyncHandler(async (req, res) => {
    res.json(await board.exportBoardPack(req.params.periodKey));
  })
);

router.get(
  '/cohorts/summary',
  asyncHandler(async (_req, res) => {
    res.json(await board.cohortSummary());
  })
);

export default router;
