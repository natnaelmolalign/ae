import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { validateBody } from '../middleware/validateZod';
import { z } from 'zod';
import { DataExportService } from '../services/DataExportService';

const router = Router();
const exportsSvc = new DataExportService();

const requestSchema = z.object({ customer_id: z.string().uuid() });

router.post(
  '/',
  validateBody(requestSchema),
  asyncHandler(async (req, res) => {
    const row = await exportsSvc.request(req.body.customer_id);
    res.status(201).json(row);
  })
);

router.post(
  '/:id/process',
  asyncHandler(async (req, res) => {
    res.json(await exportsSvc.process(req.params.id));
  })
);

router.get(
  '/customer/:customerId',
  asyncHandler(async (req, res) => {
    res.json(await exportsSvc.listForCustomer(req.params.customerId));
  })
);

export default router;
