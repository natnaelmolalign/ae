import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { parseUuidParam } from '../lib/parseUuidParam';
import { validateBody } from '../middleware/validateZod';
import { createCreditNoteSchema } from '../validation/schemas';
import { CreditNoteService } from '../services/CreditNoteService';

const router = Router();
const creditNotes = new CreditNoteService();

router.post(
  '/',
  validateBody(createCreditNoteSchema),
  asyncHandler(async (req, res) => {
    res.status(201).json(await creditNotes.issue(req.body));
  })
);

router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'credit note id');
    res.json(await creditNotes.getById(id));
  })
);

export default router;
