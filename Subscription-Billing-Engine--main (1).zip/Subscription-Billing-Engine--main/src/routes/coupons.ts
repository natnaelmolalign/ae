import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { validateBody } from '../middleware/validateZod';
import { createCouponSchema } from '../validation/schemas';
import { CouponService } from '../services/CouponService';

const router = Router();
const couponService = new CouponService();

router.post(
  '/',
  validateBody(createCouponSchema),
  asyncHandler(async (req, res) => {
    res.status(201).json(await couponService.create(req.body));
  })
);

router.get(
  '/:code',
  asyncHandler(async (req, res) => {
    res.json(await couponService.getByCode(req.params.code));
  })
);

export default router;
