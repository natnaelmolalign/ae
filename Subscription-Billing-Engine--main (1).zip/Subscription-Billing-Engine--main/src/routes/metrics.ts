import { Router } from 'express';
import { globalMetrics } from '../lib/metrics';

const router = Router();

router.get('/', (_req, res) => {
  res.type('text/plain').send(globalMetrics.toPrometheusText());
});

router.get('/snapshot', (_req, res) => {
  res.json(globalMetrics.snapshot());
});

export default router;
