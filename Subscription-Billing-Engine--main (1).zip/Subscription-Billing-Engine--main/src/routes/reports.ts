import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { ReportingService } from '../services/ReportingService';

const router = Router();
const reports = new ReportingService();

router.get(
  '/ar-aging',
  asyncHandler(async (req, res) => {
    const asOf = (req.query.as_of as string) || new Date().toISOString().slice(0, 10);
    res.json(await reports.arAging(asOf));
  })
);

router.get(
  '/mrr',
  asyncHandler(async (req, res) => {
    const asOf = (req.query.as_of as string) || new Date().toISOString().slice(0, 10);
    res.json(await reports.mrrSnapshot(asOf));
  })
);

router.get(
  '/revenue-by-plan',
  asyncHandler(async (req, res) => {
    const from = (req.query.from as string) || '2026-01-01';
    const to = (req.query.to as string) || '2026-12-31';
    res.json(await reports.revenueByPlan(from, to));
  })
);

router.get(
  '/churn',
  asyncHandler(async (req, res) => {
    const from = (req.query.from as string) || '2026-01-01';
    const to = (req.query.to as string) || '2026-12-31';
    res.json(await reports.churnRate(from, to));
  })
);

export default router;
