import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { FeatureFlagService } from '../services/FeatureFlagService';
import { requirePermission } from '../middleware/requirePermission';
import { validateBody } from '../middleware/validateZod';
import { z } from 'zod';

const router = Router();
const flags = new FeatureFlagService();

router.get(
  '/',
  requirePermission('admin', 'full'),
  asyncHandler(async (_req, res) => {
    res.json(await flags.list());
  })
);

const upsertSchema = z.object({
  key: z.string(),
  enabled: z.boolean(),
  rules: z.record(z.string(), z.unknown()).optional(),
  description: z.string().optional(),
});

router.put(
  '/',
  requirePermission('admin', 'full'),
  validateBody(upsertSchema),
  asyncHandler(async (req, res) => {
    const body = req.body as z.infer<typeof upsertSchema>;
    res.json(await flags.upsert(body.key, body.enabled, body.rules ?? {}, body.description));
  })
);

router.get(
  '/:key/enabled',
  requirePermission('plans', 'read'),
  asyncHandler(async (req, res) => {
    const enabled = await flags.isEnabled(req.params.key, req.query as Record<string, unknown>);
    res.json({ key: req.params.key, enabled });
  })
);

export default router;
