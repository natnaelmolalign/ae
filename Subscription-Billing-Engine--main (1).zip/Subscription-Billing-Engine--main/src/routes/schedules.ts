import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { validateBody } from '../middleware/validateZod';
import { z } from 'zod';
import { BillingScheduleService } from '../services/BillingScheduleService';

const router = Router();
const schedules = new BillingScheduleService();

const createSchema = z.object({
  customer_id: z.string().uuid(),
  name: z.string().min(1).max(128),
  cadence: z.enum(['monthly', 'quarterly', 'annual']),
  anchor_day: z.number().int().min(1).max(28),
  line_templates: z
    .array(
      z.object({
        description: z.string(),
        amount_cents: z.number().int().nonnegative(),
        quantity: z.number().int().positive(),
      })
    )
    .optional(),
});

router.post(
  '/',
  validateBody(createSchema),
  asyncHandler(async (req, res) => {
    res.status(201).json(await schedules.create(req.body));
  })
);

router.get(
  '/customer/:customerId',
  asyncHandler(async (req, res) => {
    res.json(await schedules.listForCustomer(req.params.customerId));
  })
);

router.post(
  '/:id/deactivate',
  asyncHandler(async (req, res) => {
    res.json(await schedules.deactivate(req.params.id));
  })
);

export default router;
