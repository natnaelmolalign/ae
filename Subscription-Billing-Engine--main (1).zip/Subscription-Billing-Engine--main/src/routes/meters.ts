import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { validateBody } from '../middleware/validateZod';
import { createMeterSchema, recordUsageSchema } from '../validation/schemas';
import { MeteringService } from '../services/MeteringService';

const router = Router();
const metering = new MeteringService();

router.post(
  '/',
  validateBody(createMeterSchema),
  asyncHandler(async (req, res) => {
    res.status(201).json(await metering.createMeter(req.body));
  })
);

router.get(
  '/:code',
  asyncHandler(async (req, res) => {
    res.json(await metering.getByCode(req.params.code));
  })
);

router.post(
  '/:code/usage',
  validateBody(recordUsageSchema),
  asyncHandler(async (req, res) => {
    await metering.recordUsage({
      meter_code: req.params.code,
      subscription_id: req.body.subscription_id,
      quantity: req.body.quantity,
      recorded_at: req.body.recorded_at ? new Date(req.body.recorded_at) : undefined,
      idempotency_key: req.body.idempotency_key,
    });
    res.status(204).send();
  })
);

export default router;
