import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { validateBody } from '../middleware/validateZod';
import { z } from 'zod';
import { PolicyEvaluationService } from '../services/PolicyEvaluationService';

const router = Router();
const policy = new PolicyEvaluationService();

const quoteSchema = z.object({
  subtotal_cents: z.number().int().nonnegative(),
  country: z.string().length(2),
  discount_codes: z.array(z.string()).optional(),
  usage_quantity: z.number().int().nonnegative().optional(),
  usage_tiers: z
    .array(z.object({ up_to: z.number().int().positive().nullable(), unit_cents: z.number() }))
    .optional(),
});

router.post(
  '/quote',
  validateBody(quoteSchema),
  asyncHandler(async (req, res) => {
    res.json(policy.quote(req.body));
  })
);

router.get(
  '/seat-price',
  asyncHandler(async (req, res) => {
    const seats = Number(req.query.seats ?? 1);
    res.json({ seats, amount_cents: policy.seatPrice(seats) });
  })
);

export default router;
