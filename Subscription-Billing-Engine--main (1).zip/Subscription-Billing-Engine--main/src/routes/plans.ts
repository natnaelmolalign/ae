import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { parseUuidParam } from '../lib/parseUuidParam';
import { validateBody, validateQuery } from '../middleware/validateZod';
import { createPlanSchema, paginationSchema } from '../validation/schemas';
import { PlanService } from '../services/PlanService';
import { AppError } from '../lib/errors';

const router = Router();
const planService = new PlanService();

router.get(
  '/',
  validateQuery(paginationSchema),
  asyncHandler(async (req, res) => {
    const q = req.query as unknown as { page: number; limit: number };
    res.json(await planService.listPaginated(q.page, q.limit));
  })
);

router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'plan id');
    res.json(await planService.getById(id));
  })
);

router.post(
  '/',
  validateBody(createPlanSchema),
  asyncHandler(async (req, res) => {
    res.status(201).json(await planService.create(req.body));
  })
);

router.patch(
  '/:id/price',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'plan id');
    const price = req.body.price_cents;
    if (typeof price !== 'number' || price < 0) {
      throw new AppError(400, 'price_cents must be a non-negative number');
    }
    res.json(await planService.updatePrice(id, price));
  })
);

export default router;
