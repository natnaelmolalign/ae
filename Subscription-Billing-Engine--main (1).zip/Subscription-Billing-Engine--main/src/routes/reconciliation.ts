import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { InvoiceReconciliationService } from '../services/InvoiceReconciliationService';

const router = Router();
const recon = new InvoiceReconciliationService();

router.get(
  '/period/:periodKey',
  asyncHandler(async (req, res) => {
    res.json(await recon.runForPeriod(req.params.periodKey));
  })
);

router.get(
  '/period/:periodKey/summary',
  asyncHandler(async (req, res) => {
    res.json(await recon.summaryByStatus(req.params.periodKey));
  })
);

router.get(
  '/invoices/:invoiceId',
  asyncHandler(async (req, res) => {
    res.json(await recon.reconcileInvoice(req.params.invoiceId));
  })
);

router.post(
  '/invoices/:invoiceId/fix-subtotals',
  asyncHandler(async (req, res) => {
    res.json(await recon.fixLineSubtotals(req.params.invoiceId));
  })
);

router.get(
  '/period/:periodKey/export.csv',
  asyncHandler(async (req, res) => {
    res.type('text/csv').send(await recon.exportReport(req.params.periodKey));
  })
);

export default router;
