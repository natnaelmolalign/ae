import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { parseUuidParam } from '../lib/parseUuidParam';
import { validateBody } from '../middleware/validateZod';
import {
  addSubscriptionAddonSchema,
  changeItemQuantitySchema,
  changePlanSchema,
  createSubscriptionSchema,
  uuidParam,
} from '../validation/schemas';
import { SubscriptionItemService } from '../services/SubscriptionItemService';
import { InvoiceService } from '../services/InvoiceService';
import { ProrationService } from '../services/ProrationService';
import { SubscriptionService } from '../services/SubscriptionService';
import { CustomerService } from '../services/CustomerService';
import { AppError } from '../lib/errors';
import { parseDate } from '../utils/dateUtils';
import { z } from 'zod';

const router = Router();
const subscriptionService = new SubscriptionService();
const prorationService = new ProrationService();
const invoiceService = new InvoiceService();
const customerService = new CustomerService();
const subscriptionItems = new SubscriptionItemService();

const extendTrialSchema = z.object({
  extra_days: z.number().int().positive().default(1),
});

const resumeSchema = z.object({
  resume_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
});

const changePlanAtPeriodEndSchema = z.object({
  plan_id: uuidParam,
  as_of: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
});

router.post(
  '/',
  validateBody(createSubscriptionSchema),
  asyncHandler(async (req, res) => {
    res.status(201).json(await subscriptionService.create(req.body));
  })
);

router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'subscription id');
    res.json(await subscriptionService.getById(id));
  })
);

router.post(
  '/:id/cancel',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'subscription id');
    res.json(await subscriptionService.transition(id, 'cancelled'));
  })
);

router.post(
  '/:id/reactivate',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'subscription id');
    res.json(await subscriptionService.reactivate(id));
  })
);

router.post(
  '/:id/pause',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'subscription id');
    res.json(await subscriptionService.pause(id));
  })
);

router.post(
  '/:id/resume',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'subscription id');
    const body = resumeSchema.safeParse(req.body);
    if (!body.success) {
      throw new AppError(400, body.error.message, 'VALIDATION_ERROR');
    }
    res.json(await subscriptionService.resume(id, body.data.resume_date));
  })
);

router.post(
  '/:id/change-plan-at-period-end',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'subscription id');
    const body = changePlanAtPeriodEndSchema.safeParse(req.body);
    if (!body.success) {
      throw new AppError(400, body.error.message, 'VALIDATION_ERROR');
    }
    res.json(
      await subscriptionService.changePlanAtPeriodEnd(
        id,
        body.data.plan_id,
        body.data.as_of ? parseDate(body.data.as_of) : new Date()
      )
    );
  })
);

router.post(
  '/:id/change-plan',
  validateBody(changePlanSchema),
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'subscription id');
    res.json(
      await prorationService.changePlanMidCycle(
        id,
        req.body.plan_id,
        req.body.change_date || new Date().toISOString().slice(0, 10)
      )
    );
  })
);

router.post(
  '/:id/extend-trial',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'subscription id');
    const body = extendTrialSchema.safeParse(req.body);
    if (!body.success) {
      throw new AppError(400, body.error.message, 'VALIDATION_ERROR');
    }
    res.json(await subscriptionService.extendTrial(id, body.data.extra_days));
  })
);

router.get(
  '/:id/items',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'subscription id');
    res.json(await subscriptionItems.listActive(id));
  })
);

router.post(
  '/:id/addons',
  validateBody(addSubscriptionAddonSchema),
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'subscription id');
    res.status(201).json(
      await subscriptionItems.addAddon(id, req.body.addon_code, req.body.quantity)
    );
  })
);

router.patch(
  '/:id/items/:itemId/quantity',
  validateBody(changeItemQuantitySchema),
  asyncHandler(async (req, res) => {
    parseUuidParam(req.params.id, 'subscription id');
    const itemId = parseUuidParam(req.params.itemId, 'item id');
    res.json(
      await subscriptionItems.changeQuantity(
        itemId,
        req.body.quantity,
        req.body.change_date || new Date().toISOString().slice(0, 10)
      )
    );
  })
);

router.post(
  '/:id/invoice',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'subscription id');
    const sub = await subscriptionService.getById(id);
    const customer = await customerService.getById(sub.customer_id);
    res.status(201).json(
      await invoiceService.generateForSubscription(sub, customer.country)
    );
  })
);

export default router;
