import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { CustomerInsightsService } from '../services/CustomerInsightsService';
import { BillingForecastService } from '../services/BillingForecastService';
import { EventProjectionService } from '../services/EventProjectionService';
import { InvoiceExportService } from '../services/InvoiceExportService';
import { CohortAnalysisService } from '../services/CohortAnalysisService';
import { RevenueLeakageService } from '../services/RevenueLeakageService';

const router = Router();
const insights = new CustomerInsightsService();
const forecast = new BillingForecastService();
const projections = new EventProjectionService();
const invoiceExport = new InvoiceExportService();

router.get(
  '/customers/:id/health',
  asyncHandler(async (req, res) => {
    res.json(await insights.healthScore(req.params.id));
  })
);

router.get(
  '/customers/:id/ltv',
  asyncHandler(async (req, res) => {
    res.json(await insights.lifetimeValue(req.params.id));
  })
);

router.get(
  '/at-risk',
  asyncHandler(async (_req, res) => {
    res.json(await insights.atRiskCustomers());
  })
);

router.get(
  '/forecast',
  asyncHandler(async (req, res) => {
    const asOf = (req.query.as_of as string) || new Date().toISOString().slice(0, 10);
    res.json(await forecast.runDefaultScenario(asOf));
  })
);

router.get(
  '/projections/:type',
  asyncHandler(async (req, res) => {
    res.json(await projections.listByAggregate(req.params.type));
  })
);

router.get(
  '/cohorts',
  asyncHandler(async (_req, res) => {
    res.json(await new CohortAnalysisService().buildRetentionMatrix());
  })
);

router.get(
  '/leakage',
  asyncHandler(async (_req, res) => {
    res.json(await new RevenueLeakageService().scan());
  })
);

router.get(
  '/customers/:id/invoices/export',
  asyncHandler(async (req, res) => {
    const format = (req.query.format as 'json' | 'csv') || 'json';
    const body = await invoiceExport.exportCustomerInvoices(req.params.id, format);
    res.type(format === 'csv' ? 'text/csv' : 'application/json').send(body);
  })
);

export default router;
