import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { parseUuidParam } from '../lib/parseUuidParam';
import { RevenueRecognitionService } from '../services/RevenueRecognitionService';

const router = Router();
const revenue = new RevenueRecognitionService();

router.get(
  '/invoices/:invoiceId/schedule',
  asyncHandler(async (req, res) => {
    const invoiceId = parseUuidParam(req.params.invoiceId, 'invoice id');
    res.json(await revenue.listForInvoice(invoiceId));
  })
);

router.get(
  '/subscriptions/:subscriptionId/summary',
  asyncHandler(async (req, res) => {
    const subscriptionId = parseUuidParam(req.params.subscriptionId, 'subscription id');
    res.json(await revenue.summaryForSubscription(subscriptionId));
  })
);

export default router;
