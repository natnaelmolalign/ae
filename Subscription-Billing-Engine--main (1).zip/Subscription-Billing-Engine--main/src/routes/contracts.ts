import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { validateBody } from '../middleware/validateZod';
import { z } from 'zod';
import { ContractService } from '../services/ContractService';

const router = Router();
const contracts = new ContractService();

const createSchema = z.object({
  customer_id: z.string().uuid(),
  reference: z.string().min(1).max(64),
  effective_from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  effective_to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  committed_mrr_cents: z.number().int().nonnegative().optional(),
  terms: z.record(z.string(), z.unknown()).optional(),
});

router.post(
  '/',
  validateBody(createSchema),
  asyncHandler(async (req, res) => {
    res.status(201).json(await contracts.create(req.body));
  })
);

router.post(
  '/:id/activate',
  asyncHandler(async (req, res) => {
    res.json(await contracts.activate(req.params.id));
  })
);

router.post(
  '/:id/amend',
  validateBody(z.object({ amendment_type: z.string(), payload: z.record(z.string(), z.unknown()) })),
  asyncHandler(async (req, res) => {
    res.json(await contracts.amend(req.params.id, req.body.amendment_type, req.body.payload));
  })
);

router.get(
  '/customer/:customerId',
  asyncHandler(async (req, res) => {
    res.json(await contracts.listForCustomer(req.params.customerId));
  })
);

export default router;
