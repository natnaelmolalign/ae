import { Router } from 'express';
import { getDb } from '../config/database';
import { asyncHandler } from '../lib/asyncHandler';
import { HealthProbeService } from '../services/HealthProbeService';

const router = Router();
const probe = new HealthProbeService();

router.get(
  '/',
  asyncHandler(async (_req, res) => {
    try {
      await getDb().raw('SELECT 1');
      res.json({ status: 'ok', database: 'up' });
    } catch {
      res.status(503).json({ status: 'degraded', database: 'down' });
    }
  })
);

router.get('/live', (_req, res) => {
  res.json({ status: 'ok' });
});

router.get(
  '/ready',
  asyncHandler(async (_req, res) => {
    const report = await probe.probe();
    res.status(report.status === 'ok' ? 200 : 503).json(report);
  })
);

export default router;
