import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { getDb } from '../config/database';
import { coerceJsonArray } from '../lib/jsonCoerce';
import { DunningService } from '../services/DunningService';

const router = Router();
const dunning = new DunningService();

router.get(
  '/',
  asyncHandler(async (_req, res) => {
    const rows = await getDb()('dunning_policies').orderBy('created_at', 'asc');
    res.json(
      rows.map((row) => {
        const stages = coerceJsonArray(row.stages);
        return { ...row, stages };
      })
    );
  })
);

router.get(
  '/default',
  asyncHandler(async (_req, res) => {
    res.json(await dunning.getDefaultPolicy());
  })
);

export default router;
