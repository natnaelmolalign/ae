import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { validateBody } from '../middleware/validateZod';
import { z } from 'zod';
import { PaymentMethodVaultService } from '../services/PaymentMethodVaultService';
import { ApiKeyRotationService } from '../services/ApiKeyRotationService';
import { RateLimitPolicyService } from '../services/RateLimitPolicyService';
import { BillingAlertService } from '../services/BillingAlertService';
import { ComplianceReportBuilder } from '../services/compliance/ComplianceReportBuilder';
import { requirePermission } from '../middleware/requirePermission';

const router = Router();
const vault = new PaymentMethodVaultService();
const rotation = new ApiKeyRotationService();
const rateLimits = new RateLimitPolicyService();
const alerts = new BillingAlertService();

router.post(
  '/vault',
  requirePermission('payments', 'write'),
  validateBody(
    z.object({
      customer_id: z.string().uuid(),
      brand: z.string(),
      last4: z.string().length(4),
      exp_month: z.number().int().min(1).max(12),
      exp_year: z.number().int().min(2024),
      set_default: z.boolean().optional(),
    })
  ),
  asyncHandler(async (req, res) => {
    res.status(201).json(await vault.store(req.body));
  })
);

router.get(
  '/vault/customer/:customerId',
  requirePermission('payments', 'read'),
  asyncHandler(async (req, res) => {
    res.json(await vault.listForCustomer(req.params.customerId));
  })
);

router.post(
  '/rbac/principals/:id/rotate-key',
  requirePermission('admin', 'full'),
  asyncHandler(async (req, res) => {
    res.json(await rotation.rotate(req.params.id));
  })
);

router.post(
  '/rate-limits',
  requirePermission('admin', 'full'),
  validateBody(z.object({ principal_id: z.string().uuid(), requests_per_minute: z.number().int() })),
  asyncHandler(async (req, res) => {
    res.json(await rateLimits.setOverride(req.body.principal_id, req.body.requests_per_minute));
  })
);

router.get(
  '/alerts',
  requirePermission('admin', 'full'),
  asyncHandler(async (_req, res) => {
    res.json(await alerts.listOpen());
  })
);

router.post(
  '/alerts/evaluate',
  requirePermission('admin', 'full'),
  asyncHandler(async (_req, res) => {
    const payment = await alerts.evaluatePaymentFailureSpike(0);
    const pastDue = await alerts.evaluatePastDueSubscriptions(0);
    res.json({ payment, past_due: pastDue });
  })
);

router.get(
  '/compliance/report',
  requirePermission('admin', 'full'),
  asyncHandler(async (_req, res) => {
    res.json(await new ComplianceReportBuilder().buildFull());
  })
);

export default router;
