import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { PermissionService, PrincipalService, RoleService } from '../services/RbacService';
import { requirePermission } from '../middleware/requirePermission';
import { validateBody } from '../middleware/validateZod';
import { z } from 'zod';

const router = Router();
const principals = new PrincipalService();
const roles = new RoleService();
const permissions = new PermissionService();

router.get(
  '/permissions',
  requirePermission('admin', 'full'),
  asyncHandler(async (_req, res) => {
    res.json(await permissions.list());
  })
);

router.get(
  '/roles',
  requirePermission('admin', 'full'),
  asyncHandler(async (_req, res) => {
    res.json(await roles.list());
  })
);

router.get(
  '/principals',
  requirePermission('admin', 'full'),
  asyncHandler(async (_req, res) => {
    res.json(await principals.list());
  })
);

const createPrincipalSchema = z.object({
  name: z.string().min(1),
  roles: z.array(z.string()).min(1),
});

router.post(
  '/principals',
  requirePermission('admin', 'full'),
  validateBody(createPrincipalSchema),
  asyncHandler(async (req, res) => {
    const body = req.body as z.infer<typeof createPrincipalSchema>;
    const result = await principals.create(body.name, body.roles);
    res.status(201).json({ principal: result.principal, api_key: result.apiKey });
  })
);

export default router;
