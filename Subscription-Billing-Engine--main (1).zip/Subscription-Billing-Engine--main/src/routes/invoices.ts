import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { parseUuidParam } from '../lib/parseUuidParam';
import { InvoiceService } from '../services/InvoiceService';

const router = Router();
const invoiceService = new InvoiceService();

router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'invoice id');
    const invoice = await invoiceService.getById(id);
    const lineItems = await invoiceService.getLineItems(id);
    res.json({ ...invoice, line_items: lineItems });
  })
);

router.post(
  '/:id/void',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'invoice id');
    res.json(await invoiceService.voidInvoice(id));
  })
);

export default router;
