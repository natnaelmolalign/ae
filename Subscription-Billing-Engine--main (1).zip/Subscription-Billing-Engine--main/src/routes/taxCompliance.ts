import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { TaxComplianceReportService } from '../services/TaxComplianceReportService';

const router = Router();
const tax = new TaxComplianceReportService();

router.get(
  '/:periodKey',
  asyncHandler(async (req, res) => {
    res.json(await tax.buildPack(req.params.periodKey));
  })
);

router.get(
  '/:periodKey/nexus',
  asyncHandler(async (req, res) => {
    res.json(await tax.nexusReport(req.params.periodKey));
  })
);

router.get(
  '/:periodKey/eu-vat',
  asyncHandler(async (req, res) => {
    res.json(await tax.euVatSummary(req.params.periodKey));
  })
);

router.get(
  '/:periodKey/export.csv',
  asyncHandler(async (req, res) => {
    res.type('text/csv').send(await tax.exportPackCsv(req.params.periodKey));
  })
);

export default router;
