import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { validateBody } from '../middleware/validateZod';
import { createAddonSchema } from '../validation/schemas';
import { AddonProductService } from '../services/AddonProductService';

const router = Router();
const addons = new AddonProductService();

router.get(
  '/',
  asyncHandler(async (_req, res) => {
    res.json(await addons.list());
  })
);

router.post(
  '/',
  validateBody(createAddonSchema),
  asyncHandler(async (req, res) => {
    res.status(201).json(await addons.create(req.body));
  })
);

router.get(
  '/:code',
  asyncHandler(async (req, res) => {
    res.json(await addons.getByCode(req.params.code));
  })
);

export default router;
