import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { parseUuidParam } from '../lib/parseUuidParam';
import { validateBody } from '../middleware/validateZod';
import { createQuoteSchema } from '../validation/schemas';
import { QuoteService } from '../services/QuoteService';

const router = Router();
const quotes = new QuoteService();

router.post(
  '/',
  validateBody(createQuoteSchema),
  asyncHandler(async (req, res) => {
    res.status(201).json(await quotes.create(req.body));
  })
);

router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'quote id');
    res.json(await quotes.getById(id));
  })
);

router.post(
  '/:id/send',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'quote id');
    res.json(await quotes.send(id));
  })
);

router.post(
  '/:id/convert',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'quote id');
    res.status(201).json(await quotes.convertToSubscription(id));
  })
);

export default router;
