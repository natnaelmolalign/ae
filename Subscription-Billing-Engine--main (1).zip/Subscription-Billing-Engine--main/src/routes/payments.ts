import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { parseUuidParam } from '../lib/parseUuidParam';
import { idempotencyMiddleware } from '../middleware/idempotency';
import { validateBody } from '../middleware/validateZod';
import { chargeSchema, refundSchema } from '../validation/schemas';
import { PaymentService } from '../services/PaymentService';
import { AppError } from '../lib/errors';

const router = Router();
const paymentService = new PaymentService();

router.post(
  '/charge',
  idempotencyMiddleware('POST /payments/charge'),
  validateBody(chargeSchema),
  asyncHandler(async (req, res) => {
    const key = req.header('idempotency-key') || undefined;
    const payment = await paymentService.chargeInvoice(
      req.body.invoice_id,
      req.body.simulate_success !== false,
      { idempotencyKey: key }
    );
    res.status(201).json(payment);
  })
);

router.post(
  '/:id/refund',
  asyncHandler(async (req, res) => {
    const id = parseUuidParam(req.params.id, 'payment id');
    const body = refundSchema.safeParse(req.body);
    if (!body.success) {
      throw new AppError(400, body.error.message, 'VALIDATION_ERROR');
    }
    res.json(await paymentService.refundPayment(id, body.data.amount_cents));
  })
);

export default router;
