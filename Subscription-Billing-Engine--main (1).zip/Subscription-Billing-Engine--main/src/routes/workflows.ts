import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { WorkflowEngine } from '../services/WorkflowEngine';
import { requirePermission } from '../middleware/requirePermission';
import { validateBody } from '../middleware/validateZod';
import { z } from 'zod';

const router = Router();
const engine = new WorkflowEngine();

const startSchema = z.object({
  definition_name: z.string(),
  entity_type: z.string(),
  entity_id: z.string().uuid(),
  initial_state: z.string(),
  context: z.record(z.string(), z.unknown()).optional(),
});

router.post(
  '/instances',
  requirePermission('subscriptions', 'write'),
  validateBody(startSchema),
  asyncHandler(async (req, res) => {
    const body = req.body as z.infer<typeof startSchema>;
    const instance = await engine.start(
      body.definition_name,
      body.entity_type,
      body.entity_id,
      body.initial_state,
      body.context ?? {}
    );
    res.status(201).json(instance);
  })
);

const triggerSchema = z.object({
  trigger: z.string(),
  context: z.record(z.string(), z.unknown()).optional(),
});

router.post(
  '/instances/:id/trigger',
  requirePermission('subscriptions', 'write'),
  validateBody(triggerSchema),
  asyncHandler(async (req, res) => {
    const body = req.body as z.infer<typeof triggerSchema>;
    const instance = await engine.trigger(
      req.params.id,
      body.trigger,
      req.principalId,
      body.context ?? {}
    );
    res.json(instance);
  })
);

router.get(
  '/instances/:id',
  requirePermission('subscriptions', 'read'),
  asyncHandler(async (req, res) => {
    res.json(await engine.getInstance(req.params.id));
  })
);

router.get(
  '/instances/:id/history',
  requirePermission('subscriptions', 'read'),
  asyncHandler(async (req, res) => {
    res.json(await engine.getHistory(req.params.id));
  })
);

export default router;
