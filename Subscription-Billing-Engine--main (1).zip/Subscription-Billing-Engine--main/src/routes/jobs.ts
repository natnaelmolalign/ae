import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { JobLockService } from '../services/JobLockService';

const router = Router();
const jobs = new JobLockService();

router.get(
  '/runs',
  asyncHandler(async (req, res) => {
    const jobName = req.query.job as string | undefined;
    res.json(await jobs.listRecent(jobName));
  })
);

export default router;
