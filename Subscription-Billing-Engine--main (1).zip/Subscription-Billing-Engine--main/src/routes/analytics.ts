import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { AnalyticsRollupService } from '../services/AnalyticsRollupService';

const router = Router();
const analytics = new AnalyticsRollupService();

router.get(
  '/daily',
  asyncHandler(async (req, res) => {
    const date = (req.query.date as string) || undefined;
    if (date) {
      const row = await analytics.getDaily(date);
      res.json(row ?? { stat_date: date, message: 'No rollup for date' });
      return;
    }
    res.json(await analytics.listRecent(30));
  })
);

export default router;
