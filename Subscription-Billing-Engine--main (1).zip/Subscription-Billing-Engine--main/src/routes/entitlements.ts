import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler';
import { parseUuidParam } from '../lib/parseUuidParam';
import { validateBody } from '../middleware/validateZod';
import { entitlementCheckSchema, upsertEntitlementsSchema } from '../validation/schemas';
import { EntitlementService } from '../services/EntitlementService';

const router = Router({ mergeParams: true });
const entitlements = new EntitlementService();

router.put(
  '/',
  validateBody(upsertEntitlementsSchema),
  asyncHandler(async (req, res) => {
    const planId = parseUuidParam(req.params.planId, 'plan id');
    res.json(await entitlements.upsertForPlan(planId, req.body.entitlements));
  })
);

router.get(
  '/',
  asyncHandler(async (req, res) => {
    const planId = parseUuidParam(req.params.planId, 'plan id');
    res.json(await entitlements.listForPlan(planId));
  })
);

router.post(
  '/check',
  validateBody(entitlementCheckSchema),
  asyncHandler(async (req, res) => {
    res.json(
      await entitlements.check(req.body.subscription_id, req.body.feature_key)
    );
  })
);

export default router;
