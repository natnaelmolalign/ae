import { AppError } from './errors';
import { uuidParam } from '../validation/schemas';

export function parseUuidParam(value: string, label = 'id'): string {
  const parsed = uuidParam.safeParse(value);
  if (!parsed.success) {
    throw new AppError(400, `Invalid ${label}`);
  }
  return parsed.data;
}
