import { getDb } from '../config/database';

type MetricLabels = Record<string, string | number>;

interface CounterState {
  value: number;
  labels: MetricLabels;
}

interface HistogramBucket {
  le: number;
  count: number;
}

export class MetricsRegistry {
  private counters = new Map<string, CounterState>();
  private histograms = new Map<string, { sum: number; count: number; buckets: HistogramBucket[] }>();

  private key(name: string, labels: MetricLabels): string {
    const sorted = Object.keys(labels)
      .sort()
      .map((k) => `${k}=${labels[k]}`)
      .join(',');
    return sorted ? `${name}{${sorted}}` : name;
  }

  increment(name: string, labels: MetricLabels = {}, delta = 1): void {
    const k = this.key(name, labels);
    const existing = this.counters.get(k) ?? { value: 0, labels };
    existing.value += delta;
    this.counters.set(k, existing);
  }

  observeHistogram(name: string, value: number, labels: MetricLabels = {}): void {
    const k = this.key(name, labels);
    const bounds = [5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000];
    let h = this.histograms.get(k);
    if (!h) {
      h = { sum: 0, count: 0, buckets: bounds.map((le) => ({ le, count: 0 })) };
      this.histograms.set(k, h);
    }
    h.sum += value;
    h.count += 1;
    for (const b of h.buckets) {
      if (value <= b.le) b.count += 1;
    }
  }

  snapshot(): { counters: CounterState[]; histograms: Array<{ name: string; sum: number; count: number; buckets: HistogramBucket[] }> } {
    return {
      counters: [...this.counters.entries()].map(([name, s]) => ({ ...s, labels: { ...s.labels, __name: name.split('{')[0] } })),
      histograms: [...this.histograms.entries()].map(([name, h]) => ({ name, ...h })),
    };
  }

  toPrometheusText(): string {
    const lines: string[] = [];
    for (const [key, state] of this.counters) {
      const labelStr = Object.entries(state.labels)
        .map(([k, v]) => `${k}="${v}"`)
        .join(',');
      const metricName = key.split('{')[0];
      lines.push(labelStr ? `${metricName}{${labelStr}} ${state.value}` : `${metricName} ${state.value}`);
    }
    for (const [key, h] of this.histograms) {
      const metricName = key.split('{')[0];
      for (const b of h.buckets) {
        lines.push(`${metricName}_bucket{le="${b.le}"} ${b.count}`);
      }
      lines.push(`${metricName}_sum ${h.sum}`);
      lines.push(`${metricName}_count ${h.count}`);
    }
    return lines.join('\n') + (lines.length ? '\n' : '');
  }

  async persistRecent(windowMinutes = 60): Promise<number> {
    const db = getDb();
    const since = new Date(Date.now() - windowMinutes * 60_000);
    await db('application_metrics').where('recorded_at', '<', since).del();
    let inserted = 0;
    for (const [key, state] of this.counters) {
      await db('application_metrics').insert({
        name: key.split('{')[0],
        value: state.value,
        labels: JSON.stringify(state.labels),
      });
      inserted += 1;
    }
    return inserted;
  }
}

export const globalMetrics = new MetricsRegistry();

export function recordHttpRequest(method: string, path: string, status: number, durationMs: number): void {
  globalMetrics.increment('http_requests_total', { method, path, status: String(status) });
  globalMetrics.observeHistogram('http_request_duration_ms', durationMs, { method, path });
}
