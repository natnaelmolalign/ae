interface CacheEntry<T> {
  value: T;
  expiresAt: number;
}

export class QueryCache<T> {
  private store = new Map<string, CacheEntry<T>>();

  constructor(private readonly ttlMs: number, private readonly maxEntries = 500) {}

  private evictIfNeeded(): void {
    if (this.store.size < this.maxEntries) return;
    const oldest = [...this.store.entries()].sort((a, b) => a[1].expiresAt - b[1].expiresAt)[0];
    if (oldest) this.store.delete(oldest[0]);
  }

  get(key: string): T | undefined {
    const entry = this.store.get(key);
    if (!entry) return undefined;
    if (Date.now() > entry.expiresAt) {
      this.store.delete(key);
      return undefined;
    }
    return entry.value;
  }

  set(key: string, value: T): void {
    this.evictIfNeeded();
    this.store.set(key, { value, expiresAt: Date.now() + this.ttlMs });
  }

  invalidate(key: string): void {
    this.store.delete(key);
  }

  clear(): void {
    this.store.clear();
  }

  size(): number {
    return this.store.size;
  }
}

export const planCache = new QueryCache<Record<string, unknown>>(60_000);
export const subscriptionCache = new QueryCache<Record<string, unknown>>(30_000);
