export interface BillingPeriod {
  key: string;
  start: Date;
  end: Date;
}

/**
 * Utilities for calendar and fiscal billing periods used across reporting services.
 */
export function monthPeriodKey(date: Date): string {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}`;
}

export function parseMonthPeriod(periodKey: string): BillingPeriod {
  if (!/^\d{4}-\d{2}$/.test(periodKey)) {
    throw new Error('period_key must be YYYY-MM');
  }
  const [y, m] = periodKey.split('-').map(Number);
  return {
    key: periodKey,
    start: new Date(Date.UTC(y, m - 1, 1)),
    end: new Date(Date.UTC(y, m, 0, 23, 59, 59, 999)),
  };
}

export function previousMonth(periodKey: string): string {
  const { start } = parseMonthPeriod(periodKey);
  const prev = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() - 1, 1));
  return monthPeriodKey(prev);
}

export function nextMonth(periodKey: string): string {
  const { start } = parseMonthPeriod(periodKey);
  const next = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + 1, 1));
  return monthPeriodKey(next);
}

export function monthsBetween(fromKey: string, toKey: string): string[] {
  const keys: string[] = [];
  let current = fromKey;
  while (current <= toKey) {
    keys.push(current);
    current = nextMonth(current);
    if (keys.length > 240) break;
  }
  return keys;
}

export function fiscalQuarter(periodKey: string, fiscalYearStartMonth = 1): 1 | 2 | 3 | 4 {
  const { start } = parseMonthPeriod(periodKey);
  const month = start.getUTCMonth() + 1;
  const offset = (month - fiscalYearStartMonth + 12) % 12;
  return (Math.floor(offset / 3) + 1) as 1 | 2 | 3 | 4;
}

export function fiscalYear(periodKey: string, fiscalYearStartMonth = 1): number {
  const { start } = parseMonthPeriod(periodKey);
  const month = start.getUTCMonth() + 1;
  return month >= fiscalYearStartMonth ? start.getUTCFullYear() : start.getUTCFullYear() - 1;
}

export function quarterPeriodKeys(year: number, quarter: 1 | 2 | 3 | 4): string[] {
  const startMonth = (quarter - 1) * 3 + 1;
  return [0, 1, 2].map((i) => `${year}-${String(startMonth + i).padStart(2, '0')}`);
}

export function daysInMonthPeriod(periodKey: string): number {
  const { start, end } = parseMonthPeriod(periodKey);
  return Math.round((end.getTime() - start.getTime()) / 86400000) + 1;
}

export function containsDate(periodKey: string, date: Date): boolean {
  const { start, end } = parseMonthPeriod(periodKey);
  return date >= start && date <= end;
}

export function currentMonthPeriod(asOf = new Date()): BillingPeriod {
  const key = monthPeriodKey(asOf);
  return parseMonthPeriod(key);
}

export function trailingMonths(count: number, asOf = new Date()): string[] {
  const keys: string[] = [];
  let d = new Date(Date.UTC(asOf.getUTCFullYear(), asOf.getUTCMonth(), 1));
  for (let i = 0; i < count; i++) {
    keys.unshift(monthPeriodKey(d));
    d = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - 1, 1));
  }
  return keys;
}

export function formatPeriodLabel(periodKey: string): string {
  const { start } = parseMonthPeriod(periodKey);
  return start.toLocaleString('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' });
}

export function isValidPeriodKey(value: string): boolean {
  return /^\d{4}-\d{2}$/.test(value);
}

export function yearToDateMonths(periodKey: string): string[] {
  const { start } = parseMonthPeriod(periodKey);
  const year = start.getUTCFullYear();
  const endMonth = start.getUTCMonth() + 1;
  const keys: string[] = [];
  for (let m = 1; m <= endMonth; m++) {
    keys.push(`${year}-${String(m).padStart(2, '0')}`);
  }
  return keys;
}

export function overlapDays(aKey: string, bKey: string): number {
  const a = parseMonthPeriod(aKey);
  const b = parseMonthPeriod(bKey);
  const start = a.start > b.start ? a.start : b.start;
  const end = a.end < b.end ? a.end : b.end;
  if (end < start) return 0;
  return Math.round((end.getTime() - start.getTime()) / 86400000) + 1;
}

export function sameYear(aKey: string, bKey: string): boolean {
  return parseMonthPeriod(aKey).start.getUTCFullYear() === parseMonthPeriod(bKey).start.getUTCFullYear();
}

export function minPeriodKey(keys: string[]): string | null {
  if (keys.length === 0) return null;
  return keys.slice().sort()[0];
}

export function maxPeriodKey(keys: string[]): string | null {
  if (keys.length === 0) return null;
  return keys.slice().sort().reverse()[0];
}

export function periodKeyFromDate(date: Date): string {
  return monthPeriodKey(date);
}
