import winston from 'winston';
import { loadEnv } from '../config/env';

const { LOG_LEVEL } = loadEnv();

export const logger = winston.createLogger({
  level: LOG_LEVEL,
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: { service: 'billing-engine' },
  transports: [new winston.transports.Console()],
});

export function childLogger(meta: Record<string, unknown>) {
  return logger.child(meta);
}
