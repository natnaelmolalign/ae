import { logger } from './logger';

export type CircuitState = 'closed' | 'open' | 'half_open';

export interface CircuitBreakerOptions {
  failureThreshold: number;
  resetTimeoutMs: number;
  halfOpenSuccesses: number;
}

const DEFAULT_OPTS: CircuitBreakerOptions = {
  failureThreshold: 5,
  resetTimeoutMs: 30_000,
  halfOpenSuccesses: 2,
};

/**
 * Lightweight in-process circuit breaker for outbound calls (webhooks, exports).
 */
export class CircuitBreaker {
  private state: CircuitState = 'closed';
  private failures = 0;
  private successesInHalfOpen = 0;
  private openedAt = 0;

  constructor(private readonly name: string, private readonly opts: CircuitBreakerOptions = DEFAULT_OPTS) {}

  getState(): CircuitState {
    if (this.state === 'open' && Date.now() - this.openedAt >= this.opts.resetTimeoutMs) {
      this.state = 'half_open';
      this.successesInHalfOpen = 0;
    }
    return this.state;
  }

  async execute<T>(fn: () => Promise<T>): Promise<T> {
    const state = this.getState();
    if (state === 'open') {
      throw new Error(`Circuit ${this.name} is open`);
    }
    try {
      const result = await fn();
      this.onSuccess();
      return result;
    } catch (err) {
      this.onFailure();
      throw err;
    }
  }

  private onSuccess(): void {
    if (this.state === 'half_open') {
      this.successesInHalfOpen += 1;
      if (this.successesInHalfOpen >= this.opts.halfOpenSuccesses) {
        this.state = 'closed';
        this.failures = 0;
        logger.info('circuit_closed', { circuit: this.name });
      }
      return;
    }
    this.failures = 0;
  }

  private onFailure(): void {
    this.failures += 1;
    if (this.state === 'half_open' || this.failures >= this.opts.failureThreshold) {
      this.state = 'open';
      this.openedAt = Date.now();
      logger.warn('circuit_opened', { circuit: this.name, failures: this.failures });
    }
  }

  reset(): void {
    this.state = 'closed';
    this.failures = 0;
    this.successesInHalfOpen = 0;
  }
}

export const webhookCircuit = new CircuitBreaker('webhook_delivery');
