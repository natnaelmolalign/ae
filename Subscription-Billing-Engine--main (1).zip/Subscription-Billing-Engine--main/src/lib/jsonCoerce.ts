/**
 * Normalizes JSON/JSONB columns that may be returned as strings or parsed objects.
 */
export function coerceJsonValue<T>(value: unknown, fallback: T): T {
  if (value == null) return fallback;
  if (typeof value === 'string') return JSON.parse(value) as T;
  return value as T;
}

export function coerceJsonArray<T>(value: unknown, fallback: T[] = []): T[] {
  return coerceJsonValue(value, fallback);
}
