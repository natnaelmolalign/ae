import { daysInPeriod, daysRemainingInPeriod, parseDate } from './dateUtils';

export interface ProrationInput {
  oldPriceCents: number;
  newPriceCents: number;
  periodStart: string | Date;
  periodEnd: string | Date;
  changeDate: string | Date;
}

export interface ProrationResult {
  creditCents: number;
  chargeCents: number;
  netCents: number;
  unusedDays: number;
  remainingDays: number;
  totalDays: number;
}

/**
 * Mid-cycle plan change: credit unused portion of old plan, charge remaining on new plan.
 */
export function calculateProration(input: ProrationInput): ProrationResult {
  const start = parseDate(input.periodStart);
  const end = parseDate(input.periodEnd);
  const change = parseDate(input.changeDate);

  const totalDays = daysInPeriod(start, end);
  const remainingDays = daysRemainingInPeriod(change, end);
  const unusedDays = totalDays - remainingDays;

  if (totalDays <= 0 || remainingDays <= 0) {
    return {
      creditCents: 0,
      chargeCents: 0,
      netCents: 0,
      unusedDays: 0,
      remainingDays: 0,
      totalDays,
    };
  }

  const creditCents = Math.round((input.oldPriceCents * unusedDays) / totalDays);
  const chargeCents = Math.round((input.newPriceCents * remainingDays) / totalDays);
  const netCents = chargeCents - creditCents;

  return {
    creditCents,
    chargeCents,
    netCents,
    unusedDays,
    remainingDays,
    totalDays,
  };
}
