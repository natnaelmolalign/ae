import {
  addDays,
  addMonths,
  addYears,
  differenceInCalendarDays,
  format,
  isAfter,
  isBefore,
  isEqual,
  parseISO,
  startOfDay,
} from 'date-fns';
import type { BillingInterval } from '../models/Plan';

export function toDateString(d: Date): string {
  return format(startOfDay(d), 'yyyy-MM-dd');
}

export function parseDate(value: string | Date): Date {
  return typeof value === 'string' ? startOfDay(parseISO(value)) : startOfDay(value);
}

/** Anchor billing day (e.g. 31) clamped to the month's last day. */
export function anchorDayInMonth(year: number, monthIndex: number, anchorDay: number): number {
  const lastDay = new Date(year, monthIndex + 1, 0).getDate();
  return Math.min(anchorDay, lastDay);
}

export function addBillingInterval(
  from: Date,
  interval: BillingInterval,
  anchorDay: number
): Date {
  const base = startOfDay(from);
  if (interval === 'yearly') {
    const next = addYears(base, 1);
    const day = anchorDayInMonth(next.getFullYear(), next.getMonth(), anchorDay);
    return new Date(next.getFullYear(), next.getMonth(), day);
  }
  const next = addMonths(base, 1);
  const day = anchorDayInMonth(next.getFullYear(), next.getMonth(), anchorDay);
  return new Date(next.getFullYear(), next.getMonth(), day);
}

export function periodEndFromStart(
  periodStart: Date,
  interval: BillingInterval,
  anchorDay: number
): Date {
  const end = addBillingInterval(periodStart, interval, anchorDay);
  return addDays(end, -1);
}

export function daysInPeriod(start: Date, end: Date): number {
  return differenceInCalendarDays(end, start) + 1;
}

export function daysRemainingInPeriod(asOf: Date, periodEnd: Date): number {
  const asOfDay = startOfDay(asOf);
  const endDay = startOfDay(periodEnd);
  if (isAfter(asOfDay, endDay)) return 0;
  return differenceInCalendarDays(endDay, asOfDay) + 1;
}

export function isOnOrBefore(a: Date, b: Date): boolean {
  return isBefore(a, b) || isEqual(a, b);
}

export function isExpired(asOf: Date, periodEnd: Date): boolean {
  return isAfter(startOfDay(asOf), startOfDay(periodEnd));
}

export function gracePeriodEnd(dueDate: Date, graceDays: number): Date {
  return addDays(startOfDay(dueDate), graceDays);
}
