import { addDays } from 'date-fns';

export function parseRetryDelays(envValue?: string): number[] {
  const raw = envValue || process.env.RETRY_DELAYS_DAYS || '3,5,7';
  return raw.split(',').map((s) => parseInt(s.trim(), 10)).filter((n) => !Number.isNaN(n) && n > 0);
}

export function nextRetryDate(
  firstFailureAt: Date,
  attemptNumber: number,
  delays: number[]
): Date | null {
  if (attemptNumber < 1 || attemptNumber > delays.length) {
    return null;
  }
  const delayDays = delays.slice(0, attemptNumber).reduce((a, b) => a + b, 0);
  return addDays(firstFailureAt, delayDays);
}

export function maxRetryAttempts(delays: number[]): number {
  return delays.length;
}
