export function centsToDecimal(cents: number): string {
  return (cents / 100).toFixed(2);
}

export function applyPercentDiscount(amountCents: number, percent: number): number {
  const discount = Math.round((amountCents * percent) / 100);
  return Math.max(0, amountCents - discount);
}

export function applyFixedDiscount(amountCents: number, fixedCents: number): number {
  return Math.max(0, amountCents - fixedCents);
}

export function calculateTax(subtotalCents: number, rateBps: number): number {
  return Math.round((subtotalCents * rateBps) / 10000);
}

export function sumCents(...amounts: number[]): number {
  return amounts.reduce((a, b) => a + b, 0);
}
