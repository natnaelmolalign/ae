import type { Request, Response, NextFunction } from 'express';

const SUPPORTED = ['2024-06-01', '2025-01-01', '2026-06-01'];
const DEFAULT_VERSION = '2026-06-01';

declare module 'express-serve-static-core' {
  interface Request {
    apiVersion?: string;
  }
}

export function apiVersionMiddleware(req: Request, _res: Response, next: NextFunction): void {
  const header = (req.headers['x-api-version'] as string) || DEFAULT_VERSION;
  req.apiVersion = SUPPORTED.includes(header) ? header : DEFAULT_VERSION;
  next();
}

export function getSupportedApiVersions(): string[] {
  return [...SUPPORTED];
}
