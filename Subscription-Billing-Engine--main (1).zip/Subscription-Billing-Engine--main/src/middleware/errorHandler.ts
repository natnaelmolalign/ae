import { NextFunction, Request, Response } from 'express';
import { ZodError } from 'zod';
import { AppError } from '../lib/errors';
import { childLogger } from '../lib/logger';
import { getRequestId } from '../lib/requestContext';

export { AppError } from '../lib/errors';

export function errorHandler(
  err: Error,
  _req: Request,
  res: Response,
  _next: NextFunction
): void {
  const log = childLogger({ requestId: getRequestId() });

  if (err instanceof AppError) {
    res.status(err.statusCode).json({ error: err.message, code: err.code });
    return;
  }

  if (err instanceof ZodError) {
    res.status(400).json({
      error: err.issues.map((i) => i.message).join(', '),
      code: 'VALIDATION_ERROR',
    });
    return;
  }

  log.error('unhandled_error', { error: err.message, stack: err.stack });
  res.status(500).json({ error: 'Internal server error' });
}
