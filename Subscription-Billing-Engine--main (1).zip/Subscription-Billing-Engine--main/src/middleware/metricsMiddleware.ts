import { Request, Response, NextFunction } from 'express';
import { recordHttpRequest } from '../lib/metrics';

export function metricsMiddleware(req: Request, res: Response, next: NextFunction): void {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    const path = req.route?.path ? `${req.baseUrl}${req.route.path}` : req.path;
    recordHttpRequest(req.method, path, res.statusCode, duration);
  });
  next();
}
