import { NextFunction, Request, Response } from 'express';
import { loadEnv } from '../config/env';
import { AppError } from '../lib/errors';
import { PrincipalService } from '../services/RbacService';

declare global {
  namespace Express {
    interface Request {
      principalId?: string;
    }
  }
}

export async function authMiddleware(
  req: Request,
  _res: Response,
  next: NextFunction
): Promise<void> {
  const apiKey = req.header('x-api-key');
  if (!apiKey) {
    next(new AppError(401, 'Unauthorized', 'UNAUTHORIZED'));
    return;
  }
  const { API_KEY } = loadEnv();
  const principals = new PrincipalService();
  const principal = await principals.resolveByApiKey(apiKey);
  if (principal) {
    req.principalId = principal.id;
    next();
    return;
  }
  if (apiKey === API_KEY) {
    const bootstrapped = await principals.bootstrapFromEnvMasterKey(API_KEY);
    req.principalId = bootstrapped.id;
    next();
    return;
  }
  next(new AppError(401, 'Unauthorized', 'UNAUTHORIZED'));
}
