import { NextFunction, Request, Response } from 'express';
import { AppError } from './errorHandler';

type FieldRule = {
  required?: boolean;
  type?: 'string' | 'number' | 'boolean';
  min?: number;
};

export function validateBody(fields: Record<string, FieldRule>) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    const body = req.body || {};
    for (const [name, rule] of Object.entries(fields)) {
      const value = body[name];
      if (rule.required && (value === undefined || value === null || value === '')) {
        next(new AppError(400, `Missing required field: ${name}`, 'VALIDATION_ERROR'));
        return;
      }
      if (value !== undefined && rule.type) {
        if (rule.type === 'number' && typeof value !== 'number') {
          next(new AppError(400, `Field ${name} must be a number`, 'VALIDATION_ERROR'));
          return;
        }
        if (rule.type === 'string' && typeof value !== 'string') {
          next(new AppError(400, `Field ${name} must be a string`, 'VALIDATION_ERROR'));
          return;
        }
        if (rule.type === 'number' && rule.min !== undefined && value < rule.min) {
          next(new AppError(400, `Field ${name} must be >= ${rule.min}`, 'VALIDATION_ERROR'));
          return;
        }
      }
    }
    next();
  };
}
