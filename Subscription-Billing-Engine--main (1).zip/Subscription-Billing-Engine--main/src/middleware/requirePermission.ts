import { NextFunction, Request, Response } from 'express';
import { PrincipalService } from '../services/RbacService';
import { AppError } from '../lib/errors';

declare global {
  namespace Express {
    interface Request {
      principalId?: string;
    }
  }
}

export function requirePermission(resource: string, action: string) {
  const principals = new PrincipalService();
  return async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.principalId) {
        next(new AppError(401, 'Principal not resolved', 'UNAUTHORIZED'));
        return;
      }
      await principals.assertPermission(req.principalId, resource, action);
      next();
    } catch (err) {
      next(err);
    }
  };
}
