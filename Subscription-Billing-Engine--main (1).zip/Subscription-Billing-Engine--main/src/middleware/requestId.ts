import { randomUUID } from 'crypto';
import { NextFunction, Request, Response } from 'express';
import { requestContext } from '../lib/requestContext';

export function requestIdMiddleware(req: Request, res: Response, next: NextFunction): void {
  const requestId = (req.header('x-request-id') || randomUUID()).slice(0, 64);
  res.setHeader('x-request-id', requestId);
  requestContext.run({ requestId }, () => next());
}
