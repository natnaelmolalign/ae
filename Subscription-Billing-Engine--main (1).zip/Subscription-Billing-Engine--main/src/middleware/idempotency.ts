import { NextFunction, Request, Response } from 'express';
import { IdempotencyService } from '../services/IdempotencyService';

const idempotency = new IdempotencyService();

export function idempotencyMiddleware(routeKey: string) {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    const key = req.header('idempotency-key');
    if (!key) {
      next();
      return;
    }

    const cached = await idempotency.getCached(routeKey, key);
    if (cached) {
      res.status(cached.status).json(cached.body);
      return;
    }

    const originalJson = res.json.bind(res);
    res.json = (body: unknown) => {
      void idempotency.store(routeKey, key, res.statusCode, body);
      return originalJson(body);
    };

    next();
  };
}
