import { NextFunction, Request, Response } from 'express';
import { childLogger } from '../lib/logger';
import { getRequestId } from '../lib/requestContext';

export function requestLogger(req: Request, res: Response, next: NextFunction): void {
  const start = Date.now();
  const log = childLogger({ requestId: getRequestId() });

  res.on('finish', () => {
    log.info('http_request', {
      method: req.method,
      path: req.originalUrl,
      status: res.statusCode,
      duration_ms: Date.now() - start,
    });
  });

  next();
}
