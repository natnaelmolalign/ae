import { NextFunction, Request, Response } from 'express';

const windowMs = 60_000;
const maxRequests = 120;
const hits = new Map<string, { count: number; resetAt: number }>();

export function rateLimiter(req: Request, res: Response, next: NextFunction): void {
  const key = req.ip || 'unknown';
  const now = Date.now();
  let entry = hits.get(key);
  if (!entry || now > entry.resetAt) {
    entry = { count: 0, resetAt: now + windowMs };
    hits.set(key, entry);
  }
  entry.count += 1;
  if (entry.count > maxRequests) {
    res.status(429).json({ error: 'Too many requests' });
    return;
  }
  next();
}
