import { BaseRepository } from './BaseRepository';
import type { Payment } from '../models/Payment';

export class PaymentRepository extends BaseRepository {
  async findByIdempotency(
    invoiceId: string,
    idempotencyKey: string
  ): Promise<Payment | null> {
    const row = await this.db('payments')
      .where({ invoice_id: invoiceId, idempotency_key: idempotencyKey })
      .first();
    return row ? (row as Payment) : null;
  }

  async insert(row: Record<string, unknown>): Promise<Payment> {
    const [payment] = await this.db('payments').insert(row).returning('*');
    return payment as Payment;
  }
}
