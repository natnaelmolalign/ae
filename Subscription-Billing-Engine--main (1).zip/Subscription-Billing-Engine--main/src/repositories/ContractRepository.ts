import { coerceJsonValue } from '../lib/jsonCoerce';
import { BaseRepository } from './BaseRepository';
import type { Contract } from '../services/ContractService';

export class ContractRepository extends BaseRepository {
  protected table = 'contracts';

  async findByReference(reference: string): Promise<Contract | null> {
    const row = await this.db(this.table).where({ reference }).first();
    return row ? this.map(row) : null;
  }

  async listActiveForCustomer(customerId: string): Promise<Contract[]> {
    const rows = await this.db(this.table)
      .where({ customer_id: customerId })
      .whereIn('status', ['active', 'amended'])
      .orderBy('effective_from', 'desc');
    return rows.map((r) => this.map(r));
  }

  private map(row: Record<string, unknown>): Contract {
    return {
      ...row,
      terms: coerceJsonValue(row.terms, {}),
    } as Contract;
  }
}
