import { BaseRepository } from './BaseRepository';
import type { Invoice } from '../models/Invoice';

export class InvoiceRepository extends BaseRepository {
  async findByIdForUpdate(id: string): Promise<Invoice | null> {
    const row = await this.db('invoices').where({ id }).forUpdate().first();
    return row ? (row as Invoice) : null;
  }

  async markPaid(id: string): Promise<Invoice> {
    const [row] = await this.db('invoices')
      .where({ id })
      .update({ status: 'paid', updated_at: this.db.fn.now() })
      .returning('*');
    return row as Invoice;
  }
}
