import type { Knex } from 'knex';
import { BaseRepository } from './BaseRepository';
import type { Subscription } from '../models/Subscription';

export class SubscriptionRepository extends BaseRepository {
  async findByIdForUpdate(id: string): Promise<Subscription | null> {
    const row = await this.db('subscriptions').where({ id }).forUpdate().first();
    return row ? (row as Subscription) : null;
  }

  async update(
    id: string,
    patch: Record<string, unknown>,
    trx?: Knex.Transaction
  ): Promise<Subscription> {
    const conn = trx ?? this.db;
    const [row] = await conn('subscriptions')
      .where({ id })
      .update({ ...patch, updated_at: conn.fn.now() })
      .returning('*');
    return row as Subscription;
  }
}
