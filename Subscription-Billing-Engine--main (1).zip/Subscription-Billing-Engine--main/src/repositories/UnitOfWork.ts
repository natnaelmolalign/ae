import type { Knex } from 'knex';
import { getDb } from '../config/database';
import { DomainEventPublisher, type PublishEventInput } from '../services/DomainEventPublisher';
import { InvoiceRepository } from './InvoiceRepository';
import { PaymentRepository } from './PaymentRepository';
import { SubscriptionRepository } from './SubscriptionRepository';

export class UnitOfWork {
  readonly subscriptions: SubscriptionRepository;
  readonly invoices: InvoiceRepository;
  readonly payments: PaymentRepository;

  constructor(
    private readonly trx: Knex.Transaction,
    private readonly events = new DomainEventPublisher()
  ) {
    this.subscriptions = new SubscriptionRepository(trx);
    this.invoices = new InvoiceRepository(trx);
    this.payments = new PaymentRepository(trx);
  }

  get transaction(): Knex.Transaction {
    return this.trx;
  }

  async publish(input: PublishEventInput) {
    return this.events.publish(input, this.trx);
  }

  static async run<T>(fn: (uow: UnitOfWork) => Promise<T>): Promise<T> {
    return getDb().transaction(async (trx) => fn(new UnitOfWork(trx)));
  }
}
