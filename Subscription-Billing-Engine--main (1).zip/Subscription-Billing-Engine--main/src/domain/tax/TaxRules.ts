export type TaxJurisdictionCode = 'US' | 'US-CA' | 'US-NY' | 'EU-DE' | 'EU-FR' | 'GB' | 'CA';

export interface TaxRule {
  jurisdiction: TaxJurisdictionCode;
  rateBps: number;
  inclusive: boolean;
  description: string;
}

const RULES: TaxRule[] = [
  { jurisdiction: 'US', rateBps: 0, inclusive: false, description: 'US default (varies by state)' },
  { jurisdiction: 'US-CA', rateBps: 725, inclusive: false, description: 'California sales tax approx' },
  { jurisdiction: 'US-NY', rateBps: 800, inclusive: false, description: 'New York sales tax approx' },
  { jurisdiction: 'EU-DE', rateBps: 1900, inclusive: true, description: 'Germany VAT' },
  { jurisdiction: 'EU-FR', rateBps: 2000, inclusive: true, description: 'France VAT' },
  { jurisdiction: 'GB', rateBps: 2000, inclusive: true, description: 'UK VAT' },
  { jurisdiction: 'CA', rateBps: 500, inclusive: false, description: 'Canada GST baseline' },
];

export function resolveJurisdiction(country: string, region?: string): TaxJurisdictionCode {
  const c = country.toUpperCase();
  if (c === 'US' && region) {
    const r = region.toUpperCase();
    if (r === 'CA' || r === 'CALIFORNIA') return 'US-CA';
    if (r === 'NY' || r === 'NEW YORK') return 'US-NY';
    return 'US';
  }
  if (c === 'DE') return 'EU-DE';
  if (c === 'FR') return 'EU-FR';
  if (c === 'GB' || c === 'UK') return 'GB';
  if (c === 'CA') return 'CA';
  return 'US';
}

export function calculateTaxCents(
  subtotalCents: number,
  jurisdiction: TaxJurisdictionCode
): { taxCents: number; rateBps: number; inclusive: boolean } {
  const rule = RULES.find((r) => r.jurisdiction === jurisdiction) ?? RULES[0];
  if (rule.inclusive) {
    const taxCents = Math.round((subtotalCents * rule.rateBps) / (10000 + rule.rateBps));
    return { taxCents, rateBps: rule.rateBps, inclusive: true };
  }
  const taxCents = Math.round((subtotalCents * rule.rateBps) / 10000);
  return { taxCents, rateBps: rule.rateBps, inclusive: false };
}

export function listTaxRules(): TaxRule[] {
  return [...RULES];
}
