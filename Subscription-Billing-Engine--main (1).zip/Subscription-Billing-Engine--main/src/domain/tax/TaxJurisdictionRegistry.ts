export interface JurisdictionRule {
  code: string;
  name: string;
  default_rate_bps: number;
  eu_vat: boolean;
  requires_vat_id: boolean;
}

const REGISTRY: JurisdictionRule[] = [
  { code: 'US', name: 'United States', default_rate_bps: 0, eu_vat: false, requires_vat_id: false },
  { code: 'DE', name: 'Germany', default_rate_bps: 1900, eu_vat: true, requires_vat_id: true },
  { code: 'FR', name: 'France', default_rate_bps: 2000, eu_vat: true, requires_vat_id: true },
  { code: 'GB', name: 'United Kingdom', default_rate_bps: 2000, eu_vat: false, requires_vat_id: true },
  { code: 'CA', name: 'Canada', default_rate_bps: 500, eu_vat: false, requires_vat_id: false },
  { code: 'AU', name: 'Australia', default_rate_bps: 1000, eu_vat: false, requires_vat_id: false },
  { code: 'JP', name: 'Japan', default_rate_bps: 1000, eu_vat: false, requires_vat_id: false },
  { code: 'IN', name: 'India', default_rate_bps: 1800, eu_vat: false, requires_vat_id: true },
  { code: 'BR', name: 'Brazil', default_rate_bps: 1700, eu_vat: false, requires_vat_id: true },
  { code: 'SG', name: 'Singapore', default_rate_bps: 800, eu_vat: false, requires_vat_id: false },
];

export class TaxJurisdictionRegistry {
  list(): JurisdictionRule[] {
    return [...REGISTRY];
  }

  get(countryCode: string): JurisdictionRule | undefined {
    return REGISTRY.find((r) => r.code === countryCode.toUpperCase());
  }

  isEu(countryCode: string): boolean {
    return Boolean(this.get(countryCode)?.eu_vat);
  }

  defaultRateBps(countryCode: string): number {
    return this.get(countryCode)?.default_rate_bps ?? 0;
  }

  validateVatRequirement(countryCode: string, vatId?: string): { valid: boolean; reason?: string } {
    const rule = this.get(countryCode);
    if (!rule) return { valid: true };
    if (rule.requires_vat_id && !vatId) {
      return { valid: false, reason: `VAT ID required for ${rule.name}` };
    }
    return { valid: true };
  }

  reverseChargeApplies(sellerCountry: string, buyerCountry: string, buyerVatId?: string): boolean {
    if (!this.isEu(sellerCountry) || !this.isEu(buyerCountry)) return false;
    if (sellerCountry === buyerCountry) return false;
    return Boolean(buyerVatId);
  }
}

export const taxJurisdictions = new TaxJurisdictionRegistry();
