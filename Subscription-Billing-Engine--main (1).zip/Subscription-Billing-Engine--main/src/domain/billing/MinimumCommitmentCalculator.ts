export interface CommitmentTier {
  name: string;
  minimum_mrr_cents: number;
  overage_unit_cents: number;
}

export interface CommitmentInput {
  actual_mrr_cents: number;
  usage_overage_units: number;
  tier: CommitmentTier;
}

export interface CommitmentResult {
  shortfall_cents: number;
  overage_cents: number;
  true_up_cents: number;
  tier_name: string;
}

/**
 * Computes true-up invoices when contracted minimum MRR is not met.
 */
export class MinimumCommitmentCalculator {
  compute(input: CommitmentInput): CommitmentResult {
    const shortfall = Math.max(0, input.tier.minimum_mrr_cents - input.actual_mrr_cents);
    const overage = Math.round(input.usage_overage_units * input.tier.overage_unit_cents);
    return {
      shortfall_cents: shortfall,
      overage_cents: overage,
      true_up_cents: shortfall + overage,
      tier_name: input.tier.name,
    };
  }

  selectTier(actualMrrCents: number, tiers: CommitmentTier[]): CommitmentTier {
    const sorted = [...tiers].sort((a, b) => b.minimum_mrr_cents - a.minimum_mrr_cents);
    const match = sorted.find((t) => actualMrrCents >= t.minimum_mrr_cents);
    return match ?? sorted[sorted.length - 1];
  }

  projectAnnualTrueUp(monthlyResults: CommitmentResult[]): number {
    return monthlyResults.reduce((s, r) => s + r.true_up_cents, 0);
  }
}

export const defaultCommitmentTiers: CommitmentTier[] = [
  { name: 'starter', minimum_mrr_cents: 0, overage_unit_cents: 10 },
  { name: 'growth', minimum_mrr_cents: 100_000, overage_unit_cents: 8 },
  { name: 'enterprise', minimum_mrr_cents: 500_000, overage_unit_cents: 5 },
];
