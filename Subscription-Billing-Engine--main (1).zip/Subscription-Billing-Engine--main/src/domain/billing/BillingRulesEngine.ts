/**
 * Pure billing rules for line items, discounts, tax stacking, and minimum charges.
 * Used by invoice generation and quote conversion paths.
 */

export interface LineItemInput {
  description: string;
  quantity: number;
  unit_amount_cents: number;
  metadata?: Record<string, unknown>;
}

export interface DiscountInput {
  type: 'percent' | 'fixed';
  value: number;
  recurring: boolean;
  max_discount_cents?: number;
}

export interface TaxInput {
  rate_bps: number;
  inclusive: boolean;
}

export interface BillingRulesResult {
  line_items: Array<LineItemInput & { amount_cents: number }>;
  subtotal_cents: number;
  discount_cents: number;
  tax_cents: number;
  total_cents: number;
  minimum_charge_applied: boolean;
}

export class BillingRulesEngine {
  constructor(private readonly minimumInvoiceCents = 50) {}

  computeLineAmount(quantity: number, unitCents: number): number {
    if (quantity <= 0) return 0;
    if (unitCents < 0) throw new Error('Unit amount cannot be negative');
    return Math.round(quantity * unitCents);
  }

  sumSubtotal(lines: LineItemInput[]): number {
    return lines.reduce(
      (sum, line) => sum + this.computeLineAmount(line.quantity, line.unit_amount_cents),
      0
    );
  }

  applyPercentDiscount(subtotalCents: number, percent: number, cap?: number): number {
    if (percent <= 0) return 0;
    if (percent > 100) throw new Error('Percent discount cannot exceed 100');
    let discount = Math.round((subtotalCents * percent) / 100);
    if (cap !== undefined && discount > cap) discount = cap;
    return Math.min(discount, subtotalCents);
  }

  applyFixedDiscount(subtotalCents: number, fixedCents: number): number {
    if (fixedCents <= 0) return 0;
    return Math.min(fixedCents, subtotalCents);
  }

  resolveDiscount(subtotalCents: number, discount?: DiscountInput): number {
    if (!discount || subtotalCents <= 0) return 0;
    if (discount.type === 'percent') {
      return this.applyPercentDiscount(subtotalCents, discount.value, discount.max_discount_cents);
    }
    return this.applyFixedDiscount(subtotalCents, discount.value);
  }

  computeTax(taxableCents: number, tax?: TaxInput): number {
    if (!tax || taxableCents <= 0) return 0;
    if (tax.inclusive) {
      return Math.round((taxableCents * tax.rate_bps) / (10000 + tax.rate_bps));
    }
    return Math.round((taxableCents * tax.rate_bps) / 10000);
  }

  applyMinimumCharge(totalBeforeMin: number): { total: number; applied: boolean } {
    if (totalBeforeMin === 0) return { total: 0, applied: false };
    if (totalBeforeMin < this.minimumInvoiceCents) {
      return { total: this.minimumInvoiceCents, applied: true };
    }
    return { total: totalBeforeMin, applied: false };
  }

  calculate(
    lines: LineItemInput[],
    discount?: DiscountInput,
    tax?: TaxInput
  ): BillingRulesResult {
    const enriched = lines.map((line) => ({
      ...line,
      amount_cents: this.computeLineAmount(line.quantity, line.unit_amount_cents),
    }));
    const subtotal = enriched.reduce((s, l) => s + l.amount_cents, 0);
    const discountCents = this.resolveDiscount(subtotal, discount);
    const afterDiscount = Math.max(0, subtotal - discountCents);
    const taxCents = this.computeTax(afterDiscount, tax);
    const totalBeforeMin = tax?.inclusive ? afterDiscount : afterDiscount + taxCents;
    const { total, applied } = this.applyMinimumCharge(totalBeforeMin);
    return {
      line_items: enriched,
      subtotal_cents: subtotal,
      discount_cents: discountCents,
      tax_cents: taxCents,
      total_cents: total,
      minimum_charge_applied: applied,
    };
  }

  mergeAddonLines(
    baseLines: LineItemInput[],
    addonLines: LineItemInput[]
  ): LineItemInput[] {
    return [...baseLines, ...addonLines.filter((a) => a.quantity > 0)];
  }

  prorateLineAmount(
    fullPeriodAmountCents: number,
    periodStart: Date,
    periodEnd: Date,
    effectiveStart: Date,
    effectiveEnd: Date
  ): number {
    const periodMs = periodEnd.getTime() - periodStart.getTime();
    if (periodMs <= 0) return 0;
    const start = Math.max(effectiveStart.getTime(), periodStart.getTime());
    const end = Math.min(effectiveEnd.getTime(), periodEnd.getTime());
    const usedMs = Math.max(0, end - start);
    return Math.round((fullPeriodAmountCents * usedMs) / periodMs);
  }

  tieredUsageCharge(
    quantity: number,
    tiers: Array<{ up_to: number | null; unit_cents: number }>
  ): number {
    let remaining = quantity;
    let total = 0;
    let prevCap = 0;
    for (const tier of tiers) {
      const cap = tier.up_to ?? Infinity;
      const span = Math.min(remaining, cap - prevCap);
      if (span <= 0) break;
      total += Math.round(span * tier.unit_cents);
      remaining -= span;
      prevCap = cap;
      if (remaining <= 0) break;
    }
    return total;
  }
}

export const defaultBillingRules = new BillingRulesEngine();
