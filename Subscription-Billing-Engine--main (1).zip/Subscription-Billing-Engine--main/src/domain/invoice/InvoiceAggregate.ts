import { AggregateRoot, DomainError } from '../shared/AggregateRoot';

export type InvoiceStatus = 'draft' | 'open' | 'paid' | 'void' | 'past_due';

export interface InvoiceLine {
  description: string;
  quantity: number;
  unit_amount_cents: number;
  amount_cents: number;
}

export interface InvoiceAggregateState {
  id: string;
  subscriptionId: string;
  status: InvoiceStatus;
  subtotal_cents: number;
  tax_cents: number;
  discount_cents: number;
  total_cents: number;
  lines: InvoiceLine[];
}

export class InvoiceAggregate extends AggregateRoot {
  private state: InvoiceAggregateState;

  constructor(state: InvoiceAggregateState) {
    super(state.id);
    this.state = { ...state, lines: [...state.lines] };
  }

  static draft(id: string, subscriptionId: string, lines: InvoiceLine[]): InvoiceAggregate {
    const subtotal = lines.reduce((s, l) => s + l.amount_cents, 0);
    const agg = new InvoiceAggregate({
      id,
      subscriptionId,
      status: 'draft',
      subtotal_cents: subtotal,
      tax_cents: 0,
      discount_cents: 0,
      total_cents: subtotal,
      lines,
    });
    agg.recordEvent('invoice.drafted', { invoice_id: id });
    return agg;
  }

  get snapshot(): InvoiceAggregateState {
    return { ...this.state, lines: [...this.state.lines] };
  }

  applyTax(taxCents: number): void {
    if (this.state.status !== 'draft' && this.state.status !== 'open') {
      throw new DomainError('Cannot tax finalized invoice', 'INVALID_STATE');
    }
    this.state.tax_cents = taxCents;
    this.recalculateTotal();
    this.recordEvent('invoice.tax_applied', { invoice_id: this.state.id, tax_cents: taxCents });
  }

  applyDiscount(discountCents: number): void {
    if (discountCents > this.state.subtotal_cents) {
      throw new DomainError('Discount exceeds subtotal', 'INVALID_DISCOUNT');
    }
    this.state.discount_cents = discountCents;
    this.recalculateTotal();
  }

  private recalculateTotal(): void {
    const afterDiscount = this.state.subtotal_cents - this.state.discount_cents;
    this.state.total_cents = afterDiscount + this.state.tax_cents;
  }

  markOpen(): void {
    if (this.state.status !== 'draft') {
      throw new DomainError('Only draft invoices can open', 'INVALID_STATE');
    }
    this.state.status = 'open';
    this.recordEvent('invoice.opened', { invoice_id: this.state.id });
  }

  markPaid(): void {
    if (this.state.status === 'void') {
      throw new DomainError('Cannot pay void invoice', 'INVALID_STATE');
    }
    if (this.state.status === 'paid') {
      throw new DomainError('Invoice already paid', 'INVALID_STATE');
    }
    this.state.status = 'paid';
    this.recordEvent('invoice.paid', { invoice_id: this.state.id, total_cents: this.state.total_cents });
  }

  voidInvoice(reason: string): void {
    if (this.state.status === 'paid') {
      throw new DomainError('Cannot void paid invoice', 'INVALID_STATE');
    }
    this.state.status = 'void';
    this.recordEvent('invoice.voided', { invoice_id: this.state.id, reason });
  }
}
