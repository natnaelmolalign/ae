export type InvoiceState = 'draft' | 'open' | 'paid' | 'void' | 'uncollectible';

const TRANSITIONS: Record<InvoiceState, Partial<Record<string, InvoiceState>>> = {
  draft: { finalize: 'open', void: 'void' },
  open: { pay: 'paid', void: 'void', mark_uncollectible: 'uncollectible' },
  paid: { void: 'void' },
  void: {},
  uncollectible: { pay: 'paid', void: 'void' },
};

export class InvoiceStateMachine {
  constructor(private state: InvoiceState) {}

  current(): InvoiceState {
    return this.state;
  }

  can(trigger: string): boolean {
    return Boolean(TRANSITIONS[this.state][trigger]);
  }

  trigger(action: string): InvoiceState {
    const next = TRANSITIONS[this.state][action];
    if (!next) {
      throw new Error(`Invalid transition ${this.state} -> ${action}`);
    }
    this.state = next;
    return this.state;
  }

  static allowedTriggers(state: InvoiceState): string[] {
    return Object.keys(TRANSITIONS[state]);
  }

  static isTerminal(state: InvoiceState): boolean {
    return state === 'void' || state === 'uncollectible';
  }

  static describe(state: InvoiceState): string {
    const descriptions: Record<InvoiceState, string> = {
      draft: 'Invoice created but not yet sent to customer',
      open: 'Awaiting payment',
      paid: 'Settled in full',
      void: 'Cancelled; no longer collectible',
      uncollectible: 'Written off after failed collection',
    };
    return descriptions[state];
  }
}
