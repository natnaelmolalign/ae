export type SubscriptionState =
  | 'trial'
  | 'active'
  | 'past_due'
  | 'cancelled'
  | 'paused';

const TRANSITIONS: Record<SubscriptionState, Partial<Record<string, SubscriptionState>>> = {
  trial: { convert: 'active', cancel: 'cancelled' },
  active: { payment_failed: 'past_due', pause: 'paused', cancel: 'cancelled' },
  past_due: { payment_succeeded: 'active', cancel: 'cancelled' },
  paused: { resume: 'active', cancel: 'cancelled' },
  cancelled: {},
};

export class SubscriptionStateMachine {
  constructor(private state: SubscriptionState) {}

  current(): SubscriptionState {
    return this.state;
  }

  can(trigger: string): boolean {
    return Boolean(TRANSITIONS[this.state][trigger]);
  }

  trigger(action: string): SubscriptionState {
    const next = TRANSITIONS[this.state][action];
    if (!next) throw new Error(`Invalid subscription transition ${this.state} -> ${action}`);
    this.state = next;
    return this.state;
  }

  static allowedTriggers(state: SubscriptionState): string[] {
    return Object.keys(TRANSITIONS[state]);
  }

  static billable(state: SubscriptionState): boolean {
    return state === 'active' || state === 'past_due' || state === 'trial';
  }
}
