import { ALLOWED_TRANSITIONS, type SubscriptionStatus } from '../../models/Subscription';
import { AggregateRoot, DomainError } from '../shared/AggregateRoot';

export interface SubscriptionAggregateState {
  id: string;
  customerId: string;
  planId: string;
  status: SubscriptionStatus;
  trialEndsAt: Date | null;
  currentPeriodStart: Date;
  currentPeriodEnd: Date;
  failedPaymentCount: number;
}

export class SubscriptionAggregate extends AggregateRoot {
  private state: SubscriptionAggregateState;

  constructor(state: SubscriptionAggregateState) {
    super(state.id);
    this.state = { ...state };
  }

  static create(params: Omit<SubscriptionAggregateState, 'status' | 'failedPaymentCount'> & { status?: SubscriptionStatus }) {
    const agg = new SubscriptionAggregate({
      ...params,
      status: params.status ?? 'trial',
      failedPaymentCount: 0,
    });
    agg.recordEvent('subscription.created', { subscription_id: params.id });
    return agg;
  }

  get snapshot(): SubscriptionAggregateState {
    return { ...this.state };
  }

  transition(target: SubscriptionStatus, reason: string): void {
    const allowed = ALLOWED_TRANSITIONS[this.state.status] ?? [];
    if (!allowed.includes(target)) {
      throw new DomainError(
        `Cannot transition from ${this.state.status} to ${target}`,
        'INVALID_TRANSITION'
      );
    }
    const from = this.state.status;
    this.state.status = target;
    this.recordEvent('subscription.status_changed', {
      subscription_id: this.state.id,
      from,
      to: target,
      reason,
    });
    if (target === 'cancelled') {
      this.recordEvent('subscription.cancelled', { subscription_id: this.state.id, reason });
    }
  }

  recordFailedPayment(): void {
    this.state.failedPaymentCount += 1;
    if (this.state.status === 'active') {
      this.transition('past_due', 'payment_failed');
    }
    this.recordEvent('subscription.payment_failed', {
      subscription_id: this.state.id,
      count: this.state.failedPaymentCount,
    });
  }

  recoverFromPastDue(): void {
    if (this.state.status !== 'past_due') {
      throw new DomainError('Subscription is not past due', 'INVALID_STATE');
    }
    this.state.failedPaymentCount = 0;
    this.transition('active', 'payment_recovered');
  }

  changePlan(planId: string, periodStart: Date, periodEnd: Date): void {
    this.state.planId = planId;
    this.state.currentPeriodStart = periodStart;
    this.state.currentPeriodEnd = periodEnd;
    this.recordEvent('subscription.plan_changed', {
      subscription_id: this.state.id,
      plan_id: planId,
    });
  }
}
