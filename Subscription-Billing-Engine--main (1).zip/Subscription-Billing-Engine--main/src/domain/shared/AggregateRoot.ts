export abstract class AggregateRoot<TId extends string = string> {
  protected _version = 0;
  private _events: Array<{ type: string; payload: Record<string, unknown> }> = [];

  constructor(protected readonly id: TId) {}

  get version(): number {
    return this._version;
  }

  protected recordEvent(type: string, payload: Record<string, unknown>): void {
    this._events.push({ type, payload });
    this._version += 1;
  }

  pullEvents(): Array<{ type: string; payload: Record<string, unknown> }> {
    const events = [...this._events];
    this._events = [];
    return events;
  }
}

export class DomainError extends Error {
  constructor(
    message: string,
    public readonly code: string
  ) {
    super(message);
    this.name = 'DomainError';
  }
}
