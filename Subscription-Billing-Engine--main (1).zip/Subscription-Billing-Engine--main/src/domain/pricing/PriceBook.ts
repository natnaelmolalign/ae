export interface PriceTier {
  up_to: number | null;
  unit_cents: number;
  flat_cents?: number;
}

export interface PriceComponent {
  sku: string;
  description: string;
  tiers: PriceTier[];
  currency: string;
}

/**
 * Catalog of list prices used before discounts and tax.
 */
export class PriceBook {
  private readonly components = new Map<string, PriceComponent>();

  register(component: PriceComponent): void {
    this.components.set(component.sku, component);
  }

  get(sku: string): PriceComponent | undefined {
    return this.components.get(sku);
  }

  list(): PriceComponent[] {
    return [...this.components.values()];
  }

  unitPriceForQuantity(sku: string, quantity: number): number {
    const comp = this.components.get(sku);
    if (!comp) throw new Error(`Unknown SKU ${sku}`);
    let remaining = quantity;
    let total = 0;
    for (const tier of comp.tiers) {
      if (remaining <= 0) break;
      const cap = tier.up_to == null ? remaining : Math.min(remaining, tier.up_to);
      total += cap * tier.unit_cents + (tier.flat_cents ?? 0);
      remaining -= cap;
    }
    return total;
  }

  static defaultSaas(): PriceBook {
    const book = new PriceBook();
    book.register({
      sku: 'seat',
      description: 'Per-seat license',
      currency: 'USD',
      tiers: [
        { up_to: 10, unit_cents: 1200 },
        { up_to: 50, unit_cents: 1000 },
        { up_to: null, unit_cents: 800 },
      ],
    });
    book.register({
      sku: 'api_call',
      description: 'Metered API calls',
      currency: 'USD',
      tiers: [
        { up_to: 10_000, unit_cents: 0 },
        { up_to: 100_000, unit_cents: 1 },
        { up_to: null, unit_cents: 0.5 },
      ],
    });
    return book;
  }
}
