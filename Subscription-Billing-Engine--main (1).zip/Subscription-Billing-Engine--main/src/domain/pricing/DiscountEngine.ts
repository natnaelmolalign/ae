export type DiscountType = 'percent' | 'fixed' | 'tiered_percent';

export interface DiscountRule {
  code: string;
  type: DiscountType;
  value: number;
  max_discount_cents?: number;
  min_subtotal_cents?: number;
  stackable?: boolean;
}

export interface DiscountLine {
  code: string;
  amount_cents: number;
}

export class DiscountEngine {
  constructor(private readonly rules: DiscountRule[] = []) {}

  apply(subtotalCents: number, codes: string[]): { total: number; lines: DiscountLine[] } {
    const applicable = this.rules.filter((r) => codes.includes(r.code));
    let remaining = subtotalCents;
    const lines: DiscountLine[] = [];

    for (const rule of applicable) {
      if (rule.min_subtotal_cents && remaining < rule.min_subtotal_cents) continue;
      let amount = 0;
      if (rule.type === 'percent') {
        amount = Math.round((remaining * rule.value) / 100);
      } else if (rule.type === 'fixed') {
        amount = rule.value;
      } else if (rule.type === 'tiered_percent') {
        const tierPct = remaining > 100_000 ? rule.value : rule.value / 2;
        amount = Math.round((remaining * tierPct) / 100);
      }
      if (rule.max_discount_cents) amount = Math.min(amount, rule.max_discount_cents);
      amount = Math.min(amount, remaining);
      if (amount <= 0) continue;
      lines.push({ code: rule.code, amount_cents: amount });
      remaining -= amount;
      if (!rule.stackable) break;
    }

    return { total: remaining, lines };
  }

  static standardPromos(): DiscountEngine {
    return new DiscountEngine([
      { code: 'LAUNCH20', type: 'percent', value: 20, max_discount_cents: 50_000 },
      { code: 'LOYALTY', type: 'tiered_percent', value: 10, min_subtotal_cents: 5000, stackable: true },
      { code: 'CREDIT50', type: 'fixed', value: 5000 },
    ]);
  }
}
