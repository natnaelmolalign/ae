import type { PriceTier } from './PriceBook';

export interface UsageRecord {
  meter: string;
  quantity: number;
  period_start: string;
  period_end: string;
}

export interface RatedUsageLine {
  meter: string;
  quantity: number;
  amount_cents: number;
  breakdown: { tier_index: number; quantity: number; unit_cents: number }[];
}

/**
 * Rates metered usage against tier tables (same semantics as BillingRulesEngine).
 */
export class UsageRatingEngine {
  rate(meter: string, quantity: number, tiers: PriceTier[]): RatedUsageLine {
    let remaining = quantity;
    let amount = 0;
    const breakdown: RatedUsageLine['breakdown'] = [];
    tiers.forEach((tier, index) => {
      if (remaining <= 0) return;
      const cap = tier.up_to == null ? remaining : Math.min(remaining, tier.up_to);
      const lineAmount = Math.round(cap * tier.unit_cents + (tier.flat_cents ?? 0));
      amount += lineAmount;
      breakdown.push({ tier_index: index, quantity: cap, unit_cents: tier.unit_cents });
      remaining -= cap;
    });
    return { meter, quantity, amount_cents: amount, breakdown };
  }

  rateBatch(records: UsageRecord[], tierMap: Record<string, PriceTier[]>): RatedUsageLine[] {
    return records.map((r) => {
      const tiers = tierMap[r.meter];
      if (!tiers) throw new Error(`No tiers for meter ${r.meter}`);
      return this.rate(r.meter, r.quantity, tiers);
    });
  }
}
