import { BillingForecastService } from '../services/BillingForecastService';
import { getDb } from '../config/database';
import { globalMetrics } from '../lib/metrics';

export async function runForecastJob(asOf?: string): Promise<number> {
  const date = asOf ?? new Date().toISOString().slice(0, 10);
  const forecast = await new BillingForecastService().runDefaultScenario(date, 12);
  await getDb()('application_metrics').insert({
    name: 'forecast.mrr_month_12',
    value: forecast[forecast.length - 1]?.projected_mrr_cents ?? 0,
    labels: JSON.stringify({ as_of: date }),
  });
  globalMetrics.increment('forecast_months', { as_of: date }, forecast.length);
  return forecast.length;
}
