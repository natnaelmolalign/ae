import { getDb } from '../config/database';
import { JobLockService } from '../services/JobLockService';
import { CustomerService } from '../services/CustomerService';
import { InvoiceService } from '../services/InvoiceService';
import { SubscriptionService } from '../services/SubscriptionService';
import { parseDate } from '../utils/dateUtils';

async function runBillingJobInner(asOf = new Date()): Promise<number> {
  const subscriptionService = new SubscriptionService();
  const invoiceService = new InvoiceService();
  const customerService = new CustomerService();

  await subscriptionService.activateEndedTrials(asOf);

  const subs = await getDb()('subscriptions').whereIn('status', ['active', 'past_due']);

  let generated = 0;

  for (const sub of subs) {
    if (parseDate(sub.current_period_start) > asOf) continue;

    const renewed = await subscriptionService.renewIfDue(sub.id, asOf);
    const current = renewed || sub;
    const customer = await customerService.getById(current.customer_id);

    const existing = await getDb()('invoices')
      .where({ subscription_id: current.id })
      .andWhere('issued_at', '>=', current.current_period_start)
      .whereNot('status', 'void')
      .first();

    if (!existing) {
      await invoiceService.generateForSubscription(current, customer.country);
      generated += 1;
    }
  }

  await subscriptionService.expireDue(asOf);
  return generated;
}

export async function runBillingJob(asOf = new Date()): Promise<number> {
  const outcome = await new JobLockService().runExclusive('billing', () =>
    runBillingJobInner(asOf)
  );
  if (outcome.skipped) return 0;
  return outcome.result ?? 0;
}
