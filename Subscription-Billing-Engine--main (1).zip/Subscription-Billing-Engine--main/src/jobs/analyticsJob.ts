import { AnalyticsRollupService } from '../services/AnalyticsRollupService';
import { JobLockService } from '../services/JobLockService';
import { RevenueRecognitionService } from '../services/RevenueRecognitionService';

export async function runAnalyticsJob(asOf = new Date(), daysBack = 1): Promise<number> {
  const outcome = await new JobLockService().runExclusive('analytics', async () => {
    await new RevenueRecognitionService().recognizeDue(asOf);
    return new AnalyticsRollupService().rollupRange(asOf, daysBack);
  });
  if (outcome.skipped) return 0;
  return outcome.result ?? 0;
}
