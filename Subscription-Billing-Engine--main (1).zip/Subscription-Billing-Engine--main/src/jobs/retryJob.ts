import { JobLockService } from '../services/JobLockService';
import { RetryService } from '../services/RetryService';

export async function runRetryJob(asOf = new Date()): Promise<number> {
  const outcome = await new JobLockService().runExclusive('retry', () =>
    new RetryService().processDueRetries(asOf)
  );
  if (outcome.skipped) return 0;
  return outcome.result ?? 0;
}
