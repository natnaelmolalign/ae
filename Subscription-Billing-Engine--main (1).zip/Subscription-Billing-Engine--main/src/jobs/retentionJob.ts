import { RetentionPolicyService } from '../services/RetentionPolicyService';

export async function runRetentionJob(asOf = new Date()): Promise<Record<string, number>> {
  const service = new RetentionPolicyService();
  await service.seedDefaults();
  return service.runAllEnabled(asOf);
}
