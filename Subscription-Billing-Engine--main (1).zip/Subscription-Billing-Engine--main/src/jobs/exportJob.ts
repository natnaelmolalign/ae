import { DataExportService } from '../services/DataExportService';
import { getDb } from '../config/database';

export async function runExportJob(limit = 10): Promise<number> {
  const pending = await getDb()('data_export_requests')
    .where({ status: 'pending' })
    .orderBy('created_at', 'asc')
    .limit(limit);
  const svc = new DataExportService();
  let done = 0;
  for (const row of pending) {
    await svc.process(row.id as string);
    done += 1;
  }
  return done;
}
