import { z } from 'zod';

export const uuidParam = z.string().uuid();

export const createPlanSchema = z.object({
  name: z.string().min(1).max(128),
  price_cents: z.number().int().nonnegative(),
  interval: z.enum(['monthly', 'yearly']),
  features: z.array(z.string()).optional(),
});

export const createCustomerSchema = z.object({
  email: z.string().email().max(255),
  name: z.string().min(1).max(255),
  country: z.string().length(2).optional(),
});

export const createSubscriptionSchema = z.object({
  customer_id: uuidParam,
  plan_id: uuidParam,
  billing_anchor: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  trial_days: z.number().int().positive().optional(),
  coupon_code: z.string().max(64).optional(),
});

export const chargeSchema = z.object({
  invoice_id: uuidParam,
  simulate_success: z.boolean().optional(),
});

export const refundSchema = z.object({
  amount_cents: z.number().int().positive(),
});

export const changePlanSchema = z.object({
  plan_id: uuidParam,
  change_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
});

export const createCouponSchema = z.object({
  code: z.string().min(2).max(64),
  discount_type: z.enum(['percent', 'fixed']),
  discount_value: z.number().int().positive(),
  recurring: z.boolean().optional(),
  expires_at: z.string().datetime().optional(),
  usage_limit: z.number().int().positive().optional(),
  plan_ids: z.array(uuidParam).optional(),
});

export const paginationSchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
});

export const createMeterSchema = z.object({
  code: z.string().min(2).max(64),
  name: z.string().min(1).max(128),
  aggregation: z.enum(['sum', 'max']).optional(),
  tier_config: z.array(
    z.object({
      up_to: z.number().nullable(),
      unit_price_cents: z.number().int().nonnegative(),
    })
  ),
});

export const recordUsageSchema = z.object({
  subscription_id: uuidParam,
  quantity: z.number().positive(),
  recorded_at: z.string().datetime().optional(),
  idempotency_key: z.string().max(128).optional(),
});

export const upsertEntitlementsSchema = z.object({
  entitlements: z.array(
    z.object({
      feature_key: z.string().min(1).max(128),
      limit_type: z.enum(['boolean', 'count', 'unlimited']),
      limit_value: z.number().int().nonnegative().nullable().optional(),
      reset_interval: z.string().max(32).nullable().optional(),
    })
  ),
});

export const entitlementCheckSchema = z.object({
  subscription_id: uuidParam,
  feature_key: z.string().min(1).max(128),
});

export const createCreditNoteSchema = z.object({
  invoice_id: uuidParam,
  amount_cents: z.number().int().positive(),
  reason: z.string().min(1).max(255),
});

export const createAddonSchema = z.object({
  code: z.string().min(2).max(64),
  name: z.string().min(1).max(128),
  price_cents: z.number().int().nonnegative(),
});

export const addSubscriptionAddonSchema = z.object({
  addon_code: z.string().min(2).max(64),
  quantity: z.number().int().positive().default(1),
});

export const changeItemQuantitySchema = z.object({
  quantity: z.number().int().positive(),
  change_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
});

export const createQuoteSchema = z.object({
  customer_id: uuidParam,
  expires_at: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  lines: z.array(
    z.object({
      description: z.string().min(1).max(255),
      quantity: z.number().int().positive(),
      unit_price_cents: z.number().int().nonnegative(),
      plan_id: uuidParam.optional(),
    })
  ),
});
