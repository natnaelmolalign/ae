import config from './src/config/knexConfig';
export default config;
