import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('dunning_policies', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('name', 128).notNullable();
    t.boolean('is_default').notNullable().defaultTo(false);
    t.jsonb('stages').notNullable();
    t.timestamps(true, true);
  });

  await knex.schema.alterTable('plans', (t) => {
    t.uuid('dunning_policy_id').nullable().references('id').inTable('dunning_policies');
  });

  await knex.schema.createTable('credit_notes', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('customer_id').notNullable().references('id').inTable('customers');
    t.uuid('invoice_id').notNullable().references('id').inTable('invoices');
    t.integer('amount_cents').notNullable();
    t.string('reason', 255).notNullable();
    t.enum('status', ['issued', 'applied', 'void']).notNullable().defaultTo('issued');
    t.timestamp('issued_at', { useTz: true }).notNullable();
    t.timestamps(true, true);
    t.index(['customer_id', 'issued_at']);
  });

  await knex('dunning_policies').insert({
    name: 'Standard 3-5-7',
    is_default: true,
    stages: JSON.stringify([
      { type: 'retry', delay_days: 3 },
      { type: 'retry', delay_days: 5 },
      { type: 'retry', delay_days: 7 },
      { type: 'cancel', delay_days: 0 },
    ]),
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('credit_notes');
  await knex.schema.alterTable('plans', (t) => {
    t.dropColumn('dunning_policy_id');
  });
  await knex.schema.dropTableIfExists('dunning_policies');
}
