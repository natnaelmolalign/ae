import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('idempotency_keys', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('key', 128).notNullable();
    t.string('route', 128).notNullable();
    t.integer('response_status').notNullable();
    t.jsonb('response_body').notNullable();
    t.timestamp('expires_at', { useTz: true }).notNullable();
    t.timestamps(true, true);
    t.unique(['key', 'route']);
    t.index(['expires_at']);
  });

  await knex.schema.alterTable('payments', (t) => {
    t.string('idempotency_key', 128).nullable();
    t.unique(['invoice_id', 'idempotency_key']);
  });

  await knex.schema.alterTable('webhook_events', (t) => {
    t.integer('attempt_count').notNullable().defaultTo(0);
    t.timestamp('next_retry_at', { useTz: true }).nullable();
    t.text('last_error').nullable();
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('webhook_events', (t) => {
    t.dropColumn('last_error');
    t.dropColumn('next_retry_at');
    t.dropColumn('attempt_count');
  });
  await knex.schema.alterTable('payments', (t) => {
    t.dropUnique(['invoice_id', 'idempotency_key']);
    t.dropColumn('idempotency_key');
  });
  await knex.schema.dropTableIfExists('idempotency_keys');
}
