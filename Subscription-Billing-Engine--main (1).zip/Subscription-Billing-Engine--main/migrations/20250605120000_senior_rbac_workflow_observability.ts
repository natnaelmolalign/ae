import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('permissions', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('resource', 64).notNullable();
    t.string('action', 32).notNullable();
    t.text('description');
    t.unique(['resource', 'action']);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('roles', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('name', 64).notNullable().unique();
    t.text('description');
    t.boolean('system_role').notNullable().defaultTo(false);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('role_permissions', (t) => {
    t.uuid('role_id').notNullable().references('id').inTable('roles').onDelete('CASCADE');
    t.uuid('permission_id').notNullable().references('id').inTable('permissions').onDelete('CASCADE');
    t.primary(['role_id', 'permission_id']);
  });

  await knex.schema.createTable('api_principals', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('name', 128).notNullable();
    t.string('api_key_hash', 128).notNullable().unique();
    t.boolean('active').notNullable().defaultTo(true);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('principal_roles', (t) => {
    t.uuid('principal_id').notNullable().references('id').inTable('api_principals').onDelete('CASCADE');
    t.uuid('role_id').notNullable().references('id').inTable('roles').onDelete('CASCADE');
    t.primary(['principal_id', 'role_id']);
  });

  await knex.schema.createTable('workflow_definitions', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('name', 64).notNullable().unique();
    t.string('entity_type', 64).notNullable();
    t.jsonb('states').notNullable();
    t.jsonb('transitions').notNullable();
    t.integer('version').notNullable().defaultTo(1);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('workflow_instances', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('definition_id').notNullable().references('id').inTable('workflow_definitions');
    t.string('entity_type', 64).notNullable();
    t.uuid('entity_id').notNullable();
    t.string('current_state', 64).notNullable();
    t.jsonb('context').notNullable().defaultTo('{}');
    t.timestamp('completed_at');
    t.timestamps(true, true);
    t.index(['entity_type', 'entity_id']);
  });

  await knex.schema.createTable('workflow_history', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('instance_id').notNullable().references('id').inTable('workflow_instances').onDelete('CASCADE');
    t.string('from_state', 64);
    t.string('to_state', 64).notNullable();
    t.string('trigger', 64).notNullable();
    t.uuid('actor_principal_id');
    t.timestamp('created_at').notNullable().defaultTo(knex.fn.now());
  });

  await knex.schema.createTable('feature_flags', (t) => {
    t.string('key', 128).primary();
    t.boolean('enabled').notNullable().defaultTo(false);
    t.jsonb('rules').notNullable().defaultTo('{}');
    t.text('description');
    t.timestamps(true, true);
  });

  await knex.schema.createTable('retention_policies', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('entity_type', 64).notNullable();
    t.integer('retain_days').notNullable();
    t.boolean('purge_enabled').notNullable().defaultTo(true);
    t.timestamps(true, true);
    t.unique(['entity_type']);
  });

  await knex.schema.createTable('purge_runs', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('entity_type', 64).notNullable();
    t.integer('rows_deleted').notNullable().defaultTo(0);
    t.timestamp('started_at').notNullable();
    t.timestamp('finished_at');
    t.string('status', 32).notNullable();
  });

  await knex.schema.createTable('application_metrics', (t) => {
    t.bigIncrements('id').primary();
    t.string('name', 128).notNullable();
    t.double('value').notNullable();
    t.jsonb('labels').notNullable().defaultTo('{}');
    t.timestamp('recorded_at').notNullable().defaultTo(knex.fn.now());
    t.index(['name', 'recorded_at']);
  });

  await knex.schema.createTable('saga_runs', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('saga_name', 64).notNullable();
    t.string('status', 32).notNullable();
    t.jsonb('steps').notNullable().defaultTo('[]');
    t.jsonb('context').notNullable().defaultTo('{}');
    t.timestamps(true, true);
  });

  await knex.schema.createTable('notification_queue', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('channel', 32).notNullable();
    t.string('template', 64).notNullable();
    t.string('recipient', 255).notNullable();
    t.jsonb('payload').notNullable().defaultTo('{}');
    t.string('status', 32).notNullable().defaultTo('pending');
    t.timestamp('sent_at');
    t.timestamps(true, true);
  });

  await knex.schema.createTable('billing_period_closes', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.date('period_start').notNullable();
    t.date('period_end').notNullable();
    t.string('status', 32).notNullable();
    t.integer('invoice_count').notNullable().defaultTo(0);
    t.bigInteger('total_cents').notNullable().defaultTo(0);
    t.timestamp('closed_at');
    t.timestamps(true, true);
    t.unique(['period_start', 'period_end']);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('notification_queue');
  await knex.schema.dropTableIfExists('saga_runs');
  await knex.schema.dropTableIfExists('billing_period_closes');
  await knex.schema.dropTableIfExists('application_metrics');
  await knex.schema.dropTableIfExists('purge_runs');
  await knex.schema.dropTableIfExists('retention_policies');
  await knex.schema.dropTableIfExists('feature_flags');
  await knex.schema.dropTableIfExists('workflow_history');
  await knex.schema.dropTableIfExists('workflow_instances');
  await knex.schema.dropTableIfExists('workflow_definitions');
  await knex.schema.dropTableIfExists('principal_roles');
  await knex.schema.dropTableIfExists('api_principals');
  await knex.schema.dropTableIfExists('role_permissions');
  await knex.schema.dropTableIfExists('roles');
  await knex.schema.dropTableIfExists('permissions');
}
