import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.raw('CREATE EXTENSION IF NOT EXISTS "pgcrypto"');

  await knex.schema.createTable('plans', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('name', 128).notNullable();
    t.integer('price_cents').notNullable();
    t.enum('interval', ['monthly', 'yearly']).notNullable();
    t.jsonb('features').notNullable().defaultTo('[]');
    t.boolean('active').notNullable().defaultTo(true);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('customers', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('email', 255).notNullable().unique();
    t.string('name', 255).notNullable();
    t.string('country', 2).notNullable().defaultTo('US');
    t.integer('credit_balance_cents').notNullable().defaultTo(0);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('coupons', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('code', 64).notNullable().unique();
    t.enum('discount_type', ['percent', 'fixed']).notNullable();
    t.integer('discount_value').notNullable();
    t.boolean('recurring').notNullable().defaultTo(false);
    t.timestamp('expires_at', { useTz: true }).nullable();
    t.integer('usage_limit').nullable();
    t.integer('usage_count').notNullable().defaultTo(0);
    t.jsonb('plan_ids').nullable();
    t.timestamps(true, true);
  });

  await knex.schema.createTable('subscriptions', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('customer_id').notNullable().references('id').inTable('customers').onDelete('CASCADE');
    t.uuid('plan_id').notNullable().references('id').inTable('plans');
    t.enum('status', ['trial', 'active', 'past_due', 'cancelled', 'expired']).notNullable();
    t.date('billing_anchor').notNullable();
    t.date('current_period_start').notNullable();
    t.date('current_period_end').notNullable();
    t.date('trial_end').nullable();
    t.date('cancelled_at').nullable();
    t.date('paused_at').nullable();
    t.integer('failed_payment_count').notNullable().defaultTo(0);
    t.uuid('coupon_id').nullable().references('id').inTable('coupons');
    t.timestamps(true, true);
    t.index(['customer_id', 'status']);
  });

  await knex.schema.createTable('billing_cycles', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('subscription_id').notNullable().references('id').inTable('subscriptions').onDelete('CASCADE');
    t.date('period_start').notNullable();
    t.date('period_end').notNullable();
    t.unique(['subscription_id', 'period_start']);
  });

  await knex.schema.createTable('invoices', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('subscription_id').notNullable().references('id').inTable('subscriptions');
    t.uuid('billing_cycle_id').nullable().references('id').inTable('billing_cycles');
    t.enum('status', ['pending', 'paid', 'void', 'uncollectible']).notNullable().defaultTo('pending');
    t.integer('subtotal_cents').notNullable().defaultTo(0);
    t.integer('tax_cents').notNullable().defaultTo(0);
    t.integer('discount_cents').notNullable().defaultTo(0);
    t.integer('credit_applied_cents').notNullable().defaultTo(0);
    t.integer('total_cents').notNullable().defaultTo(0);
    t.date('due_date').notNullable();
    t.date('issued_at').notNullable();
    t.string('currency', 3).notNullable().defaultTo('USD');
    t.timestamps(true, true);
  });

  await knex.schema.createTable('invoice_line_items', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('invoice_id').notNullable().references('id').inTable('invoices').onDelete('CASCADE');
    t.string('description', 255).notNullable();
    t.integer('amount_cents').notNullable();
    t.string('type', 32).notNullable();
  });

  await knex.schema.createTable('payments', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('invoice_id').notNullable().references('id').inTable('invoices');
    t.integer('amount_cents').notNullable();
    t.enum('status', ['succeeded', 'failed', 'refunded']).notNullable();
    t.timestamp('attempted_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.text('failure_reason').nullable();
  });

  await knex.schema.createTable('credits', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('customer_id').notNullable().references('id').inTable('customers');
    t.uuid('subscription_id').nullable().references('id').inTable('subscriptions');
    t.integer('amount_cents').notNullable();
    t.string('reason', 128).notNullable();
    t.uuid('invoice_id').nullable().references('id').inTable('invoices');
    t.boolean('applied').notNullable().defaultTo(false);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('payment_retries', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('subscription_id').notNullable().references('id').inTable('subscriptions').onDelete('CASCADE');
    t.uuid('invoice_id').notNullable().references('id').inTable('invoices');
    t.integer('attempt_number').notNullable();
    t.timestamp('scheduled_at', { useTz: true }).notNullable();
    t.timestamp('executed_at', { useTz: true }).nullable();
    t.enum('status', ['pending', 'completed', 'skipped']).notNullable().defaultTo('pending');
  });

  await knex.schema.createTable('webhook_events', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('event_type', 64).notNullable();
    t.jsonb('payload').notNullable();
    t.boolean('delivered').notNullable().defaultTo(false);
    t.timestamps(true, true);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('webhook_events');
  await knex.schema.dropTableIfExists('payment_retries');
  await knex.schema.dropTableIfExists('credits');
  await knex.schema.dropTableIfExists('payments');
  await knex.schema.dropTableIfExists('invoice_line_items');
  await knex.schema.dropTableIfExists('invoices');
  await knex.schema.dropTableIfExists('billing_cycles');
  await knex.schema.dropTableIfExists('subscriptions');
  await knex.schema.dropTableIfExists('coupons');
  await knex.schema.dropTableIfExists('customers');
  await knex.schema.dropTableIfExists('plans');
}
