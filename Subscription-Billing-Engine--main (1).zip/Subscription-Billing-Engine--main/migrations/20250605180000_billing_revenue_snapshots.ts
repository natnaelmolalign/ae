import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('billing_revenue_snapshots', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('snapshot_type', 32).notNullable();
    t.string('period_key', 16).notNullable();
    t.uuid('customer_id').nullable().references('id').inTable('customers');
    t.jsonb('metrics').notNullable().defaultTo('{}');
    t.jsonb('breakdown').notNullable().defaultTo('[]');
    t.string('currency', 3).notNullable().defaultTo('USD');
    t.timestamp('captured_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.unique(['snapshot_type', 'period_key', 'customer_id']);
    t.index(['period_key', 'snapshot_type']);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('billing_revenue_snapshots');
}
