import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('meters', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('code', 64).notNullable().unique();
    t.string('name', 128).notNullable();
    t.string('aggregation', 32).notNullable().defaultTo('sum');
    t.jsonb('tier_config').notNullable().defaultTo('[]');
    t.boolean('active').notNullable().defaultTo(true);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('usage_records', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('meter_id').notNullable().references('id').inTable('meters');
    t.uuid('subscription_id').notNullable().references('id').inTable('subscriptions');
    t.float('quantity').notNullable();
    t.timestamp('recorded_at', { useTz: true }).notNullable();
    t.string('idempotency_key', 128).nullable();
    t.timestamps(true, true);
    t.unique(['meter_id', 'subscription_id', 'idempotency_key']);
    t.index(['subscription_id', 'meter_id', 'recorded_at']);
  });

  await knex.schema.createTable('plan_entitlements', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('plan_id').notNullable().references('id').inTable('plans').onDelete('CASCADE');
    t.string('feature_key', 128).notNullable();
    t.integer('limit_value').nullable();
    t.enum('limit_type', ['boolean', 'count', 'unlimited']).notNullable().defaultTo('boolean');
    t.string('reset_interval', 32).nullable();
    t.timestamps(true, true);
    t.unique(['plan_id', 'feature_key']);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('plan_entitlements');
  await knex.schema.dropTableIfExists('usage_records');
  await knex.schema.dropTableIfExists('meters');
}
