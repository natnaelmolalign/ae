import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('addon_products', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('code', 64).notNullable().unique();
    t.string('name', 128).notNullable();
    t.integer('price_cents').notNullable();
    t.boolean('active').notNullable().defaultTo(true);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('subscription_items', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('subscription_id')
      .notNullable()
      .references('id')
      .inTable('subscriptions')
      .onDelete('CASCADE');
    t.enum('item_type', ['base_plan', 'addon']).notNullable();
    t.uuid('plan_id').nullable().references('id').inTable('plans');
    t.uuid('addon_product_id').nullable().references('id').inTable('addon_products');
    t.string('description', 255).notNullable();
    t.integer('unit_price_cents').notNullable();
    t.integer('quantity').notNullable().defaultTo(1);
    t.boolean('active').notNullable().defaultTo(true);
    t.timestamps(true, true);
    t.index(['subscription_id', 'active']);
  });

  await knex.schema.createTable('job_runs', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('job_name', 64).notNullable();
    t.enum('status', ['running', 'completed', 'failed', 'skipped']).notNullable();
    t.timestamp('started_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.timestamp('finished_at', { useTz: true }).nullable();
    t.jsonb('result_json').nullable();
    t.text('last_error').nullable();
    t.index(['job_name', 'status', 'started_at']);
  });

  await knex.schema.createTable('revenue_schedules', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('invoice_id').notNullable().references('id').inTable('invoices');
    t.uuid('subscription_id').notNullable().references('id').inTable('subscriptions');
    t.date('schedule_date').notNullable();
    t.integer('amount_cents').notNullable();
    t.enum('status', ['pending', 'recognized']).notNullable().defaultTo('pending');
    t.timestamps(true, true);
    t.unique(['invoice_id', 'schedule_date']);
    t.index(['subscription_id', 'schedule_date']);
  });

  await knex.schema.createTable('billing_daily_stats', (t) => {
    t.date('stat_date').primary();
    t.integer('mrr_cents').notNullable().defaultTo(0);
    t.integer('new_subscriptions').notNullable().defaultTo(0);
    t.integer('cancelled_subscriptions').notNullable().defaultTo(0);
    t.integer('failed_payments').notNullable().defaultTo(0);
    t.integer('invoices_issued').notNullable().defaultTo(0);
    t.integer('revenue_recognized_cents').notNullable().defaultTo(0);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('quotes', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('customer_id').notNullable().references('id').inTable('customers');
    t.enum('status', ['draft', 'sent', 'accepted', 'expired', 'converted'])
      .notNullable()
      .defaultTo('draft');
    t.date('expires_at').notNullable();
    t.uuid('converted_subscription_id').nullable().references('id').inTable('subscriptions');
    t.timestamps(true, true);
    t.index(['customer_id', 'status']);
  });

  await knex.schema.createTable('quote_line_items', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('quote_id').notNullable().references('id').inTable('quotes').onDelete('CASCADE');
    t.string('description', 255).notNullable();
    t.integer('quantity').notNullable().defaultTo(1);
    t.integer('unit_price_cents').notNullable();
    t.uuid('plan_id').nullable().references('id').inTable('plans');
    t.timestamps(true, true);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('quote_line_items');
  await knex.schema.dropTableIfExists('quotes');
  await knex.schema.dropTableIfExists('billing_daily_stats');
  await knex.schema.dropTableIfExists('revenue_schedules');
  await knex.schema.dropTableIfExists('job_runs');
  await knex.schema.dropTableIfExists('subscription_items');
  await knex.schema.dropTableIfExists('addon_products');
}
