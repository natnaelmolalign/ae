import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('billing_schedules', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('customer_id').notNullable().references('id').inTable('customers').onDelete('CASCADE');
    t.string('name', 128).notNullable();
    t.string('cadence', 32).notNullable();
    t.integer('anchor_day').notNullable();
    t.jsonb('line_templates').notNullable().defaultTo('[]');
    t.boolean('active').notNullable().defaultTo(true);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('contracts', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('customer_id').notNullable().references('id').inTable('customers').onDelete('CASCADE');
    t.string('reference', 64).notNullable().unique();
    t.string('status', 32).notNullable().defaultTo('draft');
    t.date('effective_from').notNullable();
    t.date('effective_to');
    t.bigInteger('committed_mrr_cents').notNullable().defaultTo(0);
    t.jsonb('terms').notNullable().defaultTo('{}');
    t.timestamps(true, true);
  });

  await knex.schema.createTable('contract_amendments', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('contract_id').notNullable().references('id').inTable('contracts').onDelete('CASCADE');
    t.string('amendment_type', 64).notNullable();
    t.jsonb('payload').notNullable().defaultTo('{}');
    t.timestamp('applied_at').notNullable().defaultTo(knex.fn.now());
  });

  await knex.schema.createTable('data_export_requests', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('customer_id').notNullable().references('id').inTable('customers').onDelete('CASCADE');
    t.string('status', 32).notNullable().defaultTo('pending');
    t.jsonb('artifact').notNullable().defaultTo('{}');
    t.timestamp('completed_at');
    t.timestamps(true, true);
  });

  await knex.schema.createTable('catalog_price_snapshots', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('bundle_code', 64).notNullable();
    t.jsonb('quote').notNullable();
    t.timestamps(true, true);
  });

  await knex.schema.createTable('billing_disputes', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('invoice_id').notNullable().references('id').inTable('invoices').onDelete('CASCADE');
    t.integer('amount_cents').notNullable();
    t.string('status', 32).notNullable();
    t.text('reason');
    t.timestamps(true, true);
  });

  await knex.schema.createTable('webhook_replay_log', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('outbox_message_id').notNullable();
    t.string('status', 32).notNullable();
    t.text('error_message');
    t.timestamp('replayed_at').notNullable().defaultTo(knex.fn.now());
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('catalog_price_snapshots');
  await knex.schema.dropTableIfExists('billing_disputes');
  await knex.schema.dropTableIfExists('webhook_replay_log');
  await knex.schema.dropTableIfExists('data_export_requests');
  await knex.schema.dropTableIfExists('contract_amendments');
  await knex.schema.dropTableIfExists('contracts');
  await knex.schema.dropTableIfExists('billing_schedules');
}
