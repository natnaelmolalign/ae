import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('domain_events', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('event_type', 128).notNullable();
    t.string('aggregate_type', 64).notNullable();
    t.uuid('aggregate_id').notNullable();
    t.jsonb('payload').notNullable();
    t.timestamp('occurred_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.index(['aggregate_type', 'aggregate_id']);
    t.index(['event_type', 'occurred_at']);
  });

  await knex.schema.createTable('outbox_messages', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('domain_event_id')
      .notNullable()
      .references('id')
      .inTable('domain_events')
      .onDelete('CASCADE');
    t.string('channel', 32).notNullable().defaultTo('webhook');
    t.enum('status', ['pending', 'delivered', 'failed']).notNullable().defaultTo('pending');
    t.integer('attempt_count').notNullable().defaultTo(0);
    t.timestamp('next_attempt_at', { useTz: true }).nullable();
    t.text('last_error').nullable();
    t.timestamp('delivered_at', { useTz: true }).nullable();
    t.timestamps(true, true);
    t.index(['status', 'next_attempt_at']);
  });

  await knex.schema.createTable('audit_log', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('entity_type', 64).notNullable();
    t.uuid('entity_id').notNullable();
    t.string('action', 64).notNullable();
    t.string('actor', 128).notNullable().defaultTo('system');
    t.jsonb('before_state').nullable();
    t.jsonb('after_state').nullable();
    t.uuid('domain_event_id').nullable().references('id').inTable('domain_events');
    t.timestamp('recorded_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.index(['entity_type', 'entity_id', 'recorded_at']);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('audit_log');
  await knex.schema.dropTableIfExists('outbox_messages');
  await knex.schema.dropTableIfExists('domain_events');
}
