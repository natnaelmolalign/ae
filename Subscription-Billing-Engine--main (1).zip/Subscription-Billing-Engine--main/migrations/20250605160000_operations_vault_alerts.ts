import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('payment_method_vault', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('customer_id').notNullable().references('id').inTable('customers').onDelete('CASCADE');
    t.string('token_ref', 128).notNullable();
    t.string('brand', 32).notNullable();
    t.string('last4', 4).notNullable();
    t.integer('exp_month').notNullable();
    t.integer('exp_year').notNullable();
    t.boolean('default_method').notNullable().defaultTo(false);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('api_key_rotation_log', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('principal_id').notNullable().references('id').inTable('api_principals').onDelete('CASCADE');
    t.string('old_hash_prefix', 16).notNullable();
    t.timestamp('rotated_at').notNullable().defaultTo(knex.fn.now());
  });

  await knex.schema.createTable('billing_alerts', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.string('alert_type', 64).notNullable();
    t.string('severity', 16).notNullable();
    t.jsonb('payload').notNullable().defaultTo('{}');
    t.boolean('acknowledged').notNullable().defaultTo(false);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('maintenance_windows', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.timestamp('starts_at').notNullable();
    t.timestamp('ends_at').notNullable();
    t.text('reason');
    t.boolean('blocks_writes').notNullable().defaultTo(true);
    t.timestamps(true, true);
  });

  await knex.schema.createTable('rate_limit_overrides', (t) => {
    t.uuid('principal_id').primary().references('id').inTable('api_principals').onDelete('CASCADE');
    t.integer('requests_per_minute').notNullable();
    t.primary(['principal_id']);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('maintenance_windows');
  await knex.schema.dropTableIfExists('rate_limit_overrides');
  await knex.schema.dropTableIfExists('billing_alerts');
  await knex.schema.dropTableIfExists('api_key_rotation_log');
  await knex.schema.dropTableIfExists('payment_method_vault');
}
