# Advanced backend roadmap (in-repo only)

Twelve phases that build on the existing billing engine. Each phase adds a self-contained capability using PostgreSQL, internal jobs, and configuration—no third-party APIs or external services.

| Phase | Capability | Builds on | Primary artifacts |
|-------|------------|-----------|-------------------|
| 1 | Transactional outbox & domain events | Payments, webhooks | `outbox_messages`, `OutboxService`, `outboxJob` |
| 2 | Immutable audit trail | Phase 1 events | `audit_log`, `AuditService` |
| 3 | Usage metering & rated charges | Invoices, plans | `meters`, `usage_records`, `MeteringService` |
| 4 | Plan entitlements | Plans, subscriptions | `plan_entitlements`, `EntitlementService` |
| 5 | Configurable dunning policies | Retries, subscriptions | `dunning_policies`, `DunningService` |
| 6 | Credit notes & invoice adjustments | Invoices, credits | `credit_notes`, `CreditNoteService` |
| 7 | Subscription add-ons & quantities | Subscriptions, proration | `subscription_items` |
| 8 | Job orchestration & advisory locks | All jobs | `job_runs`, `JobLockService` |
| 9 | Revenue recognition schedules | Paid invoices | `revenue_schedules` |
| 10 | Billing analytics rollups | All billing data | `billing_daily_stats`, rollup job |
| 11 | Repository layer & unit of work | Services | `src/repositories/*` |
| 12 | Quotes & quote-to-subscription | Customers, plans | `quotes`, `QuoteService` |

## Phase 1 — Transactional outbox & domain events

**Problem:** Side effects (webhooks) run inside request handlers; a crash after commit can skip notifications, and duplicate retries can double-send.

**Solution:** Persist domain events and outbound messages in the same DB transaction as state changes. A dedicated worker delivers webhooks from the outbox with at-least-once semantics and idempotent consumers.

**Deliverables:** `DomainEventPublisher`, `OutboxService`, `processOutbox` job, integration with `PaymentService` and `SubscriptionService`.

## Phase 2 — Immutable audit trail

**Problem:** No forensic trail for compliance or support—only current row state.

**Solution:** Append-only `audit_log` with actor, action, entity reference, and before/after snapshots. Written from services alongside domain events.

## Phase 3 — Usage metering & rated charges

**Problem:** Flat recurring plans only; no usage-based billing.

**Solution:** Define meters (e.g. `api_calls`), ingest usage records, aggregate per period, and add rated line items to invoices via tiered pricing rules stored in JSON config.

## Phase 4 — Plan entitlements

**Problem:** Feature access is implicit in plan metadata JSON.

**Solution:** First-class `plan_entitlements` (feature key, limit, reset interval). API to evaluate entitlement for a subscription at a point in time.

## Phase 5 — Configurable dunning policies

**Problem:** Retry delays are global env strings; cancellation rules are hardcoded.

**Solution:** Per-plan or default dunning policies: ordered stages (retry, email flag placeholder, cancel) with delays. `DunningService` drives `RetryService`.

## Phase 6 — Credit notes & invoice adjustments

**Problem:** Refunds update payments/credits but lack a formal adjustment document.

**Solution:** Issue credit notes linked to invoices with line-level reasons; void/adjust invoice totals without deleting history.

## Phase 7 — Subscription add-ons & quantities

**Problem:** One plan per subscription; no seats or add-on products.

**Solution:** `subscription_items` with plan/component type, quantity, and independent proration on changes.

## Phase 8 — Job orchestration & advisory locks

**Problem:** Overlapping cron runs can double-bill or double-retry.

**Solution:** `job_runs` ledger plus PostgreSQL advisory locks so only one instance runs `billing` / `retry` / `outbox` per window.

## Phase 9 — Revenue recognition schedules

**Problem:** Cash collected immediately; no deferred revenue for finance views.

**Solution:** On invoice paid, generate recognition schedule rows spreading revenue across service period days (internal reporting API).

## Phase 10 — Billing analytics rollups

**Problem:** Reporting requires ad-hoc SQL across large tables.

**Solution:** Nightly rollup job populates `billing_daily_stats` (MRR, churn count, failed payments) for dashboard endpoints.

## Phase 11 — Repository layer & unit of work

**Problem:** Services call Knex directly—harder to test and swap persistence.

**Solution:** Thin repositories per aggregate and a `UnitOfWork` wrapping transactions and outbox publish.

## Phase 12 — Quotes & quote-to-subscription

**Problem:** No sales workflow before subscription creation.

**Solution:** Quotes with line items, expiry, and one-shot conversion to subscription + first invoice.

## Phase 13 — RBAC & API principals

Hashed API keys, roles, permissions, and middleware guards for resource-level access.

## Phase 14 — Workflows & feature flags

Subscription lifecycle state machines and percentage-based feature rollouts.

## Phase 15 — Observability & retention

Prometheus metrics, period closes, saga orchestration, and data retention jobs.

## Phase 16 — Contracts & billing schedules

Commercial contracts with amendments and customer-specific billing cadence templates.

## Phase 17 — Exports & reporting

GDPR data exports, AR aging, MRR snapshots, and financial report APIs.

## Phase 18 — Insights & forecasting

Customer health scores, LTV, MRR forecasts, and domain-event projections.

## Phase 19 — Operations & analytics control plane

Payment method vault, API key rotation, billing alerts, job scheduler bundle, maintenance windows, cohort retention, and revenue leakage scans.

---

Phases 1–19 are implemented in the codebase. Run `npm run migrate` after pulling, then use the jobs and routes documented in the README.
