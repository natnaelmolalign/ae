# Architecture

## Layers

- **Routes** — HTTP validation and response mapping
- **Services** — Domain logic (subscriptions, billing, proration, payments)
- **Models** — TypeScript interfaces and state-machine rules
- **Utils** — Pure date, currency, and proration helpers
- **Jobs** — Scheduled billing and payment retry processing

## Data flow

1. Customer subscribes to a plan → subscription row + initial billing cycle
2. Billing job renews periods and triggers invoice generation
3. Invoice service applies coupons, tax, and customer credits in order
4. Payment service charges invoices; failures schedule retries and may cancel
5. Mid-cycle plan changes run through proration service and issue credits

## State machine

Subscription statuses: `trial` → `active` → `past_due` → `cancelled` / `expired`.

Transitions are enforced in `SubscriptionService.assertTransition`.

## Background jobs

- `billingJob` — renew due subscriptions, generate invoices, expire ended subscriptions
- `retryJob` — process due payment retries from `payment_retries` table
