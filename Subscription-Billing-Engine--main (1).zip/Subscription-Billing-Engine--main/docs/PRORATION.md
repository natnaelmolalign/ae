# Proration

Mid-cycle plan changes credit unused time on the old plan and charge remaining time on the new plan.

## Formula

```
totalDays   = inclusive days in [periodStart, periodEnd]
remaining   = inclusive days from changeDate through periodEnd
unused      = totalDays - remaining

creditCents = round(oldPriceCents * unused / totalDays)
chargeCents = round(newPriceCents * remaining / totalDays)
netCents    = chargeCents - creditCents
```

## Implementation

- Pure calculation: `src/utils/prorationUtils.ts`
- Orchestration + credit issuance: `src/services/ProrationService.ts`

## Edge cases

- Change after period end → zero proration
- Leap year February uses actual calendar day counts
- Yearly plans use the same day-ratio formula over the current period bounds
