# Billing Rules

## Billing anchor

Each subscription stores a `billing_anchor` (calendar day). When advancing months, the engine clamps the day to the month's last day (e.g. anchor 31 → Feb 29 in leap years).

## Billing cycles

One row per `(subscription_id, period_start)`. Duplicate cycles for the same period are rejected.

## Invoices

- Generated per billing cycle; void invoices are excluded from duplicate detection
- Trial subscriptions cannot be invoiced until trial ends
- Tax rate is selected by customer `country` at invoice time
- Credits apply only to non-void invoices and reduce `credit_balance_cents`

## Discount order

When both fixed credits and percentage coupons apply, credits reduce the subtotal first, then the coupon percentage is applied to the remainder.

## Payment retries

Default schedule: 3, 5, 7 days after first failure (configurable via `RETRY_DELAYS_DAYS`). First failure moves `active` → `past_due`. Exhausted retries cancel the subscription and enqueue a `subscription.cancelled` webhook event.

## Grace period

Grace end is computed from **due date**, not issued date: `due_date + grace_days`.
