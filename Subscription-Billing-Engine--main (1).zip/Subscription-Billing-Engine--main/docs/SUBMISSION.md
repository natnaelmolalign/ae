# Private archive submission guide

Use this checklist before uploading a **private source zip** (include `.git` at the archive root) to Silver (AQ) or similar platforms.

## Silver (AQ) repo upload

| Requirement | This repo |
|-------------|-----------|
| Zip includes `.git` at archive root | Use tar commands below (do **not** exclude `.git`) |
| `.dockerignore` must **not** exclude `.git/` | `.git` is intentionally **not** listed |
| Pinned `FROM` on every stage | `node:20.18.2-alpine3.20` (builder, runtime, workspace) |
| Default image includes git history | Final `workspace` stage uses `COPY . /app` (`.git` not in `.dockerignore`) |
| COPY destinations | Use `/app/...` paths only (Silver rejects `./dist`, `./src`, etc.) |
| `npm ci` with lockfile | Yes |
| GitHub remote private | Confirm at repo settings before upload |
| Repo bonus ($300) | Requires **5+ approved tasks** after repo approval |

Per-task authoring (Harbor `nop` / `oracle`, `instruction.md`, etc.) is a separate step after the repo is approved.

## Verified locally (re-run before upload)

| Check | Command / note |
|-------|----------------|
| Build | `npm run build` |
| Tests + coverage | `npm test -- --coverage` (must meet `jest.config.js` thresholds) |
| Production LOC | `(Get-ChildItem src -Recurse -Include *.ts \| Get-Content \| Measure-Object -Line).Lines` → ~10k |
| No Cursor co-author | `git log --format="%B" \| Select-String "Co-authored-by: Cursor"` → empty |
| No conventional prefixes | `git log --format="%s" \| Select-String "^(test\|chore\|feat\|fix\|docs):"` → empty |
| Git health | `git fsck` (dangling objects after rebases are OK) |
| Docker base pinned | All `Dockerfile` stages use `node:20.18.2-alpine3.20`; `npm ci` |
| `.dockerignore` | Must not list `.git` (Silver task harness needs git history in images) |
| Secrets | `.env` gitignored; ship `.env.example` only |

## Coverage (this repo)

`jest.config.js` enforces global minimums on `src/**/*.ts`. Re-run coverage after any change; do **not** claim 100% branches unless the report shows it.

## Zip layout (required)

Build from **inside** the repo so `.git` is at the zip root:

```powershell
cd H:\path\to\Subscription-Billing-Engine-
Remove-Item ..\Subscription-Billing-Engine-.zip -Force -ErrorAction SilentlyContinue
tar -a -cf ..\Subscription-Billing-Engine-.zip `
  --exclude=node_modules `
  --exclude=coverage `
  --exclude=dist `
  .
tar -tf ..\Subscription-Billing-Engine-.zip | Select-String "\.git/HEAD"
```

Expect `.git/HEAD` at the root, not `Subscription-Billing-Engine-/.git/HEAD`.

## Privacy attestation

Only attest “never published” if the GitHub remote is **private** or removed. Confirm visibility at `https://github.com/abudi-09/Subscription-Billing-Engine-` before signing.

## Pre-upload block

```powershell
npm run build
npm test -- --coverage
git fsck
git log --format="%B" | Select-String "Co-authored-by: Cursor"
tar -a -cf "..\Subscription-Billing-Engine-.zip" --exclude=node_modules --exclude=coverage --exclude=dist .
tar -tf "..\Subscription-Billing-Engine-.zip" | Select-String "\.git/HEAD"
```
