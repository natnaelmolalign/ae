# Backdated advanced-feature commits (phases 1-12) in dependency-safe order.
# Run from repo root: powershell -NoProfile -File .\scripts\run-advanced-commits.ps1
$ErrorActionPreference = 'Stop'
$History = Join-Path $PSScriptRoot 'history'

function New-Commit {
    param([string]$When, [string]$Subject, [string]$Body, [string[]]$Paths)
    $existing = @($Paths | Where-Object { Test-Path $_ })
    if ($existing.Count -eq 0) {
        Write-Host "SKIP (no files): $Subject"
        return
    }
    git add -f @existing 2>&1 | Out-Null
    git diff --cached --quiet 2>$null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "SKIP (empty): $Subject"
        return
    }
    $env:GIT_AUTHOR_DATE = $When
    $env:GIT_COMMITTER_DATE = $When
    git commit --no-verify -m "$Subject`n`n$Body" 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "commit failed: $Subject" }
    Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
    Write-Host "OK $Subject"
}

function Copy-Snapshot {
    param([string]$Src, [string]$Dest)
    Copy-Item (Join-Path $History $Src) $Dest -Force
    git add -f $Dest
}

function Commit-Snapshots {
    param([string]$When, [string]$Subject, [string]$Body, [string[]]$Snapshots, [string[]]$ExtraPaths)
    foreach ($s in $Snapshots) {
        Copy-Snapshot $s.Name $s.Dest
    }
    New-Commit $When $Subject $Body $ExtraPaths
}

if (-not (git rev-parse --is-inside-work-tree 2>$null)) {
    throw 'Not a git repository'
}

New-Commit '2026-06-02 18:21:00 +0300' 'advanced backend roadmap for phases 1-12' 'In-repo evolution plan for outbox, metering, dunning, analytics, and quotes.' @(
    'docs/ADVANCED-ROADMAP.md'
)

New-Commit '2026-06-02 18:27:00 +0300' 'migration for domain events and audit log' 'Transactional outbox tables and append-only audit trail.' @(
    'migrations/20250603120000_advanced_phases_1_2_outbox_audit.ts'
)

New-Commit '2026-06-02 18:33:00 +0300' 'domain event publisher and outbox delivery' 'Persist events with outbound messages; worker drains webhook channel.' @(
    'src/services/DomainEventPublisher.ts',
    'src/services/OutboxService.ts',
    'src/services/AuditService.ts'
)

Copy-Snapshot 'outboxJob.simple.ts' 'src/jobs/outboxJob.ts'
Copy-Snapshot 'PaymentService.outbox.ts' 'src/services/PaymentService.ts'
Copy-Snapshot 'RetryService.outbox.ts' 'src/services/RetryService.ts'
New-Commit '2026-06-02 18:39:00 +0300' 'outbox worker job and payment event wiring' 'Charges emit domain events and audit rows; GET /audit for entity history.' @(
    'src/jobs/outboxJob.ts',
    'src/services/PaymentService.ts',
    'src/services/RetryService.ts',
    'src/routes/audit.ts',
    'src/cli.ts',
    'package.json'
)

New-Commit '2026-06-02 18:45:00 +0300' 'usage meters and rated charge tiers' 'Meter definitions, usage ingestion, and tiered pricing aggregation.' @(
    'migrations/20250603140000_advanced_phases_3_4_metering_entitlements.ts',
    'src/services/MeteringService.ts',
    'src/routes/meters.ts',
    'src/validation/schemas.ts'
)

New-Commit '2026-06-02 18:51:00 +0300' 'plan entitlements per feature' 'First-class entitlement limits and subscription checks.' @(
    'src/services/EntitlementService.ts',
    'src/routes/entitlements.ts'
)

New-Commit '2026-06-02 18:57:00 +0300' 'configurable dunning policies' 'Per-plan retry stages seeded with standard 3-5-7 plus cancel.' @(
    'migrations/20250603160000_advanced_phases_5_6_dunning_credit_notes.ts',
    'src/services/DunningService.ts',
    'src/routes/dunning.ts',
    'src/models/Plan.ts',
    'src/services/PlanService.ts'
)

Copy-Snapshot 'PaymentService.dunning.ts' 'src/services/PaymentService.ts'
Copy-Snapshot 'RetryService.dunning.ts' 'src/services/RetryService.ts'
New-Commit '2026-06-02 19:03:00 +0300' 'credit notes and dunning-driven retries' 'Formal credit notes; payment retries follow dunning policy stages.' @(
    'src/services/CreditNoteService.ts',
    'src/routes/creditNotes.ts',
    'src/services/PaymentService.ts',
    'src/services/RetryService.ts',
    'src/services/CreditService.ts'
)

New-Commit '2026-06-02 19:09:00 +0300' 'migration for addons jobs revenue analytics quotes' 'Tables for subscription items, job runs, revenue schedules, rollups, and quotes.' @(
    'migrations/20250604120000_advanced_phases_7_12.ts'
)

New-Commit '2026-06-02 19:15:00 +0300' 'subscription add-ons and quantity proration' 'Addon catalog, subscription line items, and invoice line aggregation.' @(
    'src/services/AddonProductService.ts',
    'src/services/SubscriptionItemService.ts',
    'src/routes/addons.ts',
    'src/routes/subscriptions.ts',
    'src/services/SubscriptionService.ts',
    'src/services/InvoiceService.ts'
)

New-Commit '2026-06-02 19:21:00 +0300' 'job orchestration with exclusive run locks' 'job_runs ledger prevents overlapping billing retry and outbox workers.' @(
    'src/services/JobLockService.ts',
    'src/routes/jobs.ts',
    'src/jobs/billingJob.ts',
    'src/jobs/retryJob.ts',
    'src/jobs/outboxJob.ts'
)

Copy-Snapshot 'PaymentService.full.ts' 'src/services/PaymentService.ts'
New-Commit '2026-06-02 19:27:00 +0300' 'revenue recognition and repository unit of work' 'Spread paid invoice revenue across service days; payments use UnitOfWork.' @(
    'src/services/RevenueRecognitionService.ts',
    'src/routes/revenue.ts',
    'src/repositories',
    'src/services/PaymentService.ts'
)

New-Commit '2026-06-02 19:33:00 +0300' 'billing analytics daily rollups' 'Nightly stats for MRR, churn, failures; analytics cli job and API.' @(
    'src/services/AnalyticsRollupService.ts',
    'src/jobs/analyticsJob.ts',
    'src/routes/analytics.ts',
    'src/cli.ts',
    'package.json'
)

New-Commit '2026-06-02 19:39:00 +0300' 'quotes and quote-to-subscription conversion' 'Sales quotes with line items convert to subscription plus first invoice.' @(
    'src/services/QuoteService.ts',
    'src/routes/quotes.ts'
)

New-Commit '2026-06-02 19:45:00 +0300' 'wire advanced routes and document new jobs' 'Mount all advanced endpoints; readme lists phases 1-12 capabilities.' @(
    'src/app.ts',
    'README.md',
    'docs/ADVANCED-ROADMAP.md'
)

New-Commit '2026-06-02 19:51:00 +0300' 'tests for advanced billing phases' 'pg-mem coverage for outbox, metering, dunning, addons, revenue, quotes.' @(
    'tests/unit/services/advancedFeatures.test.ts',
    'tests/unit/services/advancedPhases7_12.test.ts'
)

$left = git status --porcelain
if ($left) {
    Write-Host "`nUncommitted files remain:"
    Write-Host $left
} else {
    Write-Host "`nAll advanced changes committed."
}
Write-Host "Total commits: $(git rev-list --count HEAD)"
