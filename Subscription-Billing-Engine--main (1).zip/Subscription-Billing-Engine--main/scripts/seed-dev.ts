/**
 * Dev seed: basic/monthly + pro/yearly plans. Run after migrate.
 * npx ts-node scripts/seed-dev.ts
 */
import dotenv from 'dotenv';
import { closeDb, getDb } from '../src/config/database';

dotenv.config();

async function seed(): Promise<void> {
  const db = getDb();
  const existing = await db('plans').count('* as c');
  if (Number((existing[0] as { c: string }).c) > 0) {
    console.log('plans already exist, skip seed');
    return;
  }

  await db('plans').insert([
    {
      name: 'Basic',
      price_cents: 1000,
      interval: 'monthly',
      features: JSON.stringify(['api-access', 'email-support']),
    },
    {
      name: 'Pro',
      price_cents: 9900,
      interval: 'yearly',
      features: JSON.stringify(['api-access', 'priority-support', 'analytics']),
    },
  ]);

  console.log('seeded Basic ($10/mo) and Pro ($99/yr)');
}

seed()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => closeDb());
