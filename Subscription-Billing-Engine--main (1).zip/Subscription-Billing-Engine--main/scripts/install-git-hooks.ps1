# Copies prepare-commit-msg hook to strip Cursor co-author from future commits.
$repoRoot = Split-Path -Parent $PSScriptRoot
$hook = @'
#!/bin/sh
MSG_FILE="$1"
if [ -f "$MSG_FILE" ]; then
  grep -v '^Co-authored-by: Cursor <cursoragent@cursor.com>$' "$MSG_FILE" > "$MSG_FILE.bak" 2>/dev/null
  mv -f "$MSG_FILE.bak" "$MSG_FILE" 2>/dev/null
fi
exit 0
'@
$dest = Join-Path $repoRoot ".git\hooks\prepare-commit-msg"
Set-Content -Path $dest -Value $hook -NoNewline -Encoding ASCII
Write-Host "Installed $dest"
