# Operations vault, alerts, and coverage tests (commits 80-100+).
$ErrorActionPreference = 'Stop'

function New-Commit {
    param([string]$When, [string]$Subject, [string]$Body, [string[]]$Paths)
    $existing = @($Paths | Where-Object { Test-Path $_ })
    if ($existing.Count -eq 0) { Write-Host "SKIP (no files): $Subject"; return }
    git add -f @existing 2>&1 | Out-Null
    git diff --cached --quiet 2>$null
    if ($LASTEXITCODE -eq 0) { Write-Host "SKIP (empty): $Subject"; return }
    $env:GIT_AUTHOR_DATE = $When
    $env:GIT_COMMITTER_DATE = $When
    git commit --no-verify -m "$Subject`n`n$Body" 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "commit failed: $Subject" }
    Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
    Write-Host "OK $Subject"
}

New-Commit '2026-06-02 22:33:00 +0300' 'migration for vault rotation and billing alerts' 'Payment method vault, API key rotation log, alerts, and rate limit overrides.' @(
    'migrations/20250605160000_operations_vault_alerts.ts'
)

New-Commit '2026-06-02 22:39:00 +0300' 'payment method vault service' 'Tokenized card references per customer with default method selection.' @(
    'src/services/PaymentMethodVaultService.ts'
)

New-Commit '2026-06-02 22:45:00 +0300' 'api key rotation audit trail' 'Rotate principal keys with append-only rotation log.' @(
    'src/services/ApiKeyRotationService.ts'
)

New-Commit '2026-06-02 22:51:00 +0300' 'webhook hmac signing helpers' 'Sign and verify outbound webhook payloads for delivery integrity.' @(
    'src/services/WebhookSigningService.ts'
)

New-Commit '2026-06-02 22:57:00 +0300' 'per-principal rate limit overrides' 'Configurable RPM caps stored in rate_limit_overrides.' @(
    'src/services/RateLimitPolicyService.ts'
)

New-Commit '2026-06-02 23:03:00 +0300' 'billing alerts and threshold evaluation' 'Raise and acknowledge operational alerts for payment spikes and past-due subs.' @(
    'src/services/BillingAlertService.ts'
)

New-Commit '2026-06-02 23:09:00 +0300' 'entitlement check cache layer' 'Short TTL cache in front of entitlement evaluation.' @(
    'src/services/EntitlementCacheService.ts'
)

New-Commit '2026-06-02 23:15:00 +0300' 'tax jurisdiction registry' 'Country VAT rules, reverse charge, and VAT ID validation helpers.' @(
    'src/domain/tax/TaxJurisdictionRegistry.ts'
)

New-Commit '2026-06-02 23:21:00 +0300' 'minimum commitment true-up calculator' 'Enterprise shortfall and overage true-up math for contracted MRR.' @(
    'src/domain/billing/MinimumCommitmentCalculator.ts'
)

New-Commit '2026-06-02 23:27:00 +0300' 'operations routes vault compliance and alerts' 'Authenticated ops API for vault, compliance report, and alert evaluation.' @(
    'src/routes/operations.ts',
    'src/app.ts'
)

New-Commit '2026-06-02 23:33:00 +0300' 'exportable cli command dispatcher' 'Refactor CLI into runCliCommand; add export and forecast commands.' @(
    'src/cli.ts',
    'src/jobs/exportJob.ts',
    'src/jobs/forecastJob.ts'
)

New-Commit '2026-06-02 23:39:00 +0300' 'fix reporting queries for pg schema' 'Use attempted_at on payments and updated_at on paid invoices.' @(
    'src/services/ReportingService.ts',
    'src/services/compliance/ComplianceReportBuilder.ts',
    'src/services/BillingAlertService.ts'
)

New-Commit '2026-06-02 23:45:00 +0300' 'unit tests for billing rules and tax registry' 'Cover BillingRulesEngine calculate path and jurisdiction helpers.' @(
    'tests/unit/domain/billingRulesEngine.test.ts',
    'tests/unit/domain/taxJurisdictionRegistry.test.ts',
    'jest.config.js'
)

New-Commit '2026-06-02 23:51:00 +0300' 'extended service and route coverage tests' 'Integration smoke for ops routes; unit coverage for catalog, compliance, vault.' @(
    'tests/unit/services/extendedCoverage.test.ts',
    'tests/integration/routes/allRoutes.test.ts',
    'tests/integration/appAndJobs.test.ts',
    'tests/unit/app/cli.test.ts'
)

New-Commit '2026-06-02 23:57:00 +0300' 'job scheduler and maintenance windows' 'Nightly bundle orchestration and maintenance window checks.' @(
    'src/services/operations/JobSchedulerService.ts',
    'src/services/operations/MaintenanceWindowService.ts',
    'migrations/20250605160000_operations_vault_alerts.ts'
)

New-Commit '2026-06-03 00:03:00 +0300' 'billing runbooks and invoice documents' 'Month-end runbook automation and plain-text invoice rendering.' @(
    'src/services/operations/BillingRunbookService.ts',
    'src/services/InvoiceDocumentService.ts',
    'src/services/CohortAnalysisService.ts',
    'src/services/RevenueLeakageService.ts',
    'tests/unit/services/operations.test.ts'
)

New-Commit '2026-06-03 00:09:00 +0300' 'final expansion commit script' 'Replay script for operations vault and coverage commits.' @(
    'scripts/run-final-expansion-commits.ps1'
)

Write-Host "Total commits: $(git rev-list --count HEAD)"
git status --porcelain
