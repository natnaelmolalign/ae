#!/bin/sh
MAP="$GIT_DIR/date-map.txt"
[ -f "$MAP" ] || exit 0
NEW=$(awk -v c="$GIT_COMMIT" '$1==c { $1=""; sub(/^ /,""); print }' "$MAP")
if [ -n "$NEW" ]; then
  export GIT_AUTHOR_DATE="$NEW"
  export GIT_COMMITTER_DATE="$NEW"
fi
