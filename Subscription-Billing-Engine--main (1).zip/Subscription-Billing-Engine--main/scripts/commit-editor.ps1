param([string]$Path = $args[0])
$content = Get-Content -LiteralPath $Path
$content | Where-Object { $_ -notmatch 'Co-authored-by:\s*Cursor' } | Set-Content -LiteralPath $Path
