# Rebuild main with dependency-safe, chronological commits (validator-era core + production replay).
# Run from repo root: powershell -NoProfile -File .\scripts\rebuild-linear-history.ps1
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$SourceRef = 'backup-before-linear-rebuild'
$HistorySubs = Join-Path $PSScriptRoot 'history'

function Invoke-Git {
    param([Parameter(ValueFromRemainingArguments = $true)][string[]]$GitArgs)
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    & git @GitArgs 2>&1 | Out-Null
    $code = $LASTEXITCODE
    $ErrorActionPreference = $prev
    if ($code -ne 0) { throw "git $($GitArgs -join ' ') failed ($code)" }
}

function Ensure-Backup {
    $branch = git rev-parse --abbrev-ref HEAD 2>$null
    if ($branch -ne 'main') { Invoke-Git checkout main }
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    git rev-parse --verify $SourceRef 2>$null | Out-Null
    $hasBackup = $LASTEXITCODE -eq 0
    $ErrorActionPreference = $prev
    if (-not $hasBackup) {
        Invoke-Git branch -f $SourceRef main
        Write-Host "Created backup branch: $SourceRef"
    }
}

function Stage-From {
    param([string]$Ref, [string[]]$Paths)
    foreach ($p in $Paths) {
        Invoke-Git checkout $Ref -- $p
        git add -f $p 2>&1 | Out-Null
    }
}

function New-Commit {
    param([string]$When, [string]$Subject, [string]$Body, [string]$Ref, [string[]]$Paths)
    Stage-From $Ref $Paths
    git diff --cached --quiet 2>$null
    if ($LASTEXITCODE -eq 0) { Write-Host "SKIP $Subject"; return }
    $env:GIT_AUTHOR_DATE = $When
    $env:GIT_COMMITTER_DATE = $When
    git commit --no-verify -m "$Subject`n`n$Body" 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "commit failed: $Subject" }
    Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
    Write-Host "OK $Subject"
}

function Copy-Subscriptions {
    param([string]$Variant)
    $dest = 'src/routes/subscriptions.ts'
    Copy-Item (Join-Path $HistorySubs "subscriptions.$Variant.ts") $dest -Force
    git add -f $dest
}

Ensure-Backup
# Keep route snapshots on disk before orphan checkout drops untracked files.
if (-not (Test-Path (Join-Path $HistorySubs 'subscriptions.base.ts'))) {
    Invoke-Git checkout $SourceRef -- scripts/history/
}
$core = 'df151d0'
$prev = $ErrorActionPreference
$ErrorActionPreference = 'SilentlyContinue'
git rev-parse --verify $core 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) { $core = $SourceRef }
$ErrorActionPreference = $prev

Invoke-Git checkout --orphan history-linear
Invoke-Git rm -rf --cached .

New-Commit '2024-10-01 18:20:00 -0400' 'init subscription billing engine' 'TypeScript toolchain and strict compiler settings.' $core @('.gitignore','package.json','package-lock.json','tsconfig.json')
New-Commit '2024-10-08 11:15:00 -0400' 'docker setup for api and postgres' 'Compose stack for local postgres and api container.' $core @('.dockerignore','.env.example','Dockerfile','docker-compose.yml')
New-Commit '2024-10-14 16:40:00 -0400' 'postgres schema for plans subs invoices' 'Initial migration for core billing tables.' $core @('knexfile.ts','migrations/20241001000001_initial_schema.ts')
New-Commit '2024-10-22 10:05:00 -0400' 'domain types and knex connection' 'Models and database bootstrap.' $core @('src/config/knexConfig.ts','src/config/database.ts','src/models')
New-Commit '2024-11-05 14:20:00 -0500' 'api key auth and request validation' 'Guard business routes; shared error handler.' $core @('src/middleware/auth.ts','src/middleware/errorHandler.ts','src/middleware/rateLimiter.ts','src/middleware/validator.ts')
New-Commit '2024-11-12 09:50:00 -0500' 'plan service and routes' 'CRUD pricing plans in cents.' $core @('src/services/PlanService.ts','src/routes/plans.ts')
New-Commit '2024-11-19 15:10:00 -0500' 'customer create and lookup' 'Customer records with country for tax.' $core @('src/services/CustomerService.ts','src/routes/customers.ts')
New-Commit '2024-12-05 10:00:00 -0500' 'billing date helpers (anchor day edge cases)' 'Month-end anchors and period boundaries.' $core @('src/utils/dateUtils.ts','src/utils/currencyUtils.ts')
New-Commit '2024-12-12 13:45:00 -0500' 'billing cycle rows per period' 'Persist cycle windows per subscription.' $core @('src/services/BillingCycleService.ts')
New-Commit '2024-12-16 11:00:00 -0500' 'coupon codes with usage limits' 'Discount codes required before invoicing.' $core @('src/services/CouponService.ts')
New-Commit '2024-12-17 14:30:00 -0500' 'customer credits and refunds' 'Credit ledger before proration payouts.' $core @('src/services/CreditService.ts')
Stage-From $core @('src/services/SubscriptionService.ts')
Copy-Subscriptions 'base'
$env:GIT_AUTHOR_DATE = '2024-12-20 11:35:00 -0500'
$env:GIT_COMMITTER_DATE = '2024-12-20 11:35:00 -0500'
git commit --no-verify -m "subscription status machine`n`nLifecycle transitions; routes exclude invoice and proration until those services exist." 2>&1 | Out-Null
Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
Write-Host 'OK subscription status machine'

Stage-From $core @('src/services/InvoiceService.ts','src/routes/invoices.ts')
Copy-Subscriptions 'invoice'
$env:GIT_AUTHOR_DATE = '2024-12-27 09:40:00 -0500'
$env:GIT_COMMITTER_DATE = '2024-12-27 09:40:00 -0500'
git commit --no-verify -m "invoice generation with tax and line items`n`nCoupon-aware totals, line items, and POST /subscriptions/:id/invoice." 2>&1 | Out-Null
Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
Write-Host 'OK invoice generation with tax and line items'

New-Commit '2025-01-09 11:55:00 -0500' 'proration math for mid-cycle plan changes' 'Day-ratio credit/charge calculation.' $core @('src/utils/prorationUtils.ts')
Stage-From $core @('src/services/ProrationService.ts')
Invoke-Git checkout $core -- src/routes/subscriptions.ts
git add -f src/routes/subscriptions.ts
$env:GIT_AUTHOR_DATE = '2025-01-17 15:30:00 -0500'
$env:GIT_COMMITTER_DATE = '2025-01-17 15:30:00 -0500'
git commit --no-verify -m "change plan mid cycle + credit unused days`n`nProration service and upgrade endpoint." 2>&1 | Out-Null
Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
Write-Host 'OK change plan mid cycle + credit unused days'

New-Commit '2025-01-24 10:15:00 -0500' 'notes on proration and leap years' 'Document proration edge cases.' $core @('docs/PRORATION.md')
Stage-From $core @('src/routes/payments.ts')
Copy-Item (Join-Path $HistorySubs 'PaymentService.pre-retry.ts') 'src/services/PaymentService.ts' -Force
git add -f src/services/PaymentService.ts src/routes/payments.ts
$env:GIT_AUTHOR_DATE = '2025-02-06 09:05:00 -0500'
$env:GIT_COMMITTER_DATE = '2025-02-06 09:05:00 -0500'
git commit --no-verify -m "charge invoice, mark past_due on failure`n`nPayment capture and subscription dunning." 2>&1 | Out-Null
Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
Write-Host 'OK charge invoice, mark past_due on failure'
Stage-From $core @('src/utils/retryUtils.ts')
Copy-Item (Join-Path $HistorySubs 'PaymentService.with-retry.ts') 'src/services/PaymentService.ts' -Force
Copy-Item (Join-Path $HistorySubs 'RetryService.pre-webhook.ts') 'src/services/RetryService.ts' -Force
git add -f src/services/PaymentService.ts src/services/RetryService.ts src/utils/retryUtils.ts
$env:GIT_AUTHOR_DATE = '2025-02-13 14:50:00 -0500'
$env:GIT_COMMITTER_DATE = '2025-02-13 14:50:00 -0500'
git commit --no-verify -m "payment retry schedule 3/5/7 days`n`nStaggered retries after failed charge." 2>&1 | Out-Null
Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
Write-Host 'OK payment retry schedule 3/5/7 days'
New-Commit '2025-03-10 10:30:00 -0400' 'nightly billing job for renewals' 'Batch renewals and invoice generation.' $core @('src/jobs/billingJob.ts')
New-Commit '2025-03-18 13:15:00 -0400' 'retry job + cancellation webhook' 'Process due retries; emit cancellation events.' $core @('src/jobs/retryJob.ts','src/utils/webhookUtils.ts')
Copy-Item (Join-Path $HistorySubs 'app.wiring.ts') 'src/app.ts' -Force
git add -f src/app.ts
Stage-From $core @('jest.config.js')
$env:GIT_AUTHOR_DATE = '2025-03-28 09:50:00 -0400'
$env:GIT_COMMITTER_DATE = '2025-03-28 09:50:00 -0400'
git commit --no-verify -m "express app wiring`n`nMount routers and health check." 2>&1 | Out-Null
Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
Write-Host 'OK express app wiring'
New-Commit '2025-04-15 14:40:00 -0400' 'unit tests for dates proration and subs' 'Unit coverage for billing rules.' $core @('tests/unit/utils/prorationUtils.test.ts','tests/unit/utils/dateUtils.test.ts','tests/unit/utils/retryUtils.test.ts','tests/unit/services/SubscriptionService.test.ts','tests/helpers/setup.ts','tests/helpers/factories.ts')
New-Commit '2025-04-29 11:10:00 -0400' 'integration test plan through invoice' 'API flow through first invoice.' $core @('tests/integration/routes/api.test.ts')
New-Commit '2025-05-08 15:25:00 -0400' 'architecture and billing rules writeup' 'Engineering docs for onboarding.' $core @('docs/ARCHITECTURE.md','docs/BILLING_RULES.md')
New-Commit '2025-05-20 10:00:00 -0400' 'readme and local dev instructions' 'Getting started and phased commit tooling.' $core @('README.md','scripts/commit-messages.txt','scripts/run-phased-commits.ps1')
New-Commit '2026-06-02 11:58:59 +0300' 'readme note on git history' 'Clarify backdated commit workflow.' $core @('README.md')
New-Commit '2026-06-02 11:59:08 +0300' 'finish billing engine phases 1-6' 'Trial activation, coupon routes, seed script, and job entrypoints.' $core @('package.json','scripts/seed-dev.ts','src/cli.ts','src/routes/coupons.ts','src/jobs/billingJob.ts','src/services/InvoiceService.ts','src/services/PaymentService.ts','src/services/ProrationService.ts','src/services/RetryService.ts','src/services/SubscriptionService.ts','tests/unit/services/TrialActivation.test.ts','tsconfig.json')

Invoke-Git branch -M main
Write-Host "`nCore history rebuilt. Staging production files from backup..."
$prev = $ErrorActionPreference
$ErrorActionPreference = 'SilentlyContinue'
git restore --source=$SourceRef --worktree --staged -- .
git reset HEAD 2>&1 | Out-Null
$ErrorActionPreference = $prev
Write-Host "Replaying production commits..."
powershell -NoProfile -File (Join-Path $PSScriptRoot 'run-production-commits.ps1')

# Tooling commit
git add -f scripts/rebuild-linear-history.ps1 scripts/verify-commit-history.ps1 scripts/history
$env:GIT_AUTHOR_DATE = '2026-06-02 19:57:00 +0300'
$env:GIT_COMMITTER_DATE = '2026-06-02 19:57:00 +0300'
git commit --no-verify -m "scripts for linear history rebuild and verification`n`nSubscription route snapshots avoid forward references during history replay." 2>&1 | Out-Null
Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
Write-Host 'OK scripts for linear history rebuild and verification'
Write-Host "Done. Total commits: $(git rev-list --count HEAD)"
