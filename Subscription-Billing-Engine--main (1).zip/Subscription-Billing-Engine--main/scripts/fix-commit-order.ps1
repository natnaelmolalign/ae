# Fix charge-before-retry and revenue PaymentService commits on current main.
# Run: powershell -NoProfile -File .\scripts\fix-commit-order.ps1
$ErrorActionPreference = 'Stop'
$History = Join-Path $PSScriptRoot 'history'
$SnapRef = 'main'

function Copy-Snapshot {
    param([string]$Name, [string]$Dest)
    $path = Join-Path $History $Name
    if (Test-Path $path) {
        Copy-Item $path $Dest -Force
        return
    }
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    git show "${SnapRef}:scripts/history/$Name" 2>$null | Out-File -Encoding utf8 $Dest
    $ErrorActionPreference = $prev
    if ((Test-Path $Dest) -and (Get-Item $Dest).Length -gt 0) { return }
    if ($Name -eq 'PaymentService.with-retry.ts' -and $script:RetryRef) {
        git show "${script:RetryRef}:src/services/PaymentService.ts" | Out-File -Encoding utf8 $Dest
    }
    if (-not (Test-Path $Dest) -or (Get-Item $Dest).Length -eq 0) {
        throw "Missing snapshot: scripts/history/$Name (ref $SnapRef)"
    }
}

function Invoke-Git {
    param([Parameter(ValueFromRemainingArguments = $true)][string[]]$GitArgs)
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    & git @GitArgs 2>&1 | ForEach-Object { Write-Host $_ }
    $code = $LASTEXITCODE
    $ErrorActionPreference = $prev
    if ($code -ne 0) { throw "git $($GitArgs -join ' ') failed ($code)" }
}

$branch = git rev-parse --abbrev-ref HEAD
if ($branch -ne 'main') { Invoke-Git checkout main }
$stash = $false
$porcelain = git status --porcelain
if ($porcelain) {
    Invoke-Git stash push -u -m 'fix-commit-order'
    $stash = $true
}
$prev = $ErrorActionPreference
$ErrorActionPreference = 'SilentlyContinue'
git branch -D history-fix-seq 2>$null | Out-Null
$ErrorActionPreference = $prev

$charge = (git log --oneline --grep='^charge invoice' -1 --format='%H').Trim()
$retry = (git log --oneline --grep='^payment retry schedule' -1 --format='%H').Trim()
if (-not $charge -or -not $retry) { throw 'Could not find charge or retry commits' }
$script:RetryRef = $retry

Write-Host "Charge commit: $charge"
Write-Host "Retry commit:  $retry"

$chargeParent = (git rev-parse "$charge^").Trim()
function Commit-Like {
    param([string]$Ref, [string[]]$Paths, [string]$When)
    $subject = (git log -1 --format='%s' $Ref).Trim()
    $body = (git log -1 --format='%b' $Ref).Trim()
    $msg = if ($body) { "$subject`n`n$body" } else { $subject }
    git add -f @Paths
    $env:GIT_AUTHOR_DATE = $When
    $env:GIT_COMMITTER_DATE = $When
    git commit --no-verify -m $msg 2>&1 | Out-Null
    Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
}
$chargeDate = (git log -1 --format='%aI' $charge).Trim()
$retryDate = (git log -1 --format='%aI' $retry).Trim()

Invoke-Git checkout -B history-fix-seq $chargeParent
Copy-Snapshot 'PaymentService.pre-retry.ts' 'src/services/PaymentService.ts'
Invoke-Git checkout $charge -- src/routes/payments.ts
Commit-Like $charge @('src/services/PaymentService.ts', 'src/routes/payments.ts') $chargeDate
$fixedCharge = (git rev-parse HEAD).Trim()
Write-Host "Fixed charge: $fixedCharge"

Copy-Snapshot 'PaymentService.with-retry.ts' 'src/services/PaymentService.ts'
Invoke-Git checkout $retry -- src/utils/retryUtils.ts
Copy-Snapshot 'RetryService.pre-webhook.ts' 'src/services/RetryService.ts'
Commit-Like $retry @('src/services/PaymentService.ts', 'src/services/RetryService.ts', 'src/utils/retryUtils.ts') $retryDate
$fixedRetry = (git rev-parse HEAD).Trim()
Write-Host "Fixed retry:  $fixedRetry"

Invoke-Git checkout main
Write-Host 'Rebasing main onto fixed retry (skipping old charge/retry)...'
Invoke-Git rebase --onto $fixedRetry $retry main

$revenue = (git log --oneline --grep='^revenue recognition' -1 --format='%H').Trim()
if ($revenue) {
    Write-Host "Amending revenue commit $revenue with PaymentService.full.ts"
    Invoke-Git checkout $revenue
    Copy-Snapshot 'PaymentService.full.ts' 'src/services/PaymentService.ts'
    git add -f src/services/PaymentService.ts
    $revDate = (git log -1 --format='%aI').Trim()
    $subject = (git log -1 --format='%s').Trim()
    $body = (git log -1 --format='%b').Trim()
    $msg = if ($body) { "$subject`n`n$body" } else { $subject }
    $env:GIT_AUTHOR_DATE = $revDate
    $env:GIT_COMMITTER_DATE = $revDate
    git commit --amend --no-verify -m $msg 2>&1 | Out-Null
    Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
    $fixedRevenue = (git rev-parse HEAD).Trim()
    Invoke-Git rebase --onto $fixedRevenue $revenue main
}

Write-Host "Done. HEAD: $(git rev-parse --short HEAD)"
if ($stash) {
    Invoke-Git stash pop
}
