$text = [Console]::In.ReadToEnd()
$lines = $text -split "`r?`n" | Where-Object {
    $_ -notmatch '^\s*Co-authored-by:\s*Cursor\s*<cursoragent@cursor\.com>\s*$'
}
($lines -join "`n").TrimEnd() + "`n"
