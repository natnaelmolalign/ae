@echo off
findstr /V /C:"Co-authored-by: Cursor"
