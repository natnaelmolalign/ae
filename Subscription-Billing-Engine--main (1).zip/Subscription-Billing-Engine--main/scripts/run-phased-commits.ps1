# Run from repo root while on history-rebuild orphan (or let script reset).
$ErrorActionPreference = 'Continue'

function New-PhaseCommit {
    param([string]$When, [string]$Subject, [string]$Body, [string[]]$Paths)
    $ex = @($Paths | Where-Object { Test-Path $_ })
    if ($ex.Count -eq 0) { return }
    git add -f @ex 2>&1 | Out-Null
    git diff --cached --quiet 2>$null
    if ($LASTEXITCODE -eq 0) { return }
    $env:GIT_AUTHOR_DATE = $When
    $env:GIT_COMMITTER_DATE = $When
    git commit -m "$Subject`n`n$Body" 2>&1 | Out-Null
    Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
    Write-Host "OK $Subject"
}

git checkout main 2>&1 | Out-Null
git branch -D history-rebuild 2>&1 | Out-Null
git checkout --orphan history-rebuild 2>&1 | Out-Null
git rm -rf --cached . 2>&1 | Out-Null

# Phase 1
New-PhaseCommit "2024-10-02 09:30:00 -0400" "chore: bootstrap TypeScript billing engine project" "Set up Node 20 toolchain, Jest, and strict TS config before domain work." @("package.json","package-lock.json","tsconfig.json",".gitignore")
New-PhaseCommit "2024-10-08 11:15:00 -0400" "chore(docker): add containerized Postgres and API runtime" "Compose gives us repeatable migrations and CI-style test runs." @("Dockerfile",".dockerignore","docker-compose.yml",".env.example")
New-PhaseCommit "2024-10-14 16:40:00 -0400" "feat(db): add core billing schema migration" "Tables for plans, subscriptions, cycles, invoices, retries, and credits." @("migrations","knexfile.ts")
New-PhaseCommit "2024-10-22 10:05:00 -0400" "feat(domain): introduce plan and subscription type definitions" "Keep billing rules in services; models stay as explicit contracts." @("src/config/knexConfig.ts","src/config/database.ts","src/models/Plan.ts","src/models/Customer.ts","src/models/Subscription.ts","src/models/Invoice.ts","src/models/Payment.ts","src/models/Credit.ts","src/models/Coupon.ts")

# Phase 2
New-PhaseCommit "2024-11-05 14:20:00 -0500" "feat(api): add auth, rate limiting, and error middleware" "Fail fast on bad input; API key gate for internal callers." @("src/middleware/auth.ts","src/middleware/errorHandler.ts","src/middleware/rateLimiter.ts","src/middleware/validator.ts")
New-PhaseCommit "2024-11-12 09:50:00 -0500" "feat(plans): implement plan service and REST routes" "Supports monthly/yearly pricing stored in cents." @("src/services/PlanService.ts","src/routes/plans.ts")
New-PhaseCommit "2024-11-19 15:10:00 -0500" "feat(customers): add customer onboarding service" "Track country for tax and credit balance per account." @("src/services/CustomerService.ts","src/routes/customers.ts")
New-PhaseCommit "2024-11-27 11:35:00 -0500" "feat(subscriptions): implement lifecycle state machine" "Enforce allowed transitions; block negative credit signups." @("src/services/SubscriptionService.ts","src/routes/subscriptions.ts")

# Phase 3
New-PhaseCommit "2024-12-05 10:00:00 -0500" "feat(utils): add billing anchor and currency helpers" "Handle month-end anchors (e.g. bill on 31st in February)." @("src/utils/dateUtils.ts","src/utils/currencyUtils.ts")
New-PhaseCommit "2024-12-12 13:45:00 -0500" "feat(billing): track billing cycles per subscription period" "Prevent duplicate cycles for the same period_start." @("src/services/BillingCycleService.ts")
New-PhaseCommit "2024-12-18 16:25:00 -0500" "feat(invoices): generate invoices with tax and discounts" "Apply credits only to non-void invoices; line items for audit trail." @("src/services/InvoiceService.ts","src/routes/invoices.ts")
New-PhaseCommit "2024-12-27 09:40:00 -0500" "feat(api): expose subscription invoice endpoint" "Invoice generation tied to active period and customer country." @("src/routes/subscriptions.ts")

# Phase 4
New-PhaseCommit "2025-01-09 11:55:00 -0500" "feat(proration): add day-ratio mid-cycle adjustment math" "Credit unused old plan days; charge remainder on new plan." @("src/utils/prorationUtils.ts")
New-PhaseCommit "2025-01-17 15:30:00 -0500" "feat(subscriptions): support in-cycle plan upgrades" "Issue proration credits atomically with plan_id update." @("src/services/ProrationService.ts","src/routes/subscriptions.ts")
New-PhaseCommit "2025-01-24 10:15:00 -0500" "docs(proration): document calculation rules and edge cases" "Clarify leap-year periods and post-period change behavior." @("docs/PRORATION.md")

# Phase 5
New-PhaseCommit "2025-02-06 09:05:00 -0500" "feat(payments): process invoice charges and refunds" "Failed charges move active subscriptions to past_due." @("src/services/PaymentService.ts","src/routes/payments.ts")
New-PhaseCommit "2025-02-13 14:50:00 -0500" "feat(retries): schedule staggered payment retry attempts" "Delays are cumulative (3+5+7 days), not immediate re-fire." @("src/services/RetryService.ts","src/utils/retryUtils.ts")
New-PhaseCommit "2025-02-20 11:20:00 -0500" "feat(credits): manage customer credit balances" "Refunds cannot exceed original payment; credits skip void invoices." @("src/services/CreditService.ts")
New-PhaseCommit "2025-02-28 16:05:00 -0500" "feat(coupons): add discount codes with usage limits" "Percent/fixed discounts; optional plan allowlist and expiry." @("src/services/CouponService.ts")

# Phase 6
New-PhaseCommit "2025-03-10 10:30:00 -0400" "feat(jobs): run periodic billing and renewal invoicing" "Renew due periods, generate missing invoices, expire ended subs." @("src/jobs/billingJob.ts")
New-PhaseCommit "2025-03-18 13:15:00 -0400" "feat(jobs): process due payment retries and webhooks" "Emit subscription.cancelled when retry budget is exhausted." @("src/jobs/retryJob.ts","src/utils/webhookUtils.ts")
New-PhaseCommit "2025-03-28 09:50:00 -0400" "feat(app): wire Express app and route mounting" "Health check stays public; business routes behind API key." @("src/app.ts","jest.config.js")
New-PhaseCommit "2025-04-15 14:40:00 -0400" "test: cover proration, dates, and subscription rules" "Split DB tests from pure unit helpers to keep CI fast." @("tests/unit/utils/prorationUtils.test.ts","tests/unit/utils/dateUtils.test.ts","tests/unit/utils/retryUtils.test.ts","tests/unit/services/SubscriptionService.test.ts","tests/helpers/setup.ts","tests/helpers/factories.ts")
New-PhaseCommit "2025-04-29 11:10:00 -0400" "test(integration): verify plan-to-invoice API flow" "Supertest exercises auth, subscription create, and invoicing." @("tests/integration/routes/api.test.ts")
New-PhaseCommit "2025-05-08 15:25:00 -0400" "docs: add architecture and billing rules guides" "Onboard engineers on state machine and discount ordering." @("docs/ARCHITECTURE.md","docs/BILLING_RULES.md")
New-PhaseCommit "2025-05-20 10:00:00 -0400" "docs: finalize README and phased history tooling" "Project ready for Docker-based test runs and Silver tasking." @("README.md","scripts/rebuild-phased-history.ps1","scripts/rebuild-phased-history.sh","scripts/run-phased-commits.ps1","scripts/backfill-commits.ps1","scripts/backfill-commits.sh")

git branch -M -f main 2>&1 | Out-Null
Write-Host "Commits: $(git rev-list --count HEAD)"
