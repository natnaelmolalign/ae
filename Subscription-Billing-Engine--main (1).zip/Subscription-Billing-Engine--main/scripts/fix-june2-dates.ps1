# Deprecated: use redistribute-commit-dates.ps1 for full timeline (Oct 2024 -> Jun 2026).
# This script only packs commits that were already on/after 2026-06-02 into the same day.
# Run: powershell -NoProfile -File .\scripts\fix-june2-dates.ps1
$ErrorActionPreference = 'Stop'
$CapDate = '2026-06-02'
$Zone = '+0300'
$Start = [DateTimeOffset]::Parse("2026-06-02T11:59:08$Zone")
$StepMinutes = 6

function Invoke-Git {
    param([Parameter(ValueFromRemainingArguments = $true)][string[]]$GitArgs)
    & git @GitArgs
    if ($LASTEXITCODE -ne 0) { throw "git $($GitArgs -join ' ') failed ($LASTEXITCODE)" }
}

function Format-GitDate([DateTimeOffset]$When) {
    $epoch = [int64][Math]::Floor($When.ToUnixTimeSeconds())
    return "@$epoch $Zone"
}

$branch = git rev-parse --abbrev-ref HEAD
if ($branch -ne 'main') { Invoke-Git checkout main }

$juneCommits = [System.Collections.Generic.List[string]]::new()
$map = @{}
$idx = 0
foreach ($c in git rev-list --reverse HEAD) {
    $day = (git log -1 --format=%ad --date=short $c).Trim()
    if ($day -ge $CapDate) {
        $juneCommits.Add($c)
        $map[$c] = Format-GitDate ($Start.AddMinutes($StepMinutes * $idx))
        $idx++
    }
}

if ($juneCommits.Count -eq 0) {
    Write-Host 'No commits on or after 2026-06-02 to rewrite.'
    exit 0
}

$first = $juneCommits[0]
$parent = (git rev-parse "$first^").Trim()
$lastWhen = $map[$juneCommits[$juneCommits.Count - 1]]

Write-Host "Rewriting $($juneCommits.Count) commits (all on $CapDate, last at $lastWhen)..."

$prev = $ErrorActionPreference
$ErrorActionPreference = 'SilentlyContinue'
git branch -D date-fix-june2 2>$null | Out-Null
$ErrorActionPreference = $prev

Invoke-Git checkout -B date-fix-june2 $parent
foreach ($c in $juneCommits) {
    Invoke-Git cherry-pick -n $c
    $subject = (git log -1 --format='%s' $c).Trim()
    $body = (git log -1 --format='%b' $c).Trim()
    $msg = if ($body) { "$subject`n`n$body" } else { $subject }
    $when = $map[$c]
    $env:GIT_AUTHOR_DATE = $when
    $env:GIT_COMMITTER_DATE = $when
    Invoke-Git commit --no-verify -m $msg
    Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
}

Invoke-Git checkout -B main date-fix-june2
$prev = $ErrorActionPreference
$ErrorActionPreference = 'SilentlyContinue'
git branch -D date-fix-june2 2>$null | Out-Null
$ErrorActionPreference = $prev

Write-Host 'Done.'
git log -5 --format='%h %ad %s' --date=format:'%Y-%m-%d %H:%M %z'
$after = @(git log --format='%ad' --date=short | Where-Object { $_ -gt $CapDate })
if ($after.Count -gt 0) {
    throw "Commits still after $CapDate : $($after[0..2] -join ', ')"
}
