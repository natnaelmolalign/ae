# Phases 13+ senior expansion commits (RBAC, workflows, observability, exports, contracts).
# Run from repo root after all files exist: powershell -NoProfile -File .\scripts\run-senior-expansion-commits.ps1
$ErrorActionPreference = 'Stop'

function New-Commit {
    param([string]$When, [string]$Subject, [string]$Body, [string[]]$Paths)
    $existing = @($Paths | Where-Object { Test-Path $_ })
    if ($existing.Count -eq 0) {
        Write-Host "SKIP (no files): $Subject"
        return
    }
    git add -f @existing 2>&1 | Out-Null
    git diff --cached --quiet 2>$null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "SKIP (empty): $Subject"
        return
    }
    $env:GIT_AUTHOR_DATE = $When
    $env:GIT_COMMITTER_DATE = $When
    git commit --no-verify -m "$Subject`n`n$Body" 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "commit failed: $Subject" }
    Remove-Item Env:\GIT_AUTHOR_DATE, Env:\GIT_COMMITTER_DATE -ErrorAction SilentlyContinue
    Write-Host "OK $Subject"
}

if (-not (git rev-parse --is-inside-work-tree 2>$null)) { throw 'Not a git repository' }

New-Commit '2026-06-02 20:03:00 +0300' 'roadmap phases 13-18 for contracts and exports' 'Documents billing schedules, contracts, GDPR exports, and reporting APIs.' @(
    'docs/ADVANCED-ROADMAP.md'
)

New-Commit '2026-06-02 20:09:00 +0300' 'migration for rbac workflows and observability' 'Permissions, workflows, feature flags, retention, metrics, sagas, notifications, period closes.' @(
    'migrations/20250605120000_senior_rbac_workflow_observability.ts'
)

New-Commit '2026-06-02 20:15:00 +0300' 'domain aggregates and billing rules engine' 'Invoice and subscription aggregates with shared event sourcing base.' @(
    'src/domain'
)

New-Commit '2026-06-02 20:21:00 +0300' 'rbac principals roles and permission middleware' 'API principals with hashed keys; requirePermission guard for routes.' @(
    'src/services/RbacService.ts',
    'src/middleware/requirePermission.ts',
    'src/routes/rbac.ts',
    'src/middleware/auth.ts'
)

New-Commit '2026-06-02 20:27:00 +0300' 'workflow engine for subscription lifecycle' 'Stateful workflow definitions, instances, and history for billing entities.' @(
    'src/services/WorkflowEngine.ts',
    'src/routes/workflows.ts'
)

New-Commit '2026-06-02 20:33:00 +0300' 'feature flags with percentage rollout' 'Runtime toggles for metering, analytics, and quote conversion features.' @(
    'src/services/FeatureFlagService.ts',
    'src/routes/featureFlags.ts'
)

New-Commit '2026-06-02 20:39:00 +0300' 'prometheus metrics and application_metrics persistence' 'In-memory counters with HTTP middleware and DB snapshot job.' @(
    'src/lib/metrics.ts',
    'src/middleware/metricsMiddleware.ts',
    'src/routes/metrics.ts'
)

New-Commit '2026-06-02 20:45:00 +0300' 'retention policies and purge job' 'Configurable entity retention with purge_runs audit trail.' @(
    'src/services/RetentionPolicyService.ts',
    'src/jobs/retentionJob.ts'
)

New-Commit '2026-06-02 20:51:00 +0300' 'billing period close and reconciliation' 'Open, reconcile, and lock accounting periods with invoice totals.' @(
    'src/services/BillingPeriodCloseService.ts',
    'src/routes/periodCloses.ts',
    'src/services/BillingReconciliationService.ts'
)

New-Commit '2026-06-02 20:57:00 +0300' 'tax calculation and saga orchestrator' 'Jurisdiction-aware tax rules and persisted multi-step sagas.' @(
    'src/services/TaxCalculationService.ts',
    'src/services/SagaOrchestrator.ts'
)

New-Commit '2026-06-02 21:03:00 +0300' 'notification queue and internal delivery worker' 'Template-based notifications with pending queue processing.' @(
    'src/services/NotificationService.ts'
)

New-Commit '2026-06-02 21:09:00 +0300' 'query cache and plan read-through cache' 'TTL map cache wired into PlanService hot paths.' @(
    'src/lib/queryCache.ts',
    'src/services/PlanService.ts'
)

New-Commit '2026-06-02 21:15:00 +0300' 'migration for schedules contracts and export requests' 'Billing schedules, commercial contracts, GDPR exports, webhook replay log.' @(
    'migrations/20250605140000_senior_phases_13_18.ts'
)

New-Commit '2026-06-02 21:21:00 +0300' 'pricing domain price book discounts and usage rating' 'Composable catalog, promo rules, and meter tier rating.' @(
    'src/domain/pricing'
)

New-Commit '2026-06-02 21:27:00 +0300' 'billing schedules and commercial contracts' 'Customer billing templates and contract amendments with MRR commits.' @(
    'src/services/BillingScheduleService.ts',
    'src/services/ContractService.ts',
    'src/routes/schedules.ts',
    'src/routes/contracts.ts'
)

New-Commit '2026-06-02 21:33:00 +0300' 'gdpr data export service and routes' 'Customer artifact exports with async processing status.' @(
    'src/services/DataExportService.ts',
    'src/routes/exports.ts'
)

New-Commit '2026-06-02 21:39:00 +0300' 'financial reporting ar aging mrr and churn' 'Reporting service with authenticated report endpoints.' @(
    'src/services/ReportingService.ts',
    'src/routes/reports.ts'
)

New-Commit '2026-06-02 21:45:00 +0300' 'policy evaluation quote previews' 'Combines tax, discounts, and usage tiers without persisting invoices.' @(
    'src/services/PolicyEvaluationService.ts',
    'src/routes/policy.ts'
)

New-Commit '2026-06-02 21:51:00 +0300' 'circuit breaker and webhook replay' 'Outbound delivery protection with outbox replay audit log.' @(
    'src/lib/CircuitBreaker.ts',
    'src/services/WebhookReplayService.ts',
    'src/services/OutboxService.ts',
    'src/routes/webhookReplay.ts'
)

New-Commit '2026-06-02 21:57:00 +0300' 'deep health probes and api versioning' 'Ready probe checks migrations; x-api-version middleware.' @(
    'src/services/HealthProbeService.ts',
    'src/routes/health.ts',
    'src/middleware/apiVersion.ts'
)

New-Commit '2026-06-02 22:03:00 +0300' 'customer insights forecast and event projections' 'Health scores, LTV, MRR forecast, and domain event read models.' @(
    'src/services/BillingForecastService.ts',
    'src/services/CustomerInsightsService.ts',
    'src/services/EventProjectionService.ts',
    'src/services/InvoiceExportService.ts',
    'src/routes/insights.ts'
)

New-Commit '2026-06-02 22:09:00 +0300' 'wire senior routes metrics and cli jobs' 'Mount rbac, workflows, reports, exports; retention and metrics-persist CLI.' @(
    'src/app.ts',
    'src/cli.ts'
)

New-Commit '2026-06-02 22:15:00 +0300' 'tests for senior and phase 13-18 features' 'Unit and integration coverage for RBAC, sagas, exports, and insights APIs.' @(
    'tests/unit/services/seniorFeatures.test.ts',
    'tests/unit/services/phases13_18.test.ts',
    'tests/integration/routes/seniorRoutes.test.ts',
    'tests/integration/routes/phases13Routes.test.ts',
    'tests/integration/appAndJobs.test.ts',
    'tests/unit/lib/queryCache.test.ts',
    'tests/unit/lib/circuitBreaker.test.ts',
    'tests/helpers/pgMemDb.ts'
)

$left = git status --porcelain
if ($left) {
    Write-Host "`nUncommitted files remain:"
    Write-Host $left
} else {
    Write-Host "`nAll senior expansion changes committed."
}
Write-Host "Total commits: $(git rev-list --count HEAD)"
