import { Router } from 'express';
import { validateBody } from '../middleware/validator';
import { InvoiceService } from '../services/InvoiceService';
import { SubscriptionService } from '../services/SubscriptionService';
import { CustomerService } from '../services/CustomerService';

const router = Router();
const subscriptionService = new SubscriptionService();
const invoiceService = new InvoiceService();
const customerService = new CustomerService();

router.post(
  '/',
  validateBody({
    customer_id: { required: true, type: 'string' },
    plan_id: { required: true, type: 'string' },
  }),
  async (req, res, next) => {
    try {
      res.status(201).json(await subscriptionService.create(req.body));
    } catch (e) {
      next(e);
    }
  }
);

router.get('/:id', async (req, res, next) => {
  try {
    res.json(await subscriptionService.getById(req.params.id));
  } catch (e) {
    next(e);
  }
});

router.post('/:id/cancel', async (req, res, next) => {
  try {
    res.json(await subscriptionService.transition(req.params.id, 'cancelled'));
  } catch (e) {
    next(e);
  }
});

router.post('/:id/reactivate', async (req, res, next) => {
  try {
    res.json(await subscriptionService.reactivate(req.params.id));
  } catch (e) {
    next(e);
  }
});

router.post('/:id/pause', async (req, res, next) => {
  try {
    res.json(await subscriptionService.pause(req.params.id));
  } catch (e) {
    next(e);
  }
});

router.post('/:id/resume', async (req, res, next) => {
  try {
    res.json(await subscriptionService.resume(req.params.id, req.body.resume_date));
  } catch (e) {
    next(e);
  }
});

router.post('/:id/extend-trial', async (req, res, next) => {
  try {
    res.json(
      await subscriptionService.extendTrial(req.params.id, req.body.extra_days || 0)
    );
  } catch (e) {
    next(e);
  }
});

router.post('/:id/invoice', async (req, res, next) => {
  try {
    const sub = await subscriptionService.getById(req.params.id);
    const customer = await customerService.getById(sub.customer_id);
    res.status(201).json(
      await invoiceService.generateForSubscription(sub, customer.country)
    );
  } catch (e) {
    next(e);
  }
});

export default router;
