import dotenv from 'dotenv';
import express from 'express';
import winston from 'winston';
import { authMiddleware } from './middleware/auth';
import { errorHandler } from './middleware/errorHandler';
import { rateLimiter } from './middleware/rateLimiter';
import plansRouter from './routes/plans';
import customersRouter from './routes/customers';
import subscriptionsRouter from './routes/subscriptions';
import invoicesRouter from './routes/invoices';
import paymentsRouter from './routes/payments';

dotenv.config();

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  transports: [new winston.transports.Console()],
});

export function createApp() {
  const app = express();
  app.use(express.json());
  app.use(rateLimiter);

  app.get('/health', (_req, res) => {
    res.json({ status: 'ok' });
  });

  app.use(authMiddleware);
  app.use('/plans', plansRouter);
  app.use('/customers', customersRouter);
  app.use('/subscriptions', subscriptionsRouter);
  app.use('/invoices', invoicesRouter);
  app.use('/payments', paymentsRouter);

  app.use(errorHandler);
  return app;
}

const port = Number(process.env.PORT || 3000);

if (require.main === module) {
  const app = createApp();
  app.listen(port, () => {
    logger.info(`Subscription billing engine listening on ${port}`);
  });
}

export default createApp;
