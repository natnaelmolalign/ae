﻿import { getDb } from '../config/database';
import { maxRetryAttempts, nextRetryDate, parseRetryDelays } from '../utils/retryUtils';
import { SubscriptionService } from './SubscriptionService';

export class RetryService {
  constructor(private subscriptionService = new SubscriptionService()) {}

  getDelays(): number[] {
    return parseRetryDelays();
  }

  async scheduleRetries(
    subscriptionId: string,
    invoiceId: string,
    firstFailureAt: Date
  ): Promise<void> {
    const db = getDb();
    const existing = await db('payment_retries')
      .where({ invoice_id: invoiceId })
      .first();
    if (existing) return;

    const delays = this.getDelays();
    for (let i = 1; i <= delays.length; i++) {
      const scheduledAt = nextRetryDate(firstFailureAt, i, delays);
      if (!scheduledAt) continue;
      await db('payment_retries').insert({
        subscription_id: subscriptionId,
        invoice_id: invoiceId,
        attempt_number: i,
        scheduled_at: scheduledAt,
        status: 'pending',
      });
    }
  }

  async processDueRetries(asOf = new Date()): Promise<number> {
    const db = getDb();
    const pending = await db('payment_retries')
      .where({ status: 'pending' })
      .andWhere('scheduled_at', '<=', asOf)
      .orderBy('scheduled_at', 'asc');

    let processed = 0;
    for (const retry of pending) {
      const { PaymentService } = await import('./PaymentService');
      await new PaymentService().chargeInvoice(retry.invoice_id, false, {
        scheduleRetries: false,
      });
      const subAfter = await this.subscriptionService.getById(retry.subscription_id);
      await db('payment_retries')
        .where({ id: retry.id })
        .update({ status: 'completed', executed_at: asOf });

      const remaining = await db('payment_retries')
        .where({
          subscription_id: retry.subscription_id,
          invoice_id: retry.invoice_id,
          status: 'pending',
        })
        .count('* as c');
      const count = Number((remaining[0] as { c: string }).c);
      if (
        count === 0 &&
        subAfter.failed_payment_count >= maxRetryAttempts(this.getDelays())
      ) {
        await this.subscriptionService.transition(subAfter.id, 'cancelled');
      }
      processed += 1;
    }
    return processed;
  }
}
