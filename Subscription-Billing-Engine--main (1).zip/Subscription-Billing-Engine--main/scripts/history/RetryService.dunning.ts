import { getDb } from '../config/database';
import { AuditService } from './AuditService';
import { DomainEventPublisher } from './DomainEventPublisher';
import { DunningService } from './DunningService';
import { OutboxService } from './OutboxService';
import { SubscriptionService } from './SubscriptionService';

export class RetryService {
  constructor(
    private subscriptionService = new SubscriptionService(),
    private dunning = new DunningService(),
    private events = new DomainEventPublisher(),
    private audit = new AuditService(),
    private outbox = new OutboxService()
  ) {}

  async scheduleRetries(
    subscriptionId: string,
    invoiceId: string,
    firstFailureAt: Date
  ): Promise<void> {
    const sub = await this.subscriptionService.getById(subscriptionId);
    await this.dunning.scheduleRetriesForPolicy(
      subscriptionId,
      invoiceId,
      sub.plan_id,
      firstFailureAt
    );
  }

  async processDueRetries(asOf = new Date()): Promise<number> {
    const db = getDb();
    const pending = await db('payment_retries')
      .where({ status: 'pending' })
      .andWhere('scheduled_at', '<=', asOf)
      .orderBy('scheduled_at', 'asc');

    let processed = 0;
    for (const retry of pending) {
      const { PaymentService } = await import('./PaymentService');
      await new PaymentService().chargeInvoice(retry.invoice_id as string, false, {
        scheduleRetries: false,
        flushOutbox: false,
      });
      const subAfter = await this.subscriptionService.getById(retry.subscription_id as string);
      await db('payment_retries')
        .where({ id: retry.id })
        .update({ status: 'completed', executed_at: asOf });

      const remaining = await db('payment_retries')
        .where({
          subscription_id: retry.subscription_id,
          invoice_id: retry.invoice_id,
          status: 'pending',
        })
        .count('* as c');
      const count = Number((remaining[0] as { c: string }).c);

      const policy = await this.dunning.getPolicyForPlan(subAfter.plan_id);
      const completedRetries = await db('payment_retries')
        .where({
          subscription_id: retry.subscription_id,
          invoice_id: retry.invoice_id,
          status: 'completed',
        })
        .count('* as c');
      const doneCount = Number((completedRetries[0] as { c: string }).c);

      if (
        count === 0 &&
        this.dunning.shouldCancelAfterRetries(policy.stages, doneCount)
      ) {
        await db.transaction(async (trx) => {
          await trx('subscriptions')
            .where({ id: subAfter.id })
            .update({
              status: 'cancelled',
              cancelled_at: trx.fn.now(),
              updated_at: trx.fn.now(),
            });
          const event = await this.events.publish(
            {
              eventType: 'subscription.cancelled',
              aggregateType: 'subscription',
              aggregateId: subAfter.id,
              payload: { subscription_id: subAfter.id, reason: 'dunning_exhausted' },
            },
            trx
          );
          await this.audit.record(
            {
              entityType: 'subscription',
              entityId: subAfter.id,
              action: 'cancelled',
              afterState: { status: 'cancelled', reason: 'dunning_exhausted' },
              domainEventId: event.id,
            },
            trx
          );
        });
      }
      processed += 1;
    }

    await this.outbox.processPending(50);
    return processed;
  }
}
