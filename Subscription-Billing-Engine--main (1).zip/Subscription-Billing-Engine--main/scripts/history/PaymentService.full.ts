﻿import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import type { Payment } from '../models/Payment';
import { UnitOfWork } from '../repositories/UnitOfWork';
import { AuditService } from './AuditService';
import { CreditService } from './CreditService';
import { DunningService } from './DunningService';
import { InvoiceService } from './InvoiceService';
import { OutboxService } from './OutboxService';
import { RevenueRecognitionService } from './RevenueRecognitionService';
import { SubscriptionService } from './SubscriptionService';

export interface ChargeOptions {
  simulateSuccess?: boolean;
  scheduleRetries?: boolean;
  idempotencyKey?: string;
  flushOutbox?: boolean;
}

export interface ChargeResult {
  payment: Payment;
}

export class PaymentService {
  constructor(
    private invoiceService = new InvoiceService(),
    private subscriptionService = new SubscriptionService(),
    private creditService = new CreditService(),
    private audit = new AuditService(),
    private dunning = new DunningService(),
    private outbox = new OutboxService(),
    private revenue = new RevenueRecognitionService()
  ) {}

  async chargeInvoice(
    invoiceId: string,
    simulateSuccess = true,
    options: ChargeOptions = {}
  ): Promise<Payment> {
    const result = await this.chargeInvoiceWithEvents(invoiceId, simulateSuccess, options);
    if (options.flushOutbox !== false) {
      await this.outbox.processPending(10);
    }
    return result.payment;
  }

  async chargeInvoiceWithEvents(
    invoiceId: string,
    simulateSuccess = true,
    options: ChargeOptions = {}
  ): Promise<ChargeResult> {
    const idempotencyKey = options.idempotencyKey;
    const scheduleRetries = options.scheduleRetries ?? true;

    const payment = await UnitOfWork.run(async (uow) => {
      const invoice = await uow.invoices.findByIdForUpdate(invoiceId);
      if (!invoice) throw new AppError(404, 'Invoice not found');

      if (idempotencyKey) {
        const existing = await uow.payments.findByIdempotency(invoiceId, idempotencyKey);
        if (existing) return existing;
      }

      if (invoice.status === 'void') {
        throw new AppError(400, 'Cannot charge voided invoice');
      }
      if (invoice.status === 'paid') {
        throw new AppError(400, 'Invoice already paid');
      }

      const subscription = await uow.subscriptions.findByIdForUpdate(invoice.subscription_id);
      if (!subscription) throw new AppError(404, 'Subscription not found');

      const status = simulateSuccess ? 'succeeded' : 'failed';
      const row = await uow.payments.insert({
        invoice_id: invoiceId,
        amount_cents: invoice.total_cents,
        status,
        idempotency_key: idempotencyKey ?? null,
        failure_reason: simulateSuccess ? null : 'card_declined',
      });

      if (simulateSuccess) {
        await uow.invoices.markPaid(invoiceId);

        if (subscription.status === 'past_due') {
          await uow.subscriptions.update(subscription.id, { status: 'active' });
        }
        await uow.subscriptions.update(subscription.id, { failed_payment_count: 0 });

        const event = await uow.publish({
          eventType: 'invoice.paid',
          aggregateType: 'invoice',
          aggregateId: invoiceId,
          payload: {
            invoice_id: invoiceId,
            subscription_id: subscription.id,
            amount_cents: invoice.total_cents,
          },
        });
        await this.audit.record(
          {
            entityType: 'invoice',
            entityId: invoiceId,
            action: 'paid',
            afterState: { status: 'paid', payment_id: row.id },
            domainEventId: event.id,
          },
          uow.transaction
        );
        await this.revenue.createForPaidInvoice(invoiceId, uow.transaction);
      } else {
        const updated = await this.subscriptionService.bumpFailedPaymentCount(
          subscription.id,
          uow.transaction
        );

        if (Number(updated.failed_payment_count) >= 1 && updated.status === 'active') {
          await uow.subscriptions.update(subscription.id, { status: 'past_due' });
        }

        if (scheduleRetries && updated.failed_payment_count === 1) {
          await this.dunning.scheduleRetriesForPolicy(
            subscription.id,
            invoiceId,
            subscription.plan_id,
            new Date()
          );
        }

        const event = await uow.publish({
          eventType: 'payment.failed',
          aggregateType: 'payment',
          aggregateId: row.id,
          payload: {
            invoice_id: invoiceId,
            subscription_id: subscription.id,
          },
        });
        await this.audit.record(
          {
            entityType: 'payment',
            entityId: row.id,
            action: 'failed',
            afterState: { invoice_id: invoiceId, status: 'failed' },
            domainEventId: event.id,
          },
          uow.transaction
        );
      }

      return row;
    });

    return { payment };
  }

  async refundPayment(paymentId: string, refundCents: number): Promise<Payment> {
    const payment = await getDb()('payments').where({ id: paymentId }).first();
    if (!payment) throw new AppError(404, 'Payment not found');
    if (payment.status !== 'succeeded') {
      throw new AppError(400, 'Can only refund succeeded payments');
    }

    const invoice = await this.invoiceService.getById(payment.invoice_id);
    const sub = await this.subscriptionService.getById(invoice.subscription_id);
    await this.creditService.refundToCredit(
      sub.customer_id,
      payment.amount_cents,
      refundCents
    );

    const [updated] = await getDb()('payments')
      .where({ id: paymentId })
      .update({ status: 'refunded' })
      .returning('*');
    return updated as Payment;
  }
}
