import dotenv from 'dotenv';
import { closeDb } from './config/database';
import { runBillingJob } from './jobs/billingJob';
import { runOutboxJob } from './jobs/outboxJob';
import { runRetryJob } from './jobs/retryJob';
import { WebhookService } from './services/WebhookService';

dotenv.config();

async function main(): Promise<void> {
  const command = process.argv[2];
  if (!command) {
    console.error('Usage: node dist/cli.js <billing|retry|webhooks|outbox>');
    process.exit(1);
  }

  try {
    if (command === 'billing') {
      const count = await runBillingJob();
      console.log(`billing job done, invoices generated: ${count}`);
    } else if (command === 'retry') {
      const count = await runRetryJob();
      console.log(`retry job done, attempts processed: ${count}`);
    } else if (command === 'webhooks') {
      const count = await new WebhookService().deliverPending();
      console.log(`webhook job done, delivered: ${count}`);
    } else if (command === 'outbox') {
      const count = await runOutboxJob();
      console.log(`outbox job done, delivered: ${count}`);
    } else {
      console.error(`Unknown command: ${command}`);
      process.exit(1);
    }
  } finally {
    await closeDb();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
