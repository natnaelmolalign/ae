import { OutboxService } from '../services/OutboxService';

export async function runOutboxJob(limit = 50): Promise<number> {
  return new OutboxService().processPending(limit);
}
