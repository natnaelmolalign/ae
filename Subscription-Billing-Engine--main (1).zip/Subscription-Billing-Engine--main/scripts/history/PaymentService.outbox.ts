import { getDb } from '../config/database';
import { AppError } from '../lib/errors';
import type { Payment } from '../models/Payment';
import { AuditService } from './AuditService';
import { CreditService } from './CreditService';
import { DomainEventPublisher } from './DomainEventPublisher';
import { InvoiceService } from './InvoiceService';
import { OutboxService } from './OutboxService';
import { SubscriptionService } from './SubscriptionService';

export interface ChargeOptions {
  simulateSuccess?: boolean;
  scheduleRetries?: boolean;
  idempotencyKey?: string;
  flushOutbox?: boolean;
}

export interface ChargeResult {
  payment: Payment;
}

export class PaymentService {
  constructor(
    private invoiceService = new InvoiceService(),
    private subscriptionService = new SubscriptionService(),
    private creditService = new CreditService(),
    private events = new DomainEventPublisher(),
    private audit = new AuditService(),
    private outbox = new OutboxService()
  ) {}

  async chargeInvoice(
    invoiceId: string,
    simulateSuccess = true,
    options: ChargeOptions = {}
  ): Promise<Payment> {
    const result = await this.chargeInvoiceWithEvents(invoiceId, simulateSuccess, options);
    if (options.flushOutbox !== false) {
      await this.outbox.processPending(10);
    }
    return result.payment;
  }

  async chargeInvoiceWithEvents(
    invoiceId: string,
    simulateSuccess = true,
    options: ChargeOptions = {}
  ): Promise<ChargeResult> {
    const idempotencyKey = options.idempotencyKey;
    const scheduleRetries = options.scheduleRetries ?? true;
    const db = getDb();

    const payment = await db.transaction(async (trx) => {
      const invoice = await trx('invoices').where({ id: invoiceId }).forUpdate().first();
      if (!invoice) throw new AppError(404, 'Invoice not found');
      if (idempotencyKey) {
        const existing = await trx('payments')
          .where({ invoice_id: invoiceId, idempotency_key: idempotencyKey })
          .first();
        if (existing) return existing as Payment;
      }

      if (invoice.status === 'void') {
        throw new AppError(400, 'Cannot charge voided invoice');
      }
      if (invoice.status === 'paid') {
        throw new AppError(400, 'Invoice already paid');
      }

      const subscription = await trx('subscriptions')
        .where({ id: invoice.subscription_id })
        .forUpdate()
        .first();
      if (!subscription) throw new AppError(404, 'Subscription not found');

      const status = simulateSuccess ? 'succeeded' : 'failed';
      const [row] = await trx('payments')
        .insert({
          invoice_id: invoiceId,
          amount_cents: invoice.total_cents,
          status,
          idempotency_key: idempotencyKey ?? null,
          failure_reason: simulateSuccess ? null : 'card_declined',
        })
        .returning('*');

      if (simulateSuccess) {
        await trx('invoices')
          .where({ id: invoiceId })
          .update({ status: 'paid', updated_at: trx.fn.now() });

        if (subscription.status === 'past_due') {
          await trx('subscriptions')
            .where({ id: subscription.id })
            .update({ status: 'active', updated_at: trx.fn.now() });
        }
        await trx('subscriptions')
          .where({ id: subscription.id })
          .update({ failed_payment_count: 0 });

        const event = await this.events.publish(
          {
            eventType: 'invoice.paid',
            aggregateType: 'invoice',
            aggregateId: invoiceId,
            payload: {
              invoice_id: invoiceId,
              subscription_id: subscription.id,
              amount_cents: invoice.total_cents,
            },
          },
          trx
        );
        await this.audit.record(
          {
            entityType: 'invoice',
            entityId: invoiceId,
            action: 'paid',
            afterState: { status: 'paid', payment_id: row.id },
            domainEventId: event.id,
          },
          trx
        );
      } else {
        const updated = await this.subscriptionService.bumpFailedPaymentCount(
          subscription.id,
          trx
        );

        if (Number(updated.failed_payment_count) >= 1 && updated.status === 'active') {
          await trx('subscriptions')
            .where({ id: subscription.id })
            .update({ status: 'past_due', updated_at: trx.fn.now() });
        }

        if (scheduleRetries && updated.failed_payment_count === 1) {
          const { RetryService } = await import('./RetryService');
          await new RetryService().scheduleRetries(
            subscription.id as string,
            invoiceId,
            new Date()
          );
        }

        const event = await this.events.publish(
          {
            eventType: 'payment.failed',
            aggregateType: 'payment',
            aggregateId: row.id as string,
            payload: {
              invoice_id: invoiceId,
              subscription_id: subscription.id,
            },
          },
          trx
        );
        await this.audit.record(
          {
            entityType: 'payment',
            entityId: row.id as string,
            action: 'failed',
            afterState: { invoice_id: invoiceId, status: 'failed' },
            domainEventId: event.id,
          },
          trx
        );
      }

      return row as Payment;
    });

    return { payment };
  }

  async refundPayment(paymentId: string, refundCents: number): Promise<Payment> {
    const payment = await getDb()('payments').where({ id: paymentId }).first();
    if (!payment) throw new AppError(404, 'Payment not found');
    if (payment.status !== 'succeeded') {
      throw new AppError(400, 'Can only refund succeeded payments');
    }

    const invoice = await this.invoiceService.getById(payment.invoice_id);
    const sub = await this.subscriptionService.getById(invoice.subscription_id);
    await this.creditService.refundToCredit(
      sub.customer_id,
      payment.amount_cents,
      refundCents
    );

    const [updated] = await getDb()('payments')
      .where({ id: paymentId })
      .update({ status: 'refunded' })
      .returning('*');
    return updated as Payment;
  }
}
