import { getDb } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import type { Payment } from '../models/Payment';
import { CreditService } from './CreditService';
import { InvoiceService } from './InvoiceService';
import { SubscriptionService } from './SubscriptionService';

export interface ChargeOptions {
  simulateSuccess?: boolean;
  scheduleRetries?: boolean;
}

export class PaymentService {
  constructor(
    private invoiceService = new InvoiceService(),
    private subscriptionService = new SubscriptionService(),
    private creditService = new CreditService()
  ) {}

  async chargeInvoice(
    invoiceId: string,
    simulateSuccess = true,
    options: ChargeOptions = {}
  ): Promise<Payment> {
    const scheduleRetries = options.scheduleRetries ?? true;
    const invoice = await this.invoiceService.getById(invoiceId);
    if (invoice.status === 'void') {
      throw new AppError(400, 'Cannot charge voided invoice');
    }
    if (invoice.status === 'paid') {
      throw new AppError(400, 'Invoice already paid');
    }

    const subscription = await this.subscriptionService.getById(
      invoice.subscription_id
    );

    const status = simulateSuccess ? 'succeeded' : 'failed';
    const [payment] = await getDb()('payments')
      .insert({
        invoice_id: invoiceId,
        amount_cents: invoice.total_cents,
        status,
        failure_reason: simulateSuccess ? null : 'card_declined',
      })
      .returning('*');

    if (simulateSuccess) {
      await this.invoiceService.markPaid(invoiceId);
      if (subscription.status === 'past_due') {
        await this.subscriptionService.transition(subscription.id, 'active');
      }
      await getDb()('subscriptions')
        .where({ id: subscription.id })
        .update({ failed_payment_count: 0 });
    } else {
      await this.subscriptionService.recordFailedPayment(subscription.id);
    }

    return payment as Payment;
  }

  async refundPayment(
    paymentId: string,
    refundCents: number
  ): Promise<Payment> {
    const payment = await getDb()('payments').where({ id: paymentId }).first();
    if (!payment) throw new AppError(404, 'Payment not found');
    if (payment.status !== 'succeeded') {
      throw new AppError(400, 'Can only refund succeeded payments');
    }

    const invoice = await this.invoiceService.getById(payment.invoice_id);
    const sub = await this.subscriptionService.getById(invoice.subscription_id);
    await this.creditService.refundToCredit(
      sub.customer_id,
      payment.amount_cents,
      refundCents
    );

    const [updated] = await getDb()('payments')
      .where({ id: paymentId })
      .update({ status: 'refunded' })
      .returning('*');
    return updated as Payment;
  }
}
