# Verify each commit compiles (tsc) in chronological order.
$ErrorActionPreference = 'Stop'
$commits = git rev-list --reverse HEAD
$failed = @()
$i = 0

$stashName = 'verify-commit-history-temp'
$hadStash = $false
$porcelain = git status --porcelain
if ($porcelain) {
    git stash push -u -m $stashName 2>&1 | Out-Null
    $hadStash = $true
    Write-Host 'Stashed working tree changes for verification.'
}

foreach ($c in $commits) {
    $i++
    $subj = git log -1 --format='%s' $c
    git checkout $c --quiet 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) {
        $failed += "$subj (checkout failed)"
        Write-Host "FAIL [$i] $subj (checkout)"
        continue
    }
    $hasSrc = git ls-tree -r --name-only $c | Where-Object { $_ -match '^src/.+\.ts$' }
    if (-not $hasSrc) {
        Write-Host "SKIP [$i] $subj (no src)"
        continue
    }
    git clean -fd -e node_modules 2>$null | Out-Null
    npm run build 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) {
        $failed += $subj
        Write-Host "FAIL [$i] $subj"
    }
}

git checkout main --quiet 2>&1 | Out-Null
if ($hadStash) {
    git stash pop 2>&1 | Out-Null
    Write-Host 'Restored stashed working tree changes.'
}

if ($failed.Count -gt 0) {
    Write-Host "`n$($failed.Count) commits failed to compile."
    exit 1
}
Write-Host "All $($commits.Count) commits compile."
