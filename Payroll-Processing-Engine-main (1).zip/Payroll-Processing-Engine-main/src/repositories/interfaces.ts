import type { Knex } from 'knex';
import type {
  BenefitEnrollment,
  CreateBenefitEnrollmentInput,
  UpdateBenefitEnrollmentInput,
} from '../models/BenefitEnrollment';
import type {
  CreateGarnishmentOrderInput,
  GarnishmentOrder,
  GarnishmentRemittance,
  UpdateGarnishmentOrderInput,
} from '../models/GarnishmentOrder';
import type { AuditEvent, CreateAuditEventInput } from '../models/AuditEvent';
import type {
  EmployeePayrollReadinessStatus,
  PayrollBatch,
  PayrollRunFailure,
} from '../models/PayrollBatch';
import type {
  RetroAdjustmentPreview,
  RetroAdjustmentRecord,
  RetroAdjustmentStatus,
} from '../models/RetroAdjustment';
import type {
  CreateEmployeeInput,
  Employee,
  EarningsLine,
  PayPeriod,
  PayStub,
  PayrollRunResult,
  TimeEntry,
  YearToDate,
} from '../models/types';

export type DbTrx = Knex.Transaction;

export interface GarnishmentOrderRepository {
  create(input: CreateGarnishmentOrderInput): Promise<GarnishmentOrder>;
  findById(id: string): Promise<GarnishmentOrder | null>;
  findByEmployee(employeeId: string): Promise<GarnishmentOrder[]>;
  findActiveForEmployee(
    employeeId: string,
    asOfDate: string
  ): Promise<GarnishmentOrder[]>;
  update(
    id: string,
    input: UpdateGarnishmentOrderInput
  ): Promise<GarnishmentOrder | null>;
  delete(id: string): Promise<boolean>;
}

export interface BenefitEnrollmentRepository {
  create(input: CreateBenefitEnrollmentInput): Promise<BenefitEnrollment>;
  findById(id: string): Promise<BenefitEnrollment | null>;
  findByEmployee(employeeId: string): Promise<BenefitEnrollment[]>;
  findActiveForEmployee(
    employeeId: string,
    asOfDate: string
  ): Promise<BenefitEnrollment[]>;
  update(
    id: string,
    input: UpdateBenefitEnrollmentInput
  ): Promise<BenefitEnrollment | null>;
  delete(id: string): Promise<boolean>;
}

export interface EmployeeRepository {
  create(input: CreateEmployeeInput): Promise<Employee>;
  findById(id: string, trx?: DbTrx): Promise<Employee | null>;
  listByCompany(companyId: string): Promise<Employee[]>;
  updateW4Fields(
    id: string,
    companyId: string,
    fields: {
      filingStatus: Employee['filingStatus'];
      w4ExtraWithholding: string;
      w4DependentsCredit: string;
      w4OtherDeductions: string;
      w4OtherIncome: string;
      w4MultipleJobs: boolean;
    }
  ): Promise<Employee | null>;
}

export interface PayPeriodRepository {
  upsertMany(periods: PayPeriod[], trx?: DbTrx): Promise<void>;
  findByYearAndFrequency(
    year: number,
    frequency: string,
    companyId: string,
    trx?: DbTrx
  ): Promise<PayPeriod[]>;
  findById(id: string, trx?: DbTrx): Promise<PayPeriod | null>;
}

export interface PayStubRepository {
  insert(stub: PayStub, trx: DbTrx): Promise<void>;
  findById(id: string, trx?: DbTrx): Promise<PayStub | null>;
  findByEmployeeAndPeriod(
    employeeId: string,
    payPeriodId: string,
    trx?: DbTrx
  ): Promise<PayStub | null>;
  findOriginalByEmployeeAndPeriod(
    employeeId: string,
    payPeriodId: string,
    trx?: DbTrx
  ): Promise<PayStub | null>;
  listByEmployee(employeeId: string): Promise<PayStub[]>;
}

export interface RetroAdjustmentRepository {
  create(
    input: Omit<
      RetroAdjustmentRecord,
      'preview' | 'catchUpPayStubId' | 'createdAt' | 'updatedAt'
    >,
    trx?: DbTrx
  ): Promise<RetroAdjustmentRecord>;
  findById(id: string, trx?: DbTrx): Promise<RetroAdjustmentRecord | null>;
  update(
    id: string,
    patch: Partial<{
      status: RetroAdjustmentStatus;
      preview: RetroAdjustmentPreview | null;
      catchUpPayStubId: string | null;
    }>,
    trx?: DbTrx
  ): Promise<RetroAdjustmentRecord | null>;
}

export interface TimeEntryRepository {
  insert(entry: TimeEntry): Promise<void>;
  findByEmployee(employeeId: string): Promise<TimeEntry[]>;
  findByPayPeriod(
    employeeId: string,
    payPeriodId: string
  ): Promise<TimeEntry[]>;
  findByShiftAssignment(shiftAssignmentId: string): Promise<TimeEntry[]>;
}

export interface ShiftRepository {
  create(
    input: Omit<
      import('../models/WorkforceScheduling').Shift,
      'id' | 'createdAt' | 'updatedAt'
    >
  ): Promise<import('../models/WorkforceScheduling').Shift>;
  findById(
    id: string,
    companyId: string
  ): Promise<import('../models/WorkforceScheduling').Shift | null>;
  listByCompany(
    companyId: string,
    workDate?: string
  ): Promise<import('../models/WorkforceScheduling').Shift[]>;
}

export interface ShiftAssignmentRepository {
  create(
    input: Omit<
      import('../models/WorkforceScheduling').ShiftAssignment,
      'id' | 'createdAt' | 'updatedAt'
    >
  ): Promise<import('../models/WorkforceScheduling').ShiftAssignment>;
  findById(
    id: string,
    companyId: string,
    trx?: DbTrx
  ): Promise<import('../models/WorkforceScheduling').ShiftAssignment | null>;
  update(
    id: string,
    companyId: string,
    patch: Partial<
      Pick<
        import('../models/WorkforceScheduling').ShiftAssignment,
        | 'status'
        | 'approvedMinutes'
        | 'approvedAt'
        | 'approvedBy'
        | 'payrollRunId'
      >
    >,
    trx?: DbTrx
  ): Promise<import('../models/WorkforceScheduling').ShiftAssignment>;
  list(
    companyId: string,
    filters: {
      employeeId?: string;
      shiftId?: string;
      status?: import('../models/WorkforceScheduling').ShiftAssignmentStatus;
    }
  ): Promise<import('../models/WorkforceScheduling').ShiftAssignment[]>;
  listForEmployeeInPeriod(
    employeeId: string,
    companyId: string,
    periodStart: string,
    periodEnd: string,
    trx?: DbTrx
  ): Promise<import('../models/WorkforceScheduling').ShiftAssignment[]>;
}

export interface TimeExceptionRepository {
  create(
    input: Omit<
      import('../models/WorkforceScheduling').TimeException,
      'id' | 'createdAt'
    >
  ): Promise<import('../models/WorkforceScheduling').TimeException>;
}

export interface YtdRepository {
  getForUpdate(
    trx: DbTrx,
    employeeId: string,
    taxYear: number
  ): Promise<YearToDate>;
  get(employeeId: string, taxYear: number): Promise<YearToDate>;
  save(trx: DbTrx, ytd: YearToDate): Promise<void>;
}

export interface PayrollRunRecord {
  id: string;
  employeeId: string;
  payPeriodId: string;
  payStubId: string;
  isCorrection: boolean;
  idempotencyKey: string | null;
}

export interface PayrollRunRepository {
  findByEmployeePeriodAndCorrection(
    trx: DbTrx,
    employeeId: string,
    payPeriodId: string,
    isCorrection: boolean
  ): Promise<PayrollRunRecord | null>;
  findByIdempotencyKey(
    trx: DbTrx,
    key: string
  ): Promise<PayrollRunRecord | null>;
  insert(
    trx: DbTrx,
    record: PayrollRunRecord,
    result: PayrollRunResult,
    earnings: EarningsLine[],
    remittances?: Omit<GarnishmentRemittance, 'id' | 'createdAt'>[]
  ): Promise<void>;
}

export interface PayrollBatchRepository {
  create(
    batch: Omit<PayrollBatch, 'createdAt' | 'updatedAt'>
  ): Promise<PayrollBatch>;
  findById(id: string): Promise<PayrollBatch | null>;
  update(
    id: string,
    patch: Partial<
      Pick<
        PayrollBatch,
        | 'status'
        | 'startedAt'
        | 'completedAt'
        | 'successCount'
        | 'failureCount'
        | 'totalCount'
        | 'durationMs'
      >
    >
  ): Promise<PayrollBatch | null>;
}

export interface PayrollRunFailureRepository {
  insert(
    failure: Omit<PayrollRunFailure, 'createdAt'>
  ): Promise<PayrollRunFailure>;
  findByBatchId(batchId: string): Promise<PayrollRunFailure[]>;
}

export interface AuditEventRepository {
  append(input: CreateAuditEventInput): Promise<AuditEvent>;
  findByEntity(entityType: string, entityId: string): Promise<AuditEvent[]>;
  deleteOlderThan(cutoffIso: string): Promise<number>;
}

export interface EmployeeWorkLocationRepository {
  replaceForEmployee(
    employeeId: string,
    locations: import('../models/WorkLocationAllocation').CreateWorkLocationInput[]
  ): Promise<import('../models/WorkLocationAllocation').EmployeeWorkLocation[]>;
  findActiveByEmployee(
    employeeId: string
  ): Promise<import('../models/WorkLocationAllocation').EmployeeWorkLocation[]>;
}

export interface EmployeePayrollReadinessRepository {
  upsertReady(employeeId: string, payPeriodId: string): Promise<void>;
  markProcessed(employeeId: string, payPeriodId: string): Promise<void>;
  findReadyEmployeeIds(payPeriodId: string): Promise<string[]>;
  setStatus(
    employeeId: string,
    payPeriodId: string,
    status: EmployeePayrollReadinessStatus
  ): Promise<void>;
}

export interface WebhookSubscriptionRepository {
  create(
    input: import('../models/Webhook').CreateWebhookSubscriptionInput
  ): Promise<import('../models/Webhook').WebhookSubscription>;
  findById(
    id: string
  ): Promise<import('../models/Webhook').WebhookSubscription | null>;
  findByCompany(
    companyId: string
  ): Promise<import('../models/Webhook').WebhookSubscription[]>;
  findActiveForEvent(
    companyId: string,
    eventType: import('../config/webhooks').WebhookEventType,
    trx?: DbTrx
  ): Promise<import('../models/Webhook').WebhookSubscription[]>;
  update(
    id: string,
    input: import('../models/Webhook').UpdateWebhookSubscriptionInput
  ): Promise<import('../models/Webhook').WebhookSubscription | null>;
  recordDeliveryFailure(
    trx: DbTrx,
    subscriptionId: string,
    threshold: number
  ): Promise<void>;
  resetFailures(trx: DbTrx, subscriptionId: string): Promise<void>;
  delete(id: string): Promise<boolean>;
}

export interface WebhookOutboxRepository {
  insert(
    trx: DbTrx,
    input: {
      subscriptionId: string;
      companyId: string;
      eventType: import('../config/webhooks').WebhookEventType;
      payload: Record<string, unknown>;
    }
  ): Promise<import('../models/Webhook').WebhookOutboxEntry>;
  findPending(
    limit: number
  ): Promise<import('../models/Webhook').WebhookOutboxEntry[]>;
  markDelivered(trx: DbTrx, id: string): Promise<void>;
  markRetry(
    trx: DbTrx,
    id: string,
    attempts: number,
    nextAttemptAt: string
  ): Promise<void>;
  markFailed(trx: DbTrx, id: string, attempts: number): Promise<void>;
}

export interface WebhookDeliveryRepository {
  insert(
    trx: DbTrx,
    input: {
      outboxId: string;
      attemptNumber: number;
      httpStatus: number | null;
      errorMessage: string | null;
    }
  ): Promise<import('../models/Webhook').WebhookDelivery>;
}

export interface DeductionScheduleRepository {
  create(
    input: import('../models/DeductionSchedule').CreateDeductionScheduleInput
  ): Promise<import('../models/DeductionSchedule').DeductionSchedule>;
  findById(
    id: string
  ): Promise<import('../models/DeductionSchedule').DeductionSchedule | null>;
  findByEmployee(
    employeeId: string
  ): Promise<import('../models/DeductionSchedule').DeductionSchedule[]>;
  findActiveForEmployee(
    employeeId: string,
    asOfDate: string
  ): Promise<import('../models/DeductionSchedule').DeductionSchedule[]>;
  update(
    id: string,
    input: import('../models/DeductionSchedule').UpdateDeductionScheduleInput
  ): Promise<import('../models/DeductionSchedule').DeductionSchedule | null>;
  updateRemainingBalance(
    trx: DbTrx,
    id: string,
    remainingBalance: string | null
  ): Promise<void>;
  delete(id: string): Promise<boolean>;
}

export interface DepartmentRepository {
  create(
    input: Omit<
      import('../models/CostAccounting').Department,
      'id' | 'createdAt' | 'updatedAt' | 'isSystem'
    > & { isSystem?: boolean }
  ): Promise<import('../models/CostAccounting').Department>;
  findById(
    id: string,
    companyId: string
  ): Promise<import('../models/CostAccounting').Department | null>;
  findByCode(
    companyId: string,
    code: string
  ): Promise<import('../models/CostAccounting').Department | null>;
  listByCompany(
    companyId: string
  ): Promise<import('../models/CostAccounting').Department[]>;
}

export interface JobRepository {
  create(
    input: Omit<
      import('../models/CostAccounting').Job,
      'id' | 'createdAt' | 'updatedAt'
    >
  ): Promise<import('../models/CostAccounting').Job>;
  findById(
    id: string,
    companyId: string
  ): Promise<import('../models/CostAccounting').Job | null>;
  listByDepartment(
    departmentId: string,
    companyId: string
  ): Promise<import('../models/CostAccounting').Job[]>;
}

export interface PayrollRunAllocationRepository {
  insertMany(
    trx: DbTrx,
    rows: Omit<
      import('../models/CostAccounting').PayrollRunAllocation,
      'id' | 'createdAt' | 'updatedAt'
    >[]
  ): Promise<void>;
  findByPayrollRun(
    payrollRunId: string
  ): Promise<import('../models/CostAccounting').PayrollRunAllocation[]>;
  findSegmentsForRuns(
    payrollRunIds: string[]
  ): Promise<
    Map<string, import('../models/CostAccounting').CostAllocationSegment[]>
  >;
}

export interface PayPolicyRepository {
  create(
    input: Omit<
      import('../models/PayPolicy').PayPolicy,
      'id' | 'createdAt' | 'updatedAt'
    >
  ): Promise<import('../models/PayPolicy').PayPolicy>;
  update(
    id: string,
    companyId: string,
    patch: Partial<
      Pick<
        import('../models/PayPolicy').PayPolicy,
        | 'name'
        | 'rules'
        | 'effectiveFrom'
        | 'effectiveTo'
        | 'isActive'
        | 'priority'
      >
    >
  ): Promise<import('../models/PayPolicy').PayPolicy | null>;
  findById(
    id: string,
    companyId: string
  ): Promise<import('../models/PayPolicy').PayPolicy | null>;
  listByCompany(
    companyId: string
  ): Promise<import('../models/PayPolicy').PayPolicy[]>;
  findActiveForRun(
    companyId: string,
    employeeId: string,
    paymentDate: string
  ): Promise<import('../models/PayPolicy').PayPolicy[]>;
}

export interface LeavePolicyRepository {
  create(
    input: Omit<
      import('../models/LeavePolicy').LeavePolicy,
      'id' | 'createdAt' | 'updatedAt'
    >
  ): Promise<import('../models/LeavePolicy').LeavePolicy>;
  update(
    id: string,
    companyId: string,
    patch: Partial<
      Pick<
        import('../models/LeavePolicy').LeavePolicy,
        | 'name'
        | 'accrualConfig'
        | 'carryoverMaxHours'
        | 'effectiveFrom'
        | 'effectiveTo'
        | 'isActive'
      >
    >
  ): Promise<import('../models/LeavePolicy').LeavePolicy | null>;
  findById(
    id: string,
    companyId: string
  ): Promise<import('../models/LeavePolicy').LeavePolicy | null>;
  listByCompany(
    companyId: string
  ): Promise<import('../models/LeavePolicy').LeavePolicy[]>;
  findActiveByType(
    companyId: string,
    leaveType: import('../models/LeavePolicy').LeaveType,
    paymentDate: string,
    trx?: DbTrx
  ): Promise<import('../models/LeavePolicy').LeavePolicy | null>;
  listActiveForAccrual(
    companyId: string,
    paymentDate: string
  ): Promise<import('../models/LeavePolicy').LeavePolicy[]>;
}

export interface LeaveBalanceRepository {
  getOrCreate(
    trx: DbTrx,
    input: {
      companyId: string;
      employeeId: string;
      leaveType: import('../models/LeavePolicy').LeaveType;
      policyId: string;
      calendarYear: number;
    }
  ): Promise<import('../models/LeavePolicy').LeaveBalance>;
  getForUpdate(
    trx: DbTrx,
    employeeId: string,
    leaveType: import('../models/LeavePolicy').LeaveType,
    calendarYear: number
  ): Promise<import('../models/LeavePolicy').LeaveBalance | null>;
  save(
    trx: DbTrx,
    balance: import('../models/LeavePolicy').LeaveBalance
  ): Promise<void>;
  listByEmployee(
    employeeId: string,
    companyId: string,
    calendarYear?: number
  ): Promise<import('../models/LeavePolicy').LeaveBalance[]>;
}

export interface LeaveTransactionRepository {
  insert(
    trx: DbTrx,
    row: Omit<
      import('../models/LeavePolicy').LeaveTransaction,
      'id' | 'createdAt'
    >
  ): Promise<import('../models/LeavePolicy').LeaveTransaction>;
  findAccrualForPeriod(
    trx: DbTrx,
    employeeId: string,
    policyId: string,
    payPeriodId: string
  ): Promise<import('../models/LeavePolicy').LeaveTransaction | null>;
  listByEmployee(
    employeeId: string,
    companyId: string,
    calendarYear?: number
  ): Promise<import('../models/LeavePolicy').LeaveTransaction[]>;
}

export interface EnrollmentWindowRepository {
  create(
    input: import('../models/BenefitsLifecycle').CreateEnrollmentWindowInput
  ): Promise<import('../models/BenefitsLifecycle').EnrollmentWindow>;
  findById(
    id: string,
    companyId: string
  ): Promise<import('../models/BenefitsLifecycle').EnrollmentWindow | null>;
  listByCompany(
    companyId: string
  ): Promise<import('../models/BenefitsLifecycle').EnrollmentWindow[]>;
  findOpenForDate(
    companyId: string,
    asOfDate: string,
    benefitType: import('../models/types').DeductionType
  ): Promise<import('../models/BenefitsLifecycle').EnrollmentWindow | null>;
  updateStatus(
    id: string,
    companyId: string,
    status: import('../models/BenefitsLifecycle').EnrollmentWindowStatus
  ): Promise<import('../models/BenefitsLifecycle').EnrollmentWindow | null>;
}

export interface EligibilityRuleRepository {
  create(
    input: import('../models/BenefitsLifecycle').CreateEligibilityRuleInput
  ): Promise<import('../models/BenefitsLifecycle').EligibilityRule>;
  findActiveForType(
    companyId: string,
    benefitType: import('../models/types').DeductionType
  ): Promise<import('../models/BenefitsLifecycle').EligibilityRule | null>;
  listByCompany(
    companyId: string
  ): Promise<import('../models/BenefitsLifecycle').EligibilityRule[]>;
}

export interface LifeEventRepository {
  create(
    input: import('../models/BenefitsLifecycle').CreateLifeEventInput
  ): Promise<import('../models/BenefitsLifecycle').LifeEvent>;
  findById(
    id: string,
    companyId: string
  ): Promise<import('../models/BenefitsLifecycle').LifeEvent | null>;
  listByEmployee(
    employeeId: string,
    companyId: string
  ): Promise<import('../models/BenefitsLifecycle').LifeEvent[]>;
  updateStatus(
    id: string,
    companyId: string,
    status: import('../models/BenefitsLifecycle').LifeEventStatus,
    patch: {
      approvedAt?: string | null;
      approvedBy?: string | null;
      cobraScheduleId?: string | null;
    }
  ): Promise<import('../models/BenefitsLifecycle').LifeEvent | null>;
}

export interface DisbursementInstructionRepository {
  create(
    input: import('../models/Disbursement').CreateDisbursementInstructionInput
  ): Promise<import('../models/Disbursement').DisbursementInstruction>;
  findById(
    id: string,
    companyId: string
  ): Promise<import('../models/Disbursement').DisbursementInstruction | null>;
  findActiveByEmployee(
    employeeId: string,
    companyId: string
  ): Promise<import('../models/Disbursement').DisbursementInstruction[]>;
  listByEmployee(
    employeeId: string,
    companyId: string
  ): Promise<import('../models/Disbursement').DisbursementInstruction[]>;
  update(
    id: string,
    companyId: string,
    input: import('../models/Disbursement').UpdateDisbursementInstructionInput
  ): Promise<import('../models/Disbursement').DisbursementInstruction | null>;
  delete(id: string, companyId: string): Promise<boolean>;
}

export interface DisbursementBatchRepository {
  createBatch(
    input: Omit<
      import('../models/Disbursement').PaymentBatch,
      'createdAt' | 'updatedAt' | 'submittedAt'
    >
  ): Promise<import('../models/Disbursement').PaymentBatch>;
  findBatchById(
    id: string,
    companyId: string
  ): Promise<import('../models/Disbursement').PaymentBatch | null>;
  findBatchByIdempotencyKey(
    companyId: string,
    key: string
  ): Promise<import('../models/Disbursement').PaymentBatch | null>;
  updateBatchStatus(
    id: string,
    companyId: string,
    status: import('../models/Disbursement').PaymentBatchStatus,
    submittedAt?: string | null
  ): Promise<import('../models/Disbursement').PaymentBatch | null>;
  insertItems(
    items: Omit<
      import('../models/Disbursement').PaymentBatchItem,
      'createdAt' | 'updatedAt'
    >[]
  ): Promise<void>;
  listItemsByBatch(
    batchId: string
  ): Promise<import('../models/Disbursement').PaymentBatchItem[]>;
  updateItemStatuses(
    batchId: string,
    status: import('../models/Disbursement').PaymentBatchItemStatus
  ): Promise<void>;
  saveAchFile(
    file: Omit<import('../models/Disbursement').AchFile, 'createdAt'>
  ): Promise<import('../models/Disbursement').AchFile>;
  findAchFileByBatch(
    batchId: string
  ): Promise<import('../models/Disbursement').AchFile | null>;
  listPayrollRunsForPeriod(
    companyId: string,
    payPeriodId: string
  ): Promise<
    {
      payrollRunId: string;
      payStubId: string;
      employeeId: string;
      netPay: string;
      firstName: string;
      lastName: string;
    }[]
  >;
  listPayrollRunsByIds(
    companyId: string,
    payrollRunIds: string[]
  ): Promise<
    {
      payrollRunId: string;
      payStubId: string;
      employeeId: string;
      netPay: string;
      firstName: string;
      lastName: string;
    }[]
  >;
}

export interface ExportBatchRecord {
  id: string;
  company_id: string;
  connection_id: string;
  pay_period_id: string;
  connector_type: string;
  status: string;
  idempotency_key: string;
  mapping_version: number;
  mapping_snapshot: string;
  connector_payload: string;
  external_journal_ids: string;
  submitted_at: string;
  created_at: string;
  updated_at: string;
}

export interface ErpConnectorRepository {
  createConnection(
    input: import('../models/ErpConnector').CreateIntegrationConnectionInput
  ): Promise<import('../models/ErpConnector').IntegrationConnection>;
  findConnectionById(
    id: string,
    companyId: string
  ): Promise<import('../models/ErpConnector').IntegrationConnection | null>;
  listConnections(
    companyId: string
  ): Promise<import('../models/ErpConnector').IntegrationConnection[]>;
  getLatestMappingVersion(connectionId: string): Promise<number>;
  publishMappings(
    companyId: string,
    connectionId: string,
    mappings: import('../models/ErpConnector').GlMappingEntry[]
  ): Promise<{
    version: number;
    mappings: import('../models/ErpConnector').GlAccountMapping[];
  }>;
  getMappingsForVersion(
    connectionId: string,
    version: number
  ): Promise<import('../models/ErpConnector').GlMappingEntry[]>;
  getActiveMappings(connectionId: string): Promise<{
    version: number;
    mappings: import('../models/ErpConnector').GlMappingEntry[];
  }>;
  findExportByIdempotencyKey(
    connectionId: string,
    idempotencyKey: string
  ): Promise<import('../models/ErpConnector').ExportBatch | null>;
  saveExportBatch(
    batch: Omit<
      import('../models/ErpConnector').ExportBatch,
      'createdAt' | 'updatedAt'
    >
  ): Promise<import('../models/ErpConnector').ExportBatch>;
  findExportById(
    id: string,
    companyId: string
  ): Promise<import('../models/ErpConnector').ExportBatch | null>;
}

export interface W4ChangeRequestRepository {
  create(
    input: import('../models/EmployeeEss').CreateW4ChangeRequestInput
  ): Promise<import('../models/EmployeeEss').W4ChangeRequest>;
  findById(
    id: string,
    companyId: string
  ): Promise<import('../models/EmployeeEss').W4ChangeRequest | null>;
  listByEmployee(
    employeeId: string,
    companyId: string
  ): Promise<import('../models/EmployeeEss').W4ChangeRequest[]>;
  listByStatus(
    companyId: string,
    status: import('../models/EmployeeEss').W4ChangeRequestStatus
  ): Promise<import('../models/EmployeeEss').W4ChangeRequest[]>;
  updateStatus(
    id: string,
    companyId: string,
    status: import('../models/EmployeeEss').W4ChangeRequestStatus,
    patch: {
      submittedAt?: string | null;
      reviewedAt?: string | null;
      reviewedBy?: string | null;
      appliedAt?: string | null;
      reviewNotes?: string | null;
    }
  ): Promise<import('../models/EmployeeEss').W4ChangeRequest | null>;
}

export interface PayrollControlRepository {
  createHold(
    input: import('../models/PayrollControl').CreatePayrollHoldInput
  ): Promise<import('../models/PayrollControl').PayrollHold>;
  findHoldById(
    id: string,
    companyId: string
  ): Promise<import('../models/PayrollControl').PayrollHold | null>;
  findActiveHoldForEmployee(
    employeeId: string,
    companyId: string
  ): Promise<import('../models/PayrollControl').PayrollHold | null>;
  releaseHold(
    id: string,
    companyId: string,
    releasedBy: string,
    releaseReason: string
  ): Promise<import('../models/PayrollControl').PayrollHold | null>;
  listActiveHolds(
    companyId: string
  ): Promise<import('../models/PayrollControl').PayrollHold[]>;
  saveAnomalyFlag(
    flag: Omit<
      import('../models/PayrollControl').AnomalyFlag,
      'id' | 'createdAt'
    >
  ): Promise<import('../models/PayrollControl').AnomalyFlag>;
  createApprovalRequest(
    input: Omit<
      import('../models/PayrollControl').ApprovalRequest,
      | 'id'
      | 'status'
      | 'reviewedBy'
      | 'reviewedAt'
      | 'reviewNotes'
      | 'createdAt'
      | 'updatedAt'
    >
  ): Promise<import('../models/PayrollControl').ApprovalRequest>;
  findApprovalById(
    id: string,
    companyId: string
  ): Promise<import('../models/PayrollControl').ApprovalRequest | null>;
  findPendingApprovalForEmployeePeriod(
    employeeId: string,
    payPeriodId: string,
    companyId: string
  ): Promise<import('../models/PayrollControl').ApprovalRequest | null>;
  findApprovedApprovalForEmployeePeriod(
    employeeId: string,
    payPeriodId: string,
    companyId: string
  ): Promise<import('../models/PayrollControl').ApprovalRequest | null>;
  updateApprovalStatus(
    id: string,
    companyId: string,
    status: import('../models/PayrollControl').ApprovalRequestStatus,
    reviewedBy: string,
    reviewNotes?: string
  ): Promise<import('../models/PayrollControl').ApprovalRequest | null>;
}
