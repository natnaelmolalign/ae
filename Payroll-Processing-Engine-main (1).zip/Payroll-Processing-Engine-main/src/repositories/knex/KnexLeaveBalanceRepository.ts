import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type { LeaveBalance, LeaveType } from '../../models/LeavePolicy';
import type { DbTrx, LeaveBalanceRepository } from '../interfaces';

interface LeaveBalanceRow {
  id: string;
  company_id: string;
  employee_id: string;
  leave_type: LeaveType;
  policy_id: string;
  calendar_year: number;
  balance_hours: string;
  created_at: string;
  updated_at: string;
}

function fromRow(row: LeaveBalanceRow): LeaveBalance {
  return {
    id: row.id,
    companyId: row.company_id,
    employeeId: row.employee_id,
    leaveType: row.leave_type,
    policyId: row.policy_id,
    calendarYear: row.calendar_year,
    balanceHours: row.balance_hours,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class KnexLeaveBalanceRepository implements LeaveBalanceRepository {
  constructor(private readonly db: Knex) {}

  async getOrCreate(
    trx: DbTrx,
    input: {
      companyId: string;
      employeeId: string;
      leaveType: LeaveType;
      policyId: string;
      calendarYear: number;
    }
  ): Promise<LeaveBalance> {
    const existing = await trx('leave_balances')
      .where({
        employee_id: input.employeeId,
        leave_type: input.leaveType,
        calendar_year: input.calendarYear,
      })
      .forUpdate()
      .first();
    if (existing) {
      return fromRow(existing as LeaveBalanceRow);
    }
    const now = new Date().toISOString();
    const row: LeaveBalanceRow = {
      id: randomUUID(),
      company_id: input.companyId,
      employee_id: input.employeeId,
      leave_type: input.leaveType,
      policy_id: input.policyId,
      calendar_year: input.calendarYear,
      balance_hours: '0.00',
      created_at: now,
      updated_at: now,
    };
    await trx('leave_balances').insert(row);
    return fromRow(row);
  }

  async getForUpdate(
    trx: DbTrx,
    employeeId: string,
    leaveType: LeaveType,
    calendarYear: number
  ): Promise<LeaveBalance | null> {
    const row = await trx('leave_balances')
      .where({
        employee_id: employeeId,
        leave_type: leaveType,
        calendar_year: calendarYear,
      })
      .forUpdate()
      .first();
    return row ? fromRow(row as LeaveBalanceRow) : null;
  }

  async save(trx: DbTrx, balance: LeaveBalance): Promise<void> {
    await trx('leave_balances').where({ id: balance.id }).update({
      balance_hours: balance.balanceHours,
      policy_id: balance.policyId,
      updated_at: new Date().toISOString(),
    });
  }

  async listByEmployee(
    employeeId: string,
    companyId: string,
    calendarYear?: number
  ): Promise<LeaveBalance[]> {
    let q = this.db('leave_balances').where({
      employee_id: employeeId,
      company_id: companyId,
    });
    if (calendarYear !== undefined) {
      q = q.andWhere({ calendar_year: calendarYear });
    }
    const rows = await q.orderBy('leave_type', 'asc');
    return rows.map((r) => fromRow(r as LeaveBalanceRow));
  }
}
