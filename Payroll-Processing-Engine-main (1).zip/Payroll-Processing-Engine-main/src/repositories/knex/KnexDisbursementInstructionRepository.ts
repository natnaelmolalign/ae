import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  CreateDisbursementInstructionInput,
  DisbursementInstruction,
  UpdateDisbursementInstructionInput,
} from '../../models/Disbursement';
import type { DisbursementInstructionRepository } from '../interfaces';
import { tokenizeBankAccount } from '../../utils/AccountTokenizer';

interface Row {
  id: string;
  company_id: string;
  employee_id: string;
  split_type: string;
  percent: string | null;
  fixed_amount: string | null;
  priority: number;
  routing_number: string;
  account_number_token: string;
  account_last_four: string;
  account_type: string;
  is_active: boolean | number;
  created_at: string;
  updated_at: string;
}

function fromRow(row: Row): DisbursementInstruction {
  return {
    id: row.id,
    companyId: row.company_id,
    employeeId: row.employee_id,
    splitType: row.split_type as DisbursementInstruction['splitType'],
    percent: row.percent,
    fixedAmount: row.fixed_amount,
    priority: row.priority,
    routingNumber: row.routing_number,
    accountNumberToken: row.account_number_token,
    accountLastFour: row.account_last_four,
    accountType: row.account_type as DisbursementInstruction['accountType'],
    isActive: Boolean(row.is_active),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class KnexDisbursementInstructionRepository
  implements DisbursementInstructionRepository
{
  constructor(private readonly db: Knex) {}

  async create(
    input: CreateDisbursementInstructionInput
  ): Promise<DisbursementInstruction> {
    const { token, lastFour } = tokenizeBankAccount(input.accountNumber);
    const now = new Date().toISOString();
    const row: Row = {
      id: randomUUID(),
      company_id: input.companyId,
      employee_id: input.employeeId,
      split_type: input.splitType,
      percent: input.percent ?? null,
      fixed_amount: input.fixedAmount ?? null,
      priority: input.priority ?? 0,
      routing_number: input.routingNumber.replace(/\D/g, '').slice(0, 9),
      account_number_token: token,
      account_last_four: lastFour,
      account_type: input.accountType ?? 'checking',
      is_active: input.isActive ?? true,
      created_at: now,
      updated_at: now,
    };
    await this.db('disbursement_instructions').insert(row);
    return fromRow(row);
  }

  async findById(
    id: string,
    companyId: string
  ): Promise<DisbursementInstruction | null> {
    const row = await this.db('disbursement_instructions')
      .where({ id, company_id: companyId })
      .first();
    return row ? fromRow(row as Row) : null;
  }

  async findActiveByEmployee(
    employeeId: string,
    companyId: string
  ): Promise<DisbursementInstruction[]> {
    const rows = await this.db('disbursement_instructions')
      .where({
        employee_id: employeeId,
        company_id: companyId,
        is_active: true,
      })
      .orderBy('priority', 'asc');
    return rows.map((r) => fromRow(r as Row));
  }

  async listByEmployee(
    employeeId: string,
    companyId: string
  ): Promise<DisbursementInstruction[]> {
    const rows = await this.db('disbursement_instructions')
      .where({ employee_id: employeeId, company_id: companyId })
      .orderBy('priority', 'asc');
    return rows.map((r) => fromRow(r as Row));
  }

  async update(
    id: string,
    companyId: string,
    input: UpdateDisbursementInstructionInput
  ): Promise<DisbursementInstruction | null> {
    const patch: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };
    if (input.splitType !== undefined) patch.split_type = input.splitType;
    if (input.percent !== undefined) patch.percent = input.percent;
    if (input.fixedAmount !== undefined) patch.fixed_amount = input.fixedAmount;
    if (input.priority !== undefined) patch.priority = input.priority;
    if (input.routingNumber !== undefined) {
      patch.routing_number = input.routingNumber.replace(/\D/g, '').slice(0, 9);
    }
    if (input.accountNumber !== undefined) {
      const { token, lastFour } = tokenizeBankAccount(input.accountNumber);
      patch.account_number_token = token;
      patch.account_last_four = lastFour;
    }
    if (input.accountType !== undefined) patch.account_type = input.accountType;
    if (input.isActive !== undefined) patch.is_active = input.isActive;

    const updated = await this.db('disbursement_instructions')
      .where({ id, company_id: companyId })
      .update(patch);
    if (!updated) return null;
    return this.findById(id, companyId);
  }

  async delete(id: string, companyId: string): Promise<boolean> {
    const n = await this.db('disbursement_instructions')
      .where({ id, company_id: companyId })
      .delete();
    return n > 0;
  }
}
