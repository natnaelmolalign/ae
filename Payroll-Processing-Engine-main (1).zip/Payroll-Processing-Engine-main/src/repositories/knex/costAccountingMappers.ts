import type {
  Department,
  Job,
  PayrollRunAllocation,
} from '../../models/CostAccounting';

export interface DepartmentRow {
  id: string;
  company_id: string;
  code: string;
  name: string;
  location_code: string | null;
  is_system: boolean;
  created_at: Date | string;
  updated_at: Date | string;
}

export interface JobRow {
  id: string;
  company_id: string;
  department_id: string;
  code: string;
  name: string;
  created_at: Date | string;
  updated_at: Date | string;
}

export interface PayrollRunAllocationRow {
  id: string;
  payroll_run_id: string;
  department_id: string;
  job_id: string | null;
  allocation_percent: string;
  allocation_hours: string | null;
  created_at: Date | string;
  updated_at: Date | string;
}

export function departmentFromRow(row: DepartmentRow): Department {
  return {
    id: row.id,
    companyId: row.company_id,
    code: row.code,
    name: row.name,
    locationCode: row.location_code,
    isSystem: Boolean(row.is_system),
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}

export function jobFromRow(row: JobRow): Job {
  return {
    id: row.id,
    companyId: row.company_id,
    departmentId: row.department_id,
    code: row.code,
    name: row.name,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}

export function allocationFromRow(
  row: PayrollRunAllocationRow
): PayrollRunAllocation {
  return {
    id: row.id,
    payrollRunId: row.payroll_run_id,
    departmentId: row.department_id,
    jobId: row.job_id,
    allocationPercent: String(row.allocation_percent),
    allocationHours: row.allocation_hours ? String(row.allocation_hours) : null,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}
