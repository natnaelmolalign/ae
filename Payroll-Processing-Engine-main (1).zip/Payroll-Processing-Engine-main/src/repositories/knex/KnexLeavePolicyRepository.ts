import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  AccrualMethod,
  LeavePolicy,
  LeaveType,
} from '../../models/LeavePolicy';
import { parseAccrualConfig } from '../../models/LeavePolicy';
import type { DbTrx, LeavePolicyRepository } from '../interfaces';

interface LeavePolicyRow {
  id: string;
  company_id: string;
  code: string;
  name: string;
  leave_type: LeaveType;
  accrual_method: AccrualMethod;
  accrual_config: string | object;
  carryover_max_hours: string | null;
  effective_from: string;
  effective_to: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

function fromRow(row: LeavePolicyRow): LeavePolicy {
  const method = row.accrual_method;
  const raw =
    typeof row.accrual_config === 'string'
      ? JSON.parse(row.accrual_config)
      : row.accrual_config;
  return {
    id: row.id,
    companyId: row.company_id,
    code: row.code,
    name: row.name,
    leaveType: row.leave_type,
    accrualMethod: method,
    accrualConfig: parseAccrualConfig(method, raw),
    carryoverMaxHours: row.carryover_max_hours,
    effectiveFrom: row.effective_from,
    effectiveTo: row.effective_to,
    isActive: row.is_active,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class KnexLeavePolicyRepository implements LeavePolicyRepository {
  constructor(private readonly db: Knex) {}

  async create(
    input: Omit<LeavePolicy, 'id' | 'createdAt' | 'updatedAt'>
  ): Promise<LeavePolicy> {
    parseAccrualConfig(input.accrualMethod, input.accrualConfig);
    const now = new Date().toISOString();
    const id = randomUUID();
    const row: LeavePolicyRow = {
      id,
      company_id: input.companyId,
      code: input.code.toUpperCase(),
      name: input.name,
      leave_type: input.leaveType,
      accrual_method: input.accrualMethod,
      accrual_config: JSON.stringify(input.accrualConfig),
      carryover_max_hours: input.carryoverMaxHours,
      effective_from: input.effectiveFrom,
      effective_to: input.effectiveTo,
      is_active: input.isActive,
      created_at: now,
      updated_at: now,
    };
    await this.db('leave_policies').insert(row);
    return fromRow(row);
  }

  async update(
    id: string,
    companyId: string,
    patch: Partial<
      Pick<
        LeavePolicy,
        | 'name'
        | 'accrualConfig'
        | 'carryoverMaxHours'
        | 'effectiveFrom'
        | 'effectiveTo'
        | 'isActive'
      >
    >
  ): Promise<LeavePolicy | null> {
    const existing = await this.findById(id, companyId);
    if (!existing) return null;
    const row: Partial<LeavePolicyRow> = {
      updated_at: new Date().toISOString(),
    };
    if (patch.name !== undefined) row.name = patch.name;
    if (patch.accrualConfig !== undefined) {
      parseAccrualConfig(existing.accrualMethod, patch.accrualConfig);
      row.accrual_config = JSON.stringify(patch.accrualConfig);
    }
    if (patch.carryoverMaxHours !== undefined) {
      row.carryover_max_hours = patch.carryoverMaxHours;
    }
    if (patch.effectiveFrom !== undefined)
      row.effective_from = patch.effectiveFrom;
    if (patch.effectiveTo !== undefined) row.effective_to = patch.effectiveTo;
    if (patch.isActive !== undefined) row.is_active = patch.isActive;
    await this.db('leave_policies')
      .where({ id, company_id: companyId })
      .update(row);
    return this.findById(id, companyId);
  }

  async findById(id: string, companyId: string): Promise<LeavePolicy | null> {
    const row = await this.db('leave_policies')
      .where({ id, company_id: companyId })
      .first();
    return row ? fromRow(row as LeavePolicyRow) : null;
  }

  async listByCompany(companyId: string): Promise<LeavePolicy[]> {
    const rows = await this.db('leave_policies')
      .where({ company_id: companyId })
      .orderBy('code', 'asc');
    return rows.map((r) => fromRow(r as LeavePolicyRow));
  }

  async findActiveByType(
    companyId: string,
    leaveType: LeaveType,
    paymentDate: string,
    trx?: DbTrx
  ): Promise<LeavePolicy | null> {
    const row = await (trx ?? this.db)('leave_policies')
      .where({
        company_id: companyId,
        leave_type: leaveType,
        is_active: true,
      })
      .andWhere('effective_from', '<=', paymentDate)
      .andWhere((qb) => {
        qb.whereNull('effective_to').orWhere('effective_to', '>=', paymentDate);
      })
      .orderBy('effective_from', 'desc')
      .first();
    return row ? fromRow(row as LeavePolicyRow) : null;
  }

  async listActiveForAccrual(
    companyId: string,
    paymentDate: string
  ): Promise<LeavePolicy[]> {
    const rows = await this.db('leave_policies')
      .where({ company_id: companyId, is_active: true })
      .andWhere('effective_from', '<=', paymentDate)
      .andWhere((qb) => {
        qb.whereNull('effective_to').orWhere('effective_to', '>=', paymentDate);
      });
    return rows.map((r) => fromRow(r as LeavePolicyRow));
  }
}
