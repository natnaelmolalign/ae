import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  CreateIntegrationConnectionInput,
  ExportBatch,
  GlAccountMapping,
  GlMappingEntry,
  IntegrationConnection,
} from '../../models/ErpConnector';
import type { ErpConnectorRepository, ExportBatchRecord } from '../interfaces';

interface ConnectionRow {
  id: string;
  company_id: string;
  connector_type: string;
  name: string;
  config: string | null;
  is_active: boolean | number;
  created_at: string;
  updated_at: string;
}

interface MappingRow {
  id: string;
  company_id: string;
  connection_id: string;
  version: number;
  internal_account_code: string;
  external_account_id: string;
  external_account_name: string;
  created_at: string;
  updated_at: string;
}

function connectionFromRow(row: ConnectionRow): IntegrationConnection {
  return {
    id: row.id,
    companyId: row.company_id,
    connectorType: row.connector_type as IntegrationConnection['connectorType'],
    name: row.name,
    config: row.config
      ? (JSON.parse(row.config) as Record<string, unknown>)
      : null,
    isActive: Boolean(row.is_active),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function mappingFromRow(row: MappingRow): GlAccountMapping {
  return {
    id: row.id,
    companyId: row.company_id,
    connectionId: row.connection_id,
    version: row.version,
    internalAccountCode: row.internal_account_code,
    externalAccountId: row.external_account_id,
    externalAccountName: row.external_account_name,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function batchFromRow(row: ExportBatchRecord): ExportBatch {
  return {
    id: row.id,
    companyId: row.company_id,
    connectionId: row.connection_id,
    payPeriodId: row.pay_period_id,
    connectorType: row.connector_type as ExportBatch['connectorType'],
    status: row.status as ExportBatch['status'],
    idempotencyKey: row.idempotency_key,
    mappingVersion: row.mapping_version,
    mappingSnapshot: JSON.parse(row.mapping_snapshot) as GlMappingEntry[],
    connectorPayload: JSON.parse(row.connector_payload),
    externalJournalIds: JSON.parse(row.external_journal_ids) as string[],
    submittedAt: row.submitted_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class KnexErpConnectorRepository implements ErpConnectorRepository {
  constructor(private readonly db: Knex) {}

  async createConnection(
    input: CreateIntegrationConnectionInput
  ): Promise<IntegrationConnection> {
    const now = new Date().toISOString();
    const row: ConnectionRow = {
      id: randomUUID(),
      company_id: input.companyId,
      connector_type: input.connectorType,
      name: input.name,
      config: input.config ? JSON.stringify(input.config) : null,
      is_active: input.isActive ?? true,
      created_at: now,
      updated_at: now,
    };
    await this.db('integration_connections').insert(row);
    return connectionFromRow(row);
  }

  async findConnectionById(
    id: string,
    companyId: string
  ): Promise<IntegrationConnection | null> {
    const row = await this.db('integration_connections')
      .where({ id, company_id: companyId })
      .first();
    return row ? connectionFromRow(row as ConnectionRow) : null;
  }

  async listConnections(companyId: string): Promise<IntegrationConnection[]> {
    const rows = await this.db('integration_connections')
      .where({ company_id: companyId })
      .orderBy('name', 'asc');
    return rows.map((r) => connectionFromRow(r as ConnectionRow));
  }

  async getLatestMappingVersion(connectionId: string): Promise<number> {
    const row = await this.db('gl_account_mappings')
      .where({ connection_id: connectionId })
      .max('version as maxVersion')
      .first();
    return row?.maxVersion ? Number(row.maxVersion) : 0;
  }

  async publishMappings(
    companyId: string,
    connectionId: string,
    mappings: GlMappingEntry[]
  ): Promise<{ version: number; mappings: GlAccountMapping[] }> {
    const latest = await this.getLatestMappingVersion(connectionId);
    const version = latest + 1;
    const now = new Date().toISOString();
    const rows: MappingRow[] = mappings.map((m) => ({
      id: randomUUID(),
      company_id: companyId,
      connection_id: connectionId,
      version,
      internal_account_code: m.internalAccountCode,
      external_account_id: m.externalAccountId,
      external_account_name: m.externalAccountName,
      created_at: now,
      updated_at: now,
    }));
    await this.db('gl_account_mappings').insert(rows);
    return { version, mappings: rows.map(mappingFromRow) };
  }

  async getMappingsForVersion(
    connectionId: string,
    version: number
  ): Promise<GlMappingEntry[]> {
    const rows = await this.db('gl_account_mappings')
      .where({ connection_id: connectionId, version })
      .orderBy('internal_account_code', 'asc');
    return rows.map((r) => ({
      internalAccountCode: String(r.internal_account_code),
      externalAccountId: String(r.external_account_id),
      externalAccountName: String(r.external_account_name),
    }));
  }

  async getActiveMappings(connectionId: string): Promise<{
    version: number;
    mappings: GlMappingEntry[];
  }> {
    const version = await this.getLatestMappingVersion(connectionId);
    if (version === 0) {
      return { version: 0, mappings: [] };
    }
    const mappings = await this.getMappingsForVersion(connectionId, version);
    return { version, mappings };
  }

  async findExportByIdempotencyKey(
    connectionId: string,
    idempotencyKey: string
  ): Promise<ExportBatch | null> {
    const row = await this.db('export_batches')
      .where({ connection_id: connectionId, idempotency_key: idempotencyKey })
      .first();
    return row ? batchFromRow(row as ExportBatchRecord) : null;
  }

  async saveExportBatch(
    batch: Omit<ExportBatch, 'createdAt' | 'updatedAt'>
  ): Promise<ExportBatch> {
    const now = new Date().toISOString();
    const row: ExportBatchRecord = {
      id: batch.id,
      company_id: batch.companyId,
      connection_id: batch.connectionId,
      pay_period_id: batch.payPeriodId,
      connector_type: batch.connectorType,
      status: batch.status,
      idempotency_key: batch.idempotencyKey,
      mapping_version: batch.mappingVersion,
      mapping_snapshot: JSON.stringify(batch.mappingSnapshot),
      connector_payload: JSON.stringify(batch.connectorPayload),
      external_journal_ids: JSON.stringify(batch.externalJournalIds),
      submitted_at: batch.submittedAt,
      created_at: now,
      updated_at: now,
    };
    await this.db('export_batches').insert(row);
    return batchFromRow(row);
  }

  async findExportById(
    id: string,
    companyId: string
  ): Promise<ExportBatch | null> {
    const row = await this.db('export_batches')
      .where({ id, company_id: companyId })
      .first();
    return row ? batchFromRow(row as ExportBatchRecord) : null;
  }
}
