import type { Knex } from 'knex';
import type { TimeEntry } from '../../models/types';
import type { TimeEntryRepository } from '../interfaces';

function fromRow(row: Record<string, unknown>): TimeEntry {
  return {
    id: String(row.id),
    employeeId: String(row.employee_id),
    payPeriodId: row.pay_period_id ? String(row.pay_period_id) : null,
    workDate: String(row.work_date).slice(0, 10),
    clockIn: new Date(String(row.clock_in)).toISOString(),
    clockOut: new Date(String(row.clock_out)).toISOString(),
    roundedMinutes: Number(row.rounded_minutes),
    entryType: String(row.entry_type) as TimeEntry['entryType'],
    shiftAssignmentId: row.shift_assignment_id
      ? String(row.shift_assignment_id)
      : null,
    createdAt: new Date(String(row.created_at)).toISOString(),
  };
}

export class KnexTimeEntryRepository implements TimeEntryRepository {
  constructor(private readonly db: Knex) {}

  async insert(entry: TimeEntry): Promise<void> {
    await this.db('time_entries').insert({
      id: entry.id,
      employee_id: entry.employeeId,
      pay_period_id: entry.payPeriodId,
      work_date: entry.workDate,
      clock_in: entry.clockIn,
      clock_out: entry.clockOut,
      rounded_minutes: entry.roundedMinutes,
      entry_type: entry.entryType,
      shift_assignment_id: entry.shiftAssignmentId,
      created_at: entry.createdAt,
      updated_at: entry.createdAt,
    });
  }

  async findByShiftAssignment(shiftAssignmentId: string): Promise<TimeEntry[]> {
    const rows = await this.db('time_entries')
      .where({ shift_assignment_id: shiftAssignmentId })
      .orderBy('work_date', 'asc');
    return rows.map(fromRow);
  }

  async findByEmployee(employeeId: string): Promise<TimeEntry[]> {
    const rows = await this.db('time_entries')
      .where({ employee_id: employeeId })
      .orderBy('work_date', 'asc');
    return rows.map(fromRow);
  }

  async findByPayPeriod(
    employeeId: string,
    payPeriodId: string
  ): Promise<TimeEntry[]> {
    const rows = await this.db('time_entries')
      .where({ employee_id: employeeId, pay_period_id: payPeriodId })
      .orderBy('work_date', 'asc');
    return rows.map(fromRow);
  }
}
