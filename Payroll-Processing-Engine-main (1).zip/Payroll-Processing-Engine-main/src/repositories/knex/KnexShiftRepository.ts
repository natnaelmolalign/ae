import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type { Shift } from '../../models/WorkforceScheduling';
import type { ShiftRepository } from '../interfaces';

interface ShiftRow {
  id: string;
  company_id: string;
  work_date: string;
  start_time: string;
  end_time: string;
  break_minutes: number;
  department_id: string | null;
  location_code: string | null;
  created_at: string;
  updated_at: string;
}

function fromRow(row: ShiftRow): Shift {
  return {
    id: row.id,
    companyId: row.company_id,
    workDate: String(row.work_date).slice(0, 10),
    startTime: new Date(row.start_time).toISOString(),
    endTime: new Date(row.end_time).toISOString(),
    breakMinutes: row.break_minutes,
    departmentId: row.department_id,
    locationCode: row.location_code,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class KnexShiftRepository implements ShiftRepository {
  constructor(private readonly db: Knex) {}

  async create(
    input: Omit<Shift, 'id' | 'createdAt' | 'updatedAt'>
  ): Promise<Shift> {
    const now = new Date().toISOString();
    const row: ShiftRow = {
      id: randomUUID(),
      company_id: input.companyId,
      work_date: input.workDate,
      start_time: input.startTime,
      end_time: input.endTime,
      break_minutes: input.breakMinutes,
      department_id: input.departmentId,
      location_code: input.locationCode,
      created_at: now,
      updated_at: now,
    };
    await this.db('shifts').insert(row);
    return fromRow(row);
  }

  async findById(id: string, companyId: string): Promise<Shift | null> {
    const row = await this.db('shifts')
      .where({ id, company_id: companyId })
      .first();
    return row ? fromRow(row as ShiftRow) : null;
  }

  async listByCompany(companyId: string, workDate?: string): Promise<Shift[]> {
    let q = this.db('shifts').where({ company_id: companyId });
    if (workDate) q = q.andWhere({ work_date: workDate });
    const rows = await q.orderBy('start_time', 'asc');
    return rows.map((r) => fromRow(r as ShiftRow));
  }
}
