import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  CreateEnrollmentWindowInput,
  EnrollmentWindow,
} from '../../models/BenefitsLifecycle';
import type { DeductionType } from '../../models/types';
import type { EnrollmentWindowRepository } from '../interfaces';

interface Row {
  id: string;
  company_id: string;
  code: string;
  name: string;
  plan_year: number;
  start_date: string;
  end_date: string;
  status: string;
  allowed_benefit_types: string;
  created_at: string;
  updated_at: string;
}

function fromRow(row: Row): EnrollmentWindow {
  return {
    id: row.id,
    companyId: row.company_id,
    code: row.code,
    name: row.name,
    planYear: row.plan_year,
    startDate: String(row.start_date).slice(0, 10),
    endDate: String(row.end_date).slice(0, 10),
    status: row.status as EnrollmentWindow['status'],
    allowedBenefitTypes: JSON.parse(
      row.allowed_benefit_types
    ) as DeductionType[],
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class KnexEnrollmentWindowRepository
  implements EnrollmentWindowRepository
{
  constructor(private readonly db: Knex) {}

  async create(input: CreateEnrollmentWindowInput): Promise<EnrollmentWindow> {
    const now = new Date().toISOString();
    const row: Row = {
      id: randomUUID(),
      company_id: input.companyId,
      code: input.code,
      name: input.name,
      plan_year: input.planYear,
      start_date: input.startDate,
      end_date: input.endDate,
      status: input.status ?? 'open',
      allowed_benefit_types: JSON.stringify(input.allowedBenefitTypes),
      created_at: now,
      updated_at: now,
    };
    await this.db('enrollment_windows').insert(row);
    return fromRow(row);
  }

  async findById(
    id: string,
    companyId: string
  ): Promise<EnrollmentWindow | null> {
    const row = await this.db('enrollment_windows')
      .where({ id, company_id: companyId })
      .first();
    return row ? fromRow(row as Row) : null;
  }

  async listByCompany(companyId: string): Promise<EnrollmentWindow[]> {
    const rows = await this.db('enrollment_windows')
      .where({ company_id: companyId })
      .orderBy('plan_year', 'desc');
    return rows.map((r) => fromRow(r as Row));
  }

  async findOpenForDate(
    companyId: string,
    asOfDate: string,
    benefitType: DeductionType
  ): Promise<EnrollmentWindow | null> {
    const rows = await this.db('enrollment_windows')
      .where({ company_id: companyId, status: 'open' })
      .where('start_date', '<=', asOfDate)
      .where('end_date', '>=', asOfDate);
    for (const row of rows) {
      const window = fromRow(row as Row);
      if (window.allowedBenefitTypes.includes(benefitType)) {
        return window;
      }
    }
    return null;
  }

  async updateStatus(
    id: string,
    companyId: string,
    status: EnrollmentWindow['status']
  ): Promise<EnrollmentWindow | null> {
    const updated = await this.db('enrollment_windows')
      .where({ id, company_id: companyId })
      .update({ status, updated_at: new Date().toISOString() });
    if (!updated) return null;
    return this.findById(id, companyId);
  }
}
