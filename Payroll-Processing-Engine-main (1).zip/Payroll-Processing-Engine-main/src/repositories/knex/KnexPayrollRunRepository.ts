import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type { GarnishmentRemittance } from '../../models/GarnishmentOrder';
import type { EarningsLine, PayrollRunResult } from '../../models/types';
import type {
  DbTrx,
  PayrollRunRecord,
  PayrollRunRepository,
} from '../interfaces';

export class KnexPayrollRunRepository implements PayrollRunRepository {
  constructor(private readonly db: Knex) {}

  private table(trx: DbTrx) {
    return trx('payroll_runs');
  }

  async findByEmployeePeriodAndCorrection(
    trx: DbTrx,
    employeeId: string,
    payPeriodId: string,
    isCorrection: boolean
  ): Promise<PayrollRunRecord | null> {
    const row = await this.table(trx)
      .where({
        employee_id: employeeId,
        pay_period_id: payPeriodId,
        is_correction: isCorrection,
      })
      .first();

    if (!row) return null;
    return this.toRecord(row);
  }

  async findByIdempotencyKey(
    trx: DbTrx,
    key: string
  ): Promise<PayrollRunRecord | null> {
    const row = await this.table(trx).where({ idempotency_key: key }).first();
    if (!row) return null;
    return this.toRecord(row);
  }

  async insert(
    trx: DbTrx,
    record: PayrollRunRecord,
    result: PayrollRunResult,
    earnings: EarningsLine[],
    remittances: Omit<GarnishmentRemittance, 'id' | 'createdAt'>[] = []
  ): Promise<void> {
    await this.table(trx).insert({
      id: record.id,
      employee_id: record.employeeId,
      pay_period_id: record.payPeriodId,
      pay_stub_id: record.payStubId,
      is_correction: record.isCorrection,
      idempotency_key: record.idempotencyKey,
      taxes: JSON.stringify(result.taxes),
      employer_contributions: JSON.stringify(result.employerContributions),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    });

    if (earnings.length > 0) {
      await trx('earnings_lines').insert(
        earnings.map((e) => ({
          id: randomUUID(),
          payroll_run_id: record.id,
          type: e.type,
          amount: e.amount,
          hours: e.hours ?? null,
        }))
      );
    }

    if (remittances.length > 0) {
      await trx('garnishment_remittances').insert(
        remittances.map((r) => ({
          id: randomUUID(),
          payroll_run_id: record.id,
          garnishment_order_id: r.garnishmentOrderId,
          case_id: r.caseId,
          order_type: r.orderType,
          amount: r.amount,
          created_at: new Date().toISOString(),
        }))
      );
    }
  }

  private toRecord(row: Record<string, unknown>): PayrollRunRecord {
    return {
      id: String(row.id),
      employeeId: String(row.employee_id),
      payPeriodId: String(row.pay_period_id),
      payStubId: String(row.pay_stub_id),
      isCorrection: Boolean(row.is_correction),
      idempotencyKey: row.idempotency_key ? String(row.idempotency_key) : null,
    };
  }
}
