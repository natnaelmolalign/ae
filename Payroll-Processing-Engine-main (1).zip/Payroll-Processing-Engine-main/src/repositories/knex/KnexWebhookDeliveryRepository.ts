import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type { WebhookDelivery } from '../../models/Webhook';
import type { DbTrx, WebhookDeliveryRepository } from '../interfaces';

export class KnexWebhookDeliveryRepository
  implements WebhookDeliveryRepository
{
  constructor(private readonly db: Knex) {}

  private table(trx?: DbTrx) {
    return (trx ?? this.db)('webhook_deliveries');
  }

  async insert(
    trx: DbTrx,
    input: {
      outboxId: string;
      attemptNumber: number;
      httpStatus: number | null;
      errorMessage: string | null;
    }
  ): Promise<WebhookDelivery> {
    const now = new Date().toISOString();
    const row = {
      id: randomUUID(),
      outbox_id: input.outboxId,
      attempt_number: input.attemptNumber,
      http_status: input.httpStatus,
      error_message: input.errorMessage,
      created_at: now,
    };
    await this.table(trx).insert(row);
    return {
      id: row.id,
      outboxId: row.outbox_id,
      attemptNumber: row.attempt_number,
      httpStatus: row.http_status,
      errorMessage: row.error_message,
      createdAt: now,
    };
  }
}
