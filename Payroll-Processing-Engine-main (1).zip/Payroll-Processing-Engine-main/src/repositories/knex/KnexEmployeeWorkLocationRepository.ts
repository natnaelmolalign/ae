import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  CreateWorkLocationInput,
  EmployeeWorkLocation,
} from '../../models/WorkLocationAllocation';
import type { EmployeeWorkLocationRepository } from '../interfaces';

interface WorkLocationRow {
  id: string;
  employee_id: string;
  state_code: string;
  allocation_percent: string;
  effective_date: string;
  end_date: string | null;
  created_at: string;
  updated_at: string;
}

function fromRow(row: WorkLocationRow): EmployeeWorkLocation {
  return {
    id: row.id,
    employeeId: row.employee_id,
    stateCode: row.state_code,
    allocationPercent: String(row.allocation_percent),
    effectiveDate: String(row.effective_date).slice(0, 10),
    endDate: row.end_date ? String(row.end_date).slice(0, 10) : null,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}

export class KnexEmployeeWorkLocationRepository
  implements EmployeeWorkLocationRepository
{
  constructor(private readonly db: Knex) {}

  async replaceForEmployee(
    employeeId: string,
    locations: CreateWorkLocationInput[]
  ): Promise<EmployeeWorkLocation[]> {
    await this.db('employee_work_locations')
      .where({ employee_id: employeeId })
      .del();
    const now = new Date().toISOString();
    const created: EmployeeWorkLocation[] = [];
    for (const loc of locations) {
      const id = randomUUID();
      await this.db('employee_work_locations').insert({
        id,
        employee_id: employeeId,
        state_code: loc.stateCode.toUpperCase(),
        allocation_percent: loc.allocationPercent,
        effective_date: loc.effectiveDate,
        end_date: loc.endDate ?? null,
        created_at: now,
        updated_at: now,
      });
      const row = await this.db('employee_work_locations')
        .where({ id })
        .first();
      created.push(fromRow(row as WorkLocationRow));
    }
    return created;
  }

  async findActiveByEmployee(
    employeeId: string
  ): Promise<EmployeeWorkLocation[]> {
    const today = new Date().toISOString().slice(0, 10);
    const rows = await this.db('employee_work_locations')
      .where({ employee_id: employeeId })
      .where('effective_date', '<=', today)
      .where((q) => {
        q.whereNull('end_date').orWhere('end_date', '>=', today);
      })
      .orderBy('effective_date', 'desc');
    return rows.map((r) => fromRow(r as WorkLocationRow));
  }
}
