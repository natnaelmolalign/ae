import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  CreateEligibilityRuleInput,
  EligibilityRule,
} from '../../models/BenefitsLifecycle';
import type { DeductionType, EmploymentType } from '../../models/types';
import type { EligibilityRuleRepository } from '../interfaces';

interface Row {
  id: string;
  company_id: string;
  benefit_type: string;
  employment_types: string | null;
  min_tenure_days: number | null;
  requires_enrollment_window: boolean | number;
  is_active: boolean | number;
  created_at: string;
  updated_at: string;
}

function fromRow(row: Row): EligibilityRule {
  return {
    id: row.id,
    companyId: row.company_id,
    benefitType: row.benefit_type as DeductionType,
    employmentTypes: row.employment_types
      ? (JSON.parse(row.employment_types) as EmploymentType[])
      : null,
    minTenureDays: row.min_tenure_days,
    requiresEnrollmentWindow: Boolean(row.requires_enrollment_window),
    isActive: Boolean(row.is_active),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class KnexEligibilityRuleRepository
  implements EligibilityRuleRepository
{
  constructor(private readonly db: Knex) {}

  async create(input: CreateEligibilityRuleInput): Promise<EligibilityRule> {
    const now = new Date().toISOString();
    const row: Row = {
      id: randomUUID(),
      company_id: input.companyId,
      benefit_type: input.benefitType,
      employment_types: input.employmentTypes
        ? JSON.stringify(input.employmentTypes)
        : null,
      min_tenure_days: input.minTenureDays ?? null,
      requires_enrollment_window: input.requiresEnrollmentWindow ?? true,
      is_active: input.isActive ?? true,
      created_at: now,
      updated_at: now,
    };
    await this.db('eligibility_rules').insert(row);
    return fromRow(row);
  }

  async findActiveForType(
    companyId: string,
    benefitType: DeductionType
  ): Promise<EligibilityRule | null> {
    const row = await this.db('eligibility_rules')
      .where({
        company_id: companyId,
        benefit_type: benefitType,
        is_active: true,
      })
      .first();
    return row ? fromRow(row as Row) : null;
  }

  async listByCompany(companyId: string): Promise<EligibilityRule[]> {
    const rows = await this.db('eligibility_rules')
      .where({ company_id: companyId })
      .orderBy('benefit_type', 'asc');
    return rows.map((r) => fromRow(r as Row));
  }
}
