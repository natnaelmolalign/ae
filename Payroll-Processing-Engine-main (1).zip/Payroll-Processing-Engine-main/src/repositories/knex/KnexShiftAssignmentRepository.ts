import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  ShiftAssignment,
  ShiftAssignmentStatus,
} from '../../models/WorkforceScheduling';
import type { DbTrx, ShiftAssignmentRepository } from '../interfaces';

interface ShiftAssignmentRow {
  id: string;
  company_id: string;
  shift_id: string;
  employee_id: string;
  status: ShiftAssignmentStatus;
  scheduled_minutes: number;
  approved_minutes: number | null;
  approved_at: string | null;
  approved_by: string | null;
  payroll_run_id: string | null;
  created_at: string;
  updated_at: string;
}

function fromRow(row: ShiftAssignmentRow): ShiftAssignment {
  return {
    id: row.id,
    companyId: row.company_id,
    shiftId: row.shift_id,
    employeeId: row.employee_id,
    status: row.status,
    scheduledMinutes: row.scheduled_minutes,
    approvedMinutes: row.approved_minutes,
    approvedAt: row.approved_at,
    approvedBy: row.approved_by,
    payrollRunId: row.payroll_run_id,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class KnexShiftAssignmentRepository
  implements ShiftAssignmentRepository
{
  constructor(private readonly db: Knex) {}

  private table(trx?: DbTrx) {
    return (trx ?? this.db)('shift_assignments');
  }

  async create(
    input: Omit<ShiftAssignment, 'id' | 'createdAt' | 'updatedAt'>
  ): Promise<ShiftAssignment> {
    const now = new Date().toISOString();
    const row: ShiftAssignmentRow = {
      id: randomUUID(),
      company_id: input.companyId,
      shift_id: input.shiftId,
      employee_id: input.employeeId,
      status: input.status,
      scheduled_minutes: input.scheduledMinutes,
      approved_minutes: input.approvedMinutes,
      approved_at: input.approvedAt,
      approved_by: input.approvedBy,
      payroll_run_id: input.payrollRunId,
      created_at: now,
      updated_at: now,
    };
    await this.table().insert(row);
    return fromRow(row);
  }

  async findById(
    id: string,
    companyId: string,
    trx?: DbTrx
  ): Promise<ShiftAssignment | null> {
    const row = await this.table(trx)
      .where({ id, company_id: companyId })
      .first();
    return row ? fromRow(row as ShiftAssignmentRow) : null;
  }

  async update(
    id: string,
    companyId: string,
    patch: Partial<
      Pick<
        ShiftAssignment,
        | 'status'
        | 'approvedMinutes'
        | 'approvedAt'
        | 'approvedBy'
        | 'payrollRunId'
      >
    >,
    trx?: DbTrx
  ): Promise<ShiftAssignment> {
    const row: Partial<ShiftAssignmentRow> = {
      updated_at: new Date().toISOString(),
    };
    if (patch.status !== undefined) row.status = patch.status;
    if (patch.approvedMinutes !== undefined)
      row.approved_minutes = patch.approvedMinutes;
    if (patch.approvedAt !== undefined) row.approved_at = patch.approvedAt;
    if (patch.approvedBy !== undefined) row.approved_by = patch.approvedBy;
    if (patch.payrollRunId !== undefined)
      row.payroll_run_id = patch.payrollRunId;
    await this.table(trx).where({ id, company_id: companyId }).update(row);
    const updated = await this.findById(id, companyId, trx);
    if (!updated) {
      throw new Error(`ShiftAssignment ${id} not found after update`);
    }
    return updated;
  }

  async list(
    companyId: string,
    filters: {
      employeeId?: string;
      shiftId?: string;
      status?: ShiftAssignmentStatus;
    }
  ): Promise<ShiftAssignment[]> {
    let q = this.table().where({ company_id: companyId });
    if (filters.employeeId) q = q.andWhere({ employee_id: filters.employeeId });
    if (filters.shiftId) q = q.andWhere({ shift_id: filters.shiftId });
    if (filters.status) q = q.andWhere({ status: filters.status });
    const rows = await q.orderBy('created_at', 'desc');
    return rows.map((r) => fromRow(r as ShiftAssignmentRow));
  }

  async listForEmployeeInPeriod(
    employeeId: string,
    companyId: string,
    periodStart: string,
    periodEnd: string,
    trx?: DbTrx
  ): Promise<ShiftAssignment[]> {
    const rows = await this.table(trx)
      .join('shifts', 'shift_assignments.shift_id', 'shifts.id')
      .where({
        'shift_assignments.employee_id': employeeId,
        'shift_assignments.company_id': companyId,
      })
      .andWhere('shifts.work_date', '>=', periodStart)
      .andWhere('shifts.work_date', '<=', periodEnd)
      .select('shift_assignments.*');
    return rows.map((r) => fromRow(r as ShiftAssignmentRow));
  }
}
