import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  PayPolicy,
  PayPolicyRule,
  PayPolicyScope,
} from '../../models/PayPolicy';
import { payPolicyRulesSchema } from '../../models/PayPolicy';
import type { PayPolicyRepository } from '../interfaces';

interface PayPolicyRow {
  id: string;
  company_id: string;
  code: string;
  name: string;
  scope: PayPolicyScope;
  employee_id: string | null;
  priority: number;
  rules: string | PayPolicyRule[];
  effective_from: string;
  effective_to: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

function parseRules(raw: string | PayPolicyRule[]): PayPolicyRule[] {
  const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
  return payPolicyRulesSchema.parse({ rules: parsed }).rules;
}

function fromRow(row: PayPolicyRow): PayPolicy {
  return {
    id: row.id,
    companyId: row.company_id,
    code: row.code,
    name: row.name,
    scope: row.scope,
    employeeId: row.employee_id,
    priority: row.priority,
    rules: parseRules(row.rules),
    effectiveFrom: row.effective_from,
    effectiveTo: row.effective_to,
    isActive: row.is_active,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class KnexPayPolicyRepository implements PayPolicyRepository {
  constructor(private readonly db: Knex) {}

  async create(
    input: Omit<PayPolicy, 'id' | 'createdAt' | 'updatedAt'>
  ): Promise<PayPolicy> {
    const now = new Date().toISOString();
    const id = randomUUID();
    payPolicyRulesSchema.parse({ rules: input.rules });
    const row: PayPolicyRow = {
      id,
      company_id: input.companyId,
      code: input.code.toUpperCase(),
      name: input.name,
      scope: input.scope,
      employee_id: input.employeeId,
      priority: input.priority,
      rules: JSON.stringify(input.rules),
      effective_from: input.effectiveFrom,
      effective_to: input.effectiveTo,
      is_active: input.isActive,
      created_at: now,
      updated_at: now,
    };
    await this.db('pay_policies').insert(row);
    return fromRow(row);
  }

  async update(
    id: string,
    companyId: string,
    patch: Partial<
      Pick<
        PayPolicy,
        | 'name'
        | 'rules'
        | 'effectiveFrom'
        | 'effectiveTo'
        | 'isActive'
        | 'priority'
      >
    >
  ): Promise<PayPolicy | null> {
    const existing = await this.findById(id, companyId);
    if (!existing) {
      return null;
    }
    if (patch.rules) {
      payPolicyRulesSchema.parse({ rules: patch.rules });
    }
    const row: Partial<PayPolicyRow> = {
      updated_at: new Date().toISOString(),
    };
    if (patch.name !== undefined) row.name = patch.name;
    if (patch.rules !== undefined) row.rules = JSON.stringify(patch.rules);
    if (patch.effectiveFrom !== undefined)
      row.effective_from = patch.effectiveFrom;
    if (patch.effectiveTo !== undefined) row.effective_to = patch.effectiveTo;
    if (patch.isActive !== undefined) row.is_active = patch.isActive;
    if (patch.priority !== undefined) row.priority = patch.priority;
    await this.db('pay_policies')
      .where({ id, company_id: companyId })
      .update(row);
    return this.findById(id, companyId);
  }

  async findById(id: string, companyId: string): Promise<PayPolicy | null> {
    const row = await this.db('pay_policies')
      .where({ id, company_id: companyId })
      .first();
    return row ? fromRow(row as PayPolicyRow) : null;
  }

  async listByCompany(companyId: string): Promise<PayPolicy[]> {
    const rows = await this.db('pay_policies')
      .where({ company_id: companyId })
      .orderBy([
        { column: 'priority', order: 'desc' },
        { column: 'code', order: 'asc' },
      ]);
    return rows.map((r) => fromRow(r as PayPolicyRow));
  }

  async findActiveForRun(
    companyId: string,
    employeeId: string,
    paymentDate: string
  ): Promise<PayPolicy[]> {
    const rows = await this.db('pay_policies')
      .where({ company_id: companyId, is_active: true })
      .andWhere('effective_from', '<=', paymentDate)
      .andWhere((qb) => {
        qb.whereNull('effective_to').orWhere('effective_to', '>=', paymentDate);
      })
      .andWhere((qb) => {
        qb.where({ scope: 'company', employee_id: null }).orWhere({
          scope: 'employee',
          employee_id: employeeId,
        });
      })
      .orderBy('priority', 'desc');
    return rows.map((r) => fromRow(r as PayPolicyRow));
  }
}
