import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type { Job } from '../../models/CostAccounting';
import type { JobRepository } from '../interfaces';
import { jobFromRow, type JobRow } from './costAccountingMappers';

export class KnexJobRepository implements JobRepository {
  constructor(private readonly db: Knex) {}

  async create(
    input: Omit<Job, 'id' | 'createdAt' | 'updatedAt'>
  ): Promise<Job> {
    const now = new Date().toISOString();
    const id = randomUUID();
    const row = {
      id,
      company_id: input.companyId,
      department_id: input.departmentId,
      code: input.code.toUpperCase(),
      name: input.name,
      created_at: now,
      updated_at: now,
    };
    await this.db('jobs').insert(row);
    return jobFromRow(row as JobRow);
  }

  async findById(id: string, companyId: string): Promise<Job | null> {
    const row = await this.db('jobs')
      .where({ id, company_id: companyId })
      .first();
    return row ? jobFromRow(row as JobRow) : null;
  }

  async listByDepartment(
    departmentId: string,
    companyId: string
  ): Promise<Job[]> {
    const rows = await this.db('jobs')
      .where({ department_id: departmentId, company_id: companyId })
      .orderBy('code', 'asc');
    return rows.map((r) => jobFromRow(r as JobRow));
  }
}
