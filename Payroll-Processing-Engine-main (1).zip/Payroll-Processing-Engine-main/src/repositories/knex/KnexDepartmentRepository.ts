import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type { Department } from '../../models/CostAccounting';
import type { DepartmentRepository } from '../interfaces';
import { departmentFromRow, type DepartmentRow } from './costAccountingMappers';

export class KnexDepartmentRepository implements DepartmentRepository {
  constructor(private readonly db: Knex) {}

  async create(
    input: Omit<Department, 'id' | 'createdAt' | 'updatedAt' | 'isSystem'> & {
      isSystem?: boolean;
    }
  ): Promise<Department> {
    const now = new Date().toISOString();
    const id = randomUUID();
    const row = {
      id,
      company_id: input.companyId,
      code: input.code.toUpperCase(),
      name: input.name,
      location_code: input.locationCode,
      is_system: input.isSystem ?? false,
      created_at: now,
      updated_at: now,
    };
    await this.db('departments').insert(row);
    return departmentFromRow(row as DepartmentRow);
  }

  async findById(id: string, companyId: string): Promise<Department | null> {
    const row = await this.db('departments')
      .where({ id, company_id: companyId })
      .first();
    return row ? departmentFromRow(row as DepartmentRow) : null;
  }

  async findByCode(
    companyId: string,
    code: string
  ): Promise<Department | null> {
    const row = await this.db('departments')
      .where({ company_id: companyId, code: code.toUpperCase() })
      .first();
    return row ? departmentFromRow(row as DepartmentRow) : null;
  }

  async listByCompany(companyId: string): Promise<Department[]> {
    const rows = await this.db('departments')
      .where({ company_id: companyId })
      .orderBy('code', 'asc');
    return rows.map((r) => departmentFromRow(r as DepartmentRow));
  }
}
