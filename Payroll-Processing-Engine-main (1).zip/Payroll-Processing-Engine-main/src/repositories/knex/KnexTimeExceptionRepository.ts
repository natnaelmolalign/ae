import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type { TimeException } from '../../models/WorkforceScheduling';
import type { TimeExceptionRepository } from '../interfaces';

export class KnexTimeExceptionRepository implements TimeExceptionRepository {
  constructor(private readonly db: Knex) {}

  async create(
    input: Omit<TimeException, 'id' | 'createdAt'>
  ): Promise<TimeException> {
    const id = randomUUID();
    const now = new Date().toISOString();
    await this.db('time_exceptions').insert({
      id,
      company_id: input.companyId,
      shift_assignment_id: input.shiftAssignmentId,
      exception_type: input.exceptionType,
      notes: input.notes,
      resolved: input.resolved,
      created_at: now,
    });
    return {
      id,
      companyId: input.companyId,
      shiftAssignmentId: input.shiftAssignmentId,
      exceptionType: input.exceptionType,
      notes: input.notes,
      resolved: input.resolved,
      createdAt: now,
    };
  }
}
