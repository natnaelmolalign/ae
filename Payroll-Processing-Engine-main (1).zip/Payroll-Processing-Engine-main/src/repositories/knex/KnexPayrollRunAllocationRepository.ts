import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  CostAllocationSegment,
  PayrollRunAllocation,
} from '../../models/CostAccounting';
import type { DbTrx, PayrollRunAllocationRepository } from '../interfaces';
import {
  allocationFromRow,
  type PayrollRunAllocationRow,
} from './costAccountingMappers';

export class KnexPayrollRunAllocationRepository
  implements PayrollRunAllocationRepository
{
  constructor(private readonly db: Knex) {}

  async insertMany(
    trx: DbTrx,
    rows: Omit<PayrollRunAllocation, 'id' | 'createdAt' | 'updatedAt'>[]
  ): Promise<void> {
    if (rows.length === 0) return;
    const now = new Date().toISOString();
    await trx('payroll_run_allocations').insert(
      rows.map((r) => ({
        id: randomUUID(),
        payroll_run_id: r.payrollRunId,
        department_id: r.departmentId,
        job_id: r.jobId,
        allocation_percent: r.allocationPercent,
        allocation_hours: r.allocationHours,
        created_at: now,
        updated_at: now,
      }))
    );
  }

  async findByPayrollRun(
    payrollRunId: string
  ): Promise<PayrollRunAllocation[]> {
    const rows = await this.db('payroll_run_allocations').where({
      payroll_run_id: payrollRunId,
    });
    return rows.map((r) => allocationFromRow(r as PayrollRunAllocationRow));
  }

  async findSegmentsForRuns(
    payrollRunIds: string[]
  ): Promise<Map<string, CostAllocationSegment[]>> {
    const map = new Map<string, CostAllocationSegment[]>();
    if (payrollRunIds.length === 0) return map;

    const rows = await this.db('payroll_run_allocations as pra')
      .join('departments as d', 'pra.department_id', 'd.id')
      .leftJoin('jobs as j', 'pra.job_id', 'j.id')
      .whereIn('pra.payroll_run_id', payrollRunIds)
      .select(
        'pra.payroll_run_id',
        'pra.department_id',
        'pra.job_id',
        'pra.allocation_percent',
        'd.code as department_code',
        'd.name as department_name',
        'd.location_code',
        'j.code as job_code'
      );

    for (const row of rows) {
      const runId = String(row.payroll_run_id);
      const segment: CostAllocationSegment = {
        departmentId: String(row.department_id),
        departmentCode: String(row.department_code),
        departmentName: String(row.department_name),
        locationCode: row.location_code ? String(row.location_code) : null,
        jobId: row.job_id ? String(row.job_id) : null,
        jobCode: row.job_code ? String(row.job_code) : null,
        percent: String(row.allocation_percent),
      };
      const list = map.get(runId) ?? [];
      list.push(segment);
      map.set(runId, list);
    }
    return map;
  }
}
