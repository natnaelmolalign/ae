import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type { LeaveTransaction } from '../../models/LeavePolicy';
import type { DbTrx, LeaveTransactionRepository } from '../interfaces';

interface LeaveTransactionRow {
  id: string;
  company_id: string;
  employee_id: string;
  leave_type: string;
  policy_id: string;
  calendar_year: number;
  transaction_type: string;
  hours: string;
  balance_after: string;
  pay_period_id: string | null;
  payroll_run_id: string | null;
  notes: string | null;
  actor: string | null;
  created_at: string;
}

function fromRow(row: LeaveTransactionRow): LeaveTransaction {
  return {
    id: row.id,
    companyId: row.company_id,
    employeeId: row.employee_id,
    leaveType: row.leave_type as LeaveTransaction['leaveType'],
    policyId: row.policy_id,
    calendarYear: row.calendar_year,
    transactionType:
      row.transaction_type as LeaveTransaction['transactionType'],
    hours: row.hours,
    balanceAfter: row.balance_after,
    payPeriodId: row.pay_period_id,
    payrollRunId: row.payroll_run_id,
    notes: row.notes,
    actor: row.actor,
    createdAt: row.created_at,
  };
}

export class KnexLeaveTransactionRepository
  implements LeaveTransactionRepository
{
  constructor(private readonly db: Knex) {}

  async insert(
    trx: DbTrx,
    row: Omit<LeaveTransaction, 'id' | 'createdAt'>
  ): Promise<LeaveTransaction> {
    const id = randomUUID();
    const now = new Date().toISOString();
    const dbRow: LeaveTransactionRow = {
      id,
      company_id: row.companyId,
      employee_id: row.employeeId,
      leave_type: row.leaveType,
      policy_id: row.policyId,
      calendar_year: row.calendarYear,
      transaction_type: row.transactionType,
      hours: row.hours,
      balance_after: row.balanceAfter,
      pay_period_id: row.payPeriodId,
      payroll_run_id: row.payrollRunId,
      notes: row.notes,
      actor: row.actor,
      created_at: now,
    };
    await trx('leave_transactions').insert(dbRow);
    return fromRow(dbRow);
  }

  async findAccrualForPeriod(
    trx: DbTrx,
    employeeId: string,
    policyId: string,
    payPeriodId: string
  ): Promise<LeaveTransaction | null> {
    const row = await trx('leave_transactions')
      .where({
        employee_id: employeeId,
        policy_id: policyId,
        pay_period_id: payPeriodId,
        transaction_type: 'accrual',
      })
      .first();
    return row ? fromRow(row as LeaveTransactionRow) : null;
  }

  async listByEmployee(
    employeeId: string,
    companyId: string,
    calendarYear?: number
  ): Promise<LeaveTransaction[]> {
    let q = this.db('leave_transactions').where({
      employee_id: employeeId,
      company_id: companyId,
    });
    if (calendarYear !== undefined) {
      q = q.andWhere({ calendar_year: calendarYear });
    }
    const rows = await q.orderBy('created_at', 'asc');
    return rows.map((r) => fromRow(r as LeaveTransactionRow));
  }
}
