import type {
  BenefitEnrollment,
  HsaCoverage,
} from '../../models/BenefitEnrollment';
import type { DeductionType } from '../../models/types';

export interface BenefitEnrollmentRow {
  id: string;
  employee_id: string;
  type: string;
  amount_per_period: string;
  percent_of_gross: string | null;
  annual_limit: string | null;
  effective_date: string;
  end_date: string | null;
  hsa_coverage: string | null;
  catch_up_eligible: number | boolean;
  priority: number;
  life_event_id?: string | null;
  enrollment_window_id?: string | null;
  created_at: string;
  updated_at: string;
}

function money(value: string | number): string {
  return typeof value === 'number' ? value.toFixed(2) : String(value);
}

export function benefitEnrollmentFromRow(
  row: BenefitEnrollmentRow
): BenefitEnrollment {
  return {
    id: row.id,
    employeeId: row.employee_id,
    type: row.type as DeductionType,
    amountPerPeriod: money(row.amount_per_period),
    percentOfGross: row.percent_of_gross,
    annualLimit: row.annual_limit ? money(row.annual_limit) : null,
    effectiveDate: String(row.effective_date).slice(0, 10),
    endDate: row.end_date ? String(row.end_date).slice(0, 10) : null,
    hsaCoverage: row.hsa_coverage as HsaCoverage | null,
    catchUpEligible: Boolean(row.catch_up_eligible),
    priority: row.priority,
    lifeEventId: row.life_event_id ?? null,
    enrollmentWindowId: row.enrollment_window_id ?? null,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}
