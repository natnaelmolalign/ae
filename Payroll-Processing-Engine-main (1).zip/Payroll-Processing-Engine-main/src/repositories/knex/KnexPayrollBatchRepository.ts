import type { Knex } from 'knex';
import type {
  PayrollBatch,
  PayrollBatchStatus,
} from '../../models/PayrollBatch';
import type { PayrollBatchRepository } from '../interfaces';

interface BatchRow {
  id: string;
  company_id: string;
  pay_period_id: string;
  year: number;
  frequency: string;
  status: string;
  started_at: string | null;
  completed_at: string | null;
  success_count: number;
  failure_count: number;
  total_count: number;
  duration_ms: number | null;
  created_at: string;
  updated_at: string;
}

function fromRow(row: BatchRow): PayrollBatch {
  return {
    id: row.id,
    companyId: row.company_id,
    payPeriodId: row.pay_period_id,
    year: row.year,
    frequency: row.frequency,
    status: row.status as PayrollBatchStatus,
    startedAt: row.started_at ? new Date(row.started_at).toISOString() : null,
    completedAt: row.completed_at
      ? new Date(row.completed_at).toISOString()
      : null,
    successCount: row.success_count,
    failureCount: row.failure_count,
    totalCount: row.total_count,
    durationMs: row.duration_ms,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}

export class KnexPayrollBatchRepository implements PayrollBatchRepository {
  constructor(private readonly db: Knex) {}

  async create(
    batch: Omit<PayrollBatch, 'createdAt' | 'updatedAt'>
  ): Promise<PayrollBatch> {
    const now = new Date().toISOString();
    await this.db('payroll_batches').insert({
      id: batch.id,
      company_id: batch.companyId,
      pay_period_id: batch.payPeriodId,
      year: batch.year,
      frequency: batch.frequency,
      status: batch.status,
      started_at: batch.startedAt,
      completed_at: batch.completedAt,
      success_count: batch.successCount,
      failure_count: batch.failureCount,
      total_count: batch.totalCount,
      duration_ms: batch.durationMs,
      created_at: now,
      updated_at: now,
    });
    const row = await this.db('payroll_batches')
      .where({ id: batch.id })
      .first();
    return fromRow(row as BatchRow);
  }

  async findById(id: string): Promise<PayrollBatch | null> {
    const row = await this.db('payroll_batches').where({ id }).first();
    return row ? fromRow(row as BatchRow) : null;
  }

  async update(
    id: string,
    patch: Partial<
      Pick<
        PayrollBatch,
        | 'status'
        | 'startedAt'
        | 'completedAt'
        | 'successCount'
        | 'failureCount'
        | 'totalCount'
        | 'durationMs'
      >
    >
  ): Promise<PayrollBatch | null> {
    const updates: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };
    if (patch.status !== undefined) updates.status = patch.status;
    if (patch.startedAt !== undefined) updates.started_at = patch.startedAt;
    if (patch.completedAt !== undefined) {
      updates.completed_at = patch.completedAt;
    }
    if (patch.successCount !== undefined) {
      updates.success_count = patch.successCount;
    }
    if (patch.failureCount !== undefined) {
      updates.failure_count = patch.failureCount;
    }
    if (patch.totalCount !== undefined) updates.total_count = patch.totalCount;
    if (patch.durationMs !== undefined) updates.duration_ms = patch.durationMs;

    await this.db('payroll_batches').where({ id }).update(updates);
    return this.findById(id);
  }
}
