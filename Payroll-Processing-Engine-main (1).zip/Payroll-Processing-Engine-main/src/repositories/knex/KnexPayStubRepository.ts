import type { Knex } from 'knex';
import type { PayStub } from '../../models/types';
import type { DbTrx, PayStubRepository } from '../interfaces';
import { payStubFromRow } from './mappers';

export class KnexPayStubRepository implements PayStubRepository {
  constructor(private readonly db: Knex) {}

  private table(trx?: DbTrx) {
    return (trx ?? this.db)('pay_stubs');
  }

  async insert(stub: PayStub, trx: DbTrx): Promise<void> {
    await this.table(trx).insert({
      id: stub.id,
      employee_id: stub.employeeId,
      pay_period_id: stub.payPeriodId,
      gross_pay: stub.grossPay,
      net_pay: stub.netPay,
      is_correction: stub.isCorrection,
      corrects_pay_stub_id: stub.correctsPayStubId ?? null,
      negative_net_recovery: stub.negativeNetRecovery ?? false,
      lines: JSON.stringify(stub.lines),
      created_at: stub.createdAt,
      updated_at: stub.createdAt,
    });
  }

  async findById(id: string, trx?: DbTrx): Promise<PayStub | null> {
    const row = await this.table(trx).where({ id }).first();
    return row ? payStubFromRow(row) : null;
  }

  async findByEmployeeAndPeriod(
    employeeId: string,
    payPeriodId: string,
    trx?: DbTrx
  ): Promise<PayStub | null> {
    const row = await this.table(trx)
      .where({ employee_id: employeeId, pay_period_id: payPeriodId })
      .orderBy('created_at', 'desc')
      .first();
    return row ? payStubFromRow(row) : null;
  }

  async findOriginalByEmployeeAndPeriod(
    employeeId: string,
    payPeriodId: string,
    trx?: DbTrx
  ): Promise<PayStub | null> {
    const row = await this.table(trx)
      .where({
        employee_id: employeeId,
        pay_period_id: payPeriodId,
        is_correction: false,
      })
      .orderBy('created_at', 'asc')
      .first();
    return row ? payStubFromRow(row) : null;
  }

  async listByEmployee(employeeId: string): Promise<PayStub[]> {
    const rows = await this.table()
      .where({ employee_id: employeeId })
      .orderBy('created_at', 'desc');
    return rows.map((r) => payStubFromRow(r));
  }
}
