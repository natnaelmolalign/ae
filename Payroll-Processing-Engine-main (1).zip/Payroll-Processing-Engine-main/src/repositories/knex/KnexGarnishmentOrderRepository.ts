import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  CreateGarnishmentOrderInput,
  GarnishmentOrder,
  UpdateGarnishmentOrderInput,
} from '../../models/GarnishmentOrder';
import type { GarnishmentOrderRepository } from '../interfaces';
import {
  garnishmentOrderFromRow,
  type GarnishmentOrderRow,
} from './garnishmentMappers';

export class KnexGarnishmentOrderRepository
  implements GarnishmentOrderRepository
{
  constructor(private readonly db: Knex) {}

  private table() {
    return this.db('garnishment_orders');
  }

  async create(input: CreateGarnishmentOrderInput): Promise<GarnishmentOrder> {
    const id = randomUUID();
    const now = new Date().toISOString();
    await this.table().insert({
      id,
      employee_id: input.employeeId,
      type: input.type,
      case_id: input.caseId,
      priority: input.priority ?? 0,
      fixed_amount: input.fixedAmount,
      max_percent_of_disposable: input.maxPercentOfDisposable ?? null,
      effective_date: input.effectiveDate,
      end_date: input.endDate ?? null,
      created_at: now,
      updated_at: now,
    });
    const row = await this.table().where({ id }).first();
    return garnishmentOrderFromRow(row as GarnishmentOrderRow);
  }

  async findById(id: string): Promise<GarnishmentOrder | null> {
    const row = await this.table().where({ id }).first();
    return row ? garnishmentOrderFromRow(row as GarnishmentOrderRow) : null;
  }

  async findByEmployee(employeeId: string): Promise<GarnishmentOrder[]> {
    const rows = await this.table()
      .where({ employee_id: employeeId })
      .orderBy('effective_date', 'desc');
    return rows.map((r) => garnishmentOrderFromRow(r as GarnishmentOrderRow));
  }

  async findActiveForEmployee(
    employeeId: string,
    asOfDate: string
  ): Promise<GarnishmentOrder[]> {
    const rows = await this.table()
      .where({ employee_id: employeeId })
      .where('effective_date', '<=', asOfDate)
      .where((qb) => {
        qb.whereNull('end_date').orWhere('end_date', '>=', asOfDate);
      });
    return rows.map((r) => garnishmentOrderFromRow(r as GarnishmentOrderRow));
  }

  async update(
    id: string,
    input: UpdateGarnishmentOrderInput
  ): Promise<GarnishmentOrder | null> {
    const patch: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };
    if (input.priority !== undefined) patch.priority = input.priority;
    if (input.fixedAmount !== undefined) patch.fixed_amount = input.fixedAmount;
    if (input.maxPercentOfDisposable !== undefined) {
      patch.max_percent_of_disposable = input.maxPercentOfDisposable;
    }
    if (input.effectiveDate !== undefined) {
      patch.effective_date = input.effectiveDate;
    }
    if (input.endDate !== undefined) patch.end_date = input.endDate;

    const n = await this.table().where({ id }).update(patch);
    if (!n) return null;
    return this.findById(id);
  }

  async delete(id: string): Promise<boolean> {
    const n = await this.table().where({ id }).delete();
    return n > 0;
  }
}
