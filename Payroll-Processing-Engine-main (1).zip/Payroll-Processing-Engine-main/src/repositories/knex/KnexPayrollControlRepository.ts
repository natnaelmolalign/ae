import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  AnomalyFlag,
  ApprovalRequest,
  ApprovalRequestStatus,
  CreatePayrollHoldInput,
  PayrollHold,
} from '../../models/PayrollControl';
import type { PayrollControlRepository } from '../interfaces';

function holdFromRow(row: Record<string, unknown>): PayrollHold {
  return {
    id: String(row.id),
    companyId: String(row.company_id),
    employeeId: String(row.employee_id),
    reasonCode: String(row.reason_code),
    notes: row.notes ? String(row.notes) : null,
    status: row.status as PayrollHold['status'],
    createdBy: String(row.created_by),
    releasedBy: row.released_by ? String(row.released_by) : null,
    releasedAt: row.released_at ? String(row.released_at) : null,
    releaseReason: row.release_reason ? String(row.release_reason) : null,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export class KnexPayrollControlRepository implements PayrollControlRepository {
  constructor(private readonly db: Knex) {}

  async createHold(input: CreatePayrollHoldInput): Promise<PayrollHold> {
    const now = new Date().toISOString();
    const id = randomUUID();
    await this.db('payroll_holds').insert({
      id,
      company_id: input.companyId,
      employee_id: input.employeeId,
      reason_code: input.reasonCode,
      notes: input.notes ?? null,
      status: 'active',
      created_by: input.createdBy,
      released_by: null,
      released_at: null,
      release_reason: null,
      created_at: now,
      updated_at: now,
    });
    return (await this.findHoldById(id, input.companyId))!;
  }

  async findHoldById(
    id: string,
    companyId: string
  ): Promise<PayrollHold | null> {
    const row = await this.db('payroll_holds')
      .where({ id, company_id: companyId })
      .first();
    return row ? holdFromRow(row) : null;
  }

  async findActiveHoldForEmployee(
    employeeId: string,
    companyId: string
  ): Promise<PayrollHold | null> {
    const row = await this.db('payroll_holds')
      .where({
        employee_id: employeeId,
        company_id: companyId,
        status: 'active',
      })
      .first();
    return row ? holdFromRow(row) : null;
  }

  async releaseHold(
    id: string,
    companyId: string,
    releasedBy: string,
    releaseReason: string
  ): Promise<PayrollHold | null> {
    const now = new Date().toISOString();
    const updated = await this.db('payroll_holds')
      .where({ id, company_id: companyId, status: 'active' })
      .update({
        status: 'released',
        released_by: releasedBy,
        released_at: now,
        release_reason: releaseReason,
        updated_at: now,
      });
    if (!updated) return null;
    return this.findHoldById(id, companyId);
  }

  async listActiveHolds(companyId: string): Promise<PayrollHold[]> {
    const rows = await this.db('payroll_holds')
      .where({ company_id: companyId, status: 'active' })
      .orderBy('created_at', 'desc');
    return rows.map(holdFromRow);
  }

  async saveAnomalyFlag(
    flag: Omit<AnomalyFlag, 'id' | 'createdAt'>
  ): Promise<AnomalyFlag> {
    const id = randomUUID();
    const createdAt = new Date().toISOString();
    await this.db('anomaly_flags').insert({
      id,
      company_id: flag.companyId,
      employee_id: flag.employeeId,
      pay_period_id: flag.payPeriodId,
      metric: flag.metric,
      amount: flag.amount,
      trailing_average: flag.trailingAverage,
      z_score: flag.zScore,
      threshold: flag.threshold,
      created_at: createdAt,
    });
    return { ...flag, id, createdAt };
  }

  async createApprovalRequest(
    input: Omit<
      ApprovalRequest,
      | 'id'
      | 'status'
      | 'reviewedBy'
      | 'reviewedAt'
      | 'reviewNotes'
      | 'createdAt'
      | 'updatedAt'
    >
  ): Promise<ApprovalRequest> {
    const now = new Date().toISOString();
    const id = randomUUID();
    await this.db('approval_requests').insert({
      id,
      company_id: input.companyId,
      employee_id: input.employeeId,
      pay_period_id: input.payPeriodId,
      payroll_run_id: input.payrollRunId,
      requested_amount: input.requestedAmount,
      z_score: input.zScore,
      threshold: input.threshold,
      status: 'pending',
      requested_by: input.requestedBy,
      reviewed_by: null,
      reviewed_at: null,
      review_notes: null,
      created_at: now,
      updated_at: now,
    });
    return (await this.findApprovalById(id, input.companyId))!;
  }

  async findApprovalById(
    id: string,
    companyId: string
  ): Promise<ApprovalRequest | null> {
    const row = await this.db('approval_requests')
      .where({ id, company_id: companyId })
      .first();
    if (!row) return null;
    return {
      id: String(row.id),
      companyId: String(row.company_id),
      employeeId: String(row.employee_id),
      payPeriodId: String(row.pay_period_id),
      payrollRunId: row.payroll_run_id ? String(row.payroll_run_id) : null,
      requestedAmount: String(row.requested_amount),
      zScore: String(row.z_score),
      threshold: String(row.threshold),
      status: row.status as ApprovalRequestStatus,
      requestedBy: String(row.requested_by),
      reviewedBy: row.reviewed_by ? String(row.reviewed_by) : null,
      reviewedAt: row.reviewed_at ? String(row.reviewed_at) : null,
      reviewNotes: row.review_notes ? String(row.review_notes) : null,
      createdAt: String(row.created_at),
      updatedAt: String(row.updated_at),
    };
  }

  async findPendingApprovalForEmployeePeriod(
    employeeId: string,
    payPeriodId: string,
    companyId: string
  ): Promise<ApprovalRequest | null> {
    const row = await this.db('approval_requests')
      .where({
        employee_id: employeeId,
        pay_period_id: payPeriodId,
        company_id: companyId,
        status: 'pending',
      })
      .first();
    return row ? this.findApprovalById(String(row.id), companyId) : null;
  }

  async findApprovedApprovalForEmployeePeriod(
    employeeId: string,
    payPeriodId: string,
    companyId: string
  ): Promise<ApprovalRequest | null> {
    const row = await this.db('approval_requests')
      .where({
        employee_id: employeeId,
        pay_period_id: payPeriodId,
        company_id: companyId,
        status: 'approved',
      })
      .first();
    return row ? this.findApprovalById(String(row.id), companyId) : null;
  }

  async updateApprovalStatus(
    id: string,
    companyId: string,
    status: ApprovalRequestStatus,
    reviewedBy: string,
    reviewNotes?: string
  ): Promise<ApprovalRequest | null> {
    const now = new Date().toISOString();
    const updated = await this.db('approval_requests')
      .where({ id, company_id: companyId, status: 'pending' })
      .update({
        status,
        reviewed_by: reviewedBy,
        reviewed_at: now,
        review_notes: reviewNotes ?? null,
        updated_at: now,
      });
    if (!updated) return null;
    return this.findApprovalById(id, companyId);
  }
}
