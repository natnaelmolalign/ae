import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type { WebhookOutboxEntry } from '../../models/Webhook';
import type { WebhookEventType } from '../../config/webhooks';
import type { DbTrx, WebhookOutboxRepository } from '../interfaces';
import { outboxFromRow, type WebhookOutboxRow } from './webhookMappers';

export class KnexWebhookOutboxRepository implements WebhookOutboxRepository {
  constructor(private readonly db: Knex) {}

  private table(trx?: DbTrx) {
    return (trx ?? this.db)('webhook_outbox');
  }

  async insert(
    trx: DbTrx,
    input: {
      subscriptionId: string;
      companyId: string;
      eventType: WebhookEventType;
      payload: Record<string, unknown>;
    }
  ): Promise<WebhookOutboxEntry> {
    const now = new Date().toISOString();
    const entry: WebhookOutboxEntry = {
      id: randomUUID(),
      subscriptionId: input.subscriptionId,
      companyId: input.companyId,
      eventType: input.eventType,
      payload: input.payload,
      status: 'pending',
      attempts: 0,
      nextAttemptAt: null,
      deliveredAt: null,
      createdAt: now,
      updatedAt: now,
    };
    await this.table(trx).insert({
      id: entry.id,
      subscription_id: entry.subscriptionId,
      company_id: entry.companyId,
      event_type: entry.eventType,
      payload: JSON.stringify(entry.payload),
      status: entry.status,
      attempts: entry.attempts,
      next_attempt_at: entry.nextAttemptAt,
      delivered_at: entry.deliveredAt,
      created_at: now,
      updated_at: now,
    });
    return entry;
  }

  async findPending(limit: number): Promise<WebhookOutboxEntry[]> {
    const now = new Date().toISOString();
    const rows = await this.table()
      .where({ status: 'pending' })
      .andWhere((qb) => {
        qb.whereNull('next_attempt_at').orWhere('next_attempt_at', '<=', now);
      })
      .orderBy('created_at', 'asc')
      .limit(limit);
    return rows.map((r) => outboxFromRow(r as WebhookOutboxRow));
  }

  async markDelivered(trx: DbTrx, id: string): Promise<void> {
    const now = new Date().toISOString();
    await this.table(trx).where({ id }).update({
      status: 'delivered',
      delivered_at: now,
      updated_at: now,
    });
  }

  async markRetry(
    trx: DbTrx,
    id: string,
    attempts: number,
    nextAttemptAt: string
  ): Promise<void> {
    await this.table(trx).where({ id }).update({
      attempts,
      next_attempt_at: nextAttemptAt,
      updated_at: new Date().toISOString(),
    });
  }

  async markFailed(trx: DbTrx, id: string, attempts: number): Promise<void> {
    await this.table(trx).where({ id }).update({
      status: 'failed',
      attempts,
      updated_at: new Date().toISOString(),
    });
  }
}
