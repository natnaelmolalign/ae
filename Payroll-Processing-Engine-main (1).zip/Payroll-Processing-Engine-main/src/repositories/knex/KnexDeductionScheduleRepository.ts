import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  CreateDeductionScheduleInput,
  DeductionSchedule,
  UpdateDeductionScheduleInput,
} from '../../models/DeductionSchedule';
import type { DbTrx, DeductionScheduleRepository } from '../interfaces';
import {
  scheduleFromRow,
  scheduleToRow,
  type DeductionScheduleRow,
} from './deductionScheduleMappers';

export class KnexDeductionScheduleRepository
  implements DeductionScheduleRepository
{
  constructor(private readonly db: Knex) {}

  private table(trx?: DbTrx) {
    return (trx ?? this.db)('deduction_schedules');
  }

  async create(
    input: CreateDeductionScheduleInput
  ): Promise<DeductionSchedule> {
    const now = new Date().toISOString();
    const schedule: DeductionSchedule = {
      id: randomUUID(),
      companyId: input.companyId ?? 'default',
      employeeId: input.employeeId,
      scheduleType: input.scheduleType,
      amountPerPeriod: input.amountPerPeriod,
      remainingBalance:
        input.scheduleType === 'arrears'
          ? (input.remainingBalance ?? input.amountPerPeriod)
          : null,
      priority:
        input.priority ?? (input.scheduleType === 'cobra_premium' ? 50 : 100),
      startDate: input.startDate,
      endDate: input.endDate ?? null,
      createdAt: now,
      updatedAt: now,
    };

    await this.table().insert({
      ...scheduleToRow(schedule),
      created_at: now,
      updated_at: now,
    });
    return schedule;
  }

  async findById(id: string): Promise<DeductionSchedule | null> {
    const row = await this.table().where({ id }).first();
    return row ? scheduleFromRow(row as DeductionScheduleRow) : null;
  }

  async findByEmployee(employeeId: string): Promise<DeductionSchedule[]> {
    const rows = await this.table()
      .where({ employee_id: employeeId })
      .orderBy('priority', 'asc');
    return rows.map((r) => scheduleFromRow(r as DeductionScheduleRow));
  }

  async findActiveForEmployee(
    employeeId: string,
    asOfDate: string
  ): Promise<DeductionSchedule[]> {
    const rows = await this.table()
      .where({ employee_id: employeeId })
      .where('start_date', '<=', asOfDate)
      .where((qb) => {
        qb.whereNull('end_date').orWhere('end_date', '>=', asOfDate);
      })
      .orderBy('priority', 'asc');
    return rows.map((r) => scheduleFromRow(r as DeductionScheduleRow));
  }

  async update(
    id: string,
    input: UpdateDeductionScheduleInput
  ): Promise<DeductionSchedule | null> {
    const existing = await this.findById(id);
    if (!existing) {
      return null;
    }
    const updated: DeductionSchedule = {
      ...existing,
      amountPerPeriod: input.amountPerPeriod ?? existing.amountPerPeriod,
      remainingBalance:
        input.remainingBalance !== undefined
          ? input.remainingBalance
          : existing.remainingBalance,
      priority: input.priority ?? existing.priority,
      startDate: input.startDate ?? existing.startDate,
      endDate: input.endDate !== undefined ? input.endDate : existing.endDate,
      updatedAt: new Date().toISOString(),
    };
    await this.table()
      .where({ id })
      .update({
        ...scheduleToRow(updated),
        updated_at: updated.updatedAt,
      });
    return updated;
  }

  async updateRemainingBalance(
    trx: DbTrx,
    id: string,
    remainingBalance: string | null
  ): Promise<void> {
    await this.table(trx).where({ id }).update({
      remaining_balance: remainingBalance,
      updated_at: new Date().toISOString(),
    });
  }

  async delete(id: string): Promise<boolean> {
    const n = await this.table().where({ id }).delete();
    return n > 0;
  }
}
