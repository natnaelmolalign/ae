import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type { CreateEmployeeInput, Employee } from '../../models/types';
import type { DbTrx, EmployeeRepository } from '../interfaces';
import { encryptTin } from '../../security/TinVault';
import { employeeFromRow, employeeToRow } from './mappers';

export class KnexEmployeeRepository implements EmployeeRepository {
  constructor(private readonly db: Knex) {}

  private table(trx?: DbTrx) {
    return (trx ?? this.db)('employees');
  }

  async create(input: CreateEmployeeInput): Promise<Employee> {
    const employee: Employee = {
      id: randomUUID(),
      companyId: input.companyId ?? 'default',
      firstName: input.firstName,
      lastName: input.lastName,
      employmentType: input.employmentType,
      payFrequency: input.payFrequency,
      baseCompensation: input.baseCompensation,
      hireDate: input.hireDate,
      terminationDate: input.terminationDate ?? null,
      filingStatus: input.filingStatus,
      stateCode: input.stateCode,
      w4ExtraWithholding: input.w4ExtraWithholding ?? '0.00',
      w4DependentsCredit: input.w4DependentsCredit ?? '0.00',
      w4OtherDeductions: input.w4OtherDeductions ?? '0.00',
      w4OtherIncome: input.w4OtherIncome ?? '0.00',
      w4MultipleJobs: input.w4MultipleJobs ?? false,
      localMunicipalityCode: input.localMunicipalityCode ?? null,
      equityWithholdingMethod:
        input.equityWithholdingMethod ?? 'supplemental_flat',
      tinLastFour: null,
      createdAt: new Date().toISOString(),
    };

    const now = new Date().toISOString();
    const row: Record<string, unknown> = {
      ...employeeToRow(employee),
      updated_at: now,
    };
    if (input.tin) {
      const sealed = encryptTin(input.tin);
      row.tin_encrypted = sealed.payload;
      row.tin_key_id = sealed.keyId;
      row.tin_last_four = sealed.lastFour;
      employee.tinLastFour = sealed.lastFour;
    }
    await this.table().insert(row);
    return employee;
  }

  async findById(id: string, trx?: DbTrx): Promise<Employee | null> {
    const row = await this.table(trx).where({ id }).first();
    return row ? employeeFromRow(row) : null;
  }

  async listByCompany(companyId: string): Promise<Employee[]> {
    const rows = await this.table().where({ company_id: companyId });
    return rows.map((r) => employeeFromRow(r));
  }

  async updateW4Fields(
    id: string,
    companyId: string,
    fields: {
      filingStatus: Employee['filingStatus'];
      w4ExtraWithholding: string;
      w4DependentsCredit: string;
      w4OtherDeductions: string;
      w4OtherIncome: string;
      w4MultipleJobs: boolean;
    }
  ): Promise<Employee | null> {
    const updated = await this.table()
      .where({ id, company_id: companyId })
      .update({
        filing_status: fields.filingStatus,
        w4_extra_withholding: fields.w4ExtraWithholding,
        w4_dependents_credit: fields.w4DependentsCredit,
        w4_other_deductions: fields.w4OtherDeductions,
        w4_other_income: fields.w4OtherIncome,
        w4_multiple_jobs: fields.w4MultipleJobs,
        updated_at: new Date().toISOString(),
      });
    if (!updated) return null;
    return this.findById(id);
  }
}
