import type {
  GarnishmentOrder,
  GarnishmentOrderType,
} from '../../models/GarnishmentOrder';

export interface GarnishmentOrderRow {
  id: string;
  employee_id: string;
  type: string;
  case_id: string;
  priority: number;
  fixed_amount: string;
  max_percent_of_disposable: string | null;
  effective_date: string;
  end_date: string | null;
  created_at: string;
  updated_at: string;
}

function money(value: string | number): string {
  return typeof value === 'number' ? value.toFixed(2) : String(value);
}

export function garnishmentOrderFromRow(
  row: GarnishmentOrderRow
): GarnishmentOrder {
  return {
    id: row.id,
    employeeId: row.employee_id,
    type: row.type as GarnishmentOrderType,
    caseId: row.case_id,
    priority: row.priority,
    fixedAmount: money(row.fixed_amount),
    maxPercentOfDisposable: row.max_percent_of_disposable,
    effectiveDate: String(row.effective_date).slice(0, 10),
    endDate: row.end_date ? String(row.end_date).slice(0, 10) : null,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}
