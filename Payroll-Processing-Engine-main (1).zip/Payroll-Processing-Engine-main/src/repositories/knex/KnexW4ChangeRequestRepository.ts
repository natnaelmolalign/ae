import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  CreateW4ChangeRequestInput,
  W4ChangeRequest,
  W4ChangeRequestStatus,
} from '../../models/EmployeeEss';
import type { W4ChangeRequestRepository } from '../interfaces';

interface Row {
  id: string;
  company_id: string;
  employee_id: string;
  status: string;
  filing_status: string;
  w4_extra_withholding: string;
  w4_dependents_credit: string;
  w4_other_deductions: string;
  w4_other_income: string;
  w4_multiple_jobs: boolean | number;
  submitted_at: string | null;
  reviewed_at: string | null;
  reviewed_by: string | null;
  applied_at: string | null;
  review_notes: string | null;
  created_at: string;
  updated_at: string;
}

function fromRow(row: Row): W4ChangeRequest {
  return {
    id: row.id,
    companyId: row.company_id,
    employeeId: row.employee_id,
    status: row.status as W4ChangeRequestStatus,
    filingStatus: row.filing_status as W4ChangeRequest['filingStatus'],
    w4ExtraWithholding: String(row.w4_extra_withholding),
    w4DependentsCredit: String(row.w4_dependents_credit),
    w4OtherDeductions: String(row.w4_other_deductions),
    w4OtherIncome: String(row.w4_other_income),
    w4MultipleJobs: Boolean(row.w4_multiple_jobs),
    submittedAt: row.submitted_at,
    reviewedBy: row.reviewed_by,
    reviewedAt: row.reviewed_at,
    appliedAt: row.applied_at,
    reviewNotes: row.review_notes,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class KnexW4ChangeRequestRepository
  implements W4ChangeRequestRepository
{
  constructor(private readonly db: Knex) {}

  async create(input: CreateW4ChangeRequestInput): Promise<W4ChangeRequest> {
    const now = new Date().toISOString();
    const row: Row = {
      id: randomUUID(),
      company_id: input.companyId,
      employee_id: input.employeeId,
      status: 'draft',
      filing_status: input.filingStatus,
      w4_extra_withholding: input.w4ExtraWithholding ?? '0.00',
      w4_dependents_credit: input.w4DependentsCredit ?? '0.00',
      w4_other_deductions: input.w4OtherDeductions ?? '0.00',
      w4_other_income: input.w4OtherIncome ?? '0.00',
      w4_multiple_jobs: input.w4MultipleJobs ?? false,
      submitted_at: null,
      reviewed_at: null,
      reviewed_by: null,
      applied_at: null,
      review_notes: null,
      created_at: now,
      updated_at: now,
    };
    await this.db('w4_change_requests').insert(row);
    return fromRow(row);
  }

  async findById(
    id: string,
    companyId: string
  ): Promise<W4ChangeRequest | null> {
    const row = await this.db('w4_change_requests')
      .where({ id, company_id: companyId })
      .first();
    return row ? fromRow(row as Row) : null;
  }

  async listByEmployee(
    employeeId: string,
    companyId: string
  ): Promise<W4ChangeRequest[]> {
    const rows = await this.db('w4_change_requests')
      .where({ employee_id: employeeId, company_id: companyId })
      .orderBy('created_at', 'desc');
    return rows.map((r) => fromRow(r as Row));
  }

  async listByStatus(
    companyId: string,
    status: W4ChangeRequestStatus
  ): Promise<W4ChangeRequest[]> {
    const rows = await this.db('w4_change_requests')
      .where({ company_id: companyId, status })
      .orderBy('submitted_at', 'asc');
    return rows.map((r) => fromRow(r as Row));
  }

  async updateStatus(
    id: string,
    companyId: string,
    status: W4ChangeRequestStatus,
    patch: {
      submittedAt?: string | null;
      reviewedAt?: string | null;
      reviewedBy?: string | null;
      appliedAt?: string | null;
      reviewNotes?: string | null;
    }
  ): Promise<W4ChangeRequest | null> {
    const updated = await this.db('w4_change_requests')
      .where({ id, company_id: companyId })
      .update({
        status,
        submitted_at: patch.submittedAt,
        reviewed_at: patch.reviewedAt ?? null,
        reviewed_by: patch.reviewedBy ?? null,
        applied_at: patch.appliedAt ?? null,
        review_notes: patch.reviewNotes ?? null,
        updated_at: new Date().toISOString(),
      });
    if (!updated) return null;
    return this.findById(id, companyId);
  }
}
