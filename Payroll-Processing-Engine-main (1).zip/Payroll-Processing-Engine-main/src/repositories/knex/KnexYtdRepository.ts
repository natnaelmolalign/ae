import type { Knex } from 'knex';
import type { YearToDate } from '../../models/types';
import { emptyYtd } from '../../utils/ytdUtils';
import type { DbTrx, YtdRepository } from '../interfaces';
import { ytdFromRow, ytdToRow } from './mappers';

export class KnexYtdRepository implements YtdRepository {
  constructor(private readonly db: Knex) {}

  private table(trx: DbTrx) {
    return trx('ytd_totals');
  }

  async getForUpdate(
    trx: DbTrx,
    employeeId: string,
    taxYear: number
  ): Promise<YearToDate> {
    let query = this.table(trx)
      .where({ employee_id: employeeId, tax_year: taxYear })
      .forUpdate();

    if (trx.client.config.client === 'better-sqlite3') {
      query = this.table(trx).where({
        employee_id: employeeId,
        tax_year: taxYear,
      });
    }

    const row = await query.first();

    if (row) {
      return ytdFromRow(row);
    }

    const empty = emptyYtd(employeeId, taxYear);
    await this.table(trx).insert(ytdToRow(empty));
    return empty;
  }

  async get(employeeId: string, taxYear: number): Promise<YearToDate> {
    const row = await this.db('ytd_totals')
      .where({ employee_id: employeeId, tax_year: taxYear })
      .first();
    return row ? ytdFromRow(row) : emptyYtd(employeeId, taxYear);
  }

  async save(trx: DbTrx, ytd: YearToDate): Promise<void> {
    await this.table(trx)
      .where({ employee_id: ytd.employeeId, tax_year: ytd.taxYear })
      .update(ytdToRow(ytd));
  }
}
