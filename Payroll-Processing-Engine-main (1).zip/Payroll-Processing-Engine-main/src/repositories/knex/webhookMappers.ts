import type {
  WebhookDelivery,
  WebhookOutboxEntry,
  WebhookSubscription,
} from '../../models/Webhook';
import type { WebhookEventType } from '../../config/webhooks';

export interface WebhookSubscriptionRow {
  id: string;
  company_id: string;
  url: string;
  secret: string;
  events: string;
  enabled: number | boolean;
  consecutive_failures: number;
  disabled_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface WebhookOutboxRow {
  id: string;
  subscription_id: string;
  company_id: string;
  event_type: string;
  payload: string;
  status: string;
  attempts: number;
  next_attempt_at: string | null;
  delivered_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface WebhookDeliveryRow {
  id: string;
  outbox_id: string;
  attempt_number: number;
  http_status: number | null;
  error_message: string | null;
  created_at: string;
}

function parseJson<T>(value: string | T): T {
  return typeof value === 'string' ? (JSON.parse(value) as T) : value;
}

export function subscriptionFromRow(
  row: WebhookSubscriptionRow
): WebhookSubscription {
  return {
    id: row.id,
    companyId: row.company_id,
    url: row.url,
    secret: row.secret,
    events: parseJson<WebhookEventType[]>(row.events),
    enabled: Boolean(row.enabled),
    consecutiveFailures: row.consecutive_failures,
    disabledAt: row.disabled_at
      ? new Date(row.disabled_at).toISOString()
      : null,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}

export function subscriptionToRow(
  sub: WebhookSubscription
): Omit<WebhookSubscriptionRow, 'created_at' | 'updated_at'> {
  return {
    id: sub.id,
    company_id: sub.companyId,
    url: sub.url,
    secret: sub.secret,
    events: JSON.stringify(sub.events),
    enabled: sub.enabled ? 1 : 0,
    consecutive_failures: sub.consecutiveFailures,
    disabled_at: sub.disabledAt,
  };
}

export function outboxFromRow(row: WebhookOutboxRow): WebhookOutboxEntry {
  return {
    id: row.id,
    subscriptionId: row.subscription_id,
    companyId: row.company_id,
    eventType: row.event_type as WebhookEventType,
    payload: parseJson<Record<string, unknown>>(row.payload),
    status: row.status as WebhookOutboxEntry['status'],
    attempts: row.attempts,
    nextAttemptAt: row.next_attempt_at
      ? new Date(row.next_attempt_at).toISOString()
      : null,
    deliveredAt: row.delivered_at
      ? new Date(row.delivered_at).toISOString()
      : null,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}

export function deliveryFromRow(row: WebhookDeliveryRow): WebhookDelivery {
  return {
    id: row.id,
    outboxId: row.outbox_id,
    attemptNumber: row.attempt_number,
    httpStatus: row.http_status,
    errorMessage: row.error_message,
    createdAt: new Date(row.created_at).toISOString(),
  };
}
