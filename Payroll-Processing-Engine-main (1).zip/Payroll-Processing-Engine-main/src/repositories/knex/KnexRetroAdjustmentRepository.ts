import type { Knex } from 'knex';
import type {
  RetroAdjustmentPreview,
  RetroAdjustmentRecord,
  RetroAdjustmentStatus,
} from '../../models/RetroAdjustment';
import type { EarningsLine } from '../../models/types';
import type { DbTrx, RetroAdjustmentRepository } from '../interfaces';

interface RetroRow {
  id: string;
  employee_id: string;
  status: string;
  effective_date: string;
  current_pay_period_id: string;
  reason: string;
  earnings_per_period: string | EarningsLine[];
  preview: string | RetroAdjustmentPreview | null;
  catch_up_pay_stub_id: string | null;
  created_at: string;
  updated_at: string;
}

function fromRow(row: RetroRow): RetroAdjustmentRecord {
  const preview =
    row.preview == null
      ? null
      : typeof row.preview === 'string'
        ? JSON.parse(row.preview)
        : row.preview;
  const earnings =
    typeof row.earnings_per_period === 'string'
      ? JSON.parse(row.earnings_per_period)
      : row.earnings_per_period;
  return {
    id: row.id,
    employeeId: row.employee_id,
    status: row.status as RetroAdjustmentStatus,
    effectiveDate: String(row.effective_date).slice(0, 10),
    currentPayPeriodId: row.current_pay_period_id,
    reason: row.reason,
    earningsPerPeriod: earnings,
    preview,
    catchUpPayStubId: row.catch_up_pay_stub_id,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}

export class KnexRetroAdjustmentRepository
  implements RetroAdjustmentRepository
{
  constructor(private readonly db: Knex) {}

  private table(trx?: DbTrx) {
    return (trx ?? this.db)('retro_adjustments');
  }

  async create(
    input: Omit<
      RetroAdjustmentRecord,
      'preview' | 'catchUpPayStubId' | 'createdAt' | 'updatedAt'
    >,
    trx?: DbTrx
  ): Promise<RetroAdjustmentRecord> {
    const now = new Date().toISOString();
    await this.table(trx).insert({
      id: input.id,
      employee_id: input.employeeId,
      status: input.status,
      effective_date: input.effectiveDate,
      current_pay_period_id: input.currentPayPeriodId,
      reason: input.reason,
      earnings_per_period: JSON.stringify(input.earningsPerPeriod),
      preview: null,
      catch_up_pay_stub_id: null,
      created_at: now,
      updated_at: now,
    });
    const row = await this.table(trx).where({ id: input.id }).first();
    return fromRow(row as RetroRow);
  }

  async findById(
    id: string,
    trx?: DbTrx
  ): Promise<RetroAdjustmentRecord | null> {
    const row = await this.table(trx).where({ id }).first();
    return row ? fromRow(row as RetroRow) : null;
  }

  async update(
    id: string,
    patch: Partial<{
      status: RetroAdjustmentStatus;
      preview: RetroAdjustmentPreview | null;
      catchUpPayStubId: string | null;
    }>,
    trx?: DbTrx
  ): Promise<RetroAdjustmentRecord | null> {
    const updates: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };
    if (patch.status !== undefined) updates.status = patch.status;
    if (patch.preview !== undefined) {
      updates.preview = patch.preview ? JSON.stringify(patch.preview) : null;
    }
    if (patch.catchUpPayStubId !== undefined) {
      updates.catch_up_pay_stub_id = patch.catchUpPayStubId;
    }
    await this.table(trx).where({ id }).update(updates);
    return this.findById(id, trx);
  }
}
