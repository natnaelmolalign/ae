import type { Knex } from 'knex';
import type { PayrollRunFailure } from '../../models/PayrollBatch';
import type { PayrollRunFailureRepository } from '../interfaces';

interface FailureRow {
  id: string;
  batch_id: string | null;
  employee_id: string;
  pay_period_id: string;
  idempotency_key: string | null;
  error_code: string;
  error_message: string;
  payload: string | Record<string, unknown> | null;
  retryable: number | boolean;
  created_at: string;
}

function fromRow(row: FailureRow): PayrollRunFailure {
  const payload =
    row.payload == null
      ? null
      : typeof row.payload === 'string'
        ? JSON.parse(row.payload)
        : row.payload;
  return {
    id: row.id,
    batchId: row.batch_id,
    employeeId: row.employee_id,
    payPeriodId: row.pay_period_id,
    idempotencyKey: row.idempotency_key,
    errorCode: row.error_code,
    errorMessage: row.error_message,
    payload,
    retryable: Boolean(row.retryable),
    createdAt: new Date(row.created_at).toISOString(),
  };
}

export class KnexPayrollRunFailureRepository
  implements PayrollRunFailureRepository
{
  constructor(private readonly db: Knex) {}

  async insert(
    failure: Omit<PayrollRunFailure, 'createdAt'>
  ): Promise<PayrollRunFailure> {
    const now = new Date().toISOString();
    await this.db('payroll_run_failures').insert({
      id: failure.id,
      batch_id: failure.batchId,
      employee_id: failure.employeeId,
      pay_period_id: failure.payPeriodId,
      idempotency_key: failure.idempotencyKey,
      error_code: failure.errorCode,
      error_message: failure.errorMessage,
      payload: failure.payload ? JSON.stringify(failure.payload) : null,
      retryable: failure.retryable,
      created_at: now,
    });
    const row = await this.db('payroll_run_failures')
      .where({ id: failure.id })
      .first();
    return fromRow(row as FailureRow);
  }

  async findByBatchId(batchId: string): Promise<PayrollRunFailure[]> {
    const rows = await this.db('payroll_run_failures')
      .where({ batch_id: batchId })
      .orderBy('created_at', 'asc');
    return rows.map((r) => fromRow(r as FailureRow));
  }
}
