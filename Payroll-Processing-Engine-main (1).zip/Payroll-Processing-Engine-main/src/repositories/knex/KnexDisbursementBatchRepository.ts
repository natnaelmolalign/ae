import type { Knex } from 'knex';
import type {
  AchFile,
  NachaProfile,
  PaymentBatch,
  PaymentBatchItem,
  PaymentBatchItemStatus,
  PaymentBatchStatus,
} from '../../models/Disbursement';
import type { DisbursementBatchRepository } from '../interfaces';

interface BatchRow {
  id: string;
  company_id: string;
  pay_period_id: string | null;
  status: string;
  nacha_profile: string;
  total_net_pay: string;
  total_ach_credit: string;
  payroll_run_count: number;
  idempotency_key: string | null;
  submitted_at: string | null;
  created_at: string;
  updated_at: string;
}

interface ItemRow {
  id: string;
  payment_batch_id: string;
  payroll_run_id: string;
  pay_stub_id: string;
  employee_id: string;
  disbursement_instruction_id: string | null;
  amount: string;
  status: string;
  account_number_token: string;
  routing_number: string;
  account_last_four: string;
  created_at: string;
  updated_at: string;
}

function batchFromRow(row: BatchRow): PaymentBatch {
  return {
    id: row.id,
    companyId: row.company_id,
    payPeriodId: row.pay_period_id,
    status: row.status as PaymentBatchStatus,
    nachaProfile: row.nacha_profile as NachaProfile,
    totalNetPay: String(row.total_net_pay),
    totalAchCredit: String(row.total_ach_credit),
    payrollRunCount: row.payroll_run_count,
    idempotencyKey: row.idempotency_key,
    submittedAt: row.submitted_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function itemFromRow(row: ItemRow): PaymentBatchItem {
  return {
    id: row.id,
    paymentBatchId: row.payment_batch_id,
    payrollRunId: row.payroll_run_id,
    payStubId: row.pay_stub_id,
    employeeId: row.employee_id,
    disbursementInstructionId: row.disbursement_instruction_id,
    amount: String(row.amount),
    status: row.status as PaymentBatchItemStatus,
    accountNumberToken: row.account_number_token,
    routingNumber: row.routing_number,
    accountLastFour: row.account_last_four,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class KnexDisbursementBatchRepository
  implements DisbursementBatchRepository
{
  constructor(private readonly db: Knex) {}

  async createBatch(
    input: Omit<PaymentBatch, 'createdAt' | 'updatedAt' | 'submittedAt'>
  ): Promise<PaymentBatch> {
    const now = new Date().toISOString();
    const row: BatchRow = {
      id: input.id,
      company_id: input.companyId,
      pay_period_id: input.payPeriodId,
      status: input.status,
      nacha_profile: input.nachaProfile,
      total_net_pay: input.totalNetPay,
      total_ach_credit: input.totalAchCredit,
      payroll_run_count: input.payrollRunCount,
      idempotency_key: input.idempotencyKey,
      submitted_at: null,
      created_at: now,
      updated_at: now,
    };
    await this.db('payment_batches').insert(row);
    return batchFromRow(row);
  }

  async findBatchById(
    id: string,
    companyId: string
  ): Promise<PaymentBatch | null> {
    const row = await this.db('payment_batches')
      .where({ id, company_id: companyId })
      .first();
    return row ? batchFromRow(row as BatchRow) : null;
  }

  async findBatchByIdempotencyKey(
    companyId: string,
    key: string
  ): Promise<PaymentBatch | null> {
    const row = await this.db('payment_batches')
      .where({ company_id: companyId, idempotency_key: key })
      .first();
    return row ? batchFromRow(row as BatchRow) : null;
  }

  async updateBatchStatus(
    id: string,
    companyId: string,
    status: PaymentBatchStatus,
    submittedAt?: string | null
  ): Promise<PaymentBatch | null> {
    const patch: Record<string, unknown> = {
      status,
      updated_at: new Date().toISOString(),
    };
    if (submittedAt !== undefined) {
      patch.submitted_at = submittedAt;
    }
    const updated = await this.db('payment_batches')
      .where({ id, company_id: companyId })
      .update(patch);
    if (!updated) return null;
    return this.findBatchById(id, companyId);
  }

  async insertItems(
    items: Omit<PaymentBatchItem, 'createdAt' | 'updatedAt'>[]
  ): Promise<void> {
    if (items.length === 0) return;
    const now = new Date().toISOString();
    await this.db('payment_batch_items').insert(
      items.map((item) => ({
        id: item.id,
        payment_batch_id: item.paymentBatchId,
        payroll_run_id: item.payrollRunId,
        pay_stub_id: item.payStubId,
        employee_id: item.employeeId,
        disbursement_instruction_id: item.disbursementInstructionId,
        amount: item.amount,
        status: item.status,
        account_number_token: item.accountNumberToken,
        routing_number: item.routingNumber,
        account_last_four: item.accountLastFour,
        created_at: now,
        updated_at: now,
      }))
    );
  }

  async listItemsByBatch(batchId: string): Promise<PaymentBatchItem[]> {
    const rows = await this.db('payment_batch_items')
      .where({ payment_batch_id: batchId })
      .orderBy('created_at', 'asc');
    return rows.map((r) => itemFromRow(r as ItemRow));
  }

  async updateItemStatuses(
    batchId: string,
    status: PaymentBatchItemStatus
  ): Promise<void> {
    await this.db('payment_batch_items')
      .where({ payment_batch_id: batchId })
      .update({ status, updated_at: new Date().toISOString() });
  }

  async saveAchFile(file: Omit<AchFile, 'createdAt'>): Promise<AchFile> {
    const now = new Date().toISOString();
    const row = {
      id: file.id,
      payment_batch_id: file.paymentBatchId,
      file_format: file.fileFormat,
      nacha_profile: file.nachaProfile,
      file_content: file.fileContent,
      entry_hash_total: file.entryHashTotal,
      control_total: file.controlTotal,
      entry_count: file.entryCount,
      created_at: now,
    };
    await this.db('ach_files').insert(row);
    return { ...file, createdAt: now };
  }

  async findAchFileByBatch(batchId: string): Promise<AchFile | null> {
    const row = await this.db('ach_files')
      .where({ payment_batch_id: batchId })
      .first();
    if (!row) return null;
    return {
      id: String(row.id),
      paymentBatchId: String(row.payment_batch_id),
      fileFormat: 'nacha',
      nachaProfile: row.nacha_profile as NachaProfile,
      fileContent: String(row.file_content),
      entryHashTotal: String(row.entry_hash_total),
      controlTotal: String(row.control_total),
      entryCount: Number(row.entry_count),
      createdAt: String(row.created_at),
    };
  }

  async listPayrollRunsForPeriod(
    companyId: string,
    payPeriodId: string
  ): Promise<
    {
      payrollRunId: string;
      payStubId: string;
      employeeId: string;
      netPay: string;
      firstName: string;
      lastName: string;
    }[]
  > {
    const rows = await this.db('payroll_runs as pr')
      .join('pay_stubs as ps', 'pr.pay_stub_id', 'ps.id')
      .join('employees as e', 'pr.employee_id', 'e.id')
      .where('pr.pay_period_id', payPeriodId)
      .where('pr.is_correction', false)
      .where('e.company_id', companyId)
      .select(
        'pr.id as payroll_run_id',
        'pr.pay_stub_id',
        'pr.employee_id',
        'ps.net_pay',
        'e.first_name',
        'e.last_name'
      );
    return rows.map((r) => ({
      payrollRunId: String(r.payroll_run_id),
      payStubId: String(r.pay_stub_id),
      employeeId: String(r.employee_id),
      netPay: String(r.net_pay),
      firstName: String(r.first_name),
      lastName: String(r.last_name),
    }));
  }

  async listPayrollRunsByIds(
    companyId: string,
    payrollRunIds: string[]
  ): Promise<
    {
      payrollRunId: string;
      payStubId: string;
      employeeId: string;
      netPay: string;
      firstName: string;
      lastName: string;
    }[]
  > {
    if (payrollRunIds.length === 0) return [];
    const rows = await this.db('payroll_runs as pr')
      .join('pay_stubs as ps', 'pr.pay_stub_id', 'ps.id')
      .join('employees as e', 'pr.employee_id', 'e.id')
      .whereIn('pr.id', payrollRunIds)
      .where('e.company_id', companyId)
      .select(
        'pr.id as payroll_run_id',
        'pr.pay_stub_id',
        'pr.employee_id',
        'ps.net_pay',
        'e.first_name',
        'e.last_name'
      );
    return rows.map((r) => ({
      payrollRunId: String(r.payroll_run_id),
      payStubId: String(r.pay_stub_id),
      employeeId: String(r.employee_id),
      netPay: String(r.net_pay),
      firstName: String(r.first_name),
      lastName: String(r.last_name),
    }));
  }
}
