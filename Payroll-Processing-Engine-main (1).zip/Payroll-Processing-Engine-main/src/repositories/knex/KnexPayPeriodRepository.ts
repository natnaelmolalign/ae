import type { Knex } from 'knex';
import type { PayPeriod } from '../../models/types';
import type { DbTrx, PayPeriodRepository } from '../interfaces';
import { payPeriodFromRow, payPeriodToRow } from './mappers';

export class KnexPayPeriodRepository implements PayPeriodRepository {
  constructor(private readonly db: Knex) {}

  private table(trx?: DbTrx) {
    return (trx ?? this.db)('pay_periods');
  }

  async upsertMany(periods: PayPeriod[], trx?: DbTrx): Promise<void> {
    const q = this.table(trx);
    for (const period of periods) {
      await q
        .insert(payPeriodToRow(period))
        .onConflict('id')
        .merge(['start_date', 'end_date', 'payment_date']);
    }
  }

  async findByYearAndFrequency(
    year: number,
    frequency: string,
    companyId: string,
    trx?: DbTrx
  ): Promise<PayPeriod[]> {
    const rows = await this.table(trx)
      .where({ year, frequency, company_id: companyId })
      .orderBy('period_index', 'asc');
    return rows.map(payPeriodFromRow);
  }

  async findById(id: string, trx?: DbTrx): Promise<PayPeriod | null> {
    const row = await this.table(trx).where({ id }).first();
    return row ? payPeriodFromRow(row) : null;
  }
}
