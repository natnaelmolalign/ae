import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  BenefitEnrollment,
  CreateBenefitEnrollmentInput,
  UpdateBenefitEnrollmentInput,
} from '../../models/BenefitEnrollment';
import type { BenefitEnrollmentRepository } from '../interfaces';
import {
  benefitEnrollmentFromRow,
  type BenefitEnrollmentRow,
} from './benefitEnrollmentMappers';

export class KnexBenefitEnrollmentRepository
  implements BenefitEnrollmentRepository
{
  constructor(private readonly db: Knex) {}

  private table() {
    return this.db('deduction_enrollments');
  }

  async create(
    input: CreateBenefitEnrollmentInput
  ): Promise<BenefitEnrollment> {
    const id = randomUUID();
    const now = new Date().toISOString();
    const row = {
      id,
      employee_id: input.employeeId,
      type: input.type,
      amount_per_period: input.amountPerPeriod,
      percent_of_gross: input.percentOfGross ?? null,
      annual_limit: input.annualLimit ?? null,
      effective_date: input.effectiveDate,
      end_date: input.endDate ?? null,
      hsa_coverage: input.hsaCoverage ?? null,
      catch_up_eligible: input.catchUpEligible ?? false,
      priority: input.priority ?? 0,
      life_event_id: input.lifeEventId ?? null,
      enrollment_window_id: input.enrollmentWindowId ?? null,
      created_at: now,
      updated_at: now,
    };
    await this.table().insert(row);
    const saved = await this.table().where({ id }).first();
    return benefitEnrollmentFromRow(saved as BenefitEnrollmentRow);
  }

  async findById(id: string): Promise<BenefitEnrollment | null> {
    const row = await this.table().where({ id }).first();
    return row ? benefitEnrollmentFromRow(row as BenefitEnrollmentRow) : null;
  }

  async findByEmployee(employeeId: string): Promise<BenefitEnrollment[]> {
    const rows = await this.table()
      .where({ employee_id: employeeId })
      .orderBy('effective_date', 'desc');
    return rows.map((r) => benefitEnrollmentFromRow(r as BenefitEnrollmentRow));
  }

  async findActiveForEmployee(
    employeeId: string,
    asOfDate: string
  ): Promise<BenefitEnrollment[]> {
    const rows = await this.table()
      .where({ employee_id: employeeId })
      .where('effective_date', '<=', asOfDate)
      .where((qb) => {
        qb.whereNull('end_date').orWhere('end_date', '>=', asOfDate);
      })
      .orderBy('priority', 'asc');
    return rows.map((r) => benefitEnrollmentFromRow(r as BenefitEnrollmentRow));
  }

  async update(
    id: string,
    input: UpdateBenefitEnrollmentInput
  ): Promise<BenefitEnrollment | null> {
    const patch: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };
    if (input.amountPerPeriod !== undefined) {
      patch.amount_per_period = input.amountPerPeriod;
    }
    if (input.percentOfGross !== undefined) {
      patch.percent_of_gross = input.percentOfGross;
    }
    if (input.annualLimit !== undefined) {
      patch.annual_limit = input.annualLimit;
    }
    if (input.effectiveDate !== undefined) {
      patch.effective_date = input.effectiveDate;
    }
    if (input.endDate !== undefined) {
      patch.end_date = input.endDate;
    }
    if (input.hsaCoverage !== undefined) {
      patch.hsa_coverage = input.hsaCoverage;
    }
    if (input.catchUpEligible !== undefined) {
      patch.catch_up_eligible = input.catchUpEligible;
    }
    if (input.priority !== undefined) {
      patch.priority = input.priority;
    }

    const updated = await this.table().where({ id }).update(patch);
    if (!updated) return null;
    return this.findById(id);
  }

  async delete(id: string): Promise<boolean> {
    const n = await this.table().where({ id }).delete();
    return n > 0;
  }
}
