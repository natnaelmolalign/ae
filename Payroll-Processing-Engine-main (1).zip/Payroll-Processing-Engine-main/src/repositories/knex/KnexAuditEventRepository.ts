import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  AuditEvent,
  CreateAuditEventInput,
} from '../../models/AuditEvent';
import { jsonDiff } from '../../utils/jsonDiff';
import type { AuditEventRepository } from '../interfaces';

interface AuditRow {
  id: string;
  entity_type: string;
  entity_id: string;
  action: string;
  actor: string;
  before_snapshot: string | Record<string, unknown> | null;
  after_snapshot: string | Record<string, unknown> | null;
  payload: string | Record<string, unknown> | null;
  created_at: string;
}

function parseJson(
  value: string | Record<string, unknown> | null
): Record<string, unknown> | null {
  if (value == null) return null;
  return typeof value === 'string' ? JSON.parse(value) : value;
}

function fromRow(row: AuditRow): AuditEvent {
  return {
    id: row.id,
    entityType: row.entity_type,
    entityId: row.entity_id,
    action: row.action,
    actor: row.actor ?? 'system',
    beforeSnapshot: parseJson(row.before_snapshot),
    afterSnapshot: parseJson(row.after_snapshot),
    payload: parseJson(row.payload),
    createdAt: new Date(row.created_at).toISOString(),
  };
}

export class KnexAuditEventRepository implements AuditEventRepository {
  constructor(private readonly db: Knex) {}

  async append(input: CreateAuditEventInput): Promise<AuditEvent> {
    const id = randomUUID();
    const before = input.beforeSnapshot ?? null;
    const after = input.afterSnapshot ?? null;
    const now = new Date().toISOString();

    await this.db('audit_events').insert({
      id,
      entity_type: input.entityType,
      entity_id: input.entityId,
      action: input.action,
      actor: input.actor,
      before_snapshot: before ? JSON.stringify(before) : null,
      after_snapshot: after ? JSON.stringify(after) : null,
      payload: JSON.stringify({
        diff: before || after ? jsonDiff(before, after) : {},
      }),
      created_at: now,
    });

    const row = await this.db('audit_events').where({ id }).first();
    return fromRow(row as AuditRow);
  }

  async findByEntity(
    entityType: string,
    entityId: string
  ): Promise<AuditEvent[]> {
    const rows = await this.db('audit_events')
      .where({ entity_type: entityType, entity_id: entityId })
      .orderBy('created_at', 'asc');
    return rows.map((r) => fromRow(r as AuditRow));
  }

  async deleteOlderThan(cutoffIso: string): Promise<number> {
    return this.db('audit_events').where('created_at', '<', cutoffIso).delete();
  }
}
