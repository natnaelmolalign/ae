import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  CreateWebhookSubscriptionInput,
  UpdateWebhookSubscriptionInput,
  WebhookSubscription,
} from '../../models/Webhook';
import type { WebhookEventType } from '../../config/webhooks';
import type { DbTrx, WebhookSubscriptionRepository } from '../interfaces';
import {
  subscriptionFromRow,
  subscriptionToRow,
  type WebhookSubscriptionRow,
} from './webhookMappers';

export class KnexWebhookSubscriptionRepository
  implements WebhookSubscriptionRepository
{
  constructor(private readonly db: Knex) {}

  private table(trx?: DbTrx) {
    return (trx ?? this.db)('webhook_subscriptions');
  }

  async create(
    input: CreateWebhookSubscriptionInput
  ): Promise<WebhookSubscription> {
    const now = new Date().toISOString();
    const sub: WebhookSubscription = {
      id: randomUUID(),
      companyId: input.companyId ?? 'default',
      url: input.url,
      secret: input.secret,
      events: input.events,
      enabled: input.enabled ?? true,
      consecutiveFailures: 0,
      disabledAt: null,
      createdAt: now,
      updatedAt: now,
    };
    await this.table().insert({
      ...subscriptionToRow(sub),
      created_at: now,
      updated_at: now,
    });
    return sub;
  }

  async findById(id: string): Promise<WebhookSubscription | null> {
    const row = await this.table().where({ id }).first();
    return row ? subscriptionFromRow(row as WebhookSubscriptionRow) : null;
  }

  async findByCompany(companyId: string): Promise<WebhookSubscription[]> {
    const rows = await this.table().where({ company_id: companyId });
    return rows.map((r) => subscriptionFromRow(r as WebhookSubscriptionRow));
  }

  async findActiveForEvent(
    companyId: string,
    eventType: WebhookEventType,
    trx?: DbTrx
  ): Promise<WebhookSubscription[]> {
    const rows = await this.table(trx)
      .where({ company_id: companyId, enabled: true })
      .whereNull('disabled_at');
    return rows
      .map((r) => subscriptionFromRow(r as WebhookSubscriptionRow))
      .filter((s) => s.events.includes(eventType));
  }

  async update(
    id: string,
    input: UpdateWebhookSubscriptionInput
  ): Promise<WebhookSubscription | null> {
    const existing = await this.findById(id);
    if (!existing) {
      return null;
    }
    const updated: WebhookSubscription = {
      ...existing,
      url: input.url ?? existing.url,
      secret: input.secret ?? existing.secret,
      events: input.events ?? existing.events,
      enabled: input.enabled ?? existing.enabled,
      updatedAt: new Date().toISOString(),
    };
    await this.table()
      .where({ id })
      .update({
        ...subscriptionToRow(updated),
        updated_at: updated.updatedAt,
      });
    return updated;
  }

  async recordDeliveryFailure(
    trx: DbTrx,
    subscriptionId: string,
    threshold: number
  ): Promise<void> {
    const row = await this.table(trx).where({ id: subscriptionId }).first();
    if (!row) {
      return;
    }
    const failures = (row.consecutive_failures as number) + 1;
    const patch: Record<string, unknown> = {
      consecutive_failures: failures,
      updated_at: new Date().toISOString(),
    };
    if (failures >= threshold) {
      patch.enabled = 0;
      patch.disabled_at = new Date().toISOString();
    }
    await this.table(trx).where({ id: subscriptionId }).update(patch);
  }

  async resetFailures(trx: DbTrx, subscriptionId: string): Promise<void> {
    await this.table(trx).where({ id: subscriptionId }).update({
      consecutive_failures: 0,
      updated_at: new Date().toISOString(),
    });
  }

  async delete(id: string): Promise<boolean> {
    const n = await this.table().where({ id }).delete();
    return n > 0;
  }
}
