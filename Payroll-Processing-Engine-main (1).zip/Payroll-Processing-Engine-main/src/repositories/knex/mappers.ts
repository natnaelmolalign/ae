import type {
  Employee,
  PayPeriod,
  PayStub,
  YearToDate,
} from '../../models/types';

export interface EmployeeRow {
  id: string;
  company_id: string;
  first_name: string;
  last_name: string;
  employment_type: string;
  pay_frequency: string;
  base_compensation: string;
  hire_date: string;
  termination_date: string | null;
  filing_status: string;
  state_code: string;
  w4_extra_withholding: string;
  w4_dependents_credit: string;
  w4_other_deductions?: string;
  w4_other_income?: string;
  w4_multiple_jobs?: number | boolean;
  local_municipality_code?: string | null;
  equity_withholding_method?: string;
  tin_encrypted?: string | null;
  tin_key_id?: string | null;
  tin_last_four?: string | null;
  created_at: string;
  updated_at: string;
}

export interface PayPeriodRow {
  id: string;
  company_id: string;
  start_date: string;
  end_date: string;
  payment_date: string;
  frequency: string;
  year: number;
  period_index: number;
}

export interface YtdRow {
  employee_id: string;
  tax_year: number;
  gross_earnings: string;
  federal_taxable_wages: string;
  state_taxable_wages: string;
  ss_taxable_wages: string;
  medicare_taxable_wages: string;
  federal_tax_withheld: string;
  state_tax_withheld: string;
  ss_tax_withheld: string;
  medicare_tax_withheld: string;
  medicare_additional_withheld: string;
  pretax_401k: string;
  roth_401k?: string;
  hsa?: string;
  fsa?: string;
  section_125: string;
  supplemental_taxable_wages?: string;
}

export interface PayStubRow {
  id: string;
  employee_id: string;
  pay_period_id: string;
  gross_pay: string;
  net_pay: string;
  is_correction: number | boolean;
  corrects_pay_stub_id?: string | null;
  negative_net_recovery?: number | boolean;
  lines: string;
  created_at: string;
  updated_at: string;
}

function money(value: string | number): string {
  return typeof value === 'number' ? value.toFixed(2) : String(value);
}

export function employeeFromRow(row: EmployeeRow): Employee {
  return {
    id: row.id,
    companyId: row.company_id,
    firstName: row.first_name,
    lastName: row.last_name,
    employmentType: row.employment_type as Employee['employmentType'],
    payFrequency: row.pay_frequency as Employee['payFrequency'],
    baseCompensation: money(row.base_compensation),
    hireDate: String(row.hire_date).slice(0, 10),
    terminationDate: row.termination_date
      ? String(row.termination_date).slice(0, 10)
      : null,
    filingStatus: row.filing_status as Employee['filingStatus'],
    stateCode: row.state_code,
    w4ExtraWithholding: money(row.w4_extra_withholding),
    w4DependentsCredit: money(row.w4_dependents_credit),
    w4OtherDeductions: money(row.w4_other_deductions ?? '0'),
    w4OtherIncome: money(row.w4_other_income ?? '0'),
    w4MultipleJobs: Boolean(row.w4_multiple_jobs),
    localMunicipalityCode: row.local_municipality_code ?? null,
    equityWithholdingMethod:
      (row.equity_withholding_method as Employee['equityWithholdingMethod']) ??
      'supplemental_flat',
    tinLastFour: row.tin_last_four ?? null,
    createdAt: new Date(row.created_at).toISOString(),
  };
}

export function employeeToRow(
  employee: Employee
): Omit<EmployeeRow, 'updated_at'> {
  return {
    id: employee.id,
    company_id: employee.companyId,
    first_name: employee.firstName,
    last_name: employee.lastName,
    employment_type: employee.employmentType,
    pay_frequency: employee.payFrequency,
    base_compensation: employee.baseCompensation,
    hire_date: employee.hireDate,
    termination_date: employee.terminationDate,
    filing_status: employee.filingStatus,
    state_code: employee.stateCode,
    w4_extra_withholding: employee.w4ExtraWithholding,
    w4_dependents_credit: employee.w4DependentsCredit,
    w4_other_deductions: employee.w4OtherDeductions,
    w4_other_income: employee.w4OtherIncome,
    w4_multiple_jobs: employee.w4MultipleJobs ? 1 : 0,
    local_municipality_code: employee.localMunicipalityCode,
    equity_withholding_method: employee.equityWithholdingMethod,
    created_at: employee.createdAt,
  };
}

export function payPeriodFromRow(row: PayPeriodRow): PayPeriod {
  return {
    id: row.id,
    companyId: row.company_id ?? 'default',
    startDate: String(row.start_date).slice(0, 10),
    endDate: String(row.end_date).slice(0, 10),
    paymentDate: String(row.payment_date).slice(0, 10),
    frequency: row.frequency as PayPeriod['frequency'],
    year: row.year,
    periodIndex: row.period_index,
  };
}

export function payPeriodToRow(period: PayPeriod): PayPeriodRow {
  return {
    id: period.id,
    company_id: period.companyId ?? 'default',
    start_date: period.startDate,
    end_date: period.endDate,
    payment_date: period.paymentDate,
    frequency: period.frequency,
    year: period.year,
    period_index: period.periodIndex,
  };
}

export function ytdFromRow(row: YtdRow): YearToDate {
  return {
    employeeId: row.employee_id,
    taxYear: row.tax_year,
    grossEarnings: money(row.gross_earnings),
    federalTaxableWages: money(row.federal_taxable_wages),
    stateTaxableWages: money(row.state_taxable_wages),
    ssTaxableWages: money(row.ss_taxable_wages),
    medicareTaxableWages: money(row.medicare_taxable_wages),
    federalTaxWithheld: money(row.federal_tax_withheld),
    stateTaxWithheld: money(row.state_tax_withheld),
    ssTaxWithheld: money(row.ss_tax_withheld),
    medicareTaxWithheld: money(row.medicare_tax_withheld),
    medicareAdditionalWithheld: money(row.medicare_additional_withheld),
    pretax401k: money(row.pretax_401k),
    roth401k: money(row.roth_401k ?? '0'),
    hsa: money(row.hsa ?? '0'),
    fsa: money(row.fsa ?? '0'),
    section125: money(row.section_125),
    supplementalTaxableWages: money(row.supplemental_taxable_wages ?? '0'),
  };
}

export function ytdToRow(ytd: YearToDate): YtdRow {
  return {
    employee_id: ytd.employeeId,
    tax_year: ytd.taxYear,
    gross_earnings: ytd.grossEarnings,
    federal_taxable_wages: ytd.federalTaxableWages,
    state_taxable_wages: ytd.stateTaxableWages,
    ss_taxable_wages: ytd.ssTaxableWages,
    medicare_taxable_wages: ytd.medicareTaxableWages,
    federal_tax_withheld: ytd.federalTaxWithheld,
    state_tax_withheld: ytd.stateTaxWithheld,
    ss_tax_withheld: ytd.ssTaxWithheld,
    medicare_tax_withheld: ytd.medicareTaxWithheld,
    medicare_additional_withheld: ytd.medicareAdditionalWithheld,
    pretax_401k: ytd.pretax401k,
    roth_401k: ytd.roth401k,
    hsa: ytd.hsa,
    fsa: ytd.fsa,
    section_125: ytd.section125,
    supplemental_taxable_wages: ytd.supplementalTaxableWages,
  };
}

export function payStubFromRow(row: PayStubRow): PayStub {
  const lines =
    typeof row.lines === 'string' ? JSON.parse(row.lines) : row.lines;
  return {
    id: row.id,
    employeeId: row.employee_id,
    payPeriodId: row.pay_period_id,
    grossPay: money(row.gross_pay),
    netPay: money(row.net_pay),
    lines,
    isCorrection: Boolean(row.is_correction),
    correctsPayStubId: row.corrects_pay_stub_id ?? null,
    negativeNetRecovery: Boolean(row.negative_net_recovery),
    createdAt: new Date(row.created_at).toISOString(),
  };
}
