import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  CreateLifeEventInput,
  LifeEvent,
  LifeEventStatus,
} from '../../models/BenefitsLifecycle';
import type { LifeEventRepository } from '../interfaces';

interface Row {
  id: string;
  company_id: string;
  employee_id: string;
  event_type: string;
  event_date: string;
  coverage_effective_date: string;
  status: string;
  approved_at: string | null;
  approved_by: string | null;
  cobra_schedule_id: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

function fromRow(row: Row): LifeEvent {
  return {
    id: row.id,
    companyId: row.company_id,
    employeeId: row.employee_id,
    eventType: row.event_type as LifeEvent['eventType'],
    eventDate: String(row.event_date).slice(0, 10),
    coverageEffectiveDate: String(row.coverage_effective_date).slice(0, 10),
    status: row.status as LifeEventStatus,
    approvedAt: row.approved_at,
    approvedBy: row.approved_by,
    cobraScheduleId: row.cobra_schedule_id,
    notes: row.notes,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class KnexLifeEventRepository implements LifeEventRepository {
  constructor(private readonly db: Knex) {}

  async create(input: CreateLifeEventInput): Promise<LifeEvent> {
    const now = new Date().toISOString();
    const row: Row = {
      id: randomUUID(),
      company_id: input.companyId,
      employee_id: input.employeeId,
      event_type: input.eventType,
      event_date: input.eventDate,
      coverage_effective_date: input.coverageEffectiveDate,
      status: 'pending',
      approved_at: null,
      approved_by: null,
      cobra_schedule_id: null,
      notes: input.notes ?? null,
      created_at: now,
      updated_at: now,
    };
    await this.db('life_events').insert(row);
    return fromRow(row);
  }

  async findById(id: string, companyId: string): Promise<LifeEvent | null> {
    const row = await this.db('life_events')
      .where({ id, company_id: companyId })
      .first();
    return row ? fromRow(row as Row) : null;
  }

  async listByEmployee(
    employeeId: string,
    companyId: string
  ): Promise<LifeEvent[]> {
    const rows = await this.db('life_events')
      .where({ employee_id: employeeId, company_id: companyId })
      .orderBy('event_date', 'desc');
    return rows.map((r) => fromRow(r as Row));
  }

  async updateStatus(
    id: string,
    companyId: string,
    status: LifeEventStatus,
    patch: {
      approvedAt?: string | null;
      approvedBy?: string | null;
      cobraScheduleId?: string | null;
    }
  ): Promise<LifeEvent | null> {
    const updated = await this.db('life_events')
      .where({ id, company_id: companyId })
      .update({
        status,
        approved_at: patch.approvedAt ?? null,
        approved_by: patch.approvedBy ?? null,
        cobra_schedule_id: patch.cobraScheduleId ?? null,
        updated_at: new Date().toISOString(),
      });
    if (!updated) return null;
    return this.findById(id, companyId);
  }
}
