import type { Knex } from 'knex';
import type { EmployeePayrollReadinessStatus } from '../../models/PayrollBatch';
import type { EmployeePayrollReadinessRepository } from '../interfaces';

export class KnexEmployeePayrollReadinessRepository
  implements EmployeePayrollReadinessRepository
{
  constructor(private readonly db: Knex) {}

  async upsertReady(employeeId: string, payPeriodId: string): Promise<void> {
    const existing = await this.db('employee_payroll_readiness')
      .where({ employee_id: employeeId, pay_period_id: payPeriodId })
      .first();

    const now = new Date().toISOString();
    if (existing) {
      await this.db('employee_payroll_readiness')
        .where({ employee_id: employeeId, pay_period_id: payPeriodId })
        .update({ status: 'ready', updated_at: now });
      return;
    }

    await this.db('employee_payroll_readiness').insert({
      employee_id: employeeId,
      pay_period_id: payPeriodId,
      status: 'ready',
      created_at: now,
      updated_at: now,
    });
  }

  async markProcessed(employeeId: string, payPeriodId: string): Promise<void> {
    await this.setStatus(employeeId, payPeriodId, 'processed');
  }

  async setStatus(
    employeeId: string,
    payPeriodId: string,
    status: EmployeePayrollReadinessStatus
  ): Promise<void> {
    await this.db('employee_payroll_readiness')
      .where({ employee_id: employeeId, pay_period_id: payPeriodId })
      .update({ status, updated_at: new Date().toISOString() });
  }

  async findReadyEmployeeIds(payPeriodId: string): Promise<string[]> {
    const rows = await this.db('employee_payroll_readiness')
      .where({ pay_period_id: payPeriodId, status: 'ready' })
      .select('employee_id');
    return rows.map((r) => r.employee_id as string);
  }
}
