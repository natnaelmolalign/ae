import type { DeductionSchedule } from '../../models/DeductionSchedule';

export interface DeductionScheduleRow {
  id: string;
  company_id: string;
  employee_id: string;
  schedule_type: string;
  amount_per_period: string;
  remaining_balance: string | null;
  priority: number;
  start_date: string;
  end_date: string | null;
  created_at: string;
  updated_at: string;
}

function money(value: string | number): string {
  return typeof value === 'number' ? value.toFixed(2) : String(value);
}

export function scheduleFromRow(row: DeductionScheduleRow): DeductionSchedule {
  return {
    id: row.id,
    companyId: row.company_id,
    employeeId: row.employee_id,
    scheduleType: row.schedule_type as DeductionSchedule['scheduleType'],
    amountPerPeriod: money(row.amount_per_period),
    remainingBalance:
      row.remaining_balance != null ? money(row.remaining_balance) : null,
    priority: row.priority,
    startDate: String(row.start_date).slice(0, 10),
    endDate: row.end_date ? String(row.end_date).slice(0, 10) : null,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}

export function scheduleToRow(
  schedule: DeductionSchedule
): Omit<DeductionScheduleRow, 'created_at' | 'updated_at'> {
  return {
    id: schedule.id,
    company_id: schedule.companyId,
    employee_id: schedule.employeeId,
    schedule_type: schedule.scheduleType,
    amount_per_period: schedule.amountPerPeriod,
    remaining_balance: schedule.remainingBalance,
    priority: schedule.priority,
    start_date: schedule.startDate,
    end_date: schedule.endDate,
  };
}
