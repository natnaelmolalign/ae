import type { Logger } from 'winston';
import type { AuthContext } from '../config/auth';

declare global {
  namespace Express {
    interface Request {
      correlationId: string;
      traceParent: string;
      log: Logger;
      actor: string;
      auth: AuthContext;
    }
  }
}

export {};
