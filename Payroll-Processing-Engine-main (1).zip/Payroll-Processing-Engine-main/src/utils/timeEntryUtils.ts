import { differenceInMinutes, parseISO } from 'date-fns';

/** Round worked minutes to nearest 15 per common payroll practice */
export function roundMinutesWorked(rawMinutes: number): number {
  if (rawMinutes <= 0) return 0;
  return Math.round(rawMinutes / 15) * 15;
}

export function minutesBetween(clockIn: string, clockOut: string): number {
  const start = parseISO(clockIn);
  const end = parseISO(clockOut);
  const mins = differenceInMinutes(end, start);
  if (mins < 0) {
    throw new Error('clockOut must be after clockIn');
  }
  return mins;
}

export function minutesToHours(minutes: number): string {
  return (minutes / 60).toFixed(2);
}

export function isDateInPayPeriod(
  workDate: string,
  startDate: string,
  endDate: string
): boolean {
  return workDate >= startDate && workDate <= endDate;
}
