import type { ClassifiedEarnings } from '../services/EarningsService';
import { compare, div, mul, sub, type Money } from './decimalUtils';

export function splitFederalTaxableAfterPretax(
  federalTaxableAfterPretax: Money,
  classified: ClassifiedEarnings
): { regularFederalTaxable: Money; supplementalFederalTaxable: Money } {
  const base = classified.federalTaxable;
  if (compare(base, '0.00') <= 0) {
    return {
      regularFederalTaxable: federalTaxableAfterPretax,
      supplementalFederalTaxable: '0.00',
    };
  }
  const regularFederalTaxable = div(
    mul(federalTaxableAfterPretax, classified.regularAmount),
    base
  );
  const supplementalFederalTaxable = sub(
    federalTaxableAfterPretax,
    regularFederalTaxable
  );
  return { regularFederalTaxable, supplementalFederalTaxable };
}
