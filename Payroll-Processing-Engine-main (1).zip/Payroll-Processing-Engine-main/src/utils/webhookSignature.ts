import { createHmac, timingSafeEqual } from 'crypto';

/** Stripe-style: HMAC-SHA256 of `${timestamp}.${body}` */
export function signWebhookPayload(
  secret: string,
  body: string,
  timestamp: string
): string {
  return createHmac('sha256', secret)
    .update(`${timestamp}.${body}`)
    .digest('hex');
}

export function buildSignatureHeader(
  secret: string,
  body: string,
  timestamp: string
): string {
  return `sha256=${signWebhookPayload(secret, body, timestamp)}`;
}

export function verifyWebhookSignature(
  secret: string,
  body: string,
  timestamp: string,
  signatureHeader: string
): boolean {
  const expected = `sha256=${signWebhookPayload(secret, body, timestamp)}`;
  if (expected.length !== signatureHeader.length) {
    return false;
  }
  try {
    return timingSafeEqual(Buffer.from(expected), Buffer.from(signatureHeader));
  } catch {
    return false;
  }
}
