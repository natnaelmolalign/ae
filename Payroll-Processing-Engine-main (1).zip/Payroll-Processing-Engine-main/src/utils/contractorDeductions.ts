import type { DeductionEnrollment } from '../models/types';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';

const W2_ONLY_PRETAX = new Set(['section_125', 'hsa', 'fsa', '401k_pretax']);

export function assertContractorDeductionsAllowed(
  deductions: DeductionEnrollment[]
): void {
  const invalid = deductions.filter((d) => W2_ONLY_PRETAX.has(d.type));
  if (invalid.length === 0) return;
  throw new PayrollDomainError(
    PayrollErrorCode.INVALID_INPUT,
    `Pre-tax W-2 deductions are not allowed for 1099 contractors: ${invalid.map((d) => d.type).join(', ')}`,
    { types: invalid.map((d) => d.type) }
  );
}
