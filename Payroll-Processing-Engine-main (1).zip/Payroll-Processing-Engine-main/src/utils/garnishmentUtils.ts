import { GARNISHMENT_MAX_PERCENT } from '../data/garnishment/priorityRules';
import { minMoney, mul, sub, sum, type Money } from './decimalUtils';

/** @deprecated Use GARNISHMENT_MAX_PERCENT.creditor */
export const CCPA_MAX_PERCENT = GARNISHMENT_MAX_PERCENT.creditor;

/** @deprecated Use GARNISHMENT_MAX_PERCENT.child_support */
export const CHILD_SUPPORT_MAX_PERCENT = GARNISHMENT_MAX_PERCENT.child_support;

/** @deprecated Use DisposableEarningsCalculator */
export function calculateDisposableEarnings(
  gross: Money,
  federalTax: Money,
  stateTax: Money,
  ssTax: Money,
  medicareTax: Money
): Money {
  return sub(gross, sum([federalTax, stateTax, ssTax, medicareTax]));
}

export function applyGarnishmentCap(
  requested: Money,
  disposable: Money,
  maxPercent: Money
): Money {
  const cap = mul(disposable, maxPercent);
  return minMoney(requested, cap);
}
