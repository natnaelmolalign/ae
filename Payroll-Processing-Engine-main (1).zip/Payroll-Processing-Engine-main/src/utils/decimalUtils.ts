import Decimal from 'decimal.js';

Decimal.set({ precision: 28, rounding: Decimal.ROUND_HALF_UP });

export type Money = string;

export function d(value: Money | number): Decimal {
  return new Decimal(value);
}

export function add(a: Money, b: Money): Money {
  return d(a).plus(b).toFixed(2);
}

export function sub(a: Money, b: Money): Money {
  return d(a).minus(b).toFixed(2);
}

export function mul(a: Money, b: Money): Money {
  return d(a).times(b).toFixed(2);
}

export function div(a: Money, b: Money): Money {
  return d(a).div(b).toFixed(2);
}

export function maxMoney(a: Money, b: Money): Money {
  return Decimal.max(d(a), d(b)).toFixed(2);
}

export function minMoney(a: Money, b: Money): Money {
  return Decimal.min(d(a), d(b)).toFixed(2);
}

export function isZero(a: Money): boolean {
  return d(a).isZero();
}

export function isPositive(a: Money): boolean {
  return d(a).greaterThan(0);
}

export function compare(a: Money, b: Money): number {
  return d(a).comparedTo(d(b));
}

export function sum(values: Money[]): Money {
  return values.reduce((acc, v) => add(acc, v), '0.00');
}
