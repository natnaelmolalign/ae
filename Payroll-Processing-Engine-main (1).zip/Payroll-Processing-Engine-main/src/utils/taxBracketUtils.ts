import Decimal from 'decimal.js';
import { FEDERAL_BRACKETS_2024 } from '../data/federalTaxBrackets2024';
import type { TaxBracket } from '../data/tax/types';
import type { FilingStatus } from '../models/types';
import { d, div, mul, type Money, sub } from './decimalUtils';

/**
 * Progressive tax on annual taxable income.
 * Each bracket rate applies only to income within that bracket slice.
 */
export function calculateProgressiveTax(
  annualTaxableIncome: Money,
  filingStatus: FilingStatus,
  brackets: Record<FilingStatus, TaxBracket[]> = FEDERAL_BRACKETS_2024
): Money {
  const statusBrackets = brackets[filingStatus];
  let remaining = d(annualTaxableIncome);
  let tax = d('0');
  let previousCap = d('0');

  for (const bracket of statusBrackets) {
    if (remaining.lte(0)) break;
    const cap = bracket.upTo ? d(bracket.upTo) : null;
    const bracketWidth = cap
      ? Decimal.min(remaining, cap.minus(previousCap))
      : remaining;
    if (bracketWidth.lte(0)) {
      if (cap) previousCap = cap;
      continue;
    }
    tax = tax.plus(bracketWidth.times(bracket.rate));
    remaining = remaining.minus(bracketWidth);
    if (cap) previousCap = cap;
  }

  return tax.toFixed(2);
}

export function annualizePeriodWages(
  periodTaxable: Money,
  periodsPerYear: number
): Money {
  return mul(periodTaxable, String(periodsPerYear));
}

export function deannualizeTax(
  annualTax: Money,
  periodsPerYear: number
): Money {
  return div(annualTax, String(periodsPerYear));
}

function add(a: Money, b: Money): Money {
  return d(a).plus(b).toFixed(2);
}

export function calculateFederalWithholdingForPeriod(
  periodFederalTaxable: Money,
  filingStatus: FilingStatus,
  periodsPerYear: number,
  extraWithholding: Money,
  dependentsCreditAnnual: Money
): Money {
  const annualized = annualizePeriodWages(periodFederalTaxable, periodsPerYear);
  const annualTax = calculateProgressiveTax(annualized, filingStatus);
  const afterCredit = d(annualTax).greaterThan(d(dependentsCreditAnnual))
    ? sub(annualTax, dependentsCreditAnnual)
    : '0.00';
  const periodTax = deannualizeTax(afterCredit, periodsPerYear);
  return add(periodTax, extraWithholding);
}
