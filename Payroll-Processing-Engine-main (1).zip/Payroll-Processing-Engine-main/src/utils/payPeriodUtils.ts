import {
  addDays,
  endOfMonth,
  endOfYear,
  format,
  parseISO,
  startOfYear,
} from 'date-fns';
import type { PayFrequency, PayPeriod } from '../models/types';

const DATE_FMT = 'yyyy-MM-dd';

function idFor(year: number, frequency: PayFrequency, index: number): string {
  return `${year}-${frequency}-${index}`;
}

export function generateWeeklyPeriods(year: number): PayPeriod[] {
  const periods: PayPeriod[] = [];
  let start = startOfYear(new Date(year, 0, 1));
  let index = 1;
  const yearEnd = endOfYear(start);

  while (start <= yearEnd && index <= 53) {
    const end = addDays(start, 6);
    if (end > yearEnd) break;
    periods.push({
      id: idFor(year, 'weekly', index),
      startDate: format(start, DATE_FMT),
      endDate: format(end, DATE_FMT),
      paymentDate: format(addDays(end, 2), DATE_FMT),
      frequency: 'weekly',
      year,
      periodIndex: index,
    });
    start = addDays(end, 1);
    index += 1;
  }
  return periods;
}

export function generateBiweeklyPeriods(
  year: number,
  anchorStart: string
): PayPeriod[] {
  const periods: PayPeriod[] = [];
  let start = parseISO(anchorStart);
  const yearEnd = endOfYear(new Date(year, 0, 1));
  let index = 1;

  while (start <= yearEnd) {
    const end = addDays(start, 13);
    if (parseISO(format(end, DATE_FMT)) > yearEnd && index > 26) break;
    periods.push({
      id: idFor(year, 'biweekly', index),
      startDate: format(start, DATE_FMT),
      endDate: format(end, DATE_FMT),
      paymentDate: format(addDays(end, 2), DATE_FMT),
      frequency: 'biweekly',
      year,
      periodIndex: index,
    });
    start = addDays(end, 1);
    index += 1;
    if (index > 27) break;
  }
  return periods;
}

export function generateSemimonthlyPeriods(year: number): PayPeriod[] {
  const periods: PayPeriod[] = [];
  for (let month = 0; month < 12; month += 1) {
    const firstStart = new Date(year, month, 1);
    const firstEnd = new Date(year, month, 15);
    const secondStart = new Date(year, month, 16);
    const secondEnd = endOfMonth(firstStart);

    periods.push({
      id: idFor(year, 'semimonthly', month * 2 + 1),
      startDate: format(firstStart, DATE_FMT),
      endDate: format(firstEnd, DATE_FMT),
      paymentDate: format(firstEnd, DATE_FMT),
      frequency: 'semimonthly',
      year,
      periodIndex: month * 2 + 1,
    });
    periods.push({
      id: idFor(year, 'semimonthly', month * 2 + 2),
      startDate: format(secondStart, DATE_FMT),
      endDate: format(secondEnd, DATE_FMT),
      paymentDate: format(secondEnd, DATE_FMT),
      frequency: 'semimonthly',
      year,
      periodIndex: month * 2 + 2,
    });
  }
  return periods;
}

export function generateMonthlyPeriods(year: number): PayPeriod[] {
  const periods: PayPeriod[] = [];
  for (let month = 0; month < 12; month += 1) {
    const start = new Date(year, month, 1);
    const end = endOfMonth(start);
    periods.push({
      id: idFor(year, 'monthly', month + 1),
      startDate: format(start, DATE_FMT),
      endDate: format(end, DATE_FMT),
      paymentDate: format(end, DATE_FMT),
      frequency: 'monthly',
      year,
      periodIndex: month + 1,
    });
  }
  return periods;
}

export function periodsOverlap(a: PayPeriod, b: PayPeriod): boolean {
  if (a.endDate !== b.endDate) return false;
  return a.startDate !== b.startDate;
}

export function paymentYear(paymentDate: string): number {
  return parseISO(paymentDate).getFullYear();
}
