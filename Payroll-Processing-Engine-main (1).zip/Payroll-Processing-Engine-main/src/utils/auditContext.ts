import type { Request } from 'express';

export function actorFromRequest(req: Request): string {
  const header = req.header('x-actor-id') ?? req.header('x-user-id');
  return header?.trim() || 'system';
}

export function toAuditSnapshot(value: unknown): Record<string, unknown> {
  return JSON.parse(JSON.stringify(value)) as Record<string, unknown>;
}
