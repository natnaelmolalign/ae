import type { Employee } from '../models/types';

export function isContractor1099(employee: Employee): boolean {
  return employee.employmentType === 'contractor';
}
