/**
 * Run async work over items with a maximum number of concurrent workers.
 */
export async function runWithConcurrencyLimit<T>(
  items: T[],
  limit: number,
  worker: (item: T) => Promise<void>
): Promise<void> {
  if (items.length === 0) return;

  const concurrency = Math.max(1, Math.min(limit, items.length));
  let nextIndex = 0;

  async function runWorker(): Promise<void> {
    while (nextIndex < items.length) {
      const current = nextIndex++;
      await worker(items[current]!);
    }
  }

  await Promise.all(Array.from({ length: concurrency }, () => runWorker()));
}
