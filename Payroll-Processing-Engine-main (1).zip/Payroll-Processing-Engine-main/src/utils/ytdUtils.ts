import type { YearToDate } from '../models/types';
import { add, sub, type Money } from './decimalUtils';

export function emptyYtd(employeeId: string, taxYear: number): YearToDate {
  const zero = '0.00';
  return {
    employeeId,
    taxYear,
    grossEarnings: zero,
    federalTaxableWages: zero,
    stateTaxableWages: zero,
    ssTaxableWages: zero,
    medicareTaxableWages: zero,
    federalTaxWithheld: zero,
    stateTaxWithheld: zero,
    ssTaxWithheld: zero,
    medicareTaxWithheld: zero,
    medicareAdditionalWithheld: zero,
    pretax401k: zero,
    roth401k: zero,
    hsa: zero,
    fsa: zero,
    section125: zero,
    supplementalTaxableWages: zero,
  };
}

export function mergeYtdDelta(
  current: YearToDate,
  delta: Partial<Record<keyof YearToDate, Money>>,
  isCorrection: boolean,
  alreadyCountedGross: Money
): YearToDate {
  const result = { ...current };
  const numericKeys: (keyof YearToDate)[] = [
    'grossEarnings',
    'federalTaxableWages',
    'stateTaxableWages',
    'ssTaxableWages',
    'medicareTaxableWages',
    'federalTaxWithheld',
    'stateTaxWithheld',
    'ssTaxWithheld',
    'medicareTaxWithheld',
    'medicareAdditionalWithheld',
    'pretax401k',
    'roth401k',
    'hsa',
    'fsa',
    'section125',
    'supplementalTaxableWages',
  ];

  for (const key of numericKeys) {
    const d = delta[key];
    if (d === undefined) continue;
    if (key === 'grossEarnings' && isCorrection) {
      const adjusted = subMoney(d, alreadyCountedGross);
      result.grossEarnings = add(result.grossEarnings, adjusted);
    } else {
      result[key] = add(result[key] as string, d) as never;
    }
  }
  return result;
}

function subMoney(a: Money, b: Money): Money {
  return sub(a, b);
}
