import type { Employee, PayPeriod } from '../models/types';

export function employeeForTenant(
  employee: Employee | null,
  companyId: string
): Employee | null {
  if (!employee || employee.companyId !== companyId) return null;
  return employee;
}

export function payPeriodForTenant(
  period: PayPeriod | null,
  companyId: string
): PayPeriod | null {
  if (!period) return null;
  if (period.companyId && period.companyId !== companyId) return null;
  return period;
}

export function withCompanyId<T extends { companyId?: string }>(
  items: T[],
  companyId: string
): (T & { companyId: string })[] {
  return items.map((item) => ({ ...item, companyId }));
}
