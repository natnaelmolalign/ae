/** Shallow field-level diff for audit snapshots. */
export function jsonDiff(
  before: Record<string, unknown> | null,
  after: Record<string, unknown> | null
): Record<string, { from: unknown; to: unknown }> {
  const diff: Record<string, { from: unknown; to: unknown }> = {};
  const keys = new Set([
    ...Object.keys(before ?? {}),
    ...Object.keys(after ?? {}),
  ]);

  for (const key of keys) {
    const fromVal = before?.[key];
    const toVal = after?.[key];
    if (JSON.stringify(fromVal) !== JSON.stringify(toVal)) {
      diff[key] = { from: fromVal ?? null, to: toVal ?? null };
    }
  }
  return diff;
}
