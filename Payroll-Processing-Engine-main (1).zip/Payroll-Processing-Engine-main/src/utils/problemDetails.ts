import type { Response } from 'express';

export interface ProblemDetailBody {
  type: string;
  title: string;
  status: number;
  detail: string;
  code?: string;
  correlationId?: string;
  instance?: string;
  [key: string]: unknown;
}

export function problemTypeUri(kind: string): string {
  const base =
    process.env.PROBLEM_TYPE_BASE?.trim() || 'https://payroll.example/problems';
  return `${base}/${kind}`;
}

export function sendProblem(
  res: Response,
  status: number,
  body: Omit<ProblemDetailBody, 'status'> & { status?: number }
): void {
  res
    .status(status)
    .type('application/problem+json')
    .json({ ...body, status });
}
