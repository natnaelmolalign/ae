import { randomUUID } from 'crypto';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';

/** Opaque token for bank account numbers — raw values are not persisted. */
export function tokenizeBankAccount(accountNumber: string): {
  token: string;
  lastFour: string;
} {
  const digits = accountNumber.replace(/\D/g, '');
  if (digits.length < 4) {
    throw new PayrollDomainError(
      PayrollErrorCode.INVALID_INPUT,
      'accountNumber must contain at least 4 digits'
    );
  }
  return {
    token: `tok_acct_${randomUUID()}`,
    lastFour: digits.slice(-4),
  };
}
