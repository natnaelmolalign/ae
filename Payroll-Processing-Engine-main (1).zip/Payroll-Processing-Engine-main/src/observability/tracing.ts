import { createHash, randomBytes } from 'crypto';

const TRACE_VERSION = '00';
const SAMPLED = '01';

/** W3C traceparent: 00-{32 hex trace}-{16 hex span}-{flags} */
export function traceParentFromCorrelationId(correlationId: string): string {
  const traceId = createHash('sha256')
    .update(correlationId)
    .digest('hex')
    .slice(0, 32);
  const spanId = createHash('sha256')
    .update(`${correlationId}:span`)
    .digest('hex')
    .slice(0, 16);
  return `${TRACE_VERSION}-${traceId}-${spanId}-${SAMPLED}`;
}

export function parseTraceParent(
  header: string | undefined
): { traceId: string; spanId: string } | null {
  if (!header?.trim()) return null;
  const parts = header.trim().split('-');
  if (parts.length !== 4 || parts[0] !== TRACE_VERSION) return null;
  const traceId = parts[1];
  const spanId = parts[2];
  if (!/^[0-9a-f]{32}$/i.test(traceId) || !/^[0-9a-f]{16}$/i.test(spanId)) {
    return null;
  }
  return { traceId, spanId };
}

/** Use upstream trace id as correlation id when x-correlation-id is absent. */
export function correlationIdFromTrace(traceId: string): string {
  return `${traceId.slice(0, 8)}-${traceId.slice(8, 12)}-${traceId.slice(12, 16)}-${traceId.slice(16, 20)}-${traceId.slice(20, 32)}`;
}

export function newTraceIds(): { correlationId: string; traceParent: string } {
  const traceId = randomBytes(16).toString('hex');
  const spanId = randomBytes(8).toString('hex');
  const correlationId = correlationIdFromTrace(traceId);
  const traceParent = `${TRACE_VERSION}-${traceId}-${spanId}-${SAMPLED}`;
  return { correlationId, traceParent };
}
