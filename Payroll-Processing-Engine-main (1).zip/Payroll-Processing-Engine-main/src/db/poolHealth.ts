import type { Knex } from 'knex';

export interface PoolHealth {
  healthy: boolean;
  used?: number;
  free?: number;
  pending?: number;
  max?: number;
}

/** Best-effort Knex pool stats for /ready (PostgreSQL pool only). */
export function checkPoolHealth(db: Knex): PoolHealth {
  const pool = (
    db as Knex & {
      client?: { pool?: { numUsed?: () => number; numFree?: () => number } };
    }
  ).client?.pool;

  if (!pool?.numUsed || !pool?.numFree) {
    return { healthy: true };
  }

  const used = pool.numUsed();
  const free = pool.numFree();
  const max = used + free;
  const pending =
    typeof (pool as { numPendingAcquires?: () => number })
      .numPendingAcquires === 'function'
      ? (pool as { numPendingAcquires: () => number }).numPendingAcquires()
      : 0;

  const saturated = max > 0 && free === 0 && pending > 0;

  return {
    healthy: !saturated,
    used,
    free,
    pending,
    max,
  };
}
