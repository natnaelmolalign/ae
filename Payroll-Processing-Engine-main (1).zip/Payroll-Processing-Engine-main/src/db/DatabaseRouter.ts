import type { Knex } from 'knex';
import { getDb } from '../config/database';
import { features } from '../config/features';

export interface DatabaseRouter {
  /** Primary connection for payroll writes and transactions */
  writer: Knex;
  /** Read-only connection for reports (may equal writer until replica is configured) */
  reader: Knex;
  readReplicaConfigured: boolean;
}

let router: DatabaseRouter | null = null;

/**
 * Routes report queries to a read replica when FEATURE_READ_REPLICA and
 * DB_READ_REPLICA_URL are set. Default stub uses the writer pool.
 */
export function getDatabaseRouter(): DatabaseRouter {
  if (router) return router;

  const writer = getDb();
  const replicaUrl = process.env.DB_READ_REPLICA_URL?.trim();
  const useReplica = features.readReplicaEnabled && Boolean(replicaUrl);

  if (!useReplica) {
    router = {
      writer,
      reader: writer,
      readReplicaConfigured: false,
    };
    return router;
  }

  // Stub: dedicated replica pool can be wired here without changing report services.
  router = {
    writer,
    reader: writer,
    readReplicaConfigured: false,
  };
  return router;
}

export function resetDatabaseRouter(): void {
  router = null;
}
