import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('integration_connections', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.string('connector_type', 32).notNullable();
    t.string('name', 128).notNullable();
    t.text('config').nullable();
    t.boolean('is_active').notNullable().defaultTo(true);
    t.timestamps(true, true);
    t.index(
      ['company_id', 'connector_type'],
      'integration_connections_company_type_idx'
    );
  });

  await knex.schema.createTable('gl_account_mappings', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('connection_id')
      .notNullable()
      .references('id')
      .inTable('integration_connections')
      .onDelete('CASCADE');
    t.integer('version').notNullable();
    t.string('internal_account_code', 16).notNullable();
    t.string('external_account_id', 64).notNullable();
    t.string('external_account_name', 128).notNullable();
    t.timestamps(true, true);
    t.unique(
      ['connection_id', 'version', 'internal_account_code'],
      'gl_mappings_conn_version_code_uq'
    );
    t.index(['connection_id', 'version'], 'gl_mappings_conn_version_idx');
  });

  await knex.schema.createTable('export_batches', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('connection_id')
      .notNullable()
      .references('id')
      .inTable('integration_connections');
    t.string('pay_period_id', 64).notNullable();
    t.string('connector_type', 32).notNullable();
    t.string('status', 16).notNullable().defaultTo('submitted');
    t.string('idempotency_key', 64).notNullable();
    t.integer('mapping_version').notNullable();
    t.text('mapping_snapshot').notNullable();
    t.text('connector_payload').notNullable();
    t.text('external_journal_ids').notNullable();
    t.timestamp('submitted_at').notNullable();
    t.timestamps(true, true);
    t.unique(
      ['connection_id', 'idempotency_key'],
      'export_batches_conn_idempotency_uq'
    );
    t.index(
      ['company_id', 'pay_period_id'],
      'export_batches_company_period_idx'
    );
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('export_batches');
  await knex.schema.dropTableIfExists('gl_account_mappings');
  await knex.schema.dropTableIfExists('integration_connections');
}
