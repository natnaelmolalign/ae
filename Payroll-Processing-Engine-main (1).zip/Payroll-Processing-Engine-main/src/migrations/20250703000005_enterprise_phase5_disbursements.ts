import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('disbursement_instructions', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('employee_id')
      .notNullable()
      .references('id')
      .inTable('employees')
      .onDelete('CASCADE');
    t.string('split_type', 16).notNullable();
    t.string('percent', 16).nullable();
    t.string('fixed_amount', 16).nullable();
    t.integer('priority').notNullable().defaultTo(0);
    t.string('routing_number', 9).notNullable();
    t.string('account_number_token', 64).notNullable();
    t.string('account_last_four', 4).notNullable();
    t.string('account_type', 16).notNullable().defaultTo('checking');
    t.boolean('is_active').notNullable().defaultTo(true);
    t.timestamps(true, true);
    t.index(
      ['employee_id', 'is_active'],
      'disbursement_instructions_employee_idx'
    );
  });

  await knex.schema.createTable('payment_batches', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.string('pay_period_id', 64).nullable();
    t.string('status', 16).notNullable().defaultTo('draft');
    t.string('nacha_profile', 8).notNullable().defaultTo('PPD');
    t.string('total_net_pay', 16).notNullable().defaultTo('0.00');
    t.string('total_ach_credit', 16).notNullable().defaultTo('0.00');
    t.integer('payroll_run_count').notNullable().defaultTo(0);
    t.string('idempotency_key', 64).nullable();
    t.timestamp('submitted_at').nullable();
    t.timestamps(true, true);
    t.unique(
      ['company_id', 'idempotency_key'],
      'payment_batches_idempotency_uq'
    );
    t.index(['company_id', 'status'], 'payment_batches_company_status_idx');
  });

  await knex.schema.createTable('payment_batch_items', (t) => {
    t.uuid('id').primary();
    t.uuid('payment_batch_id')
      .notNullable()
      .references('id')
      .inTable('payment_batches')
      .onDelete('CASCADE');
    t.uuid('payroll_run_id')
      .notNullable()
      .references('id')
      .inTable('payroll_runs');
    t.uuid('pay_stub_id').notNullable();
    t.uuid('employee_id').notNullable();
    t.uuid('disbursement_instruction_id')
      .nullable()
      .references('id')
      .inTable('disbursement_instructions')
      .onDelete('SET NULL');
    t.string('amount', 16).notNullable();
    t.string('status', 16).notNullable().defaultTo('pending');
    t.string('account_number_token', 64).notNullable();
    t.string('routing_number', 9).notNullable();
    t.string('account_last_four', 4).notNullable();
    t.timestamps(true, true);
    t.index(['payment_batch_id'], 'payment_batch_items_batch_idx');
  });

  await knex.schema.createTable('ach_files', (t) => {
    t.uuid('id').primary();
    t.uuid('payment_batch_id')
      .notNullable()
      .references('id')
      .inTable('payment_batches')
      .onDelete('CASCADE');
    t.string('file_format', 16).notNullable().defaultTo('nacha');
    t.string('nacha_profile', 8).notNullable();
    t.text('file_content').notNullable();
    t.string('entry_hash_total', 10).notNullable();
    t.string('control_total', 16).notNullable();
    t.integer('entry_count').notNullable();
    t.timestamps(true, true);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('ach_files');
  await knex.schema.dropTableIfExists('payment_batch_items');
  await knex.schema.dropTableIfExists('payment_batches');
  await knex.schema.dropTableIfExists('disbursement_instructions');
}
