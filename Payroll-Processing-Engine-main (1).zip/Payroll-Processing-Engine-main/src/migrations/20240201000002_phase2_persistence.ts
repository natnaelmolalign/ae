import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable('employees', (t) => {
    t.string('w4_extra_withholding', 32).notNullable().defaultTo('0.00');
    t.string('w4_dependents_credit', 32).notNullable().defaultTo('0.00');
  });

  await knex.schema.alterTable('pay_periods', (t) => {
    t.unique(['year', 'frequency', 'period_index'], {
      indexName: 'pay_periods_year_freq_idx_unique',
    });
  });

  await knex.schema.alterTable('ytd_totals', (t) => {
    t.decimal('federal_taxable_wages', 14, 2).notNullable().defaultTo(0);
    t.decimal('state_taxable_wages', 14, 2).notNullable().defaultTo(0);
    t.decimal('medicare_taxable_wages', 14, 2).notNullable().defaultTo(0);
    t.decimal('ss_tax_withheld', 14, 2).notNullable().defaultTo(0);
    t.decimal('state_tax_withheld', 14, 2).notNullable().defaultTo(0);
    t.decimal('medicare_tax_withheld', 14, 2).notNullable().defaultTo(0);
    t.decimal('medicare_additional_withheld', 14, 2).notNullable().defaultTo(0);
    t.decimal('pretax_401k', 14, 2).notNullable().defaultTo(0);
    t.decimal('section_125', 14, 2).notNullable().defaultTo(0);
  });

  await knex.schema.createTable('payroll_runs', (t) => {
    t.uuid('id').primary();
    t.uuid('employee_id').notNullable().references('id').inTable('employees');
    t.string('pay_period_id')
      .notNullable()
      .references('id')
      .inTable('pay_periods');
    t.uuid('pay_stub_id').notNullable().references('id').inTable('pay_stubs');
    t.boolean('is_correction').notNullable().defaultTo(false);
    t.string('idempotency_key', 64).nullable();
    t.json('taxes').notNullable();
    t.json('employer_contributions').notNullable();
    t.timestamps(true, true);
    t.unique(['employee_id', 'pay_period_id', 'is_correction'], {
      indexName: 'payroll_runs_employee_period_correction_unique',
    });
    t.unique(['idempotency_key'], {
      indexName: 'payroll_runs_idempotency_unique',
    });
  });

  await knex.schema.createTable('earnings_lines', (t) => {
    t.uuid('id').primary();
    t.uuid('payroll_run_id')
      .notNullable()
      .references('id')
      .inTable('payroll_runs')
      .onDelete('CASCADE');
    t.string('type').notNullable();
    t.decimal('amount', 14, 2).notNullable();
    t.decimal('hours', 8, 2).nullable();
  });

  await knex.schema.createTable('deduction_enrollments', (t) => {
    t.uuid('id').primary();
    t.uuid('employee_id').notNullable().references('id').inTable('employees');
    t.string('type').notNullable();
    t.decimal('amount_per_period', 14, 2).notNullable();
    t.string('percent_of_gross', 32).nullable();
    t.decimal('annual_limit', 14, 2).nullable();
    t.date('effective_date').notNullable();
    t.date('end_date').nullable();
    t.timestamps(true, true);
  });

  await knex.schema.createTable('audit_events', (t) => {
    t.uuid('id').primary();
    t.string('entity_type', 64).notNullable();
    t.string('entity_id', 64).notNullable();
    t.string('action', 64).notNullable();
    t.json('payload').nullable();
    t.timestamp('created_at').defaultTo(knex.fn.now());
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('audit_events');
  await knex.schema.dropTableIfExists('deduction_enrollments');
  await knex.schema.dropTableIfExists('earnings_lines');
  await knex.schema.dropTableIfExists('payroll_runs');
  await knex.schema.alterTable('ytd_totals', (t) => {
    t.dropColumn('section_125');
    t.dropColumn('pretax_401k');
    t.dropColumn('medicare_additional_withheld');
    t.dropColumn('medicare_tax_withheld');
    t.dropColumn('state_tax_withheld');
    t.dropColumn('ss_tax_withheld');
    t.dropColumn('medicare_taxable_wages');
    t.dropColumn('state_taxable_wages');
    t.dropColumn('federal_taxable_wages');
  });
  await knex.schema.alterTable('pay_periods', (t) => {
    t.dropUnique(
      ['year', 'frequency', 'period_index'],
      'pay_periods_year_freq_idx_unique'
    );
  });
  await knex.schema.alterTable('employees', (t) => {
    t.dropColumn('w4_dependents_credit');
    t.dropColumn('w4_extra_withholding');
  });
}
