import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('payroll_holds', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('employee_id')
      .notNullable()
      .references('id')
      .inTable('employees')
      .onDelete('CASCADE');
    t.string('reason_code', 64).notNullable();
    t.text('notes').nullable();
    t.string('status', 16).notNullable().defaultTo('active');
    t.string('created_by', 128).notNullable();
    t.string('released_by', 128).nullable();
    t.timestamp('released_at').nullable();
    t.string('release_reason', 128).nullable();
    t.timestamps(true, true);
    t.index(['employee_id', 'status'], 'payroll_holds_employee_status_idx');
  });

  await knex.schema.createTable('approval_requests', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('employee_id')
      .notNullable()
      .references('id')
      .inTable('employees')
      .onDelete('CASCADE');
    t.string('pay_period_id', 64).notNullable();
    t.uuid('payroll_run_id').nullable();
    t.string('requested_amount', 32).notNullable();
    t.string('z_score', 32).notNullable();
    t.string('threshold', 32).notNullable();
    t.string('status', 16).notNullable().defaultTo('pending');
    t.string('requested_by', 128).notNullable();
    t.string('reviewed_by', 128).nullable();
    t.timestamp('reviewed_at').nullable();
    t.text('review_notes').nullable();
    t.timestamps(true, true);
    t.index(['company_id', 'status'], 'approval_requests_company_status_idx');
  });

  await knex.schema.createTable('anomaly_flags', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('employee_id')
      .notNullable()
      .references('id')
      .inTable('employees')
      .onDelete('CASCADE');
    t.string('pay_period_id', 64).notNullable();
    t.string('metric', 64).notNullable();
    t.string('amount', 32).notNullable();
    t.string('trailing_average', 32).notNullable();
    t.string('z_score', 32).notNullable();
    t.string('threshold', 32).notNullable();
    t.timestamp('created_at').notNullable().defaultTo(knex.fn.now());
    t.index(['employee_id', 'pay_period_id'], 'anomaly_flags_emp_period_idx');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('anomaly_flags');
  await knex.schema.dropTableIfExists('approval_requests');
  await knex.schema.dropTableIfExists('payroll_holds');
}
