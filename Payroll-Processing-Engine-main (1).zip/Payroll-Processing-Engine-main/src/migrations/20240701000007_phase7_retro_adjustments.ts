import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable('pay_stubs', (t) => {
    t.uuid('corrects_pay_stub_id')
      .nullable()
      .references('id')
      .inTable('pay_stubs');
    t.boolean('negative_net_recovery').notNullable().defaultTo(false);
  });

  await knex.schema.createTable('retro_adjustments', (t) => {
    t.uuid('id').primary();
    t.uuid('employee_id').notNullable().references('id').inTable('employees');
    t.string('status', 32).notNullable().defaultTo('draft');
    t.date('effective_date').notNullable();
    t.string('current_pay_period_id')
      .notNullable()
      .references('id')
      .inTable('pay_periods');
    t.text('reason').notNullable();
    t.json('earnings_per_period').notNullable();
    t.json('preview').nullable();
    t.uuid('catch_up_pay_stub_id')
      .nullable()
      .references('id')
      .inTable('pay_stubs');
    t.timestamps(true, true);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('retro_adjustments');
  await knex.schema.alterTable('pay_stubs', (t) => {
    t.dropColumn('corrects_pay_stub_id');
    t.dropColumn('negative_net_recovery');
  });
}
