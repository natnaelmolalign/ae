import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('deduction_schedules', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('employee_id').notNullable().references('id').inTable('employees');
    t.string('schedule_type', 32).notNullable();
    t.decimal('amount_per_period', 14, 2).notNullable();
    t.decimal('remaining_balance', 14, 2).nullable();
    t.integer('priority').notNullable().defaultTo(100);
    t.date('start_date').notNullable();
    t.date('end_date').nullable();
    t.timestamps(true, true);
    t.index(
      ['employee_id', 'start_date'],
      'deduction_schedules_employee_start_idx'
    );
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('deduction_schedules');
}
