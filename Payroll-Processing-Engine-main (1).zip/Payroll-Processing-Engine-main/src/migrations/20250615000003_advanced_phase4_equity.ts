import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable('employees', (t) => {
    t.string('equity_withholding_method', 32)
      .notNullable()
      .defaultTo('supplemental_flat');
  });

  await knex.schema.alterTable('ytd_totals', (t) => {
    t.decimal('supplemental_taxable_wages', 14, 2).notNullable().defaultTo(0);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('ytd_totals', (t) => {
    t.dropColumn('supplemental_taxable_wages');
  });
  await knex.schema.alterTable('employees', (t) => {
    t.dropColumn('equity_withholding_method');
  });
}
