import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('queue_jobs', (t) => {
    t.uuid('id').primary();
    t.string('job_type', 64).notNullable();
    t.string('partition_key', 128).notNullable();
    t.text('payload').notNullable();
    t.string('status', 16).notNullable().defaultTo('pending');
    t.integer('attempts').notNullable().defaultTo(0);
    t.integer('max_attempts').notNullable().defaultTo(3);
    t.text('last_error').nullable();
    t.string('locked_by', 64).nullable();
    t.timestamp('locked_at').nullable();
    t.timestamps(true, true);
    t.index(['status', 'partition_key', 'created_at'], 'queue_jobs_poll_idx');
  });

  await knex.schema.createTable('queue_dead_letters', (t) => {
    t.uuid('id').primary();
    t.uuid('original_job_id').notNullable();
    t.string('job_type', 64).notNullable();
    t.string('partition_key', 128).notNullable();
    t.text('payload').notNullable();
    t.integer('attempts').notNullable();
    t.text('last_error').notNullable();
    t.timestamp('failed_at').notNullable();
    t.index(['failed_at'], 'queue_dlq_failed_at_idx');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('queue_dead_letters');
  await knex.schema.dropTableIfExists('queue_jobs');
}
