import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('garnishment_orders', (t) => {
    t.uuid('id').primary();
    t.uuid('employee_id').notNullable().references('id').inTable('employees');
    t.string('type', 32).notNullable();
    t.string('case_id', 64).notNullable();
    t.integer('priority').notNullable().defaultTo(0);
    t.decimal('fixed_amount', 14, 2).notNullable();
    t.string('max_percent_of_disposable', 32).nullable();
    t.date('effective_date').notNullable();
    t.date('end_date').nullable();
    t.timestamps(true, true);
  });

  await knex.schema.createTable('garnishment_remittances', (t) => {
    t.uuid('id').primary();
    t.uuid('payroll_run_id')
      .notNullable()
      .references('id')
      .inTable('payroll_runs')
      .onDelete('CASCADE');
    t.uuid('garnishment_order_id')
      .notNullable()
      .references('id')
      .inTable('garnishment_orders');
    t.string('case_id', 64).notNullable();
    t.string('order_type', 32).notNullable();
    t.decimal('amount', 14, 2).notNullable();
    t.timestamp('created_at').defaultTo(knex.fn.now());
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('garnishment_remittances');
  await knex.schema.dropTableIfExists('garnishment_orders');
}
