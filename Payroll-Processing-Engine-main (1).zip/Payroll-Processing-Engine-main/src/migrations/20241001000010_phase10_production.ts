import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable('employees', (t) => {
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.index(['company_id'], 'employees_company_id_idx');
  });

  await knex.schema.alterTable('pay_periods', (t) => {
    t.string('company_id', 64).notNullable().defaultTo('default');
  });

  await knex.schema.alterTable('pay_periods', (t) => {
    t.dropUnique(
      ['year', 'frequency', 'period_index'],
      'pay_periods_year_freq_idx_unique'
    );
  });

  await knex.schema.alterTable('pay_periods', (t) => {
    t.unique(['company_id', 'year', 'frequency', 'period_index'], {
      indexName: 'pay_periods_company_year_freq_idx_unique',
    });
  });

  await knex.schema.alterTable('payroll_batches', (t) => {
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.index(['company_id'], 'payroll_batches_company_id_idx');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('payroll_batches', (t) => {
    t.dropIndex(['company_id'], 'payroll_batches_company_id_idx');
    t.dropColumn('company_id');
  });

  await knex.schema.alterTable('pay_periods', (t) => {
    t.dropUnique(
      ['company_id', 'year', 'frequency', 'period_index'],
      'pay_periods_company_year_freq_idx_unique'
    );
  });

  await knex.schema.alterTable('pay_periods', (t) => {
    t.unique(['year', 'frequency', 'period_index'], {
      indexName: 'pay_periods_year_freq_idx_unique',
    });
    t.dropColumn('company_id');
  });

  await knex.schema.alterTable('employees', (t) => {
    t.dropIndex(['company_id'], 'employees_company_id_idx');
    t.dropColumn('company_id');
  });
}
