import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('time_entries', (t) => {
    t.uuid('id').primary();
    t.uuid('employee_id').notNullable().references('id').inTable('employees');
    t.string('pay_period_id')
      .nullable()
      .references('id')
      .inTable('pay_periods');
    t.date('work_date').notNullable();
    t.timestamp('clock_in').notNullable();
    t.timestamp('clock_out').notNullable();
    t.integer('rounded_minutes').notNullable();
    t.string('entry_type', 32).notNullable().defaultTo('regular');
    t.timestamps(true, true);
    t.index(['employee_id', 'work_date']);
    t.index(['employee_id', 'pay_period_id']);
  });

  await knex.schema.createTable('jurisdiction_rules', (t) => {
    t.string('state_code', 8).primary();
    t.integer('weekly_ot_threshold_hours').notNullable().defaultTo(40);
    t.string('ot_multiplier', 8).notNullable().defaultTo('1.5');
    t.string('double_time_multiplier', 8).notNullable().defaultTo('2.0');
    t.string('holiday_multiplier', 8).notNullable().defaultTo('1.5');
    t.boolean('holiday_exempt_from_fica').notNullable().defaultTo(false);
    t.integer('work_week_start_day').notNullable().defaultTo(1);
  });

  await knex('jurisdiction_rules').insert([
    {
      state_code: 'DEFAULT',
      weekly_ot_threshold_hours: 40,
      ot_multiplier: '1.5',
      double_time_multiplier: '2.0',
      holiday_multiplier: '1.5',
      holiday_exempt_from_fica: false,
      work_week_start_day: 1,
    },
    {
      state_code: 'CA',
      weekly_ot_threshold_hours: 40,
      ot_multiplier: '1.5',
      double_time_multiplier: '2.0',
      holiday_multiplier: '1.5',
      holiday_exempt_from_fica: false,
      work_week_start_day: 1,
    },
    {
      state_code: 'TX',
      weekly_ot_threshold_hours: 40,
      ot_multiplier: '1.5',
      double_time_multiplier: '2.0',
      holiday_multiplier: '1.0',
      holiday_exempt_from_fica: false,
      work_week_start_day: 1,
    },
  ]);
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('time_entries');
  await knex.schema.dropTableIfExists('jurisdiction_rules');
}
