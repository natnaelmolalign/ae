import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('enrollment_windows', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.string('code', 32).notNullable();
    t.string('name', 128).notNullable();
    t.integer('plan_year').notNullable();
    t.date('start_date').notNullable();
    t.date('end_date').notNullable();
    t.string('status', 16).notNullable().defaultTo('open');
    t.text('allowed_benefit_types').notNullable();
    t.timestamps(true, true);
    t.unique(['company_id', 'code'], 'enrollment_windows_company_code_uq');
    t.index(
      ['company_id', 'plan_year', 'status'],
      'enrollment_windows_year_status_idx'
    );
  });

  await knex.schema.createTable('eligibility_rules', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.string('benefit_type', 32).notNullable();
    t.text('employment_types').nullable();
    t.integer('min_tenure_days').nullable();
    t.boolean('requires_enrollment_window').notNullable().defaultTo(true);
    t.boolean('is_active').notNullable().defaultTo(true);
    t.timestamps(true, true);
    t.index(
      ['company_id', 'benefit_type'],
      'eligibility_rules_company_type_idx'
    );
  });

  await knex.schema.createTable('life_events', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('employee_id')
      .notNullable()
      .references('id')
      .inTable('employees')
      .onDelete('CASCADE');
    t.string('event_type', 32).notNullable();
    t.date('event_date').notNullable();
    t.date('coverage_effective_date').notNullable();
    t.string('status', 16).notNullable().defaultTo('pending');
    t.timestamp('approved_at').nullable();
    t.string('approved_by', 128).nullable();
    t.uuid('cobra_schedule_id').nullable();
    t.text('notes').nullable();
    t.timestamps(true, true);
    t.index(['employee_id', 'status'], 'life_events_employee_status_idx');
  });

  await knex.schema.alterTable('deduction_enrollments', (t) => {
    t.uuid('life_event_id')
      .nullable()
      .references('id')
      .inTable('life_events')
      .onDelete('SET NULL');
    t.uuid('enrollment_window_id')
      .nullable()
      .references('id')
      .inTable('enrollment_windows')
      .onDelete('SET NULL');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('deduction_enrollments', (t) => {
    t.dropColumn('enrollment_window_id');
    t.dropColumn('life_event_id');
  });
  await knex.schema.dropTableIfExists('life_events');
  await knex.schema.dropTableIfExists('eligibility_rules');
  await knex.schema.dropTableIfExists('enrollment_windows');
}
