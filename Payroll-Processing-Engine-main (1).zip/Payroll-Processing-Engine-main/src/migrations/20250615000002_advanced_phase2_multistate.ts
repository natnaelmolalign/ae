import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('employee_work_locations', (t) => {
    t.uuid('id').primary();
    t.uuid('employee_id').notNullable().references('id').inTable('employees');
    t.string('state_code', 2).notNullable();
    t.decimal('allocation_percent', 5, 2).notNullable();
    t.date('effective_date').notNullable();
    t.date('end_date').nullable();
    t.timestamps(true, true);
    t.unique(['employee_id', 'state_code', 'effective_date'], {
      indexName: 'employee_work_locations_emp_state_effective_unique',
    });
  });

  await knex.schema.createTable('payroll_run_state_allocations', (t) => {
    t.uuid('id').primary();
    t.uuid('payroll_run_id')
      .notNullable()
      .references('id')
      .inTable('payroll_runs')
      .onDelete('CASCADE');
    t.string('state_code', 2).notNullable();
    t.decimal('allocation_percent', 5, 2).notNullable();
    t.decimal('allocated_wages', 14, 2).notNullable();
    t.decimal('state_tax_withheld', 14, 2).notNullable();
    t.timestamps(true, true);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('payroll_run_state_allocations');
  await knex.schema.dropTableIfExists('employee_work_locations');
}
