import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable('employees', (t) => {
    t.text('tin_encrypted').nullable();
    t.string('tin_key_id', 64).nullable();
    t.string('tin_last_four', 4).nullable();
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('employees', (t) => {
    t.dropColumn('tin_encrypted');
    t.dropColumn('tin_key_id');
    t.dropColumn('tin_last_four');
  });
}
