import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('w4_change_requests', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('employee_id')
      .notNullable()
      .references('id')
      .inTable('employees')
      .onDelete('CASCADE');
    t.string('status', 16).notNullable().defaultTo('draft');
    t.string('filing_status', 32).notNullable();
    t.string('w4_extra_withholding', 32).notNullable().defaultTo('0.00');
    t.string('w4_dependents_credit', 32).notNullable().defaultTo('0.00');
    t.string('w4_other_deductions', 32).notNullable().defaultTo('0.00');
    t.string('w4_other_income', 32).notNullable().defaultTo('0.00');
    t.boolean('w4_multiple_jobs').notNullable().defaultTo(false);
    t.timestamp('submitted_at').nullable();
    t.timestamp('reviewed_at').nullable();
    t.string('reviewed_by', 128).nullable();
    t.timestamp('applied_at').nullable();
    t.text('review_notes').nullable();
    t.timestamps(true, true);
    t.index(
      ['employee_id', 'status'],
      'w4_change_requests_employee_status_idx'
    );
    t.index(['company_id', 'status'], 'w4_change_requests_company_status_idx');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('w4_change_requests');
}
