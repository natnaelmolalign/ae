import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('employees', (t) => {
    t.uuid('id').primary();
    t.string('first_name').notNullable();
    t.string('last_name').notNullable();
    t.string('employment_type').notNullable();
    t.string('pay_frequency').notNullable();
    t.decimal('base_compensation', 14, 2).notNullable();
    t.date('hire_date').notNullable();
    t.date('termination_date').nullable();
    t.string('filing_status').notNullable();
    t.string('state_code', 2).notNullable();
    t.timestamps(true, true);
  });

  await knex.schema.createTable('pay_periods', (t) => {
    t.string('id').primary();
    t.date('start_date').notNullable();
    t.date('end_date').notNullable();
    t.date('payment_date').notNullable();
    t.string('frequency').notNullable();
    t.integer('year').notNullable();
    t.integer('period_index').notNullable();
  });

  await knex.schema.createTable('pay_stubs', (t) => {
    t.uuid('id').primary();
    t.uuid('employee_id').references('id').inTable('employees');
    t.string('pay_period_id').references('id').inTable('pay_periods');
    t.decimal('gross_pay', 14, 2).notNullable();
    t.decimal('net_pay', 14, 2).notNullable();
    t.boolean('is_correction').defaultTo(false);
    t.json('lines').notNullable();
    t.timestamps(true, true);
  });

  await knex.schema.createTable('ytd_totals', (t) => {
    t.uuid('employee_id').references('id').inTable('employees');
    t.integer('tax_year').notNullable();
    t.decimal('gross_earnings', 14, 2).defaultTo(0);
    t.decimal('ss_taxable_wages', 14, 2).defaultTo(0);
    t.decimal('federal_tax_withheld', 14, 2).defaultTo(0);
    t.primary(['employee_id', 'tax_year']);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('ytd_totals');
  await knex.schema.dropTableIfExists('pay_stubs');
  await knex.schema.dropTableIfExists('pay_periods');
  await knex.schema.dropTableIfExists('employees');
}
