import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable('audit_events', (t) => {
    t.string('actor', 128).notNullable().defaultTo('system');
    t.json('before_snapshot').nullable();
    t.json('after_snapshot').nullable();
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('audit_events', (t) => {
    t.dropColumn('actor');
    t.dropColumn('before_snapshot');
    t.dropColumn('after_snapshot');
  });
}
