import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable('deduction_enrollments', (t) => {
    t.string('hsa_coverage', 16).nullable();
    t.boolean('catch_up_eligible').notNullable().defaultTo(false);
    t.integer('priority').notNullable().defaultTo(0);
  });

  await knex.schema.alterTable('ytd_totals', (t) => {
    t.decimal('roth_401k', 14, 2).notNullable().defaultTo(0);
    t.decimal('hsa', 14, 2).notNullable().defaultTo(0);
    t.decimal('fsa', 14, 2).notNullable().defaultTo(0);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('ytd_totals', (t) => {
    t.dropColumn('fsa');
    t.dropColumn('hsa');
    t.dropColumn('roth_401k');
  });
  await knex.schema.alterTable('deduction_enrollments', (t) => {
    t.dropColumn('priority');
    t.dropColumn('catch_up_eligible');
    t.dropColumn('hsa_coverage');
  });
}
