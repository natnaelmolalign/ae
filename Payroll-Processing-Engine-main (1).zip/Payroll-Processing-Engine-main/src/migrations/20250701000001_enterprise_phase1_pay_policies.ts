import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('pay_policies', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.string('code', 32).notNullable();
    t.string('name', 128).notNullable();
    t.string('scope', 16).notNullable().defaultTo('company');
    t.uuid('employee_id').nullable().references('id').inTable('employees');
    t.integer('priority').notNullable().defaultTo(0);
    t.json('rules').notNullable();
    t.date('effective_from').notNullable();
    t.date('effective_to').nullable();
    t.boolean('is_active').notNullable().defaultTo(true);
    t.timestamps(true, true);
    t.unique(['company_id', 'code'], {
      indexName: 'pay_policies_company_code_unique',
    });
    t.index(['company_id', 'is_active'], 'pay_policies_company_active_idx');
    t.index(['employee_id'], 'pay_policies_employee_idx');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('pay_policies');
}
