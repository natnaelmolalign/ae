import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('payroll_batches', (t) => {
    t.uuid('id').primary();
    t.string('pay_period_id')
      .notNullable()
      .references('id')
      .inTable('pay_periods');
    t.integer('year').notNullable();
    t.string('frequency', 32).notNullable();
    t.string('status', 32).notNullable().defaultTo('pending');
    t.timestamp('started_at').nullable();
    t.timestamp('completed_at').nullable();
    t.integer('success_count').notNullable().defaultTo(0);
    t.integer('failure_count').notNullable().defaultTo(0);
    t.integer('total_count').notNullable().defaultTo(0);
    t.integer('duration_ms').nullable();
    t.timestamps(true, true);
  });

  await knex.schema.createTable('employee_payroll_readiness', (t) => {
    t.uuid('employee_id').notNullable().references('id').inTable('employees');
    t.string('pay_period_id')
      .notNullable()
      .references('id')
      .inTable('pay_periods');
    t.string('status', 32).notNullable().defaultTo('ready');
    t.timestamps(true, true);
    t.unique(['employee_id', 'pay_period_id'], {
      indexName: 'employee_payroll_readiness_unique',
    });
  });

  await knex.schema.createTable('payroll_run_failures', (t) => {
    t.uuid('id').primary();
    t.uuid('batch_id').nullable().references('id').inTable('payroll_batches');
    t.uuid('employee_id').notNullable().references('id').inTable('employees');
    t.string('pay_period_id')
      .notNullable()
      .references('id')
      .inTable('pay_periods');
    t.string('idempotency_key', 128).nullable();
    t.string('error_code', 64).notNullable();
    t.text('error_message').notNullable();
    t.json('payload').nullable();
    t.boolean('retryable').notNullable().defaultTo(true);
    t.timestamps(true, true);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('payroll_run_failures');
  await knex.schema.dropTableIfExists('employee_payroll_readiness');
  await knex.schema.dropTableIfExists('payroll_batches');
}
