import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('shifts', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.date('work_date').notNullable();
    t.timestamp('start_time').notNullable();
    t.timestamp('end_time').notNullable();
    t.integer('break_minutes').notNullable().defaultTo(0);
    t.uuid('department_id').nullable().references('id').inTable('departments');
    t.string('location_code', 32).nullable();
    t.timestamps(true, true);
    t.index(['company_id', 'work_date'], 'shifts_company_date_idx');
  });

  await knex.schema.createTable('shift_assignments', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('shift_id')
      .notNullable()
      .references('id')
      .inTable('shifts')
      .onDelete('CASCADE');
    t.uuid('employee_id')
      .notNullable()
      .references('id')
      .inTable('employees')
      .onDelete('CASCADE');
    t.string('status', 32).notNullable().defaultTo('pending');
    t.integer('scheduled_minutes').notNullable();
    t.integer('approved_minutes').nullable();
    t.timestamp('approved_at').nullable();
    t.string('approved_by', 128).nullable();
    t.uuid('payroll_run_id').nullable();
    t.timestamps(true, true);
    t.index(['employee_id', 'status'], 'shift_assignments_employee_status_idx');
    t.index(['shift_id'], 'shift_assignments_shift_idx');
  });

  await knex.schema.createTable('time_exceptions', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('shift_assignment_id')
      .notNullable()
      .references('id')
      .inTable('shift_assignments')
      .onDelete('CASCADE');
    t.string('exception_type', 32).notNullable();
    t.text('notes').notNullable();
    t.boolean('resolved').notNullable().defaultTo(false);
    t.timestamp('created_at').notNullable().defaultTo(knex.fn.now());
    t.index(['shift_assignment_id'], 'time_exceptions_assignment_idx');
  });

  await knex.schema.alterTable('time_entries', (t) => {
    t.uuid('shift_assignment_id')
      .nullable()
      .references('id')
      .inTable('shift_assignments')
      .onDelete('SET NULL');
    t.index(['shift_assignment_id'], 'time_entries_shift_assignment_idx');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('time_entries', (t) => {
    t.dropColumn('shift_assignment_id');
  });
  await knex.schema.dropTableIfExists('time_exceptions');
  await knex.schema.dropTableIfExists('shift_assignments');
  await knex.schema.dropTableIfExists('shifts');
}
