import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable('employees', (table) => {
    table.decimal('w4_other_deductions', 14, 2).notNullable().defaultTo(0);
    table.decimal('w4_other_income', 14, 2).notNullable().defaultTo(0);
    table.boolean('w4_multiple_jobs').notNullable().defaultTo(false);
    table.string('local_municipality_code', 16).nullable();
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('employees', (table) => {
    table.dropColumn('w4_other_deductions');
    table.dropColumn('w4_other_income');
    table.dropColumn('w4_multiple_jobs');
    table.dropColumn('local_municipality_code');
  });
}
