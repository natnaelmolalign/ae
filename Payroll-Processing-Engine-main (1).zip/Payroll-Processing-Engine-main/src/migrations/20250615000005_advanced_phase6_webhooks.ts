import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('webhook_subscriptions', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.string('url', 2048).notNullable();
    t.string('secret', 256).notNullable();
    t.json('events').notNullable();
    t.boolean('enabled').notNullable().defaultTo(true);
    t.integer('consecutive_failures').notNullable().defaultTo(0);
    t.timestamp('disabled_at').nullable();
    t.timestamps(true, true);
    t.index(
      ['company_id', 'enabled'],
      'webhook_subscriptions_company_enabled_idx'
    );
  });

  await knex.schema.createTable('webhook_outbox', (t) => {
    t.uuid('id').primary();
    t.uuid('subscription_id')
      .notNullable()
      .references('id')
      .inTable('webhook_subscriptions');
    t.string('company_id', 64).notNullable();
    t.string('event_type', 64).notNullable();
    t.json('payload').notNullable();
    t.string('status', 32).notNullable().defaultTo('pending');
    t.integer('attempts').notNullable().defaultTo(0);
    t.timestamp('next_attempt_at').nullable();
    t.timestamp('delivered_at').nullable();
    t.timestamps(true, true);
    t.index(['status', 'next_attempt_at'], 'webhook_outbox_status_next_idx');
  });

  await knex.schema.createTable('webhook_deliveries', (t) => {
    t.uuid('id').primary();
    t.uuid('outbox_id')
      .notNullable()
      .references('id')
      .inTable('webhook_outbox')
      .onDelete('CASCADE');
    t.integer('attempt_number').notNullable();
    t.integer('http_status').nullable();
    t.string('error_message', 512).nullable();
    t.timestamp('created_at').notNullable().defaultTo(knex.fn.now());
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('webhook_deliveries');
  await knex.schema.dropTableIfExists('webhook_outbox');
  await knex.schema.dropTableIfExists('webhook_subscriptions');
}
