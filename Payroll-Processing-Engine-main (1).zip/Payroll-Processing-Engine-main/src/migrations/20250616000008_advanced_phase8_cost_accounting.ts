import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('departments', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.string('code', 32).notNullable();
    t.string('name', 128).notNullable();
    t.string('location_code', 32).nullable();
    t.boolean('is_system').notNullable().defaultTo(false);
    t.timestamps(true, true);
    t.unique(['company_id', 'code'], {
      indexName: 'departments_company_code_unique',
    });
    t.index(['company_id'], 'departments_company_id_idx');
  });

  await knex.schema.createTable('jobs', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('department_id')
      .notNullable()
      .references('id')
      .inTable('departments')
      .onDelete('CASCADE');
    t.string('code', 32).notNullable();
    t.string('name', 128).notNullable();
    t.timestamps(true, true);
    t.unique(['company_id', 'department_id', 'code'], {
      indexName: 'jobs_company_dept_code_unique',
    });
    t.index(['department_id'], 'jobs_department_id_idx');
  });

  await knex.schema.createTable('payroll_run_allocations', (t) => {
    t.uuid('id').primary();
    t.uuid('payroll_run_id')
      .notNullable()
      .references('id')
      .inTable('payroll_runs')
      .onDelete('CASCADE');
    t.uuid('department_id')
      .notNullable()
      .references('id')
      .inTable('departments');
    t.uuid('job_id').nullable().references('id').inTable('jobs');
    t.string('allocation_percent', 16).notNullable();
    t.string('allocation_hours', 16).nullable();
    t.timestamps(true, true);
    t.index(['payroll_run_id'], 'payroll_run_allocations_run_idx');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('payroll_run_allocations');
  await knex.schema.dropTableIfExists('jobs');
  await knex.schema.dropTableIfExists('departments');
}
