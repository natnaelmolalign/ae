import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('leave_policies', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.string('code', 32).notNullable();
    t.string('name', 128).notNullable();
    t.string('leave_type', 16).notNullable();
    t.string('accrual_method', 32).notNullable();
    t.json('accrual_config').notNullable();
    t.string('carryover_max_hours', 16).nullable();
    t.date('effective_from').notNullable();
    t.date('effective_to').nullable();
    t.boolean('is_active').notNullable().defaultTo(true);
    t.timestamps(true, true);
    t.unique(['company_id', 'code'], {
      indexName: 'leave_policies_company_code_unique',
    });
    t.index(
      ['company_id', 'leave_type', 'is_active'],
      'leave_policies_active_idx'
    );
  });

  await knex.schema.createTable('leave_balances', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('employee_id')
      .notNullable()
      .references('id')
      .inTable('employees')
      .onDelete('CASCADE');
    t.string('leave_type', 16).notNullable();
    t.uuid('policy_id')
      .notNullable()
      .references('id')
      .inTable('leave_policies')
      .onDelete('CASCADE');
    t.integer('calendar_year').notNullable();
    t.string('balance_hours', 16).notNullable().defaultTo('0.00');
    t.timestamps(true, true);
    t.unique(['employee_id', 'leave_type', 'calendar_year'], {
      indexName: 'leave_balances_employee_type_year_unique',
    });
    t.index(
      ['company_id', 'employee_id'],
      'leave_balances_company_employee_idx'
    );
  });

  await knex.schema.createTable('leave_transactions', (t) => {
    t.uuid('id').primary();
    t.string('company_id', 64).notNullable().defaultTo('default');
    t.uuid('employee_id')
      .notNullable()
      .references('id')
      .inTable('employees')
      .onDelete('CASCADE');
    t.string('leave_type', 16).notNullable();
    t.uuid('policy_id')
      .notNullable()
      .references('id')
      .inTable('leave_policies')
      .onDelete('CASCADE');
    t.integer('calendar_year').notNullable();
    t.string('transaction_type', 16).notNullable();
    t.string('hours', 16).notNullable();
    t.string('balance_after', 16).notNullable();
    t.string('pay_period_id', 64).nullable();
    t.uuid('payroll_run_id').nullable();
    t.text('notes').nullable();
    t.string('actor', 128).nullable();
    t.timestamp('created_at').notNullable().defaultTo(knex.fn.now());
    t.index(
      ['employee_id', 'policy_id', 'pay_period_id'],
      'leave_txn_period_idx'
    );
    t.index(['employee_id', 'calendar_year'], 'leave_txn_employee_year_idx');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('leave_transactions');
  await knex.schema.dropTableIfExists('leave_balances');
  await knex.schema.dropTableIfExists('leave_policies');
}
