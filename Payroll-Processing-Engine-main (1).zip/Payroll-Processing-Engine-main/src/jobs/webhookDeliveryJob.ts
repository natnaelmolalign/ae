import { getAppDependencies } from '../deps';
import type { DeliveryWorkerResult } from '../services/webhooks/WebhookDeliveryWorker';

export async function runWebhookDelivery(
  limit = 50
): Promise<DeliveryWorkerResult> {
  const deps = await getAppDependencies();
  return deps.webhookDeliveryWorker.processPending(limit);
}
