import { getAppDependencies } from '../deps';
import { runWithConcurrencyLimit } from '../utils/parallelLimit';

export interface ScheduledPayrollOptions {
  year: number;
  payPeriodId: string;
  frequency: string;
  parallelLimit?: number;
}

/**
 * Phase 8 scheduler: process only employees marked `ready` for the pay period.
 */
export async function runScheduledPayroll(
  options: ScheduledPayrollOptions
): Promise<{ processed: number; failed: number }> {
  const deps = await getAppDependencies();
  const payPeriod = await deps.payPeriodRepository.findById(
    options.payPeriodId
  );
  if (!payPeriod) {
    return { processed: 0, failed: 0 };
  }

  const readyIds =
    await deps.employeePayrollReadinessRepository.findReadyEmployeeIds(
      options.payPeriodId
    );
  if (readyIds.length === 0) {
    return { processed: 0, failed: 0 };
  }

  const result = await deps.payrollBatchService.createAndRun({
    companyId: payPeriod.companyId ?? 'default',
    payPeriod,
    year: options.year,
    frequency: options.frequency,
    parallelLimit: options.parallelLimit ?? 4,
    employeeIds: readyIds,
  });

  return {
    processed: result.batch.successCount,
    failed: result.batch.failureCount,
  };
}

/**
 * Legacy entry: run last period of year for every employee (sequential fallback).
 */
export async function runScheduledPayrollLegacy(year: number): Promise<number> {
  const deps = await getAppDependencies();
  const allEmployees = await deps.db('employees').select('id');
  let count = 0;

  await runWithConcurrencyLimit(
    allEmployees as { id: string }[],
    1,
    async (row) => {
      const employee = await deps.employeeRepository.findById(row.id);
      if (!employee) return;

      const periods = await deps.payPeriodRepository.findByYearAndFrequency(
        year,
        employee.payFrequency,
        employee.companyId
      );
      if (!periods.length) return;

      const last = periods[periods.length - 1]!;
      await deps.employeePayrollReadinessRepository.upsertReady(
        employee.id,
        last.id
      );
      await deps.payrollRunService.run(employee, last, {
        employeeId: employee.id,
        payPeriodId: last.id,
        earnings: [{ type: 'regular', amount: employee.baseCompensation }],
        deductions: [],
        garnishments: [],
      });
      count += 1;
    }
  );

  return count;
}
