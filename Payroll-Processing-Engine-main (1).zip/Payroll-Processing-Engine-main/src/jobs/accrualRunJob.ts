import { getAppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';

export interface AccrualRunJobInput {
  companyId: string;
  payPeriodId: string;
}

export async function runAccrualForPayPeriod(input: AccrualRunJobInput) {
  const deps = await getAppDependencies();
  const payPeriod = await deps.payPeriodRepository.findById(input.payPeriodId);
  if (!payPeriod) {
    throw PayrollDomainError.notFound('PayPeriod', input.payPeriodId);
  }
  return deps.leaveAccrualService.runForPayPeriod(input.companyId, payPeriod);
}
