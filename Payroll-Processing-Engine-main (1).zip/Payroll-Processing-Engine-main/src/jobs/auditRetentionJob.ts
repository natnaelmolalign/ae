import { auditRetentionDays } from '../config/audit';
import { getAppDependencies } from '../deps';

/** Delete audit rows past retention window (append-only store maintenance). */
export async function purgeExpiredAuditEvents(): Promise<number> {
  const deps = await getAppDependencies();
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - auditRetentionDays);
  return deps.auditEventRepository.deleteOlderThan(cutoff.toISOString());
}
