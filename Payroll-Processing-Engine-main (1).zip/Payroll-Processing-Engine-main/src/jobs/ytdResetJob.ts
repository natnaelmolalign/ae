import type { Knex } from 'knex';
import { getAppDependencies } from '../deps';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';
import { paymentYear } from '../utils/payPeriodUtils';

export interface YtdResetResult {
  taxYear: number;
  deletedRows: number;
  payrollRunsInYear: number;
}

async function countPayrollRunsForPaymentYear(
  db: Knex,
  taxYear: number
): Promise<number> {
  const rows = await db('payroll_runs as pr')
    .join('pay_periods as pp', 'pr.pay_period_id', 'pp.id')
    .select('pp.payment_date');

  let count = 0;
  for (const row of rows) {
    const date = String(row.payment_date).slice(0, 10);
    if (paymentYear(date) === taxYear) {
      count += 1;
    }
  }
  return count;
}

/**
 * Reset persisted YTD totals for a closed tax year (payment-date attribution).
 * Refuses when payroll runs still exist for that payment year unless `force` is set.
 */
export async function runYtdReset(
  taxYear: number,
  options?: { force?: boolean }
): Promise<YtdResetResult> {
  const deps = await getAppDependencies();
  const payrollRunsInYear = await countPayrollRunsForPaymentYear(
    deps.db,
    taxYear
  );

  if (payrollRunsInYear > 0 && !options?.force) {
    throw new PayrollDomainError(
      PayrollErrorCode.YTD_RESET_BLOCKED,
      `Cannot reset YTD for payment year ${taxYear}: ${payrollRunsInYear} payroll run(s) still attributed to that year. Use force=true after archival.`,
      { taxYear, payrollRunsInYear }
    );
  }

  const deletedRows = await deps
    .db('ytd_totals')
    .where({ tax_year: taxYear })
    .del();

  return { taxYear, deletedRows, payrollRunsInYear };
}

export function ytdBucketYear(paymentDate: string): number {
  return paymentYear(paymentDate);
}
