import type { GarnishmentOrderType } from '../../models/GarnishmentOrder';

/** CCPA-style maximum percent of disposable earnings by garnishment type */
export const GARNISHMENT_MAX_PERCENT: Record<GarnishmentOrderType, string> = {
  child_support: '0.50',
  student_loan: '0.15',
  creditor: '0.25',
};

/** Lower sort value = withheld earlier (child support before creditor) */
export const GARNISHMENT_TYPE_RANK: Record<GarnishmentOrderType, number> = {
  child_support: 0,
  student_loan: 1,
  creditor: 2,
};

export function compareGarnishmentPriority(
  a: { type: GarnishmentOrderType; priority: number },
  b: { type: GarnishmentOrderType; priority: number }
): number {
  const rankDiff =
    GARNISHMENT_TYPE_RANK[a.type] - GARNISHMENT_TYPE_RANK[b.type];
  if (rankDiff !== 0) return rankDiff;
  return a.priority - b.priority;
}
