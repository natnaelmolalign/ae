/** @deprecated Import from `src/data/2024/fica` — kept for backward compatibility */
import { FICA_2024 } from './2024/fica';

export const SOCIAL_SECURITY_WAGE_BASE_2024 = FICA_2024.socialSecurityWageBase;
export const MEDICARE_ADDITIONAL_THRESHOLD_2024 =
  FICA_2024.medicareAdditionalThreshold;
export const FEDERAL_SUPPLEMENTAL_FLAT_RATE_2024 = '0.22';
export const SOCIAL_SECURITY_RATE = FICA_2024.socialSecurityRate;
export const MEDICARE_RATE = FICA_2024.medicareRate;
export const MEDICARE_ADDITIONAL_RATE = FICA_2024.medicareAdditionalRate;
export const PRETAX_401K_LIMIT_2024 = '23000';
