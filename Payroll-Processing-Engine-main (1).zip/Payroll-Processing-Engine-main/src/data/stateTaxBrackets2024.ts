/** @deprecated Import from `src/data/2024/state` — kept for backward compatibility */
import { STATES_2024 } from './2024/state';

export interface StateTaxConfig {
  flatRate?: string;
  noIncomeTax?: boolean;
}

export const STATE_TAX_2024: Record<string, StateTaxConfig> =
  Object.fromEntries(
    Object.entries(STATES_2024).map(([code, entry]) => [
      code,
      {
        noIncomeTax: entry.noIncomeTax,
        flatRate: entry.flatRate,
      },
    ])
  );
