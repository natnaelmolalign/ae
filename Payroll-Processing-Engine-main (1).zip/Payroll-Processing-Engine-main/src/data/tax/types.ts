import type { FilingStatus, PayFrequency } from '../../models/types';

export interface TaxBracket {
  upTo: string | null;
  rate: string;
}

export interface FederalTaxYearData {
  brackets: Record<FilingStatus, TaxBracket[]>;
  standardDeduction: Record<FilingStatus, string>;
  supplementalFlatRate: string;
  payPeriodsPerYear: Record<PayFrequency, number>;
}

export interface FicaTaxYearData {
  socialSecurityWageBase: string;
  socialSecurityRate: string;
  medicareRate: string;
  medicareAdditionalThreshold: string;
  medicareAdditionalRate: string;
}

export interface StateTaxYearEntry {
  noIncomeTax?: boolean;
  flatRate?: string;
  brackets?: TaxBracket[];
}

export interface LocalTaxEntry {
  municipalityCode: string;
  rate: string;
}

export interface TaxYearTables {
  taxYear: number;
  federal: FederalTaxYearData;
  fica: FicaTaxYearData;
  states: Record<string, StateTaxYearEntry>;
  local: Record<string, LocalTaxEntry[]>;
}
