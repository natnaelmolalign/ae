export interface JurisdictionRule {
  stateCode: string;
  weeklyOtThresholdHours: number;
  otMultiplier: string;
  doubleTimeMultiplier: string;
  holidayMultiplier: string;
  /** When true, holiday pay is excluded from FICA taxable base (state-specific; feature-gated) */
  holidayExemptFromFica: boolean;
  workWeekStartDay: 0 | 1 | 2 | 3 | 4 | 5 | 6;
}

/** 0 = Sunday, 1 = Monday (default work week) */
export const JURISDICTIONS: Record<string, JurisdictionRule> = {
  DEFAULT: {
    stateCode: 'DEFAULT',
    weeklyOtThresholdHours: 40,
    otMultiplier: '1.5',
    doubleTimeMultiplier: '2.0',
    holidayMultiplier: '1.5',
    holidayExemptFromFica: false,
    workWeekStartDay: 1,
  },
  CA: {
    stateCode: 'CA',
    weeklyOtThresholdHours: 40,
    otMultiplier: '1.5',
    doubleTimeMultiplier: '2.0',
    holidayMultiplier: '1.5',
    holidayExemptFromFica: false,
    workWeekStartDay: 1,
  },
  TX: {
    stateCode: 'TX',
    weeklyOtThresholdHours: 40,
    otMultiplier: '1.5',
    doubleTimeMultiplier: '2.0',
    holidayMultiplier: '1.0',
    holidayExemptFromFica: false,
    workWeekStartDay: 1,
  },
};

export function getJurisdiction(stateCode: string): JurisdictionRule {
  return JURISDICTIONS[stateCode] ?? JURISDICTIONS.DEFAULT;
}
