/** @deprecated Import from `src/data/2024/federal` — kept for backward compatibility */
export { FEDERAL_BRACKETS_2024 } from './2024/federal/brackets';
export { PAY_PERIODS_PER_YEAR } from './2024/federal';
