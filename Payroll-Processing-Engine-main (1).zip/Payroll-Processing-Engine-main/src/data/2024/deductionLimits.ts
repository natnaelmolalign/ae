import type { SupportedTaxYear } from '../../config/taxYear';

export interface DeductionLimitsYear {
  taxYear: SupportedTaxYear;
  /** IRS §402(g) elective deferral limit */
  deferral402g: string;
  /** Age 50+ catch-up (added to §402(g) ceiling) */
  catchUp402g: string;
  hsaIndividual: string;
  hsaFamily: string;
  fsaHealth: string;
}

export const DEDUCTION_LIMITS_2024: DeductionLimitsYear = {
  taxYear: 2024,
  deferral402g: '23000.00',
  catchUp402g: '7500.00',
  hsaIndividual: '4150.00',
  hsaFamily: '8300.00',
  fsaHealth: '3200.00',
};

const REGISTRY: Record<number, DeductionLimitsYear> = {
  2024: DEDUCTION_LIMITS_2024,
  2025: { ...DEDUCTION_LIMITS_2024, taxYear: 2025 },
  2026: { ...DEDUCTION_LIMITS_2024, taxYear: 2026 },
};

export function getDeductionLimits(taxYear: number): DeductionLimitsYear {
  const limits = REGISTRY[taxYear];
  if (!limits) {
    throw new Error(`No deduction limits for tax year ${taxYear}`);
  }
  return limits;
}
