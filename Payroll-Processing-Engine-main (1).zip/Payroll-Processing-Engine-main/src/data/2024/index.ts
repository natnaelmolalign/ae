import type { TaxYearTables } from '../tax/types';
import { FEDERAL_2024 } from './federal';
import { FICA_2024 } from './fica';
import { LOCAL_2024 } from './local';
import { STATES_2024 } from './state';

export const TAX_YEAR_2024: TaxYearTables = {
  taxYear: 2024,
  federal: FEDERAL_2024,
  fica: FICA_2024,
  states: STATES_2024,
  local: LOCAL_2024,
};
