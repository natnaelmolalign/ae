/** IRS Publication 15-T supplemental wage flat rate (2024) */
export const SUPPLEMENTAL_FLAT_RATE_2024 = '0.22';
