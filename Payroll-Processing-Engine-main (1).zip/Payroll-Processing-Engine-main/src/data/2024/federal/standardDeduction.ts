import type { FilingStatus } from '../../../models/types';

/** 2024 standard deduction amounts (IRS) */
export const STANDARD_DEDUCTION_2024: Record<FilingStatus, string> = {
  single: '14600.00',
  married_filing_jointly: '29200.00',
  married_filing_separately: '14600.00',
  head_of_household: '21900.00',
};
