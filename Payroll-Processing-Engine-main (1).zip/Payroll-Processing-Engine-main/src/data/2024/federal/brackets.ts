import type { FilingStatus } from '../../../models/types';
import type { TaxBracket } from '../../tax/types';

export const FEDERAL_BRACKETS_2024: Record<FilingStatus, TaxBracket[]> = {
  single: [
    { upTo: '11600', rate: '0.10' },
    { upTo: '47150', rate: '0.12' },
    { upTo: '100525', rate: '0.22' },
    { upTo: '191950', rate: '0.24' },
    { upTo: '243725', rate: '0.32' },
    { upTo: '609350', rate: '0.35' },
    { upTo: null, rate: '0.37' },
  ],
  married_filing_jointly: [
    { upTo: '23200', rate: '0.10' },
    { upTo: '94300', rate: '0.12' },
    { upTo: '201050', rate: '0.22' },
    { upTo: '383900', rate: '0.24' },
    { upTo: '487450', rate: '0.32' },
    { upTo: '731200', rate: '0.35' },
    { upTo: null, rate: '0.37' },
  ],
  married_filing_separately: [
    { upTo: '11600', rate: '0.10' },
    { upTo: '47150', rate: '0.12' },
    { upTo: '100525', rate: '0.22' },
    { upTo: '191950', rate: '0.24' },
    { upTo: '243725', rate: '0.32' },
    { upTo: '365600', rate: '0.35' },
    { upTo: null, rate: '0.37' },
  ],
  head_of_household: [
    { upTo: '16550', rate: '0.10' },
    { upTo: '63100', rate: '0.12' },
    { upTo: '100500', rate: '0.22' },
    { upTo: '191950', rate: '0.24' },
    { upTo: '243700', rate: '0.32' },
    { upTo: '609350', rate: '0.35' },
    { upTo: null, rate: '0.37' },
  ],
};
