import type { PayFrequency } from '../../../models/types';
import type { FederalTaxYearData } from '../../tax/types';
import { FEDERAL_BRACKETS_2024 } from './brackets';
import { STANDARD_DEDUCTION_2024 } from './standardDeduction';
import { SUPPLEMENTAL_FLAT_RATE_2024 } from './supplemental';

export const PAY_PERIODS_PER_YEAR: Record<PayFrequency, number> = {
  weekly: 52,
  biweekly: 26,
  semimonthly: 24,
  monthly: 12,
};

export const FEDERAL_2024: FederalTaxYearData = {
  brackets: FEDERAL_BRACKETS_2024,
  standardDeduction: STANDARD_DEDUCTION_2024,
  supplementalFlatRate: SUPPLEMENTAL_FLAT_RATE_2024,
  payPeriodsPerYear: PAY_PERIODS_PER_YEAR,
};
