import type { StateTaxYearEntry } from '../../tax/types';

export const STATES_2024: Record<string, StateTaxYearEntry> = {
  TX: { noIncomeTax: true },
  FL: { noIncomeTax: true },
  WA: { noIncomeTax: true },
  NV: { noIncomeTax: true },
  CA: { flatRate: '0.05' },
  NY: {
    brackets: [
      { upTo: '8500', rate: '0.04' },
      { upTo: '11700', rate: '0.045' },
      { upTo: '13900', rate: '0.0525' },
      { upTo: '21400', rate: '0.055' },
      { upTo: '80650', rate: '0.06' },
      { upTo: '215400', rate: '0.0685' },
      { upTo: '1077550', rate: '0.0965' },
      { upTo: null, rate: '0.103' },
    ],
  },
  IL: { flatRate: '0.0495' },
  CT: { flatRate: '0.05' },
};
