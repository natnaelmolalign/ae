export interface ReciprocityAgreement {
  residentState: string;
  workState: string;
  /** When true, resident state does not tax wages earned in workState (work state only). */
  withholdWorkStateOnly: boolean;
}

/** Simplified reciprocity table for 2024 — expand per jurisdiction guidance. */
export const RECIPROCITY_2024: ReciprocityAgreement[] = [
  { residentState: 'NY', workState: 'CT', withholdWorkStateOnly: true },
  { residentState: 'CT', workState: 'NY', withholdWorkStateOnly: true },
];
