import type { LocalTaxEntry } from '../../tax/types';

/** Sample municipal taxes (Phase 4 stub; gated by FEATURE_LOCAL_TAX) */
export const LOCAL_2024: Record<string, LocalTaxEntry[]> = {
  OH: [{ municipalityCode: 'COL', rate: '0.025' }],
  PA: [{ municipalityCode: 'PHL', rate: '0.0376' }],
};
