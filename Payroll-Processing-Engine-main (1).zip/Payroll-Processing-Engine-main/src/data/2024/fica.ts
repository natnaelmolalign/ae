import type { FicaTaxYearData } from '../tax/types';

export const FICA_2024: FicaTaxYearData = {
  socialSecurityWageBase: '168600',
  socialSecurityRate: '0.062',
  medicareRate: '0.0145',
  medicareAdditionalThreshold: '200000',
  medicareAdditionalRate: '0.009',
};
