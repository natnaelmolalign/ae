/** Supported webhook event types (Advanced Phase 6). */
export const WEBHOOK_EVENT_TYPES = [
  'payroll.run.completed',
  'pay_stub.created',
  'batch.completed',
  'payment.batch.submitted',
] as const;

export type WebhookEventType = (typeof WEBHOOK_EVENT_TYPES)[number];

export const WEBHOOK_MAX_ATTEMPTS = 5;
export const WEBHOOK_BACKOFF_BASE_MS = 1000;
export const WEBHOOK_SUBSCRIPTION_FAILURE_THRESHOLD = 10;
export const WEBHOOK_DELIVERY_TIMEOUT_MS = 10_000;
