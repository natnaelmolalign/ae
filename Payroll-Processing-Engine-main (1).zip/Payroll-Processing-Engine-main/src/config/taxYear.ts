import { features } from './features';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';

/** Tax years always available in production */
export const CORE_TAX_YEARS = [2024] as const;

/** Forward-year packs (stubs until IRS final); gated by FEATURE_TAX_YEAR_2025 */
export const OPTIONAL_TAX_YEARS = [2025, 2026] as const;

export type CoreTaxYear = (typeof CORE_TAX_YEARS)[number];
export type OptionalTaxYear = (typeof OPTIONAL_TAX_YEARS)[number];
export type KnownTaxYear = CoreTaxYear | OptionalTaxYear;
export type SupportedTaxYear = KnownTaxYear;

/** @deprecated Use enabledTaxYears() — kept for tests referencing a static list */
export const SUPPORTED_TAX_YEARS = CORE_TAX_YEARS;

export function enabledTaxYears(): SupportedTaxYear[] {
  const years: SupportedTaxYear[] = [...CORE_TAX_YEARS];
  if (features.taxYear2025Enabled) {
    for (const y of OPTIONAL_TAX_YEARS) {
      if (!years.includes(y)) {
        years.push(y);
      }
    }
  }
  return years;
}

export function taxYearFromPaymentDate(paymentDate: string): SupportedTaxYear {
  const year = parseInt(paymentDate.slice(0, 4), 10);
  return assertSupportedTaxYear(year);
}

export function assertSupportedTaxYear(year: number): SupportedTaxYear {
  const enabled = enabledTaxYears();
  if (!enabled.includes(year as SupportedTaxYear)) {
    throw new PayrollDomainError(
      PayrollErrorCode.TAX_YEAR_UNSUPPORTED,
      `Tax year ${year} is not supported`,
      { year, supported: enabled }
    );
  }
  return year as SupportedTaxYear;
}

export const DEFAULT_TAX_YEAR: SupportedTaxYear = 2024;
