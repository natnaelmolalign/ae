/** Immutable audit retention (days). Purge job removes rows older than this. */
export const auditRetentionDays = Number(
  process.env.AUDIT_RETENTION_DAYS ?? '2555'
);
