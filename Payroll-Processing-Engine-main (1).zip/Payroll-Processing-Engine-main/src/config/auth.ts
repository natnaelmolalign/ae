export type PayrollRole =
  | 'payroll_admin'
  | 'payroll_clerk'
  | 'read_only'
  | 'employee_self';

export interface AuthContext {
  actor: string;
  roles: PayrollRole[];
  companyId: string;
  /** Set when role is employee_self — scopes ESS to this employee only */
  employeeId?: string;
}

const VALID_ROLES: PayrollRole[] = [
  'payroll_admin',
  'payroll_clerk',
  'read_only',
  'employee_self',
];

export function isPayrollRole(value: string): value is PayrollRole {
  return (VALID_ROLES as string[]).includes(value);
}

/** API_KEYS format: `key:role,key2:role2` (comma-separated pairs) */
export function parseApiKeys(
  raw: string | undefined
): Map<string, PayrollRole[]> {
  const map = new Map<string, PayrollRole[]>();
  if (!raw?.trim()) return map;
  for (const pair of raw.split(',')) {
    const trimmed = pair.trim();
    if (!trimmed) continue;
    const colon = trimmed.indexOf(':');
    if (colon <= 0) continue;
    const key = trimmed.slice(0, colon).trim();
    const rolePart = trimmed.slice(colon + 1).trim();
    const roles = rolePart
      .split('|')
      .map((r) => r.trim())
      .filter(isPayrollRole);
    if (key && roles.length > 0) {
      map.set(key, roles);
    }
  }
  return map;
}

export function authEnforced(): boolean {
  if (process.env.NODE_ENV === 'production') return true;
  if (process.env.STRICT_AUTH === '1') return true;
  return parseApiKeys(process.env.API_KEYS).size > 0;
}

export function defaultCompanyId(): string {
  return process.env.DEFAULT_COMPANY_ID?.trim() || 'default';
}
