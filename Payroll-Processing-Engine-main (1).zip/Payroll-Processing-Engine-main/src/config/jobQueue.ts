import type { Knex } from 'knex';
import { InMemoryJobQueue } from '../queue/InMemoryJobQueue';
import { KnexJobQueue } from '../queue/KnexJobQueue';
import { SqsJobQueue } from '../queue/SqsJobQueue';
import type { JobQueue } from '../queue/JobQueue';

export type JobQueueBackend = 'memory' | 'knex' | 'sqs';

export function resolveJobQueueBackend(): JobQueueBackend {
  const raw = process.env.JOB_QUEUE_BACKEND?.trim().toLowerCase();
  if (raw === 'memory' || raw === 'knex' || raw === 'sqs') return raw;
  return process.env.NODE_ENV === 'test' ? 'memory' : 'knex';
}

export function createJobQueue(db?: Knex): JobQueue {
  const backend = resolveJobQueueBackend();
  if (backend === 'memory') return new InMemoryJobQueue();
  if (backend === 'sqs') return new SqsJobQueue();
  if (!db) {
    throw new Error('KnexJobQueue requires a database connection');
  }
  return new KnexJobQueue(db);
}
