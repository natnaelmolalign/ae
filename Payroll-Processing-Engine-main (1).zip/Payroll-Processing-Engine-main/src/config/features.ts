/**
 * Feature flags for incremental rollout (Phase 1 stub; expanded in later phases).
 */
export const features = {
  /** When false, local/municipal tax is skipped */
  localTaxEnabled: process.env.FEATURE_LOCAL_TAX === 'true',
  /** Hourly/OT engine (Phase 3); set FEATURE_HOURLY_EARNINGS=false to disable */
  hourlyEarningsEnabled: process.env.FEATURE_HOURLY_EARNINGS !== 'false',
  /** Holiday pay excluded from FICA when true (jurisdiction-specific) */
  holidayFicaExemptEnabled: process.env.FEATURE_HOLIDAY_FICA_EXEMPT === 'true',
  /** Persist to PostgreSQL (Phase 2) */
  persistenceEnabled:
    process.env.FEATURE_PERSISTENCE === 'true' ||
    process.env.NODE_ENV !== 'test',
  /** 1099 contractor pay path (Advanced Phase 1) */
  contractorPayrollEnabled: process.env.FEATURE_CONTRACTOR_PAY !== 'false',
  /** Multi-state wage allocation (Advanced Phase 2) */
  multiStateTaxEnabled: process.env.FEATURE_MULTI_STATE_TAX !== 'false',
  /** Tips, tip credit, allocated tips (Advanced Phase 3) */
  tipsAndTipCreditEnabled: process.env.FEATURE_TIPS !== 'false',
  /** RSU / NQSO equity pay and withholding elections (Advanced Phase 4) */
  equityCompensationEnabled: process.env.FEATURE_EQUITY !== 'false',
  /** COBRA premiums and arrears schedules (Advanced Phase 5) */
  cobraArrearsEnabled: process.env.FEATURE_COBRA_ARREARS !== 'false',
  /** Webhook outbox and signed delivery (Advanced Phase 6) */
  webhooksEnabled: process.env.FEATURE_WEBHOOKS !== 'false',
  /** Enable 2025/2026 tax table packs (Advanced Phase 7; stubs until IRS final) */
  taxYear2025Enabled: process.env.FEATURE_TAX_YEAR_2025 === 'true',
  /** Labor cost allocations, GL segments, labor-cost report (Advanced Phase 8) */
  costAccountingEnabled: process.env.FEATURE_COST_ACCOUNTING !== 'false',
  /** Prometheus /metrics exporter (Advanced Phase 9) */
  prometheusMetricsEnabled: process.env.FEATURE_PROMETHEUS_METRICS !== 'false',
  /** Route report queries to read replica when DB_READ_REPLICA_URL is set (stub) */
  readReplicaEnabled: process.env.FEATURE_READ_REPLICA === 'true',
  /** W-2 / 1099-NEC / 941 compliance previews and TIN vault (Advanced Phase 10) */
  complianceExportsEnabled: process.env.FEATURE_COMPLIANCE_EXPORTS !== 'false',
  /** Declarative pay policies evaluated before payroll run (Enterprise Phase 1) */
  payPolicyEngineEnabled: process.env.FEATURE_PAY_POLICIES !== 'false',
  /** PTO/sick accruals and leave balance tracking (Enterprise Phase 2) */
  leaveAccrualsEnabled: process.env.FEATURE_LEAVE_ACCRUALS !== 'false',
  /** Shift scheduling and manager time approval (Enterprise Phase 3) */
  workforceSchedulingEnabled:
    process.env.FEATURE_WORKFORCE_SCHEDULING !== 'false',
  /** California meal break premium earnings (Enterprise Phase 3) */
  caMealPenaltyEnabled: process.env.FEATURE_CA_MEAL_PENALTY === 'true',
  /** Open enrollment windows, life events, eligibility rules (Enterprise Phase 4) */
  benefitsLifecycleEnabled: process.env.FEATURE_BENEFITS_LIFECYCLE !== 'false',
  /** Net pay splits, NACHA files, payment batches (Enterprise Phase 5) */
  disbursementsEnabled: process.env.FEATURE_DISBURSEMENTS !== 'false',
  /** ERP GL export connectors (Enterprise Phase 6) */
  erpConnectorsEnabled: process.env.FEATURE_ERP_CONNECTORS !== 'false',
  /** Employee self-service pay history and W-4 workflow (Enterprise Phase 7) */
  employeeEssEnabled: process.env.FEATURE_EMPLOYEE_ESS !== 'false',
  /** Durable job queue for batch payroll and webhooks (Enterprise Phase 8) */
  jobQueueEnabled: process.env.FEATURE_JOB_QUEUE !== 'false',
  /** Payroll holds, anomaly detection, dual approval (Enterprise Phase 9) */
  payrollControlsEnabled: process.env.FEATURE_PAYROLL_CONTROLS !== 'false',
  /** E-file XML exports and deduction plugin SDK (Enterprise Phase 10) */
  filingPlatformEnabled: process.env.FEATURE_FILING_PLATFORM !== 'false',
} as const;

export type FeatureFlags = typeof features;
