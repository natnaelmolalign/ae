/** Federal FLSA defaults (2024); override per run via TipCreditInput. */
export const FEDERAL_MINIMUM_WAGE = '7.25';
export const FEDERAL_TIPPED_CASH_WAGE = '2.13';
