import fs from 'fs';
import knex, { type Knex } from 'knex';
import path from 'path';

let db: Knex | null = null;

function migrationExtension(migrationsDir: string): string {
  const hasJs = fs.existsSync(
    path.join(migrationsDir, '20240101000001_initial_schema.js')
  );
  return hasJs ? 'js' : 'ts';
}

function buildConfig(): Knex.Config {
  const migrationsDir = path.join(__dirname, '..', 'migrations');
  const env = process.env.NODE_ENV || 'development';
  const migrations = {
    directory: migrationsDir,
    extension: migrationExtension(migrationsDir),
  };

  if (env === 'test') {
    return {
      client: 'better-sqlite3',
      connection: { filename: ':memory:' },
      useNullAsDefault: true,
      migrations,
    };
  }

  return {
    client: 'pg',
    connection: {
      host: process.env.DB_HOST || 'localhost',
      port: Number(process.env.DB_PORT || 5432),
      user: process.env.DB_USER || 'payroll',
      password: process.env.DB_PASSWORD || 'payroll',
      database: process.env.DB_NAME || 'payroll',
    },
    migrations,
    pool: { min: 1, max: 10 },
  };
}

export function getDb(): Knex {
  if (!db) {
    db = knex(buildConfig());
  }
  return db;
}

export async function runMigrations(connection: Knex = getDb()): Promise<void> {
  await connection.migrate.latest();
}

export async function rollbackMigrations(
  connection: Knex = getDb()
): Promise<void> {
  await connection.migrate.rollback(undefined, true);
}

export async function closeDb(): Promise<void> {
  if (db) {
    await db.destroy();
    db = null;
  }
}

export async function truncateAllTables(
  connection: Knex = getDb()
): Promise<void> {
  await connection('time_exceptions').del();
  await connection('time_entries').del();
  await connection('shift_assignments').del();
  await connection('shifts').del();
  await connection('garnishment_remittances').del();
  await connection('earnings_lines').del();
  await connection('payroll_run_allocations').del();
  await connection('export_batches').del();
  await connection('gl_account_mappings').del();
  await connection('integration_connections').del();
  await connection('ach_files').del();
  await connection('payment_batch_items').del();
  await connection('payment_batches').del();
  await connection('payroll_runs').del();
  await connection('payroll_run_failures').del();
  await connection('payroll_batches').del();
  await connection('employee_payroll_readiness').del();
  await connection('retro_adjustments').del();
  await connection('garnishment_orders').del();
  await connection('pay_stubs').del();
  await connection('ytd_totals').del();
  await connection('deduction_enrollments').del();
  await connection('life_events').del();
  await connection('w4_change_requests').del();
  await connection('anomaly_flags').del();
  await connection('approval_requests').del();
  await connection('payroll_holds').del();
  await connection('queue_dead_letters').del();
  await connection('queue_jobs').del();
  await connection('eligibility_rules').del();
  await connection('disbursement_instructions').del();
  await connection('enrollment_windows').del();
  await connection('deduction_schedules').del();
  await connection('webhook_deliveries').del();
  await connection('webhook_outbox').del();
  await connection('webhook_subscriptions').del();
  await connection('audit_events').del();
  await connection('jobs').del();
  await connection('departments').del();
  await connection('pay_periods').del();
  await connection('pay_policies').del();
  await connection('leave_transactions').del();
  await connection('leave_balances').del();
  await connection('leave_policies').del();
  await connection('employees').del();
}
