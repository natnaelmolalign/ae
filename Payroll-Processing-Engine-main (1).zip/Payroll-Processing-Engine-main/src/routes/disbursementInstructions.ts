import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { features } from '../config/features';

const createSchema = z.object({
  employeeId: z.string().uuid(),
  splitType: z.enum(['percent', 'fixed', 'remainder']),
  percent: z.string().nullable().optional(),
  fixedAmount: z.string().nullable().optional(),
  priority: z.number().int().optional(),
  routingNumber: z.string().min(9).max(9),
  accountNumber: z.string().min(4).max(17),
  accountType: z.enum(['checking', 'savings']).optional(),
  isActive: z.boolean().optional(),
});

const updateSchema = createSchema.omit({ employeeId: true }).partial();

export function createDisbursementInstructionsRouter(
  deps: AppDependencies
): Router {
  const router = Router();

  router.use((_req, res, next) => {
    if (!features.disbursementsEnabled) {
      res.status(503).json({
        error: 'Disbursements are disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.get(
        req.body.employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.body.employeeId);
      }
      const instruction = await deps.disbursementInstructionService.create({
        companyId: req.auth.companyId,
        ...req.body,
      });
      res.status(201).json(instruction);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const employeeId = req.query.employeeId as string | undefined;
      if (!employeeId) {
        throw PayrollDomainError.notFound('Employee', 'missing employeeId');
      }
      const list = await deps.disbursementInstructionService.listByEmployee(
        employeeId,
        req.auth.companyId
      );
      res.json({ instructions: list });
    })
  );

  router.patch(
    '/:id',
    validateBody(updateSchema),
    asyncHandler(async (req, res) => {
      const instruction = await deps.disbursementInstructionService.update(
        req.params.id,
        req.auth.companyId,
        req.body
      );
      res.json(instruction);
    })
  );

  router.delete(
    '/:id',
    asyncHandler(async (req, res) => {
      await deps.disbursementInstructionService.remove(
        req.params.id,
        req.auth.companyId
      );
      res.status(204).send();
    })
  );

  return router;
}
