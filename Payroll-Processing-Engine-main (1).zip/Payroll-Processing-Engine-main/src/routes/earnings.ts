import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';

const previewSchema = z.object({
  employeeId: z.string().uuid(),
  payPeriodId: z.string(),
  year: z.number(),
  frequency: z.enum(['weekly', 'biweekly', 'semimonthly', 'monthly']),
  earnings: z
    .array(
      z.object({
        type: z.string(),
        amount: z.string(),
        hours: z.number().optional(),
      })
    )
    .optional(),
  useTimeEntries: z.boolean().optional(),
  hourlyRate: z.string().optional(),
  imputedIncome: z
    .array(
      z.object({
        type: z.literal('group_life'),
        coverageAmount: z.string(),
        employerPaidPremium: z.string(),
      })
    )
    .optional(),
  deductions: z
    .array(z.object({ type: z.string(), amountPerPeriod: z.string() }))
    .optional(),
  garnishments: z
    .array(
      z.object({
        type: z.string(),
        fixedAmount: z.string(),
        priority: z.number(),
      })
    )
    .optional(),
});

export function createEarningsRouter(deps: AppDependencies): Router {
  const router = Router();

  router.post(
    '/preview',
    validateBody(previewSchema),
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.get(
        req.body.employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.body.employeeId);
      }

      const periods = await deps.payPeriodRepository.findByYearAndFrequency(
        req.body.year,
        req.body.frequency,
        req.auth.companyId
      );
      const payPeriod = periods.find((p) => p.id === req.body.payPeriodId);
      if (!payPeriod) {
        throw PayrollDomainError.notFound('Pay period', req.body.payPeriodId);
      }

      const result = await deps.earningsPreviewService.preview(
        employee,
        payPeriod,
        req.body
      );

      res.json(result);
    })
  );

  return router;
}
