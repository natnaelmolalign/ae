import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { toAuditSnapshot } from '../utils/auditContext';

const createSchema = z.object({
  code: z.string().min(1).max(32),
  name: z.string().min(1).max(128),
  locationCode: z.string().max(32).nullable().optional(),
});

export function createDepartmentsRouter(deps: AppDependencies): Router {
  const router = Router();

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const dept = await deps.departmentService.create(
        req.body,
        req.auth.companyId
      );
      await deps.auditService.recordCreate(
        req.actor,
        'department',
        dept.id,
        toAuditSnapshot(dept)
      );
      res.status(201).json(dept);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const list = await deps.departmentService.list(req.auth.companyId);
      res.json({ departments: list });
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const dept = await deps.departmentService.get(
        req.params.id,
        req.auth.companyId
      );
      if (!dept) {
        throw PayrollDomainError.notFound('Department', req.params.id);
      }
      res.json(dept);
    })
  );

  return router;
}
