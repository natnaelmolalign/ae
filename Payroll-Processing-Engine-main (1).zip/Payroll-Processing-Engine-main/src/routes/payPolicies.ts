import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { payPolicyRuleSchema, payPolicyRulesSchema } from '../models/PayPolicy';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { toAuditSnapshot } from '../utils/auditContext';
import { features } from '../config/features';

const createSchema = z.object({
  code: z.string().min(1).max(32),
  name: z.string().min(1).max(128),
  scope: z.enum(['company', 'employee']),
  employeeId: z.string().uuid().nullable().optional(),
  priority: z.number().int().min(0).max(1000).optional(),
  rules: payPolicyRulesSchema.shape.rules,
  effectiveFrom: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  effectiveTo: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .nullable()
    .optional(),
  isActive: z.boolean().optional(),
});

const updateSchema = createSchema
  .partial()
  .omit({ code: true, scope: true, employeeId: true });

const validateRunSchema = z.object({
  employeeId: z.string().uuid(),
  payPeriodId: z.string().min(1),
  earnings: z
    .array(
      z.object({
        type: z.string(),
        amount: z.string(),
        description: z.string().optional(),
      })
    )
    .min(1),
  deductions: z.array(z.unknown()).optional(),
  garnishments: z.array(z.unknown()).optional(),
});

export function createPayPoliciesRouter(deps: AppDependencies): Router {
  const router = Router();

  router.use((req, res, next) => {
    if (!features.payPolicyEngineEnabled) {
      res.status(503).json({
        error: 'Pay policy engine is disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const body = req.body as z.infer<typeof createSchema>;
      payPolicyRulesSchema.parse({ rules: body.rules });
      const policy = await deps.payPolicyService.create({
        companyId: req.auth.companyId,
        code: body.code,
        name: body.name,
        scope: body.scope,
        employeeId: body.employeeId ?? null,
        priority: body.priority ?? 0,
        rules: body.rules.map((r) => payPolicyRuleSchema.parse(r)),
        effectiveFrom: body.effectiveFrom,
        effectiveTo: body.effectiveTo ?? null,
        isActive: body.isActive ?? true,
      });
      await deps.auditService.recordCreate(
        req.actor,
        'pay_policy',
        policy.id,
        toAuditSnapshot(policy)
      );
      res.status(201).json(policy);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const policies = await deps.payPolicyService.list(req.auth.companyId);
      res.json({ policies });
    })
  );

  router.post(
    '/validate',
    validateBody(validateRunSchema),
    asyncHandler(async (req, res) => {
      const body = req.body as z.infer<typeof validateRunSchema>;
      const employee = await deps.employeeRepository.findById(body.employeeId);
      if (!employee || employee.companyId !== req.auth.companyId) {
        throw PayrollDomainError.notFound('Employee', body.employeeId);
      }
      const payPeriod = await deps.payPeriodRepository.findById(
        body.payPeriodId
      );
      if (!payPeriod) {
        throw PayrollDomainError.notFound('PayPeriod', body.payPeriodId);
      }
      const violations = await deps.payPolicyService.evaluateRun(
        employee,
        payPeriod,
        {
          employeeId: body.employeeId,
          payPeriodId: body.payPeriodId,
          earnings: body.earnings as import('../models/types').EarningsLine[],
          deductions: [],
          garnishments: [],
        }
      );
      res.json({
        allowed: violations.length === 0,
        violations,
      });
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const policy = await deps.payPolicyService.get(
        req.params.id,
        req.auth.companyId
      );
      if (!policy) {
        throw PayrollDomainError.notFound('PayPolicy', req.params.id);
      }
      res.json(policy);
    })
  );

  router.patch(
    '/:id',
    validateBody(updateSchema),
    asyncHandler(async (req, res) => {
      const before = await deps.payPolicyService.get(
        req.params.id,
        req.auth.companyId
      );
      if (!before) {
        throw PayrollDomainError.notFound('PayPolicy', req.params.id);
      }
      const body = req.body as z.infer<typeof updateSchema>;
      if (body.rules) {
        payPolicyRulesSchema.parse({ rules: body.rules });
      }
      const policy = await deps.payPolicyService.update(
        req.params.id,
        req.auth.companyId,
        body
      );
      await deps.auditService.recordUpdate(
        req.actor,
        'pay_policy',
        policy.id,
        toAuditSnapshot(before),
        toAuditSnapshot(policy)
      );
      res.json(policy);
    })
  );

  return router;
}
