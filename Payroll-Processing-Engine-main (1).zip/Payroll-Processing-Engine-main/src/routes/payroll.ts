import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { taxYearFromPaymentDate } from '../config/taxYear';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { toAuditSnapshot } from '../utils/auditContext';
import { employeeForTenant, payPeriodForTenant } from '../utils/tenant';
import { features } from '../config/features';

const runSchema = z.object({
  employeeId: z.string().uuid(),
  payPeriodId: z.string(),
  year: z.number(),
  frequency: z.enum(['weekly', 'biweekly', 'semimonthly', 'monthly']),
  earnings: z.array(
    z.object({
      type: z.string(),
      amount: z.string(),
      hours: z.number().optional(),
    })
  ),
  deductions: z
    .array(
      z.object({
        type: z.string(),
        amountPerPeriod: z.string(),
        percentOfGross: z.string().optional(),
      })
    )
    .default([]),
  garnishments: z
    .array(
      z.object({
        type: z.enum(['child_support', 'creditor', 'student_loan']),
        fixedAmount: z.string(),
        percentOfDisposable: z.string().optional(),
        priority: z.number(),
      })
    )
    .default([]),
  useActiveGarnishmentOrders: z.boolean().optional(),
  employerMatch401kPercent: z.number().min(0).max(1).optional(),
  safeHarborMatch: z.boolean().optional(),
  stateAllocations: z
    .array(
      z.object({
        stateCode: z.string().length(2),
        percent: z.string(),
      })
    )
    .optional(),
  tipCredit: z
    .object({
      hours: z.number().positive(),
      directCashWages: z.string(),
      minimumWage: z.string().optional(),
      tippedCashWageRate: z.string().optional(),
    })
    .optional(),
  useActiveDeductionSchedules: z.boolean().optional(),
  costAllocations: z
    .array(
      z.object({
        departmentId: z.string().uuid(),
        jobId: z.string().uuid().optional(),
        percent: z.string(),
        hours: z.string().optional(),
      })
    )
    .optional(),
  useTimeEntries: z.boolean().optional(),
  hourlyRate: z.string().optional(),
});

export function createPayrollRouter(deps: AppDependencies): Router {
  const router = Router();

  router.post(
    '/run',
    validateBody(runSchema),
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.get(
        req.body.employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.body.employeeId);
      }

      let stateAllocations = req.body.stateAllocations;
      if (!stateAllocations?.length) {
        const defaults =
          await deps.employeeWorkLocationService.defaultAllocations(
            employee.id
          );
        if (defaults.length > 0) {
          stateAllocations = defaults;
        }
      }

      const periods = await deps.payPeriodRepository.findByYearAndFrequency(
        req.body.year,
        req.body.frequency,
        req.auth.companyId
      );
      const payPeriod = payPeriodForTenant(
        periods.find((p) => p.id === req.body.payPeriodId) ?? null,
        req.auth.companyId
      );
      if (!payPeriod) {
        throw PayrollDomainError.notFound('Pay period', req.body.payPeriodId);
      }

      taxYearFromPaymentDate(payPeriod.paymentDate);

      const idempotencyKey =
        req.header('idempotency-key') ??
        req.header('x-idempotency-key') ??
        null;

      req.log.info('payroll.run.start', {
        employeeId: employee.id,
        payPeriodId: payPeriod.id,
        phase: 'phase-2',
        idempotencyKey,
      });

      let earnings = req.body.earnings;
      if (req.body.useTimeEntries) {
        const resolved = await deps.earningsPreviewService.resolveEarningsLines(
          employee,
          payPeriod,
          req.body
        );
        earnings = resolved;
      }

      const result = await deps.payrollRunService.run(
        employee,
        payPeriod,
        {
          employeeId: req.body.employeeId,
          payPeriodId: req.body.payPeriodId,
          earnings,
          deductions: req.body.deductions,
          garnishments: req.body.garnishments,
          useActiveGarnishmentOrders: req.body.useActiveGarnishmentOrders,
          employerMatch401kPercent: req.body.employerMatch401kPercent,
          safeHarborMatch: req.body.safeHarborMatch,
          stateAllocations,
          tipCredit: req.body.tipCredit,
          useActiveDeductionSchedules: req.body.useActiveDeductionSchedules,
          costAllocations: req.body.costAllocations,
          useTimeEntries: req.body.useTimeEntries,
          hourlyRate: req.body.hourlyRate,
        },
        { idempotencyKey, useTimeEntries: req.body.useTimeEntries }
      );

      req.log.info('payroll.run.complete', {
        employeeId: employee.id,
        payPeriodId: payPeriod.id,
        netPay: result.payStub.netPay,
      });

      const priorAudit = await deps.auditService.listForEntity(
        'pay_stub',
        result.payStub.id
      );
      if (priorAudit.length === 0) {
        await deps.auditService.recordCreate(
          req.actor,
          'pay_stub',
          result.payStub.id,
          toAuditSnapshot({
            employeeId: employee.id,
            payPeriodId: payPeriod.id,
            netPay: result.payStub.netPay,
            grossPay: result.payStub.grossPay,
          })
        );
      }

      res.json(result);
    })
  );

  const batchSchema = z.object({
    payPeriodId: z.string(),
    year: z.number(),
    frequency: z.enum(['weekly', 'biweekly', 'semimonthly', 'monthly']),
    parallelLimit: z.number().int().min(1).max(32).optional(),
    employeeIds: z.array(z.string().uuid()).optional(),
    useQueue: z.boolean().optional(),
  });

  const readinessSchema = z.object({
    payPeriodId: z.string(),
    employeeIds: z.array(z.string().uuid()),
  });

  router.post(
    '/readiness',
    validateBody(readinessSchema),
    asyncHandler(async (req, res) => {
      for (const employeeId of req.body.employeeIds) {
        await deps.employeePayrollReadinessRepository.upsertReady(
          employeeId,
          req.body.payPeriodId
        );
      }
      res.status(201).json({ marked: req.body.employeeIds.length });
    })
  );

  router.post(
    '/batch',
    validateBody(batchSchema),
    asyncHandler(async (req, res) => {
      const periods = await deps.payPeriodRepository.findByYearAndFrequency(
        req.body.year,
        req.body.frequency,
        req.auth.companyId
      );
      const payPeriod = payPeriodForTenant(
        periods.find((p) => p.id === req.body.payPeriodId) ?? null,
        req.auth.companyId
      );
      if (!payPeriod) {
        throw PayrollDomainError.notFound('Pay period', req.body.payPeriodId);
      }

      req.log.info('payroll.batch.start', {
        payPeriodId: payPeriod.id,
        parallelLimit: req.body.parallelLimit ?? 4,
        useQueue: req.body.useQueue ?? false,
      });

      if (req.body.useQueue && features.jobQueueEnabled) {
        const queued = await deps.queuedBatchService.enqueueBatch({
          companyId: req.auth.companyId,
          payPeriod,
          year: req.body.year,
          frequency: req.body.frequency,
          employeeIds: req.body.employeeIds,
        });
        res.status(202).json({
          batch: queued.batch,
          enqueued: queued.enqueued,
          mode: 'queued',
        });
        return;
      }

      const result = await deps.payrollBatchService.createAndRun({
        companyId: req.auth.companyId,
        payPeriod,
        year: req.body.year,
        frequency: req.body.frequency,
        parallelLimit: req.body.parallelLimit,
        employeeIds: req.body.employeeIds,
      });

      req.log.info('payroll.batch.complete', {
        batchId: result.batch.id,
        successCount: result.batch.successCount,
        failureCount: result.batch.failureCount,
        durationMs: result.batch.durationMs,
      });

      res.status(201).json(result);
    })
  );

  router.get(
    '/batch/:id',
    asyncHandler(async (req, res) => {
      const result = await deps.payrollBatchService.getBatch(
        req.params.id,
        req.auth.companyId
      );
      res.json(result);
    })
  );

  router.get(
    '/stubs/:id/html',
    asyncHandler(async (req, res) => {
      const stub = await deps.payStubRepository.findById(req.params.id);
      if (!stub) {
        throw PayrollDomainError.notFound('Pay stub', req.params.id);
      }
      const employee = employeeForTenant(
        await deps.employeeRepository.findById(stub.employeeId),
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Pay stub', req.params.id);
      }
      const period = payPeriodForTenant(
        await deps.payPeriodRepository.findById(stub.payPeriodId),
        req.auth.companyId
      );
      const label = period
        ? `${period.startDate} – ${period.endDate}`
        : stub.payPeriodId;
      const html = deps.payStubHtmlRenderer.render(stub, employee, label);
      res.type('text/html').send(html);
    })
  );

  router.get(
    '/stubs/:id',
    asyncHandler(async (req, res) => {
      const stub = await deps.payStubRepository.findById(req.params.id);
      if (!stub) {
        throw PayrollDomainError.notFound('Pay stub', req.params.id);
      }
      const employee = employeeForTenant(
        await deps.employeeRepository.findById(stub.employeeId),
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Pay stub', req.params.id);
      }
      res.json(stub);
    })
  );

  return router;
}
