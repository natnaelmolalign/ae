import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { features } from '../config/features';

function parseTaxYear(query: Record<string, unknown>): number {
  const raw = query.taxYear;
  const taxYear =
    typeof raw === 'string' ? parseInt(raw, 10) : Number(raw ?? NaN);
  if (!Number.isInteger(taxYear) || taxYear < 2000 || taxYear > 2100) {
    throw new PayrollDomainError(
      PayrollErrorCode.INVALID_INPUT,
      'taxYear query parameter is required (2000–2100)'
    );
  }
  return taxYear;
}

function parseQuarter(query: Record<string, unknown>): number {
  const raw = query.quarter;
  const quarter =
    typeof raw === 'string' ? parseInt(raw, 10) : Number(raw ?? NaN);
  if (!Number.isInteger(quarter) || quarter < 1 || quarter > 4) {
    throw new PayrollDomainError(
      PayrollErrorCode.INVALID_INPUT,
      'quarter query parameter is required (1–4)'
    );
  }
  return quarter;
}

export function createReportsRouter(deps: AppDependencies): Router {
  const router = Router();

  router.get(
    '/payroll-register',
    asyncHandler(async (req, res) => {
      const periodId = req.query.periodId as string;
      if (!periodId) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'periodId query parameter is required'
        );
      }
      const data = await deps.reportingService.payrollRegister(
        periodId,
        req.auth.companyId
      );
      res.json(data);
    })
  );

  router.get(
    '/gl-export',
    asyncHandler(async (req, res) => {
      const periodId = req.query.periodId as string;
      if (!periodId) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'periodId query parameter is required'
        );
      }
      const data = await deps.reportingService.glExportForPeriod(
        periodId,
        req.auth.companyId
      );
      if (req.query.format === 'csv') {
        res.type('text/csv').send(data.csv);
        return;
      }
      res.json(data);
    })
  );

  router.get(
    '/labor-cost',
    asyncHandler(async (req, res) => {
      const periodId = req.query.periodId as string;
      if (!periodId) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'periodId query parameter is required'
        );
      }
      const data = await deps.reportingService.laborCost(
        periodId,
        req.auth.companyId
      );
      res.json(data);
    })
  );

  router.get(
    '/tip-register',
    asyncHandler(async (req, res) => {
      const periodId = req.query.periodId as string;
      if (!periodId) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'periodId query parameter is required'
        );
      }
      const data = await deps.reportingService.tipRegister(
        periodId,
        req.auth.companyId
      );
      res.json(data);
    })
  );

  router.get(
    '/w2-preview',
    asyncHandler(async (req, res) => {
      if (!features.complianceExportsEnabled) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'Compliance exports are disabled'
        );
      }
      const taxYear = parseTaxYear(req.query);
      const data = await deps.complianceReportingService.w2Preview(
        req.auth.companyId,
        taxYear
      );
      res.json(data);
    })
  );

  router.get(
    '/1099-nec-preview',
    asyncHandler(async (req, res) => {
      if (!features.complianceExportsEnabled) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'Compliance exports are disabled'
        );
      }
      const taxYear = parseTaxYear(req.query);
      const data = await deps.complianceReportingService.nec1099Preview(
        req.auth.companyId,
        taxYear
      );
      res.json(data);
    })
  );

  router.get(
    '/941-reconciliation',
    asyncHandler(async (req, res) => {
      if (!features.complianceExportsEnabled) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'Compliance exports are disabled'
        );
      }
      const taxYear = parseTaxYear(req.query);
      const quarter = parseQuarter(req.query);
      const data = await deps.complianceReportingService.form941Reconciliation(
        req.auth.companyId,
        taxYear,
        quarter
      );
      res.json(data);
    })
  );

  router.get(
    '/audit',
    asyncHandler(async (req, res) => {
      const schema = z.object({
        entityType: z.string().min(1),
        entityId: z.string().min(1),
      });
      const parsed = schema.safeParse(req.query);
      if (!parsed.success) {
        throw PayrollDomainError.notFound('entityType and entityId required');
      }
      const events = await deps.auditService.listForEntity(
        parsed.data.entityType,
        parsed.data.entityId
      );
      res.json({ events });
    })
  );

  return router;
}
