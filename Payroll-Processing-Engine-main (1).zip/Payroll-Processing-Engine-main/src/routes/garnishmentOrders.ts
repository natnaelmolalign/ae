import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { toAuditSnapshot } from '../utils/auditContext';

const createSchema = z.object({
  employeeId: z.string().uuid(),
  type: z.enum(['child_support', 'creditor', 'student_loan']),
  caseId: z.string().min(1),
  priority: z.number().int().optional(),
  fixedAmount: z.string(),
  maxPercentOfDisposable: z.string().nullable().optional(),
  effectiveDate: z.string(),
  endDate: z.string().nullable().optional(),
});

const updateSchema = createSchema
  .omit({ employeeId: true, type: true, caseId: true })
  .partial();

export function createGarnishmentOrdersRouter(deps: AppDependencies): Router {
  const router = Router();

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.get(
        req.body.employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.body.employeeId);
      }
      const order = await deps.garnishmentOrderService.create(req.body);
      await deps.auditService.recordCreate(
        req.actor,
        'garnishment_order',
        order.id,
        toAuditSnapshot(order)
      );
      res.status(201).json(order);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const employeeId = req.query.employeeId as string | undefined;
      if (!employeeId) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'employeeId query parameter is required'
        );
      }
      const employee = await deps.employeeService.get(
        employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', employeeId);
      }
      const asOf =
        (req.query.asOf as string) ?? new Date().toISOString().slice(0, 10);
      const activeOnly = req.query.active === 'true';
      const orders = activeOnly
        ? await deps.garnishmentOrderService.listActive(employeeId, asOf)
        : await deps.garnishmentOrderService.listByEmployee(employeeId);
      res.json({ orders });
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const order = await deps.garnishmentOrderService.get(req.params.id);
      if (!order) {
        throw PayrollDomainError.notFound('GarnishmentOrder', req.params.id);
      }
      res.json(order);
    })
  );

  router.patch(
    '/:id',
    validateBody(updateSchema),
    asyncHandler(async (req, res) => {
      const before = await deps.garnishmentOrderService.get(req.params.id);
      if (!before) {
        throw PayrollDomainError.notFound('GarnishmentOrder', req.params.id);
      }
      const order = await deps.garnishmentOrderService.update(
        req.params.id,
        req.body
      );
      await deps.auditService.recordUpdate(
        req.actor,
        'garnishment_order',
        order.id,
        toAuditSnapshot(before),
        toAuditSnapshot(order)
      );
      res.json(order);
    })
  );

  router.delete(
    '/:id',
    asyncHandler(async (req, res) => {
      const before = await deps.garnishmentOrderService.get(req.params.id);
      if (!before) {
        throw PayrollDomainError.notFound('GarnishmentOrder', req.params.id);
      }
      await deps.garnishmentOrderService.remove(req.params.id);
      await deps.auditService.recordDelete(
        req.actor,
        'garnishment_order',
        req.params.id,
        toAuditSnapshot(before)
      );
      res.status(204).send();
    })
  );

  return router;
}
