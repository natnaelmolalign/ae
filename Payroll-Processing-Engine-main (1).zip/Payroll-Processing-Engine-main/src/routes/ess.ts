import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { features } from '../config/features';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';

const w4DraftSchema = z.object({
  filingStatus: z.enum([
    'single',
    'married_filing_jointly',
    'married_filing_separately',
    'head_of_household',
  ]),
  w4ExtraWithholding: z.string().optional(),
  w4DependentsCredit: z.string().optional(),
  w4OtherDeductions: z.string().optional(),
  w4OtherIncome: z.string().optional(),
  w4MultipleJobs: z.boolean().optional(),
});

function requireEmployeeId(req: { auth: { employeeId?: string } }): string {
  const employeeId = req.auth.employeeId;
  if (!employeeId) {
    throw new PayrollDomainError(
      PayrollErrorCode.ESS_EMPLOYEE_CONTEXT_REQUIRED,
      'employee_self role requires employeeId in token or x-employee-id header'
    );
  }
  return employeeId;
}

export function createEssRouter(deps: AppDependencies): Router {
  const router = Router();

  router.use((_req, res, next) => {
    if (!features.employeeEssEnabled) {
      res.status(503).json({
        error: 'Employee self-service is disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.get(
    '/me/profile',
    asyncHandler(async (req, res) => {
      const employeeId = requireEmployeeId(req);
      const profile = await deps.essService.getProfile(
        employeeId,
        req.auth.companyId
      );
      res.json(profile);
    })
  );

  router.get(
    '/me/pay-stubs',
    asyncHandler(async (req, res) => {
      const employeeId = requireEmployeeId(req);
      const stubs = await deps.essService.listPayStubs(
        employeeId,
        req.auth.companyId
      );
      res.json({ payStubs: stubs });
    })
  );

  router.get(
    '/me/pay-stubs/:id',
    asyncHandler(async (req, res) => {
      const employeeId = requireEmployeeId(req);
      const stub = await deps.essService.getPayStub(
        employeeId,
        req.auth.companyId,
        req.params.id
      );
      res.json(stub);
    })
  );

  router.get(
    '/me/ytd',
    asyncHandler(async (req, res) => {
      const employeeId = requireEmployeeId(req);
      const taxYear = parseInt(
        String(req.query.taxYear ?? new Date().getFullYear()),
        10
      );
      if (!Number.isFinite(taxYear)) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'Invalid taxYear'
        );
      }
      const ytd = await deps.essService.getYtd(
        employeeId,
        req.auth.companyId,
        taxYear
      );
      res.json(ytd);
    })
  );

  router.get(
    '/me/w2-preview',
    asyncHandler(async (req, res) => {
      const employeeId = requireEmployeeId(req);
      const taxYear = parseInt(
        String(req.query.taxYear ?? new Date().getFullYear()),
        10
      );
      if (!Number.isFinite(taxYear)) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'Invalid taxYear'
        );
      }
      const preview = await deps.essService.getW2Preview(
        employeeId,
        req.auth.companyId,
        taxYear
      );
      res.json(preview);
    })
  );

  router.get(
    '/me/w4-change-requests',
    asyncHandler(async (req, res) => {
      const employeeId = requireEmployeeId(req);
      const requests = await deps.w4ChangeRequestService.listForEmployee(
        employeeId,
        req.auth.companyId
      );
      res.json({ w4ChangeRequests: requests });
    })
  );

  router.post(
    '/me/w4-change-requests',
    validateBody(w4DraftSchema),
    asyncHandler(async (req, res) => {
      const employeeId = requireEmployeeId(req);
      const request = await deps.w4ChangeRequestService.createDraft({
        companyId: req.auth.companyId,
        employeeId,
        ...req.body,
      });
      res.status(201).json(request);
    })
  );

  router.get(
    '/me/w4-change-requests/:id',
    asyncHandler(async (req, res) => {
      const employeeId = requireEmployeeId(req);
      const request = await deps.w4ChangeRequestService.getForEmployee(
        req.params.id,
        employeeId,
        req.auth.companyId
      );
      res.json(request);
    })
  );

  router.post(
    '/me/w4-change-requests/:id/submit',
    asyncHandler(async (req, res) => {
      const employeeId = requireEmployeeId(req);
      const request = await deps.w4ChangeRequestService.submit(
        req.params.id,
        employeeId,
        req.auth.companyId
      );
      res.json(request);
    })
  );

  return router;
}
