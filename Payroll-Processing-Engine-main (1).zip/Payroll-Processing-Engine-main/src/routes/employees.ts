import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { toAuditSnapshot } from '../utils/auditContext';

const createSchema = z.object({
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  employmentType: z.enum([
    'full_time_salaried',
    'full_time_hourly',
    'part_time',
    'contractor',
  ]),
  payFrequency: z.enum(['weekly', 'biweekly', 'semimonthly', 'monthly']),
  baseCompensation: z.string(),
  hireDate: z.string(),
  terminationDate: z.string().nullable().optional(),
  filingStatus: z.enum([
    'single',
    'married_filing_jointly',
    'married_filing_separately',
    'head_of_household',
  ]),
  stateCode: z.string().length(2),
  w4ExtraWithholding: z.string().optional(),
  w4DependentsCredit: z.string().optional(),
  equityWithholdingMethod: z
    .enum(['supplemental_flat', 'w4_annualized'])
    .optional(),
  tin: z.string().min(9).max(11).optional(),
});

const workLocationsSchema = z.object({
  locations: z
    .array(
      z.object({
        stateCode: z.string().length(2),
        allocationPercent: z.string(),
        effectiveDate: z.string(),
        endDate: z.string().nullable().optional(),
      })
    )
    .min(1),
});

export function createEmployeesRouter(deps: AppDependencies): Router {
  const router = Router();

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.create(
        req.body,
        req.auth.companyId
      );
      await deps.auditService.recordCreate(
        req.actor,
        'employee',
        employee.id,
        toAuditSnapshot(employee)
      );
      res.status(201).json(employee);
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.get(
        req.params.id,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.params.id);
      }
      res.json(employee);
    })
  );

  router.put(
    '/:id/work-locations',
    validateBody(workLocationsSchema),
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.get(
        req.params.id,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.params.id);
      }
      const locations = await deps.employeeWorkLocationService.replace(
        employee.id,
        req.body.locations
      );
      res.json({ locations });
    })
  );

  router.get(
    '/:id/work-locations',
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.get(
        req.params.id,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.params.id);
      }
      const locations = await deps.employeeWorkLocationService.listActive(
        employee.id
      );
      res.json({ locations });
    })
  );

  return router;
}
