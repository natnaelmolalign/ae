import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { features } from '../config/features';

const holdSchema = z.object({
  employeeId: z.string().uuid(),
  reasonCode: z.string().min(1).max(64),
  notes: z.string().optional(),
});

const releaseSchema = z.object({
  releaseReason: z.string().min(1).max(128),
});

const approvalSchema = z.object({
  notes: z.string().optional(),
});

export function createPayrollControlsRouter(deps: AppDependencies): Router {
  const router = Router();

  router.use((_req, res, next) => {
    if (!features.payrollControlsEnabled) {
      res.status(503).json({
        error: 'Payroll controls are disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.get(
    '/holds',
    asyncHandler(async (req, res) => {
      const holds = await deps.controlService.listActiveHolds(
        req.auth.companyId
      );
      res.json({ holds });
    })
  );

  router.post(
    '/holds',
    validateBody(holdSchema),
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.get(
        req.body.employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.body.employeeId);
      }
      const hold = await deps.controlService.createHold({
        companyId: req.auth.companyId,
        employeeId: req.body.employeeId,
        reasonCode: req.body.reasonCode,
        notes: req.body.notes,
        createdBy: req.actor,
      });
      res.status(201).json(hold);
    })
  );

  router.post(
    '/holds/:id/release',
    validateBody(releaseSchema),
    asyncHandler(async (req, res) => {
      const hold = await deps.controlService.releaseHold(
        req.params.id,
        req.auth.companyId,
        req.actor,
        req.body.releaseReason
      );
      if (!hold) {
        throw PayrollDomainError.notFound('Payroll hold', req.params.id);
      }
      res.json(hold);
    })
  );

  router.post(
    '/approvals/:id/approve',
    validateBody(approvalSchema),
    asyncHandler(async (req, res) => {
      const updated = await deps.payrollControlRepository.updateApprovalStatus(
        req.params.id,
        req.auth.companyId,
        'approved',
        req.actor,
        req.body.notes
      );
      if (!updated) {
        throw PayrollDomainError.notFound('Approval request', req.params.id);
      }
      res.json(updated);
    })
  );

  router.post(
    '/approvals/:id/reject',
    validateBody(approvalSchema),
    asyncHandler(async (req, res) => {
      const updated = await deps.payrollControlRepository.updateApprovalStatus(
        req.params.id,
        req.auth.companyId,
        'rejected',
        req.actor,
        req.body.notes
      );
      if (!updated) {
        throw PayrollDomainError.notFound('Approval request', req.params.id);
      }
      res.json(updated);
    })
  );

  return router;
}
