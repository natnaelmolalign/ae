import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { connectorTypes } from '../models/ErpConnector';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { features } from '../config/features';

const connectionSchema = z.object({
  connectorType: z.enum([...connectorTypes] as [string, ...string[]]),
  name: z.string().min(1).max(128),
  config: z.record(z.unknown()).nullable().optional(),
  isActive: z.boolean().optional(),
});

const mappingSchema = z.object({
  connectionId: z.string().uuid(),
  mappings: z.array(
    z.object({
      internalAccountCode: z.string().min(1).max(16),
      externalAccountId: z.string().min(1).max(64),
      externalAccountName: z.string().min(1).max(128),
    })
  ),
});

const exportSchema = z.object({
  connectionId: z.string().uuid(),
  payPeriodId: z.string().min(1),
  idempotencyKey: z.string().min(1).max(64),
});

function erpDisabled(
  _req: unknown,
  res: { status: (n: number) => { json: (b: unknown) => void } },
  next: () => void
) {
  if (!features.erpConnectorsEnabled) {
    res.status(503).json({
      error: 'ERP connectors are disabled',
      code: 'SERVICE_UNAVAILABLE',
    });
    return;
  }
  next();
}

export function createErpConnectionsRouter(deps: AppDependencies): Router {
  const router = Router();
  router.use(erpDisabled);

  router.post(
    '/',
    validateBody(connectionSchema),
    asyncHandler(async (req, res) => {
      const connection = await deps.erpExportService.createConnection({
        companyId: req.auth.companyId,
        ...req.body,
      });
      res.status(201).json(connection);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const connections = await deps.erpExportService.listConnections(
        req.auth.companyId
      );
      res.json({ connections });
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const connection = await deps.erpExportService.getConnection(
        req.params.id,
        req.auth.companyId
      );
      if (!connection) {
        throw PayrollDomainError.notFound(
          'IntegrationConnection',
          req.params.id
        );
      }
      res.json(connection);
    })
  );

  return router;
}

export function createGlAccountMappingsRouter(deps: AppDependencies): Router {
  const router = Router();
  router.use(erpDisabled);

  router.post(
    '/',
    validateBody(mappingSchema),
    asyncHandler(async (req, res) => {
      const connection = await deps.erpExportService.getConnection(
        req.body.connectionId,
        req.auth.companyId
      );
      if (!connection) {
        throw PayrollDomainError.notFound(
          'IntegrationConnection',
          req.body.connectionId
        );
      }
      const result = await deps.erpExportService.publishMappings({
        companyId: req.auth.companyId,
        connectionId: req.body.connectionId,
        mappings: req.body.mappings,
      });
      res.status(201).json(result);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const connectionId = req.query.connectionId as string | undefined;
      const versionRaw = req.query.version as string | undefined;
      if (!connectionId) {
        throw PayrollDomainError.notFound(
          'IntegrationConnection',
          'missing connectionId'
        );
      }
      if (versionRaw) {
        const mappings = await deps.erpExportService.getMappingsForVersion(
          connectionId,
          req.auth.companyId,
          parseInt(versionRaw, 10)
        );
        res.json({ connectionId, version: parseInt(versionRaw, 10), mappings });
        return;
      }
      const active = await deps.erpExportService.getActiveMappings(
        connectionId,
        req.auth.companyId
      );
      res.json({ connectionId, ...active });
    })
  );

  return router;
}

export function createErpExportsRouter(deps: AppDependencies): Router {
  const router = Router();
  router.use(erpDisabled);

  router.post(
    '/',
    validateBody(exportSchema),
    asyncHandler(async (req, res) => {
      const batch = await deps.erpExportService.exportToConnector({
        companyId: req.auth.companyId,
        ...req.body,
      });
      res.status(201).json(batch);
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const batch = await deps.erpExportService.getExport(
        req.params.id,
        req.auth.companyId
      );
      res.json(batch);
    })
  );

  return router;
}
