import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { employeeForTenant, payPeriodForTenant } from '../utils/tenant';
import { validateBody } from '../middleware/validator';

const createSchema = z.object({
  employeeId: z.string().uuid(),
  payPeriodId: z.string().optional(),
  workDate: z.string(),
  clockIn: z.string(),
  clockOut: z.string(),
  entryType: z
    .enum(['regular', 'holiday', 'overtime_manual', 'pto', 'sick'])
    .optional(),
  shiftAssignmentId: z.string().uuid().nullable().optional(),
});

export function createTimeEntriesRouter(deps: AppDependencies): Router {
  const router = Router();

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const entry = await deps.timeEntryService.create(req.body);
      res.status(201).json(entry);
    })
  );

  router.get(
    '/employee/:employeeId/period/:payPeriodId',
    asyncHandler(async (req, res) => {
      const period = payPeriodForTenant(
        await deps.payPeriodRepository.findById(req.params.payPeriodId),
        req.auth.companyId
      );
      if (!period) {
        throw PayrollDomainError.notFound('Pay period', req.params.payPeriodId);
      }
      const employee = employeeForTenant(
        await deps.employeeRepository.findById(req.params.employeeId),
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.params.employeeId);
      }
      const entries = await deps.timeEntryService.listForPayPeriod(
        req.params.employeeId,
        period
      );
      res.json(entries);
    })
  );

  return router;
}
