import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { enrollableBenefitTypes } from '../models/BenefitsLifecycle';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { features } from '../config/features';

const createSchema = z.object({
  benefitType: z.enum([...enrollableBenefitTypes] as [string, ...string[]]),
  employmentTypes: z
    .array(
      z.enum([
        'full_time_salaried',
        'full_time_hourly',
        'part_time',
        'contractor',
      ])
    )
    .nullable()
    .optional(),
  minTenureDays: z.number().int().nullable().optional(),
  requiresEnrollmentWindow: z.boolean().optional(),
  isActive: z.boolean().optional(),
});

export function createEligibilityRulesRouter(deps: AppDependencies): Router {
  const router = Router();

  router.use((_req, res, next) => {
    if (!features.benefitsLifecycleEnabled) {
      res.status(503).json({
        error: 'Benefits lifecycle is disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const rule = await deps.openEnrollmentService.createEligibilityRule({
        companyId: req.auth.companyId,
        ...req.body,
      });
      res.status(201).json(rule);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const rules = await deps.openEnrollmentService.listEligibilityRules(
        req.auth.companyId
      );
      res.json({ rules });
    })
  );

  return router;
}
