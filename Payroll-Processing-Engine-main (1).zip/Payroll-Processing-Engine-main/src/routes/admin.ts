import { Router } from 'express';
import { z } from 'zod';
import { runYtdReset } from '../jobs/ytdResetJob';
import { runAccrualForPayPeriod } from '../jobs/accrualRunJob';
import { defaultCompanyId } from '../config/auth';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';

const ytdResetSchema = z.object({
  taxYear: z.number().int().min(2000).max(2100),
  force: z.boolean().optional(),
});

export function createAdminRouter(): Router {
  const router = Router();

  router.post(
    '/ytd-reset',
    validateBody(ytdResetSchema),
    asyncHandler(async (req, res) => {
      const result = await runYtdReset(req.body.taxYear, {
        force: req.body.force,
      });
      res.json(result);
    })
  );

  const accrualRunSchema = z.object({
    payPeriodId: z.string().min(1),
    companyId: z.string().min(1).optional(),
  });

  router.post(
    '/accrual-run',
    validateBody(accrualRunSchema),
    asyncHandler(async (req, res) => {
      const result = await runAccrualForPayPeriod({
        companyId:
          req.body.companyId ?? req.auth?.companyId ?? defaultCompanyId(),
        payPeriodId: req.body.payPeriodId,
      });
      res.json(result);
    })
  );

  return router;
}
