import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { toAuditSnapshot } from '../utils/auditContext';

const createSchema = z.object({
  departmentId: z.string().uuid(),
  code: z.string().min(1).max(32),
  name: z.string().min(1).max(128),
});

export function createJobsRouter(deps: AppDependencies): Router {
  const router = Router();

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const job = await deps.jobService.create(req.body, req.auth.companyId);
      await deps.auditService.recordCreate(
        req.actor,
        'job',
        job.id,
        toAuditSnapshot(job)
      );
      res.status(201).json(job);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const departmentId = req.query.departmentId as string | undefined;
      if (!departmentId) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'departmentId query parameter is required'
        );
      }
      const list = await deps.jobService.listByDepartment(
        departmentId,
        req.auth.companyId
      );
      res.json({ jobs: list });
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const job = await deps.jobService.get(req.params.id, req.auth.companyId);
      if (!job) {
        throw PayrollDomainError.notFound('Job', req.params.id);
      }
      res.json(job);
    })
  );

  return router;
}
