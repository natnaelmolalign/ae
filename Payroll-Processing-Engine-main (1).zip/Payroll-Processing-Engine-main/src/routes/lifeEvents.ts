import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { features } from '../config/features';

const createSchema = z.object({
  employeeId: z.string().uuid(),
  eventType: z.enum([
    'marriage',
    'birth',
    'adoption',
    'loss_of_coverage',
    'divorce',
    'other',
  ]),
  eventDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  coverageEffectiveDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  notes: z.string().nullable().optional(),
});

const approveSchema = z.object({
  cobraPremiumPerPeriod: z.string().optional(),
  cobraStartDate: z.string().optional(),
});

export function createLifeEventsRouter(deps: AppDependencies): Router {
  const router = Router();

  router.use((_req, res, next) => {
    if (!features.benefitsLifecycleEnabled) {
      res.status(503).json({
        error: 'Benefits lifecycle is disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.get(
        req.body.employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.body.employeeId);
      }
      const event = await deps.openEnrollmentService.recordLifeEvent({
        companyId: req.auth.companyId,
        ...req.body,
      });
      res.status(201).json(event);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const employeeId = req.query.employeeId as string | undefined;
      if (!employeeId) {
        throw PayrollDomainError.notFound('Employee', 'missing employeeId');
      }
      const employee = await deps.employeeService.get(
        employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', employeeId);
      }
      const events = await deps.openEnrollmentService.listLifeEvents(
        employeeId,
        req.auth.companyId
      );
      res.json({ lifeEvents: events });
    })
  );

  router.post(
    '/:id/approve',
    validateBody(approveSchema),
    asyncHandler(async (req, res) => {
      const event = await deps.openEnrollmentService.approveLifeEvent(
        req.params.id,
        req.auth.companyId,
        {
          approvedBy: req.actor,
          cobraPremiumPerPeriod: req.body.cobraPremiumPerPeriod,
          cobraStartDate: req.body.cobraStartDate,
        }
      );
      res.json(event);
    })
  );

  router.post(
    '/:id/reject',
    asyncHandler(async (req, res) => {
      const event = await deps.openEnrollmentService.rejectLifeEvent(
        req.params.id,
        req.auth.companyId,
        req.actor
      );
      res.json(event);
    })
  );

  return router;
}
