import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { features } from '../config/features';

const createSchema = z.object({
  payPeriodId: z.string().optional(),
  payrollRunIds: z.array(z.string().uuid()).optional(),
  nachaProfile: z.enum(['PPD', 'CCD']).optional(),
  idempotencyKey: z.string().max(64).optional(),
});

const submitSchema = z.object({
  companyRouting: z.string().min(9).max(9),
  companyAccount: z.string().min(4).max(17),
  companyName: z.string().min(1).max(23),
  effectiveDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
});

export function createPaymentBatchesRouter(deps: AppDependencies): Router {
  const router = Router();

  router.use((_req, res, next) => {
    if (!features.disbursementsEnabled) {
      res.status(503).json({
        error: 'Disbursements are disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const batch = await deps.paymentBatchService.createBatch({
        companyId: req.auth.companyId,
        ...req.body,
      });
      res.status(201).json(batch);
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const batch = await deps.paymentBatchService.getBatch(
        req.params.id,
        req.auth.companyId
      );
      res.json(batch);
    })
  );

  router.post(
    '/:id/submit',
    validateBody(submitSchema),
    asyncHandler(async (req, res) => {
      const result = await deps.paymentBatchService.submitBatch(
        req.params.id,
        req.auth.companyId,
        req.body
      );
      res.json(result);
    })
  );

  router.get(
    '/:id/reconciliation',
    asyncHandler(async (req, res) => {
      const report = await deps.paymentBatchService.reconcile(
        req.params.id,
        req.auth.companyId
      );
      res.json(report);
    })
  );

  router.get(
    '/:id/ach-file',
    asyncHandler(async (req, res) => {
      const file = await deps.paymentBatchService.getAchFile(
        req.params.id,
        req.auth.companyId
      );
      res.json(file);
    })
  );

  return router;
}
