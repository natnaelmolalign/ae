import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import type { EarningsLine, PayPeriod, PayrollRunInput } from '../models/types';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';

const earningsSchema = z.array(
  z.object({
    type: z.string(),
    amount: z.string(),
    hours: z.number().optional(),
  })
);

const adjustmentBodySchema = z.object({
  employeeId: z.string().uuid(),
  effectiveDate: z.string(),
  currentPayPeriodId: z.string(),
  year: z.number(),
  frequency: z.enum(['weekly', 'biweekly', 'semimonthly', 'monthly']),
  reason: z.string(),
  earningsPerPeriod: earningsSchema,
});

function runInputFactory(
  employeeId: string,
  earnings: EarningsLine[]
): (period: PayPeriod) => PayrollRunInput {
  return (period) => ({
    employeeId,
    payPeriodId: period.id,
    earnings,
    deductions: [],
    garnishments: [],
  });
}

async function loadAdjustmentContext(
  deps: AppDependencies,
  body: z.infer<typeof adjustmentBodySchema>,
  companyId: string
) {
  const employee = await deps.employeeService.get(body.employeeId, companyId);
  if (!employee) {
    throw PayrollDomainError.notFound('Employee', body.employeeId);
  }

  const periods = await deps.payPeriodRepository.findByYearAndFrequency(
    body.year,
    body.frequency,
    companyId
  );
  if (periods.length === 0) {
    throw PayrollDomainError.notFound(
      'Pay periods',
      `${body.year}:${body.frequency}`
    );
  }

  const currentPeriod = periods.find((p) => p.id === body.currentPayPeriodId);
  if (!currentPeriod) {
    throw PayrollDomainError.notFound('Pay period', body.currentPayPeriodId);
  }

  return { employee, periods, currentPeriod };
}

export function createAdjustmentsRouter(deps: AppDependencies): Router {
  const router = Router();

  router.post(
    '/',
    validateBody(adjustmentBodySchema),
    asyncHandler(async (req, res) => {
      const draft = await deps.retroAdjustmentService.createDraft(
        req.body.employeeId,
        req.body.effectiveDate,
        req.body.currentPayPeriodId,
        req.body.reason,
        req.body.earningsPerPeriod
      );
      res.status(201).json(draft);
    })
  );

  router.post(
    '/:id/preview',
    validateBody(
      z.object({
        year: z.number(),
        frequency: z.enum(['weekly', 'biweekly', 'semimonthly', 'monthly']),
      })
    ),
    asyncHandler(async (req, res) => {
      const record = await deps.retroAdjustmentRepository.findById(
        req.params.id
      );
      if (!record) {
        throw PayrollDomainError.notFound('Retro adjustment', req.params.id);
      }

      const body = {
        employeeId: record.employeeId,
        effectiveDate: record.effectiveDate,
        currentPayPeriodId: record.currentPayPeriodId,
        year: req.body.year as number,
        frequency: req.body.frequency as string,
        reason: record.reason,
        earningsPerPeriod: record.earningsPerPeriod,
      };

      if (!body.year || !body.frequency) {
        throw PayrollDomainError.notFound(
          'year and frequency',
          'required in preview body'
        );
      }

      const ctx = await loadAdjustmentContext(
        deps,
        body as z.infer<typeof adjustmentBodySchema>,
        req.auth.companyId
      );

      const previewed = await deps.retroAdjustmentService.preview(
        req.params.id,
        ctx.employee,
        ctx.periods,
        ctx.currentPeriod,
        runInputFactory(record.employeeId, record.earningsPerPeriod)
      );

      res.json(previewed);
    })
  );

  router.post(
    '/:id/approve',
    asyncHandler(async (req, res) => {
      const approved = await deps.retroAdjustmentService.approve(req.params.id);
      res.json(approved);
    })
  );

  router.post(
    '/:id/apply',
    validateBody(
      z.object({
        year: z.number(),
        frequency: z.enum(['weekly', 'biweekly', 'semimonthly', 'monthly']),
      })
    ),
    asyncHandler(async (req, res) => {
      const record = await deps.retroAdjustmentRepository.findById(
        req.params.id
      );
      if (!record) {
        throw PayrollDomainError.notFound('Retro adjustment', req.params.id);
      }

      const ctx = await loadAdjustmentContext(
        deps,
        {
          employeeId: record.employeeId,
          effectiveDate: record.effectiveDate,
          currentPayPeriodId: record.currentPayPeriodId,
          year: req.body.year,
          frequency: req.body.frequency,
          reason: record.reason,
          earningsPerPeriod: record.earningsPerPeriod,
        },
        req.auth.companyId
      );

      const result = await deps.retroAdjustmentService.apply(
        req.params.id,
        ctx.employee,
        ctx.periods,
        ctx.currentPeriod,
        runInputFactory(record.employeeId, record.earningsPerPeriod)
      );

      res.status(200).json(result);
    })
  );

  /** Legacy: draft → preview → approve → apply in one request. */
  router.post(
    '/run',
    validateBody(adjustmentBodySchema),
    asyncHandler(async (req, res) => {
      const ctx = await loadAdjustmentContext(
        deps,
        req.body,
        req.auth.companyId
      );
      const adjustment = await deps.retroAdjustmentService.applyDirect(
        ctx.employee,
        ctx.periods,
        req.body.effectiveDate,
        ctx.currentPeriod,
        runInputFactory(req.body.employeeId, req.body.earningsPerPeriod),
        req.body.reason
      );
      res.status(201).json(adjustment);
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const record = await deps.retroAdjustmentRepository.findById(
        req.params.id
      );
      if (!record) {
        throw PayrollDomainError.notFound('Retro adjustment', req.params.id);
      }
      res.json(record);
    })
  );

  return router;
}
