import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { withCompanyId } from '../utils/tenant';

const generateSchema = z.object({
  year: z.number().int().min(2000).max(2100),
  frequency: z.enum(['weekly', 'biweekly', 'semimonthly', 'monthly']),
  biweeklyAnchor: z.string().optional(),
});

export function createPayPeriodsRouter(deps: AppDependencies): Router {
  const router = Router();

  router.post(
    '/generate',
    validateBody(generateSchema),
    asyncHandler(async (req, res) => {
      const { year, frequency, biweeklyAnchor } = req.body;
      const periods = withCompanyId(
        deps.payPeriodService.generate(year, frequency, biweeklyAnchor),
        req.auth.companyId
      );
      deps.payPeriodService.validateNoOverlap(periods);
      await deps.payPeriodRepository.upsertMany(periods);
      res.json({ count: periods.length, periods });
    })
  );

  router.get(
    '/:year/:frequency',
    asyncHandler(async (req, res) => {
      const year = Number(req.params.year);
      const periods = await deps.payPeriodRepository.findByYearAndFrequency(
        year,
        req.params.frequency,
        req.auth.companyId
      );
      if (periods.length === 0) {
        throw PayrollDomainError.notFound(
          'Pay periods',
          `${year}:${req.params.frequency}`
        );
      }
      res.json(periods);
    })
  );

  return router;
}
