import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { features } from '../config/features';

const rejectSchema = z.object({
  notes: z.string().optional(),
});

export function createW4ChangeRequestsRouter(deps: AppDependencies): Router {
  const router = Router();

  router.use((_req, res, next) => {
    if (!features.employeeEssEnabled) {
      res.status(503).json({
        error: 'Employee self-service is disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const status = (req.query.status as string | undefined) ?? 'pending';
      if (status !== 'pending') {
        res.json({ w4ChangeRequests: [] });
        return;
      }
      const requests = await deps.w4ChangeRequestService.listPending(
        req.auth.companyId
      );
      res.json({ w4ChangeRequests: requests });
    })
  );

  router.post(
    '/:id/approve',
    asyncHandler(async (req, res) => {
      const request = await deps.w4ChangeRequestService.approve(
        req.params.id,
        req.auth.companyId,
        req.actor
      );
      res.json(request);
    })
  );

  router.post(
    '/:id/reject',
    validateBody(rejectSchema),
    asyncHandler(async (req, res) => {
      const request = await deps.w4ChangeRequestService.reject(
        req.params.id,
        req.auth.companyId,
        req.actor,
        req.body.notes
      );
      res.json(request);
    })
  );

  return router;
}
