import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { toAuditSnapshot } from '../utils/auditContext';

const createSchema = z.object({
  url: z.string().url(),
  secret: z.string().min(16),
  events: z
    .array(
      z.enum(['payroll.run.completed', 'pay_stub.created', 'batch.completed'])
    )
    .min(1),
  enabled: z.boolean().optional(),
});

const updateSchema = createSchema.partial();

export function createAdminWebhooksRouter(deps: AppDependencies): Router {
  const router = Router();

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const sub = await deps.webhookSubscriptionService.create(
        req.body,
        req.auth.companyId
      );
      await deps.auditService.recordCreate(
        req.actor,
        'webhook_subscription',
        sub.id,
        toAuditSnapshot(deps.webhookSubscriptionService.toPublicView(sub))
      );
      res.status(201).json(deps.webhookSubscriptionService.toPublicView(sub));
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const list = await deps.webhookSubscriptionService.list(
        req.auth.companyId
      );
      res.json({
        subscriptions: list.map((s) =>
          deps.webhookSubscriptionService.toPublicView(s)
        ),
      });
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const sub = await deps.webhookSubscriptionService.get(req.params.id);
      if (!sub || sub.companyId !== req.auth.companyId) {
        throw PayrollDomainError.notFound('WebhookSubscription', req.params.id);
      }
      res.json(deps.webhookSubscriptionService.toPublicView(sub));
    })
  );

  router.patch(
    '/:id',
    validateBody(updateSchema),
    asyncHandler(async (req, res) => {
      const before = await deps.webhookSubscriptionService.get(req.params.id);
      if (!before || before.companyId !== req.auth.companyId) {
        throw PayrollDomainError.notFound('WebhookSubscription', req.params.id);
      }
      const updated = await deps.webhookSubscriptionService.update(
        req.params.id,
        req.body
      );
      await deps.auditService.recordUpdate(
        req.actor,
        'webhook_subscription',
        updated.id,
        toAuditSnapshot(deps.webhookSubscriptionService.toPublicView(before)),
        toAuditSnapshot(deps.webhookSubscriptionService.toPublicView(updated))
      );
      res.json(deps.webhookSubscriptionService.toPublicView(updated));
    })
  );

  router.delete(
    '/:id',
    asyncHandler(async (req, res) => {
      const before = await deps.webhookSubscriptionService.get(req.params.id);
      if (!before || before.companyId !== req.auth.companyId) {
        throw PayrollDomainError.notFound('WebhookSubscription', req.params.id);
      }
      await deps.webhookSubscriptionService.delete(req.params.id);
      await deps.auditService.recordDelete(
        req.actor,
        'webhook_subscription',
        req.params.id,
        toAuditSnapshot(deps.webhookSubscriptionService.toPublicView(before))
      );
      res.status(204).send();
    })
  );

  return router;
}
