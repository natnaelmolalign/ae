import { Router } from 'express';
import { asyncHandler } from '../middleware/asyncHandler';
import { metricsContentType, renderMetrics } from '../metrics/prometheus';

export function createMetricsRouter(): Router {
  const router = Router();

  router.get(
    '/',
    asyncHandler(async (_req, res) => {
      const body = await renderMetrics();
      res.set('Content-Type', metricsContentType());
      res.send(body);
    })
  );

  return router;
}
