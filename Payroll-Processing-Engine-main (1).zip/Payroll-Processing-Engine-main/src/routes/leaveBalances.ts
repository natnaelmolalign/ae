import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';
import { leaveTypes } from '../models/LeavePolicy';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { features } from '../config/features';

const adjustSchema = z.object({
  employeeId: z.string().uuid(),
  leaveType: z.enum(leaveTypes),
  policyId: z.string().uuid(),
  calendarYear: z.number().int().min(2000).max(2100),
  hoursDelta: z.string().min(1),
  notes: z.string().min(1).max(512),
});

export function createLeaveBalancesRouter(deps: AppDependencies): Router {
  const router = Router();

  router.use((_req, res, next) => {
    if (!features.leaveAccrualsEnabled) {
      res.status(503).json({
        error: 'Leave accruals are disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const employeeId = req.query.employeeId as string | undefined;
      const yearRaw = req.query.calendarYear as string | undefined;
      if (!employeeId) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'employeeId query parameter is required'
        );
      }
      const employee = await deps.employeeRepository.findById(employeeId);
      if (!employee || employee.companyId !== req.auth.companyId) {
        throw PayrollDomainError.notFound('Employee', employeeId);
      }
      const calendarYear = yearRaw ? parseInt(yearRaw, 10) : undefined;
      const balances = await deps.leaveBalanceRepository.listByEmployee(
        employeeId,
        req.auth.companyId,
        calendarYear
      );
      const transactions = await deps.leaveTransactionRepository.listByEmployee(
        employeeId,
        req.auth.companyId,
        calendarYear
      );
      res.json({ balances, transactions });
    })
  );

  router.post(
    '/adjust',
    validateBody(adjustSchema),
    asyncHandler(async (req, res) => {
      const body = req.body as z.infer<typeof adjustSchema>;
      const employee = await deps.employeeRepository.findById(body.employeeId);
      if (!employee || employee.companyId !== req.auth.companyId) {
        throw PayrollDomainError.notFound('Employee', body.employeeId);
      }
      const result = await deps.db.transaction(async (trx) => {
        return deps.leaveAccrualService.adjustBalance(trx, {
          companyId: req.auth.companyId,
          employeeId: body.employeeId,
          leaveType: body.leaveType,
          policyId: body.policyId,
          calendarYear: body.calendarYear,
          hoursDelta: body.hoursDelta,
          actor: req.actor,
          notes: body.notes,
        });
      });
      await deps.auditService.recordCreate(
        req.actor,
        'leave_adjustment',
        body.employeeId,
        {
          ...body,
          balanceHours: result.balanceHours,
        }
      );
      res.json(result);
    })
  );

  return router;
}
