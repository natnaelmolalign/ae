import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { toAuditSnapshot } from '../utils/auditContext';

const createSchema = z.object({
  employeeId: z.string().uuid(),
  scheduleType: z.enum(['cobra_premium', 'arrears']),
  amountPerPeriod: z.string(),
  remainingBalance: z.string().nullable().optional(),
  priority: z.number().int().optional(),
  startDate: z.string(),
  endDate: z.string().nullable().optional(),
});

const updateSchema = createSchema
  .omit({ employeeId: true, scheduleType: true })
  .partial();

export function createDeductionSchedulesRouter(deps: AppDependencies): Router {
  const router = Router();

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.get(
        req.body.employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.body.employeeId);
      }

      const schedule = await deps.deductionScheduleService.create(
        req.body,
        req.auth.companyId
      );
      await deps.auditService.recordCreate(
        req.actor,
        'deduction_schedule',
        schedule.id,
        toAuditSnapshot(schedule)
      );
      res.status(201).json(schedule);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const employeeId = req.query.employeeId as string | undefined;
      if (!employeeId) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'employeeId query parameter is required'
        );
      }
      const employee = await deps.employeeService.get(
        employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', employeeId);
      }
      const asOf = req.query.asOf as string | undefined;
      const list = asOf
        ? await deps.deductionScheduleService.listActive(employeeId, asOf)
        : await deps.deductionScheduleService.listByEmployee(employeeId);
      res.json({ schedules: list });
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const schedule = await deps.deductionScheduleService.get(req.params.id);
      if (!schedule) {
        throw PayrollDomainError.notFound('DeductionSchedule', req.params.id);
      }
      res.json(schedule);
    })
  );

  router.patch(
    '/:id',
    validateBody(updateSchema),
    asyncHandler(async (req, res) => {
      const before = await deps.deductionScheduleService.get(req.params.id);
      if (!before) {
        throw PayrollDomainError.notFound('DeductionSchedule', req.params.id);
      }
      const updated = await deps.deductionScheduleService.update(
        req.params.id,
        req.body
      );
      await deps.auditService.recordUpdate(
        req.actor,
        'deduction_schedule',
        updated.id,
        toAuditSnapshot(before),
        toAuditSnapshot(updated)
      );
      res.json(updated);
    })
  );

  router.delete(
    '/:id',
    asyncHandler(async (req, res) => {
      const before = await deps.deductionScheduleService.get(req.params.id);
      if (!before) {
        throw PayrollDomainError.notFound('DeductionSchedule', req.params.id);
      }
      await deps.deductionScheduleService.delete(req.params.id);
      await deps.auditService.recordDelete(
        req.actor,
        'deduction_schedule',
        req.params.id,
        toAuditSnapshot(before)
      );
      res.status(204).send();
    })
  );

  return router;
}
