import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { toAuditSnapshot } from '../utils/auditContext';
import { features } from '../config/features';

const createSchema = z.object({
  employeeId: z.string().uuid(),
  type: z.enum([
    'section_125',
    'hsa',
    'fsa',
    '401k_pretax',
    '401k_roth',
    'life_insurance',
    'charitable',
  ]),
  amountPerPeriod: z.string(),
  percentOfGross: z.string().nullable().optional(),
  annualLimit: z.string().nullable().optional(),
  effectiveDate: z.string(),
  endDate: z.string().nullable().optional(),
  hsaCoverage: z.enum(['individual', 'family']).nullable().optional(),
  catchUpEligible: z.boolean().optional(),
  priority: z.number().int().optional(),
  lifeEventId: z.string().uuid().nullable().optional(),
  enrollmentWindowId: z.string().uuid().nullable().optional(),
});

const updateSchema = createSchema
  .omit({ employeeId: true, type: true })
  .partial();

export function createBenefitEnrollmentsRouter(deps: AppDependencies): Router {
  const router = Router();

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.get(
        req.body.employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.body.employeeId);
      }
      const enrollment = features.benefitsLifecycleEnabled
        ? await deps.openEnrollmentService.electBenefit(employee, {
            companyId: req.auth.companyId,
            ...req.body,
          })
        : await deps.benefitEnrollmentService.create(req.body);
      res.status(201).json(enrollment);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const employeeId = req.query.employeeId as string | undefined;
      if (!employeeId) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'employeeId query parameter is required'
        );
      }
      const employee = await deps.employeeService.get(
        employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', employeeId);
      }
      const asOf =
        (req.query.asOf as string) ?? new Date().toISOString().slice(0, 10);
      const activeOnly = req.query.active === 'true';
      const list = activeOnly
        ? await deps.benefitEnrollmentService.listActive(employeeId, asOf)
        : await deps.benefitEnrollmentService.listByEmployee(employeeId);
      res.json({ enrollments: list });
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const enrollment = await deps.benefitEnrollmentService.get(req.params.id);
      if (!enrollment) {
        throw PayrollDomainError.notFound('BenefitEnrollment', req.params.id);
      }
      res.json(enrollment);
    })
  );

  router.patch(
    '/:id',
    validateBody(updateSchema),
    asyncHandler(async (req, res) => {
      const before = await deps.benefitEnrollmentService.get(req.params.id);
      if (!before) {
        throw PayrollDomainError.notFound('BenefitEnrollment', req.params.id);
      }
      const enrollment = await deps.benefitEnrollmentService.update(
        req.params.id,
        req.body
      );
      await deps.auditService.recordUpdate(
        req.actor,
        'benefit_enrollment',
        enrollment.id,
        toAuditSnapshot(before),
        toAuditSnapshot(enrollment)
      );
      res.json(enrollment);
    })
  );

  router.delete(
    '/:id',
    asyncHandler(async (req, res) => {
      const before = await deps.benefitEnrollmentService.get(req.params.id);
      if (!before) {
        throw PayrollDomainError.notFound('BenefitEnrollment', req.params.id);
      }
      await deps.benefitEnrollmentService.remove(req.params.id);
      await deps.auditService.recordDelete(
        req.actor,
        'benefit_enrollment',
        req.params.id,
        toAuditSnapshot(before)
      );
      res.status(204).send();
    })
  );

  return router;
}
