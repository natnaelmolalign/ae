import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { taxYearFromPaymentDate } from '../config/taxYear';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';

const previewSchema = z.object({
  employeeId: z.string().uuid(),
  payPeriodId: z.string(),
  year: z.number(),
  frequency: z.enum(['weekly', 'biweekly', 'semimonthly', 'monthly']),
  earnings: z
    .array(
      z.object({
        type: z.string(),
        amount: z.string(),
        hours: z.number().optional(),
      })
    )
    .default([]),
  deductions: z
    .array(
      z.object({
        type: z.string(),
        amountPerPeriod: z.string(),
        percentOfGross: z.string().optional(),
        annualLimit: z.string().optional(),
        catchUpEligible: z.boolean().optional(),
        hsaCoverage: z.enum(['individual', 'family']).optional(),
        priority: z.number().optional(),
      })
    )
    .optional(),
  useActiveEnrollments: z.boolean().optional(),
  useActiveDeductionSchedules: z.boolean().optional(),
});

export function createDeductionsRouter(deps: AppDependencies): Router {
  const router = Router();

  router.get('/types', (_req, res) => {
    res.json({
      pretax: ['section_125', 'hsa', 'fsa', '401k_pretax'],
      posttax: ['401k_roth', 'life_insurance', 'charitable'],
      scheduled: ['cobra_premium', 'arrears_recovery'],
      garnishment: ['garnishment_child_support', 'garnishment_creditor'],
    });
  });

  router.post(
    '/preview',
    validateBody(previewSchema),
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.get(
        req.body.employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.body.employeeId);
      }

      const periods = await deps.payPeriodRepository.findByYearAndFrequency(
        req.body.year,
        req.body.frequency,
        req.auth.companyId
      );
      const payPeriod = periods.find((p) => p.id === req.body.payPeriodId);
      if (!payPeriod) {
        throw PayrollDomainError.notFound('Pay period', req.body.payPeriodId);
      }

      const taxYear = taxYearFromPaymentDate(payPeriod.paymentDate);

      const result = await deps.deductionPreviewService.preview({
        employee,
        paymentDate: payPeriod.paymentDate,
        taxYear,
        earnings: req.body.earnings,
        deductions: req.body.deductions,
        useActiveEnrollments: req.body.useActiveEnrollments,
        useActiveDeductionSchedules: req.body.useActiveDeductionSchedules,
      });

      res.json(result);
    })
  );

  return router;
}
