import { Router } from 'express';
import type { AppDependencies } from '../deps';
import { asyncHandler } from '../middleware/asyncHandler';
import { features } from '../config/features';

export function createQueueAdminRouter(deps: AppDependencies): Router {
  const router = Router();

  router.use((_req, res, next) => {
    if (!features.jobQueueEnabled) {
      res.status(503).json({
        error: 'Job queue is disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.get(
    '/dead-letters',
    asyncHandler(async (_req, res) => {
      const items = await deps.jobQueue.listDeadLetters(100);
      res.json({ deadLetters: items });
    })
  );

  return router;
}
