import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { enrollableBenefitTypes } from '../models/BenefitsLifecycle';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { features } from '../config/features';

const createSchema = z.object({
  code: z.string().min(1).max(32),
  name: z.string().min(1).max(128),
  planYear: z.number().int(),
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  status: z.enum(['open', 'closed']).optional(),
  allowedBenefitTypes: z.array(
    z.enum([...enrollableBenefitTypes] as [string, ...string[]])
  ),
});

export function createEnrollmentWindowsRouter(deps: AppDependencies): Router {
  const router = Router();

  router.use((_req, res, next) => {
    if (!features.benefitsLifecycleEnabled) {
      res.status(503).json({
        error: 'Benefits lifecycle is disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const window = await deps.openEnrollmentService.createWindow({
        companyId: req.auth.companyId,
        ...req.body,
      });
      res.status(201).json(window);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const windows = await deps.openEnrollmentService.listWindows(
        req.auth.companyId
      );
      res.json({ windows });
    })
  );

  router.post(
    '/:id/close',
    asyncHandler(async (req, res) => {
      const window = await deps.openEnrollmentService.closeWindow(
        req.params.id,
        req.auth.companyId
      );
      res.json(window);
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const window = await deps.enrollmentWindowRepository.findById(
        req.params.id,
        req.auth.companyId
      );
      if (!window) {
        throw PayrollDomainError.notFound('EnrollmentWindow', req.params.id);
      }
      res.json(window);
    })
  );

  return router;
}
