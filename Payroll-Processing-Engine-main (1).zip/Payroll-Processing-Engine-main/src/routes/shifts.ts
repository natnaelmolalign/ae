import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import {
  assignShiftSchema,
  createShiftSchema,
} from '../models/WorkforceScheduling';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { toAuditSnapshot } from '../utils/auditContext';
import { features } from '../config/features';

export function createShiftsRouter(deps: AppDependencies): Router {
  const router = Router();

  router.use((_req, res, next) => {
    if (!features.workforceSchedulingEnabled) {
      res.status(503).json({
        error: 'Workforce scheduling is disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.post(
    '/',
    validateBody(createShiftSchema),
    asyncHandler(async (req, res) => {
      const shift = await deps.schedulingService.createShift(
        req.auth.companyId,
        req.body
      );
      await deps.auditService.recordCreate(
        req.actor,
        'shift',
        shift.id,
        toAuditSnapshot(shift)
      );
      res.status(201).json(shift);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const workDate = req.query.workDate as string | undefined;
      const shifts = await deps.schedulingService.listShifts(
        req.auth.companyId,
        workDate
      );
      res.json({ shifts });
    })
  );

  router.post(
    '/:shiftId/assignments',
    validateBody(assignShiftSchema),
    asyncHandler(async (req, res) => {
      const assignment = await deps.schedulingService.assignEmployee(
        req.auth.companyId,
        req.params.shiftId,
        req.body.employeeId
      );
      await deps.auditService.recordCreate(
        req.actor,
        'shift_assignment',
        assignment.id,
        toAuditSnapshot(assignment)
      );
      res.status(201).json(assignment);
    })
  );

  router.get(
    '/assignments',
    asyncHandler(async (req, res) => {
      const assignments = await deps.schedulingService.listAssignments(
        req.auth.companyId,
        {
          employeeId: req.query.employeeId as string | undefined,
          shiftId: req.query.shiftId as string | undefined,
          status: req.query.status as
            | import('../models/WorkforceScheduling').ShiftAssignmentStatus
            | undefined,
        }
      );
      res.json({ assignments });
    })
  );

  router.post(
    '/assignments/:id/approve',
    asyncHandler(async (req, res) => {
      const assignment = await deps.timeApprovalService.approve(
        req.params.id,
        req.auth.companyId,
        req.actor
      );
      await deps.auditService.recordUpdate(
        req.actor,
        'shift_assignment',
        assignment.id,
        {},
        toAuditSnapshot(assignment)
      );
      res.json(assignment);
    })
  );

  router.post(
    '/assignments/:id/reject',
    validateBody(z.object({ notes: z.string().min(1).max(512) })),
    asyncHandler(async (req, res) => {
      const assignment = await deps.timeApprovalService.reject(
        req.params.id,
        req.auth.companyId,
        req.actor,
        req.body.notes
      );
      res.json(assignment);
    })
  );

  return router;
}
