import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { features } from '../config/features';
import { PayrollDomainError } from '../errors/PayrollDomainError';

const pluginSchema = z.object({
  pluginId: z.string().min(1),
  employeeId: z.string().uuid(),
  payPeriodId: z.string(),
  grossPay: z.string(),
});

export function createFilingRouter(deps: AppDependencies): Router {
  const router = Router();

  router.use((_req, res, next) => {
    if (!features.filingPlatformEnabled) {
      res.status(503).json({
        error: 'Filing platform is disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.get(
    '/w2/:taxYear/xml',
    asyncHandler(async (req, res) => {
      const taxYear = parseInt(req.params.taxYear, 10);
      const result = await deps.filingExportService.exportW2Xml(
        req.auth.companyId,
        taxYear
      );
      res.type(result.contentType).send(result.body);
    })
  );

  router.get(
    '/1099-nec/:taxYear/xml',
    asyncHandler(async (req, res) => {
      const taxYear = parseInt(req.params.taxYear, 10);
      const result = await deps.filingExportService.export1099NecXml(
        req.auth.companyId,
        taxYear
      );
      res.type(result.contentType).send(result.body);
    })
  );

  router.get(
    '/941/:taxYear/:quarter/csv',
    asyncHandler(async (req, res) => {
      const taxYear = parseInt(req.params.taxYear, 10);
      const quarter = parseInt(req.params.quarter, 10);
      const result = await deps.filingExportService.export941Csv(
        req.auth.companyId,
        taxYear,
        quarter
      );
      res.type(result.contentType).send(result.body);
    })
  );

  router.post(
    '/plugins/execute',
    validateBody(pluginSchema),
    asyncHandler(async (req, res) => {
      const employee = await deps.employeeService.get(
        req.body.employeeId,
        req.auth.companyId
      );
      if (!employee) {
        throw PayrollDomainError.notFound('Employee', req.body.employeeId);
      }
      const result = await deps.pluginHost.execute(req.body.pluginId, {
        companyId: req.auth.companyId,
        employeeId: req.body.employeeId,
        grossPay: req.body.grossPay,
        payPeriodId: req.body.payPeriodId,
      });
      res.json({ result });
    })
  );

  router.get(
    '/plugins',
    asyncHandler(async (_req, res) => {
      res.json({
        plugins: deps.pluginHost
          .list()
          .map((p) => ({ id: p.id, name: p.name })),
      });
    })
  );

  return router;
}
