import { Router } from 'express';
import { z } from 'zod';
import type { AppDependencies } from '../deps';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import {
  accrualMethods,
  fixedAccrualConfigSchema,
  leaveTypes,
  tenureBandsAccrualConfigSchema,
} from '../models/LeavePolicy';
import { asyncHandler } from '../middleware/asyncHandler';
import { validateBody } from '../middleware/validator';
import { toAuditSnapshot } from '../utils/auditContext';
import { features } from '../config/features';

const createSchema = z.object({
  code: z.string().min(1).max(32),
  name: z.string().min(1).max(128),
  leaveType: z.enum(leaveTypes),
  accrualMethod: z.enum(accrualMethods),
  accrualConfig: z.union([
    fixedAccrualConfigSchema,
    tenureBandsAccrualConfigSchema,
  ]),
  carryoverMaxHours: z.string().nullable().optional(),
  effectiveFrom: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  effectiveTo: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .nullable()
    .optional(),
  isActive: z.boolean().optional(),
});

const updateSchema = createSchema
  .partial()
  .omit({ code: true, leaveType: true, accrualMethod: true });

export function createLeavePoliciesRouter(deps: AppDependencies): Router {
  const router = Router();

  router.use((_req, res, next) => {
    if (!features.leaveAccrualsEnabled) {
      res.status(503).json({
        error: 'Leave accruals are disabled',
        code: 'SERVICE_UNAVAILABLE',
      });
      return;
    }
    next();
  });

  router.post(
    '/',
    validateBody(createSchema),
    asyncHandler(async (req, res) => {
      const body = req.body as z.infer<typeof createSchema>;
      const policy = await deps.leavePolicyService.create({
        companyId: req.auth.companyId,
        code: body.code,
        name: body.name,
        leaveType: body.leaveType,
        accrualMethod: body.accrualMethod,
        accrualConfig: body.accrualConfig,
        carryoverMaxHours: body.carryoverMaxHours ?? null,
        effectiveFrom: body.effectiveFrom,
        effectiveTo: body.effectiveTo ?? null,
        isActive: body.isActive ?? true,
      });
      await deps.auditService.recordCreate(
        req.actor,
        'leave_policy',
        policy.id,
        toAuditSnapshot(policy)
      );
      res.status(201).json(policy);
    })
  );

  router.get(
    '/',
    asyncHandler(async (req, res) => {
      const policies = await deps.leavePolicyService.list(req.auth.companyId);
      res.json({ policies });
    })
  );

  router.get(
    '/:id',
    asyncHandler(async (req, res) => {
      const policy = await deps.leavePolicyService.get(
        req.params.id,
        req.auth.companyId
      );
      if (!policy) {
        throw PayrollDomainError.notFound('LeavePolicy', req.params.id);
      }
      res.json(policy);
    })
  );

  router.patch(
    '/:id',
    validateBody(updateSchema),
    asyncHandler(async (req, res) => {
      const before = await deps.leavePolicyService.get(
        req.params.id,
        req.auth.companyId
      );
      if (!before) {
        throw PayrollDomainError.notFound('LeavePolicy', req.params.id);
      }
      const policy = await deps.leavePolicyService.update(
        req.params.id,
        req.auth.companyId,
        req.body
      );
      await deps.auditService.recordUpdate(
        req.actor,
        'leave_policy',
        policy.id,
        toAuditSnapshot(before),
        toAuditSnapshot(policy)
      );
      res.json(policy);
    })
  );

  return router;
}
