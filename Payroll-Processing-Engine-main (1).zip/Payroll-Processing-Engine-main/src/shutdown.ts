import type { Server } from 'http';
import { rootLogger } from './logging/logger';

let shuttingDown = false;
const inFlight = new Set<Promise<unknown>>();

export function isShuttingDown(): boolean {
  return shuttingDown;
}

export function beginShutdown(): void {
  shuttingDown = true;
}

export function trackInFlight<T>(promise: Promise<T>): Promise<T> {
  inFlight.add(promise);
  return promise.finally(() => {
    inFlight.delete(promise);
  });
}

export async function drainInFlight(timeoutMs = 30_000): Promise<void> {
  if (inFlight.size === 0) return;
  const pending = [...inFlight];
  await Promise.race([
    Promise.allSettled(pending),
    new Promise<void>((resolve) => setTimeout(resolve, timeoutMs)),
  ]);
}

export function registerGracefulShutdown(
  server: Server,
  onClose: () => Promise<void>
): void {
  const shutdown = async (signal: string) => {
    if (shuttingDown) return;
    beginShutdown();
    rootLogger.info('shutdown.start', { signal, inFlight: inFlight.size });

    await new Promise<void>((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });

    await drainInFlight();
    await onClose();
    rootLogger.info('shutdown.complete', { signal });
    process.exit(0);
  };

  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));
}
