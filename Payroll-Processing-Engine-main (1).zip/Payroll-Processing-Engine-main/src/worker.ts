import { rootLogger } from './logging/logger';
import { initPrometheusMetrics } from './metrics/prometheus';
import { closeDb } from './config/database';
import { features } from './config/features';

const workerId =
  process.env.WORKER_ID?.trim() ||
  `worker-${process.pid}-${Math.random().toString(36).slice(2, 8)}`;

export async function startWorker(): Promise<void> {
  if (!features.jobQueueEnabled) {
    rootLogger.warn('worker.disabled', { reason: 'FEATURE_JOB_QUEUE=false' });
    process.exit(0);
  }

  initPrometheusMetrics();
  const { getAppDependencies } = await import('./deps');
  const deps = await getAppDependencies();

  const pollMs = Number(process.env.WORKER_POLL_MS ?? 250);
  rootLogger.info('worker.start', { workerId, pollMs });

  let running = true;
  const shutdown = () => {
    running = false;
  };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);

  while (running) {
    const processed = await deps.jobWorkerService.runLoop(workerId, {
      maxIterations: 10,
      idleMs: 0,
    });
    if (processed === 0) {
      await new Promise((r) => setTimeout(r, pollMs));
    }
  }

  await closeDb();
  rootLogger.info('worker.stop', { workerId });
}

if (require.main === module) {
  void startWorker();
}
