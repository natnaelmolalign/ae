export interface AuditEvent {
  id: string;
  entityType: string;
  entityId: string;
  action: string;
  actor: string;
  beforeSnapshot: Record<string, unknown> | null;
  afterSnapshot: Record<string, unknown> | null;
  payload: Record<string, unknown> | null;
  createdAt: string;
}

export interface CreateAuditEventInput {
  entityType: string;
  entityId: string;
  action: string;
  actor: string;
  beforeSnapshot?: Record<string, unknown> | null;
  afterSnapshot?: Record<string, unknown> | null;
}
