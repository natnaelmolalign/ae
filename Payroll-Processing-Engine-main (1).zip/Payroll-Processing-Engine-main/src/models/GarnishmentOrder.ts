import type { GarnishmentEnrollment } from './types';

export type GarnishmentOrderType =
  | 'child_support'
  | 'creditor'
  | 'student_loan';

/** Persisted garnishment order with effective dating and case tracking */
export interface GarnishmentOrder {
  id: string;
  employeeId: string;
  type: GarnishmentOrderType;
  caseId: string;
  priority: number;
  fixedAmount: string;
  maxPercentOfDisposable: string | null;
  effectiveDate: string;
  endDate: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreateGarnishmentOrderInput {
  employeeId: string;
  type: GarnishmentOrderType;
  caseId: string;
  priority?: number;
  fixedAmount: string;
  maxPercentOfDisposable?: string | null;
  effectiveDate: string;
  endDate?: string | null;
}

export interface UpdateGarnishmentOrderInput {
  priority?: number;
  fixedAmount?: string;
  maxPercentOfDisposable?: string | null;
  effectiveDate?: string;
  endDate?: string | null;
}

export interface GarnishmentRemittance {
  id: string;
  payrollRunId: string;
  garnishmentOrderId: string;
  caseId: string;
  orderType: GarnishmentOrderType;
  amount: string;
  createdAt: string;
}

export function garnishmentOrderToEnrollment(
  order: GarnishmentOrder
): GarnishmentEnrollment {
  return {
    type: order.type,
    fixedAmount: order.fixedAmount,
    percentOfDisposable: order.maxPercentOfDisposable ?? undefined,
    priority: order.priority,
  };
}

export function garnishmentOrderToAllocation(order: GarnishmentOrder): {
  orderId: string;
  caseId: string;
  type: GarnishmentOrderType;
  priority: number;
  fixedAmount: string;
  percentOfDisposable: string | null;
} {
  return {
    orderId: order.id,
    caseId: order.caseId,
    type: order.type,
    priority: order.priority,
    fixedAmount: order.fixedAmount,
    percentOfDisposable: order.maxPercentOfDisposable,
  };
}
