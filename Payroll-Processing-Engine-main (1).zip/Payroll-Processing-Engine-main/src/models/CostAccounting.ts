export interface Department {
  id: string;
  companyId: string;
  code: string;
  name: string;
  locationCode: string | null;
  isSystem: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Job {
  id: string;
  companyId: string;
  departmentId: string;
  code: string;
  name: string;
  createdAt: string;
  updatedAt: string;
}

export interface CostAllocationInput {
  departmentId: string;
  jobId?: string | null;
  percent: string;
  hours?: string | null;
}

export interface PayrollRunAllocation {
  id: string;
  payrollRunId: string;
  departmentId: string;
  jobId: string | null;
  allocationPercent: string;
  allocationHours: string | null;
  createdAt: string;
  updatedAt: string;
}

/** Resolved segment for GL/register output */
export interface CostAllocationSegment {
  departmentId: string;
  departmentCode: string;
  departmentName: string;
  locationCode: string | null;
  jobId: string | null;
  jobCode: string | null;
  percent: string;
}
