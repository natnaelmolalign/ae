export type PayrollHoldStatus = 'active' | 'released';

export interface PayrollHold {
  id: string;
  companyId: string;
  employeeId: string;
  reasonCode: string;
  notes: string | null;
  status: PayrollHoldStatus;
  createdBy: string;
  releasedBy: string | null;
  releasedAt: string | null;
  releaseReason: string | null;
  createdAt: string;
  updatedAt: string;
}

export type ApprovalRequestStatus = 'pending' | 'approved' | 'rejected';

export interface ApprovalRequest {
  id: string;
  companyId: string;
  employeeId: string;
  payPeriodId: string;
  payrollRunId: string | null;
  requestedAmount: string;
  zScore: string;
  threshold: string;
  status: ApprovalRequestStatus;
  requestedBy: string;
  reviewedBy: string | null;
  reviewedAt: string | null;
  reviewNotes: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface AnomalyFlag {
  id: string;
  companyId: string;
  employeeId: string;
  payPeriodId: string;
  metric: string;
  amount: string;
  trailingAverage: string;
  zScore: string;
  threshold: string;
  createdAt: string;
}

export interface CreatePayrollHoldInput {
  companyId: string;
  employeeId: string;
  reasonCode: string;
  notes?: string | null;
  createdBy: string;
}
