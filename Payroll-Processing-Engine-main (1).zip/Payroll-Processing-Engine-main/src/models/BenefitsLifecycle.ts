import type { DeductionType, EmploymentType } from './types';

export type EnrollmentWindowStatus = 'open' | 'closed';

export type LifeEventType =
  | 'marriage'
  | 'birth'
  | 'adoption'
  | 'loss_of_coverage'
  | 'divorce'
  | 'other';

export type LifeEventStatus = 'pending' | 'approved' | 'rejected';

export interface EnrollmentWindow {
  id: string;
  companyId: string;
  code: string;
  name: string;
  planYear: number;
  startDate: string;
  endDate: string;
  status: EnrollmentWindowStatus;
  allowedBenefitTypes: DeductionType[];
  createdAt: string;
  updatedAt: string;
}

export interface CreateEnrollmentWindowInput {
  companyId: string;
  code: string;
  name: string;
  planYear: number;
  startDate: string;
  endDate: string;
  status?: EnrollmentWindowStatus;
  allowedBenefitTypes: DeductionType[];
}

export interface EligibilityRule {
  id: string;
  companyId: string;
  benefitType: DeductionType;
  employmentTypes: EmploymentType[] | null;
  minTenureDays: number | null;
  requiresEnrollmentWindow: boolean;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateEligibilityRuleInput {
  companyId: string;
  benefitType: DeductionType;
  employmentTypes?: EmploymentType[] | null;
  minTenureDays?: number | null;
  requiresEnrollmentWindow?: boolean;
  isActive?: boolean;
}

export interface LifeEvent {
  id: string;
  companyId: string;
  employeeId: string;
  eventType: LifeEventType;
  eventDate: string;
  coverageEffectiveDate: string;
  status: LifeEventStatus;
  approvedAt: string | null;
  approvedBy: string | null;
  cobraScheduleId: string | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreateLifeEventInput {
  companyId: string;
  employeeId: string;
  eventType: LifeEventType;
  eventDate: string;
  coverageEffectiveDate: string;
  notes?: string | null;
}

export interface ApproveLifeEventInput {
  approvedBy: string;
  cobraPremiumPerPeriod?: string;
  cobraStartDate?: string;
}

export const enrollableBenefitTypes = [
  'section_125',
  'hsa',
  'fsa',
  '401k_pretax',
  '401k_roth',
  'life_insurance',
  'charitable',
] as const satisfies readonly DeductionType[];
