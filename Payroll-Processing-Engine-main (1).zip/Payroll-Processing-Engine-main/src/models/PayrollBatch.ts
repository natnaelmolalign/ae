export type PayrollBatchStatus = 'pending' | 'running' | 'completed' | 'failed';

export type EmployeePayrollReadinessStatus = 'ready' | 'processed';

export interface PayrollBatch {
  id: string;
  companyId: string;
  payPeriodId: string;
  year: number;
  frequency: string;
  status: PayrollBatchStatus;
  startedAt: string | null;
  completedAt: string | null;
  successCount: number;
  failureCount: number;
  totalCount: number;
  durationMs: number | null;
  createdAt: string;
  updatedAt: string;
}

export interface PayrollRunFailure {
  id: string;
  batchId: string | null;
  employeeId: string;
  payPeriodId: string;
  idempotencyKey: string | null;
  errorCode: string;
  errorMessage: string;
  payload: Record<string, unknown> | null;
  retryable: boolean;
  createdAt: string;
}

export interface EmployeePayrollReadiness {
  employeeId: string;
  payPeriodId: string;
  status: EmployeePayrollReadinessStatus;
  createdAt: string;
  updatedAt: string;
}
