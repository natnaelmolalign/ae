import type { Employee, FilingStatus } from './types';
import type { Money } from '../utils/decimalUtils';

/**
 * W-4 (2020+) inputs used for federal withholding (Publication 15-T).
 */
export interface W4Params {
  filingStatus: FilingStatus;
  extraWithholdingPerPeriod: Money;
  /** Step 3 — total annual tax credit from dependents/other credits */
  dependentsCreditAnnual: Money;
  /** Step 4(b) — additional annual deductions beyond standard deduction */
  otherDeductionsAnnual: Money;
  /** Step 4(a) — other income annualized adjustment (increases withholding) */
  otherIncomeAnnual: Money;
  /** Step 2 — multiple jobs / spouse works (simplified higher withholding) */
  multipleJobs: boolean;
}

export function w4ParamsFromEmployee(employee: Employee): W4Params {
  return {
    filingStatus: employee.filingStatus,
    extraWithholdingPerPeriod: employee.w4ExtraWithholding,
    dependentsCreditAnnual: employee.w4DependentsCredit,
    otherDeductionsAnnual: employee.w4OtherDeductions ?? '0.00',
    otherIncomeAnnual: employee.w4OtherIncome ?? '0.00',
    multipleJobs: employee.w4MultipleJobs ?? false,
  };
}
