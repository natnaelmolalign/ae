export type DisbursementSplitType = 'percent' | 'fixed' | 'remainder';

export type DisbursementAccountType = 'checking' | 'savings';

export type PaymentBatchStatus =
  | 'draft'
  | 'submitted'
  | 'failed'
  | 'reconciled';

export type PaymentBatchItemStatus = 'pending' | 'submitted' | 'failed';

export type NachaProfile = 'PPD' | 'CCD';

export interface DisbursementInstruction {
  id: string;
  companyId: string;
  employeeId: string;
  splitType: DisbursementSplitType;
  percent: string | null;
  fixedAmount: string | null;
  priority: number;
  routingNumber: string;
  accountNumberToken: string;
  accountLastFour: string;
  accountType: DisbursementAccountType;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateDisbursementInstructionInput {
  companyId: string;
  employeeId: string;
  splitType: DisbursementSplitType;
  percent?: string | null;
  fixedAmount?: string | null;
  priority?: number;
  routingNumber: string;
  accountNumber: string;
  accountType?: DisbursementAccountType;
  isActive?: boolean;
}

export interface UpdateDisbursementInstructionInput {
  splitType?: DisbursementSplitType;
  percent?: string | null;
  fixedAmount?: string | null;
  priority?: number;
  routingNumber?: string;
  accountNumber?: string;
  accountType?: DisbursementAccountType;
  isActive?: boolean;
}

export interface PaymentBatch {
  id: string;
  companyId: string;
  payPeriodId: string | null;
  status: PaymentBatchStatus;
  nachaProfile: NachaProfile;
  totalNetPay: string;
  totalAchCredit: string;
  payrollRunCount: number;
  idempotencyKey: string | null;
  submittedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentBatchItem {
  id: string;
  paymentBatchId: string;
  payrollRunId: string;
  payStubId: string;
  employeeId: string;
  disbursementInstructionId: string | null;
  amount: string;
  status: PaymentBatchItemStatus;
  accountNumberToken: string;
  routingNumber: string;
  accountLastFour: string;
  createdAt: string;
  updatedAt: string;
}

export interface AchFile {
  id: string;
  paymentBatchId: string;
  fileFormat: 'nacha';
  nachaProfile: NachaProfile;
  fileContent: string;
  entryHashTotal: string;
  controlTotal: string;
  entryCount: number;
  createdAt: string;
}

export interface PaymentReconciliationReport {
  paymentBatchId: string;
  totalNetPay: string;
  totalAchCredit: string;
  payrollLiabilityTotal: string;
  balanced: boolean;
  entryCount: number;
  entryHashTotal: string;
  controlTotal: string;
}
