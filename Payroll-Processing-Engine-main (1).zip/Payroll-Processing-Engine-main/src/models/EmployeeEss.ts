import type { FilingStatus } from './types';

export type W4ChangeRequestStatus =
  | 'draft'
  | 'pending'
  | 'approved'
  | 'rejected'
  | 'applied';

export interface W4ChangeRequest {
  id: string;
  companyId: string;
  employeeId: string;
  status: W4ChangeRequestStatus;
  filingStatus: FilingStatus;
  w4ExtraWithholding: string;
  w4DependentsCredit: string;
  w4OtherDeductions: string;
  w4OtherIncome: string;
  w4MultipleJobs: boolean;
  submittedAt: string | null;
  reviewedAt: string | null;
  reviewedBy: string | null;
  appliedAt: string | null;
  reviewNotes: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreateW4ChangeRequestInput {
  companyId: string;
  employeeId: string;
  filingStatus: FilingStatus;
  w4ExtraWithholding?: string;
  w4DependentsCredit?: string;
  w4OtherDeductions?: string;
  w4OtherIncome?: string;
  w4MultipleJobs?: boolean;
}

export interface EssEmployeeProfile {
  id: string;
  firstName: string;
  lastName: string;
  employmentType: string;
  payFrequency: string;
  filingStatus: FilingStatus;
  stateCode: string;
  w4ExtraWithholding: string;
  w4DependentsCredit: string;
  w4OtherDeductions: string;
  w4OtherIncome: string;
  w4MultipleJobs: boolean;
}
