export type EmploymentType =
  | 'full_time_salaried'
  | 'full_time_hourly'
  | 'part_time'
  | 'contractor';

export type PayFrequency = 'weekly' | 'biweekly' | 'semimonthly' | 'monthly';

export type FilingStatus =
  | 'single'
  | 'married_filing_jointly'
  | 'married_filing_separately'
  | 'head_of_household';

export type EarningsType =
  | 'regular'
  | 'overtime'
  | 'holiday'
  | 'bonus'
  | 'commission'
  | 'severance'
  | 'expense_reimbursement'
  | 'cash_tips'
  | 'charged_tips'
  | 'allocated_tips'
  | 'tip_credit_makeup'
  | 'rsu_vest'
  | 'nqso_exercise'
  | 'pto'
  | 'sick';

export type EquityWithholdingMethod = 'supplemental_flat' | 'w4_annualized';

export type DeductionType =
  | 'section_125'
  | 'hsa'
  | 'fsa'
  | '401k_pretax'
  | '401k_roth'
  | 'life_insurance'
  | 'charitable'
  | 'garnishment_child_support'
  | 'garnishment_creditor';

export interface CreateEmployeeInput {
  companyId?: string;
  firstName: string;
  lastName: string;
  employmentType: EmploymentType;
  payFrequency: PayFrequency;
  baseCompensation: string;
  hireDate: string;
  terminationDate?: string | null;
  filingStatus: FilingStatus;
  stateCode: string;
  w4ExtraWithholding?: string;
  w4DependentsCredit?: string;
  w4OtherDeductions?: string;
  w4OtherIncome?: string;
  w4MultipleJobs?: boolean;
  localMunicipalityCode?: string | null;
  /** Advanced Phase 4: federal withholding on equity supplemental pay */
  equityWithholdingMethod?: EquityWithholdingMethod;
  /** SSN or EIN (9 digits); stored encrypted at rest (Advanced Phase 10) */
  tin?: string;
}

export interface Employee {
  id: string;
  companyId: string;
  firstName: string;
  lastName: string;
  employmentType: EmploymentType;
  payFrequency: PayFrequency;
  baseCompensation: string;
  hireDate: string;
  terminationDate: string | null;
  filingStatus: FilingStatus;
  stateCode: string;
  w4ExtraWithholding: string;
  w4DependentsCredit: string;
  w4OtherDeductions: string;
  w4OtherIncome: string;
  w4MultipleJobs: boolean;
  localMunicipalityCode: string | null;
  equityWithholdingMethod: EquityWithholdingMethod;
  /** Last four of TIN when stored; never the full number in API responses */
  tinLastFour: string | null;
  createdAt: string;
}

export interface PayPeriod {
  id: string;
  /** Set when persisted or when scoped to a tenant in API routes */
  companyId?: string;
  startDate: string;
  endDate: string;
  paymentDate: string;
  frequency: PayFrequency;
  year: number;
  periodIndex: number;
}

export type TimeEntryType =
  | 'regular'
  | 'holiday'
  | 'overtime_manual'
  | 'pto'
  | 'sick';

export interface TimeEntry {
  id: string;
  employeeId: string;
  payPeriodId: string | null;
  shiftAssignmentId: string | null;
  workDate: string;
  clockIn: string;
  clockOut: string;
  roundedMinutes: number;
  entryType: TimeEntryType;
  createdAt: string;
}

export interface CreateTimeEntryInput {
  employeeId: string;
  payPeriodId?: string | null;
  shiftAssignmentId?: string | null;
  workDate: string;
  clockIn: string;
  clockOut: string;
  entryType?: TimeEntryType;
}

export interface ImputedIncomeInput {
  type: 'group_life';
  coverageAmount: string;
  employerPaidPremium: string;
}

export interface EarningsLine {
  type: EarningsType;
  amount: string;
  hours?: number;
}

export interface EarningsPreviewInput {
  employeeId: string;
  payPeriodId: string;
  year: number;
  frequency: PayFrequency;
  earnings?: EarningsLine[];
  useTimeEntries?: boolean;
  hourlyRate?: string;
  imputedIncome?: ImputedIncomeInput[];
  deductions?: DeductionEnrollment[];
  garnishments?: GarnishmentEnrollment[];
}

export interface DeductionEnrollment {
  type: DeductionType;
  amountPerPeriod: string;
  percentOfGross?: string;
  annualLimit?: string;
  priority?: number;
  /** Age 50+ §402(g) catch-up (401k pre-tax / Roth) */
  catchUpEligible?: boolean;
  /** Required for HSA limit selection */
  hsaCoverage?: 'individual' | 'family';
}

export interface GarnishmentEnrollment {
  type: 'child_support' | 'creditor' | 'student_loan';
  fixedAmount: string;
  percentOfDisposable?: string;
  priority: number;
}

export interface YearToDate {
  employeeId: string;
  taxYear: number;
  grossEarnings: string;
  federalTaxableWages: string;
  stateTaxableWages: string;
  ssTaxableWages: string;
  medicareTaxableWages: string;
  federalTaxWithheld: string;
  stateTaxWithheld: string;
  ssTaxWithheld: string;
  medicareTaxWithheld: string;
  medicareAdditionalWithheld: string;
  pretax401k: string;
  roth401k: string;
  hsa: string;
  fsa: string;
  section125: string;
  /** Advanced Phase 4: supplemental wages (bonus, equity, severance, etc.) */
  supplementalTaxableWages: string;
}

export interface TaxWithholdingResult {
  federalIncome: string;
  stateIncome: string;
  localIncome: string;
  socialSecurity: string;
  medicare: string;
  medicareAdditional: string;
}

export interface PayStubLine {
  category: string;
  label: string;
  current: string;
  ytd: string;
}

export interface PayStub {
  id: string;
  employeeId: string;
  payPeriodId: string;
  grossPay: string;
  netPay: string;
  lines: PayStubLine[];
  isCorrection: boolean;
  correctsPayStubId?: string | null;
  negativeNetRecovery?: boolean;
  createdAt: string;
}

export interface RetroAdjustment {
  id: string;
  employeeId: string;
  effectiveDate: string;
  reason: string;
  earningsDelta: EarningsLine[];
  appliedInPayPeriodId: string;
}

export interface PayrollRunInput {
  employeeId: string;
  payPeriodId: string;
  earnings: EarningsLine[];
  deductions: DeductionEnrollment[];
  garnishments: GarnishmentEnrollment[];
  /** Load active orders from DB for payment date */
  useActiveGarnishmentOrders?: boolean;
  employerMatch401kPercent?: number;
  /** When set, employer match uses IRS safe harbor basic formula instead of flat percent */
  safeHarborMatch?: boolean;
  /** Advanced Phase 2: work-state wage allocation (percents must sum to 100) */
  stateAllocations?: { stateCode: string; percent: string }[];
  /** Advanced Phase 3: FLSA tip credit (hourly employees only) */
  tipCredit?: {
    hours: number;
    directCashWages: string;
    minimumWage?: string;
    tippedCashWageRate?: string;
  };
  /** Advanced Phase 5: load active deduction_schedules for payment date */
  useActiveDeductionSchedules?: boolean;
  /** Advanced Phase 8: labor cost dimensions (percents must sum to 100) */
  useTimeEntries?: boolean;
  hourlyRate?: string;
  costAllocations?: {
    departmentId: string;
    jobId?: string | null;
    percent: string;
    hours?: string | null;
  }[];
}

export interface PayrollRunResult {
  payStub: PayStub;
  taxes: TaxWithholdingResult;
  employerContributions: {
    ss: string;
    medicare: string;
    match401k: string;
    /** Employer FLSA minimum wage make-up wages (paid to employee; also in gross). */
    flsaTipCreditMakeup?: string;
  };
  tipSummary?: {
    cashTips: string;
    chargedTips: string;
    allocatedTips: string;
    totalTips: string;
    tipCreditMakeup: string;
  };
  equitySummary?: {
    rsuVest: string;
    nqsoExercise: string;
    totalEquity: string;
    withholdingMethod: EquityWithholdingMethod;
  };
  scheduledDeductions?: {
    cobraPremium: string;
    arrearsRecovery: string;
    total: string;
    lines: { scheduleId: string; label: string; amount: string }[];
  };
  garnishmentRemittances?: {
    garnishmentOrderId: string;
    caseId: string;
    orderType: string;
    amount: string;
  }[];
}
