export type ConnectorType = 'netsuite' | 'quickbooks' | 'sap';

export interface IntegrationConnection {
  id: string;
  companyId: string;
  connectorType: ConnectorType;
  name: string;
  config: Record<string, unknown> | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateIntegrationConnectionInput {
  companyId: string;
  connectorType: ConnectorType;
  name: string;
  config?: Record<string, unknown> | null;
  isActive?: boolean;
}

export interface GlAccountMapping {
  id: string;
  companyId: string;
  connectionId: string;
  version: number;
  internalAccountCode: string;
  externalAccountId: string;
  externalAccountName: string;
  createdAt: string;
  updatedAt: string;
}

export interface GlMappingEntry {
  internalAccountCode: string;
  externalAccountId: string;
  externalAccountName: string;
}

export interface PublishGlMappingsInput {
  companyId: string;
  connectionId: string;
  mappings: GlMappingEntry[];
}

export type ExportBatchStatus = 'submitted' | 'failed';

export interface ExportBatch {
  id: string;
  companyId: string;
  connectionId: string;
  payPeriodId: string;
  connectorType: ConnectorType;
  status: ExportBatchStatus;
  idempotencyKey: string;
  mappingVersion: number;
  mappingSnapshot: GlMappingEntry[];
  connectorPayload: ConnectorJournalPayload;
  externalJournalIds: string[];
  submittedAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface ConnectorJournalLine {
  lineKey: string;
  payPeriodId: string;
  payrollRunId: string;
  employeeId: string;
  internalAccountCode: string;
  externalAccountId: string;
  externalAccountName: string;
  debit: string;
  credit: string;
  memo: string;
  departmentCode?: string;
  jobCode?: string | null;
  locationCode?: string | null;
}

export interface ConnectorJournalPayload {
  connectorType: ConnectorType;
  payPeriodId: string;
  lines: ConnectorJournalLine[];
  totalDebits: string;
  totalCredits: string;
}

export interface CreateErpExportInput {
  companyId: string;
  connectionId: string;
  payPeriodId: string;
  idempotencyKey: string;
}

export const connectorTypes: ConnectorType[] = [
  'netsuite',
  'quickbooks',
  'sap',
];
