import type { WebhookEventType } from '../config/webhooks';

export interface WebhookSubscription {
  id: string;
  companyId: string;
  url: string;
  secret: string;
  events: WebhookEventType[];
  enabled: boolean;
  consecutiveFailures: number;
  disabledAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreateWebhookSubscriptionInput {
  companyId?: string;
  url: string;
  secret: string;
  events: WebhookEventType[];
  enabled?: boolean;
}

export interface UpdateWebhookSubscriptionInput {
  url?: string;
  secret?: string;
  events?: WebhookEventType[];
  enabled?: boolean;
}

export type WebhookOutboxStatus = 'pending' | 'delivered' | 'failed';

export interface WebhookOutboxEntry {
  id: string;
  subscriptionId: string;
  companyId: string;
  eventType: WebhookEventType;
  payload: Record<string, unknown>;
  status: WebhookOutboxStatus;
  attempts: number;
  nextAttemptAt: string | null;
  deliveredAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface WebhookDelivery {
  id: string;
  outboxId: string;
  attemptNumber: number;
  httpStatus: number | null;
  errorMessage: string | null;
  createdAt: string;
}
