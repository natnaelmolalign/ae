export type DeductionScheduleType = 'cobra_premium' | 'arrears';

export interface DeductionSchedule {
  id: string;
  companyId: string;
  employeeId: string;
  scheduleType: DeductionScheduleType;
  amountPerPeriod: string;
  remainingBalance: string | null;
  priority: number;
  startDate: string;
  endDate: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreateDeductionScheduleInput {
  employeeId: string;
  companyId?: string;
  scheduleType: DeductionScheduleType;
  amountPerPeriod: string;
  remainingBalance?: string | null;
  priority?: number;
  startDate: string;
  endDate?: string | null;
}

export interface UpdateDeductionScheduleInput {
  amountPerPeriod?: string;
  remainingBalance?: string | null;
  priority?: number;
  startDate?: string;
  endDate?: string | null;
}
