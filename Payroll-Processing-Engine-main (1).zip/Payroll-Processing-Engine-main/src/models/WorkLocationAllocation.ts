export interface StateAllocationInput {
  stateCode: string;
  /** Whole-number percent (e.g. `60` = 60% of state-taxable wages). */
  percent: string;
}

export interface EmployeeWorkLocation {
  id: string;
  employeeId: string;
  stateCode: string;
  allocationPercent: string;
  effectiveDate: string;
  endDate: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreateWorkLocationInput {
  stateCode: string;
  allocationPercent: string;
  effectiveDate: string;
  endDate?: string | null;
}

export interface PayrollRunStateAllocationSnapshot {
  stateCode: string;
  allocationPercent: string;
  allocatedWages: string;
  stateTaxWithheld: string;
}
