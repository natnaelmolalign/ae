import type { DeductionEnrollment, DeductionType } from './types';

export type HsaCoverage = 'individual' | 'family';

/** Persisted benefit/deduction enrollment with effective dating */
export interface BenefitEnrollment {
  id: string;
  employeeId: string;
  type: DeductionType;
  amountPerPeriod: string;
  percentOfGross: string | null;
  annualLimit: string | null;
  effectiveDate: string;
  endDate: string | null;
  hsaCoverage: HsaCoverage | null;
  catchUpEligible: boolean;
  priority: number;
  lifeEventId: string | null;
  enrollmentWindowId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreateBenefitEnrollmentInput {
  employeeId: string;
  type: DeductionType;
  amountPerPeriod: string;
  percentOfGross?: string | null;
  annualLimit?: string | null;
  effectiveDate: string;
  endDate?: string | null;
  hsaCoverage?: HsaCoverage | null;
  catchUpEligible?: boolean;
  priority?: number;
  lifeEventId?: string | null;
  enrollmentWindowId?: string | null;
}

export interface UpdateBenefitEnrollmentInput {
  amountPerPeriod?: string;
  percentOfGross?: string | null;
  annualLimit?: string | null;
  effectiveDate?: string;
  endDate?: string | null;
  hsaCoverage?: HsaCoverage | null;
  catchUpEligible?: boolean;
  priority?: number;
}

export function benefitEnrollmentToDeduction(
  enrollment: BenefitEnrollment
): DeductionEnrollment {
  return {
    type: enrollment.type,
    amountPerPeriod: enrollment.amountPerPeriod,
    percentOfGross: enrollment.percentOfGross ?? undefined,
    annualLimit: enrollment.annualLimit ?? undefined,
    priority: enrollment.priority,
    catchUpEligible: enrollment.catchUpEligible,
    hsaCoverage: enrollment.hsaCoverage ?? undefined,
  };
}
