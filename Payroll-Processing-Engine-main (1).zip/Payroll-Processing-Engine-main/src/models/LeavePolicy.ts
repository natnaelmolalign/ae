import { z } from 'zod';

export const leaveTypes = ['pto', 'sick'] as const;
export type LeaveType = (typeof leaveTypes)[number];

export const accrualMethods = ['fixed_per_period', 'tenure_bands'] as const;
export type AccrualMethod = (typeof accrualMethods)[number];

export const tenureBandSchema = z.object({
  minTenureMonths: z.number().int().min(0),
  hoursPerPeriod: z.string().min(1),
});

export const fixedAccrualConfigSchema = z.object({
  hoursPerPeriod: z.string().min(1),
});

export const tenureBandsAccrualConfigSchema = z.object({
  bands: z.array(tenureBandSchema).min(1),
});

export const leaveTransactionTypes = [
  'accrual',
  'usage',
  'adjustment',
  'carryover',
  'forfeit',
] as const;
export type LeaveTransactionType = (typeof leaveTransactionTypes)[number];

export interface LeavePolicy {
  id: string;
  companyId: string;
  code: string;
  name: string;
  leaveType: LeaveType;
  accrualMethod: AccrualMethod;
  accrualConfig: FixedAccrualConfig | TenureBandsAccrualConfig;
  carryoverMaxHours: string | null;
  effectiveFrom: string;
  effectiveTo: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export type FixedAccrualConfig = z.infer<typeof fixedAccrualConfigSchema>;
export type TenureBandsAccrualConfig = z.infer<
  typeof tenureBandsAccrualConfigSchema
>;

export interface LeaveBalance {
  id: string;
  companyId: string;
  employeeId: string;
  leaveType: LeaveType;
  policyId: string;
  calendarYear: number;
  balanceHours: string;
  createdAt: string;
  updatedAt: string;
}

export interface LeaveTransaction {
  id: string;
  companyId: string;
  employeeId: string;
  leaveType: LeaveType;
  policyId: string;
  calendarYear: number;
  transactionType: LeaveTransactionType;
  hours: string;
  balanceAfter: string;
  payPeriodId: string | null;
  payrollRunId: string | null;
  notes: string | null;
  actor: string | null;
  createdAt: string;
}

export function parseAccrualConfig(
  method: AccrualMethod,
  raw: unknown
): FixedAccrualConfig | TenureBandsAccrualConfig {
  if (method === 'fixed_per_period') {
    return fixedAccrualConfigSchema.parse(raw);
  }
  return tenureBandsAccrualConfigSchema.parse(raw);
}
