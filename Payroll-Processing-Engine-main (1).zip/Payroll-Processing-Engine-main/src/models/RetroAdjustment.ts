import type { EarningsLine } from './types';

export type RetroAdjustmentStatus =
  | 'draft'
  | 'previewed'
  | 'approved'
  | 'applied';

export interface PeriodPayrollDelta {
  payPeriodId: string;
  paymentDate: string;
  originalPayStubId: string | null;
  originalGross: string;
  originalNet: string;
  recomputedGross: string;
  recomputedNet: string;
  grossDelta: string;
  netDelta: string;
}

export interface RetroAdjustmentPreview {
  affectedPeriodIds: string[];
  periodDeltas: PeriodPayrollDelta[];
  totalNetCatchUp: string;
  projectedYtdGross: string;
  negativeNetRecovery: boolean;
}

export interface RetroAdjustmentRecord {
  id: string;
  employeeId: string;
  status: RetroAdjustmentStatus;
  effectiveDate: string;
  currentPayPeriodId: string;
  reason: string;
  earningsPerPeriod: EarningsLine[];
  preview: RetroAdjustmentPreview | null;
  catchUpPayStubId: string | null;
  createdAt: string;
  updatedAt: string;
}

/** Correction stub posted on the current open period (aggregate catch-up). */
export interface CorrectionPayStubLink {
  payStubId: string;
  correctsPayStubIds: string[];
  netPay: string;
  negativeNetRecovery: boolean;
}
