import { z } from 'zod';

export const shiftAssignmentStatuses = [
  'pending',
  'approved',
  'exported_to_payroll',
  'rejected',
] as const;
export type ShiftAssignmentStatus = (typeof shiftAssignmentStatuses)[number];

export const timeExceptionTypes = [
  'missed_break',
  'late_clock_in',
  'unscheduled_overtime',
] as const;
export type TimeExceptionType = (typeof timeExceptionTypes)[number];

export interface Shift {
  id: string;
  companyId: string;
  workDate: string;
  startTime: string;
  endTime: string;
  breakMinutes: number;
  departmentId: string | null;
  locationCode: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface ShiftAssignment {
  id: string;
  companyId: string;
  shiftId: string;
  employeeId: string;
  status: ShiftAssignmentStatus;
  scheduledMinutes: number;
  approvedMinutes: number | null;
  approvedAt: string | null;
  approvedBy: string | null;
  payrollRunId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface TimeException {
  id: string;
  companyId: string;
  shiftAssignmentId: string;
  exceptionType: TimeExceptionType;
  notes: string;
  resolved: boolean;
  createdAt: string;
}

export const createShiftSchema = z.object({
  workDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  startTime: z.string().min(1),
  endTime: z.string().min(1),
  breakMinutes: z.number().int().min(0).optional(),
  departmentId: z.string().uuid().nullable().optional(),
  locationCode: z.string().max(32).nullable().optional(),
});

export const assignShiftSchema = z.object({
  employeeId: z.string().uuid(),
});
