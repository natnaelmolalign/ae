import { z } from 'zod';

export const payPolicyRuleTypes = [
  'min_gross',
  'max_gross',
  'min_hourly_rate',
  'require_positive_gross',
] as const;

export type PayPolicyRuleType = (typeof payPolicyRuleTypes)[number];

export const payPolicyRuleSchema = z.discriminatedUnion('type', [
  z.object({
    type: z.literal('min_gross'),
    params: z.object({ amount: z.string().min(1) }),
  }),
  z.object({
    type: z.literal('max_gross'),
    params: z.object({ amount: z.string().min(1) }),
  }),
  z.object({
    type: z.literal('min_hourly_rate'),
    params: z.object({ rate: z.string().min(1) }),
  }),
  z.object({
    type: z.literal('require_positive_gross'),
    params: z.object({}).optional().default({}),
  }),
]);

export const payPolicyRulesSchema = z.object({
  rules: z.array(payPolicyRuleSchema).min(1).max(32),
});

export type PayPolicyRule = z.infer<typeof payPolicyRuleSchema>;
export type PayPolicyRules = z.infer<typeof payPolicyRulesSchema>;

export type PayPolicyScope = 'company' | 'employee';

export interface PayPolicy {
  id: string;
  companyId: string;
  code: string;
  name: string;
  scope: PayPolicyScope;
  employeeId: string | null;
  priority: number;
  rules: PayPolicyRule[];
  effectiveFrom: string;
  effectiveTo: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PayPolicyRunContext {
  companyId: string;
  employeeId: string;
  employmentType: string;
  baseCompensation: string;
  paymentDate: string;
  grossEarnings: string;
}

export interface PayPolicyViolation {
  policyId: string;
  policyCode: string;
  ruleType: PayPolicyRuleType;
  message: string;
}
