export type QueueJobType = 'payroll_batch_employee' | 'webhook_delivery';

export type QueueJobStatus = 'pending' | 'processing' | 'completed' | 'failed';

export interface QueueJob {
  id: string;
  jobType: QueueJobType;
  partitionKey: string;
  payload: Record<string, unknown>;
  status: QueueJobStatus;
  attempts: number;
  maxAttempts: number;
  lastError: string | null;
  lockedBy: string | null;
  lockedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface QueueDeadLetter {
  id: string;
  originalJobId: string;
  jobType: QueueJobType;
  partitionKey: string;
  payload: Record<string, unknown>;
  attempts: number;
  lastError: string;
  failedAt: string;
}

export interface EnqueueJobInput {
  jobType: QueueJobType;
  partitionKey: string;
  payload: Record<string, unknown>;
  maxAttempts?: number;
}
