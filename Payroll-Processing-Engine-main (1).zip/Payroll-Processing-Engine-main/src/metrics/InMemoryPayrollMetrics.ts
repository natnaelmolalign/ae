import type { PayrollMetrics } from './hooks';

export interface BatchMetricSnapshot {
  durationMs: number;
  successCount: number;
  failureCount: number;
  labels: Record<string, string>;
}

export class InMemoryPayrollMetrics implements PayrollMetrics {
  readonly runDurations: number[] = [];
  readonly runErrors: string[] = [];
  lastBatch: BatchMetricSnapshot | null = null;

  recordPayrollRunDuration(ms: number, labels: Record<string, string>): void {
    this.runDurations.push(ms);
    void labels;
  }

  incrementPayrollRunErrors(code: string): void {
    this.runErrors.push(code);
  }

  recordBatchComplete(
    durationMs: number,
    successCount: number,
    failureCount: number,
    labels: Record<string, string>
  ): void {
    this.lastBatch = { durationMs, successCount, failureCount, labels };
  }

  reset(): void {
    this.runDurations.length = 0;
    this.runErrors.length = 0;
    this.lastBatch = null;
  }
}
