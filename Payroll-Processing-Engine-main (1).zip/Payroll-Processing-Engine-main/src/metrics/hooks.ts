/**
 * Metrics hooks (Phase 1 interface; Prometheus exporter in Phase 8).
 */
export interface PayrollMetrics {
  recordPayrollRunDuration(ms: number, labels: Record<string, string>): void;
  incrementPayrollRunErrors(code: string): void;
  recordBatchComplete?(
    durationMs: number,
    successCount: number,
    failureCount: number,
    labels: Record<string, string>
  ): void;
}

export const noopMetrics: PayrollMetrics = {
  recordPayrollRunDuration() {},
  incrementPayrollRunErrors() {},
};

let metrics: PayrollMetrics = noopMetrics;

export function setPayrollMetrics(impl: PayrollMetrics): void {
  metrics = impl;
}

export function getPayrollMetrics(): PayrollMetrics {
  return metrics;
}
