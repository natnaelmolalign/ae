import {
  Counter,
  Histogram,
  Registry,
  collectDefaultMetrics,
} from 'prom-client';
import { features } from '../config/features';
import type { PayrollMetrics } from './hooks';
import { setPayrollMetrics } from './hooks';

/** Low-cardinality labels only (no employee ids). */
export type RunMetricSource = 'api' | 'batch';
export type RunMetricStatus = 'success' | 'error';

const registry = new Registry();

collectDefaultMetrics({ register: registry, prefix: 'payroll_' });

export const payrollRunDurationMs = new Histogram({
  name: 'payroll_run_duration_ms',
  help: 'Payroll run wall time in milliseconds',
  labelNames: ['source', 'status'] as const,
  buckets: [50, 100, 250, 500, 1000, 2000, 5000, 10000],
  registers: [registry],
});

export const payrollRunErrorsTotal = new Counter({
  name: 'payroll_run_errors_total',
  help: 'Payroll run failures by domain error code',
  labelNames: ['code'] as const,
  registers: [registry],
});

export const payrollBatchDurationMs = new Histogram({
  name: 'payroll_batch_duration_ms',
  help: 'Batch payroll wall time in milliseconds',
  labelNames: ['status'] as const,
  buckets: [1000, 5000, 10000, 30000, 60000, 120000, 300000],
  registers: [registry],
});

export const payrollBatchSize = new Histogram({
  name: 'payroll_batch_size',
  help: 'Number of employees in a batch run',
  buckets: [1, 10, 50, 100, 250, 500, 1000],
  registers: [registry],
});

export const httpRequestDurationMs = new Histogram({
  name: 'http_request_duration_ms',
  help: 'HTTP request duration in milliseconds',
  labelNames: ['method', 'route', 'status_code'] as const,
  buckets: [5, 25, 50, 100, 250, 500, 1000, 2500, 5000],
  registers: [registry],
});

class PrometheusPayrollMetrics implements PayrollMetrics {
  recordPayrollRunDuration(ms: number, labels: Record<string, string>): void {
    const source = (labels.source as RunMetricSource) || 'api';
    const status = (labels.status as RunMetricStatus) || 'success';
    payrollRunDurationMs.observe({ source, status }, ms);
  }

  incrementPayrollRunErrors(code: string): void {
    payrollRunErrorsTotal.inc({ code });
  }

  recordBatchComplete(
    durationMs: number,
    successCount: number,
    failureCount: number,
    _labels: Record<string, string>
  ): void {
    const total = successCount + failureCount;
    payrollBatchSize.observe(total);
    const status =
      failureCount > 0 && successCount === 0 ? 'failed' : 'completed';
    payrollBatchDurationMs.observe({ status }, durationMs);
  }
}

let initialized = false;

export function initPrometheusMetrics(): void {
  if (initialized || !features.prometheusMetricsEnabled) {
    return;
  }
  setPayrollMetrics(new PrometheusPayrollMetrics());
  initialized = true;
}

export async function renderMetrics(): Promise<string> {
  return registry.metrics();
}

export function metricsContentType(): string {
  return registry.contentType;
}

export function recordHttpRequest(
  method: string,
  route: string,
  statusCode: number,
  durationMs: number
): void {
  if (!features.prometheusMetricsEnabled) {
    return;
  }
  const normalizedRoute = route.replace(
    /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi,
    ':id'
  );
  httpRequestDurationMs.observe(
    {
      method,
      route: normalizedRoute,
      status_code: String(statusCode),
    },
    durationMs
  );
}

export const queueDlqTotal = new Counter({
  name: 'queue_dlq_total',
  help: 'Jobs moved to dead-letter queue',
  labelNames: ['job_type'] as const,
  registers: [registry],
});

export function incrementQueueDlqTotal(jobType: string): void {
  if (!features.prometheusMetricsEnabled) return;
  queueDlqTotal.inc({ job_type: jobType });
}
