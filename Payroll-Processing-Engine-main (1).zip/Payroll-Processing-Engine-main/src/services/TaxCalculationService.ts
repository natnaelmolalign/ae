import type {
  Employee,
  EarningsLine,
  TaxWithholdingResult,
  YearToDate,
} from '../models/types';
import type { StateAllocationInput } from '../models/WorkLocationAllocation';
import type { Money } from '../utils/decimalUtils';
import { FederalTaxService } from './FederalTaxService';
import { StateTaxService } from './StateTaxService';
import { EarningsService } from './EarningsService';
import { FicaTaxService } from './tax/FicaTaxService';
import { LocalTaxService } from './tax/LocalTaxService';
import { TaxYearService, defaultTaxYearService } from './tax/TaxYearService';
import { taxYearFromPaymentDate } from '../config/taxYear';
import { features } from '../config/features';
import { isContractor1099 } from '../utils/employmentClassification';
import { zeroContractorWithholding } from './contractor/ContractorTaxService';
import { EquityCompensationService } from './equity/EquityCompensationService';

export interface TaxCalculationOptions {
  paymentDate: string;
  regularFederalTaxable: Money;
  supplementalFederalTaxable: Money;
  stateAllocations?: StateAllocationInput[];
}

export class TaxCalculationService {
  constructor(
    private readonly taxYearService: TaxYearService = defaultTaxYearService,
    private readonly federal = new FederalTaxService(taxYearService),
    private readonly state = new StateTaxService(taxYearService),
    private readonly fica = new FicaTaxService(),
    private readonly local = new LocalTaxService(),
    private readonly earnings = new EarningsService(),
    private readonly equity = new EquityCompensationService()
  ) {}

  calculateFica(
    ssTaxableWages: Money,
    medicareTaxableWages: Money,
    ytd: YearToDate,
    paymentDate: string
  ): Pick<
    TaxWithholdingResult,
    'socialSecurity' | 'medicare' | 'medicareAdditional'
  > {
    const taxYear = taxYearFromPaymentDate(paymentDate);
    const tables = this.taxYearService.getYearTables(taxYear);
    return this.fica.calculate(
      tables.fica,
      ssTaxableWages,
      medicareTaxableWages,
      ytd
    );
  }

  calculateAll(
    employee: Employee,
    federalTaxable: Money,
    stateTaxable: Money,
    ssTaxable: Money,
    medicareTaxable: Money,
    earnings: EarningsLine[],
    ytd: YearToDate,
    options: TaxCalculationOptions
  ): TaxWithholdingResult {
    if (features.contractorPayrollEnabled && isContractor1099(employee)) {
      return zeroContractorWithholding();
    }

    let supplementalOnly = this.earnings.hasSupplementalOnly(earnings);
    let mixedSupplemental = this.earnings.hasMixedSupplemental(earnings);
    const withholdingFlags = this.equity.resolveWithholdingFlags(
      employee,
      earnings
    );
    if (withholdingFlags) {
      supplementalOnly = withholdingFlags.supplementalOnly;
      mixedSupplemental = withholdingFlags.mixedSupplemental;
    }

    const federalIncome = this.federal.calculate(
      employee,
      federalTaxable,
      earnings,
      supplementalOnly,
      mixedSupplemental,
      {
        paymentDate: options.paymentDate,
        regularFederalTaxable: options.regularFederalTaxable,
        supplementalFederalTaxable: options.supplementalFederalTaxable,
      }
    );
    const stateIncome = this.state.calculate(
      employee,
      stateTaxable,
      options.paymentDate,
      options.stateAllocations
    );
    const fica = this.calculateFica(
      ssTaxable,
      medicareTaxable,
      ytd,
      options.paymentDate
    );

    const taxYear = taxYearFromPaymentDate(options.paymentDate);
    const tables = this.taxYearService.getYearTables(taxYear);
    const localIncome = this.local.calculate(tables, employee, stateTaxable);

    return {
      federalIncome,
      stateIncome,
      localIncome,
      ...fica,
    };
  }

  stateTaxSlices(
    employee: Employee,
    stateTaxable: Money,
    paymentDate: string,
    stateAllocations: StateAllocationInput[]
  ) {
    return this.state.calculateWithSlices(
      employee,
      stateTaxable,
      paymentDate,
      stateAllocations
    );
  }
}
