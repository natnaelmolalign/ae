import type { TaxWithholdingResult } from '../../models/types';

/** Independent contractor (1099-NEC): no employee income tax or FICA withholding via payroll. */
export function zeroContractorWithholding(): TaxWithholdingResult {
  return {
    federalIncome: '0.00',
    stateIncome: '0.00',
    localIncome: '0.00',
    socialSecurity: '0.00',
    medicare: '0.00',
    medicareAdditional: '0.00',
  };
}
