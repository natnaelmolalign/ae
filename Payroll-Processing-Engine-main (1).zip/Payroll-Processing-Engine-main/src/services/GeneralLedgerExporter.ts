import type { PayrollRunResult } from '../models/types';
import type { CostAllocationSegment } from '../models/CostAccounting';
import {
  add,
  compare,
  div,
  isZero,
  mul,
  sub,
  sum,
  type Money,
} from '../utils/decimalUtils';

export interface GlLine {
  accountCode: string;
  accountName: string;
  debit: Money;
  credit: Money;
  memo: string;
  departmentCode?: string;
  jobCode?: string | null;
  locationCode?: string | null;
}

export interface GlExport {
  payPeriodId: string;
  payrollRunId: string;
  employeeId: string;
  lines: GlLine[];
  totalDebits: Money;
  totalCredits: Money;
  balanced: boolean;
}

const ACCOUNTS = {
  salaries: { code: '5100', name: 'Salaries Expense' },
  employerTax: { code: '5200', name: 'Employer Payroll Tax Expense' },
  employerMatch: { code: '5180', name: 'Employer 401(k) Match Expense' },
  federalWh: { code: '2100', name: 'Federal Withholding Payable' },
  stateWh: { code: '2110', name: 'State Withholding Payable' },
  localWh: { code: '2115', name: 'Local Withholding Payable' },
  ficaPayable: { code: '2120', name: 'FICA Payable' },
  medicarePayable: { code: '2130', name: 'Medicare Payable' },
  deductionsPayable: { code: '2140', name: 'Deductions Payable' },
  garnishmentPayable: { code: '2150', name: 'Garnishment Payable' },
  netPayPayable: { code: '2160', name: 'Net Pay Payable' },
} as const;

export class GeneralLedgerExporter {
  exportRun(
    payPeriodId: string,
    payrollRunId: string,
    result: PayrollRunResult,
    costSegments: CostAllocationSegment[] = []
  ): GlExport {
    const baseLines: Omit<
      GlLine,
      'departmentCode' | 'jobCode' | 'locationCode'
    >[] = [];
    const stub = result.payStub;
    const { taxes, employerContributions } = result;

    const addLine = (
      account: { code: string; name: string },
      debit: Money,
      credit: Money,
      memo: string
    ) => {
      if (isZero(debit) && isZero(credit)) return;
      baseLines.push({
        accountCode: account.code,
        accountName: account.name,
        debit,
        credit,
        memo,
      });
    };

    if (!isZero(stub.grossPay)) {
      addLine(ACCOUNTS.salaries, stub.grossPay, '0.00', 'Gross wages');
    }

    addLine(
      ACCOUNTS.federalWh,
      '0.00',
      taxes.federalIncome,
      'Federal income tax'
    );
    addLine(ACCOUNTS.stateWh, '0.00', taxes.stateIncome, 'State income tax');
    addLine(ACCOUNTS.localWh, '0.00', taxes.localIncome, 'Local income tax');

    addLine(
      ACCOUNTS.ficaPayable,
      '0.00',
      taxes.socialSecurity,
      'Employee Social Security'
    );
    addLine(
      ACCOUNTS.medicarePayable,
      '0.00',
      sum([taxes.medicare, taxes.medicareAdditional]),
      'Employee Medicare'
    );

    const employerFica = sum([
      employerContributions.ss,
      employerContributions.medicare,
    ]);
    if (!isZero(employerFica)) {
      addLine(
        ACCOUNTS.employerTax,
        employerFica,
        '0.00',
        'Employer FICA expense'
      );
      addLine(
        ACCOUNTS.ficaPayable,
        '0.00',
        employerContributions.ss,
        'Employer Social Security'
      );
      addLine(
        ACCOUNTS.medicarePayable,
        '0.00',
        employerContributions.medicare,
        'Employer Medicare'
      );
    }

    if (!isZero(employerContributions.match401k)) {
      addLine(
        ACCOUNTS.employerMatch,
        employerContributions.match401k,
        '0.00',
        'Employer 401(k) match'
      );
      addLine(
        ACCOUNTS.deductionsPayable,
        '0.00',
        employerContributions.match401k,
        '401(k) match payable'
      );
    }

    for (const line of stub.lines) {
      if (line.category === 'deduction' && parseFloat(line.current) > 0) {
        addLine(ACCOUNTS.deductionsPayable, '0.00', line.current, line.label);
      }
    }

    const garnishmentTotal =
      result.garnishmentRemittances?.reduce(
        (acc, r) => add(acc, r.amount),
        '0.00'
      ) ?? '0.00';
    if (!isZero(garnishmentTotal)) {
      addLine(
        ACCOUNTS.garnishmentPayable,
        '0.00',
        garnishmentTotal,
        'Garnishments'
      );
    }

    if (!isZero(stub.netPay)) {
      const netDebit =
        compare(stub.netPay, '0.00') < 0
          ? stub.netPay.replace('-', '')
          : '0.00';
      const netCredit = compare(stub.netPay, '0.00') > 0 ? stub.netPay : '0.00';
      addLine(ACCOUNTS.netPayPayable, netDebit, netCredit, 'Net pay');
    }

    if (isZero(stub.grossPay) && !isZero(stub.netPay)) {
      baseLines.length = 0;
      addLine(
        ACCOUNTS.netPayPayable,
        '0.00',
        stub.netPay,
        'Retro catch-up net pay'
      );
    }

    const lines = this.applyCostSegments(baseLines, costSegments);
    const totalDebits = lines.reduce((acc, l) => add(acc, l.debit), '0.00');
    const totalCredits = lines.reduce((acc, l) => add(acc, l.credit), '0.00');

    return {
      payPeriodId,
      payrollRunId,
      employeeId: stub.employeeId,
      lines,
      totalDebits,
      totalCredits,
      balanced: totalDebits === totalCredits,
    };
  }

  private applyCostSegments(
    baseLines: Omit<GlLine, 'departmentCode' | 'jobCode' | 'locationCode'>[],
    segments: CostAllocationSegment[]
  ): GlLine[] {
    if (segments.length === 0) {
      return baseLines.map((l) => ({ ...l }));
    }

    const out: GlLine[] = [];
    for (const line of baseLines) {
      const debits = this.splitByPercents(line.debit, segments);
      const credits = this.splitByPercents(line.credit, segments);
      segments.forEach((seg, i) => {
        out.push({
          ...line,
          debit: debits[i],
          credit: credits[i],
          memo: `${line.memo} (${seg.departmentCode}${seg.jobCode ? `/${seg.jobCode}` : ''})`,
          departmentCode: seg.departmentCode,
          jobCode: seg.jobCode,
          locationCode: seg.locationCode,
        });
      });
    }
    return out;
  }

  /** Split amount across segments; last segment absorbs rounding remainder. */
  private splitByPercents(
    amount: Money,
    segments: CostAllocationSegment[]
  ): Money[] {
    if (isZero(amount) || segments.length === 0) {
      return segments.map(() => '0.00');
    }
    const parts: Money[] = [];
    let allocated = '0.00';
    for (let i = 0; i < segments.length; i++) {
      if (i === segments.length - 1) {
        parts.push(sub(amount, allocated));
      } else {
        const part = mul(amount, div(segments[i].percent, '100'));
        parts.push(part);
        allocated = add(allocated, part);
      }
    }
    return parts;
  }

  toCsv(exports: GlExport[]): string {
    const header =
      'pay_period_id,payroll_run_id,employee_id,department_code,job_code,location_code,account_code,account_name,debit,credit,memo';
    const rows = exports.flatMap((e) =>
      e.lines.map(
        (l) =>
          `${e.payPeriodId},${e.payrollRunId},${e.employeeId},${l.departmentCode ?? ''},${l.jobCode ?? ''},${l.locationCode ?? ''},${l.accountCode},"${l.accountName}",${l.debit},${l.credit},"${l.memo}"`
      )
    );
    return [header, ...rows].join('\n');
  }
}
