import type { Employee } from '../models/types';
import type { PayStub } from '../models/types';

export class PayStubHtmlRenderer {
  render(stub: PayStub, employee: Employee, payPeriodLabel: string): string {
    const rows = stub.lines
      .map(
        (l) =>
          `<tr><td>${escapeHtml(l.label)}</td><td class="num">${l.current}</td><td class="num">${l.ytd}</td></tr>`
      )
      .join('');

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <title>Pay Stub — ${escapeHtml(employee.lastName)}, ${escapeHtml(employee.firstName)}</title>
  <style>
    body { font-family: system-ui, sans-serif; margin: 2rem; color: #111; }
    h1 { font-size: 1.25rem; margin-bottom: 0.25rem; }
    .meta { color: #444; margin-bottom: 1.5rem; }
    table { border-collapse: collapse; width: 100%; max-width: 32rem; }
    th, td { text-align: left; padding: 0.4rem 0.6rem; border-bottom: 1px solid #ddd; }
    th { font-weight: 600; background: #f6f6f6; }
    .num { text-align: right; font-variant-numeric: tabular-nums; }
    .net { font-weight: 700; }
    .correction { color: #b45309; }
  </style>
</head>
<body>
  <h1>Earnings Statement</h1>
  <p class="meta">
    ${escapeHtml(employee.firstName)} ${escapeHtml(employee.lastName)}<br/>
    Period: ${escapeHtml(payPeriodLabel)}<br/>
    ${stub.isCorrection ? '<span class="correction">Correction pay stub</span><br/>' : ''}
    Stub ID: ${escapeHtml(stub.id)}
  </p>
  <table>
    <thead><tr><th>Description</th><th class="num">Current</th><th class="num">YTD</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>
  <p class="net">Net pay: ${stub.netPay}</p>
</body>
</html>`;
  }
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
