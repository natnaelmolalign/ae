import { mul, type Money } from '../utils/decimalUtils';
import { minutesToHours } from '../utils/timeEntryUtils';

/**
 * Computes hourly pay with half-up rounding to cents.
 */
export class HourlyPayCalculator {
  payForMinutes(hourlyRate: Money, minutes: number, multiplier = '1.0'): Money {
    const hours = minutesToHours(minutes);
    const base = mul(hourlyRate, hours);
    return mul(base, multiplier);
  }

  payForHours(hourlyRate: Money, hours: string, multiplier = '1.0'): Money {
    const base = mul(hourlyRate, hours);
    return mul(base, multiplier);
  }
}
