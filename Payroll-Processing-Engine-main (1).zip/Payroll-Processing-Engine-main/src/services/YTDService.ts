import type { TaxWithholdingResult, YearToDate } from '../models/types';
import { emptyYtd, mergeYtdDelta } from '../utils/ytdUtils';
import { paymentYear } from '../utils/payPeriodUtils';

export class YTDService {
  getOrCreate(
    store: Map<string, YearToDate>,
    employeeId: string,
    paymentDate: string
  ): YearToDate {
    const taxYear = paymentYear(paymentDate);
    const key = `${employeeId}:${taxYear}`;
    if (!store.has(key)) {
      store.set(key, emptyYtd(employeeId, taxYear));
    }
    return store.get(key)!;
  }

  applyPayrollRun(
    ytd: YearToDate,
    gross: string,
    federalTaxable: string,
    stateTaxable: string,
    ssTaxable: string,
    medicareTaxable: string,
    taxes: TaxWithholdingResult,
    pretax401k: string,
    roth401k: string,
    hsa: string,
    fsa: string,
    section125: string,
    supplementalTaxableWages: string,
    isCorrection: boolean,
    correctionOriginalGross: string
  ): YearToDate {
    return mergeYtdDelta(
      ytd,
      {
        grossEarnings: gross,
        federalTaxableWages: federalTaxable,
        stateTaxableWages: stateTaxable,
        ssTaxableWages: ssTaxable,
        medicareTaxableWages: medicareTaxable,
        supplementalTaxableWages,
        federalTaxWithheld: taxes.federalIncome,
        stateTaxWithheld: taxes.stateIncome,
        ssTaxWithheld: taxes.socialSecurity,
        medicareTaxWithheld: taxes.medicare,
        medicareAdditionalWithheld: taxes.medicareAdditional,
        pretax401k,
        roth401k,
        hsa,
        fsa,
        section125,
      },
      isCorrection,
      correctionOriginalGross
    );
  }

  resetForYear(store: Map<string, YearToDate>, taxYear: number): void {
    for (const [key, ytd] of store.entries()) {
      if (ytd.taxYear === taxYear) {
        store.set(key, emptyYtd(ytd.employeeId, taxYear));
      }
    }
  }
}
