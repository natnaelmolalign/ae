import type {
  CreateDeductionScheduleInput,
  DeductionSchedule,
  UpdateDeductionScheduleInput,
} from '../models/DeductionSchedule';
import type { DeductionScheduleRepository } from '../repositories/interfaces';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';
import { compare } from '../utils/decimalUtils';

export class DeductionScheduleService {
  constructor(private readonly repo: DeductionScheduleRepository) {}

  create(
    input: CreateDeductionScheduleInput,
    companyId: string
  ): Promise<DeductionSchedule> {
    this.validateCreate(input);
    return this.repo.create({ ...input, companyId });
  }

  get(id: string): Promise<DeductionSchedule | null> {
    return this.repo.findById(id);
  }

  listByEmployee(employeeId: string): Promise<DeductionSchedule[]> {
    return this.repo.findByEmployee(employeeId);
  }

  listActive(
    employeeId: string,
    asOfDate: string
  ): Promise<DeductionSchedule[]> {
    return this.repo.findActiveForEmployee(employeeId, asOfDate);
  }

  async update(
    id: string,
    input: UpdateDeductionScheduleInput
  ): Promise<DeductionSchedule> {
    const updated = await this.repo.update(id, input);
    if (!updated) {
      throw PayrollDomainError.notFound('DeductionSchedule', id);
    }
    return updated;
  }

  async delete(id: string): Promise<void> {
    const ok = await this.repo.delete(id);
    if (!ok) {
      throw PayrollDomainError.notFound('DeductionSchedule', id);
    }
  }

  private validateCreate(input: CreateDeductionScheduleInput): void {
    if (compare(input.amountPerPeriod, '0.00') <= 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'amountPerPeriod must be positive'
      );
    }
    if (input.scheduleType === 'arrears') {
      const balance = input.remainingBalance ?? input.amountPerPeriod;
      if (compare(balance, '0.00') <= 0) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'arrears schedules require a positive remainingBalance'
        );
      }
    }
  }
}
