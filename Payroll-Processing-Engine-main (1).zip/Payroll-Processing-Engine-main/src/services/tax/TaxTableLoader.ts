import * as fs from 'fs';
import * as path from 'path';
import Ajv, { type ErrorObject } from 'ajv';
import type { TaxYearTables } from '../../data/tax/types';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import { enabledTaxYears } from '../../config/taxYear';
import { taxYearTablesSchema } from './TaxTableSchema';

const SCHEMA_PATH = path.join(
  __dirname,
  '../../data/schema/taxTables.schema.json'
);

export interface TaxTableValidationIssue {
  path: string;
  message: string;
}

export interface TaxTableValidationResult {
  taxYear: number;
  valid: boolean;
  issues: TaxTableValidationIssue[];
}

function formatAjvErrors(
  errors: ErrorObject[] | null | undefined
): TaxTableValidationIssue[] {
  if (!errors?.length) {
    return [];
  }
  return errors.map((e) => ({
    path: e.instancePath || '/',
    message: e.message ?? 'schema validation failed',
  }));
}

export class TaxTableLoader {
  private cache = new Map<number, TaxYearTables>();
  private ajv: Ajv;
  private validateJson: ReturnType<Ajv['compile']>;

  constructor(private readonly dataRoot = path.join(__dirname, '../../data')) {
    this.ajv = new Ajv({ allErrors: true, strict: false });
    const schema = JSON.parse(fs.readFileSync(SCHEMA_PATH, 'utf8')) as Record<
      string,
      unknown
    >;
    this.validateJson = this.ajv.compile(schema);
  }

  /** Years with a `tables.json` pack under `src/data/{year}/`. */
  discoverYears(): number[] {
    if (!fs.existsSync(this.dataRoot)) {
      return [];
    }
    return fs
      .readdirSync(this.dataRoot, { withFileTypes: true })
      .filter((d) => d.isDirectory() && /^\d{4}$/.test(d.name))
      .map((d) => parseInt(d.name, 10))
      .filter((year) => fs.existsSync(this.tablesPath(year)))
      .sort((a, b) => a - b);
  }

  tablesPath(taxYear: number): string {
    return path.join(this.dataRoot, String(taxYear), 'tables.json');
  }

  /** Clear in-memory cache (dev hot-reload). */
  reload(): void {
    this.cache.clear();
  }

  private useCache(): boolean {
    return (
      process.env.NODE_ENV !== 'development' &&
      process.env.TAX_TABLE_HOT_RELOAD !== 'true'
    );
  }

  validateRaw(taxYear: number, raw: unknown): TaxTableValidationResult {
    const jsonOk = this.validateJson(raw);
    const jsonIssues = formatAjvErrors(this.validateJson.errors);
    const zod = taxYearTablesSchema.safeParse(raw);
    const zodIssues: TaxTableValidationIssue[] = zod.success
      ? []
      : zod.error.issues.map((i) => ({
          path: i.path.join('.') || '/',
          message: i.message,
        }));

    const issues = [...jsonIssues, ...zodIssues];
    const parsedYear =
      typeof raw === 'object' &&
      raw !== null &&
      'taxYear' in raw &&
      typeof (raw as { taxYear: unknown }).taxYear === 'number'
        ? (raw as { taxYear: number }).taxYear
        : taxYear;

    if (parsedYear !== taxYear) {
      issues.push({
        path: 'taxYear',
        message: `taxYear field ${parsedYear} does not match directory year ${taxYear}`,
      });
    }

    return {
      taxYear,
      valid: Boolean(jsonOk) && zod.success && parsedYear === taxYear,
      issues,
    };
  }

  validateYear(taxYear: number): TaxTableValidationResult {
    const filePath = this.tablesPath(taxYear);
    if (!fs.existsSync(filePath)) {
      return {
        taxYear,
        valid: false,
        issues: [{ path: filePath, message: 'tables.json not found' }],
      };
    }
    const raw: unknown = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    return this.validateRaw(taxYear, raw);
  }

  /** Validate every discovered year pack (CI / CLI). */
  validateAllDiscovered(): TaxTableValidationResult[] {
    return this.discoverYears().map((year) => this.validateYear(year));
  }

  /** Validate packs for tax years enabled in this environment. */
  validateEnabledYears(): TaxTableValidationResult[] {
    const enabled = enabledTaxYears();
    const discovered = this.discoverYears();
    const missing = enabled.filter((y) => !discovered.includes(y));
    const results = discovered.map((year) => this.validateYear(year));
    for (const year of missing) {
      results.push({
        taxYear: year,
        valid: false,
        issues: [
          {
            path: this.tablesPath(year),
            message: `enabled tax year ${year} has no tables.json pack`,
          },
        ],
      });
    }
    return results;
  }

  loadYear(taxYear: number): TaxYearTables {
    if (this.useCache() && this.cache.has(taxYear)) {
      return this.cache.get(taxYear)!;
    }

    const result = this.validateYear(taxYear);
    if (!result.valid) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        `Tax tables for year ${taxYear} failed validation`,
        { taxYear, issues: result.issues }
      );
    }

    const raw: unknown = JSON.parse(
      fs.readFileSync(this.tablesPath(taxYear), 'utf8')
    );
    const tables = taxYearTablesSchema.parse(raw) as TaxYearTables;
    if (this.useCache()) {
      this.cache.set(taxYear, tables);
    }
    return tables;
  }
}

export const defaultTaxTableLoader = new TaxTableLoader();
