import type { Employee } from '../../models/types';
import type { StateAllocationInput } from '../../models/WorkLocationAllocation';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type { TaxYearTables } from '../../data/tax/types';
import {
  add,
  compare,
  div,
  mul,
  sub,
  type Money,
} from '../../utils/decimalUtils';
import { StateWithholdingEngine } from './state/StateWithholdingEngine';

export interface StateTaxSlice {
  stateCode: string;
  allocatedWages: Money;
  stateTaxWithheld: Money;
}

const PERCENT_TOLERANCE = '0.01';

export class MultiStateAllocationService {
  validateAllocations(allocations: StateAllocationInput[]): void {
    if (allocations.length === 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'At least one state allocation is required'
      );
    }
    let sum = '0.00';
    const seen = new Set<string>();
    for (const row of allocations) {
      const code = row.stateCode.toUpperCase();
      if (seen.has(code)) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          `Duplicate state in allocation: ${code}`,
          { stateCode: code }
        );
      }
      seen.add(code);
      if (compare(row.percent, '0.00') < 0) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          `Allocation percent must be non-negative for ${code}`
        );
      }
      sum = add(sum, row.percent);
    }
    if (compare(sum, sub('100.00', PERCENT_TOLERANCE)) < 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        `State allocation percents must sum to 100 (got ${sum})`,
        { sum }
      );
    }
    if (compare(sum, add('100.00', PERCENT_TOLERANCE)) > 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        `State allocation percents must sum to 100 (got ${sum})`,
        { sum }
      );
    }
  }

  calculateTotalStateTax(
    tables: TaxYearTables,
    employee: Employee,
    stateTaxable: Money,
    allocations: StateAllocationInput[]
  ): { total: Money; slices: StateTaxSlice[] } {
    this.validateAllocations(allocations);
    let total = '0.00';
    const slices: StateTaxSlice[] = [];

    for (const row of allocations) {
      const stateCode = row.stateCode.toUpperCase();
      const allocatedWages = mul(stateTaxable, div(row.percent, '100'));
      const stateTaxWithheld = StateWithholdingEngine.calculateForState(
        tables,
        stateCode,
        employee.payFrequency,
        allocatedWages
      );
      total = add(total, stateTaxWithheld);
      slices.push({ stateCode, allocatedWages, stateTaxWithheld });
    }

    return { total, slices };
  }
}
