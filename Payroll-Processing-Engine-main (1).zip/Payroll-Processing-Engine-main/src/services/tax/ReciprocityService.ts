import {
  RECIPROCITY_2024,
  type ReciprocityAgreement,
} from '../../data/2024/reciprocity';

export class ReciprocityService {
  constructor(
    private readonly agreements: ReciprocityAgreement[] = RECIPROCITY_2024
  ) {}

  /** Resident should not tax wages allocated to a reciprocity work state. */
  shouldSkipResidentTaxOnWorkState(
    residentState: string,
    workState: string
  ): boolean {
    if (residentState === workState) return false;
    return this.agreements.some(
      (a) =>
        a.withholdWorkStateOnly &&
        a.residentState === residentState &&
        a.workState === workState
    );
  }

  findAgreement(
    residentState: string,
    workState: string
  ): ReciprocityAgreement | undefined {
    return this.agreements.find(
      (a) => a.residentState === residentState && a.workState === workState
    );
  }
}
