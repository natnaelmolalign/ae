import type { TaxYearTables } from '../../data/tax/types';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import {
  assertSupportedTaxYear,
  enabledTaxYears,
  type SupportedTaxYear,
} from '../../config/taxYear';
import { TaxTableLoader, defaultTaxTableLoader } from './TaxTableLoader';

export class TaxYearService {
  private validated = false;

  constructor(
    private readonly loader: TaxTableLoader = defaultTaxTableLoader
  ) {}

  /** Validate enabled tax year packs at startup (Phase 7 exit gate). */
  validateAll(): void {
    const results = this.loader.validateEnabledYears();
    const failed = results.filter((r) => !r.valid);
    if (failed.length > 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'One or more tax table packs failed validation',
        { failures: failed }
      );
    }
    this.validated = true;
  }

  getYearTables(taxYear: SupportedTaxYear): TaxYearTables {
    if (!this.validated) {
      this.validateAll();
    }
    if (!enabledTaxYears().includes(taxYear)) {
      throw new PayrollDomainError(
        PayrollErrorCode.TAX_YEAR_UNSUPPORTED,
        `Tax year ${taxYear} is not enabled`,
        { taxYear, enabled: enabledTaxYears() }
      );
    }
    return this.loader.loadYear(taxYear);
  }

  getYearTablesForPaymentDate(paymentDate: string): TaxYearTables {
    const year = parseInt(paymentDate.slice(0, 4), 10);
    const supported = assertSupportedTaxYear(year);
    return this.getYearTables(supported);
  }

  /** Dev-only: reload JSON packs without process restart. */
  reloadTables(): void {
    this.loader.reload();
    this.validated = false;
  }
}

export const defaultTaxYearService = new TaxYearService();
