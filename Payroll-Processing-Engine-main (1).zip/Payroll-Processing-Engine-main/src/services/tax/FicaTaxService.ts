import type { FicaTaxYearData } from '../../data/tax/types';
import type { TaxWithholdingResult, YearToDate } from '../../models/types';
import {
  compare,
  d,
  minMoney,
  mul,
  sub,
  type Money,
} from '../../utils/decimalUtils';

export class FicaTaxService {
  calculate(
    fica: FicaTaxYearData,
    ssTaxableWages: Money,
    medicareTaxableWages: Money,
    ytd: YearToDate
  ): Pick<
    TaxWithholdingResult,
    'socialSecurity' | 'medicare' | 'medicareAdditional'
  > {
    const remainingSsBase = sub(
      fica.socialSecurityWageBase,
      ytd.ssTaxableWages
    );
    const ssWagesThisPeriod =
      compare(remainingSsBase, '0.00') <= 0
        ? '0.00'
        : minMoney(ssTaxableWages, remainingSsBase);

    const socialSecurity = mul(ssWagesThisPeriod, fica.socialSecurityRate);
    const medicare = mul(medicareTaxableWages, fica.medicareRate);

    const priorYtd = d(ytd.medicareTaxableWages);
    const afterPeriod = priorYtd.plus(medicareTaxableWages);
    const threshold = d(fica.medicareAdditionalThreshold);

    let medicareAdditional = '0.00';
    if (afterPeriod.gt(threshold)) {
      const taxableAtAdditional = priorYtd.gte(threshold)
        ? d(medicareTaxableWages)
        : afterPeriod.minus(threshold);
      medicareAdditional = taxableAtAdditional
        .times(fica.medicareAdditionalRate)
        .toFixed(2);
    }

    return { socialSecurity, medicare, medicareAdditional };
  }
}
