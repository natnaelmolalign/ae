import { features } from '../../config/features';
import type { TaxYearTables } from '../../data/tax/types';
import type { Employee } from '../../models/types';
import { mul, type Money } from '../../utils/decimalUtils';

export class LocalTaxService {
  calculate(
    tables: TaxYearTables,
    employee: Employee,
    localTaxableWages: Money
  ): Money {
    if (!features.localTaxEnabled || !employee.localMunicipalityCode) {
      return '0.00';
    }

    const entries = tables.local[employee.stateCode];
    if (!entries?.length) return '0.00';

    const match = entries.find(
      (e) => e.municipalityCode === employee.localMunicipalityCode
    );
    if (!match) return '0.00';

    return mul(localTaxableWages, match.rate);
  }
}
