import { z } from 'zod';

const taxBracketSchema = z.object({
  upTo: z.string().nullable(),
  rate: z.string(),
});

const filingStatusSchema = z.enum([
  'single',
  'married_filing_jointly',
  'married_filing_separately',
  'head_of_household',
]);

const federalSchema = z.object({
  brackets: z.record(filingStatusSchema, z.array(taxBracketSchema)),
  standardDeduction: z.record(filingStatusSchema, z.string()),
  supplementalFlatRate: z.string(),
  payPeriodsPerYear: z.object({
    weekly: z.number(),
    biweekly: z.number(),
    semimonthly: z.number(),
    monthly: z.number(),
  }),
});

const ficaSchema = z.object({
  socialSecurityWageBase: z.string(),
  socialSecurityRate: z.string(),
  medicareRate: z.string(),
  medicareAdditionalThreshold: z.string(),
  medicareAdditionalRate: z.string(),
});

const stateEntrySchema = z.object({
  noIncomeTax: z.boolean().optional(),
  flatRate: z.string().optional(),
  brackets: z.array(taxBracketSchema).optional(),
});

export const taxYearTablesSchema = z.object({
  taxYear: z.number().int(),
  federal: federalSchema,
  fica: ficaSchema,
  states: z.record(z.string(), stateEntrySchema),
  local: z.record(
    z.string(),
    z.array(
      z.object({
        municipalityCode: z.string(),
        rate: z.string(),
      })
    )
  ),
});

export type ValidatedTaxYearTables = z.infer<typeof taxYearTablesSchema>;
