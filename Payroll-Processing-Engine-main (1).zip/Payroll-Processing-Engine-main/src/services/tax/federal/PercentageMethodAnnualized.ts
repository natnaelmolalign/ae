import type { FederalWithholdingStrategy } from './FederalWithholdingStrategy';
import {
  annualIncomeTaxFromTaxable,
  annualTaxableAfterW4Adjustments,
  periodWithholdingFromAnnualTax,
} from './federalTaxableAnnual';
import { annualizePeriodWages } from '../../../utils/taxBracketUtils';

export class PercentageMethodAnnualized implements FederalWithholdingStrategy {
  readonly name = 'percentage_method_annualized';

  calculate(
    ctx: import('./FederalWithholdingStrategy').FederalWithholdingContext
  ): string {
    const periods = ctx.federal.payPeriodsPerYear[ctx.payFrequency];
    const annualized = annualizePeriodWages(ctx.periodFederalTaxable, periods);
    const taxableAnnual = annualTaxableAfterW4Adjustments(
      annualized,
      ctx.w4,
      ctx.federal
    );
    const annualTax = annualIncomeTaxFromTaxable(
      taxableAnnual,
      ctx.w4.filingStatus,
      ctx.federal.brackets,
      ctx.w4.dependentsCreditAnnual,
      ctx.w4.multipleJobs
    );
    return periodWithholdingFromAnnualTax(
      annualTax,
      periods,
      ctx.w4.extraWithholdingPerPeriod
    );
  }
}
