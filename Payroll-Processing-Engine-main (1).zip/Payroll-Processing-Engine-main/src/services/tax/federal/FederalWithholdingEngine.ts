import type { FederalTaxYearData } from '../../../data/tax/types';
import type { W4Params } from '../../../models/W4Params';
import type { PayFrequency } from '../../../models/types';
import type { Money } from '../../../utils/decimalUtils';
import type { FederalWithholdingContext } from './FederalWithholdingStrategy';
import { PercentageMethodAnnualized } from './PercentageMethodAnnualized';
import { SupplementalAggregateStrategy } from './SupplementalAggregateStrategy';
import { SupplementalFlatStrategy } from './SupplementalFlatStrategy';

const percentage = new PercentageMethodAnnualized();
const supplementalFlat = new SupplementalFlatStrategy();
const supplementalAggregate = new SupplementalAggregateStrategy();

export class FederalWithholdingEngine {
  static selectStrategy(ctx: FederalWithholdingContext) {
    if (ctx.supplementalOnly && !ctx.mixedSupplemental) {
      return supplementalFlat;
    }
    if (ctx.mixedSupplemental) {
      return supplementalAggregate;
    }
    return percentage;
  }

  static calculate(
    federal: FederalTaxYearData,
    w4: W4Params,
    payFrequency: PayFrequency,
    periodFederalTaxable: Money,
    regularFederalTaxable: Money,
    supplementalFederalTaxable: Money,
    supplementalOnly: boolean,
    mixedSupplemental: boolean
  ): Money {
    const ctx: FederalWithholdingContext = {
      federal,
      w4,
      payFrequency,
      periodFederalTaxable,
      regularFederalTaxable,
      supplementalFederalTaxable,
      supplementalOnly,
      mixedSupplemental,
    };
    return FederalWithholdingEngine.selectStrategy(ctx).calculate(ctx);
  }
}
