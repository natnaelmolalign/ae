import type { FederalWithholdingStrategy } from './FederalWithholdingStrategy';
import { add } from '../../../utils/decimalUtils';
import { PercentageMethodAnnualized } from './PercentageMethodAnnualized';

/**
 * Mixed supplemental + regular wages: withhold as if total were one regular payment
 * (IRS Publication 15 aggregate / combined payment method).
 */
export class SupplementalAggregateStrategy
  implements FederalWithholdingStrategy
{
  readonly name = 'supplemental_aggregate';
  private percentage = new PercentageMethodAnnualized();

  calculate(
    ctx: import('./FederalWithholdingStrategy').FederalWithholdingContext
  ): string {
    const combined = add(
      ctx.regularFederalTaxable,
      ctx.supplementalFederalTaxable
    );
    return this.percentage.calculate({
      ...ctx,
      periodFederalTaxable: combined,
    });
  }
}
