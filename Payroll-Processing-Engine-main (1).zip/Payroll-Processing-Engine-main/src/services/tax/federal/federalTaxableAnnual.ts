import type { FederalTaxYearData } from '../../../data/tax/types';
import type { W4Params } from '../../../models/W4Params';
import type { FilingStatus } from '../../../models/types';
import type { TaxBracket } from '../../../data/tax/types';
import {
  calculateProgressiveTax,
  deannualizeTax,
} from '../../../utils/taxBracketUtils';
import { compare, d, mul, type Money, sub } from '../../../utils/decimalUtils';

export function annualTaxableAfterW4Adjustments(
  annualGrossWages: Money,
  w4: W4Params,
  federal: FederalTaxYearData
): Money {
  let taxable = sub(
    annualGrossWages,
    federal.standardDeduction[w4.filingStatus]
  );
  taxable = sub(taxable, w4.otherDeductionsAnnual);
  taxable = d(taxable).plus(w4.otherIncomeAnnual).toFixed(2);
  if (compare(taxable, '0.00') < 0) return '0.00';
  return taxable;
}

export function annualIncomeTaxFromTaxable(
  annualTaxable: Money,
  filingStatus: FilingStatus,
  brackets: Record<FilingStatus, TaxBracket[]>,
  dependentsCreditAnnual: Money,
  multipleJobs: boolean
): Money {
  let tax = calculateProgressiveTax(annualTaxable, filingStatus, brackets);
  if (d(tax).greaterThan(d(dependentsCreditAnnual))) {
    tax = sub(tax, dependentsCreditAnnual);
  } else {
    tax = '0.00';
  }
  if (multipleJobs) {
    tax = mul(tax, '1.10');
  }
  return tax;
}

export function periodWithholdingFromAnnualTax(
  annualTax: Money,
  periodsPerYear: number,
  extraPerPeriod: Money
): Money {
  const period = deannualizeTax(annualTax, periodsPerYear);
  return d(period).plus(extraPerPeriod).toFixed(2);
}
