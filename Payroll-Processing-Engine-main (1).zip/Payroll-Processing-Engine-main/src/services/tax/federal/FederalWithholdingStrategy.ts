import type { FederalTaxYearData } from '../../../data/tax/types';
import type { W4Params } from '../../../models/W4Params';
import type { PayFrequency } from '../../../models/types';
import type { Money } from '../../../utils/decimalUtils';

export interface FederalWithholdingContext {
  federal: FederalTaxYearData;
  w4: W4Params;
  payFrequency: PayFrequency;
  periodFederalTaxable: Money;
  regularFederalTaxable: Money;
  supplementalFederalTaxable: Money;
  supplementalOnly: boolean;
  mixedSupplemental: boolean;
}

export interface FederalWithholdingStrategy {
  readonly name: string;
  calculate(ctx: FederalWithholdingContext): Money;
}
