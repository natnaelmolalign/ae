import type { FederalWithholdingStrategy } from './FederalWithholdingStrategy';
import { d, mul } from '../../../utils/decimalUtils';

export class SupplementalFlatStrategy implements FederalWithholdingStrategy {
  readonly name = 'supplemental_flat';

  calculate(
    ctx: import('./FederalWithholdingStrategy').FederalWithholdingContext
  ): string {
    const amount =
      ctx.supplementalOnly && !ctx.mixedSupplemental
        ? ctx.periodFederalTaxable
        : ctx.supplementalFederalTaxable;
    const tax = mul(amount, ctx.federal.supplementalFlatRate);
    return d(tax).plus(ctx.w4.extraWithholdingPerPeriod).toFixed(2);
  }
}
