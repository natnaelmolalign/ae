import type { StateTaxYearEntry, TaxBracket } from '../../../data/tax/types';
import type { FilingStatus } from '../../../models/types';
import type {
  StateWithholdingContext,
  StateWithholdingStrategy,
} from './StateWithholdingStrategy';
import {
  annualizePeriodWages,
  calculateProgressiveTax,
  deannualizeTax,
} from '../../../utils/taxBracketUtils';

/** State bracket tables use single filing status in v1 (NY 2024 simplified). */
const STATE_BRACKET_FILING: FilingStatus = 'single';

export class BracketStateWithholdingStrategy
  implements StateWithholdingStrategy
{
  supports(config: StateTaxYearEntry): boolean {
    return Boolean(config.brackets?.length) && !config.noIncomeTax;
  }

  calculate(ctx: StateWithholdingContext): string {
    const statusBrackets = ctx.config.brackets!;
    const brackets: Record<FilingStatus, TaxBracket[]> = {
      single: statusBrackets,
      married_filing_jointly: statusBrackets,
      married_filing_separately: statusBrackets,
      head_of_household: statusBrackets,
    };
    const annualized = annualizePeriodWages(
      ctx.periodStateTaxable,
      ctx.periodsPerYear
    );
    const annualTax = calculateProgressiveTax(
      annualized,
      STATE_BRACKET_FILING,
      brackets
    );
    return deannualizeTax(annualTax, ctx.periodsPerYear);
  }
}
