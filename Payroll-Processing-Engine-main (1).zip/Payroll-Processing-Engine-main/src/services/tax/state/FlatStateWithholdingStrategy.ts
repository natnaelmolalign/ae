import type { StateTaxYearEntry } from '../../../data/tax/types';
import type {
  StateWithholdingContext,
  StateWithholdingStrategy,
} from './StateWithholdingStrategy';
import { mul } from '../../../utils/decimalUtils';
import {
  annualizePeriodWages,
  deannualizeTax,
} from '../../../utils/taxBracketUtils';

export class FlatStateWithholdingStrategy implements StateWithholdingStrategy {
  supports(config: StateTaxYearEntry): boolean {
    return Boolean(config.flatRate) && !config.noIncomeTax;
  }

  calculate(ctx: StateWithholdingContext): string {
    const rate = ctx.config.flatRate!;
    const annualized = annualizePeriodWages(
      ctx.periodStateTaxable,
      ctx.periodsPerYear
    );
    const annualTax = mul(annualized, rate);
    return deannualizeTax(annualTax, ctx.periodsPerYear);
  }
}
