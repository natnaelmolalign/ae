import type { StateTaxYearEntry } from '../../../data/tax/types';
import type { PayFrequency } from '../../../models/types';
import type { Money } from '../../../utils/decimalUtils';

export interface StateWithholdingContext {
  stateCode: string;
  payFrequency: PayFrequency;
  periodStateTaxable: Money;
  config: StateTaxYearEntry;
  periodsPerYear: number;
}

export interface StateWithholdingStrategy {
  supports(config: StateTaxYearEntry): boolean;
  calculate(ctx: StateWithholdingContext): Money;
}
