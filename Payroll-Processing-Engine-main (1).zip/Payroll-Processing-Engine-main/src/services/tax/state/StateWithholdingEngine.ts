import type { TaxYearTables } from '../../../data/tax/types';
import type { Employee, PayFrequency } from '../../../models/types';
import type { Money } from '../../../utils/decimalUtils';
import { BracketStateWithholdingStrategy } from './BracketStateWithholdingStrategy';
import { FlatStateWithholdingStrategy } from './FlatStateWithholdingStrategy';
import { NoStateTaxStrategy } from './NoStateTaxStrategy';
import type { StateWithholdingContext } from './StateWithholdingStrategy';

const strategies = [
  new NoStateTaxStrategy(),
  new FlatStateWithholdingStrategy(),
  new BracketStateWithholdingStrategy(),
];

export class StateWithholdingEngine {
  static calculate(
    tables: TaxYearTables,
    employee: Employee,
    periodStateTaxable: Money
  ): Money {
    return StateWithholdingEngine.calculateForState(
      tables,
      employee.stateCode,
      employee.payFrequency,
      periodStateTaxable
    );
  }

  static calculateForState(
    tables: TaxYearTables,
    stateCode: string,
    payFrequency: PayFrequency,
    periodStateTaxable: Money
  ): Money {
    const config = tables.states[stateCode];
    if (!config) return '0.00';

    const strategy = strategies.find((s) => s.supports(config));
    if (!strategy) return '0.00';

    const periodsPerYear = tables.federal.payPeriodsPerYear[payFrequency];
    const ctx: StateWithholdingContext = {
      stateCode,
      payFrequency,
      periodStateTaxable,
      config,
      periodsPerYear,
    };
    return strategy.calculate(ctx);
  }
}
