import type { StateTaxYearEntry } from '../../../data/tax/types';
import type {
  StateWithholdingContext,
  StateWithholdingStrategy,
} from './StateWithholdingStrategy';

export class NoStateTaxStrategy implements StateWithholdingStrategy {
  supports(config: StateTaxYearEntry): boolean {
    return Boolean(config.noIncomeTax);
  }

  calculate(_ctx: StateWithholdingContext): string {
    return '0.00';
  }
}
