import { benefitEnrollmentToDeduction } from '../models/BenefitEnrollment';
import type { Employee, EarningsLine, YearToDate } from '../models/types';
import type { BenefitEnrollmentService } from './BenefitEnrollmentService';
import { DeductionService, type DeductionBases } from './DeductionService';
import { EarningsService } from './EarningsService';
import { compare } from '../utils/decimalUtils';
import { emptyYtd } from '../utils/ytdUtils';
import type {
  DeductionScheduleRepository,
  YtdRepository,
} from '../repositories/interfaces';
import type { DeductionSchedule } from '../models/DeductionSchedule';
import { ScheduledDeductionService } from './deductions/ScheduledDeductionService';
import { CobraPremiumService } from './deductions/CobraPremiumService';
import { features } from '../config/features';
import { TaxCalculationService } from './TaxCalculationService';
import { splitFederalTaxableAfterPretax } from '../utils/federalTaxableSplit';
import { sub } from '../utils/decimalUtils';

export interface DeductionPreviewInput {
  employee: Employee;
  paymentDate: string;
  taxYear: number;
  earnings: EarningsLine[];
  deductions?: import('../models/types').DeductionEnrollment[];
  useActiveEnrollments?: boolean;
  useActiveDeductionSchedules?: boolean;
  ytd?: YearToDate;
}

export interface DeductionPreviewResult {
  gross: string;
  bases: DeductionBases;
  withinGross: boolean;
  scheduledDeductions?: {
    lines: { scheduleId: string; label: string; amount: string }[];
    total: string;
  };
  federalTaxableAfterPretax?: string;
}

export class DeductionPreviewService {
  private scheduled = new ScheduledDeductionService();
  private cobraGuard = new CobraPremiumService();
  private taxService = new TaxCalculationService();

  constructor(
    private readonly ytdRepo: YtdRepository,
    private readonly deductionService = new DeductionService(),
    private readonly earningsService = new EarningsService(),
    private readonly enrollmentService: BenefitEnrollmentService,
    private readonly scheduleRepo?: DeductionScheduleRepository
  ) {}

  async preview(input: DeductionPreviewInput): Promise<DeductionPreviewResult> {
    const classified = this.earningsService.classify(input.earnings, {
      employee: input.employee,
    });

    let deductions = input.deductions ?? [];
    if (input.useActiveEnrollments) {
      const active = await this.enrollmentService.listActive(
        input.employee.id,
        input.paymentDate
      );
      deductions = active.map(benefitEnrollmentToDeduction);
    }

    const ytd =
      input.ytd ??
      (await this.ytdRepo.get(input.employee.id, input.taxYear)) ??
      emptyYtd(input.employee.id, input.taxYear);

    const filtered = deductions.filter(
      (d) => !d.type.startsWith('garnishment')
    );
    this.cobraGuard.assertNotPreTaxEnrollment(filtered);

    const bases = this.deductionService.applyPreTax(
      classified.federalTaxable,
      classified.stateTaxable,
      classified.ssTaxable,
      classified.medicareTaxable,
      filtered,
      ytd,
      { taxYear: input.taxYear, gross: classified.gross }
    );

    const withinGross =
      compare(bases.federalTaxableReduction, classified.gross) <= 0;

    const federalTaxable = sub(
      classified.federalTaxable,
      bases.federalTaxableReduction
    );

    let scheduledDeductions: DeductionPreviewResult['scheduledDeductions'];
    if (input.useActiveDeductionSchedules && this.scheduleRepo) {
      const schedules = await this.loadSchedules(
        input.employee.id,
        input.paymentDate,
        input.useActiveDeductionSchedules
      );
      const federalSplit = splitFederalTaxableAfterPretax(
        federalTaxable,
        classified
      );
      const taxes = this.taxService.calculateAll(
        input.employee,
        federalTaxable,
        classified.stateTaxable,
        classified.ssTaxable,
        classified.medicareTaxable,
        input.earnings,
        ytd,
        {
          paymentDate: input.paymentDate,
          regularFederalTaxable: federalSplit.regularFederalTaxable,
          supplementalFederalTaxable: federalSplit.supplementalFederalTaxable,
        }
      );
      const scheduled = this.scheduled.resolve(
        input.employee,
        input.paymentDate,
        schedules,
        { gross: classified.gross, taxes, pretax: bases }
      );
      scheduledDeductions = {
        lines: scheduled.lines.map((l) => ({
          scheduleId: l.scheduleId,
          label: l.label,
          amount: l.amount,
        })),
        total: scheduled.total,
      };
    }

    return {
      gross: classified.gross,
      bases,
      withinGross,
      federalTaxableAfterPretax: federalTaxable,
      scheduledDeductions,
    };
  }

  private async loadSchedules(
    employeeId: string,
    paymentDate: string,
    useActive: boolean
  ): Promise<DeductionSchedule[]> {
    if (!features.cobraArrearsEnabled || !useActive || !this.scheduleRepo) {
      return [];
    }
    return this.scheduleRepo.findActiveForEmployee(employeeId, paymentDate);
  }
}
