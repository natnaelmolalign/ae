import { randomUUID } from 'crypto';
import type {
  CreateTimeEntryInput,
  PayPeriod,
  TimeEntry,
} from '../models/types';
import type { TimeEntryRepository } from '../repositories/interfaces';
import {
  isDateInPayPeriod,
  minutesBetween,
  roundMinutesWorked,
} from '../utils/timeEntryUtils';

export class TimeEntryService {
  constructor(private readonly repo: TimeEntryRepository) {}

  async create(input: CreateTimeEntryInput): Promise<TimeEntry> {
    const raw = minutesBetween(input.clockIn, input.clockOut);
    const entry: TimeEntry = {
      id: randomUUID(),
      employeeId: input.employeeId,
      payPeriodId: input.payPeriodId ?? null,
      shiftAssignmentId: input.shiftAssignmentId ?? null,
      workDate: input.workDate,
      clockIn: input.clockIn,
      clockOut: input.clockOut,
      roundedMinutes: roundMinutesWorked(raw),
      entryType: input.entryType ?? 'regular',
      createdAt: new Date().toISOString(),
    };
    await this.repo.insert(entry);
    return entry;
  }

  async listForPayPeriod(
    employeeId: string,
    payPeriod: PayPeriod
  ): Promise<TimeEntry[]> {
    const all = await this.repo.findByEmployee(employeeId);
    return all.filter(
      (e) =>
        e.payPeriodId === payPeriod.id ||
        isDateInPayPeriod(e.workDate, payPeriod.startDate, payPeriod.endDate)
    );
  }
}
