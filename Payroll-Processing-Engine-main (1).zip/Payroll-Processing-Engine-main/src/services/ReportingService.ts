import type { Knex } from 'knex';
import type { PayrollRunResult } from '../models/types';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { GeneralLedgerExporter, type GlExport } from './GeneralLedgerExporter';
import { PayrollRegisterService } from './PayrollRegisterService';
import { TipReportingService } from './tips/TipReportingService';
import type { PayrollRunAllocationRepository } from '../repositories/interfaces';
import {
  LaborCostReportingService,
  type LaborCostReport,
} from './costing/LaborCostReportingService';

export class ReportingService {
  private registerService: PayrollRegisterService;
  private glExporter = new GeneralLedgerExporter();
  private laborCostReport: LaborCostReportingService;

  private tipReportingService: TipReportingService;

  constructor(
    private readonly db: Knex,
    private readonly allocationRepo?: PayrollRunAllocationRepository
  ) {
    this.registerService = new PayrollRegisterService(db, allocationRepo);
    this.laborCostReport = new LaborCostReportingService(
      db,
      allocationRepo ?? {
        findSegmentsForRuns: async () => new Map(),
        insertMany: async () => {},
        findByPayrollRun: async () => [],
      }
    );
    this.tipReportingService = new TipReportingService(db);
  }

  async laborCost(
    payPeriodId: string,
    companyId: string
  ): Promise<LaborCostReport> {
    return this.laborCostReport.build(payPeriodId, companyId);
  }

  async tipRegister(payPeriodId: string, companyId: string) {
    const period = await this.db('pay_periods')
      .where({ id: payPeriodId, company_id: companyId })
      .first();
    if (!period) {
      throw PayrollDomainError.notFound('Pay period', payPeriodId);
    }
    return this.tipReportingService.buildForPeriod(payPeriodId);
  }

  async payrollRegister(payPeriodId: string, companyId: string) {
    const period = await this.db('pay_periods')
      .where({ id: payPeriodId, company_id: companyId })
      .first();
    if (!period) {
      throw PayrollDomainError.notFound('Pay period', payPeriodId);
    }
    const register = await this.registerService.build(payPeriodId);
    const stubSums = await this.registerService.sumStubsForPeriod(payPeriodId);
    return {
      register,
      reconciliation: {
        registerGross: register.totals.grossPay,
        registerNet: register.totals.netPay,
        stubTableGross: stubSums.grossPay,
        stubTableNet: stubSums.netPay,
        matches:
          register.totals.grossPay === stubSums.grossPay &&
          register.totals.netPay === stubSums.netPay,
      },
    };
  }

  async glExportForPeriod(
    payPeriodId: string,
    companyId: string
  ): Promise<{
    exports: GlExport[];
    csv: string;
    allBalanced: boolean;
  }> {
    const period = await this.db('pay_periods')
      .where({ id: payPeriodId, company_id: companyId })
      .first();
    if (!period) {
      throw PayrollDomainError.notFound('Pay period', payPeriodId);
    }

    const runs = await this.db('payroll_runs')
      .join('employees', 'payroll_runs.employee_id', 'employees.id')
      .where({
        'payroll_runs.pay_period_id': payPeriodId,
        'employees.company_id': companyId,
      })
      .select('payroll_runs.*');
    const runIds = runs.map((r) => String(r.id));
    const segmentMap = this.allocationRepo
      ? await this.allocationRepo.findSegmentsForRuns(runIds)
      : new Map();
    const exports: GlExport[] = [];

    for (const run of runs) {
      const result = await this.loadRunResult(run);
      const segments = segmentMap.get(String(run.id)) ?? [];
      exports.push(
        this.glExporter.exportRun(payPeriodId, String(run.id), result, segments)
      );
    }

    return {
      exports,
      csv: this.glExporter.toCsv(exports),
      allBalanced: exports.every((e) => e.balanced),
    };
  }

  private async loadRunResult(
    run: Record<string, unknown>
  ): Promise<PayrollRunResult> {
    const stubRow = await this.db('pay_stubs')
      .where({ id: run.pay_stub_id })
      .first();
    if (!stubRow) {
      throw PayrollDomainError.notFound('Pay stub', String(run.pay_stub_id));
    }

    const taxes =
      typeof run.taxes === 'string' ? JSON.parse(run.taxes) : run.taxes;
    const employerContributions =
      typeof run.employer_contributions === 'string'
        ? JSON.parse(run.employer_contributions)
        : run.employer_contributions;
    const lines =
      typeof stubRow.lines === 'string'
        ? JSON.parse(stubRow.lines)
        : stubRow.lines;

    return {
      payStub: {
        id: String(stubRow.id),
        employeeId: String(stubRow.employee_id),
        payPeriodId: String(stubRow.pay_period_id),
        grossPay: String(stubRow.gross_pay),
        netPay: String(stubRow.net_pay),
        lines,
        isCorrection: Boolean(stubRow.is_correction),
        createdAt: new Date(stubRow.created_at).toISOString(),
      },
      taxes,
      employerContributions,
    };
  }
}
