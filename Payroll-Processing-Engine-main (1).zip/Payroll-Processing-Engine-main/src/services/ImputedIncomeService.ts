import { features } from '../config/features';
import type { EarningsLine, ImputedIncomeInput } from '../models/types';
import { div, mul, sub, type Money } from '../utils/decimalUtils';

const GROUP_LIFE_EXEMPT_THRESHOLD = '50000.00';
/** IRS Table I factor per $1,000 of coverage per month (simplified) */
const GROUP_LIFE_MONTHLY_FACTOR = '0.024';

export class ImputedIncomeService {
  /**
   * Group-term life above $50,000 employer-provided coverage produces imputed taxable income.
   */
  calculateGroupLifeImputed(input: ImputedIncomeInput): Money {
    const excess = sub(input.coverageAmount, GROUP_LIFE_EXEMPT_THRESHOLD);
    if (parseFloat(excess) <= 0) return '0.00';

    const thousands = div(excess, '1000');
    const monthly = mul(thousands, GROUP_LIFE_MONTHLY_FACTOR);
    return monthly;
  }

  toEarningsLines(inputs: ImputedIncomeInput[]): EarningsLine[] {
    return inputs.map((input) => {
      if (input.type !== 'group_life') {
        return { type: 'regular' as const, amount: '0.00' };
      }
      const amount = this.calculateGroupLifeImputed(input);
      return { type: 'regular' as const, amount };
    });
  }

  /**
   * Holiday pay FICA exemption is jurisdiction-specific and feature-flagged.
   */
  isHolidayFicaExempt(stateCode: string): boolean {
    void stateCode;
    return features.holidayFicaExemptEnabled;
  }
}
