import type { NachaProfile, PaymentBatchItem } from '../../models/Disbursement';
import type { Money } from '../../utils/decimalUtils';

export interface NachaBuildInput {
  profile: NachaProfile;
  companyName: string;
  companyId: string;
  companyRouting: string;
  companyAccount: string;
  effectiveDate: string;
  items: PaymentBatchItem[];
  employeeNames: Record<string, string>;
}

export interface NachaBuildResult {
  fileContent: string;
  entryHashTotal: string;
  controlTotal: Money;
  entryCount: number;
}

const RECORD_WIDTH = 94;

function padRight(value: string, width: number): string {
  return value.slice(0, width).padEnd(width, ' ');
}

function padLeft(value: string, width: number, char = '0'): string {
  return value.slice(-width).padStart(width, char);
}

function amountCents(amount: Money): string {
  const cents = Math.round(parseFloat(amount) * 100);
  return padLeft(String(cents), 12);
}

function routingCheck(routing: string): string {
  return routing.slice(0, 8);
}

export class NachaFileBuilder {
  build(input: NachaBuildInput): NachaBuildResult {
    const creditCode = (item: PaymentBatchItem) =>
      item.routingNumber.startsWith('3') ? '32' : '22';
    const debitCode = '27';

    let entryHash = 0;
    let creditTotal = 0;
    const entryLines: string[] = [];
    let trace = 1;

    for (const item of input.items) {
      const rdfi = routingCheck(item.routingNumber);
      entryHash += parseInt(rdfi, 10);
      creditTotal += parseFloat(item.amount);
      const name =
        input.employeeNames[item.employeeId]?.slice(0, 22) ?? 'EMPLOYEE';
      entryLines.push(
        this.entryDetail({
          transactionCode: creditCode(item),
          routing: item.routingNumber,
          accountToken: item.accountNumberToken.slice(-17),
          amount: item.amount,
          name,
          traceNumber: padLeft(String(trace++), 7),
          profile: input.profile,
        })
      );
    }

    const totalCredit = creditTotal.toFixed(2);
    const companyDebit = totalCredit;

    entryHash += parseInt(routingCheck(input.companyRouting), 10);
    entryLines.push(
      this.entryDetail({
        transactionCode: debitCode,
        routing: input.companyRouting,
        accountToken: input.companyAccount.slice(-17),
        amount: companyDebit,
        name: input.companyName.slice(0, 22),
        traceNumber: padLeft(String(trace++), 7),
        profile: input.profile,
      })
    );

    const entryCount = entryLines.length;
    const entryHashTotal = padLeft(String(entryHash % 10_000_000_000), 10);
    const batchNumber = '0000001';
    const fileId = input.companyId.replace(/\D/g, '').slice(0, 10) || '1';

    const fileHeader = this.fileHeader(input, fileId);
    const batchHeader = this.batchHeader(
      input,
      batchNumber,
      entryCount,
      companyDebit
    );
    const batchControl = this.batchControl(
      input,
      batchNumber,
      entryCount,
      entryHashTotal,
      companyDebit,
      totalCredit
    );
    const fileControl = this.fileControl(
      entryCount,
      entryHashTotal,
      companyDebit,
      totalCredit
    );

    const fileContent = [
      fileHeader,
      batchHeader,
      ...entryLines,
      batchControl,
      fileControl,
    ].join('\n');

    return {
      fileContent,
      entryHashTotal,
      controlTotal: totalCredit,
      entryCount,
    };
  }

  private fileHeader(input: NachaBuildInput, fileId: string): string {
    const line =
      '1' +
      '01' +
      padRight(input.companyRouting, 10) +
      padRight('0', 1) +
      padRight(input.companyName, 16) +
      padRight('PAYROLL ENGINE', 20) +
      padLeft(fileId, 10) +
      input.effectiveDate.replace(/-/g, '').slice(4) +
      input.effectiveDate.replace(/-/g, '').slice(0, 4) +
      '0000' +
      '094' +
      '10' +
      '1' +
      ' ' +
      ' ' +
      ' ';
    return padRight(line, RECORD_WIDTH);
  }

  private batchHeader(
    input: NachaBuildInput,
    batchNumber: string,
    entryCount: number,
    total: Money
  ): string {
    const serviceClass = '200';
    const line =
      '5' +
      serviceClass +
      padRight(input.companyName, 16) +
      padRight('', 20) +
      padLeft(input.companyRouting, 10) +
      padRight(input.profile, 3) +
      padRight('PAYROLL', 10) +
      padRight(input.effectiveDate.replace(/-/g, ''), 6) +
      padRight(input.effectiveDate.replace(/-/g, ''), 6) +
      '   1' +
      padLeft(batchNumber, 7) +
      '1' +
      padLeft(input.companyRouting.slice(0, 8), 8) +
      padLeft(String(entryCount), 6) +
      padLeft(routingCheck(input.companyRouting), 10) +
      amountCents(total) +
      padLeft('', 19) +
      padRight('', 6) +
      ' ';
    return padRight(line, RECORD_WIDTH);
  }

  private entryDetail(args: {
    transactionCode: string;
    routing: string;
    accountToken: string;
    amount: Money;
    name: string;
    traceNumber: string;
    profile: NachaProfile;
  }): string {
    const line =
      '6' +
      args.transactionCode +
      padLeft(routingCheck(args.routing), 8) +
      args.routing[8] +
      padRight(args.accountToken, 17) +
      amountCents(args.amount) +
      padRight(args.accountToken.slice(0, 15), 15) +
      padRight(args.name, 22) +
      '  0' +
      padLeft(args.routing.slice(0, 8), 8) +
      args.traceNumber +
      ' ';
    return padRight(line, RECORD_WIDTH);
  }

  private batchControl(
    input: NachaBuildInput,
    batchNumber: string,
    entryCount: number,
    entryHashTotal: string,
    debitTotal: Money,
    creditTotal: Money
  ): string {
    const line =
      '8' +
      '200' +
      padLeft(String(entryCount), 6) +
      entryHashTotal +
      amountCents(debitTotal) +
      amountCents(creditTotal) +
      padLeft(input.companyRouting.slice(0, 10), 10) +
      padLeft('', 19) +
      padRight('', 6) +
      padLeft(batchNumber, 7) +
      padLeft('', 7) +
      ' ';
    return padRight(line, RECORD_WIDTH);
  }

  private fileControl(
    entryCount: number,
    entryHashTotal: string,
    debitTotal: Money,
    creditTotal: Money
  ): string {
    const line =
      '9' +
      '000001' +
      padLeft('1', 6) +
      padLeft(String(entryCount), 8) +
      entryHashTotal +
      amountCents(debitTotal) +
      amountCents(creditTotal) +
      padLeft('', 39);
    return padRight(line, RECORD_WIDTH);
  }

  /** Verify batch control hash matches recomputed entry lines. */
  verifyHash(items: PaymentBatchItem[], companyRouting: string): string {
    let hash = parseInt(routingCheck(companyRouting), 10);
    for (const item of items) {
      hash += parseInt(routingCheck(item.routingNumber), 10);
    }
    return padLeft(String(hash % 10_000_000_000), 10);
  }
}
