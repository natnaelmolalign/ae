import type {
  CreateDisbursementInstructionInput,
  DisbursementInstruction,
  UpdateDisbursementInstructionInput,
} from '../../models/Disbursement';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type { DisbursementInstructionRepository } from '../../repositories/interfaces';

export class DisbursementInstructionService {
  constructor(private readonly repo: DisbursementInstructionRepository) {}

  create(
    input: CreateDisbursementInstructionInput
  ): Promise<DisbursementInstruction> {
    this.validateSplit(input.splitType, input.percent, input.fixedAmount);
    return this.repo.create(input);
  }

  get(id: string, companyId: string): Promise<DisbursementInstruction | null> {
    return this.repo.findById(id, companyId);
  }

  listByEmployee(
    employeeId: string,
    companyId: string
  ): Promise<DisbursementInstruction[]> {
    return this.repo.listByEmployee(employeeId, companyId);
  }

  async update(
    id: string,
    companyId: string,
    input: UpdateDisbursementInstructionInput
  ): Promise<DisbursementInstruction> {
    const existing = await this.repo.findById(id, companyId);
    if (!existing) {
      throw PayrollDomainError.notFound('DisbursementInstruction', id);
    }
    const splitType = input.splitType ?? existing.splitType;
    this.validateSplit(
      splitType,
      input.percent ?? existing.percent,
      input.fixedAmount ?? existing.fixedAmount
    );
    const updated = await this.repo.update(id, companyId, input);
    if (!updated) {
      throw PayrollDomainError.notFound('DisbursementInstruction', id);
    }
    return updated;
  }

  async remove(id: string, companyId: string): Promise<void> {
    const ok = await this.repo.delete(id, companyId);
    if (!ok) {
      throw PayrollDomainError.notFound('DisbursementInstruction', id);
    }
  }

  private validateSplit(
    splitType: string,
    percent: string | null | undefined,
    fixedAmount: string | null | undefined
  ): void {
    if (splitType === 'percent' && !percent) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'percent split requires percent'
      );
    }
    if (splitType === 'fixed' && !fixedAmount) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'fixed split requires fixedAmount'
      );
    }
  }
}
