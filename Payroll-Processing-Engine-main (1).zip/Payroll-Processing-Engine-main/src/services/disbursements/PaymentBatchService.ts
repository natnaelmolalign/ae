import { randomUUID } from 'crypto';
import type {
  AchFile,
  NachaProfile,
  PaymentBatch,
  PaymentReconciliationReport,
} from '../../models/Disbursement';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type {
  DisbursementBatchRepository,
  DisbursementInstructionRepository,
} from '../../repositories/interfaces';
import { DisbursementAllocationService } from './DisbursementAllocationService';
import { NachaFileBuilder } from './NachaFileBuilder';
import { add, compare, sum } from '../../utils/decimalUtils';
import type { WebhookOutboxService } from '../webhooks/WebhookOutboxService';
import { features } from '../../config/features';

export interface CreatePaymentBatchInput {
  companyId: string;
  payPeriodId?: string;
  payrollRunIds?: string[];
  nachaProfile?: NachaProfile;
  idempotencyKey?: string;
  companyRouting?: string;
  companyAccount?: string;
  companyName?: string;
  effectiveDate?: string;
}

export class PaymentBatchService {
  private readonly allocator = new DisbursementAllocationService();
  private readonly nachaBuilder = new NachaFileBuilder();

  constructor(
    private readonly batchRepo: DisbursementBatchRepository,
    private readonly instructionRepo: DisbursementInstructionRepository,
    private readonly webhookOutbox?: WebhookOutboxService
  ) {}

  async createBatch(input: CreatePaymentBatchInput): Promise<PaymentBatch> {
    if (input.idempotencyKey) {
      const existing = await this.batchRepo.findBatchByIdempotencyKey(
        input.companyId,
        input.idempotencyKey
      );
      if (existing) return existing;
    }

    const runs = input.payrollRunIds?.length
      ? await this.batchRepo.listPayrollRunsByIds(
          input.companyId,
          input.payrollRunIds
        )
      : input.payPeriodId
        ? await this.batchRepo.listPayrollRunsForPeriod(
            input.companyId,
            input.payPeriodId
          )
        : [];

    if (runs.length === 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'No payroll runs found for payment batch'
      );
    }

    const batchId = randomUUID();
    const items: Parameters<DisbursementBatchRepository['insertItems']>[0] = [];
    let totalNetPay = '0.00';
    let totalAchCredit = '0.00';

    for (const run of runs) {
      totalNetPay = add(totalNetPay, run.netPay);
      const instructions = await this.instructionRepo.findActiveByEmployee(
        run.employeeId,
        input.companyId
      );
      const instructionById = new Map(instructions.map((i) => [i.id, i]));
      const { allocations } = this.allocator.allocate(run.netPay, instructions);

      for (const alloc of allocations) {
        const inst = instructionById.get(alloc.instructionId)!;
        totalAchCredit = add(totalAchCredit, alloc.amount);
        items.push({
          id: randomUUID(),
          paymentBatchId: batchId,
          payrollRunId: run.payrollRunId,
          payStubId: run.payStubId,
          employeeId: run.employeeId,
          disbursementInstructionId: inst.id,
          amount: alloc.amount,
          status: 'pending',
          accountNumberToken: inst.accountNumberToken,
          routingNumber: inst.routingNumber,
          accountLastFour: inst.accountLastFour,
        });
      }
    }

    if (compare(totalNetPay, totalAchCredit) !== 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.DISBURSEMENT_SPLIT_MISMATCH,
        'Batch ACH credits must equal total net pay',
        { totalNetPay, totalAchCredit }
      );
    }

    const batch = await this.batchRepo.createBatch({
      id: batchId,
      companyId: input.companyId,
      payPeriodId: input.payPeriodId ?? null,
      status: 'draft',
      nachaProfile: input.nachaProfile ?? 'PPD',
      totalNetPay,
      totalAchCredit,
      payrollRunCount: runs.length,
      idempotencyKey: input.idempotencyKey ?? null,
    });

    await this.batchRepo.insertItems(items);
    return batch;
  }

  async getBatch(id: string, companyId: string): Promise<PaymentBatch> {
    const batch = await this.batchRepo.findBatchById(id, companyId);
    if (!batch) {
      throw PayrollDomainError.notFound('PaymentBatch', id);
    }
    return batch;
  }

  async submitBatch(
    id: string,
    companyId: string,
    opts: {
      companyRouting: string;
      companyAccount: string;
      companyName: string;
      effectiveDate: string;
    }
  ): Promise<{ batch: PaymentBatch; achFile: AchFile }> {
    const batch = await this.getBatch(id, companyId);
    if (batch.status !== 'draft') {
      throw new PayrollDomainError(
        PayrollErrorCode.PAYMENT_BATCH_INVALID_STATE,
        `Payment batch is ${batch.status}, expected draft`
      );
    }

    const items = await this.batchRepo.listItemsByBatch(id);
    const employeeNames: Record<string, string> = {};
    const runs = await this.batchRepo.listPayrollRunsByIds(companyId, [
      ...new Set(items.map((i) => i.payrollRunId)),
    ]);
    for (const run of runs) {
      employeeNames[run.employeeId] = `${run.firstName} ${run.lastName}`;
    }

    const nacha = this.nachaBuilder.build({
      profile: batch.nachaProfile,
      companyName: opts.companyName,
      companyId,
      companyRouting: opts.companyRouting,
      companyAccount: opts.companyAccount,
      effectiveDate: opts.effectiveDate,
      items,
      employeeNames,
    });

    const verifiedHash = this.nachaBuilder.verifyHash(
      items,
      opts.companyRouting
    );
    if (verifiedHash !== nacha.entryHashTotal) {
      throw new PayrollDomainError(
        PayrollErrorCode.PAY_STUB_RECONCILIATION_FAILED,
        'NACHA entry hash does not match control record'
      );
    }

    const achFile = await this.batchRepo.saveAchFile({
      id: randomUUID(),
      paymentBatchId: id,
      fileFormat: 'nacha',
      nachaProfile: batch.nachaProfile,
      fileContent: nacha.fileContent,
      entryHashTotal: nacha.entryHashTotal,
      controlTotal: nacha.controlTotal,
      entryCount: nacha.entryCount,
    });

    const submittedAt = new Date().toISOString();
    const updated = await this.batchRepo.updateBatchStatus(
      id,
      companyId,
      'submitted',
      submittedAt
    );
    await this.batchRepo.updateItemStatuses(id, 'submitted');

    if (features.webhooksEnabled && this.webhookOutbox) {
      try {
        await this.webhookOutbox.enqueuePaymentBatchSubmitted(companyId, {
          paymentBatchId: id,
          payPeriodId: batch.payPeriodId,
          totalNetPay: batch.totalNetPay,
          totalAchCredit: batch.totalAchCredit,
          entryCount: nacha.entryCount,
          submittedAt,
        });
      } catch {
        await this.batchRepo.updateBatchStatus(id, companyId, 'failed');
        throw new PayrollDomainError(
          PayrollErrorCode.SERVICE_UNAVAILABLE,
          'ACH file saved but webhook enqueue failed; batch marked failed for retry',
          { paymentBatchId: id }
        );
      }
    }

    return { batch: updated!, achFile };
  }

  async reconcile(
    id: string,
    companyId: string
  ): Promise<PaymentReconciliationReport> {
    const batch = await this.getBatch(id, companyId);
    const achFile = await this.batchRepo.findAchFileByBatch(id);
    const items = await this.batchRepo.listItemsByBatch(id);
    const payrollLiabilityTotal = sum(items.map((i) => i.amount));

    const balanced =
      compare(batch.totalNetPay, batch.totalAchCredit) === 0 &&
      compare(batch.totalAchCredit, payrollLiabilityTotal) === 0;

    if (balanced && batch.status === 'submitted') {
      await this.batchRepo.updateBatchStatus(id, companyId, 'reconciled');
    }

    return {
      paymentBatchId: id,
      totalNetPay: batch.totalNetPay,
      totalAchCredit: batch.totalAchCredit,
      payrollLiabilityTotal,
      balanced,
      entryCount: achFile?.entryCount ?? items.length,
      entryHashTotal: achFile?.entryHashTotal ?? '0000000000',
      controlTotal: achFile?.controlTotal ?? batch.totalAchCredit,
    };
  }

  async getAchFile(batchId: string, companyId: string): Promise<AchFile> {
    await this.getBatch(batchId, companyId);
    const file = await this.batchRepo.findAchFileByBatch(batchId);
    if (!file) {
      throw PayrollDomainError.notFound('AchFile', batchId);
    }
    return file;
  }
}
