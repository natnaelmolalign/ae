import type { DisbursementInstruction } from '../../models/Disbursement';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import {
  compare,
  minMoney,
  mul,
  sub,
  sum,
  type Money,
} from '../../utils/decimalUtils';

export interface DisbursementAllocation {
  instructionId: string;
  amount: Money;
}

export interface AllocationResult {
  allocations: DisbursementAllocation[];
  totalAllocated: Money;
}

export class DisbursementAllocationService {
  allocate(
    netPay: Money,
    instructions: DisbursementInstruction[]
  ): AllocationResult {
    const active = instructions.filter((i) => i.isActive);
    if (active.length === 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.NO_DISBURSEMENT_INSTRUCTIONS,
        'Employee has no active disbursement instructions'
      );
    }

    const remainderCount = active.filter(
      (i) => i.splitType === 'remainder'
    ).length;
    if (remainderCount > 1) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'At most one remainder disbursement instruction is allowed'
      );
    }

    const sorted = [...active].sort((a, b) => a.priority - b.priority);
    const allocations: DisbursementAllocation[] = [];
    let remaining = netPay;

    for (const inst of sorted) {
      if (inst.splitType === 'remainder') {
        continue;
      }
      let amount: Money;
      if (inst.splitType === 'fixed') {
        if (!inst.fixedAmount) {
          throw new PayrollDomainError(
            PayrollErrorCode.INVALID_INPUT,
            'fixed disbursement requires fixedAmount'
          );
        }
        amount = minMoney(inst.fixedAmount, remaining);
      } else if (inst.splitType === 'percent') {
        if (!inst.percent) {
          throw new PayrollDomainError(
            PayrollErrorCode.INVALID_INPUT,
            'percent disbursement requires percent'
          );
        }
        amount = minMoney(mul(netPay, inst.percent), remaining);
      } else {
        continue;
      }
      if (compare(amount, '0.00') > 0) {
        allocations.push({ instructionId: inst.id, amount });
        remaining = sub(remaining, amount);
      }
    }

    const remainder = sorted.find((i) => i.splitType === 'remainder');
    if (remainder) {
      allocations.push({ instructionId: remainder.id, amount: remaining });
      remaining = '0.00';
    }

    const totalAllocated = sum(allocations.map((a) => a.amount));
    if (compare(totalAllocated, netPay) !== 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.DISBURSEMENT_SPLIT_MISMATCH,
        'Disbursement splits must sum to net pay exactly',
        { netPay, totalAllocated, remaining }
      );
    }

    return { allocations, totalAllocated };
  }
}
