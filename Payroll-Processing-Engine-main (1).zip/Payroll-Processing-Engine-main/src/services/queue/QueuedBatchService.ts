import { randomUUID } from 'crypto';
import type { PayPeriod } from '../../models/types';
import type { PayrollBatch } from '../../models/PayrollBatch';
import { buildPartitionKey, type JobQueue } from '../../queue/JobQueue';
import type {
  EmployeePayrollReadinessRepository,
  PayrollBatchRepository,
} from '../../repositories/interfaces';

export interface EnqueueBatchInput {
  companyId: string;
  payPeriod: PayPeriod;
  year: number;
  frequency: string;
  employeeIds?: string[];
}

export interface EnqueueBatchResult {
  batch: PayrollBatch;
  enqueued: number;
}

export class QueuedBatchService {
  constructor(
    private readonly batchRepo: PayrollBatchRepository,
    private readonly readinessRepo: EmployeePayrollReadinessRepository,
    private readonly jobQueue: JobQueue
  ) {}

  async enqueueBatch(input: EnqueueBatchInput): Promise<EnqueueBatchResult> {
    const employeeIds =
      input.employeeIds ??
      (await this.readinessRepo.findReadyEmployeeIds(input.payPeriod.id));

    const batchId = randomUUID();
    const partitionKey = buildPartitionKey(input.companyId, input.payPeriod.id);
    const startedAt = new Date().toISOString();

    const batch = await this.batchRepo.create({
      id: batchId,
      companyId: input.companyId,
      payPeriodId: input.payPeriod.id,
      year: input.year,
      frequency: input.frequency,
      status: employeeIds.length === 0 ? 'completed' : 'running',
      startedAt: employeeIds.length === 0 ? startedAt : startedAt,
      completedAt: employeeIds.length === 0 ? startedAt : null,
      successCount: 0,
      failureCount: 0,
      totalCount: employeeIds.length,
      durationMs: employeeIds.length === 0 ? 0 : null,
    });

    for (const employeeId of employeeIds) {
      await this.jobQueue.enqueue({
        jobType: 'payroll_batch_employee',
        partitionKey,
        payload: {
          batchId,
          employeeId,
          companyId: input.companyId,
          payPeriodId: input.payPeriod.id,
          year: input.year,
          frequency: input.frequency,
        },
      });
    }

    return { batch, enqueued: employeeIds.length };
  }
}
