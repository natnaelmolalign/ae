import { randomUUID } from 'crypto';
import type { PayPeriod } from '../../models/types';
import type { QueueJob } from '../../models/QueueJob';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import { getPayrollMetrics } from '../../metrics/hooks';
import { incrementQueueDlqTotal } from '../../metrics/prometheus';
import type { JobQueue } from '../../queue/JobQueue';
import type {
  EmployeePayrollReadinessRepository,
  EmployeeRepository,
  PayPeriodRepository,
  PayrollBatchRepository,
  PayrollRunFailureRepository,
} from '../../repositories/interfaces';
import { employeeForTenant } from '../../utils/tenant';
import { PayrollRunService } from '../PayrollRunService';
import { WebhookDeliveryWorker } from '../webhooks/WebhookDeliveryWorker';
import { WebhookOutboxService } from '../webhooks/WebhookOutboxService';
import type { ControlService } from '../controls/ControlService';

export class JobWorkerService {
  constructor(
    private readonly jobQueue: JobQueue,
    private readonly batchRepo: PayrollBatchRepository,
    private readonly failureRepo: PayrollRunFailureRepository,
    private readonly readinessRepo: EmployeePayrollReadinessRepository,
    private readonly employeeRepo: EmployeeRepository,
    private readonly payPeriodRepo: PayPeriodRepository,
    private readonly payrollRunService: PayrollRunService,
    private readonly webhookOutbox?: WebhookOutboxService,
    private readonly webhookWorker?: WebhookDeliveryWorker,
    private readonly controlService?: ControlService
  ) {}

  async processOne(workerId: string): Promise<boolean> {
    const job = await this.jobQueue.poll(workerId);
    if (!job) return false;

    try {
      await this.dispatch(job);
      await this.jobQueue.complete(job.id);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      const outcome = await this.jobQueue.fail(job.id, message);
      if (outcome === 'dlq') {
        incrementQueueDlqTotal(job.jobType);
      }
    }
    return true;
  }

  async runLoop(
    workerId: string,
    options: { maxIterations?: number; idleMs?: number } = {}
  ): Promise<number> {
    const max = options.maxIterations ?? Number.POSITIVE_INFINITY;
    const idleMs = options.idleMs ?? 100;
    let processed = 0;
    for (let i = 0; i < max; i += 1) {
      const worked = await this.processOne(workerId);
      if (worked) {
        processed += 1;
      } else if (idleMs > 0) {
        await new Promise((r) => setTimeout(r, idleMs));
      } else {
        break;
      }
    }
    return processed;
  }

  private async dispatch(job: QueueJob): Promise<void> {
    if (job.jobType === 'payroll_batch_employee') {
      await this.handleBatchEmployee(job);
      return;
    }
    if (job.jobType === 'webhook_delivery') {
      await this.handleWebhook(job);
      return;
    }
    throw new PayrollDomainError(
      PayrollErrorCode.INVALID_INPUT,
      `Unknown job type ${job.jobType}`
    );
  }

  private async handleBatchEmployee(job: QueueJob): Promise<void> {
    const batchId = String(job.payload.batchId);
    const employeeId = String(job.payload.employeeId);
    const companyId = String(job.payload.companyId);
    const payPeriodId = String(job.payload.payPeriodId);

    const batch = await this.batchRepo.findById(batchId);
    if (!batch) {
      throw PayrollDomainError.notFound('Payroll batch', batchId);
    }

    const payPeriodRow = await this.payPeriodRepo.findById(payPeriodId);
    if (!payPeriodRow) {
      throw PayrollDomainError.notFound('Pay period', payPeriodId);
    }
    const payPeriod: PayPeriod = payPeriodRow;

    const employeeResolved = employeeForTenant(
      await this.employeeRepo.findById(employeeId),
      companyId
    );
    const idempotencyKey = `batch-${batchId}-${employeeId}`;

    if (!employeeResolved) {
      await this.recordFailure(
        batchId,
        employeeId,
        payPeriodId,
        idempotencyKey,
        PayrollDomainError.notFound('Employee', employeeId)
      );
      await this.incrementBatchFailure(batchId, batch);
      return;
    }

    if (this.controlService) {
      try {
        await this.controlService.assertRunAllowed({
          employeeId,
          companyId,
          payPeriodId,
          grossAmount: employeeResolved.baseCompensation,
          actor: 'worker',
        });
      } catch (err) {
        if (err instanceof PayrollDomainError) {
          await this.recordFailure(
            batchId,
            employeeId,
            payPeriodId,
            idempotencyKey,
            err
          );
          await this.incrementBatchFailure(batchId, batch);
          return;
        }
        throw err;
      }
    }

    try {
      await this.payrollRunService.run(
        employeeResolved,
        payPeriod,
        {
          employeeId,
          payPeriodId,
          earnings: [
            { type: 'regular', amount: employeeResolved.baseCompensation },
          ],
          deductions: [],
          garnishments: [],
        },
        { idempotencyKey, metricsSource: 'batch' }
      );
      await this.readinessRepo.markProcessed(employeeId, payPeriodId);
      await this.incrementBatchSuccess(batchId, batch);
    } catch (err) {
      const domain =
        err instanceof PayrollDomainError
          ? err
          : new PayrollDomainError(
              PayrollErrorCode.INVALID_INPUT,
              err instanceof Error ? err.message : String(err),
              { employeeId }
            );
      await this.recordFailure(
        batchId,
        employeeId,
        payPeriodId,
        idempotencyKey,
        domain
      );
      await this.incrementBatchFailure(batchId, batch);
    }
  }

  private async handleWebhook(_job: QueueJob): Promise<void> {
    if (!this.webhookWorker) return;
    await this.webhookWorker.processPending(1);
  }

  private async incrementBatchSuccess(
    batchId: string,
    batch: NonNullable<Awaited<ReturnType<PayrollBatchRepository['findById']>>>
  ): Promise<void> {
    const successCount = batch.successCount + 1;
    const updated = await this.batchRepo.update(batchId, { successCount });
    if (updated) {
      await this.maybeFinalizeBatch(updated);
    }
  }

  private async incrementBatchFailure(
    batchId: string,
    batch: NonNullable<Awaited<ReturnType<PayrollBatchRepository['findById']>>>
  ): Promise<void> {
    const failureCount = batch.failureCount + 1;
    const updated = await this.batchRepo.update(batchId, { failureCount });
    if (updated) {
      await this.maybeFinalizeBatch(updated);
    }
  }

  private async maybeFinalizeBatch(
    batch: NonNullable<Awaited<ReturnType<PayrollBatchRepository['findById']>>>
  ): Promise<void> {
    if (batch.status === 'completed' || batch.status === 'failed') return;
    const done = batch.successCount + batch.failureCount;
    if (done < batch.totalCount) return;

    const completedAt = new Date().toISOString();
    const startedAt = batch.startedAt ?? completedAt;
    const durationMs =
      new Date(completedAt).getTime() - new Date(startedAt).getTime();
    const finalStatus =
      batch.failureCount > 0 && batch.successCount === 0
        ? 'failed'
        : 'completed';

    const finalized = await this.batchRepo.update(batch.id, {
      status: finalStatus,
      completedAt,
      durationMs,
    });
    if (!finalized) return;

    getPayrollMetrics().recordBatchComplete?.(
      durationMs,
      finalized.successCount,
      finalized.failureCount,
      { payPeriodId: finalized.payPeriodId }
    );

    if (this.webhookOutbox) {
      await this.webhookOutbox.enqueueBatchCompleted(finalized.companyId, {
        batchId: finalized.id,
        payPeriodId: finalized.payPeriodId,
        status: finalStatus,
        successCount: finalized.successCount,
        failureCount: finalized.failureCount,
        totalCount: finalized.totalCount,
      });
    }
  }

  private async recordFailure(
    batchId: string,
    employeeId: string,
    payPeriodId: string,
    idempotencyKey: string,
    err: PayrollDomainError
  ): Promise<void> {
    await this.failureRepo.insert({
      id: randomUUID(),
      batchId,
      employeeId,
      payPeriodId,
      idempotencyKey,
      errorCode: err.code,
      errorMessage: err.message,
      payload: err.details ?? null,
      retryable: err.code !== 'DUPLICATE_PAYROLL_RUN',
    });
  }
}
