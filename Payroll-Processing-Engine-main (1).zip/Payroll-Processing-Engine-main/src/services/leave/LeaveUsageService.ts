import type { Knex } from 'knex';
import type { EarningsLine, Employee, PayPeriod } from '../../models/types';
import type { LeaveType } from '../../models/LeavePolicy';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type {
  LeaveBalanceRepository,
  LeavePolicyRepository,
  LeaveTransactionRepository,
} from '../../repositories/interfaces';
import { calendarYearFromDate, nextBalanceAfterUsage } from './AccrualEngine';
import { compare, d } from '../../utils/decimalUtils';
import { features } from '../../config/features';

const LEAVE_EARNING_TYPES: Record<'pto' | 'sick', LeaveType> = {
  pto: 'pto',
  sick: 'sick',
};

export interface LeaveUsageByType {
  leaveType: LeaveType;
  hours: string;
}

export function extractLeaveUsage(
  earnings: EarningsLine[]
): LeaveUsageByType[] {
  const totals = new Map<LeaveType, number>();
  for (const line of earnings) {
    if (line.type !== 'pto' && line.type !== 'sick') continue;
    const leaveType = LEAVE_EARNING_TYPES[line.type];
    const hours = line.hours ?? 0;
    if (hours <= 0) continue;
    totals.set(leaveType, (totals.get(leaveType) ?? 0) + hours);
  }
  return [...totals.entries()].map(([leaveType, hours]) => ({
    leaveType,
    hours: d(hours).toFixed(2),
  }));
}

export class LeaveUsageService {
  constructor(
    private readonly policyRepo: LeavePolicyRepository,
    private readonly balanceRepo: LeaveBalanceRepository,
    private readonly transactionRepo: LeaveTransactionRepository
  ) {}

  async assertSufficientBalance(
    employee: Employee,
    payPeriod: PayPeriod,
    earnings: EarningsLine[]
  ): Promise<void> {
    if (!features.leaveAccrualsEnabled) return;
    const usages = extractLeaveUsage(earnings);
    if (usages.length === 0) return;

    const year = calendarYearFromDate(payPeriod.paymentDate);
    for (const usage of usages) {
      const policy = await this.policyRepo.findActiveByType(
        employee.companyId,
        usage.leaveType,
        payPeriod.paymentDate
      );
      if (!policy) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          `No active leave policy for ${usage.leaveType}`,
          { leaveType: usage.leaveType }
        );
      }
      const balance = await this.balanceRepo.listByEmployee(
        employee.id,
        employee.companyId,
        year
      );
      const row = balance.find((b) => b.leaveType === usage.leaveType);
      const available = row?.balanceHours ?? '0.00';
      if (compare(available, usage.hours) < 0) {
        throw new PayrollDomainError(
          PayrollErrorCode.INSUFFICIENT_LEAVE_BALANCE,
          `Insufficient ${usage.leaveType} balance: need ${usage.hours}, have ${available}`,
          { leaveType: usage.leaveType, required: usage.hours, available }
        );
      }
    }
  }

  async recordUsageFromPayroll(
    trx: Knex.Transaction,
    employee: Employee,
    payPeriod: PayPeriod,
    payrollRunId: string,
    earnings: EarningsLine[]
  ): Promise<void> {
    if (!features.leaveAccrualsEnabled) return;
    const usages = extractLeaveUsage(earnings);
    if (usages.length === 0) return;

    const year = calendarYearFromDate(payPeriod.paymentDate);
    for (const usage of usages) {
      const policy = await this.policyRepo.findActiveByType(
        employee.companyId,
        usage.leaveType,
        payPeriod.paymentDate,
        trx
      );
      if (!policy) continue;

      const balance = await this.balanceRepo.getForUpdate(
        trx,
        employee.id,
        usage.leaveType,
        year
      );
      if (!balance) continue;

      const next = nextBalanceAfterUsage(balance.balanceHours, usage.hours);
      balance.balanceHours = next;
      await this.balanceRepo.save(trx, balance);
      await this.transactionRepo.insert(trx, {
        companyId: employee.companyId,
        employeeId: employee.id,
        leaveType: usage.leaveType,
        policyId: policy.id,
        calendarYear: year,
        transactionType: 'usage',
        hours: `-${usage.hours}`,
        balanceAfter: next,
        payPeriodId: payPeriod.id,
        payrollRunId,
        notes: 'Payroll run usage',
        actor: null,
      });
    }
  }
}
