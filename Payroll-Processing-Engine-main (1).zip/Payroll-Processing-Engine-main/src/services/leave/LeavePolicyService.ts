import type { LeavePolicy } from '../../models/LeavePolicy';
import { PayrollDomainError } from '../../errors/PayrollDomainError';
import type { LeavePolicyRepository } from '../../repositories/interfaces';

export class LeavePolicyService {
  constructor(private readonly repo: LeavePolicyRepository) {}

  create(
    input: Omit<LeavePolicy, 'id' | 'createdAt' | 'updatedAt'>
  ): Promise<LeavePolicy> {
    return this.repo.create(input);
  }

  async update(
    id: string,
    companyId: string,
    patch: Parameters<LeavePolicyRepository['update']>[2]
  ): Promise<LeavePolicy> {
    const updated = await this.repo.update(id, companyId, patch);
    if (!updated) {
      throw PayrollDomainError.notFound('LeavePolicy', id);
    }
    return updated;
  }

  get(id: string, companyId: string): Promise<LeavePolicy | null> {
    return this.repo.findById(id, companyId);
  }

  list(companyId: string): Promise<LeavePolicy[]> {
    return this.repo.listByCompany(companyId);
  }
}
