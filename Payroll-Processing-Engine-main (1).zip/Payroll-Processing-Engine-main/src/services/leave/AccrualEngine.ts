import { differenceInMonths, parseISO } from 'date-fns';
import type {
  FixedAccrualConfig,
  LeavePolicy,
  TenureBandsAccrualConfig,
} from '../../models/LeavePolicy';
import { add, compare, sub } from '../../utils/decimalUtils';

export function tenureMonths(hireDate: string, asOfDate: string): number {
  return Math.max(
    0,
    differenceInMonths(parseISO(asOfDate), parseISO(hireDate))
  );
}

/**
 * Hours earned for one pay period from policy accrual rules.
 */
export function accrualHoursForPeriod(
  policy: LeavePolicy,
  hireDate: string,
  paymentDate: string
): string {
  if (policy.accrualMethod === 'fixed_per_period') {
    return (policy.accrualConfig as FixedAccrualConfig).hoursPerPeriod;
  }
  const config = policy.accrualConfig as TenureBandsAccrualConfig;
  const months = tenureMonths(hireDate, paymentDate);
  const sorted = [...config.bands].sort(
    (a, b) => b.minTenureMonths - a.minTenureMonths
  );
  const band = sorted.find((b) => months >= b.minTenureMonths);
  return band?.hoursPerPeriod ?? sorted[sorted.length - 1]!.hoursPerPeriod;
}

/**
 * Apply carryover cap at calendar year boundary.
 * Returns { carried, forfeited } from prior-year closing balance.
 */
export function applyCarryoverCap(
  closingBalance: string,
  carryoverMaxHours: string | null
): { carried: string; forfeited: string } {
  if (!carryoverMaxHours || compare(carryoverMaxHours, '0') <= 0) {
    return { carried: closingBalance, forfeited: '0.00' };
  }
  if (compare(closingBalance, carryoverMaxHours) <= 0) {
    return { carried: closingBalance, forfeited: '0.00' };
  }
  return {
    carried: carryoverMaxHours,
    forfeited: sub(closingBalance, carryoverMaxHours),
  };
}

export function sumTransactionHours(
  transactions: Array<{ hours: string }>
): string {
  return transactions.reduce((sum, tx) => add(sum, tx.hours), '0.00');
}

export function nextBalanceAfterUsage(
  currentBalance: string,
  usageHours: string
): string {
  return sub(currentBalance, usageHours);
}

export function nextBalanceAfterAccrual(
  currentBalance: string,
  accrualHours: string
): string {
  return add(currentBalance, accrualHours);
}

export function calendarYearFromDate(date: string): number {
  return parseISO(date.slice(0, 10)).getFullYear();
}
