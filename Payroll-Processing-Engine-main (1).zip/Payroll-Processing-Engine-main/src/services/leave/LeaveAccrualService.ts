import type { Knex } from 'knex';
import type { Employee, PayPeriod } from '../../models/types';
import type { LeavePolicy } from '../../models/LeavePolicy';
import type {
  EmployeeRepository,
  LeaveBalanceRepository,
  LeavePolicyRepository,
  LeaveTransactionRepository,
} from '../../repositories/interfaces';
import {
  accrualHoursForPeriod,
  applyCarryoverCap,
  calendarYearFromDate,
  nextBalanceAfterAccrual,
} from './AccrualEngine';
import { features } from '../../config/features';

export interface AccrualRunResult {
  payPeriodId: string;
  employeesProcessed: number;
  accrualsPosted: number;
  carryoversApplied: number;
  skippedDuplicate: number;
}

export class LeaveAccrualService {
  constructor(
    private readonly db: Knex,
    private readonly policyRepo: LeavePolicyRepository,
    private readonly balanceRepo: LeaveBalanceRepository,
    private readonly transactionRepo: LeaveTransactionRepository,
    private readonly employeeRepo: EmployeeRepository
  ) {}

  async runForPayPeriod(
    companyId: string,
    payPeriod: PayPeriod
  ): Promise<AccrualRunResult> {
    if (!features.leaveAccrualsEnabled) {
      return {
        payPeriodId: payPeriod.id,
        employeesProcessed: 0,
        accrualsPosted: 0,
        carryoversApplied: 0,
        skippedDuplicate: 0,
      };
    }

    const policies = await this.policyRepo.listActiveForAccrual(
      companyId,
      payPeriod.paymentDate
    );
    if (policies.length === 0) {
      return {
        payPeriodId: payPeriod.id,
        employeesProcessed: 0,
        accrualsPosted: 0,
        carryoversApplied: 0,
        skippedDuplicate: 0,
      };
    }

    const employees = await this.employeeRepo.listByCompany(companyId);
    let accrualsPosted = 0;
    let carryoversApplied = 0;
    let skippedDuplicate = 0;

    for (const employee of employees) {
      if (
        employee.terminationDate &&
        employee.terminationDate < payPeriod.paymentDate
      ) {
        continue;
      }
      for (const policy of policies) {
        const posted = await this.db.transaction(async (trx) => {
          const dup = await this.transactionRepo.findAccrualForPeriod(
            trx,
            employee.id,
            policy.id,
            payPeriod.id
          );
          if (dup) {
            return { kind: 'duplicate' as const };
          }

          const year = calendarYearFromDate(payPeriod.paymentDate);
          const carryover = await this.applyYearCarryoverIfNeeded(
            trx,
            employee,
            policy,
            year
          );

          const balance = await this.balanceRepo.getOrCreate(trx, {
            companyId,
            employeeId: employee.id,
            leaveType: policy.leaveType,
            policyId: policy.id,
            calendarYear: year,
          });

          const hours = accrualHoursForPeriod(
            policy,
            employee.hireDate,
            payPeriod.paymentDate
          );
          const next = nextBalanceAfterAccrual(balance.balanceHours, hours);
          balance.balanceHours = next;
          await this.balanceRepo.save(trx, balance);
          await this.transactionRepo.insert(trx, {
            companyId,
            employeeId: employee.id,
            leaveType: policy.leaveType,
            policyId: policy.id,
            calendarYear: year,
            transactionType: 'accrual',
            hours,
            balanceAfter: next,
            payPeriodId: payPeriod.id,
            payrollRunId: null,
            notes: `Accrual for ${payPeriod.id}`,
            actor: 'accrual-run',
          });
          return { kind: 'posted' as const, carryover };
        });
        if (posted.kind === 'duplicate') {
          skippedDuplicate += 1;
        } else {
          accrualsPosted += 1;
          if (posted.carryover) carryoversApplied += 1;
        }
      }
    }

    return {
      payPeriodId: payPeriod.id,
      employeesProcessed: employees.length,
      accrualsPosted,
      carryoversApplied,
      skippedDuplicate,
    };
  }

  async adjustBalance(
    trx: Knex.Transaction,
    input: {
      companyId: string;
      employeeId: string;
      leaveType: LeavePolicy['leaveType'];
      policyId: string;
      calendarYear: number;
      hoursDelta: string;
      actor: string;
      notes: string;
    }
  ): Promise<{ balanceHours: string }> {
    const balance = await this.balanceRepo.getOrCreate(trx, {
      companyId: input.companyId,
      employeeId: input.employeeId,
      leaveType: input.leaveType,
      policyId: input.policyId,
      calendarYear: input.calendarYear,
    });
    const next = nextBalanceAfterAccrual(
      balance.balanceHours,
      input.hoursDelta
    );
    balance.balanceHours = next;
    await this.balanceRepo.save(trx, balance);
    await this.transactionRepo.insert(trx, {
      companyId: input.companyId,
      employeeId: input.employeeId,
      leaveType: input.leaveType,
      policyId: input.policyId,
      calendarYear: input.calendarYear,
      transactionType: 'adjustment',
      hours: input.hoursDelta,
      balanceAfter: next,
      payPeriodId: null,
      payrollRunId: null,
      notes: input.notes,
      actor: input.actor,
    });
    return { balanceHours: next };
  }

  private async applyYearCarryoverIfNeeded(
    trx: Knex.Transaction,
    employee: Employee,
    policy: LeavePolicy,
    year: number
  ): Promise<boolean> {
    const priorYear = year - 1;
    const prior = await this.balanceRepo.getForUpdate(
      trx,
      employee.id,
      policy.leaveType,
      priorYear
    );
    if (!prior || prior.balanceHours === '0.00') {
      return false;
    }

    const existing = await this.balanceRepo.getForUpdate(
      trx,
      employee.id,
      policy.leaveType,
      year
    );
    if (existing && existing.balanceHours !== '0.00') {
      return false;
    }

    const { carried, forfeited } = applyCarryoverCap(
      prior.balanceHours,
      policy.carryoverMaxHours
    );

    const balance = await this.balanceRepo.getOrCreate(trx, {
      companyId: employee.companyId,
      employeeId: employee.id,
      leaveType: policy.leaveType,
      policyId: policy.id,
      calendarYear: year,
    });
    balance.balanceHours = carried;
    await this.balanceRepo.save(trx, balance);

    if (carried !== '0.00') {
      await this.transactionRepo.insert(trx, {
        companyId: employee.companyId,
        employeeId: employee.id,
        leaveType: policy.leaveType,
        policyId: policy.id,
        calendarYear: year,
        transactionType: 'carryover',
        hours: carried,
        balanceAfter: carried,
        payPeriodId: null,
        payrollRunId: null,
        notes: `Carryover from ${priorYear}`,
        actor: 'accrual-run',
      });
    }
    if (forfeited !== '0.00') {
      await this.transactionRepo.insert(trx, {
        companyId: employee.companyId,
        employeeId: employee.id,
        leaveType: policy.leaveType,
        policyId: policy.id,
        calendarYear: priorYear,
        transactionType: 'forfeit',
        hours: `-${forfeited}`,
        balanceAfter: carried,
        payPeriodId: null,
        payrollRunId: null,
        notes: `Forfeit above carryover cap`,
        actor: 'accrual-run',
      });
    }
    return true;
  }
}
