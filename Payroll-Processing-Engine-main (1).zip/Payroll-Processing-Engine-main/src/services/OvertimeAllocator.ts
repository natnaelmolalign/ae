import { getJurisdiction, type JurisdictionRule } from '../data/jurisdictions';
import type { TimeEntry } from '../models/types';
import type { Money } from '../utils/decimalUtils';
import { HourlyPayCalculator } from './HourlyPayCalculator';

export interface WeeklyHoursBucket {
  weekKey: string;
  regularMinutes: number;
  overtimeMinutes: number;
}

export interface OvertimeAllocationResult {
  regularMinutes: number;
  overtimeMinutes: number;
  regularPay: Money;
  overtimePay: Money;
}

/**
 * Weekly overtime: minutes beyond threshold in a work week earn OT multiplier.
 * Work week starts on jurisdiction.workWeekStartDay (default Monday).
 */
export class OvertimeAllocator {
  constructor(private readonly hourly = new HourlyPayCalculator()) {}

  allocateWeekly(
    entries: TimeEntry[],
    hourlyRate: Money,
    stateCode: string
  ): OvertimeAllocationResult {
    const jurisdiction = getJurisdiction(stateCode);
    const thresholdMinutes = jurisdiction.weeklyOtThresholdHours * 60;

    const byWeek = this.groupMinutesByWorkWeek(entries, jurisdiction);
    let regularMinutes = 0;
    let overtimeMinutes = 0;

    for (const bucket of byWeek.values()) {
      const total = bucket.regularMinutes;
      if (total <= thresholdMinutes) {
        regularMinutes += total;
      } else {
        regularMinutes += thresholdMinutes;
        overtimeMinutes += total - thresholdMinutes;
      }
    }

    const regularPay = this.hourly.payForMinutes(
      hourlyRate,
      regularMinutes,
      '1.0'
    );
    const overtimePay = this.hourly.payForMinutes(
      hourlyRate,
      overtimeMinutes,
      jurisdiction.otMultiplier
    );

    return { regularMinutes, overtimeMinutes, regularPay, overtimePay };
  }

  groupMinutesByWorkWeek(
    entries: TimeEntry[],
    jurisdiction: JurisdictionRule
  ): Map<string, WeeklyHoursBucket> {
    const map = new Map<string, WeeklyHoursBucket>();

    for (const entry of entries) {
      if (entry.entryType === 'holiday') continue;
      const weekKey = workWeekKey(
        entry.workDate,
        jurisdiction.workWeekStartDay
      );
      const existing = map.get(weekKey) ?? {
        weekKey,
        regularMinutes: 0,
        overtimeMinutes: 0,
      };
      existing.regularMinutes += entry.roundedMinutes;
      map.set(weekKey, existing);
    }

    return map;
  }
}

export function workWeekKey(workDate: string, startDay: number): string {
  const d = new Date(`${workDate}T12:00:00Z`);
  const day = d.getUTCDay();
  const diff = (day - startDay + 7) % 7;
  d.setUTCDate(d.getUTCDate() - diff);
  return d.toISOString().slice(0, 10);
}
