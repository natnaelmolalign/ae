import type {
  PayPolicy,
  PayPolicyRunContext,
  PayPolicyViolation,
} from '../../models/PayPolicy';
import { compare, isPositive, isZero } from '../../utils/decimalUtils';

const HOURLY_TYPES = new Set(['full_time_hourly', 'part_time']);

/**
 * Pure policy evaluation — no I/O.
 */
export function evaluatePayPolicies(
  policies: PayPolicy[],
  context: PayPolicyRunContext
): PayPolicyViolation[] {
  const violations: PayPolicyViolation[] = [];
  const ordered = [...policies].sort((a, b) => b.priority - a.priority);

  for (const policy of ordered) {
    for (const rule of policy.rules) {
      const violation = evaluateRule(policy, rule, context);
      if (violation) {
        violations.push(violation);
      }
    }
  }

  return violations;
}

function evaluateRule(
  policy: PayPolicy,
  rule: PayPolicy['rules'][number],
  context: PayPolicyRunContext
): PayPolicyViolation | null {
  switch (rule.type) {
    case 'require_positive_gross':
      if (!isPositive(context.grossEarnings) || isZero(context.grossEarnings)) {
        return violation(policy, rule.type, 'Gross earnings must be positive');
      }
      return null;
    case 'min_gross':
      if (compare(context.grossEarnings, rule.params.amount) < 0) {
        return violation(
          policy,
          rule.type,
          `Gross ${context.grossEarnings} is below minimum ${rule.params.amount}`
        );
      }
      return null;
    case 'max_gross':
      if (compare(context.grossEarnings, rule.params.amount) > 0) {
        return violation(
          policy,
          rule.type,
          `Gross ${context.grossEarnings} exceeds maximum ${rule.params.amount}`
        );
      }
      return null;
    case 'min_hourly_rate':
      if (!HOURLY_TYPES.has(context.employmentType)) {
        return null;
      }
      if (compare(context.baseCompensation, rule.params.rate) < 0) {
        return violation(
          policy,
          rule.type,
          `Hourly rate ${context.baseCompensation} is below minimum ${rule.params.rate}`
        );
      }
      return null;
    default:
      return null;
  }
}

function violation(
  policy: PayPolicy,
  ruleType: PayPolicyViolation['ruleType'],
  message: string
): PayPolicyViolation {
  return {
    policyId: policy.id,
    policyCode: policy.code,
    ruleType,
    message,
  };
}
