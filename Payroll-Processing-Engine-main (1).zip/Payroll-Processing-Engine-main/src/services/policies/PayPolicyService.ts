import type { Employee, PayPeriod, PayrollRunInput } from '../../models/types';
import type {
  PayPolicy,
  PayPolicyRunContext,
  PayPolicyViolation,
} from '../../models/PayPolicy';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type { PayPolicyRepository } from '../../repositories/interfaces';
import { evaluatePayPolicies } from './PayPolicyEvaluator';
import { EarningsService } from '../EarningsService';

export class PayPolicyService {
  private earnings = new EarningsService();

  constructor(private readonly repo: PayPolicyRepository) {}

  async create(
    input: Omit<PayPolicy, 'id' | 'createdAt' | 'updatedAt'>
  ): Promise<PayPolicy> {
    if (input.scope === 'employee' && !input.employeeId) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'Employee-scoped policies require employeeId'
      );
    }
    if (input.scope === 'company' && input.employeeId) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'Company-scoped policies cannot set employeeId'
      );
    }
    return this.repo.create(input);
  }

  async update(
    id: string,
    companyId: string,
    patch: Parameters<PayPolicyRepository['update']>[2]
  ): Promise<PayPolicy> {
    const updated = await this.repo.update(id, companyId, patch);
    if (!updated) {
      throw PayrollDomainError.notFound('PayPolicy', id);
    }
    return updated;
  }

  async get(id: string, companyId: string): Promise<PayPolicy | null> {
    return this.repo.findById(id, companyId);
  }

  async list(companyId: string): Promise<PayPolicy[]> {
    return this.repo.listByCompany(companyId);
  }

  async evaluateRun(
    employee: Employee,
    payPeriod: PayPeriod,
    input: PayrollRunInput
  ): Promise<PayPolicyViolation[]> {
    const policies = await this.repo.findActiveForRun(
      employee.companyId,
      employee.id,
      payPeriod.paymentDate
    );
    if (policies.length === 0) {
      return [];
    }
    const gross = this.resolveGross(input);
    const context: PayPolicyRunContext = {
      companyId: employee.companyId,
      employeeId: employee.id,
      employmentType: employee.employmentType,
      baseCompensation: employee.baseCompensation,
      paymentDate: payPeriod.paymentDate,
      grossEarnings: gross,
    };
    return evaluatePayPolicies(policies, context);
  }

  async assertRunAllowed(
    employee: Employee,
    payPeriod: PayPeriod,
    input: PayrollRunInput
  ): Promise<void> {
    const violations = await this.evaluateRun(employee, payPeriod, input);
    if (violations.length > 0) {
      throw PayrollDomainError.payPolicyViolation(violations);
    }
  }

  private resolveGross(input: PayrollRunInput): string {
    return this.earnings.totalGross(input.earnings ?? []);
  }
}
