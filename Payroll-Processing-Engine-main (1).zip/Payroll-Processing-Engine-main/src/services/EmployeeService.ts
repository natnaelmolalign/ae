import type { CreateEmployeeInput, Employee } from '../models/types';
import type { EmployeeRepository } from '../repositories/interfaces';
import { employeeForTenant } from '../utils/tenant';

export class EmployeeService {
  constructor(private readonly employeeRepo: EmployeeRepository) {}

  create(input: CreateEmployeeInput, companyId: string): Promise<Employee> {
    return this.employeeRepo.create({ ...input, companyId });
  }

  async get(id: string, companyId: string): Promise<Employee | null> {
    const employee = await this.employeeRepo.findById(id);
    return employeeForTenant(employee, companyId);
  }
}
