import { randomUUID } from 'crypto';
import type { ConnectorType } from '../../models/ErpConnector';
import type {
  ConnectorAdapter,
  ConnectorExportInput,
  ConnectorExportResult,
} from './ConnectorAdapter';

/** In-memory journal registry per connection+idempotency (test/dev stub). */
const journalRegistry = new Map<string, ConnectorExportResult>();

function registryKey(connectionId: string, idempotencyKey: string): string {
  return `${connectionId}:${idempotencyKey}`;
}

export abstract class BaseConnectorStub implements ConnectorAdapter {
  abstract readonly connectorType: ConnectorType;

  async exportJournals(
    input: ConnectorExportInput
  ): Promise<ConnectorExportResult> {
    const key = registryKey(input.connectionId, input.idempotencyKey);
    const existing = journalRegistry.get(key);
    if (existing) {
      return existing;
    }

    const journalId = `${this.connectorType}-jrnl-${randomUUID()}`;
    const result: ConnectorExportResult = {
      externalJournalIds: [journalId],
      connectorResponse: this.formatResponse(input, journalId),
    };
    journalRegistry.set(key, result);
    return result;
  }

  protected abstract formatResponse(
    input: ConnectorExportInput,
    journalId: string
  ): Record<string, unknown>;

  /** Test helper */
  static clearRegistry(): void {
    journalRegistry.clear();
  }
}

export class NetSuiteStub extends BaseConnectorStub {
  readonly connectorType = 'netsuite' as const;

  protected formatResponse(
    input: ConnectorExportInput,
    journalId: string
  ): Record<string, unknown> {
    return {
      platform: 'NetSuite',
      journalEntry: {
        id: journalId,
        subsidiary: '1',
        tranDate: new Date().toISOString().slice(0, 10),
        lineCount: input.payload.lines.length,
        lines: input.payload.lines.map((l) => ({
          account: {
            internalId: l.externalAccountId,
            name: l.externalAccountName,
          },
          debit: l.debit,
          credit: l.credit,
          memo: l.memo,
          department: l.departmentCode ?? null,
          class: l.jobCode ?? null,
        })),
      },
    };
  }
}

export class QuickBooksStub extends BaseConnectorStub {
  readonly connectorType = 'quickbooks' as const;

  protected formatResponse(
    input: ConnectorExportInput,
    journalId: string
  ): Record<string, unknown> {
    return {
      platform: 'QuickBooks',
      JournalEntry: {
        Id: journalId,
        TxnDate: new Date().toISOString().slice(0, 10),
        Line: input.payload.lines.map((l) => ({
          JournalEntryLineDetail: {
            PostingType: parseFloat(l.debit) > 0 ? 'Debit' : 'Credit',
            AccountRef: {
              value: l.externalAccountId,
              name: l.externalAccountName,
            },
          },
          Amount: parseFloat(l.debit) > 0 ? l.debit : l.credit,
          Description: l.memo,
        })),
      },
    };
  }
}

export class ConnectorAdapterRegistry {
  private readonly adapters = new Map<ConnectorType, ConnectorAdapter>();

  register(adapter: ConnectorAdapter): void {
    this.adapters.set(adapter.connectorType, adapter);
  }

  get(type: ConnectorType): ConnectorAdapter {
    const adapter = this.adapters.get(type);
    if (!adapter) {
      throw new Error(`No connector adapter registered for ${type}`);
    }
    return adapter;
  }
}

export function createDefaultConnectorRegistry(): ConnectorAdapterRegistry {
  const registry = new ConnectorAdapterRegistry();
  registry.register(new NetSuiteStub());
  registry.register(new QuickBooksStub());
  return registry;
}
