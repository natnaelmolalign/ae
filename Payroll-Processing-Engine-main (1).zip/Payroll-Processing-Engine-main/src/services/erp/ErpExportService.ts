import { randomUUID } from 'crypto';
import type {
  CreateErpExportInput,
  CreateIntegrationConnectionInput,
  ExportBatch,
  PublishGlMappingsInput,
} from '../../models/ErpConnector';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type { ErpConnectorRepository } from '../../repositories/interfaces';
import type { ReportingService } from '../ReportingService';
import { GlJournalTransformer } from './GlJournalTransformer';
import type { ConnectorAdapterRegistry } from './ConnectorStubs';

export class ErpExportService {
  private readonly transformer = new GlJournalTransformer();

  constructor(
    private readonly repo: ErpConnectorRepository,
    private readonly reportingService: ReportingService,
    private readonly connectors: ConnectorAdapterRegistry
  ) {}

  createConnection(input: CreateIntegrationConnectionInput) {
    return this.repo.createConnection(input);
  }

  listConnections(companyId: string) {
    return this.repo.listConnections(companyId);
  }

  getConnection(id: string, companyId: string) {
    return this.repo.findConnectionById(id, companyId);
  }

  publishMappings(input: PublishGlMappingsInput) {
    return this.repo.publishMappings(
      input.companyId,
      input.connectionId,
      input.mappings
    );
  }

  getActiveMappings(connectionId: string, _companyId: string) {
    return this.repo.getActiveMappings(connectionId);
  }

  getMappingsForVersion(
    connectionId: string,
    companyId: string,
    version: number
  ) {
    return this.repo.getMappingsForVersion(connectionId, version);
  }

  async exportToConnector(input: CreateErpExportInput): Promise<ExportBatch> {
    const connection = await this.repo.findConnectionById(
      input.connectionId,
      input.companyId
    );
    if (!connection || !connection.isActive) {
      throw PayrollDomainError.notFound(
        'IntegrationConnection',
        input.connectionId
      );
    }

    const existing = await this.repo.findExportByIdempotencyKey(
      input.connectionId,
      input.idempotencyKey
    );
    if (existing) {
      return existing;
    }

    const { version, mappings } = await this.repo.getActiveMappings(
      input.connectionId
    );
    if (mappings.length === 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.GL_MAPPING_NOT_FOUND,
        'Publish GL account mappings before exporting'
      );
    }

    const glData = await this.reportingService.glExportForPeriod(
      input.payPeriodId,
      input.companyId
    );
    if (!glData.allBalanced) {
      throw new PayrollDomainError(
        PayrollErrorCode.PAY_STUB_RECONCILIATION_FAILED,
        'GL export is not balanced for the pay period'
      );
    }

    const payload = this.transformer.transform(
      connection.connectorType,
      glData.exports,
      mappings
    );

    const adapter = this.connectors.get(connection.connectorType);
    const result = await adapter.exportJournals({
      connectionId: input.connectionId,
      companyId: input.companyId,
      idempotencyKey: input.idempotencyKey,
      payPeriodId: input.payPeriodId,
      payload,
      mappingSnapshot: mappings,
    });

    const batchId = randomUUID();
    const submittedAt = new Date().toISOString();
    return this.repo.saveExportBatch({
      id: batchId,
      companyId: input.companyId,
      connectionId: input.connectionId,
      payPeriodId: input.payPeriodId,
      connectorType: connection.connectorType,
      status: 'submitted',
      idempotencyKey: input.idempotencyKey,
      mappingVersion: version,
      mappingSnapshot: mappings,
      connectorPayload: payload,
      externalJournalIds: result.externalJournalIds,
      submittedAt,
    });
  }

  async getExport(id: string, companyId: string): Promise<ExportBatch> {
    const batch = await this.repo.findExportById(id, companyId);
    if (!batch) {
      throw PayrollDomainError.notFound('ExportBatch', id);
    }
    return batch;
  }
}
