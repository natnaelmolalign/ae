import type { GlExport } from '../GeneralLedgerExporter';
import type {
  ConnectorJournalLine,
  ConnectorJournalPayload,
  ConnectorType,
  GlMappingEntry,
} from '../../models/ErpConnector';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import { sum } from '../../utils/decimalUtils';

export class GlJournalTransformer {
  transform(
    connectorType: ConnectorType,
    exports: GlExport[],
    mappings: GlMappingEntry[]
  ): ConnectorJournalPayload {
    const mapByCode = new Map(mappings.map((m) => [m.internalAccountCode, m]));
    const lines: ConnectorJournalLine[] = [];

    for (const exp of exports) {
      for (const line of exp.lines) {
        const mapping = mapByCode.get(line.accountCode);
        if (!mapping) {
          throw new PayrollDomainError(
            PayrollErrorCode.GL_MAPPING_NOT_FOUND,
            `No GL mapping for account ${line.accountCode}`,
            { accountCode: line.accountCode }
          );
        }
        lines.push({
          lineKey: `${exp.payrollRunId}:${line.accountCode}:${line.memo}:${line.debit}:${line.credit}`,
          payPeriodId: exp.payPeriodId,
          payrollRunId: exp.payrollRunId,
          employeeId: exp.employeeId,
          internalAccountCode: line.accountCode,
          externalAccountId: mapping.externalAccountId,
          externalAccountName: mapping.externalAccountName,
          debit: line.debit,
          credit: line.credit,
          memo: line.memo,
          departmentCode: line.departmentCode,
          jobCode: line.jobCode,
          locationCode: line.locationCode,
        });
      }
    }

    return {
      connectorType,
      payPeriodId: exports[0]?.payPeriodId ?? '',
      lines,
      totalDebits: sum(lines.map((l) => l.debit)),
      totalCredits: sum(lines.map((l) => l.credit)),
    };
  }
}
