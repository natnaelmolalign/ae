import type {
  ConnectorJournalPayload,
  ConnectorType,
  GlMappingEntry,
} from '../../models/ErpConnector';

export interface ConnectorExportInput {
  connectionId: string;
  companyId: string;
  idempotencyKey: string;
  payPeriodId: string;
  payload: ConnectorJournalPayload;
  mappingSnapshot: GlMappingEntry[];
}

export interface ConnectorExportResult {
  externalJournalIds: string[];
  connectorResponse: Record<string, unknown>;
}

export interface ConnectorAdapter {
  readonly connectorType: ConnectorType;
  exportJournals(input: ConnectorExportInput): Promise<ConnectorExportResult>;
}
