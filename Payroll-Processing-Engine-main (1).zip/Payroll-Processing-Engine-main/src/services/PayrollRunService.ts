import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  EarningsLine,
  Employee,
  EquityWithholdingMethod,
  PayPeriod,
  PayrollRunInput,
  PayrollRunResult,
  YearToDate,
} from '../models/types';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { garnishmentOrderToAllocation } from '../models/GarnishmentOrder';
import type {
  DeductionScheduleRepository,
  GarnishmentOrderRepository,
  PayStubRepository,
  PayrollRunAllocationRepository,
  PayrollRunRepository,
  YtdRepository,
} from '../repositories/interfaces';
import type { DeductionSchedule } from '../models/DeductionSchedule';
import type { GarnishmentAllocationInput } from './garnishments/GarnishmentAllocationService';
import { paymentYear } from '../utils/payPeriodUtils';
import { compare, sub } from '../utils/decimalUtils';
import { DeductionService } from './DeductionService';
import { EarningsService, assertPositiveGross } from './EarningsService';
import { EmployerContributionService } from './EmployerContributionService';
import { GarnishmentService } from './GarnishmentService';
import { CorrectionPayStubService } from './CorrectionPayStubService';
import { PayStubService } from './PayStubService';
import { TaxCalculationService } from './TaxCalculationService';
import { splitFederalTaxableAfterPretax } from '../utils/federalTaxableSplit';
import { YTDService } from './YTDService';
import { isContractor1099 } from '../utils/employmentClassification';
import { assertContractorDeductionsAllowed } from '../utils/contractorDeductions';
import type { StateTaxSlice } from './tax/MultiStateAllocationService';
import { TipPayrollHelper } from './tips/TipPayrollHelper';
import { EquityCompensationService } from './equity/EquityCompensationService';
import type { EquityEarningsSummary } from './equity/EquityCompensationService';
import { CobraPremiumService } from './deductions/CobraPremiumService';
import {
  ScheduledDeductionService,
  type ScheduledDeductionResult,
} from './deductions/ScheduledDeductionService';
import { add } from '../utils/decimalUtils';
import { WebhookOutboxService } from './webhooks/WebhookOutboxService';
import { features } from '../config/features';
import type { LaborCostAllocationService } from './costing/LaborCostAllocationService';
import { getPayrollMetrics } from '../metrics/hooks';
import type { PayPolicyService } from './policies/PayPolicyService';
import type { LeaveUsageService } from './leave/LeaveUsageService';
import type { TimeApprovalService } from './workforce/TimeApprovalService';

export interface PayrollRunOptions {
  isCorrection?: boolean;
  correctionOriginalGross?: string;
  correctsPayStubId?: string | null;
  idempotencyKey?: string | null;
  /** Metrics label source (default api) */
  metricsSource?: 'api' | 'batch';
  /** Mark approved shifts exported after successful run */
  useTimeEntries?: boolean;
}

export class PayrollRunService {
  private ytdService = new YTDService();
  private tipPayroll = new TipPayrollHelper();
  private equityPayroll = new EquityCompensationService();
  private scheduledDeduction = new ScheduledDeductionService();
  private cobraGuard = new CobraPremiumService();

  constructor(
    private readonly db: Knex,
    private readonly ytdRepo: YtdRepository,
    private readonly payStubRepo: PayStubRepository,
    private readonly payrollRunRepo: PayrollRunRepository,
    private readonly garnishmentOrderRepo?: GarnishmentOrderRepository,
    private readonly deductionScheduleRepo?: DeductionScheduleRepository,
    private readonly webhookOutbox?: WebhookOutboxService,
    private readonly laborCostAllocation?: LaborCostAllocationService,
    private readonly payrollRunAllocationRepo?: PayrollRunAllocationRepository,
    private readonly payPolicyService?: PayPolicyService,
    private readonly leaveUsageService?: LeaveUsageService,
    private readonly timeApprovalService?: TimeApprovalService,
    private readonly earningsService = new EarningsService(),
    private readonly deductionService = new DeductionService(),
    private readonly taxService = new TaxCalculationService(),
    private readonly garnishmentService = new GarnishmentService(),
    private readonly payStubService = new PayStubService(),
    private readonly correctionPayStubService = new CorrectionPayStubService(),
    private readonly employerService = new EmployerContributionService()
  ) {}

  /** Same calculation as run(), without persisting (for earnings preview). */
  async preview(
    employee: Employee,
    payPeriod: PayPeriod,
    input: PayrollRunInput
  ): Promise<PayrollRunResult> {
    const schedules = await this.loadDeductionSchedules(
      employee,
      payPeriod,
      input
    );
    const { result } = await this.previewWithYtd(
      employee,
      payPeriod,
      input,
      undefined,
      false,
      '0.00',
      schedules
    );
    return result;
  }

  /** Preview with explicit YTD (retro simulation). */
  async previewWithYtd(
    employee: Employee,
    payPeriod: PayPeriod,
    input: PayrollRunInput,
    ytd?: YearToDate,
    isCorrection = false,
    correctionOriginalGross = '0.00',
    deductionSchedules: DeductionSchedule[] = []
  ): Promise<{ result: PayrollRunResult; updatedYtd: YearToDate }> {
    await this.assertPayPolicies(employee, payPeriod, input);
    await this.assertLeaveBalance(employee, payPeriod, input);
    const taxYear = paymentYear(payPeriod.paymentDate);
    const baseYtd = ytd ?? (await this.ytdRepo.get(employee.id, taxYear));
    const allocations = await this.resolveGarnishmentAllocations(
      employee,
      payPeriod,
      input
    );
    return this.compute(
      employee,
      payPeriod,
      input,
      baseYtd,
      allocations,
      isCorrection,
      correctionOriginalGross,
      null,
      deductionSchedules
    );
  }

  /** Net-only catch-up correction on current period (no YTD change). */
  async runCatchUpCorrection(
    employee: Employee,
    payPeriod: PayPeriod,
    netPay: string,
    correctsPayStubId: string | null
  ): Promise<PayrollRunResult> {
    const taxYear = paymentYear(payPeriod.paymentDate);
    return this.db.transaction(async (trx) => {
      const duplicate =
        await this.payrollRunRepo.findByEmployeePeriodAndCorrection(
          trx,
          employee.id,
          payPeriod.id,
          true
        );
      if (duplicate) {
        throw PayrollDomainError.duplicatePayrollRun(employee.id, payPeriod.id);
      }

      const ytd = await this.ytdRepo.getForUpdate(trx, employee.id, taxYear);
      const payStub = this.correctionPayStubService.buildCatchUp(
        employee.id,
        payPeriod.id,
        netPay,
        correctsPayStubId,
        ytd
      );

      const payrollRunId = randomUUID();
      const emptyTaxes = {
        federalIncome: '0.00',
        stateIncome: '0.00',
        localIncome: '0.00',
        socialSecurity: '0.00',
        medicare: '0.00',
        medicareAdditional: '0.00',
      };
      const result: PayrollRunResult = {
        payStub,
        taxes: emptyTaxes,
        employerContributions: {
          ss: '0.00',
          medicare: '0.00',
          match401k: '0.00',
        },
      };

      await this.payStubRepo.insert(payStub, trx);
      await this.payrollRunRepo.insert(
        trx,
        {
          id: payrollRunId,
          employeeId: employee.id,
          payPeriodId: payPeriod.id,
          payStubId: payStub.id,
          isCorrection: true,
          idempotencyKey: null,
        },
        result,
        []
      );

      return result;
    });
  }

  async run(
    employee: Employee,
    payPeriod: PayPeriod,
    input: PayrollRunInput,
    options: PayrollRunOptions = {}
  ): Promise<PayrollRunResult> {
    const runStart = Date.now();
    const metricsSource = options.metricsSource ?? 'api';
    try {
      const result = await this.runInternal(
        employee,
        payPeriod,
        input,
        options
      );
      getPayrollMetrics().recordPayrollRunDuration(Date.now() - runStart, {
        source: metricsSource,
        status: 'success',
      });
      return result;
    } catch (err) {
      if (err instanceof PayrollDomainError) {
        getPayrollMetrics().incrementPayrollRunErrors(err.code);
      }
      getPayrollMetrics().recordPayrollRunDuration(Date.now() - runStart, {
        source: metricsSource,
        status: 'error',
      });
      throw err;
    }
  }

  private async assertPayPolicies(
    employee: Employee,
    payPeriod: PayPeriod,
    input: PayrollRunInput
  ): Promise<void> {
    if (!features.payPolicyEngineEnabled || !this.payPolicyService) {
      return;
    }
    await this.payPolicyService.assertRunAllowed(employee, payPeriod, input);
  }

  private async assertLeaveBalance(
    employee: Employee,
    payPeriod: PayPeriod,
    input: PayrollRunInput
  ): Promise<void> {
    if (!features.leaveAccrualsEnabled || !this.leaveUsageService) {
      return;
    }
    await this.leaveUsageService.assertSufficientBalance(
      employee,
      payPeriod,
      input.earnings ?? []
    );
  }

  private async runInternal(
    employee: Employee,
    payPeriod: PayPeriod,
    input: PayrollRunInput,
    options: PayrollRunOptions = {}
  ): Promise<PayrollRunResult> {
    await this.assertPayPolicies(employee, payPeriod, input);
    await this.assertLeaveBalance(employee, payPeriod, input);
    const isCorrection = options.isCorrection ?? false;
    const idempotencyKey = options.idempotencyKey ?? null;
    const garnishmentAllocations = await this.resolveGarnishmentAllocations(
      employee,
      payPeriod,
      input
    );
    const deductionSchedules = await this.loadDeductionSchedules(
      employee,
      payPeriod,
      input
    );
    const resolvedCostAllocations = this.laborCostAllocation
      ? await this.laborCostAllocation.resolveForRun(
          employee.companyId,
          input.costAllocations
        )
      : [];

    return this.db.transaction(async (trx) => {
      if (idempotencyKey) {
        const existing = await this.payrollRunRepo.findByIdempotencyKey(
          trx,
          idempotencyKey
        );
        if (existing) {
          return this.loadExistingResult(trx, existing.payStubId);
        }
      }

      const duplicate =
        await this.payrollRunRepo.findByEmployeePeriodAndCorrection(
          trx,
          employee.id,
          payPeriod.id,
          isCorrection
        );
      if (duplicate) {
        throw PayrollDomainError.duplicatePayrollRun(employee.id, payPeriod.id);
      }

      const taxYear = paymentYear(payPeriod.paymentDate);
      const ytd = await this.ytdRepo.getForUpdate(trx, employee.id, taxYear);

      const {
        result,
        updatedYtd,
        stateTaxSlices,
        processedEarnings,
        scheduledBalanceUpdates,
      } = this.compute(
        employee,
        payPeriod,
        input,
        ytd,
        garnishmentAllocations,
        isCorrection,
        options.correctionOriginalGross ?? '0.00',
        options.correctsPayStubId ?? null,
        deductionSchedules
      );

      if (
        input.useActiveDeductionSchedules &&
        this.deductionScheduleRepo &&
        scheduledBalanceUpdates.length > 0
      ) {
        for (const update of scheduledBalanceUpdates) {
          await this.deductionScheduleRepo.updateRemainingBalance(
            trx,
            update.scheduleId,
            update.remainingBalance
          );
        }
      }

      const payrollRunId = randomUUID();

      await this.payStubRepo.insert(result.payStub, trx);
      await this.ytdRepo.save(trx, updatedYtd);

      await this.payrollRunRepo.insert(
        trx,
        {
          id: payrollRunId,
          employeeId: employee.id,
          payPeriodId: payPeriod.id,
          payStubId: result.payStub.id,
          isCorrection,
          idempotencyKey,
        },
        result,
        processedEarnings,
        result.garnishmentRemittances?.map((r) => ({
          payrollRunId,
          garnishmentOrderId: r.garnishmentOrderId,
          caseId: r.caseId,
          orderType:
            r.orderType as import('../models/GarnishmentOrder').GarnishmentOrderType,
          amount: r.amount,
        }))
      );

      if (resolvedCostAllocations.length > 0 && this.payrollRunAllocationRepo) {
        await this.payrollRunAllocationRepo.insertMany(
          trx,
          resolvedCostAllocations.map((a) => ({
            payrollRunId,
            departmentId: a.departmentId,
            jobId: a.jobId,
            allocationPercent: a.allocationPercent,
            allocationHours: a.allocationHours,
          }))
        );
      }

      if (options.useTimeEntries && this.timeApprovalService) {
        await this.timeApprovalService.markExported(
          trx,
          employee.id,
          employee.companyId,
          payPeriod,
          payrollRunId
        );
      }

      if (this.leaveUsageService) {
        await this.leaveUsageService.recordUsageFromPayroll(
          trx,
          employee,
          payPeriod,
          payrollRunId,
          processedEarnings
        );
      }

      if (this.webhookOutbox) {
        await this.webhookOutbox.enqueuePayrollRunCompleted(
          trx,
          employee.companyId,
          {
            payrollRunId,
            employeeId: employee.id,
            payPeriodId: payPeriod.id,
            payStubId: result.payStub.id,
            netPay: result.payStub.netPay,
            grossPay: result.payStub.grossPay,
          }
        );
      }

      if (stateTaxSlices?.length) {
        const now = new Date().toISOString();
        for (const slice of stateTaxSlices) {
          const percent =
            input.stateAllocations!.find(
              (a) => a.stateCode.toUpperCase() === slice.stateCode
            )?.percent ?? '0.00';
          await trx('payroll_run_state_allocations').insert({
            id: randomUUID(),
            payroll_run_id: payrollRunId,
            state_code: slice.stateCode,
            allocation_percent: percent,
            allocated_wages: slice.allocatedWages,
            state_tax_withheld: slice.stateTaxWithheld,
            created_at: now,
            updated_at: now,
          });
        }
      }

      return result;
    });
  }

  private async loadExistingResult(
    trx: Knex.Transaction,
    payStubId: string
  ): Promise<PayrollRunResult> {
    const stub = await this.payStubRepo.findById(payStubId, trx);
    if (!stub) {
      throw PayrollDomainError.notFound('Pay stub', payStubId);
    }
    const runRow = await trx('payroll_runs')
      .where({ pay_stub_id: payStubId })
      .first();
    if (!runRow) {
      throw PayrollDomainError.notFound('Payroll run', payStubId);
    }
    return {
      payStub: stub,
      taxes:
        typeof runRow.taxes === 'string'
          ? JSON.parse(runRow.taxes)
          : runRow.taxes,
      employerContributions:
        typeof runRow.employer_contributions === 'string'
          ? JSON.parse(runRow.employer_contributions)
          : runRow.employer_contributions,
    };
  }

  private async resolveGarnishmentAllocations(
    employee: Employee,
    payPeriod: PayPeriod,
    input: PayrollRunInput
  ): Promise<GarnishmentAllocationInput[]> {
    if (input.useActiveGarnishmentOrders) {
      if (!this.garnishmentOrderRepo) {
        throw PayrollDomainError.notFound('GarnishmentOrderRepository');
      }
      const orders = await this.garnishmentOrderRepo.findActiveForEmployee(
        employee.id,
        payPeriod.paymentDate
      );
      return orders.map(garnishmentOrderToAllocation);
    }
    return input.garnishments.map((g) => ({
      type: g.type,
      priority: g.priority,
      fixedAmount: g.fixedAmount,
      percentOfDisposable: g.percentOfDisposable ?? null,
    }));
  }

  private compute(
    employee: Employee,
    payPeriod: PayPeriod,
    input: PayrollRunInput,
    ytd: YearToDate,
    garnishmentAllocations: GarnishmentAllocationInput[],
    isCorrection: boolean,
    correctionOriginalGross: string,
    correctsPayStubId: string | null,
    deductionSchedules: DeductionSchedule[] = []
  ): {
    result: PayrollRunResult;
    updatedYtd: YearToDate;
    stateTaxSlices?: StateTaxSlice[];
    processedEarnings: EarningsLine[];
    scheduledBalanceUpdates: ScheduledDeductionResult['balanceUpdates'];
  } {
    const { earnings: earningsWithTips, tipSummary } = this.tipPayroll.prepare(
      employee,
      input
    );
    const classified = this.earningsService.classify(earningsWithTips, {
      employee,
    });
    assertPositiveGross(classified.gross);

    const equitySummary =
      this.equityPayroll.validateAndSummarize(earningsWithTips);

    const nonGarnishmentDeductions = input.deductions.filter(
      (d) => !d.type.startsWith('garnishment')
    );
    if (isContractor1099(employee)) {
      assertContractorDeductionsAllowed(nonGarnishmentDeductions);
    }
    this.cobraGuard.assertNotPreTaxEnrollment(nonGarnishmentDeductions);

    const taxYear = paymentYear(payPeriod.paymentDate);
    const pretax = this.deductionService.applyPreTax(
      classified.federalTaxable,
      classified.stateTaxable,
      classified.ssTaxable,
      classified.medicareTaxable,
      nonGarnishmentDeductions,
      ytd,
      { taxYear, gross: classified.gross }
    );

    const federalTaxable = sub(
      classified.federalTaxable,
      pretax.federalTaxableReduction
    );
    const stateTaxable = sub(
      classified.stateTaxable,
      pretax.stateTaxableReduction
    );
    const ssTaxable = sub(classified.ssTaxable, pretax.ssTaxableReduction);
    const medicareTaxable = sub(
      classified.medicareTaxable,
      pretax.medicareTaxableReduction
    );

    const federalSplit = splitFederalTaxableAfterPretax(
      federalTaxable,
      classified
    );
    let stateTaxSlices: StateTaxSlice[] | undefined;
    if (input.stateAllocations?.length) {
      stateTaxSlices = this.taxService.stateTaxSlices(
        employee,
        stateTaxable,
        payPeriod.paymentDate,
        input.stateAllocations
      ).slices;
    }

    const taxes = this.taxService.calculateAll(
      employee,
      federalTaxable,
      stateTaxable,
      ssTaxable,
      medicareTaxable,
      earningsWithTips,
      ytd,
      {
        paymentDate: payPeriod.paymentDate,
        regularFederalTaxable: federalSplit.regularFederalTaxable,
        supplementalFederalTaxable: federalSplit.supplementalFederalTaxable,
        stateAllocations: input.stateAllocations,
      }
    );

    const scheduled = this.scheduledDeduction.resolve(
      employee,
      payPeriod.paymentDate,
      deductionSchedules,
      {
        gross: classified.gross,
        taxes,
        pretax,
      }
    );

    const garnishments = isContractor1099(employee)
      ? {
          total: '0.00',
          lines: [],
          disposableEarnings: '0.00',
          remittances: [],
        }
      : this.garnishmentService.process(
          garnishmentAllocations,
          {
            gross: classified.gross,
            taxes,
            mandatoryDeductions: { section125: pretax.section125Amount },
          },
          employee,
          payPeriod.paymentDate
        );

    const supplementalTaxable = this.equityPayroll.supplementalTaxableForYtd(
      earningsWithTips,
      equitySummary
    );

    const updatedYtd = this.ytdService.applyPayrollRun(
      ytd,
      classified.gross,
      federalTaxable,
      stateTaxable,
      ssTaxable,
      medicareTaxable,
      taxes,
      pretax.pretax401kAmount,
      pretax.roth401kAmount,
      pretax.hsaAmount,
      pretax.fsaAmount,
      pretax.section125Amount,
      supplementalTaxable,
      isCorrection,
      correctionOriginalGross
    );

    const payStub = this.payStubService.build(
      employee.id,
      payPeriod.id,
      classified.gross,
      taxes,
      pretax.pretax401kAmount,
      pretax.section125Amount,
      pretax.hsaAmount,
      pretax.fsaAmount,
      pretax.roth401kAmount,
      pretax.postTaxTotal,
      garnishments.total,
      updatedYtd,
      isCorrection,
      correctsPayStubId,
      tipSummary.tipCreditMakeup,
      equitySummary,
      scheduled.lines
    );

    const baseEmployer = isContractor1099(employee)
      ? { ss: '0.00', medicare: '0.00', match401k: '0.00' }
      : this.employerService.calculate(
          ssTaxable,
          medicareTaxable,
          ytd,
          {
            matchPercent: input.employerMatch401kPercent ?? 0,
            safeHarborMatch: input.safeHarborMatch ?? false,
            compensation: classified.gross,
            employeeDeferral: pretax.pretax401kAmount,
          },
          payPeriod.paymentDate
        );
    const employerContributions = {
      ...baseEmployer,
      ...(compare(tipSummary.tipCreditMakeup, '0.00') > 0
        ? { flsaTipCreditMakeup: tipSummary.tipCreditMakeup }
        : {}),
    };

    return {
      result: {
        payStub,
        taxes,
        employerContributions,
        garnishmentRemittances: garnishments.remittances,
        tipSummary,
        ...(equitySummary
          ? {
              equitySummary: toEquityRunSummary(
                equitySummary,
                employee.equityWithholdingMethod
              ),
            }
          : {}),
        ...(compare(scheduled.total, '0.00') > 0 ||
        scheduled.lines.some((l) => compare(l.amount, '0.00') > 0)
          ? { scheduledDeductions: toScheduledRunSummary(scheduled) }
          : {}),
      },
      updatedYtd,
      stateTaxSlices,
      processedEarnings: earningsWithTips,
      scheduledBalanceUpdates: scheduled.balanceUpdates,
    };
  }

  private async loadDeductionSchedules(
    employee: Employee,
    payPeriod: PayPeriod,
    input: PayrollRunInput
  ): Promise<DeductionSchedule[]> {
    if (
      !features.cobraArrearsEnabled ||
      !input.useActiveDeductionSchedules ||
      !this.deductionScheduleRepo
    ) {
      return [];
    }
    return this.deductionScheduleRepo.findActiveForEmployee(
      employee.id,
      payPeriod.paymentDate
    );
  }
}

function toScheduledRunSummary(scheduled: ScheduledDeductionResult) {
  let cobraPremium = '0.00';
  let arrearsRecovery = '0.00';
  for (const line of scheduled.lines) {
    if (line.scheduleType === 'cobra_premium') {
      cobraPremium = add(cobraPremium, line.amount);
    } else {
      arrearsRecovery = add(arrearsRecovery, line.amount);
    }
  }
  return {
    cobraPremium,
    arrearsRecovery,
    total: scheduled.total,
    lines: scheduled.lines.map((l) => ({
      scheduleId: l.scheduleId,
      label: l.label,
      amount: l.amount,
    })),
  };
}

function toEquityRunSummary(
  summary: EquityEarningsSummary,
  withholdingMethod: EquityWithholdingMethod
) {
  return {
    rsuVest: summary.rsuVest,
    nqsoExercise: summary.nqsoExercise,
    totalEquity: summary.totalEquity,
    withholdingMethod,
  };
}
