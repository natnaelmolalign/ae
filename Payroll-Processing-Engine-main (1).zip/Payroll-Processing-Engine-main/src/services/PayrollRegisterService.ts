import type { Knex } from 'knex';
import type { CostAllocationSegment } from '../models/CostAccounting';
import type { PayrollRunAllocationRepository } from '../repositories/interfaces';
import { add, type Money } from '../utils/decimalUtils';
import { payStubFromRow, type PayStubRow } from '../repositories/knex/mappers';

export interface PayrollRegisterRow {
  employeeId: string;
  employeeName: string;
  payStubId: string;
  payrollRunId: string;
  grossPay: Money;
  netPay: Money;
  isCorrection: boolean;
  costAllocations: CostAllocationSegment[];
}

export interface PayrollRegister {
  payPeriodId: string;
  rows: PayrollRegisterRow[];
  totals: {
    grossPay: Money;
    netPay: Money;
    stubCount: number;
  };
}

export class PayrollRegisterService {
  constructor(
    private readonly db: Knex,
    private readonly allocationRepo?: PayrollRunAllocationRepository
  ) {}

  async build(payPeriodId: string): Promise<PayrollRegister> {
    const rows = await this.db('payroll_runs as pr')
      .join('pay_stubs as ps', 'pr.pay_stub_id', 'ps.id')
      .join('employees as e', 'pr.employee_id', 'e.id')
      .where('pr.pay_period_id', payPeriodId)
      .select(
        'pr.id as payroll_run_id',
        'pr.employee_id',
        'ps.id as pay_stub_id',
        'ps.gross_pay',
        'ps.net_pay',
        'ps.is_correction',
        'e.first_name',
        'e.last_name'
      )
      .orderBy('e.last_name', 'asc');

    const runIds = rows.map((r) => String(r.payroll_run_id));
    const segmentMap = this.allocationRepo
      ? await this.allocationRepo.findSegmentsForRuns(runIds)
      : new Map<string, CostAllocationSegment[]>();

    const registerRows: PayrollRegisterRow[] = rows.map((r) => ({
      employeeId: String(r.employee_id),
      employeeName: `${r.first_name} ${r.last_name}`,
      payStubId: String(r.pay_stub_id),
      payrollRunId: String(r.payroll_run_id),
      grossPay: String(r.gross_pay),
      netPay: String(r.net_pay),
      isCorrection: Boolean(r.is_correction),
      costAllocations: segmentMap.get(String(r.payroll_run_id)) ?? [],
    }));

    const totals = registerRows.reduce(
      (acc, row) => ({
        grossPay: add(acc.grossPay, row.grossPay),
        netPay: add(acc.netPay, row.netPay),
        stubCount: acc.stubCount + 1,
      }),
      { grossPay: '0.00', netPay: '0.00', stubCount: 0 }
    );

    return { payPeriodId, rows: registerRows, totals };
  }

  async sumStubsForPeriod(payPeriodId: string): Promise<{
    grossPay: Money;
    netPay: Money;
    count: number;
  }> {
    const stubs = await this.db('pay_stubs').where({
      pay_period_id: payPeriodId,
    });
    return stubs.reduce(
      (acc, row) => {
        const stub = payStubFromRow(row as PayStubRow);
        return {
          grossPay: add(acc.grossPay, stub.grossPay),
          netPay: add(acc.netPay, stub.netPay),
          count: acc.count + 1,
        };
      },
      { grossPay: '0.00', netPay: '0.00', count: 0 }
    );
  }
}
