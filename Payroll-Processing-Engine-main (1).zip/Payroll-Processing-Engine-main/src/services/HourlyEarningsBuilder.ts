import { getJurisdiction } from '../data/jurisdictions';
import { features } from '../config/features';
import type { EarningsLine, Employee, TimeEntry } from '../models/types';
import type { Money } from '../utils/decimalUtils';
import { minutesToHours } from '../utils/timeEntryUtils';
import { HourlyPayCalculator } from './HourlyPayCalculator';
import { OvertimeAllocator } from './OvertimeAllocator';
export class HourlyEarningsBuilder {
  constructor(
    private readonly hourly = new HourlyPayCalculator(),
    private readonly overtime = new OvertimeAllocator()
  ) {}

  buildFromTimeEntries(
    employee: Employee,
    entries: TimeEntry[],
    hourlyRate: Money
  ): EarningsLine[] {
    if (!features.hourlyEarningsEnabled) {
      throw new Error('Hourly earnings feature is disabled');
    }

    const lines: EarningsLine[] = [];
    const holidayEntries = entries.filter((e) => e.entryType === 'holiday');
    const workEntries = entries.filter((e) => e.entryType !== 'holiday');

    const ot = this.overtime.allocateWeekly(
      workEntries,
      hourlyRate,
      employee.stateCode
    );

    if (parseFloat(ot.regularPay) > 0) {
      lines.push({
        type: 'regular',
        amount: ot.regularPay,
        hours: parseFloat(minutesToHours(ot.regularMinutes)),
      });
    }
    if (parseFloat(ot.overtimePay) > 0) {
      lines.push({
        type: 'overtime',
        amount: ot.overtimePay,
        hours: parseFloat(minutesToHours(ot.overtimeMinutes)),
      });
    }

    const jurisdiction = getJurisdiction(employee.stateCode);
    for (const h of holidayEntries) {
      const pay = this.hourly.payForMinutes(
        hourlyRate,
        h.roundedMinutes,
        jurisdiction.holidayMultiplier
      );
      lines.push({
        type: 'holiday',
        amount: pay,
        hours: parseFloat(minutesToHours(h.roundedMinutes)),
      });
    }

    return lines;
  }
}
