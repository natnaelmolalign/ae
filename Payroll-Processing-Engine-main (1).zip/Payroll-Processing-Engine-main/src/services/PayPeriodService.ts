import type { PayFrequency, PayPeriod } from '../models/types';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import {
  generateBiweeklyPeriods,
  generateMonthlyPeriods,
  generateSemimonthlyPeriods,
  generateWeeklyPeriods,
  periodsOverlap,
} from '../utils/payPeriodUtils';

export class PayPeriodService {
  generate(
    year: number,
    frequency: PayFrequency,
    biweeklyAnchor?: string
  ): PayPeriod[] {
    switch (frequency) {
      case 'weekly':
        return generateWeeklyPeriods(year);
      case 'biweekly':
        return generateBiweeklyPeriods(year, biweeklyAnchor || `${year}-01-01`);
      case 'semimonthly':
        return generateSemimonthlyPeriods(year);
      case 'monthly':
        return generateMonthlyPeriods(year);
      default:
        throw PayrollDomainError.unknownPayFrequency(String(frequency));
    }
  }

  validateNoOverlap(periods: PayPeriod[]): void {
    for (let i = 0; i < periods.length; i += 1) {
      for (let j = i + 1; j < periods.length; j += 1) {
        if (periodsOverlap(periods[i], periods[j])) {
          throw PayrollDomainError.payPeriodOverlap(
            periods[i].id,
            periods[j].id
          );
        }
      }
    }
  }
}
