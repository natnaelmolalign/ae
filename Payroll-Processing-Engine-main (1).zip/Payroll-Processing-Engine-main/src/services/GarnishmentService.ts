import type { Employee } from '../models/types';
import type { GarnishmentOrderType } from '../models/GarnishmentOrder';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';
import { compare } from '../utils/decimalUtils';
import { DisposableEarningsCalculator } from './garnishments/DisposableEarningsCalculator';
import type { DisposableEarningsInput } from './garnishments/DisposableEarningsCalculator';
import {
  GarnishmentAllocationService,
  type GarnishmentAllocationInput,
} from './garnishments/GarnishmentAllocationService';

export interface GarnishmentProcessResult {
  total: string;
  lines: {
    type: string;
    amount: string;
    orderId: string | null;
    caseId: string | null;
  }[];
  disposableEarnings: string;
  remittances: {
    garnishmentOrderId: string;
    caseId: string;
    orderType: GarnishmentOrderType;
    amount: string;
  }[];
}

export class GarnishmentService {
  private disposableCalc = new DisposableEarningsCalculator();
  private allocator = new GarnishmentAllocationService();

  process(
    orders: GarnishmentAllocationInput[],
    disposableInput: DisposableEarningsInput,
    employee: Employee,
    paymentDate: string
  ): GarnishmentProcessResult {
    if (orders.length > 0) {
      this.assertNotAfterTermination(employee, paymentDate);
    }

    const disposable = this.disposableCalc.calculate(disposableInput);
    if (compare(disposable, '0.00') <= 0) {
      return {
        total: '0.00',
        lines: [],
        disposableEarnings: disposable,
        remittances: [],
      };
    }

    const result = this.allocator.allocate(orders, disposable);

    const remittances = result.lines
      .filter((l) => l.orderId && compare(l.amount, '0.00') > 0)
      .map((l) => ({
        garnishmentOrderId: l.orderId!,
        caseId: l.caseId ?? '',
        orderType: l.type,
        amount: l.amount,
      }));

    return {
      total: result.total,
      lines: result.lines.map((l) => ({
        type: l.type,
        amount: l.amount,
        orderId: l.orderId,
        caseId: l.caseId,
      })),
      disposableEarnings: disposable,
      remittances,
    };
  }

  private assertNotAfterTermination(
    employee: Employee,
    paymentDate: string
  ): void {
    if (employee.terminationDate && paymentDate > employee.terminationDate) {
      throw new PayrollDomainError(
        PayrollErrorCode.GARNISHMENT_AFTER_TERMINATION,
        `Cannot apply garnishments when payment date ${paymentDate} is after termination ${employee.terminationDate}`,
        { paymentDate, terminationDate: employee.terminationDate }
      );
    }
  }
}
