import { randomUUID } from 'crypto';
import type { Employee, PayPeriod } from '../models/types';
import type { PayrollBatch } from '../models/PayrollBatch';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';
import { getPayrollMetrics } from '../metrics/hooks';
import type {
  EmployeePayrollReadinessRepository,
  EmployeeRepository,
  PayrollBatchRepository,
  PayrollRunFailureRepository,
} from '../repositories/interfaces';
import { runWithConcurrencyLimit } from '../utils/parallelLimit';
import { isShuttingDown, trackInFlight } from '../shutdown';
import { employeeForTenant } from '../utils/tenant';
import { PayrollRunService } from './PayrollRunService';
import { WebhookOutboxService } from './webhooks/WebhookOutboxService';
import { features } from '../config/features';
import type { ControlService } from './controls/ControlService';

export interface CreateBatchInput {
  companyId: string;
  payPeriod: PayPeriod;
  year: number;
  frequency: string;
  parallelLimit?: number;
  employeeIds?: string[];
}

export interface BatchResult {
  batch: PayrollBatch;
  failures: Awaited<ReturnType<PayrollRunFailureRepository['findByBatchId']>>;
}

export class PayrollBatchService {
  constructor(
    private readonly batchRepo: PayrollBatchRepository,
    private readonly failureRepo: PayrollRunFailureRepository,
    private readonly readinessRepo: EmployeePayrollReadinessRepository,
    private readonly employeeRepo: EmployeeRepository,
    private readonly payrollRunService: PayrollRunService,
    private readonly webhookOutbox?: WebhookOutboxService,
    private readonly controlService?: ControlService
  ) {}

  async createAndRun(input: CreateBatchInput): Promise<BatchResult> {
    if (isShuttingDown()) {
      throw new PayrollDomainError(
        PayrollErrorCode.SERVICE_UNAVAILABLE,
        'Server is shutting down; new batch runs are not accepted'
      );
    }
    return trackInFlight(this.executeBatch(input));
  }

  private async executeBatch(input: CreateBatchInput): Promise<BatchResult> {
    const parallelLimit = input.parallelLimit ?? 4;
    const employeeIds =
      input.employeeIds ??
      (await this.readinessRepo.findReadyEmployeeIds(input.payPeriod.id));

    const batchId = randomUUID();
    let batch = await this.batchRepo.create({
      id: batchId,
      companyId: input.companyId,
      payPeriodId: input.payPeriod.id,
      year: input.year,
      frequency: input.frequency,
      status: 'pending',
      startedAt: null,
      completedAt: null,
      successCount: 0,
      failureCount: 0,
      totalCount: employeeIds.length,
      durationMs: null,
    });

    if (employeeIds.length === 0) {
      const completedAt = new Date().toISOString();
      batch = (await this.batchRepo.update(batchId, {
        status: 'completed',
        startedAt: completedAt,
        completedAt,
        durationMs: 0,
      }))!;
      if (this.webhookOutbox) {
        await this.webhookOutbox.enqueueBatchCompleted(input.companyId, {
          batchId,
          payPeriodId: input.payPeriod.id,
          status: 'completed',
          successCount: 0,
          failureCount: 0,
          totalCount: 0,
        });
      }
      return { batch, failures: [] };
    }

    const startedAt = new Date().toISOString();
    batch = (await this.batchRepo.update(batchId, {
      status: 'running',
      startedAt,
    }))!;

    const startMs = Date.now();
    let successCount = 0;
    let failureCount = 0;

    await runWithConcurrencyLimit(employeeIds, parallelLimit, async (empId) => {
      const outcome = await this.runOneEmployee(
        batchId,
        empId,
        input.payPeriod,
        input.companyId
      );
      if (outcome.ok) {
        successCount += 1;
        await this.readinessRepo.markProcessed(empId, input.payPeriod.id);
      } else {
        failureCount += 1;
      }
    });

    const durationMs = Date.now() - startMs;
    const completedAt = new Date().toISOString();
    const finalStatus =
      failureCount > 0 && successCount === 0 ? 'failed' : 'completed';

    batch = (await this.batchRepo.update(batchId, {
      status: finalStatus,
      completedAt,
      successCount,
      failureCount,
      durationMs,
    }))!;

    getPayrollMetrics().recordBatchComplete?.(
      durationMs,
      successCount,
      failureCount,
      { payPeriodId: input.payPeriod.id }
    );

    const failures = await this.failureRepo.findByBatchId(batchId);

    if (this.webhookOutbox) {
      await this.webhookOutbox.enqueueBatchCompleted(input.companyId, {
        batchId,
        payPeriodId: input.payPeriod.id,
        status: finalStatus,
        successCount,
        failureCount,
        totalCount: employeeIds.length,
      });
    }

    return { batch, failures };
  }

  async getBatch(
    id: string,
    companyId: string
  ): Promise<{
    batch: PayrollBatch;
    failures: Awaited<ReturnType<PayrollRunFailureRepository['findByBatchId']>>;
  }> {
    const batch = await this.batchRepo.findById(id);
    if (!batch || batch.companyId !== companyId) {
      throw PayrollDomainError.notFound('Payroll batch', id);
    }
    const failures = await this.failureRepo.findByBatchId(id);
    return { batch, failures };
  }

  private async runOneEmployee(
    batchId: string,
    employeeId: string,
    payPeriod: PayPeriod,
    companyId: string
  ): Promise<{ ok: true } | { ok: false }> {
    const employee = employeeForTenant(
      await this.employeeRepo.findById(employeeId),
      companyId
    );
    if (!employee) {
      await this.recordFailure(
        batchId,
        employeeId,
        payPeriod.id,
        `batch-${batchId}-${employeeId}`,
        PayrollDomainError.notFound('Employee', employeeId)
      );
      return { ok: false };
    }

    const idempotencyKey = `batch-${batchId}-${employeeId}`;

    try {
      if (this.controlService && features.payrollControlsEnabled) {
        await this.controlService.assertRunAllowed({
          employeeId,
          companyId,
          payPeriodId: payPeriod.id,
          grossAmount: employee.baseCompensation,
          actor: 'batch',
        });
      }

      await this.payrollRunService.run(
        employee,
        payPeriod,
        this.defaultInput(employee, payPeriod),
        { idempotencyKey, metricsSource: 'batch' }
      );
      return { ok: true };
    } catch (err) {
      const domain =
        err instanceof PayrollDomainError
          ? err
          : new PayrollDomainError(
              PayrollErrorCode.INVALID_INPUT,
              err instanceof Error ? err.message : String(err),
              { employeeId }
            );
      await this.recordFailure(
        batchId,
        employeeId,
        payPeriod.id,
        idempotencyKey,
        domain
      );
      return { ok: false };
    }
  }

  private defaultInput(employee: Employee, payPeriod: PayPeriod) {
    return {
      employeeId: employee.id,
      payPeriodId: payPeriod.id,
      earnings: [
        { type: 'regular' as const, amount: employee.baseCompensation },
      ],
      deductions: [],
      garnishments: [],
    };
  }

  private async recordFailure(
    batchId: string,
    employeeId: string,
    payPeriodId: string,
    idempotencyKey: string,
    err: PayrollDomainError
  ): Promise<void> {
    await this.failureRepo.insert({
      id: randomUUID(),
      batchId,
      employeeId,
      payPeriodId,
      idempotencyKey,
      errorCode: err.code,
      errorMessage: err.message,
      payload: err.details ?? null,
      retryable: err.code !== 'DUPLICATE_PAYROLL_RUN',
    });
  }
}
