import type { CreateAuditEventInput, AuditEvent } from '../models/AuditEvent';
import type { AuditEventRepository } from '../repositories/interfaces';
import { jsonDiff } from '../utils/jsonDiff';

export class AuditService {
  constructor(private readonly repo: AuditEventRepository) {}

  async record(input: CreateAuditEventInput): Promise<AuditEvent> {
    return this.repo.append(input);
  }

  async recordCreate(
    actor: string,
    entityType: string,
    entityId: string,
    after: Record<string, unknown>
  ): Promise<AuditEvent> {
    return this.record({
      entityType,
      entityId,
      action: 'create',
      actor,
      beforeSnapshot: null,
      afterSnapshot: after,
    });
  }

  async recordUpdate(
    actor: string,
    entityType: string,
    entityId: string,
    before: Record<string, unknown>,
    after: Record<string, unknown>
  ): Promise<AuditEvent> {
    return this.record({
      entityType,
      entityId,
      action: 'update',
      actor,
      beforeSnapshot: before,
      afterSnapshot: after,
    });
  }

  async recordDelete(
    actor: string,
    entityType: string,
    entityId: string,
    before: Record<string, unknown>
  ): Promise<AuditEvent> {
    return this.record({
      entityType,
      entityId,
      action: 'delete',
      actor,
      beforeSnapshot: before,
      afterSnapshot: null,
    });
  }

  listForEntity(entityType: string, entityId: string): Promise<AuditEvent[]> {
    return this.repo.findByEntity(entityType, entityId);
  }

  buildDiff(
    before: Record<string, unknown> | null,
    after: Record<string, unknown> | null
  ): Record<string, { from: unknown; to: unknown }> {
    return jsonDiff(before, after);
  }
}
