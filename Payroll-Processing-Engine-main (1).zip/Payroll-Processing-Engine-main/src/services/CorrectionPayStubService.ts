import { randomUUID } from 'crypto';
import type { PayStub, PayStubLine, YearToDate } from '../models/types';
import { compare, type Money } from '../utils/decimalUtils';

export class CorrectionPayStubService {
  /**
   * Aggregate catch-up on the current open period. Net may be negative (recovery on next check).
   */
  buildCatchUp(
    employeeId: string,
    payPeriodId: string,
    netPay: Money,
    correctsPayStubId: string | null,
    ytd: YearToDate
  ): PayStub {
    const negativeNetRecovery = compare(netPay, '0.00') < 0;
    const lines: PayStubLine[] = [
      {
        category: 'earnings',
        label: negativeNetRecovery
          ? 'Retroactive Adjustment (recovery)'
          : 'Retroactive Adjustment',
        current: netPay,
        ytd: ytd.grossEarnings,
      },
      {
        category: 'net',
        label: 'Net Pay',
        current: netPay,
        ytd: netPay,
      },
    ];

    return {
      id: randomUUID(),
      employeeId,
      payPeriodId,
      grossPay: '0.00',
      netPay,
      lines,
      isCorrection: true,
      correctsPayStubId,
      negativeNetRecovery,
      createdAt: new Date().toISOString(),
    };
  }
}
