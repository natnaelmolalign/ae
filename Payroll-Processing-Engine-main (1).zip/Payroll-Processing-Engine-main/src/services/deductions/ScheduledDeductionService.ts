import type { DeductionSchedule } from '../../models/DeductionSchedule';
import type { Employee } from '../../models/types';
import { features } from '../../config/features';
import { compare, sub, sum, type Money } from '../../utils/decimalUtils';
import type { DeductionBases } from '../DeductionService';
import type { TaxWithholdingResult } from '../../models/types';
import { ArrearsScheduler } from './ArrearsScheduler';
import { CobraPremiumService } from './CobraPremiumService';

export interface ScheduledDeductionLine {
  scheduleId: string;
  scheduleType: DeductionSchedule['scheduleType'];
  label: string;
  amount: Money;
}

export interface ScheduledDeductionResult {
  lines: ScheduledDeductionLine[];
  total: Money;
  balanceUpdates: { scheduleId: string; remainingBalance: string | null }[];
}

export interface CapScheduledInput {
  gross: Money;
  taxes: TaxWithholdingResult;
  pretax: DeductionBases;
}

export class ScheduledDeductionService {
  private arrears = new ArrearsScheduler();
  private cobra = new CobraPremiumService();

  resolve(
    employee: Employee,
    paymentDate: string,
    schedules: DeductionSchedule[],
    capInput?: CapScheduledInput
  ): ScheduledDeductionResult {
    if (!features.cobraArrearsEnabled) {
      return { lines: [], total: '0.00', balanceUpdates: [] };
    }

    const active = schedules
      .filter((s) => this.isScheduleActive(employee, s, paymentDate))
      .sort((a, b) => a.priority - b.priority);

    const requested: ScheduledDeductionLine[] = [];

    for (const schedule of active) {
      const amount = this.dueAmount(employee, schedule, paymentDate);
      if (compare(amount, '0.00') <= 0) {
        continue;
      }
      requested.push({
        scheduleId: schedule.id,
        scheduleType: schedule.scheduleType,
        label:
          schedule.scheduleType === 'cobra_premium'
            ? 'COBRA Premium'
            : 'Arrears Recovery',
        amount,
      });
    }

    const lines = capInput
      ? this.capToAvailableNet(requested, capInput).lines
      : requested;
    const total = sum(lines.map((l) => l.amount));
    const balanceUpdates = lines
      .filter(
        (l) => l.scheduleType === 'arrears' && compare(l.amount, '0.00') > 0
      )
      .map((l) => {
        const schedule = schedules.find((s) => s.id === l.scheduleId)!;
        return {
          scheduleId: l.scheduleId,
          remainingBalance: this.arrears.balanceAfterPayment(
            schedule,
            l.amount
          ),
        };
      });

    return { lines, total, balanceUpdates };
  }

  private isScheduleActive(
    employee: Employee,
    schedule: DeductionSchedule,
    paymentDate: string
  ): boolean {
    if (schedule.scheduleType === 'arrears') {
      if (!this.arrears.isEligible(employee, paymentDate)) {
        return false;
      }
      return this.arrears.isActive(schedule, paymentDate);
    }
    return this.cobra.isActive(schedule, paymentDate);
  }

  private dueAmount(
    employee: Employee,
    schedule: DeductionSchedule,
    paymentDate: string
  ): Money {
    if (schedule.scheduleType === 'arrears') {
      if (!this.arrears.isEligible(employee, paymentDate)) {
        return '0.00';
      }
      return this.arrears.computeDue(schedule);
    }
    return this.cobra.computeDue(schedule);
  }

  private capToAvailableNet(
    lines: ScheduledDeductionLine[],
    input: CapScheduledInput
  ): ScheduledDeductionResult {
    const taxTotal = sum([
      input.taxes.federalIncome,
      input.taxes.stateIncome,
      input.taxes.localIncome,
      input.taxes.socialSecurity,
      input.taxes.medicare,
      input.taxes.medicareAdditional,
    ]);
    const otherDeductions = sum([
      input.pretax.pretax401kAmount,
      input.pretax.section125Amount,
      input.pretax.hsaAmount,
      input.pretax.fsaAmount,
      input.pretax.roth401kAmount,
      input.pretax.postTaxTotal,
    ]);
    let available = sub(sub(input.gross, taxTotal), otherDeductions);
    if (compare(available, '0.00') < 0) {
      available = '0.00';
    }

    const cappedLines: ScheduledDeductionLine[] = [];
    for (const line of lines) {
      if (compare(available, '0.00') <= 0) {
        cappedLines.push({ ...line, amount: '0.00' });
        continue;
      }
      const applied =
        compare(line.amount, available) <= 0 ? line.amount : available;
      cappedLines.push({ ...line, amount: applied });
      available = sub(available, applied);
    }

    return { lines: cappedLines, total: '0.00', balanceUpdates: [] };
  }
}
