import type { DeductionSchedule } from '../../models/DeductionSchedule';
import type { Employee } from '../../models/types';
import { compare, sub, type Money } from '../../utils/decimalUtils';

export class ArrearsScheduler {
  /** Arrears do not run after the employee's termination payment date. */
  isEligible(employee: Employee, paymentDate: string): boolean {
    if (!employee.terminationDate) {
      return true;
    }
    return paymentDate <= employee.terminationDate;
  }

  isActive(schedule: DeductionSchedule, paymentDate: string): boolean {
    if (schedule.scheduleType !== 'arrears') {
      return false;
    }
    if (paymentDate < schedule.startDate) {
      return false;
    }
    if (schedule.endDate && paymentDate > schedule.endDate) {
      return false;
    }
    const balance = schedule.remainingBalance ?? '0.00';
    return compare(balance, '0.00') > 0;
  }

  /** Due this period: min(installment, remaining balance). */
  computeDue(schedule: DeductionSchedule): Money {
    const balance = schedule.remainingBalance ?? '0.00';
    if (compare(balance, '0.00') <= 0) {
      return '0.00';
    }
    if (compare(schedule.amountPerPeriod, balance) <= 0) {
      return schedule.amountPerPeriod;
    }
    return balance;
  }

  balanceAfterPayment(schedule: DeductionSchedule, applied: Money): Money {
    const balance = schedule.remainingBalance ?? '0.00';
    return sub(balance, applied);
  }
}
