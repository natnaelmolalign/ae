import type { DeductionSchedule } from '../../models/DeductionSchedule';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type { DeductionEnrollment } from '../../models/types';
import { compare, type Money } from '../../utils/decimalUtils';

/** COBRA premiums are post-tax only and never reduce pre-tax bases. */
export class CobraPremiumService {
  assertNotPreTaxEnrollment(deductions: DeductionEnrollment[]): void {
    for (const d of deductions) {
      const t = d.type as string;
      if (t === 'cobra_premium' || t === 'arrears_recovery') {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          `${d.type} must use deduction schedules, not benefit enrollments`,
          { type: d.type }
        );
      }
    }
  }

  isActive(schedule: DeductionSchedule, paymentDate: string): boolean {
    if (schedule.scheduleType !== 'cobra_premium') {
      return false;
    }
    if (paymentDate < schedule.startDate) {
      return false;
    }
    if (schedule.endDate && paymentDate > schedule.endDate) {
      return false;
    }
    return compare(schedule.amountPerPeriod, '0.00') > 0;
  }

  computeDue(schedule: DeductionSchedule): Money {
    return schedule.amountPerPeriod;
  }
}
