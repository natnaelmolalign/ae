import type { EarningsLine, EarningsType } from '../../models/types';
import { add } from '../../utils/decimalUtils';

export const EQUITY_EARNING_TYPES = ['rsu_vest', 'nqso_exercise'] as const;
export type EquityEarningType = (typeof EQUITY_EARNING_TYPES)[number];

/** ISO exercises are out of scope for this engine (Advanced Phase 4). */
export const ISO_EARNING_TYPE = 'iso_exercise';

export function isEquityEarningType(type: EarningsType): boolean {
  return (EQUITY_EARNING_TYPES as readonly string[]).includes(type);
}

export function sumEquityByType(
  lines: EarningsLine[],
  type: EquityEarningType
): string {
  let total = '0.00';
  for (const line of lines) {
    if (line.type === type) {
      total = add(total, line.amount);
    }
  }
  return total;
}
