import type { EarningsLine, Employee } from '../../models/types';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import { features } from '../../config/features';
import { EarningsService } from '../EarningsService';
import { add } from '../../utils/decimalUtils';
import {
  EQUITY_EARNING_TYPES,
  ISO_EARNING_TYPE,
  isEquityEarningType,
  sumEquityByType,
} from './equityEarningsUtils';

export type EquityWithholdingMethod = 'supplemental_flat' | 'w4_annualized';

export interface EquityEarningsSummary {
  rsuVest: string;
  nqsoExercise: string;
  totalEquity: string;
}

export interface FederalWithholdingFlags {
  supplementalOnly: boolean;
  mixedSupplemental: boolean;
}

export class EquityCompensationService {
  private readonly earnings = new EarningsService();

  validateAndSummarize(lines: EarningsLine[]): EquityEarningsSummary | null {
    if (!features.equityCompensationEnabled) {
      return null;
    }

    let hasEquity = false;
    for (const line of lines) {
      if ((line.type as string) === ISO_EARNING_TYPE) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'ISO stock option exercises are not supported; use NQSO exercise earnings',
          { type: line.type }
        );
      }
      if (isEquityEarningType(line.type)) {
        hasEquity = true;
      }
    }

    if (!hasEquity) {
      return null;
    }

    const rsuVest = sumEquityByType(lines, 'rsu_vest');
    const nqsoExercise = sumEquityByType(lines, 'nqso_exercise');
    return {
      rsuVest,
      nqsoExercise,
      totalEquity: add(rsuVest, nqsoExercise),
    };
  }

  supplementalTaxableForYtd(
    lines: EarningsLine[],
    summary: EquityEarningsSummary | null
  ): string {
    if (!summary) {
      return '0.00';
    }
    let total = '0.00';
    for (const line of lines) {
      if (
        (EQUITY_EARNING_TYPES as readonly string[]).includes(line.type) ||
        ['bonus', 'commission', 'severance'].includes(line.type)
      ) {
        total = add(total, line.amount);
      }
    }
    return total;
  }

  /**
   * When equity is present, apply employee withholding election for supplemental-only pay.
   * Mixed regular + supplemental always uses the aggregate (combined) method.
   */
  resolveWithholdingFlags(
    employee: Employee,
    lines: EarningsLine[]
  ): FederalWithholdingFlags | null {
    if (!features.equityCompensationEnabled) {
      return null;
    }
    if (!lines.some((l) => isEquityEarningType(l.type))) {
      return null;
    }

    const mixedSupplemental = this.earnings.hasMixedSupplemental(lines);
    if (mixedSupplemental) {
      return { supplementalOnly: false, mixedSupplemental: true };
    }

    const supplementalOnly = this.earnings.hasSupplementalOnly(lines);
    if (!supplementalOnly) {
      return { supplementalOnly: false, mixedSupplemental: false };
    }

    if (employee.equityWithholdingMethod === 'w4_annualized') {
      return { supplementalOnly: false, mixedSupplemental: false };
    }

    return { supplementalOnly: true, mixedSupplemental: false };
  }
}
