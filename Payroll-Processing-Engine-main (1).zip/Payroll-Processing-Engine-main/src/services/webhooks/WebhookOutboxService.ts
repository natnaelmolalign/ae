import type { Knex } from 'knex';
import type { WebhookEventType } from '../../config/webhooks';
import { features } from '../../config/features';
import type {
  DbTrx,
  WebhookOutboxRepository,
} from '../../repositories/interfaces';
import type { WebhookSubscriptionRepository } from '../../repositories/interfaces';
import {
  batchCompletedPayload,
  payStubCreatedPayload,
  payrollRunPayload,
  paymentBatchSubmittedPayload,
  type BatchCompletedWebhookData,
  type PaymentBatchSubmittedWebhookData,
  type PayrollRunWebhookData,
} from './webhookPayload';

export class WebhookOutboxService {
  constructor(
    private readonly db: Knex,
    private readonly subscriptions: WebhookSubscriptionRepository,
    private readonly outbox: WebhookOutboxRepository
  ) {}

  async enqueuePayrollRunCompleted(
    trx: DbTrx,
    companyId: string,
    data: PayrollRunWebhookData
  ): Promise<void> {
    if (!features.webhooksEnabled) {
      return;
    }
    await this.enqueue(
      trx,
      companyId,
      'payroll.run.completed',
      payrollRunPayload(companyId, data)
    );
    await this.enqueue(
      trx,
      companyId,
      'pay_stub.created',
      payStubCreatedPayload(companyId, data)
    );
  }

  async enqueueBatchCompleted(
    companyId: string,
    data: BatchCompletedWebhookData
  ): Promise<void> {
    if (!features.webhooksEnabled) {
      return;
    }
    await this.db.transaction(async (trx) => {
      await this.enqueue(
        trx,
        companyId,
        'batch.completed',
        batchCompletedPayload(companyId, data)
      );
    });
  }

  async enqueuePaymentBatchSubmitted(
    companyId: string,
    data: PaymentBatchSubmittedWebhookData
  ): Promise<void> {
    if (!features.webhooksEnabled) {
      return;
    }
    await this.db.transaction(async (trx) => {
      await this.enqueue(
        trx,
        companyId,
        'payment.batch.submitted',
        paymentBatchSubmittedPayload(companyId, data)
      );
    });
  }

  private async enqueue(
    trx: DbTrx,
    companyId: string,
    eventType: WebhookEventType,
    payload: Record<string, unknown>
  ): Promise<void> {
    const subs = await this.subscriptions.findActiveForEvent(
      companyId,
      eventType,
      trx
    );
    for (const sub of subs) {
      await this.outbox.insert(trx, {
        subscriptionId: sub.id,
        companyId,
        eventType,
        payload,
      });
    }
  }
}
