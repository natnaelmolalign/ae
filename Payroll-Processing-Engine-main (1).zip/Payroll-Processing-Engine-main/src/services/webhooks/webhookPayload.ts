import type { WebhookEventType } from '../../config/webhooks';

export interface PayrollRunWebhookData {
  payrollRunId: string;
  employeeId: string;
  payPeriodId: string;
  payStubId: string;
  netPay: string;
  grossPay: string;
}

export interface BatchCompletedWebhookData {
  batchId: string;
  payPeriodId: string;
  status: string;
  successCount: number;
  failureCount: number;
  totalCount: number;
}

export interface PaymentBatchSubmittedWebhookData {
  paymentBatchId: string;
  payPeriodId: string | null;
  totalNetPay: string;
  totalAchCredit: string;
  entryCount: number;
  submittedAt: string;
}

export function buildWebhookEnvelope(
  eventType: WebhookEventType,
  companyId: string,
  data: Record<string, unknown>
): Record<string, unknown> {
  return {
    event: eventType,
    companyId,
    timestamp: new Date().toISOString(),
    data,
  };
}

/** Minimal payload — no employee names, SSN, or compensation details beyond ids/amounts. */
export function payrollRunPayload(
  companyId: string,
  data: PayrollRunWebhookData
): Record<string, unknown> {
  return buildWebhookEnvelope('payroll.run.completed', companyId, {
    payrollRunId: data.payrollRunId,
    employeeId: data.employeeId,
    payPeriodId: data.payPeriodId,
    payStubId: data.payStubId,
    netPay: data.netPay,
    grossPay: data.grossPay,
  });
}

export function payStubCreatedPayload(
  companyId: string,
  data: Pick<
    PayrollRunWebhookData,
    'payStubId' | 'employeeId' | 'payPeriodId' | 'netPay'
  >
): Record<string, unknown> {
  return buildWebhookEnvelope('pay_stub.created', companyId, {
    payStubId: data.payStubId,
    employeeId: data.employeeId,
    payPeriodId: data.payPeriodId,
    netPay: data.netPay,
  });
}

export function batchCompletedPayload(
  companyId: string,
  data: BatchCompletedWebhookData
): Record<string, unknown> {
  return buildWebhookEnvelope('batch.completed', companyId, { ...data });
}

export function paymentBatchSubmittedPayload(
  companyId: string,
  data: PaymentBatchSubmittedWebhookData
): Record<string, unknown> {
  return buildWebhookEnvelope('payment.batch.submitted', companyId, {
    ...data,
  });
}
