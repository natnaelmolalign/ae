import type {
  CreateWebhookSubscriptionInput,
  UpdateWebhookSubscriptionInput,
  WebhookSubscription,
} from '../../models/Webhook';
import {
  WEBHOOK_EVENT_TYPES,
  type WebhookEventType,
} from '../../config/webhooks';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type { WebhookSubscriptionRepository } from '../../repositories/interfaces';

export class WebhookSubscriptionService {
  constructor(private readonly repo: WebhookSubscriptionRepository) {}

  create(
    input: CreateWebhookSubscriptionInput,
    companyId: string
  ): Promise<WebhookSubscription> {
    this.validateEvents(input.events);
    return this.repo.create({ ...input, companyId });
  }

  get(id: string): Promise<WebhookSubscription | null> {
    return this.repo.findById(id);
  }

  list(companyId: string): Promise<WebhookSubscription[]> {
    return this.repo.findByCompany(companyId);
  }

  async update(
    id: string,
    input: UpdateWebhookSubscriptionInput
  ): Promise<WebhookSubscription> {
    if (input.events) {
      this.validateEvents(input.events);
    }
    const updated = await this.repo.update(id, input);
    if (!updated) {
      throw PayrollDomainError.notFound('WebhookSubscription', id);
    }
    return updated;
  }

  async delete(id: string): Promise<void> {
    const ok = await this.repo.delete(id);
    if (!ok) {
      throw PayrollDomainError.notFound('WebhookSubscription', id);
    }
  }

  /** API responses omit signing secret. */
  toPublicView(sub: WebhookSubscription) {
    return {
      id: sub.id,
      companyId: sub.companyId,
      url: sub.url,
      events: sub.events,
      enabled: sub.enabled,
      consecutiveFailures: sub.consecutiveFailures,
      disabledAt: sub.disabledAt,
      createdAt: sub.createdAt,
      updatedAt: sub.updatedAt,
    };
  }

  private validateEvents(events: WebhookEventType[]): void {
    if (events.length === 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'At least one event type is required'
      );
    }
    for (const e of events) {
      if (!WEBHOOK_EVENT_TYPES.includes(e)) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          `Unknown webhook event: ${e}`
        );
      }
    }
  }
}
