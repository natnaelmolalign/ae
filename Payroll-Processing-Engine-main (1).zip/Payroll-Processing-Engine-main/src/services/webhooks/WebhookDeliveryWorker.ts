import type { Knex } from 'knex';
import {
  WEBHOOK_BACKOFF_BASE_MS,
  WEBHOOK_DELIVERY_TIMEOUT_MS,
  WEBHOOK_MAX_ATTEMPTS,
  WEBHOOK_SUBSCRIPTION_FAILURE_THRESHOLD,
} from '../../config/webhooks';
import { features } from '../../config/features';
import { buildSignatureHeader } from '../../utils/webhookSignature';
import type {
  WebhookDeliveryRepository,
  WebhookOutboxRepository,
  WebhookSubscriptionRepository,
} from '../../repositories/interfaces';

export interface DeliveryWorkerResult {
  processed: number;
  delivered: number;
  failed: number;
}

export class WebhookDeliveryWorker {
  constructor(
    private readonly db: Knex,
    private readonly subscriptions: WebhookSubscriptionRepository,
    private readonly outbox: WebhookOutboxRepository,
    private readonly deliveries: WebhookDeliveryRepository
  ) {}

  async processPending(limit = 50): Promise<DeliveryWorkerResult> {
    if (!features.webhooksEnabled) {
      return { processed: 0, delivered: 0, failed: 0 };
    }

    const pending = await this.outbox.findPending(limit);
    let delivered = 0;
    let failed = 0;

    for (const entry of pending) {
      const sub = await this.subscriptions.findById(entry.subscriptionId);
      if (!sub || !sub.enabled) {
        await this.db.transaction(async (trx) => {
          await this.outbox.markFailed(trx, entry.id, entry.attempts + 1);
        });
        failed += 1;
        continue;
      }

      const attemptNumber = entry.attempts + 1;
      const body = JSON.stringify(entry.payload);
      const timestamp = Math.floor(Date.now() / 1000).toString();
      const signature = buildSignatureHeader(sub.secret, body, timestamp);

      let httpStatus: number | null = null;
      let errorMessage: string | null = null;
      let success = false;

      try {
        const controller = new AbortController();
        const timeout = setTimeout(
          () => controller.abort(),
          WEBHOOK_DELIVERY_TIMEOUT_MS
        );
        const response = await fetch(sub.url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Webhook-Signature': signature,
            'X-Webhook-Timestamp': timestamp,
            'X-Webhook-Id': entry.id,
            'X-Webhook-Event': entry.eventType,
          },
          body,
          signal: controller.signal,
        });
        clearTimeout(timeout);
        httpStatus = response.status;
        success = response.status >= 200 && response.status < 300;
        if (!success) {
          errorMessage = `HTTP ${response.status}`;
        }
      } catch (err) {
        errorMessage =
          err instanceof Error ? err.message : 'Webhook delivery failed';
      }

      await this.db.transaction(async (trx) => {
        await this.deliveries.insert(trx, {
          outboxId: entry.id,
          attemptNumber,
          httpStatus,
          errorMessage,
        });

        if (success) {
          await this.outbox.markDelivered(trx, entry.id);
          await this.subscriptions.resetFailures(trx, sub.id);
          return;
        }

        const retryable =
          httpStatus === null || httpStatus >= 500 || httpStatus === 429;
        if (retryable && attemptNumber < WEBHOOK_MAX_ATTEMPTS) {
          const delayMs =
            WEBHOOK_BACKOFF_BASE_MS * Math.pow(2, attemptNumber - 1);
          const nextAttempt = new Date(Date.now() + delayMs).toISOString();
          await this.outbox.markRetry(
            trx,
            entry.id,
            attemptNumber,
            nextAttempt
          );
        } else {
          await this.outbox.markFailed(trx, entry.id, attemptNumber);
          await this.subscriptions.recordDeliveryFailure(
            trx,
            sub.id,
            WEBHOOK_SUBSCRIPTION_FAILURE_THRESHOLD
          );
        }
      });

      if (success) {
        delivered += 1;
      } else {
        const retryable =
          httpStatus === null ||
          (httpStatus !== null && httpStatus >= 500) ||
          httpStatus === 429;
        if (!retryable || attemptNumber >= WEBHOOK_MAX_ATTEMPTS) {
          failed += 1;
        }
      }
    }

    return {
      processed: pending.length,
      delivered,
      failed,
    };
  }
}
