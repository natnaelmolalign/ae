import type {
  CreateWorkLocationInput,
  EmployeeWorkLocation,
  StateAllocationInput,
} from '../models/WorkLocationAllocation';
import type { EmployeeWorkLocationRepository } from '../repositories/interfaces';
import { MultiStateAllocationService } from './tax/MultiStateAllocationService';

export class EmployeeWorkLocationService {
  private readonly allocator = new MultiStateAllocationService();

  constructor(private readonly repo: EmployeeWorkLocationRepository) {}

  replace(
    employeeId: string,
    locations: CreateWorkLocationInput[]
  ): Promise<EmployeeWorkLocation[]> {
    const asAllocations: StateAllocationInput[] = locations.map((l) => ({
      stateCode: l.stateCode,
      percent: l.allocationPercent,
    }));
    this.allocator.validateAllocations(asAllocations);
    return this.repo.replaceForEmployee(employeeId, locations);
  }

  listActive(employeeId: string): Promise<EmployeeWorkLocation[]> {
    return this.repo.findActiveByEmployee(employeeId);
  }

  defaultAllocations(employeeId: string): Promise<StateAllocationInput[]> {
    return this.listActive(employeeId).then((rows) =>
      rows.map((r) => ({
        stateCode: r.stateCode,
        percent: r.allocationPercent,
      }))
    );
  }
}
