import type { EarningsLine } from '../../models/types';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import { add, compare } from '../../utils/decimalUtils';
import { REPORTED_TIP_TYPES, sumEarningsByTypes } from './tipEarningsUtils';

export interface AllocatedTipsSummary {
  cashTips: string;
  chargedTips: string;
  allocatedTips: string;
  totalTips: string;
}

export class AllocatedTipsService {
  /** Ensures tip lines are valid and allocated tips are not duplicated in gross via regular wages. */
  validateTipEarnings(lines: EarningsLine[]): AllocatedTipsSummary {
    const cashTips = sumEarningsByTypes(lines, ['cash_tips']);
    const chargedTips = sumEarningsByTypes(lines, ['charged_tips']);
    const allocatedTips = sumEarningsByTypes(lines, ['allocated_tips']);
    const totalTips = add(add(cashTips, chargedTips), allocatedTips);

    const regularTotal = lines
      .filter((l) => l.type === 'regular')
      .reduce((s, l) => add(s, l.amount), '0.00');

    if (
      compare(allocatedTips, '0.00') > 0 &&
      compare(regularTotal, '0.00') > 0 &&
      regularTotal === totalTips
    ) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'Allocated tips appear double-counted with regular wages equal to total tips',
        { regularTotal, totalTips }
      );
    }

    return { cashTips, chargedTips, allocatedTips, totalTips };
  }

  reportedTipsForMinimumWage(lines: EarningsLine[]): string {
    return sumEarningsByTypes(lines, REPORTED_TIP_TYPES);
  }
}
