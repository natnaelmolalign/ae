import type { Employee } from '../../models/types';
import {
  FEDERAL_MINIMUM_WAGE,
  FEDERAL_TIPPED_CASH_WAGE,
} from '../../config/tipCredit';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import { add, compare, mul, sub, type Money } from '../../utils/decimalUtils';

export interface TipCreditInput {
  hours: number;
  /** Cash wages paid at tipped rate (excluding tips). */
  directCashWages: string;
  /** Applicable minimum wage (default federal $7.25). */
  minimumWage?: string;
  /** Maximum credit toward minimum (default $5.12 = 7.25 - 2.13). */
  tippedCashWageRate?: string;
}

export interface TipCreditResult {
  requiredMinimumPay: Money;
  reportedTips: Money;
  directCashWages: Money;
  shortfallMakeUp: Money;
}

const TIPPED_EMPLOYMENT = new Set(['full_time_hourly', 'part_time']);

export class TipCreditCalculator {
  computeShortfall(
    employee: Employee,
    reportedTips: Money,
    input: TipCreditInput
  ): TipCreditResult {
    this.assertEligible(employee);

    if (input.hours <= 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'Tip credit hours must be positive'
      );
    }

    const minimumWage = input.minimumWage ?? FEDERAL_MINIMUM_WAGE;
    const required = mul(minimumWage, String(input.hours));

    const cashPlusTips = add(input.directCashWages, reportedTips);
    let shortfall = sub(required, cashPlusTips);
    if (compare(shortfall, '0.00') < 0) {
      shortfall = '0.00';
    }

    return {
      requiredMinimumPay: required,
      reportedTips,
      directCashWages: input.directCashWages,
      shortfallMakeUp: shortfall,
    };
  }

  assertEligible(employee: Employee): void {
    if (!TIPPED_EMPLOYMENT.has(employee.employmentType)) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'FLSA tip credit applies only to hourly employees',
        { employmentType: employee.employmentType }
      );
    }
  }

  /** Direct cash wage from tipped rate × hours when not supplied explicitly. */
  defaultDirectCashWages(
    hours: number,
    tippedRate = FEDERAL_TIPPED_CASH_WAGE
  ): string {
    return mul(tippedRate, String(hours));
  }
}
