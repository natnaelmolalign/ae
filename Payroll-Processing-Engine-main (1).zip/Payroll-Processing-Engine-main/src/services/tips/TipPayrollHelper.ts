import type {
  EarningsLine,
  Employee,
  PayrollRunInput,
} from '../../models/types';
import { features } from '../../config/features';
import { compare } from '../../utils/decimalUtils';
import { AllocatedTipsService } from './AllocatedTipsService';
import { TipCreditCalculator } from './TipCreditCalculator';
import type { AllocatedTipsSummary } from './AllocatedTipsService';

export interface PreparedTipEarnings {
  earnings: EarningsLine[];
  tipSummary: AllocatedTipsSummary & { tipCreditMakeup: string };
}

export class TipPayrollHelper {
  private readonly allocated = new AllocatedTipsService();
  private readonly tipCredit = new TipCreditCalculator();

  prepare(employee: Employee, input: PayrollRunInput): PreparedTipEarnings {
    let earnings = [...input.earnings];
    let tipCreditMakeup = '0.00';

    if (!features.tipsAndTipCreditEnabled) {
      return {
        earnings,
        tipSummary: {
          cashTips: '0.00',
          chargedTips: '0.00',
          allocatedTips: '0.00',
          totalTips: '0.00',
          tipCreditMakeup: '0.00',
        },
      };
    }

    const summary = this.allocated.validateTipEarnings(earnings);

    if (input.tipCredit) {
      const reported = this.allocated.reportedTipsForMinimumWage(earnings);
      const credit = this.tipCredit.computeShortfall(
        employee,
        reported,
        input.tipCredit
      );
      tipCreditMakeup = credit.shortfallMakeUp;
      if (compare(tipCreditMakeup, '0.00') > 0) {
        earnings = [
          ...earnings,
          { type: 'tip_credit_makeup', amount: tipCreditMakeup },
        ];
      }
    }

    return {
      earnings,
      tipSummary: { ...summary, tipCreditMakeup },
    };
  }
}
