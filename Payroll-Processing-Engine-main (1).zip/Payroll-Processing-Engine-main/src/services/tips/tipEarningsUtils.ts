import type { EarningsLine, EarningsType } from '../../models/types';
import { add } from '../../utils/decimalUtils';

export const TIP_EARNING_TYPES: EarningsType[] = [
  'cash_tips',
  'charged_tips',
  'allocated_tips',
  'tip_credit_makeup',
];

export const REPORTED_TIP_TYPES: EarningsType[] = ['cash_tips', 'charged_tips'];

export function isTipEarning(type: string): boolean {
  return (TIP_EARNING_TYPES as string[]).includes(type);
}

export function sumEarningsByTypes(
  lines: EarningsLine[],
  types: EarningsType[]
): string {
  let total = '0.00';
  for (const line of lines) {
    if (types.includes(line.type)) {
      total = add(total, line.amount);
    }
  }
  return total;
}
