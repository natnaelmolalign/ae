import type { Knex } from 'knex';
import { add } from '../../utils/decimalUtils';
import { isTipEarning } from './tipEarningsUtils';

export interface TipRegisterRow {
  payrollRunId: string;
  employeeId: string;
  employeeName: string;
  earningType: string;
  amount: string;
}

export interface TipRegister {
  payPeriodId: string;
  rows: TipRegisterRow[];
  totals: {
    cashTips: string;
    chargedTips: string;
    allocatedTips: string;
    tipCreditMakeup: string;
    total: string;
  };
}

export class TipReportingService {
  constructor(private readonly db: Knex) {}

  async buildForPeriod(payPeriodId: string): Promise<TipRegister> {
    const rows = await this.db('earnings_lines as el')
      .join('payroll_runs as pr', 'el.payroll_run_id', 'pr.id')
      .join('employees as e', 'pr.employee_id', 'e.id')
      .where('pr.pay_period_id', payPeriodId)
      .select(
        'pr.id as payroll_run_id',
        'pr.employee_id',
        'e.first_name',
        'e.last_name',
        'el.type',
        'el.amount'
      );

    const registerRows: TipRegisterRow[] = [];
    let cashTips = '0.00';
    let chargedTips = '0.00';
    let allocatedTips = '0.00';
    let tipCreditMakeup = '0.00';

    for (const r of rows) {
      const type = String(r.type);
      if (!isTipEarning(type)) continue;
      const amount = String(r.amount);
      registerRows.push({
        payrollRunId: String(r.payroll_run_id),
        employeeId: String(r.employee_id),
        employeeName: `${r.first_name} ${r.last_name}`,
        earningType: type,
        amount,
      });
      if (type === 'cash_tips') cashTips = add(cashTips, amount);
      else if (type === 'charged_tips') chargedTips = add(chargedTips, amount);
      else if (type === 'allocated_tips')
        allocatedTips = add(allocatedTips, amount);
      else if (type === 'tip_credit_makeup')
        tipCreditMakeup = add(tipCreditMakeup, amount);
    }

    const total = add(
      add(add(cashTips, chargedTips), allocatedTips),
      tipCreditMakeup
    );

    return {
      payPeriodId,
      rows: registerRows,
      totals: { cashTips, chargedTips, allocatedTips, tipCreditMakeup, total },
    };
  }
}
