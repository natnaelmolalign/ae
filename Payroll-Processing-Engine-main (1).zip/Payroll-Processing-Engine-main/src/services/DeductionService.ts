import type { DeductionEnrollment, YearToDate } from '../models/types';
import { DeductionLimitTracker } from './benefits/DeductionLimitTracker';
import type { LimitCapResult } from './benefits/DeductionLimitTracker';
import { add, compare, mul, sub, sum, type Money } from '../utils/decimalUtils';

export interface DeductionBases {
  federalTaxableReduction: Money;
  stateTaxableReduction: Money;
  ssTaxableReduction: Money;
  medicareTaxableReduction: Money;
  pretax401kAmount: Money;
  roth401kAmount: Money;
  hsaAmount: Money;
  fsaAmount: Money;
  section125Amount: Money;
  postTaxTotal: Money;
  postTaxLines: { type: string; amount: Money }[];
  /** Amounts capped by annual limits (requested − allowed) */
  limitAdjustments: LimitAdjustment[];
}

export interface LimitAdjustment {
  type: string;
  requested: Money;
  allowed: Money;
  reason: string;
}

const PRETAX_ORDER: string[] = ['section_125', 'hsa', 'fsa', '401k_pretax'];
const POST_TAX_TYPES = new Set(['401k_roth', 'life_insurance', 'charitable']);

export interface ApplyPreTaxOptions {
  taxYear: number;
  gross: Money;
}

export class DeductionService {
  constructor(private readonly limitTracker = new DeductionLimitTracker()) {}

  applyPreTax(
    grossFederal: Money,
    grossState: Money,
    grossSs: Money,
    grossMedicare: Money,
    enrollments: DeductionEnrollment[],
    ytd: YearToDate,
    options: ApplyPreTaxOptions
  ): DeductionBases {
    const sorted = [...enrollments].sort(
      (a, b) =>
        (a.priority ?? PRETAX_ORDER.indexOf(a.type)) -
        (b.priority ?? PRETAX_ORDER.indexOf(b.type))
    );

    let federal = grossFederal;
    let state = grossState;
    let ss = grossSs;
    let medicare = grossMedicare;
    let pretax401k = '0.00';
    let roth401k = '0.00';
    let hsa = '0.00';
    let fsa = '0.00';
    let section125 = '0.00';
    const postTaxLines: { type: string; amount: Money }[] = [];
    let postTaxTotal = '0.00';
    const limitAdjustments: LimitAdjustment[] = [];

    const runningYtd = { ...ytd };
    let electiveDeferralUsed = this.limitTracker.electiveDeferralYtd(ytd);

    for (const d of sorted) {
      const requested = this.resolveAmount(d, options.gross);
      if (POST_TAX_TYPES.has(d.type)) {
        const allowed = this.capPostTaxDeduction(
          d,
          requested,
          runningYtd,
          electiveDeferralUsed,
          options.taxYear,
          limitAdjustments
        );
        if (d.type === '401k_roth') {
          roth401k = add(roth401k, allowed);
          electiveDeferralUsed = add(electiveDeferralUsed, allowed);
          runningYtd.roth401k = add(runningYtd.roth401k, allowed);
        }
        postTaxLines.push({ type: d.type, amount: allowed });
        postTaxTotal = add(postTaxTotal, allowed);
        continue;
      }

      const allowed = this.capPreTaxDeduction(
        d,
        requested,
        runningYtd,
        electiveDeferralUsed,
        options.taxYear,
        limitAdjustments
      );

      if (d.type === '401k_pretax') {
        pretax401k = add(pretax401k, allowed);
        electiveDeferralUsed = add(electiveDeferralUsed, allowed);
        runningYtd.pretax401k = add(runningYtd.pretax401k, allowed);
        federal = sub(federal, allowed);
        state = sub(state, allowed);
      } else if (d.type === 'section_125') {
        section125 = add(section125, allowed);
        federal = sub(federal, allowed);
        state = sub(state, allowed);
        ss = sub(ss, allowed);
        medicare = sub(medicare, allowed);
        runningYtd.section125 = add(runningYtd.section125, allowed);
      } else if (d.type === 'hsa') {
        hsa = add(hsa, allowed);
        federal = sub(federal, allowed);
        state = sub(state, allowed);
        runningYtd.hsa = add(runningYtd.hsa, allowed);
      } else if (d.type === 'fsa') {
        fsa = add(fsa, allowed);
        federal = sub(federal, allowed);
        state = sub(state, allowed);
        runningYtd.fsa = add(runningYtd.fsa, allowed);
      }
    }

    return {
      federalTaxableReduction: sub(grossFederal, federal),
      stateTaxableReduction: sub(grossState, state),
      ssTaxableReduction: sub(grossSs, ss),
      medicareTaxableReduction: sub(grossMedicare, medicare),
      pretax401kAmount: pretax401k,
      roth401kAmount: roth401k,
      hsaAmount: hsa,
      fsaAmount: fsa,
      section125Amount: section125,
      postTaxTotal,
      postTaxLines,
      limitAdjustments,
    };
  }

  /** @deprecated Use DeductionLimitTracker via applyPreTax */
  enforce401kLimit(requested: Money, ytd401k: Money, taxYear = 2024): Money {
    const ytd = {
      pretax401k: ytd401k,
      roth401k: '0.00',
    } as YearToDate;
    return this.limitTracker.capElectiveDeferral(requested, ytd, taxYear, false)
      .allowed;
  }

  totalDeductionsFromGross(bases: DeductionBases): Money {
    return sum([bases.federalTaxableReduction, bases.postTaxTotal]);
  }

  private capPreTaxDeduction(
    d: DeductionEnrollment,
    requested: Money,
    runningYtd: YearToDate,
    electiveDeferralUsed: Money,
    taxYear: number,
    adjustments: LimitAdjustment[]
  ): Money {
    let cap: LimitCapResult;

    if (d.type === '401k_pretax') {
      const annualLimit = this.limitTracker.deferral402gLimit(
        taxYear,
        d.catchUpEligible ?? false
      );
      cap = this.limitTracker.capAgainstAnnual(
        requested,
        electiveDeferralUsed,
        annualLimit
      );
    } else if (d.type === 'section_125') {
      cap = this.limitTracker.capEnrollmentAnnualLimit(
        requested,
        runningYtd.section125,
        d.annualLimit
      );
    } else if (d.type === 'hsa') {
      if (d.annualLimit) {
        cap = this.limitTracker.capAgainstAnnual(
          requested,
          runningYtd.hsa,
          d.annualLimit
        );
      } else {
        cap = this.limitTracker.capHsa(
          requested,
          runningYtd.hsa,
          taxYear,
          d.hsaCoverage ?? 'individual'
        );
      }
    } else if (d.type === 'fsa') {
      cap = this.limitTracker.capFsa(requested, runningYtd.fsa, taxYear);
    } else {
      cap = this.limitTracker.capEnrollmentAnnualLimit(
        requested,
        '0.00',
        d.annualLimit
      );
    }

    this.recordAdjustment(d.type, cap, adjustments);
    return cap.allowed;
  }

  private capPostTaxDeduction(
    d: DeductionEnrollment,
    requested: Money,
    runningYtd: YearToDate,
    electiveDeferralUsed: Money,
    taxYear: number,
    adjustments: LimitAdjustment[]
  ): Money {
    if (d.type !== '401k_roth') {
      return requested;
    }

    const annualLimit = this.limitTracker.deferral402gLimit(
      taxYear,
      d.catchUpEligible ?? false
    );
    const cap = this.limitTracker.capAgainstAnnual(
      requested,
      electiveDeferralUsed,
      annualLimit
    );
    this.recordAdjustment(d.type, cap, adjustments);
    return cap.allowed;
  }

  private recordAdjustment(
    type: string,
    cap: LimitCapResult,
    adjustments: LimitAdjustment[]
  ): void {
    if (compare(cap.requested, cap.allowed) !== 0) {
      adjustments.push({
        type,
        requested: cap.requested,
        allowed: cap.allowed,
        reason: `Annual limit ${cap.annualLimit}; YTD ${cap.ytdBefore}; remaining ${cap.remaining}`,
      });
    }
  }

  private resolveAmount(d: DeductionEnrollment, gross: Money): Money {
    if (d.percentOfGross) {
      return mul(gross, d.percentOfGross);
    }
    return d.amountPerPeriod;
  }
}
