import { differenceInMinutes, parseISO } from 'date-fns';
import type { Shift, ShiftAssignment } from '../../models/WorkforceScheduling';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type {
  ShiftAssignmentRepository,
  ShiftRepository,
} from '../../repositories/interfaces';

export class SchedulingService {
  constructor(
    private readonly shiftRepo: ShiftRepository,
    private readonly assignmentRepo: ShiftAssignmentRepository
  ) {}

  async createShift(
    companyId: string,
    input: {
      workDate: string;
      startTime: string;
      endTime: string;
      breakMinutes?: number;
      departmentId?: string | null;
      locationCode?: string | null;
    }
  ): Promise<Shift> {
    const start = parseISO(input.startTime);
    const end = parseISO(input.endTime);
    if (end <= start) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'Shift end time must be after start time'
      );
    }
    return this.shiftRepo.create({
      companyId,
      workDate: input.workDate,
      startTime: input.startTime,
      endTime: input.endTime,
      breakMinutes: input.breakMinutes ?? 0,
      departmentId: input.departmentId ?? null,
      locationCode: input.locationCode ?? null,
    });
  }

  async assignEmployee(
    companyId: string,
    shiftId: string,
    employeeId: string
  ): Promise<ShiftAssignment> {
    const shift = await this.shiftRepo.findById(shiftId, companyId);
    if (!shift) {
      throw PayrollDomainError.notFound('Shift', shiftId);
    }
    const scheduledMinutes = differenceInMinutes(
      parseISO(shift.endTime),
      parseISO(shift.startTime)
    );
    return this.assignmentRepo.create({
      companyId,
      shiftId,
      employeeId,
      status: 'pending',
      scheduledMinutes,
      approvedMinutes: null,
      approvedAt: null,
      approvedBy: null,
      payrollRunId: null,
    });
  }

  async listShifts(companyId: string, workDate?: string): Promise<Shift[]> {
    return this.shiftRepo.listByCompany(companyId, workDate);
  }

  async listAssignments(
    companyId: string,
    filters: {
      employeeId?: string;
      shiftId?: string;
      status?: ShiftAssignment['status'];
    }
  ): Promise<ShiftAssignment[]> {
    return this.assignmentRepo.list(companyId, filters);
  }
}
