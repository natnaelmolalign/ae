import type { Knex } from 'knex';
import type { PayPeriod, TimeEntry } from '../../models/types';
import type { Shift, ShiftAssignment } from '../../models/WorkforceScheduling';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type {
  ShiftAssignmentRepository,
  ShiftRepository,
  TimeEntryRepository,
  TimeExceptionRepository,
} from '../../repositories/interfaces';
import { features } from '../../config/features';
import { isDateInPayPeriod } from '../../utils/timeEntryUtils';

const DEFAULT_MINUTE_TOLERANCE = 15;

export class TimeApprovalService {
  constructor(
    private readonly assignmentRepo: ShiftAssignmentRepository,
    private readonly shiftRepo: ShiftRepository,
    private readonly timeEntryRepo: TimeEntryRepository,
    private readonly timeExceptionRepo: TimeExceptionRepository
  ) {}

  async approve(
    assignmentId: string,
    companyId: string,
    actor: string,
    minuteTolerance = DEFAULT_MINUTE_TOLERANCE
  ): Promise<ShiftAssignment> {
    const assignment = await this.assignmentRepo.findById(
      assignmentId,
      companyId
    );
    if (!assignment) {
      throw PayrollDomainError.notFound('ShiftAssignment', assignmentId);
    }
    if (assignment.status !== 'pending') {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        `Assignment is ${assignment.status}; only pending can be approved`
      );
    }

    const entries =
      await this.timeEntryRepo.findByShiftAssignment(assignmentId);
    const workedMinutes = entries.reduce((sum, e) => sum + e.roundedMinutes, 0);
    if (entries.length === 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'Cannot approve shift without clocked time entries'
      );
    }
    if (
      Math.abs(workedMinutes - assignment.scheduledMinutes) > minuteTolerance
    ) {
      throw new PayrollDomainError(
        PayrollErrorCode.TIME_APPROVAL_TOLERANCE_EXCEEDED,
        `Worked ${workedMinutes} minutes differs from scheduled ${assignment.scheduledMinutes} by more than ${minuteTolerance} minutes`,
        {
          workedMinutes,
          scheduledMinutes: assignment.scheduledMinutes,
          minuteTolerance,
        }
      );
    }

    return this.assignmentRepo.update(assignmentId, companyId, {
      status: 'approved',
      approvedMinutes: workedMinutes,
      approvedAt: new Date().toISOString(),
      approvedBy: actor,
    });
  }

  async reject(
    assignmentId: string,
    companyId: string,
    actor: string,
    notes: string
  ): Promise<ShiftAssignment> {
    const assignment = await this.assignmentRepo.findById(
      assignmentId,
      companyId
    );
    if (!assignment) {
      throw PayrollDomainError.notFound('ShiftAssignment', assignmentId);
    }
    await this.timeExceptionRepo.create({
      companyId,
      shiftAssignmentId: assignmentId,
      exceptionType: 'unscheduled_overtime',
      notes: `Rejected by ${actor}: ${notes}`,
      resolved: true,
    });
    return this.assignmentRepo.update(assignmentId, companyId, {
      status: 'rejected',
      approvedBy: actor,
      approvedAt: new Date().toISOString(),
    });
  }

  async assertPayrollReady(
    employeeId: string,
    companyId: string,
    payPeriod: PayPeriod
  ): Promise<void> {
    if (!features.workforceSchedulingEnabled) return;

    const assignments = await this.assignmentRepo.listForEmployeeInPeriod(
      employeeId,
      companyId,
      payPeriod.startDate,
      payPeriod.endDate
    );

    const blocking = assignments.filter(
      (a) => a.status === 'pending' || a.status === 'rejected'
    );
    if (blocking.length > 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.TIME_NOT_APPROVED,
        `${blocking.length} shift assignment(s) are not approved for this pay period`,
        { assignmentIds: blocking.map((a) => a.id) }
      );
    }
  }

  async filterPayrollEntries(
    employeeId: string,
    companyId: string,
    payPeriod: PayPeriod,
    entries: TimeEntry[]
  ): Promise<TimeEntry[]> {
    if (!features.workforceSchedulingEnabled) {
      return entries;
    }
    const approvedAssignmentIds = new Set(
      (
        await this.assignmentRepo.listForEmployeeInPeriod(
          employeeId,
          companyId,
          payPeriod.startDate,
          payPeriod.endDate
        )
      )
        .filter(
          (a) => a.status === 'approved' || a.status === 'exported_to_payroll'
        )
        .map((a) => a.id)
    );

    return entries.filter((entry) => {
      if (!entry.shiftAssignmentId) return true;
      return approvedAssignmentIds.has(entry.shiftAssignmentId);
    });
  }

  async markExported(
    trx: Knex.Transaction,
    employeeId: string,
    companyId: string,
    payPeriod: PayPeriod,
    payrollRunId: string
  ): Promise<void> {
    if (!features.workforceSchedulingEnabled) return;
    const assignments = await this.assignmentRepo.listForEmployeeInPeriod(
      employeeId,
      companyId,
      payPeriod.startDate,
      payPeriod.endDate,
      trx
    );
    for (const assignment of assignments.filter(
      (a) => a.status === 'approved'
    )) {
      await this.assignmentRepo.update(
        assignment.id,
        companyId,
        { status: 'exported_to_payroll', payrollRunId },
        trx
      );
    }
  }

  async getShiftForAssignment(
    assignment: ShiftAssignment,
    companyId: string
  ): Promise<Shift | null> {
    return this.shiftRepo.findById(assignment.shiftId, companyId);
  }

  async listApprovedWithShifts(
    employeeId: string,
    companyId: string,
    payPeriod: PayPeriod
  ): Promise<Array<{ assignment: ShiftAssignment; shift: Shift }>> {
    const assignments = await this.assignmentRepo.listForEmployeeInPeriod(
      employeeId,
      companyId,
      payPeriod.startDate,
      payPeriod.endDate
    );
    const out: Array<{ assignment: ShiftAssignment; shift: Shift }> = [];
    for (const assignment of assignments.filter(
      (a) => a.status === 'approved' || a.status === 'exported_to_payroll'
    )) {
      const shift = await this.shiftRepo.findById(
        assignment.shiftId,
        companyId
      );
      if (shift) out.push({ assignment, shift });
    }
    return out;
  }

  entriesInPeriod(entries: TimeEntry[], payPeriod: PayPeriod): TimeEntry[] {
    return entries.filter(
      (e) =>
        e.payPeriodId === payPeriod.id ||
        isDateInPayPeriod(e.workDate, payPeriod.startDate, payPeriod.endDate)
    );
  }
}
