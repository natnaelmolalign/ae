import type { Money } from '../../utils/decimalUtils';
import { mul } from '../../utils/decimalUtils';

export interface MealPenaltyInput {
  stateCode: string;
  shiftMinutes: number;
  breakMinutes: number;
  hourlyRate: Money;
}

export interface MealPenaltyResult {
  premiumHours: number;
  premiumAmount: Money;
  reason: string;
}

const CA_MEAL_THRESHOLD_MINUTES = 5 * 60;
const CA_MIN_BREAK_MINUTES = 30;

/**
 * California meal break premium: 1 hour of pay when shift exceeds 5 hours without 30-min break.
 */
export function calculateMealPenalty(
  input: MealPenaltyInput
): MealPenaltyResult | null {
  if (input.stateCode.toUpperCase() !== 'CA') {
    return null;
  }
  if (input.shiftMinutes <= CA_MEAL_THRESHOLD_MINUTES) {
    return null;
  }
  if (input.breakMinutes >= CA_MIN_BREAK_MINUTES) {
    return null;
  }
  return {
    premiumHours: 1,
    premiumAmount: mul(input.hourlyRate, '1'),
    reason: 'CA meal break premium: shift over 5 hours without 30-minute break',
  };
}
