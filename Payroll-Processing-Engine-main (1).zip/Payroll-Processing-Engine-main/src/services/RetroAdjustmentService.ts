import { parseISO, isAfter, isBefore } from 'date-fns';
import { randomUUID } from 'crypto';
import type {
  Employee,
  EarningsLine,
  PayPeriod,
  PayrollRunInput,
  RetroAdjustment,
} from '../models/types';
import type {
  PeriodPayrollDelta,
  RetroAdjustmentPreview,
  RetroAdjustmentRecord,
} from '../models/RetroAdjustment';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import type {
  PayStubRepository,
  RetroAdjustmentRepository,
  YtdRepository,
} from '../repositories/interfaces';
import { add, compare, sub } from '../utils/decimalUtils';
import { paymentYear } from '../utils/payPeriodUtils';
import { PayrollRunService } from './PayrollRunService';

export type RetroRunInputFactory = (period: PayPeriod) => PayrollRunInput;

export class RetroAdjustmentService {
  constructor(
    private readonly payrollRun: PayrollRunService,
    private readonly payStubRepo: PayStubRepository,
    private readonly retroRepo: RetroAdjustmentRepository,
    private readonly ytdRepo: YtdRepository
  ) {}

  findAffectedPeriods(
    periods: PayPeriod[],
    effectiveDate: string,
    currentPeriod: PayPeriod,
    terminationDate: string | null
  ): PayPeriod[] {
    const effective = parseISO(effectiveDate);

    return periods
      .filter((p) => {
        const periodEnd = parseISO(p.endDate);
        const periodStart = parseISO(p.startDate);
        const currentEnd = parseISO(currentPeriod.endDate);

        if (isBefore(periodEnd, effective)) return false;
        if (isAfter(periodStart, currentEnd)) return false;

        if (terminationDate) {
          const term = parseISO(terminationDate);
          if (isAfter(parseISO(p.paymentDate), term)) return false;
        }
        return true;
      })
      .sort((a, b) => a.periodIndex - b.periodIndex);
  }

  assertNotAfterTermination(
    employee: Employee,
    currentPeriod: PayPeriod
  ): void {
    if (
      employee.terminationDate &&
      isAfter(
        parseISO(currentPeriod.paymentDate),
        parseISO(employee.terminationDate)
      )
    ) {
      throw PayrollDomainError.retroAfterTermination();
    }
  }

  async createDraft(
    employeeId: string,
    effectiveDate: string,
    currentPayPeriodId: string,
    reason: string,
    earningsPerPeriod: EarningsLine[]
  ): Promise<RetroAdjustmentRecord> {
    return this.retroRepo.create({
      id: randomUUID(),
      employeeId,
      status: 'draft',
      effectiveDate,
      currentPayPeriodId,
      reason,
      earningsPerPeriod,
    });
  }

  async computePreview(
    employee: Employee,
    allPeriods: PayPeriod[],
    effectiveDate: string,
    currentPeriod: PayPeriod,
    runInputFactory: RetroRunInputFactory
  ): Promise<RetroAdjustmentPreview> {
    this.assertNotAfterTermination(employee, currentPeriod);

    const affected = this.findAffectedPeriods(
      allPeriods,
      effectiveDate,
      currentPeriod,
      employee.terminationDate
    );

    const taxYear = paymentYear(currentPeriod.paymentDate);
    let ytd = await this.ytdRepo.get(employee.id, taxYear);

    const periodDeltas: PeriodPayrollDelta[] = [];
    let totalNetCatchUp = '0.00';

    const pastPeriods = affected.filter((p) => p.id !== currentPeriod.id);

    for (const period of pastPeriods) {
      const original = await this.payStubRepo.findOriginalByEmployeeAndPeriod(
        employee.id,
        period.id
      );
      const originalGross = original?.grossPay ?? '0.00';
      const originalNet = original?.netPay ?? '0.00';
      const { result, updatedYtd } = await this.payrollRun.previewWithYtd(
        employee,
        period,
        runInputFactory(period),
        ytd,
        original != null,
        original != null ? originalGross : '0.00'
      );
      ytd = updatedYtd;

      const grossDelta = sub(result.payStub.grossPay, originalGross);
      const netDelta = sub(result.payStub.netPay, originalNet);

      periodDeltas.push({
        payPeriodId: period.id,
        paymentDate: period.paymentDate,
        originalPayStubId: original?.id ?? null,
        originalGross,
        originalNet,
        recomputedGross: result.payStub.grossPay,
        recomputedNet: result.payStub.netPay,
        grossDelta,
        netDelta,
      });

      totalNetCatchUp = add(totalNetCatchUp, netDelta);
    }

    const negativeNetRecovery = compare(totalNetCatchUp, '0.00') < 0;

    return {
      affectedPeriodIds: affected.map((p) => p.id),
      periodDeltas,
      totalNetCatchUp,
      projectedYtdGross: ytd.grossEarnings,
      negativeNetRecovery,
    };
  }

  async preview(
    adjustmentId: string,
    employee: Employee,
    allPeriods: PayPeriod[],
    currentPeriod: PayPeriod,
    runInputFactory: RetroRunInputFactory
  ): Promise<RetroAdjustmentRecord> {
    const record = await this.requireRecord(adjustmentId);
    if (record.status !== 'draft') {
      throw PayrollDomainError.retroInvalidState(
        adjustmentId,
        record.status,
        'draft'
      );
    }

    const preview = await this.computePreview(
      employee,
      allPeriods,
      record.effectiveDate,
      currentPeriod,
      runInputFactory
    );

    const updated = await this.retroRepo.update(adjustmentId, {
      status: 'previewed',
      preview,
    });
    return updated!;
  }

  async approve(adjustmentId: string): Promise<RetroAdjustmentRecord> {
    const record = await this.requireRecord(adjustmentId);
    if (record.status !== 'previewed') {
      throw PayrollDomainError.retroInvalidState(
        adjustmentId,
        record.status,
        'previewed'
      );
    }
    const updated = await this.retroRepo.update(adjustmentId, {
      status: 'approved',
    });
    return updated!;
  }

  async apply(
    adjustmentId: string,
    employee: Employee,
    allPeriods: PayPeriod[],
    currentPeriod: PayPeriod,
    runInputFactory: RetroRunInputFactory
  ): Promise<{
    record: RetroAdjustmentRecord;
    correction: RetroAdjustment;
    catchUpPayStubId: string | null;
  }> {
    const record = await this.requireRecord(adjustmentId);
    if (record.status !== 'approved') {
      throw PayrollDomainError.retroInvalidState(
        adjustmentId,
        record.status,
        'approved'
      );
    }
    if (!record.preview) {
      throw PayrollDomainError.notFound('Retro preview', adjustmentId);
    }

    this.assertNotAfterTermination(employee, currentPeriod);

    const affected = this.findAffectedPeriods(
      allPeriods,
      record.effectiveDate,
      currentPeriod,
      employee.terminationDate
    );

    const pastPeriods = affected.filter((p) => p.id !== currentPeriod.id);
    let primaryCorrectsId: string | null = null;

    for (const period of pastPeriods) {
      const original = await this.payStubRepo.findOriginalByEmployeeAndPeriod(
        employee.id,
        period.id
      );
      if (!original) continue;

      if (!primaryCorrectsId) primaryCorrectsId = original.id;

      await this.payrollRun.run(employee, period, runInputFactory(period), {
        isCorrection: true,
        correctionOriginalGross: original.grossPay,
        correctsPayStubId: original.id,
      });
    }

    let catchUpPayStubId: string | null = null;
    const { totalNetCatchUp } = record.preview;
    if (compare(totalNetCatchUp, '0.00') !== 0) {
      const currentOriginal =
        await this.payStubRepo.findOriginalByEmployeeAndPeriod(
          employee.id,
          currentPeriod.id
        );
      const catchUp = await this.payrollRun.runCatchUpCorrection(
        employee,
        currentPeriod,
        totalNetCatchUp,
        currentOriginal?.id ?? primaryCorrectsId
      );
      catchUpPayStubId = catchUp.payStub.id;
    }

    const updated = await this.retroRepo.update(adjustmentId, {
      status: 'applied',
      catchUpPayStubId,
    });

    return {
      record: updated!,
      correction: {
        id: adjustmentId,
        employeeId: employee.id,
        effectiveDate: record.effectiveDate,
        reason: record.reason,
        earningsDelta: record.earningsPerPeriod,
        appliedInPayPeriodId: currentPeriod.id,
      },
      catchUpPayStubId,
    };
  }

  /** Legacy direct apply (skips workflow). */
  async applyDirect(
    employee: Employee,
    allPeriods: PayPeriod[],
    effectiveDate: string,
    currentPeriod: PayPeriod,
    runInputFactory: RetroRunInputFactory,
    reason: string
  ): Promise<RetroAdjustment> {
    const draft = await this.createDraft(
      employee.id,
      effectiveDate,
      currentPeriod.id,
      reason,
      runInputFactory(currentPeriod).earnings
    );
    await this.preview(
      draft.id,
      employee,
      allPeriods,
      currentPeriod,
      runInputFactory
    );
    await this.approve(draft.id);
    const { correction } = await this.apply(
      draft.id,
      employee,
      allPeriods,
      currentPeriod,
      runInputFactory
    );
    return correction;
  }

  private async requireRecord(id: string): Promise<RetroAdjustmentRecord> {
    const record = await this.retroRepo.findById(id);
    if (!record) {
      throw PayrollDomainError.notFound('Retro adjustment', id);
    }
    return record;
  }
}
