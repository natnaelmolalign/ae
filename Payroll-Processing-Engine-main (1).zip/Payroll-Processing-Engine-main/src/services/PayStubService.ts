import { randomUUID } from 'crypto';
import type {
  PayStub,
  PayStubLine,
  TaxWithholdingResult,
  YearToDate,
} from '../models/types';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import type { EquityEarningsSummary } from './equity/EquityCompensationService';
import type { ScheduledDeductionLine } from './deductions/ScheduledDeductionService';
import { sub, sum, type Money } from '../utils/decimalUtils';

export class PayStubService {
  build(
    employeeId: string,
    payPeriodId: string,
    gross: Money,
    taxes: TaxWithholdingResult,
    pretax401k: Money,
    section125: Money,
    hsa: Money,
    fsa: Money,
    roth401k: Money,
    postTaxDeductions: Money,
    garnishments: Money,
    ytd: YearToDate,
    isCorrection: boolean,
    correctsPayStubId?: string | null,
    tipCreditMakeup = '0.00',
    equitySummary: EquityEarningsSummary | null = null,
    scheduledLines: ScheduledDeductionLine[] = []
  ): PayStub {
    const taxTotal = sum([
      taxes.federalIncome,
      taxes.stateIncome,
      taxes.localIncome,
      taxes.socialSecurity,
      taxes.medicare,
      taxes.medicareAdditional,
    ]);
    const scheduledTotal = sum(scheduledLines.map((l) => l.amount));
    const deductionsTotal = sum([
      pretax401k,
      section125,
      postTaxDeductions,
      scheduledTotal,
      garnishments,
    ]);
    const netPay = sub(sub(gross, taxTotal), deductionsTotal);

    const lines: PayStubLine[] = [
      line('earnings', 'Gross Pay', gross, ytd.grossEarnings),
      ...(equitySummary && parseFloat(equitySummary.rsuVest) > 0
        ? [
            line(
              'earnings',
              'RSU Vest',
              equitySummary.rsuVest,
              equitySummary.rsuVest
            ),
          ]
        : []),
      ...(equitySummary && parseFloat(equitySummary.nqsoExercise) > 0
        ? [
            line(
              'earnings',
              'NQSO Exercise',
              equitySummary.nqsoExercise,
              equitySummary.nqsoExercise
            ),
          ]
        : []),
      ...(parseFloat(tipCreditMakeup) > 0
        ? [
            line(
              'earnings',
              'FLSA Tip Credit Make-Up',
              tipCreditMakeup,
              tipCreditMakeup
            ),
          ]
        : []),
      line('deduction', 'Section 125', section125, ytd.section125),
      line('deduction', '401(k) Pre-Tax', pretax401k, ytd.pretax401k),
      ...(parseFloat(hsa) > 0 ? [line('deduction', 'HSA', hsa, ytd.hsa)] : []),
      ...(parseFloat(fsa) > 0 ? [line('deduction', 'FSA', fsa, ytd.fsa)] : []),
      ...(parseFloat(roth401k) > 0
        ? [line('deduction', 'Roth 401(k)', roth401k, ytd.roth401k)]
        : []),
      ...scheduledLines
        .filter((l) => parseFloat(l.amount) > 0)
        .map((l) => line('deduction', l.label, l.amount, l.amount)),
      line(
        'tax',
        'Federal Income Tax',
        taxes.federalIncome,
        ytd.federalTaxWithheld
      ),
      line('tax', 'State Income Tax', taxes.stateIncome, ytd.stateTaxWithheld),
      ...(parseFloat(taxes.localIncome) > 0
        ? [
            line(
              'tax',
              'Local Income Tax',
              taxes.localIncome,
              taxes.localIncome
            ),
          ]
        : []),
      line('tax', 'Social Security', taxes.socialSecurity, ytd.ssTaxWithheld),
      line('tax', 'Medicare', taxes.medicare, ytd.medicareTaxWithheld),
      line(
        'tax',
        'Medicare Additional',
        taxes.medicareAdditional,
        ytd.medicareAdditionalWithheld
      ),
      line('net', 'Net Pay', netPay, netPay),
    ];

    this.assertReconciliation(gross, netPay, taxTotal, deductionsTotal);

    return {
      id: randomUUID(),
      employeeId,
      payPeriodId,
      grossPay: gross,
      netPay,
      lines,
      isCorrection,
      correctsPayStubId: correctsPayStubId ?? null,
      createdAt: new Date().toISOString(),
    };
  }

  private assertReconciliation(
    gross: Money,
    net: Money,
    taxes: Money,
    deductions: Money
  ): void {
    const expected = sub(sub(gross, taxes), deductions);
    if (expected !== net) {
      throw PayrollDomainError.payStubReconciliation(
        gross,
        net,
        taxes,
        deductions
      );
    }
  }
}

function line(
  category: string,
  label: string,
  current: Money,
  ytd: Money
): PayStubLine {
  return { category, label, current, ytd };
}
