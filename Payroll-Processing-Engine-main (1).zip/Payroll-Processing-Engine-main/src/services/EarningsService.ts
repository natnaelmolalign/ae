import type { EarningsLine, EarningsType, Employee } from '../models/types';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { ImputedIncomeService } from './ImputedIncomeService';
import { add, isZero, sum, type Money } from '../utils/decimalUtils';

export interface ClassifiedEarnings {
  gross: Money;
  federalTaxable: Money;
  stateTaxable: Money;
  ssTaxable: Money;
  medicareTaxable: Money;
  supplementalAmount: Money;
  regularAmount: Money;
  nonTaxableReimbursement: Money;
}

export interface ClassifyOptions {
  employee?: Employee;
}

const NON_TAXABLE: EarningsType[] = ['expense_reimbursement'];
const SUPPLEMENTAL: EarningsType[] = [
  'bonus',
  'commission',
  'severance',
  'rsu_vest',
  'nqso_exercise',
];
/** Tips and tip-credit make-up are regular wages for withholding/FICA. */
const TIP_TAXABLE: EarningsType[] = [
  'cash_tips',
  'charged_tips',
  'allocated_tips',
  'tip_credit_makeup',
];

export class EarningsService {
  private imputed = new ImputedIncomeService();

  classify(
    lines: EarningsLine[],
    options: ClassifyOptions = {}
  ): ClassifiedEarnings {
    let gross = '0.00';
    let federalTaxable = '0.00';
    let stateTaxable = '0.00';
    let ssTaxable = '0.00';
    let medicareTaxable = '0.00';
    let supplementalAmount = '0.00';
    let regularAmount = '0.00';
    let nonTaxableReimbursement = '0.00';

    const stateCode = options.employee?.stateCode ?? 'DEFAULT';
    const holidayFicaExempt = this.imputed.isHolidayFicaExempt(stateCode);

    for (const line of lines) {
      gross = add(gross, line.amount);
      if (NON_TAXABLE.includes(line.type)) {
        nonTaxableReimbursement = add(nonTaxableReimbursement, line.amount);
        continue;
      }

      federalTaxable = add(federalTaxable, line.amount);
      stateTaxable = add(stateTaxable, line.amount);

      const ficaExemptHoliday = line.type === 'holiday' && holidayFicaExempt;
      if (!ficaExemptHoliday) {
        ssTaxable = add(ssTaxable, line.amount);
        medicareTaxable = add(medicareTaxable, line.amount);
      }

      if (SUPPLEMENTAL.includes(line.type)) {
        supplementalAmount = add(supplementalAmount, line.amount);
      } else if (
        TIP_TAXABLE.includes(line.type) ||
        line.type === 'regular' ||
        line.type === 'overtime' ||
        line.type === 'holiday' ||
        line.type === 'pto' ||
        line.type === 'sick'
      ) {
        regularAmount = add(regularAmount, line.amount);
      }
    }

    return {
      gross,
      federalTaxable,
      stateTaxable,
      ssTaxable,
      medicareTaxable,
      supplementalAmount,
      regularAmount,
      nonTaxableReimbursement,
    };
  }

  totalGross(lines: EarningsLine[]): Money {
    return sum(lines.map((l) => l.amount));
  }

  hasSupplementalOnly(lines: EarningsLine[]): boolean {
    const taxable = lines.filter((l) => !NON_TAXABLE.includes(l.type));
    if (taxable.length === 0) return false;
    return taxable.every((l) => SUPPLEMENTAL.includes(l.type));
  }

  hasMixedSupplemental(lines: EarningsLine[]): boolean {
    const hasSup = lines.some((l) => SUPPLEMENTAL.includes(l.type));
    const hasReg = lines.some(
      (l) => !SUPPLEMENTAL.includes(l.type) && !NON_TAXABLE.includes(l.type)
    );
    return hasSup && hasReg;
  }
}

export function assertPositiveGross(gross: Money): void {
  if (isZero(gross)) {
    throw PayrollDomainError.invalidGross();
  }
}
