import type { Knex } from 'knex';
import { compare, add, type Money } from '../../utils/decimalUtils';
import {
  filterByEmployment,
  loadCompliancePayrollRows,
  paymentYearBounds,
} from './compliancePayrollData';

const NEC_THRESHOLD = '600.00';

export interface Form1099NecRecipient {
  employeeId: string;
  recipientName: string;
  tinMasked: string | null;
  nonemployeeCompensation: Money;
  meets600Threshold: boolean;
}

export interface Form1099NecPreview {
  taxYear: number;
  threshold: Money;
  recipients: Form1099NecRecipient[];
  totals: { nonemployeeCompensation: Money };
}

export class Form1099NecExportService {
  constructor(private readonly db: Knex) {}

  async build(companyId: string, taxYear: number): Promise<Form1099NecPreview> {
    const { start, end } = paymentYearBounds(taxYear);
    const rows = filterByEmployment(
      await loadCompliancePayrollRows(this.db, companyId, start, end),
      'contractor'
    );

    const byEmployee = new Map<string, Form1099NecRecipient>();

    for (const row of rows) {
      const key = row.employee.id;
      const existing = byEmployee.get(key) ?? {
        employeeId: row.employee.id,
        recipientName: `${row.employee.firstName} ${row.employee.lastName}`,
        tinMasked: row.employee.tinLastFour
          ? `***-**-${row.employee.tinLastFour}`
          : null,
        nonemployeeCompensation: '0.00',
        meets600Threshold: false,
      };
      existing.nonemployeeCompensation = add(
        existing.nonemployeeCompensation,
        row.grossPay
      );
      existing.meets600Threshold =
        compare(existing.nonemployeeCompensation, NEC_THRESHOLD) >= 0;
      byEmployee.set(key, existing);
    }

    const recipients = [...byEmployee.values()].sort((a, b) =>
      a.recipientName.localeCompare(b.recipientName)
    );
    const total = recipients.reduce(
      (acc, r) => add(acc, r.nonemployeeCompensation),
      '0.00'
    );

    return {
      taxYear,
      threshold: NEC_THRESHOLD,
      recipients,
      totals: { nonemployeeCompensation: total },
    };
  }
}
