import type { Knex } from 'knex';
import { W2ExportService } from './W2ExportService';
import { Form1099NecExportService } from './Form1099NecExportService';
import { Form941ReconciliationService } from './Form941ReconciliationService';

export class ComplianceReportingService {
  private w2: W2ExportService;
  private nec1099: Form1099NecExportService;
  private form941: Form941ReconciliationService;

  constructor(private readonly db: Knex) {
    this.w2 = new W2ExportService(db);
    this.nec1099 = new Form1099NecExportService(db);
    this.form941 = new Form941ReconciliationService(db);
  }

  w2Preview(companyId: string, taxYear: number) {
    return this.w2.build(companyId, taxYear);
  }

  nec1099Preview(companyId: string, taxYear: number) {
    return this.nec1099.build(companyId, taxYear);
  }

  form941Reconciliation(companyId: string, taxYear: number, quarter: number) {
    return this.form941.build(companyId, taxYear, quarter);
  }
}
