import type { Knex } from 'knex';
import { add, type Money } from '../../utils/decimalUtils';
import {
  filterByEmployment,
  loadCompliancePayrollRows,
  quarterBounds,
} from './compliancePayrollData';

export interface Form941Reconciliation {
  taxYear: number;
  quarter: number;
  federalIncomeTaxWithheld: Money;
  employeeSocialSecurityTax: Money;
  employeeMedicareTax: Money;
  employerSocialSecurity: Money;
  employerMedicare: Money;
  totalLiability: Money;
  payrollRegisterGross: Money;
  reconciliationNote: string;
}

export class Form941ReconciliationService {
  constructor(private readonly db: Knex) {}

  async build(
    companyId: string,
    taxYear: number,
    quarter: number
  ): Promise<Form941Reconciliation> {
    const { start, end } = quarterBounds(taxYear, quarter);
    const rows = filterByEmployment(
      await loadCompliancePayrollRows(this.db, companyId, start, end),
      'w2'
    );

    let federalIncomeTaxWithheld = '0.00';
    let employeeSocialSecurityTax = '0.00';
    let employeeMedicareTax = '0.00';
    let employerSocialSecurity = '0.00';
    let employerMedicare = '0.00';
    let payrollRegisterGross = '0.00';

    for (const row of rows) {
      federalIncomeTaxWithheld = add(
        federalIncomeTaxWithheld,
        row.taxes.federalIncome
      );
      employeeSocialSecurityTax = add(
        employeeSocialSecurityTax,
        row.taxes.socialSecurity
      );
      employeeMedicareTax = add(
        employeeMedicareTax,
        add(row.taxes.medicare, row.taxes.medicareAdditional)
      );
      employerSocialSecurity = add(
        employerSocialSecurity,
        row.employerContributions.ss
      );
      employerMedicare = add(
        employerMedicare,
        row.employerContributions.medicare
      );
      payrollRegisterGross = add(payrollRegisterGross, row.grossPay);
    }

    const totalLiability = add(
      add(
        add(federalIncomeTaxWithheld, employeeSocialSecurityTax),
        employeeMedicareTax
      ),
      add(employerSocialSecurity, employerMedicare)
    );

    return {
      taxYear,
      quarter,
      federalIncomeTaxWithheld,
      employeeSocialSecurityTax,
      employeeMedicareTax,
      employerSocialSecurity,
      employerMedicare,
      totalLiability,
      payrollRegisterGross,
      reconciliationNote:
        '941 totals sum W-2 payroll runs in quarter (federal withheld + FICA); excludes 1099 contractors.',
    };
  }
}
