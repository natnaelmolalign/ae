import type { Knex } from 'knex';
import { add, type Money } from '../../utils/decimalUtils';
import {
  filterByEmployment,
  loadCompliancePayrollRows,
  paymentYearBounds,
  sumGross,
} from './compliancePayrollData';

export interface W2BoxTotals {
  wages: Money;
  federalIncomeTaxWithheld: Money;
  socialSecurityWages: Money;
  socialSecurityTaxWithheld: Money;
  medicareWages: Money;
  medicareTaxWithheld: Money;
}

export interface W2EmployeePreview {
  employeeId: string;
  employeeName: string;
  tinMasked: string | null;
  boxes: W2BoxTotals;
}

export interface W2PreviewReport {
  taxYear: number;
  employees: W2EmployeePreview[];
  totals: W2BoxTotals;
  reconciliation: {
    stubGrossTotal: Money;
    previewWagesTotal: Money;
    matches: boolean;
  };
}

export class W2ExportService {
  constructor(private readonly db: Knex) {}

  async build(companyId: string, taxYear: number): Promise<W2PreviewReport> {
    const { start, end } = paymentYearBounds(taxYear);
    const rows = filterByEmployment(
      await loadCompliancePayrollRows(this.db, companyId, start, end),
      'w2'
    );

    const byEmployee = new Map<string, W2EmployeePreview>();

    for (const row of rows) {
      const key = row.employee.id;
      const existing = byEmployee.get(key) ?? {
        employeeId: row.employee.id,
        employeeName: `${row.employee.firstName} ${row.employee.lastName}`,
        tinMasked: row.employee.tinLastFour
          ? `***-**-${row.employee.tinLastFour}`
          : null,
        boxes: emptyBoxes(),
      };
      existing.boxes.wages = add(existing.boxes.wages, row.grossPay);
      existing.boxes.federalIncomeTaxWithheld = add(
        existing.boxes.federalIncomeTaxWithheld,
        row.taxes.federalIncome
      );
      existing.boxes.socialSecurityTaxWithheld = add(
        existing.boxes.socialSecurityTaxWithheld,
        row.taxes.socialSecurity
      );
      existing.boxes.medicareTaxWithheld = add(
        existing.boxes.medicareTaxWithheld,
        add(row.taxes.medicare, row.taxes.medicareAdditional)
      );
      existing.boxes.socialSecurityWages = add(
        existing.boxes.socialSecurityWages,
        row.grossPay
      );
      existing.boxes.medicareWages = add(
        existing.boxes.medicareWages,
        row.grossPay
      );
      byEmployee.set(key, existing);
    }

    const employees = [...byEmployee.values()].sort((a, b) =>
      a.employeeName.localeCompare(b.employeeName)
    );
    const totals = employees.reduce(
      (acc, e) => ({
        wages: add(acc.wages, e.boxes.wages),
        federalIncomeTaxWithheld: add(
          acc.federalIncomeTaxWithheld,
          e.boxes.federalIncomeTaxWithheld
        ),
        socialSecurityWages: add(
          acc.socialSecurityWages,
          e.boxes.socialSecurityWages
        ),
        socialSecurityTaxWithheld: add(
          acc.socialSecurityTaxWithheld,
          e.boxes.socialSecurityTaxWithheld
        ),
        medicareWages: add(acc.medicareWages, e.boxes.medicareWages),
        medicareTaxWithheld: add(
          acc.medicareTaxWithheld,
          e.boxes.medicareTaxWithheld
        ),
      }),
      emptyBoxes()
    );

    const stubGrossTotal = sumGross(rows);
    return {
      taxYear,
      employees,
      totals,
      reconciliation: {
        stubGrossTotal,
        previewWagesTotal: totals.wages,
        matches: stubGrossTotal === totals.wages,
      },
    };
  }
}

function emptyBoxes(): W2BoxTotals {
  return {
    wages: '0.00',
    federalIncomeTaxWithheld: '0.00',
    socialSecurityWages: '0.00',
    socialSecurityTaxWithheld: '0.00',
    medicareWages: '0.00',
    medicareTaxWithheld: '0.00',
  };
}
