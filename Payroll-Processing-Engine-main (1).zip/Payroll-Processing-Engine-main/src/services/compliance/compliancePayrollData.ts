import type { Knex } from 'knex';
import type { Employee, EmploymentType } from '../../models/types';
import { add, type Money } from '../../utils/decimalUtils';
import { isContractor1099 } from '../../utils/employmentClassification';
import {
  employeeFromRow,
  type EmployeeRow,
} from '../../repositories/knex/mappers';

export interface PayrollTaxSnapshot {
  federalIncome: Money;
  stateIncome: Money;
  socialSecurity: Money;
  medicare: Money;
  medicareAdditional: Money;
}

export interface EmployerContributionSnapshot {
  ss: Money;
  medicare: Money;
  match401k: Money;
}

export interface CompliancePayrollRow {
  employee: Employee;
  payStubId: string;
  payPeriodId: string;
  paymentDate: string;
  grossPay: Money;
  taxes: PayrollTaxSnapshot;
  employerContributions: EmployerContributionSnapshot;
}

export function paymentYearBounds(taxYear: number): {
  start: string;
  end: string;
} {
  return {
    start: `${taxYear}-01-01`,
    end: `${taxYear}-12-31`,
  };
}

export function quarterBounds(
  taxYear: number,
  quarter: number
): { start: string; end: string } {
  const starts = ['01-01', '04-01', '07-01', '10-01'];
  const ends = ['03-31', '06-30', '09-30', '12-31'];
  const idx = quarter - 1;
  return {
    start: `${taxYear}-${starts[idx]}`,
    end: `${taxYear}-${ends[idx]}`,
  };
}

export async function loadCompliancePayrollRows(
  db: Knex,
  companyId: string,
  startDate: string,
  endDate: string
): Promise<CompliancePayrollRow[]> {
  const rows = await db('pay_stubs as ps')
    .join('employees as e', 'ps.employee_id', 'e.id')
    .join('pay_periods as pp', 'ps.pay_period_id', 'pp.id')
    .join('payroll_runs as pr', 'pr.pay_stub_id', 'ps.id')
    .where('e.company_id', companyId)
    .whereBetween('pp.payment_date', [startDate, endDate])
    .select(
      'ps.id as pay_stub_id',
      'ps.employee_id',
      'ps.pay_period_id',
      'ps.gross_pay',
      'pp.payment_date',
      'pr.taxes',
      'pr.employer_contributions',
      'e.*'
    );

  return rows.map((row) => {
    const taxes =
      typeof row.taxes === 'string' ? JSON.parse(row.taxes) : row.taxes;
    const employer =
      typeof row.employer_contributions === 'string'
        ? JSON.parse(row.employer_contributions)
        : row.employer_contributions;
    const employee = employeeFromRow(row as EmployeeRow);
    return {
      employee,
      payStubId: String(row.pay_stub_id),
      payPeriodId: String(row.pay_period_id),
      paymentDate: String(row.payment_date).slice(0, 10),
      grossPay: String(row.gross_pay),
      taxes: {
        federalIncome: String(taxes.federalIncome ?? '0.00'),
        stateIncome: String(taxes.stateIncome ?? '0.00'),
        socialSecurity: String(taxes.socialSecurity ?? '0.00'),
        medicare: String(taxes.medicare ?? '0.00'),
        medicareAdditional: String(taxes.medicareAdditional ?? '0.00'),
      },
      employerContributions: {
        ss: String(employer.ss ?? '0.00'),
        medicare: String(employer.medicare ?? '0.00'),
        match401k: String(employer.match401k ?? '0.00'),
      },
    };
  });
}

export function filterByEmployment(
  rows: CompliancePayrollRow[],
  type: 'w2' | 'contractor'
): CompliancePayrollRow[] {
  return rows.filter((r) => {
    const isContractor = isContractor1099(r.employee);
    return type === 'contractor' ? isContractor : !isContractor;
  });
}

export function sumGross(rows: CompliancePayrollRow[]): Money {
  return rows.reduce((acc, r) => add(acc, r.grossPay), '0.00');
}

export function isW2Employment(type: EmploymentType): boolean {
  return type !== 'contractor';
}
