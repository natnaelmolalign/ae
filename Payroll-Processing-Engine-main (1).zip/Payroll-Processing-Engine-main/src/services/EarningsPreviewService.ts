import type {
  EarningsLine,
  EarningsPreviewInput,
  Employee,
  PayPeriod,
  PayrollRunInput,
  PayrollRunResult,
} from '../models/types';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { features } from '../config/features';
import { PayrollErrorCode } from '../errors/PayrollDomainError';
import { HourlyEarningsBuilder } from './HourlyEarningsBuilder';
import { ImputedIncomeService } from './ImputedIncomeService';
import { PayrollRunService } from './PayrollRunService';
import { TimeEntryService } from './TimeEntryService';
import type { TimeApprovalService } from './workforce/TimeApprovalService';
import { calculateMealPenalty } from './workforce/MealPenaltyCalculator';

export class EarningsPreviewService {
  constructor(
    private readonly payrollRunService: PayrollRunService,
    private readonly timeEntryService: TimeEntryService,
    private readonly timeApprovalService?: TimeApprovalService,
    private readonly hourlyBuilder = new HourlyEarningsBuilder(),
    private readonly imputed = new ImputedIncomeService()
  ) {}

  async preview(
    employee: Employee,
    payPeriod: PayPeriod,
    input: EarningsPreviewInput
  ): Promise<PayrollRunResult & { earningsLines: EarningsLine[] }> {
    const earningsLines = await this.resolveEarningsLines(
      employee,
      payPeriod,
      input
    );

    const payrollInput: PayrollRunInput = {
      employeeId: input.employeeId,
      payPeriodId: input.payPeriodId,
      earnings: earningsLines,
      deductions: input.deductions ?? [],
      garnishments: input.garnishments ?? [],
    };

    const result = await this.payrollRunService.preview(
      employee,
      payPeriod,
      payrollInput
    );

    return { ...result, earningsLines };
  }

  async resolveEarningsLines(
    employee: Employee,
    payPeriod: PayPeriod,
    input: EarningsPreviewInput
  ): Promise<EarningsLine[]> {
    let lines: EarningsLine[] = [];

    if (input.useTimeEntries) {
      if (!features.hourlyEarningsEnabled) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'Hourly earnings feature is disabled'
        );
      }
      if (!input.hourlyRate) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'hourlyRate is required when useTimeEntries is true'
        );
      }
      if (this.timeApprovalService) {
        await this.timeApprovalService.assertPayrollReady(
          employee.id,
          employee.companyId,
          payPeriod
        );
      }
      let entries = await this.timeEntryService.listForPayPeriod(
        employee.id,
        payPeriod
      );
      if (this.timeApprovalService) {
        entries = await this.timeApprovalService.filterPayrollEntries(
          employee.id,
          employee.companyId,
          payPeriod,
          entries
        );
      }
      lines = this.hourlyBuilder.buildFromTimeEntries(
        employee,
        entries,
        input.hourlyRate
      );
      if (features.caMealPenaltyEnabled && this.timeApprovalService) {
        lines.push(
          ...(await this.mealPenaltyLines(
            employee,
            payPeriod,
            input.hourlyRate
          ))
        );
      }
    } else if (input.earnings?.length) {
      lines = [...input.earnings];
    } else {
      throw PayrollDomainError.invalidGross();
    }

    if (input.imputedIncome?.length) {
      const imputedLines = this.imputed.toEarningsLines(input.imputedIncome);
      for (const il of imputedLines) {
        if (parseFloat(il.amount) > 0) {
          lines.push(il);
        }
      }
    }

    return lines;
  }

  private async mealPenaltyLines(
    employee: import('../models/types').Employee,
    payPeriod: PayPeriod,
    hourlyRate: string
  ): Promise<EarningsLine[]> {
    if (!this.timeApprovalService) return [];
    const pairs = await this.timeApprovalService.listApprovedWithShifts(
      employee.id,
      employee.companyId,
      payPeriod
    );
    const lines: EarningsLine[] = [];
    for (const { assignment, shift } of pairs) {
      const penalty = calculateMealPenalty({
        stateCode: employee.stateCode,
        shiftMinutes: assignment.scheduledMinutes,
        breakMinutes: shift.breakMinutes,
        hourlyRate,
      });
      if (penalty) {
        lines.push({
          type: 'regular',
          amount: penalty.premiumAmount,
          hours: penalty.premiumHours,
        });
      }
    }
    return lines;
  }
}
