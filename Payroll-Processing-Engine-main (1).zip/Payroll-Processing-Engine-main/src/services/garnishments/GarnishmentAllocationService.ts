import {
  compareGarnishmentPriority,
  GARNISHMENT_MAX_PERCENT,
} from '../../data/garnishment/priorityRules';
import type { GarnishmentOrderType } from '../../models/GarnishmentOrder';
import { applyGarnishmentCap } from '../../utils/garnishmentUtils';
import {
  add,
  compare,
  minMoney,
  mul,
  sub,
  type Money,
} from '../../utils/decimalUtils';

export interface GarnishmentAllocationInput {
  orderId?: string;
  caseId?: string;
  type: GarnishmentOrderType;
  priority: number;
  fixedAmount: Money;
  percentOfDisposable: string | null;
}

export interface GarnishmentAllocationLine {
  orderId: string | null;
  caseId: string | null;
  type: GarnishmentOrderType;
  requested: Money;
  amount: Money;
}

export interface GarnishmentAllocationResult {
  disposableEarnings: Money;
  total: Money;
  lines: GarnishmentAllocationLine[];
  remainingDisposable: Money;
}

/**
 * Waterfill: satisfy higher-priority orders first, reducing remaining disposable.
 */
export class GarnishmentAllocationService {
  allocate(
    orders: GarnishmentAllocationInput[],
    disposableEarnings: Money
  ): GarnishmentAllocationResult {
    const sorted = [...orders].sort(compareGarnishmentPriority);
    const lines: GarnishmentAllocationLine[] = [];
    let total = '0.00';
    let remaining = disposableEarnings;

    for (const order of sorted) {
      if (compare(remaining, '0.00') <= 0) {
        lines.push({
          orderId: order.orderId ?? null,
          caseId: order.caseId ?? null,
          type: order.type,
          requested: order.fixedAmount,
          amount: '0.00',
        });
        continue;
      }

      let requested = order.fixedAmount;
      if (order.percentOfDisposable) {
        requested = mul(remaining, order.percentOfDisposable);
      }

      const maxPct = GARNISHMENT_MAX_PERCENT[order.type];
      const cappedByPct = applyGarnishmentCap(requested, remaining, maxPct);
      const amount = minMoney(cappedByPct, remaining);

      lines.push({
        orderId: order.orderId ?? null,
        caseId: order.caseId ?? null,
        type: order.type,
        requested,
        amount,
      });
      total = add(total, amount);
      remaining = sub(remaining, amount);
    }

    return {
      disposableEarnings,
      total,
      lines,
      remainingDisposable: remaining,
    };
  }
}
