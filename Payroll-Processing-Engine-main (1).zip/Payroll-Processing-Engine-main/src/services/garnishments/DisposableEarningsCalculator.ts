import type { TaxWithholdingResult } from '../../models/types';
import { sub, sum, type Money } from '../../utils/decimalUtils';

export interface MandatoryDeductions {
  section125: Money;
}

export interface DisposableEarningsInput {
  gross: Money;
  taxes: TaxWithholdingResult;
  mandatoryDeductions: MandatoryDeductions;
}

/**
 * CCPA disposable earnings: gross minus legally required withholdings.
 * Includes income/FICA taxes and mandatory Section 125 (health) reductions.
 */
export class DisposableEarningsCalculator {
  calculate(input: DisposableEarningsInput): Money {
    const taxTotal = sum([
      input.taxes.federalIncome,
      input.taxes.stateIncome,
      input.taxes.localIncome,
      input.taxes.socialSecurity,
      input.taxes.medicare,
      input.taxes.medicareAdditional,
    ]);
    const mandatory = input.mandatoryDeductions.section125;
    return sub(sub(input.gross, taxTotal), mandatory);
  }
}
