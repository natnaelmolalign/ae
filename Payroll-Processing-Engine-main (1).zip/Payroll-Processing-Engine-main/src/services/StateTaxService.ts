import type { Employee } from '../models/types';
import type { StateAllocationInput } from '../models/WorkLocationAllocation';
import type { Money } from '../utils/decimalUtils';
import { taxYearFromPaymentDate } from '../config/taxYear';
import { features } from '../config/features';
import { StateWithholdingEngine } from './tax/state/StateWithholdingEngine';
import { MultiStateAllocationService } from './tax/MultiStateAllocationService';
import { TaxYearService, defaultTaxYearService } from './tax/TaxYearService';

export class StateTaxService {
  private readonly multiState = new MultiStateAllocationService();

  constructor(
    private readonly taxYearService: TaxYearService = defaultTaxYearService
  ) {}

  calculate(
    employee: Employee,
    stateTaxableWages: Money,
    paymentDate: string,
    stateAllocations?: StateAllocationInput[]
  ): Money {
    const taxYear = taxYearFromPaymentDate(paymentDate);
    const tables = this.taxYearService.getYearTables(taxYear);

    if (
      features.multiStateTaxEnabled &&
      stateAllocations &&
      stateAllocations.length > 0
    ) {
      return this.multiState.calculateTotalStateTax(
        tables,
        employee,
        stateTaxableWages,
        stateAllocations
      ).total;
    }

    return StateWithholdingEngine.calculate(
      tables,
      employee,
      stateTaxableWages
    );
  }

  calculateWithSlices(
    employee: Employee,
    stateTaxableWages: Money,
    paymentDate: string,
    stateAllocations: StateAllocationInput[]
  ) {
    const taxYear = taxYearFromPaymentDate(paymentDate);
    const tables = this.taxYearService.getYearTables(taxYear);
    return this.multiState.calculateTotalStateTax(
      tables,
      employee,
      stateTaxableWages,
      stateAllocations
    );
  }
}
