import type {
  CreateGarnishmentOrderInput,
  GarnishmentOrder,
  UpdateGarnishmentOrderInput,
} from '../models/GarnishmentOrder';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import type { GarnishmentOrderRepository } from '../repositories/interfaces';

export class GarnishmentOrderService {
  constructor(private readonly repo: GarnishmentOrderRepository) {}

  async create(input: CreateGarnishmentOrderInput): Promise<GarnishmentOrder> {
    return this.repo.create(input);
  }

  async get(id: string): Promise<GarnishmentOrder | null> {
    return this.repo.findById(id);
  }

  async listByEmployee(employeeId: string): Promise<GarnishmentOrder[]> {
    return this.repo.findByEmployee(employeeId);
  }

  async listActive(
    employeeId: string,
    asOfDate: string
  ): Promise<GarnishmentOrder[]> {
    return this.repo.findActiveForEmployee(employeeId, asOfDate);
  }

  async update(
    id: string,
    input: UpdateGarnishmentOrderInput
  ): Promise<GarnishmentOrder> {
    const updated = await this.repo.update(id, input);
    if (!updated) {
      throw PayrollDomainError.notFound('GarnishmentOrder', id);
    }
    return updated;
  }

  async remove(id: string): Promise<void> {
    const ok = await this.repo.delete(id);
    if (!ok) {
      throw PayrollDomainError.notFound('GarnishmentOrder', id);
    }
  }
}
