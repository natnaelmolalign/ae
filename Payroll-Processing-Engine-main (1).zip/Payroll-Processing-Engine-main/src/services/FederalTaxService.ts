import type { Employee, EarningsLine } from '../models/types';
import { w4ParamsFromEmployee } from '../models/W4Params';
import type { Money } from '../utils/decimalUtils';
import { EarningsService } from './EarningsService';
import { FederalWithholdingEngine } from './tax/federal/FederalWithholdingEngine';
import { TaxYearService, defaultTaxYearService } from './tax/TaxYearService';
import { taxYearFromPaymentDate } from '../config/taxYear';

export interface FederalTaxCalculateOptions {
  paymentDate: string;
  regularFederalTaxable: Money;
  supplementalFederalTaxable: Money;
}

export class FederalTaxService {
  constructor(
    private readonly taxYearService: TaxYearService = defaultTaxYearService,
    private readonly earningsService = new EarningsService()
  ) {}

  calculate(
    employee: Employee,
    federalTaxableWages: Money,
    earnings: EarningsLine[],
    supplementalOnly: boolean,
    mixedSupplemental: boolean,
    options: FederalTaxCalculateOptions
  ): Money {
    const taxYear = taxYearFromPaymentDate(options.paymentDate);
    const tables = this.taxYearService.getYearTables(taxYear);

    return FederalWithholdingEngine.calculate(
      tables.federal,
      w4ParamsFromEmployee(employee),
      employee.payFrequency,
      federalTaxableWages,
      options.regularFederalTaxable,
      options.supplementalFederalTaxable,
      supplementalOnly,
      mixedSupplemental
    );
  }
}
