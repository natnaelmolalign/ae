import Decimal from 'decimal.js';
import type { PayrollHold } from '../../models/PayrollControl';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type {
  PayStubRepository,
  PayrollControlRepository,
} from '../../repositories/interfaces';
import type { AuditService } from '../AuditService';
import { toAuditSnapshot } from '../../utils/auditContext';
import { features } from '../../config/features';

export class ControlService {
  private readonly anomalyDetector = new AnomalyDetector();

  constructor(
    private readonly repo: PayrollControlRepository,
    private readonly payStubRepo: PayStubRepository,
    private readonly auditService: AuditService
  ) {}

  async evaluateEmployeeHold(
    employeeId: string,
    companyId: string
  ): Promise<PayrollHold | null> {
    return this.repo.findActiveHoldForEmployee(employeeId, companyId);
  }

  async createHold(
    input: Parameters<PayrollControlRepository['createHold']>[0]
  ) {
    return this.repo.createHold(input);
  }

  async releaseHold(
    id: string,
    companyId: string,
    actor: string,
    releaseReason: string
  ) {
    const before = await this.repo.findHoldById(id, companyId);
    const hold = await this.repo.releaseHold(
      id,
      companyId,
      actor,
      releaseReason
    );
    if (hold && before) {
      await this.auditService.recordUpdate(
        actor,
        'payroll_hold',
        id,
        toAuditSnapshot({
          status: before.status,
          reasonCode: before.reasonCode,
        }),
        toAuditSnapshot({
          status: hold.status,
          releaseReason: hold.releaseReason,
        })
      );
    }
    return hold;
  }

  listActiveHolds(companyId: string) {
    return this.repo.listActiveHolds(companyId);
  }

  async assertRunAllowed(input: {
    employeeId: string;
    companyId: string;
    payPeriodId: string;
    grossAmount: string;
    actor: string;
  }): Promise<void> {
    if (!features.payrollControlsEnabled) return;

    const hold = await this.evaluateEmployeeHold(
      input.employeeId,
      input.companyId
    );
    if (hold) {
      throw new PayrollDomainError(
        PayrollErrorCode.PAYROLL_HOLD_ACTIVE,
        `Payroll hold active: ${hold.reasonCode}`
      );
    }

    const pending = await this.repo.findPendingApprovalForEmployeePeriod(
      input.employeeId,
      input.payPeriodId,
      input.companyId
    );
    if (pending) {
      throw new PayrollDomainError(
        PayrollErrorCode.ANOMALY_APPROVAL_REQUIRED,
        'Pending anomaly approval required before payroll run'
      );
    }

    const alreadyApproved =
      await this.repo.findApprovedApprovalForEmployeePeriod(
        input.employeeId,
        input.payPeriodId,
        input.companyId
      );
    if (alreadyApproved) return;

    const stubs = await this.payStubRepo.listByEmployee(input.employeeId);
    const history = stubs
      .slice(0, 8)
      .map((s) => s.grossPay)
      .filter((g) => g !== input.grossAmount);

    const evaluation = this.anomalyDetector.evaluate({
      amount: input.grossAmount,
      history,
    });

    if (!evaluation.flagged) return;

    await this.repo.saveAnomalyFlag({
      companyId: input.companyId,
      employeeId: input.employeeId,
      payPeriodId: input.payPeriodId,
      metric: 'gross_pay',
      amount: input.grossAmount,
      trailingAverage: evaluation.trailingAverage,
      zScore: evaluation.zScore,
      threshold: evaluation.threshold,
    });

    await this.repo.createApprovalRequest({
      companyId: input.companyId,
      employeeId: input.employeeId,
      payPeriodId: input.payPeriodId,
      payrollRunId: null,
      requestedAmount: input.grossAmount,
      zScore: evaluation.zScore,
      threshold: evaluation.threshold,
      requestedBy: input.actor,
    });

    throw new PayrollDomainError(
      PayrollErrorCode.ANOMALY_APPROVAL_REQUIRED,
      `Gross pay anomaly detected (z=${evaluation.zScore})`
    );
  }
}

export interface AnomalyThresholds {
  zScoreThreshold: number;
}

const DEFAULT_THRESHOLDS: AnomalyThresholds = {
  zScoreThreshold: Number(process.env.ANOMALY_Z_SCORE_THRESHOLD ?? 3),
};

export interface AnomalyEvaluationInput {
  amount: string;
  history: string[];
  thresholds?: AnomalyThresholds;
}

export interface AnomalyEvaluationResult {
  flagged: boolean;
  zScore: string;
  trailingAverage: string;
  threshold: string;
}

export class AnomalyDetector {
  evaluate(input: AnomalyEvaluationInput): AnomalyEvaluationResult {
    const threshold =
      input.thresholds?.zScoreThreshold ?? DEFAULT_THRESHOLDS.zScoreThreshold;
    const history = input.history.map((h) => new Decimal(h));
    if (history.length === 0) {
      return {
        flagged: false,
        zScore: '0',
        trailingAverage: input.amount,
        threshold: String(threshold),
      };
    }

    const mean = history
      .reduce((acc, v) => acc.plus(v), new Decimal(0))
      .div(history.length);
    const variance = history
      .reduce((acc, v) => acc.plus(v.minus(mean).pow(2)), new Decimal(0))
      .div(history.length);
    const stdDev = variance.sqrt();
    const amount = new Decimal(input.amount);

    if (stdDev.isZero()) {
      const flagged = amount.minus(mean).abs().gt(new Decimal(threshold));
      return {
        flagged,
        zScore: flagged ? String(threshold) : '0',
        trailingAverage: mean.toFixed(2),
        threshold: String(threshold),
      };
    }

    const z = amount.minus(mean).div(stdDev).abs();
    return {
      flagged: z.gte(threshold),
      zScore: z.toFixed(4),
      trailingAverage: mean.toFixed(2),
      threshold: String(threshold),
    };
  }
}
