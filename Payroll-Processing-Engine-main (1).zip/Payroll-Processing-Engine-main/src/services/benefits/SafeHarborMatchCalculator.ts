import {
  add,
  compare,
  minMoney,
  mul,
  sub,
  type Money,
} from '../../utils/decimalUtils';

/**
 * Basic safe harbor match (IRC §401(m)): 100% of deferrals up to 3% of compensation
 * plus 50% of deferrals from 3% to 5% of compensation.
 */
export class SafeHarborMatchCalculator {
  calculateBasicMatch(compensation: Money, employeeDeferral: Money): Money {
    if (compare(employeeDeferral, '0.00') <= 0) return '0.00';

    const threePctComp = mul(compensation, '0.03');
    const fivePctComp = mul(compensation, '0.05');

    const tier1Deferral = minMoney(employeeDeferral, threePctComp);
    const tier1Match = tier1Deferral;

    const deferralUpToFive = minMoney(employeeDeferral, fivePctComp);
    const tier2Deferral = sub(deferralUpToFive, threePctComp);
    const tier2Match =
      compare(tier2Deferral, '0.00') > 0 ? mul(tier2Deferral, '0.50') : '0.00';

    return add(tier1Match, tier2Match);
  }
}
