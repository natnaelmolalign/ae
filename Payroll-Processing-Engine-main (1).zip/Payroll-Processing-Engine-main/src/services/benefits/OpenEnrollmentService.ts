import type {
  ApproveLifeEventInput,
  CreateEligibilityRuleInput,
  CreateEnrollmentWindowInput,
  CreateLifeEventInput,
  EnrollmentWindow,
  LifeEvent,
} from '../../models/BenefitsLifecycle';
import type {
  CreateBenefitEnrollmentInput,
  BenefitEnrollment,
} from '../../models/BenefitEnrollment';
import type { Employee } from '../../models/types';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type {
  EligibilityRuleRepository,
  EnrollmentWindowRepository,
  LifeEventRepository,
} from '../../repositories/interfaces';
import type { BenefitEnrollmentService } from '../BenefitEnrollmentService';
import type { DeductionScheduleService } from '../DeductionScheduleService';
import { prorateHsaAnnualLimit } from './HsaLimitProration';

export interface ElectBenefitInput extends CreateBenefitEnrollmentInput {
  companyId: string;
}

export class OpenEnrollmentService {
  constructor(
    private readonly windowRepo: EnrollmentWindowRepository,
    private readonly ruleRepo: EligibilityRuleRepository,
    private readonly lifeEventRepo: LifeEventRepository,
    private readonly enrollmentService: BenefitEnrollmentService,
    private readonly scheduleService?: DeductionScheduleService
  ) {}

  createWindow(input: CreateEnrollmentWindowInput): Promise<EnrollmentWindow> {
    return this.windowRepo.create(input);
  }

  listWindows(companyId: string): Promise<EnrollmentWindow[]> {
    return this.windowRepo.listByCompany(companyId);
  }

  async closeWindow(id: string, companyId: string): Promise<EnrollmentWindow> {
    const updated = await this.windowRepo.updateStatus(id, companyId, 'closed');
    if (!updated) {
      throw PayrollDomainError.notFound('EnrollmentWindow', id);
    }
    return updated;
  }

  createEligibilityRule(input: CreateEligibilityRuleInput) {
    return this.ruleRepo.create(input);
  }

  listEligibilityRules(companyId: string) {
    return this.ruleRepo.listByCompany(companyId);
  }

  recordLifeEvent(input: CreateLifeEventInput): Promise<LifeEvent> {
    this.assertForwardEffectiveDate(
      input.coverageEffectiveDate,
      input.eventDate
    );
    return this.lifeEventRepo.create(input);
  }

  listLifeEvents(employeeId: string, companyId: string): Promise<LifeEvent[]> {
    return this.lifeEventRepo.listByEmployee(employeeId, companyId);
  }

  async approveLifeEvent(
    id: string,
    companyId: string,
    input: ApproveLifeEventInput
  ): Promise<LifeEvent> {
    const event = await this.lifeEventRepo.findById(id, companyId);
    if (!event) {
      throw PayrollDomainError.notFound('LifeEvent', id);
    }
    if (event.status !== 'pending') {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        `Life event is already ${event.status}`
      );
    }

    let cobraScheduleId: string | null = null;
    if (event.eventType === 'loss_of_coverage') {
      if (!this.scheduleService) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'COBRA schedules require deduction schedule service'
        );
      }
      if (!input.cobraPremiumPerPeriod || !input.cobraStartDate) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'loss_of_coverage approval requires cobraPremiumPerPeriod and cobraStartDate'
        );
      }
      const schedule = await this.scheduleService.create(
        {
          employeeId: event.employeeId,
          scheduleType: 'cobra_premium',
          amountPerPeriod: input.cobraPremiumPerPeriod,
          startDate: input.cobraStartDate,
          priority: 50,
        },
        companyId
      );
      cobraScheduleId = schedule.id;
    }

    const updated = await this.lifeEventRepo.updateStatus(
      id,
      companyId,
      'approved',
      {
        approvedAt: new Date().toISOString(),
        approvedBy: input.approvedBy,
        cobraScheduleId,
      }
    );
    if (!updated) {
      throw PayrollDomainError.notFound('LifeEvent', id);
    }
    return updated;
  }

  async rejectLifeEvent(
    id: string,
    companyId: string,
    approvedBy: string
  ): Promise<LifeEvent> {
    const updated = await this.lifeEventRepo.updateStatus(
      id,
      companyId,
      'rejected',
      {
        approvedAt: new Date().toISOString(),
        approvedBy,
      }
    );
    if (!updated) {
      throw PayrollDomainError.notFound('LifeEvent', id);
    }
    return updated;
  }

  async electBenefit(
    employee: Employee,
    input: ElectBenefitInput
  ): Promise<BenefitEnrollment> {
    const prepared = await this.prepareEnrollment(employee, input);
    return this.enrollmentService.create(prepared);
  }

  async prepareEnrollment(
    employee: Employee,
    input: ElectBenefitInput
  ): Promise<CreateBenefitEnrollmentInput> {
    const today = new Date().toISOString().slice(0, 10);
    if (input.effectiveDate < today) {
      throw new PayrollDomainError(
        PayrollErrorCode.RETROACTIVE_PRETAX_NOT_ALLOWED,
        'Pre-tax benefit effective date cannot be in the past',
        { effectiveDate: input.effectiveDate }
      );
    }

    const rule = await this.ruleRepo.findActiveForType(
      input.companyId,
      input.type
    );
    if (rule) {
      this.assertEmploymentEligible(employee, rule);
      if (rule.minTenureDays != null) {
        const tenure = this.tenureDays(employee.hireDate, input.effectiveDate);
        if (tenure < rule.minTenureDays) {
          throw new PayrollDomainError(
            PayrollErrorCode.INELIGIBLE_FOR_BENEFIT,
            `Minimum tenure ${rule.minTenureDays} days required`,
            { tenureDays: tenure }
          );
        }
      }
    }

    let lifeEvent: LifeEvent | null = null;
    let enrollmentWindowId: string | null = input.enrollmentWindowId ?? null;

    if (input.lifeEventId) {
      lifeEvent = await this.lifeEventRepo.findById(
        input.lifeEventId,
        input.companyId
      );
      if (!lifeEvent || lifeEvent.employeeId !== employee.id) {
        throw PayrollDomainError.notFound('LifeEvent', input.lifeEventId);
      }
      if (lifeEvent.status !== 'approved') {
        throw new PayrollDomainError(
          PayrollErrorCode.LIFE_EVENT_NOT_APPROVED,
          'Life event must be approved before enrollment',
          { lifeEventId: input.lifeEventId, status: lifeEvent.status }
        );
      }
      if (input.effectiveDate !== lifeEvent.coverageEffectiveDate) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'effectiveDate must match approved life event coverageEffectiveDate',
          {
            effectiveDate: input.effectiveDate,
            coverageEffectiveDate: lifeEvent.coverageEffectiveDate,
          }
        );
      }
    } else if (rule?.requiresEnrollmentWindow !== false) {
      const window = await this.windowRepo.findOpenForDate(
        input.companyId,
        today,
        input.type
      );
      if (!window) {
        throw new PayrollDomainError(
          PayrollErrorCode.ENROLLMENT_WINDOW_CLOSED,
          'No open enrollment window for this benefit type; document a qualifying life event',
          { benefitType: input.type }
        );
      }
      enrollmentWindowId = window.id;
    }

    let annualLimit = input.annualLimit ?? null;
    if (input.type === 'hsa' && input.hsaCoverage && lifeEvent) {
      const taxYear = parseInt(input.effectiveDate.slice(0, 4), 10);
      const month = parseInt(input.effectiveDate.slice(5, 7), 10);
      if (month > 1) {
        annualLimit = prorateHsaAnnualLimit(
          taxYear,
          input.hsaCoverage,
          input.effectiveDate
        );
      }
    }

    return {
      ...input,
      annualLimit,
      lifeEventId: lifeEvent?.id ?? null,
      enrollmentWindowId,
    };
  }

  private assertEmploymentEligible(
    employee: Employee,
    rule: {
      employmentTypes: import('../../models/types').EmploymentType[] | null;
    }
  ): void {
    if (!rule.employmentTypes?.length) return;
    if (!rule.employmentTypes.includes(employee.employmentType)) {
      throw new PayrollDomainError(
        PayrollErrorCode.INELIGIBLE_FOR_BENEFIT,
        `Employment type ${employee.employmentType} is not eligible`,
        { employmentType: employee.employmentType }
      );
    }
  }

  private assertForwardEffectiveDate(
    coverageEffectiveDate: string,
    eventDate: string
  ): void {
    if (coverageEffectiveDate < eventDate) {
      throw new PayrollDomainError(
        PayrollErrorCode.RETROACTIVE_PRETAX_NOT_ALLOWED,
        'Coverage effective date cannot precede life event date'
      );
    }
  }

  private tenureDays(hireDate: string, asOf: string): number {
    const hire = new Date(hireDate);
    const as = new Date(asOf);
    return Math.floor((as.getTime() - hire.getTime()) / 86_400_000);
  }
}
