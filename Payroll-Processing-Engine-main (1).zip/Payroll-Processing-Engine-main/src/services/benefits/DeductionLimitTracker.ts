import { getDeductionLimits } from '../../data/2024/deductionLimits';
import type { DeductionType, YearToDate } from '../../models/types';
import type { HsaCoverage } from '../../models/BenefitEnrollment';
import {
  add,
  compare,
  minMoney,
  sub,
  type Money,
} from '../../utils/decimalUtils';

export interface LimitCapResult {
  allowed: Money;
  requested: Money;
  annualLimit: Money;
  ytdBefore: Money;
  remaining: Money;
}

export class DeductionLimitTracker {
  /** §402(g) ceiling including catch-up when eligible */
  deferral402gLimit(taxYear: number, catchUpEligible: boolean): Money {
    const limits = getDeductionLimits(taxYear);
    if (!catchUpEligible) return limits.deferral402g;
    return add(limits.deferral402g, limits.catchUp402g);
  }

  electiveDeferralYtd(ytd: YearToDate): Money {
    return add(ytd.pretax401k, ytd.roth401k);
  }

  capElectiveDeferral(
    requested: Money,
    ytd: YearToDate,
    taxYear: number,
    catchUpEligible: boolean
  ): LimitCapResult {
    const annualLimit = this.deferral402gLimit(taxYear, catchUpEligible);
    const ytdBefore = this.electiveDeferralYtd(ytd);
    return this.capAgainstAnnual(requested, ytdBefore, annualLimit);
  }

  capHsa(
    requested: Money,
    ytdHsa: Money,
    taxYear: number,
    coverage: HsaCoverage
  ): LimitCapResult {
    const limits = getDeductionLimits(taxYear);
    const annualLimit =
      coverage === 'family' ? limits.hsaFamily : limits.hsaIndividual;
    return this.capAgainstAnnual(requested, ytdHsa, annualLimit);
  }

  capFsa(requested: Money, ytdFsa: Money, taxYear: number): LimitCapResult {
    const limits = getDeductionLimits(taxYear);
    return this.capAgainstAnnual(requested, ytdFsa, limits.fsaHealth);
  }

  capEnrollmentAnnualLimit(
    requested: Money,
    ytdAmount: Money,
    enrollmentAnnualLimit: Money | null | undefined
  ): LimitCapResult {
    if (!enrollmentAnnualLimit) {
      return {
        allowed: requested,
        requested,
        annualLimit: requested,
        ytdBefore: ytdAmount,
        remaining: requested,
      };
    }
    return this.capAgainstAnnual(requested, ytdAmount, enrollmentAnnualLimit);
  }

  capAgainstAnnual(
    requested: Money,
    ytdBefore: Money,
    annualLimit: Money
  ): LimitCapResult {
    const remaining = sub(annualLimit, ytdBefore);
    if (compare(remaining, '0.00') <= 0) {
      return {
        allowed: '0.00',
        requested,
        annualLimit,
        ytdBefore,
        remaining: '0.00',
      };
    }
    const withCurrent = add(ytdBefore, requested);
    const allowed =
      compare(withCurrent, annualLimit) <= 0
        ? requested
        : minMoney(requested, remaining);
    return {
      allowed,
      requested,
      annualLimit,
      ytdBefore,
      remaining,
    };
  }

  ytdFieldForType(type: DeductionType): keyof YearToDate | null {
    switch (type) {
      case '401k_pretax':
        return 'pretax401k';
      case '401k_roth':
        return 'roth401k';
      case 'hsa':
        return 'hsa';
      case 'fsa':
        return 'fsa';
      default:
        return null;
    }
  }
}
