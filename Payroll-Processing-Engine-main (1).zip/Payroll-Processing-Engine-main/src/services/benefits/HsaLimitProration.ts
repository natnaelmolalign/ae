import { getDeductionLimits } from '../../data/2024/deductionLimits';
import type { HsaCoverage } from '../../models/BenefitEnrollment';
import { mul, type Money } from '../../utils/decimalUtils';

/** Prorate IRS HSA annual limit by months eligible in the calendar year. */
export function prorateHsaAnnualLimit(
  taxYear: number,
  coverage: HsaCoverage,
  coverageEffectiveDate: string
): Money {
  const limits = getDeductionLimits(taxYear);
  const full = coverage === 'family' ? limits.hsaFamily : limits.hsaIndividual;
  const month = parseInt(coverageEffectiveDate.slice(5, 7), 10);
  const monthsEligible = Math.max(1, Math.min(12, 12 - month + 1));
  return mul(full, String(monthsEligible / 12));
}
