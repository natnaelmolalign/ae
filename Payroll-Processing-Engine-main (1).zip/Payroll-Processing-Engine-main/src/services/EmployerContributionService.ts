import {
  MEDICARE_RATE,
  SOCIAL_SECURITY_RATE,
} from '../data/socialSecurityWageBase';
import { defaultTaxYearService } from './tax/TaxYearService';
import type { YearToDate } from '../models/types';
import { compare, minMoney, mul, sub, type Money } from '../utils/decimalUtils';
import { SafeHarborMatchCalculator } from './benefits/SafeHarborMatchCalculator';

export interface EmployerMatchOptions {
  matchPercent: number;
  safeHarborMatch: boolean;
  compensation: Money;
  employeeDeferral: Money;
}

export class EmployerContributionService {
  private safeHarbor = new SafeHarborMatchCalculator();

  constructor(private readonly taxYearService = defaultTaxYearService) {}

  calculate(
    ssTaxableWages: Money,
    medicareTaxableWages: Money,
    ytd: YearToDate,
    matchOptions: EmployerMatchOptions,
    paymentDate = '2024-06-15'
  ): { ss: Money; medicare: Money; match401k: Money } {
    const tables = this.taxYearService.getYearTablesForPaymentDate(paymentDate);
    const remainingSsBase = sub(
      tables.fica.socialSecurityWageBase,
      ytd.ssTaxableWages
    );
    const ssWages =
      compare(remainingSsBase, '0.00') <= 0
        ? '0.00'
        : minMoney(ssTaxableWages, remainingSsBase);

    const ss = mul(ssWages, SOCIAL_SECURITY_RATE);
    const medicare = mul(medicareTaxableWages, MEDICARE_RATE);

    let match401k: Money;
    if (matchOptions.safeHarborMatch) {
      match401k = this.safeHarbor.calculateBasicMatch(
        matchOptions.compensation,
        matchOptions.employeeDeferral
      );
    } else {
      match401k = mul(
        matchOptions.employeeDeferral,
        String(matchOptions.matchPercent ?? 0)
      );
    }

    return { ss, medicare, match401k };
  }
}
