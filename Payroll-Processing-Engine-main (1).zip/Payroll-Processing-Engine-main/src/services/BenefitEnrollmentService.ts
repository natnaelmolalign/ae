import type {
  BenefitEnrollment,
  CreateBenefitEnrollmentInput,
  UpdateBenefitEnrollmentInput,
} from '../models/BenefitEnrollment';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';
import type { BenefitEnrollmentRepository } from '../repositories/interfaces';

export class BenefitEnrollmentService {
  constructor(private readonly repo: BenefitEnrollmentRepository) {}

  async create(
    input: CreateBenefitEnrollmentInput
  ): Promise<BenefitEnrollment> {
    this.validateEnrollment(input.type, input.hsaCoverage);
    return this.repo.create(input);
  }

  async get(id: string): Promise<BenefitEnrollment | null> {
    return this.repo.findById(id);
  }

  async listByEmployee(employeeId: string): Promise<BenefitEnrollment[]> {
    return this.repo.findByEmployee(employeeId);
  }

  async listActive(
    employeeId: string,
    asOfDate: string
  ): Promise<BenefitEnrollment[]> {
    return this.repo.findActiveForEmployee(employeeId, asOfDate);
  }

  async update(
    id: string,
    input: UpdateBenefitEnrollmentInput
  ): Promise<BenefitEnrollment> {
    const existing = await this.repo.findById(id);
    if (!existing) {
      throw PayrollDomainError.notFound('BenefitEnrollment', id);
    }
    if (input.hsaCoverage !== undefined) {
      this.validateEnrollment(
        existing.type,
        input.hsaCoverage ?? existing.hsaCoverage
      );
    }
    const updated = await this.repo.update(id, input);
    if (!updated) {
      throw PayrollDomainError.notFound('BenefitEnrollment', id);
    }
    return updated;
  }

  async remove(id: string): Promise<void> {
    const ok = await this.repo.delete(id);
    if (!ok) {
      throw PayrollDomainError.notFound('BenefitEnrollment', id);
    }
  }

  private validateEnrollment(
    type: string,
    hsaCoverage: string | null | undefined
  ): void {
    if (type === 'hsa' && !hsaCoverage) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'HSA enrollments require hsaCoverage (individual or family)'
      );
    }
  }
}
