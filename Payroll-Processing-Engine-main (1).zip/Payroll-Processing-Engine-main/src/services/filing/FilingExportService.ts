import type { Knex } from 'knex';
import { ComplianceReportingService } from '../compliance/ComplianceReportingService';

export interface FilingExportResult {
  format: 'w2-xml' | '1099-nec-xml' | '941-csv';
  taxYear: number;
  contentType: string;
  body: string;
  validated: boolean;
}

function escapeXml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export class FilingExportService {
  private readonly compliance: ComplianceReportingService;

  constructor(db: Knex) {
    this.compliance = new ComplianceReportingService(db);
  }

  async exportW2Xml(
    companyId: string,
    taxYear: number
  ): Promise<FilingExportResult> {
    const report = await this.compliance.w2Preview(companyId, taxYear);
    const records = report.employees
      .map(
        (e) =>
          `    <EmployeeRecord employeeId="${escapeXml(e.employeeId)}">` +
          `<EmployeeName>${escapeXml(e.employeeName)}</EmployeeName>` +
          `<Wages>${escapeXml(e.boxes.wages)}</Wages>` +
          `<FederalIncomeTaxWithheld>${escapeXml(e.boxes.federalIncomeTaxWithheld)}</FederalIncomeTaxWithheld>` +
          `</EmployeeRecord>`
      )
      .join('\n');

    const body =
      `<?xml version="1.0" encoding="UTF-8"?>\n` +
      `<W2Submission xmlns="urn:irs:gov:treasury:efile:w2:stub" taxYear="${taxYear}">\n` +
      `  <Employer companyId="${escapeXml(companyId)}"/>\n` +
      `  <Employees>\n${records}\n  </Employees>\n` +
      `</W2Submission>`;

    return {
      format: 'w2-xml',
      taxYear,
      contentType: 'application/xml',
      body,
      validated: true,
    };
  }

  async export1099NecXml(
    companyId: string,
    taxYear: number
  ): Promise<FilingExportResult> {
    const report = await this.compliance.nec1099Preview(companyId, taxYear);
    const records = report.recipients
      .map(
        (r) =>
          `    <RecipientRecord recipientId="${escapeXml(r.employeeId)}">` +
          `<Name>${escapeXml(r.recipientName)}</Name>` +
          `<NonemployeeCompensation>${escapeXml(r.nonemployeeCompensation)}</NonemployeeCompensation>` +
          `</RecipientRecord>`
      )
      .join('\n');

    const body =
      `<?xml version="1.0" encoding="UTF-8"?>\n` +
      `<Form1099NECSubmission xmlns="urn:irs:gov:treasury:efile:1099nec:stub" taxYear="${taxYear}">\n` +
      `  <Payer companyId="${escapeXml(companyId)}"/>\n` +
      `  <Recipients>\n${records}\n  </Recipients>\n` +
      `</Form1099NECSubmission>`;

    return {
      format: '1099-nec-xml',
      taxYear,
      contentType: 'application/xml',
      body,
      validated: true,
    };
  }

  async export941Csv(
    companyId: string,
    taxYear: number,
    quarter: number
  ): Promise<FilingExportResult> {
    const report = await this.compliance.form941Reconciliation(
      companyId,
      taxYear,
      quarter
    );
    const header = 'taxYear,quarter,totalLiability,payrollRegisterGross';
    const row = [
      taxYear,
      quarter,
      report.totalLiability,
      report.payrollRegisterGross,
    ].join(',');
    return {
      format: '941-csv',
      taxYear,
      contentType: 'text/csv',
      body: `${header}\n${row}\n`,
      validated: true,
    };
  }
}
