import type { Department } from '../../models/CostAccounting';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type { DepartmentRepository } from '../../repositories/interfaces';
import { UNASSIGNED_DEPARTMENT_CODE } from './LaborCostAllocationService';

export interface CreateDepartmentInput {
  code: string;
  name: string;
  locationCode?: string | null;
}

export class DepartmentService {
  constructor(private readonly repo: DepartmentRepository) {}

  async create(
    input: CreateDepartmentInput,
    companyId: string
  ): Promise<Department> {
    const code = input.code.trim().toUpperCase();
    if (code === UNASSIGNED_DEPARTMENT_CODE) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        `Department code ${UNASSIGNED_DEPARTMENT_CODE} is reserved`
      );
    }
    const existing = await this.repo.findByCode(companyId, code);
    if (existing) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        `Department code already exists: ${code}`,
        { code }
      );
    }
    return this.repo.create({
      companyId,
      code,
      name: input.name.trim(),
      locationCode: input.locationCode ?? null,
    });
  }

  async get(id: string, companyId: string): Promise<Department | null> {
    return this.repo.findById(id, companyId);
  }

  list(companyId: string): Promise<Department[]> {
    return this.repo.listByCompany(companyId);
  }
}
