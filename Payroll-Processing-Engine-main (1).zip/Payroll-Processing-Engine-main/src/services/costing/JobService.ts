import type { Job } from '../../models/CostAccounting';
import { PayrollDomainError } from '../../errors/PayrollDomainError';
import type {
  DepartmentRepository,
  JobRepository,
} from '../../repositories/interfaces';

export interface CreateJobInput {
  departmentId: string;
  code: string;
  name: string;
}

export class JobService {
  constructor(
    private readonly jobRepo: JobRepository,
    private readonly departmentRepo: DepartmentRepository
  ) {}

  async create(input: CreateJobInput, companyId: string): Promise<Job> {
    const dept = await this.departmentRepo.findById(
      input.departmentId,
      companyId
    );
    if (!dept) {
      throw PayrollDomainError.notFound('Department', input.departmentId);
    }
    return this.jobRepo.create({
      companyId,
      departmentId: dept.id,
      code: input.code.trim().toUpperCase(),
      name: input.name.trim(),
    });
  }

  async get(id: string, companyId: string): Promise<Job | null> {
    return this.jobRepo.findById(id, companyId);
  }

  listByDepartment(departmentId: string, companyId: string): Promise<Job[]> {
    return this.jobRepo.listByDepartment(departmentId, companyId);
  }
}
