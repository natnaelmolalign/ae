import { features } from '../../config/features';
import type {
  CostAllocationInput,
  CostAllocationSegment,
  Department,
} from '../../models/CostAccounting';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type {
  DepartmentRepository,
  JobRepository,
} from '../../repositories/interfaces';
import {
  add,
  compare,
  div,
  mul,
  sub,
  type Money,
} from '../../utils/decimalUtils';

const PERCENT_TOLERANCE = '0.01';
export const UNASSIGNED_DEPARTMENT_CODE = 'UNASSIGNED';

export interface ResolvedCostAllocation {
  departmentId: string;
  jobId: string | null;
  allocationPercent: string;
  allocationHours: string | null;
  segment: CostAllocationSegment;
}

export class LaborCostAllocationService {
  constructor(
    private readonly departmentRepo: DepartmentRepository,
    private readonly jobRepo: JobRepository
  ) {}

  isEnabled(): boolean {
    return features.costAccountingEnabled;
  }

  async ensureUnassignedDepartment(companyId: string): Promise<Department> {
    const existing = await this.departmentRepo.findByCode(
      companyId,
      UNASSIGNED_DEPARTMENT_CODE
    );
    if (existing) return existing;
    try {
      return await this.departmentRepo.create({
        companyId,
        code: UNASSIGNED_DEPARTMENT_CODE,
        name: 'Unassigned labor',
        locationCode: null,
        isSystem: true,
      });
    } catch {
      const raced = await this.departmentRepo.findByCode(
        companyId,
        UNASSIGNED_DEPARTMENT_CODE
      );
      if (raced) return raced;
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'Failed to provision UNASSIGNED department'
      );
    }
  }

  validatePercents(allocations: CostAllocationInput[]): void {
    if (allocations.length === 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        'At least one cost allocation is required'
      );
    }
    let sum = '0.00';
    const seenDept = new Set<string>();
    for (const row of allocations) {
      if (seenDept.has(row.departmentId)) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          `Duplicate department in cost allocation: ${row.departmentId}`,
          { departmentId: row.departmentId }
        );
      }
      seenDept.add(row.departmentId);
      if (compare(row.percent, '0.00') < 0) {
        throw new PayrollDomainError(
          PayrollErrorCode.INVALID_INPUT,
          'Allocation percent must be non-negative'
        );
      }
      sum = add(sum, row.percent);
    }
    if (compare(sum, sub('100.00', PERCENT_TOLERANCE)) < 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        `Cost allocation percents must sum to 100 (got ${sum})`,
        { sum }
      );
    }
    if (compare(sum, add('100.00', PERCENT_TOLERANCE)) > 0) {
      throw new PayrollDomainError(
        PayrollErrorCode.INVALID_INPUT,
        `Cost allocation percents must sum to 100 (got ${sum})`,
        { sum }
      );
    }
  }

  async resolveForRun(
    companyId: string,
    allocations: CostAllocationInput[] | undefined
  ): Promise<ResolvedCostAllocation[]> {
    if (!this.isEnabled()) {
      return [];
    }

    const rows =
      allocations && allocations.length > 0
        ? allocations
        : [
            {
              departmentId: (await this.ensureUnassignedDepartment(companyId))
                .id,
              percent: '100',
            },
          ];

    this.validatePercents(rows);

    const resolved: ResolvedCostAllocation[] = [];
    for (const row of rows) {
      const dept = await this.departmentRepo.findById(
        row.departmentId,
        companyId
      );
      if (!dept) {
        throw new PayrollDomainError(
          PayrollErrorCode.NOT_FOUND,
          `Department not found: ${row.departmentId}`,
          { departmentId: row.departmentId }
        );
      }
      let jobCode: string | null = null;
      if (row.jobId) {
        const job = await this.jobRepo.findById(row.jobId, companyId);
        if (!job || job.departmentId !== dept.id) {
          throw new PayrollDomainError(
            PayrollErrorCode.INVALID_INPUT,
            `Job ${row.jobId} does not belong to department ${dept.code}`,
            { jobId: row.jobId, departmentId: dept.id }
          );
        }
        jobCode = job.code;
      }

      const segment: CostAllocationSegment = {
        departmentId: dept.id,
        departmentCode: dept.code,
        departmentName: dept.name,
        locationCode: dept.locationCode,
        jobId: row.jobId ?? null,
        jobCode,
        percent: row.percent,
      };

      resolved.push({
        departmentId: dept.id,
        jobId: row.jobId ?? null,
        allocationPercent: row.percent,
        allocationHours: row.hours ?? null,
        segment,
      });
    }
    return resolved;
  }

  /** Split a monetary amount across allocation percents (used by GL export). */
  splitAmount(amount: Money, segments: CostAllocationSegment[]): Money[] {
    if (segments.length === 0) {
      return [amount];
    }
    return segments.map((s) => mul(amount, div(s.percent, '100')));
  }
}
