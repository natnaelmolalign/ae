import type { Knex } from 'knex';
import { PayrollDomainError } from '../../errors/PayrollDomainError';
import { add, mul, div, type Money } from '../../utils/decimalUtils';
import type { PayrollRunAllocationRepository } from '../../repositories/interfaces';
import type { CostAllocationSegment } from '../../models/CostAccounting';

export interface LaborCostDepartmentRow {
  departmentId: string;
  departmentCode: string;
  departmentName: string;
  locationCode: string | null;
  grossPay: Money;
  netPay: Money;
  federalWithholding: Money;
  stateWithholding: Money;
  employerFica: Money;
  employerMatch401k: Money;
  payrollRunCount: number;
}

export interface LaborCostReport {
  payPeriodId: string;
  departments: LaborCostDepartmentRow[];
  totals: Omit<
    LaborCostDepartmentRow,
    | 'departmentId'
    | 'departmentCode'
    | 'departmentName'
    | 'locationCode'
    | 'payrollRunCount'
  > & {
    payrollRunCount: number;
  };
}

interface RunFinancials {
  payrollRunId: string;
  grossPay: Money;
  netPay: Money;
  federalWithholding: Money;
  stateWithholding: Money;
  employerFica: Money;
  employerMatch401k: Money;
  segments: CostAllocationSegment[];
}

export class LaborCostReportingService {
  constructor(
    private readonly db: Knex,
    private readonly allocationRepo: PayrollRunAllocationRepository
  ) {}

  async build(
    payPeriodId: string,
    companyId: string
  ): Promise<LaborCostReport> {
    const period = await this.db('pay_periods')
      .where({ id: payPeriodId, company_id: companyId })
      .first();
    if (!period) {
      throw PayrollDomainError.notFound('Pay period', payPeriodId);
    }

    const runs = await this.db('payroll_runs as pr')
      .join('employees as e', 'pr.employee_id', 'e.id')
      .join('pay_stubs as ps', 'pr.pay_stub_id', 'ps.id')
      .where({
        'pr.pay_period_id': payPeriodId,
        'e.company_id': companyId,
      })
      .select(
        'pr.id as payroll_run_id',
        'ps.gross_pay',
        'ps.net_pay',
        'pr.taxes',
        'pr.employer_contributions'
      );

    const runIds = runs.map((r) => String(r.payroll_run_id));
    const segmentMap = await this.allocationRepo.findSegmentsForRuns(runIds);

    const financials: RunFinancials[] = runs.map((r) => {
      const taxes = typeof r.taxes === 'string' ? JSON.parse(r.taxes) : r.taxes;
      const employer =
        typeof r.employer_contributions === 'string'
          ? JSON.parse(r.employer_contributions)
          : r.employer_contributions;
      const runId = String(r.payroll_run_id);
      const segments = segmentMap.get(runId) ?? [];
      return {
        payrollRunId: runId,
        grossPay: String(r.gross_pay),
        netPay: String(r.net_pay),
        federalWithholding: String(taxes.federalIncome ?? '0.00'),
        stateWithholding: String(taxes.stateIncome ?? '0.00'),
        employerFica: add(
          String(employer.ss ?? '0.00'),
          String(employer.medicare ?? '0.00')
        ),
        employerMatch401k: String(employer.match401k ?? '0.00'),
        segments,
      };
    });

    const byDept = new Map<string, LaborCostDepartmentRow>();

    for (const run of financials) {
      const segments =
        run.segments.length > 0
          ? run.segments
          : [
              {
                departmentId: '_unassigned',
                departmentCode: 'UNASSIGNED',
                departmentName: 'Unassigned labor',
                locationCode: null,
                jobId: null,
                jobCode: null,
                percent: '100',
              },
            ];

      for (const seg of segments) {
        const share = div(seg.percent, '100');
        const key = seg.departmentId;
        const existing = byDept.get(key) ?? {
          departmentId: seg.departmentId,
          departmentCode: seg.departmentCode,
          departmentName: seg.departmentName,
          locationCode: seg.locationCode,
          grossPay: '0.00',
          netPay: '0.00',
          federalWithholding: '0.00',
          stateWithholding: '0.00',
          employerFica: '0.00',
          employerMatch401k: '0.00',
          payrollRunCount: 0,
        };
        existing.grossPay = add(existing.grossPay, mul(run.grossPay, share));
        existing.netPay = add(existing.netPay, mul(run.netPay, share));
        existing.federalWithholding = add(
          existing.federalWithholding,
          mul(run.federalWithholding, share)
        );
        existing.stateWithholding = add(
          existing.stateWithholding,
          mul(run.stateWithholding, share)
        );
        existing.employerFica = add(
          existing.employerFica,
          mul(run.employerFica, share)
        );
        existing.employerMatch401k = add(
          existing.employerMatch401k,
          mul(run.employerMatch401k, share)
        );
        existing.payrollRunCount += 1;
        byDept.set(key, existing);
      }
    }

    const departments = [...byDept.values()].sort((a, b) =>
      a.departmentCode.localeCompare(b.departmentCode)
    );

    const totals = departments.reduce(
      (acc, row) => ({
        grossPay: add(acc.grossPay, row.grossPay),
        netPay: add(acc.netPay, row.netPay),
        federalWithholding: add(acc.federalWithholding, row.federalWithholding),
        stateWithholding: add(acc.stateWithholding, row.stateWithholding),
        employerFica: add(acc.employerFica, row.employerFica),
        employerMatch401k: add(acc.employerMatch401k, row.employerMatch401k),
        payrollRunCount: acc.payrollRunCount + row.payrollRunCount,
      }),
      {
        grossPay: '0.00',
        netPay: '0.00',
        federalWithholding: '0.00',
        stateWithholding: '0.00',
        employerFica: '0.00',
        employerMatch401k: '0.00',
        payrollRunCount: 0,
      }
    );

    return { payPeriodId, departments, totals };
  }
}
