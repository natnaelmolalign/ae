import type { EssEmployeeProfile } from '../../models/EmployeeEss';
import type { PayStub, YearToDate } from '../../models/types';
import { PayrollDomainError } from '../../errors/PayrollDomainError';
import type {
  PayStubRepository,
  YtdRepository,
} from '../../repositories/interfaces';
import type { EmployeeService } from '../EmployeeService';
import type { ComplianceReportingService } from '../compliance/ComplianceReportingService';
import { emptyYtd } from '../../utils/ytdUtils';

export class EssService {
  constructor(
    private readonly employeeService: EmployeeService,
    private readonly payStubRepository: PayStubRepository,
    private readonly ytdRepository: YtdRepository,
    private readonly complianceReportingService: ComplianceReportingService
  ) {}

  async getProfile(
    employeeId: string,
    companyId: string
  ): Promise<EssEmployeeProfile> {
    const employee = await this.requireOwnEmployee(employeeId, companyId);
    return {
      id: employee.id,
      firstName: employee.firstName,
      lastName: employee.lastName,
      employmentType: employee.employmentType,
      payFrequency: employee.payFrequency,
      filingStatus: employee.filingStatus,
      stateCode: employee.stateCode,
      w4ExtraWithholding: employee.w4ExtraWithholding,
      w4DependentsCredit: employee.w4DependentsCredit,
      w4OtherDeductions: employee.w4OtherDeductions,
      w4OtherIncome: employee.w4OtherIncome,
      w4MultipleJobs: employee.w4MultipleJobs,
    };
  }

  async listPayStubs(
    employeeId: string,
    companyId: string
  ): Promise<PayStub[]> {
    await this.requireOwnEmployee(employeeId, companyId);
    return this.payStubRepository.listByEmployee(employeeId);
  }

  async getPayStub(
    employeeId: string,
    companyId: string,
    payStubId: string
  ): Promise<PayStub> {
    await this.requireOwnEmployee(employeeId, companyId);
    const stub = await this.payStubRepository.findById(payStubId);
    if (!stub || stub.employeeId !== employeeId) {
      throw PayrollDomainError.notFound('PayStub', payStubId);
    }
    return stub;
  }

  async getYtd(
    employeeId: string,
    companyId: string,
    taxYear: number
  ): Promise<YearToDate> {
    await this.requireOwnEmployee(employeeId, companyId);
    return (
      (await this.ytdRepository.get(employeeId, taxYear)) ??
      emptyYtd(employeeId, taxYear)
    );
  }

  async getW2Preview(
    employeeId: string,
    companyId: string,
    taxYear: number
  ): Promise<unknown> {
    await this.requireOwnEmployee(employeeId, companyId);
    const report = await this.complianceReportingService.w2Preview(
      companyId,
      taxYear
    );
    const employee = report.employees.find((e) => e.employeeId === employeeId);
    if (!employee) {
      throw PayrollDomainError.notFound('W2 preview', employeeId);
    }
    return { taxYear, employee };
  }

  private async requireOwnEmployee(employeeId: string, companyId: string) {
    const employee = await this.employeeService.get(employeeId, companyId);
    if (!employee) {
      throw PayrollDomainError.notFound('Employee', employeeId);
    }
    return employee;
  }
}
