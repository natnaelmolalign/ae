import type {
  CreateW4ChangeRequestInput,
  W4ChangeRequest,
} from '../../models/EmployeeEss';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../errors/PayrollDomainError';
import type {
  EmployeeRepository,
  W4ChangeRequestRepository,
} from '../../repositories/interfaces';
import type { AuditService } from '../AuditService';
import { toAuditSnapshot } from '../../utils/auditContext';

export class W4ChangeRequestService {
  constructor(
    private readonly w4Repo: W4ChangeRequestRepository,
    private readonly employeeRepo: EmployeeRepository,
    private readonly auditService: AuditService
  ) {}

  createDraft(input: CreateW4ChangeRequestInput): Promise<W4ChangeRequest> {
    return this.w4Repo.create(input);
  }

  listForEmployee(
    employeeId: string,
    companyId: string
  ): Promise<W4ChangeRequest[]> {
    return this.w4Repo.listByEmployee(employeeId, companyId);
  }

  listPending(companyId: string): Promise<W4ChangeRequest[]> {
    return this.w4Repo.listByStatus(companyId, 'pending');
  }

  async getForEmployee(
    id: string,
    employeeId: string,
    companyId: string
  ): Promise<W4ChangeRequest> {
    const request = await this.w4Repo.findById(id, companyId);
    if (!request || request.employeeId !== employeeId) {
      throw PayrollDomainError.notFound('W4ChangeRequest', id);
    }
    return request;
  }

  async submit(
    id: string,
    employeeId: string,
    companyId: string
  ): Promise<W4ChangeRequest> {
    const request = await this.getForEmployee(id, employeeId, companyId);
    if (request.status !== 'draft') {
      throw new PayrollDomainError(
        PayrollErrorCode.W4_CHANGE_INVALID_STATE,
        `Cannot submit W-4 change in status ${request.status}`
      );
    }
    const updated = await this.w4Repo.updateStatus(id, companyId, 'pending', {
      submittedAt: new Date().toISOString(),
    });
    if (!updated) {
      throw PayrollDomainError.notFound('W4ChangeRequest', id);
    }
    return updated;
  }

  async approve(
    id: string,
    companyId: string,
    reviewer: string
  ): Promise<W4ChangeRequest> {
    const request = await this.w4Repo.findById(id, companyId);
    if (!request) {
      throw PayrollDomainError.notFound('W4ChangeRequest', id);
    }
    if (request.status !== 'pending') {
      throw new PayrollDomainError(
        PayrollErrorCode.W4_CHANGE_INVALID_STATE,
        `Cannot approve W-4 change in status ${request.status}`
      );
    }

    const before = await this.employeeRepo.findById(request.employeeId);
    const employee = await this.employeeRepo.updateW4Fields(
      request.employeeId,
      companyId,
      {
        filingStatus: request.filingStatus,
        w4ExtraWithholding: request.w4ExtraWithholding,
        w4DependentsCredit: request.w4DependentsCredit,
        w4OtherDeductions: request.w4OtherDeductions,
        w4OtherIncome: request.w4OtherIncome,
        w4MultipleJobs: request.w4MultipleJobs,
      }
    );
    if (!employee) {
      throw PayrollDomainError.notFound('Employee', request.employeeId);
    }

    const now = new Date().toISOString();
    const updated = await this.w4Repo.updateStatus(id, companyId, 'applied', {
      reviewedAt: now,
      reviewedBy: reviewer,
      appliedAt: now,
    });
    if (!updated) {
      throw PayrollDomainError.notFound('W4ChangeRequest', id);
    }

    if (before) {
      await this.auditService.recordUpdate(
        reviewer,
        'employee',
        employee.id,
        toAuditSnapshot({
          filingStatus: before.filingStatus,
          w4ExtraWithholding: before.w4ExtraWithholding,
          w4DependentsCredit: before.w4DependentsCredit,
          w4ChangeRequestId: id,
        }),
        toAuditSnapshot({
          filingStatus: employee.filingStatus,
          w4ExtraWithholding: employee.w4ExtraWithholding,
          w4DependentsCredit: employee.w4DependentsCredit,
          w4ChangeRequestId: id,
        })
      );
    }

    return updated;
  }

  async reject(
    id: string,
    companyId: string,
    reviewer: string,
    notes?: string
  ): Promise<W4ChangeRequest> {
    const request = await this.w4Repo.findById(id, companyId);
    if (!request) {
      throw PayrollDomainError.notFound('W4ChangeRequest', id);
    }
    if (request.status !== 'pending') {
      throw new PayrollDomainError(
        PayrollErrorCode.W4_CHANGE_INVALID_STATE,
        `Cannot reject W-4 change in status ${request.status}`
      );
    }
    const updated = await this.w4Repo.updateStatus(id, companyId, 'rejected', {
      reviewedAt: new Date().toISOString(),
      reviewedBy: reviewer,
      reviewNotes: notes ?? null,
    });
    if (!updated) {
      throw PayrollDomainError.notFound('W4ChangeRequest', id);
    }
    return updated;
  }
}
