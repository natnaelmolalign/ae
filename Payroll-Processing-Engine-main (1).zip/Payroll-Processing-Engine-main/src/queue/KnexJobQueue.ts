import { randomUUID } from 'crypto';
import type { Knex } from 'knex';
import type {
  EnqueueJobInput,
  QueueDeadLetter,
  QueueJob,
  QueueJobStatus,
  QueueJobType,
} from '../models/QueueJob';
import type { JobQueue } from './JobQueue';

interface JobRow {
  id: string;
  job_type: string;
  partition_key: string;
  payload: string;
  status: string;
  attempts: number;
  max_attempts: number;
  last_error: string | null;
  locked_by: string | null;
  locked_at: string | null;
  created_at: string;
  updated_at: string;
}

interface DlqRow {
  id: string;
  original_job_id: string;
  job_type: string;
  partition_key: string;
  payload: string;
  attempts: number;
  last_error: string;
  failed_at: string;
}

function fromRow(row: JobRow): QueueJob {
  return {
    id: row.id,
    jobType: row.job_type as QueueJobType,
    partitionKey: row.partition_key,
    payload: JSON.parse(row.payload) as Record<string, unknown>,
    status: row.status as QueueJobStatus,
    attempts: row.attempts,
    maxAttempts: row.max_attempts,
    lastError: row.last_error,
    lockedBy: row.locked_by,
    lockedAt: row.locked_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class KnexJobQueue implements JobQueue {
  constructor(private readonly db: Knex) {}

  async enqueue(input: EnqueueJobInput): Promise<string> {
    const id = randomUUID();
    const now = new Date().toISOString();
    await this.db('queue_jobs').insert({
      id,
      job_type: input.jobType,
      partition_key: input.partitionKey,
      payload: JSON.stringify(input.payload),
      status: 'pending',
      attempts: 0,
      max_attempts: input.maxAttempts ?? 3,
      last_error: null,
      locked_by: null,
      locked_at: null,
      created_at: now,
      updated_at: now,
    });
    return id;
  }

  async poll(workerId: string): Promise<QueueJob | null> {
    return this.db.transaction(async (trx) => {
      const row = await trx('queue_jobs')
        .where({ status: 'pending' })
        .orderBy(['partition_key', 'created_at'])
        .first();
      if (!row) return null;
      const now = new Date().toISOString();
      const attempts = (row as JobRow).attempts + 1;
      await trx('queue_jobs')
        .where({ id: (row as JobRow).id, status: 'pending' })
        .update({
          status: 'processing',
          attempts,
          locked_by: workerId,
          locked_at: now,
          updated_at: now,
        });
      const updated = await trx('queue_jobs')
        .where({ id: (row as JobRow).id })
        .first();
      return updated ? fromRow(updated as JobRow) : null;
    });
  }

  async complete(jobId: string): Promise<void> {
    await this.db('queue_jobs').where({ id: jobId }).del();
  }

  async fail(jobId: string, error: string): Promise<'retry' | 'dlq'> {
    const row = await this.db('queue_jobs').where({ id: jobId }).first();
    if (!row) return 'dlq';
    const job = fromRow(row as JobRow);
    if (job.attempts >= job.maxAttempts) {
      await this.db('queue_dead_letters').insert({
        id: randomUUID(),
        original_job_id: job.id,
        job_type: job.jobType,
        partition_key: job.partitionKey,
        payload: JSON.stringify(job.payload),
        attempts: job.attempts,
        last_error: error,
        failed_at: new Date().toISOString(),
      });
      await this.db('queue_jobs').where({ id: jobId }).del();
      return 'dlq';
    }
    await this.db('queue_jobs').where({ id: jobId }).update({
      status: 'pending',
      last_error: error,
      locked_by: null,
      locked_at: null,
      updated_at: new Date().toISOString(),
    });
    return 'retry';
  }

  async listDeadLetters(limit = 100): Promise<QueueDeadLetter[]> {
    const rows = await this.db('queue_dead_letters')
      .orderBy('failed_at', 'desc')
      .limit(limit);
    return rows.map((row) => {
      const r = row as DlqRow;
      return {
        id: r.id,
        originalJobId: r.original_job_id,
        jobType: r.job_type as QueueJobType,
        partitionKey: r.partition_key,
        payload: JSON.parse(r.payload) as Record<string, unknown>,
        attempts: r.attempts,
        lastError: r.last_error,
        failedAt: r.failed_at,
      };
    });
  }
}
