import type {
  EnqueueJobInput,
  QueueDeadLetter,
  QueueJob,
} from '../models/QueueJob';
import type { JobQueue } from './JobQueue';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';

/**
 * AWS SQS adapter stub — configure JOB_QUEUE_BACKEND=knex for production-like behavior.
 */
export class SqsJobQueue implements JobQueue {
  async enqueue(_input: EnqueueJobInput): Promise<string> {
    throw new PayrollDomainError(
      PayrollErrorCode.SERVICE_UNAVAILABLE,
      'SQS job queue is not configured; set JOB_QUEUE_BACKEND=knex'
    );
  }

  async poll(_workerId: string): Promise<QueueJob | null> {
    return null;
  }

  async complete(_jobId: string): Promise<void> {}

  async fail(_jobId: string, _error: string): Promise<'retry' | 'dlq'> {
    return 'dlq';
  }

  async listDeadLetters(_limit?: number): Promise<QueueDeadLetter[]> {
    return [];
  }
}
