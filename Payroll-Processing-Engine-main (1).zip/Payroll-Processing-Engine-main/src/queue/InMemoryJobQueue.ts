import { randomUUID } from 'crypto';
import type {
  EnqueueJobInput,
  QueueDeadLetter,
  QueueJob,
} from '../models/QueueJob';
import type { JobQueue } from './JobQueue';

export class InMemoryJobQueue implements JobQueue {
  private readonly pending: QueueJob[] = [];
  private readonly deadLetters: QueueDeadLetter[] = [];

  async enqueue(input: EnqueueJobInput): Promise<string> {
    const now = new Date().toISOString();
    const job: QueueJob = {
      id: randomUUID(),
      jobType: input.jobType,
      partitionKey: input.partitionKey,
      payload: input.payload,
      status: 'pending',
      attempts: 0,
      maxAttempts: input.maxAttempts ?? 3,
      lastError: null,
      lockedBy: null,
      lockedAt: null,
      createdAt: now,
      updatedAt: now,
    };
    this.pending.push(job);
    this.pending.sort(
      (a, b) =>
        a.partitionKey.localeCompare(b.partitionKey) ||
        a.createdAt.localeCompare(b.createdAt)
    );
    return job.id;
  }

  async poll(workerId: string): Promise<QueueJob | null> {
    const job = this.pending.find((j) => j.status === 'pending');
    if (!job) return null;
    job.status = 'processing';
    job.lockedBy = workerId;
    job.lockedAt = new Date().toISOString();
    job.attempts += 1;
    job.updatedAt = job.lockedAt;
    return { ...job };
  }

  async complete(jobId: string): Promise<void> {
    const idx = this.pending.findIndex((j) => j.id === jobId);
    if (idx >= 0) this.pending.splice(idx, 1);
  }

  async fail(jobId: string, error: string): Promise<'retry' | 'dlq'> {
    const job = this.pending.find((j) => j.id === jobId);
    if (!job) return 'dlq';
    job.lastError = error;
    job.status = 'pending';
    job.lockedBy = null;
    job.lockedAt = null;
    job.updatedAt = new Date().toISOString();
    if (job.attempts >= job.maxAttempts) {
      const idx = this.pending.indexOf(job);
      this.pending.splice(idx, 1);
      this.deadLetters.push({
        id: randomUUID(),
        originalJobId: job.id,
        jobType: job.jobType,
        partitionKey: job.partitionKey,
        payload: job.payload,
        attempts: job.attempts,
        lastError: error,
        failedAt: new Date().toISOString(),
      });
      return 'dlq';
    }
    return 'retry';
  }

  async listDeadLetters(limit = 100): Promise<QueueDeadLetter[]> {
    return this.deadLetters.slice(0, limit);
  }

  /** Test helper */
  pendingCount(): number {
    return this.pending.filter((j) => j.status === 'pending').length;
  }
}
