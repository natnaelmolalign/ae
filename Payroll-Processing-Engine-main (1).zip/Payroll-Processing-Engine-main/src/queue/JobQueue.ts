import type {
  EnqueueJobInput,
  QueueDeadLetter,
  QueueJob,
} from '../models/QueueJob';

export interface JobQueue {
  enqueue(input: EnqueueJobInput): Promise<string>;
  poll(workerId: string): Promise<QueueJob | null>;
  complete(jobId: string): Promise<void>;
  fail(jobId: string, error: string): Promise<'retry' | 'dlq'>;
  listDeadLetters(limit?: number): Promise<QueueDeadLetter[]>;
}

export function buildPartitionKey(
  companyId: string,
  payPeriodId: string
): string {
  return `${companyId}:${payPeriodId}`;
}
