import {
  createCipheriv,
  createDecipheriv,
  createHash,
  randomBytes,
} from 'crypto';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';

const ALGO = 'aes-256-gcm';
const IV_LEN = 12;
const TAG_LEN = 16;
const KEY_ID = 'local-v1';

export interface TinCiphertext {
  keyId: string;
  payload: string;
  lastFour: string;
}

function deriveKey(secret: string): Buffer {
  return createHash('sha256').update(secret).digest();
}

function masterSecret(): string {
  const secret = process.env.TIN_MASTER_KEY?.trim();
  if (!secret) {
    throw new PayrollDomainError(
      PayrollErrorCode.INVALID_INPUT,
      'TIN_MASTER_KEY is required to store or read tax identification numbers'
    );
  }
  return secret;
}

export function normalizeTin(tin: string): string {
  const digits = tin.replace(/\D/g, '');
  if (digits.length !== 9) {
    throw new PayrollDomainError(
      PayrollErrorCode.INVALID_INPUT,
      'TIN must be 9 digits (SSN or EIN format)'
    );
  }
  return digits;
}

export function maskTin(tin: string): string {
  const digits = normalizeTin(tin);
  return `***-**-${digits.slice(-4)}`;
}

export function encryptTin(plainTin: string): TinCiphertext {
  const normalized = normalizeTin(plainTin);
  const iv = randomBytes(IV_LEN);
  const cipher = createCipheriv(ALGO, deriveKey(masterSecret()), iv);
  const encrypted = Buffer.concat([
    cipher.update(normalized, 'utf8'),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();
  const payload = Buffer.concat([iv, tag, encrypted]).toString('base64');
  return {
    keyId: KEY_ID,
    payload,
    lastFour: normalized.slice(-4),
  };
}

export function decryptTin(payload: string, keyId: string): string {
  if (keyId !== KEY_ID) {
    throw new PayrollDomainError(
      PayrollErrorCode.INVALID_INPUT,
      `Unsupported TIN key id: ${keyId}`
    );
  }
  const buf = Buffer.from(payload, 'base64');
  if (buf.length < IV_LEN + TAG_LEN + 1) {
    throw new PayrollDomainError(
      PayrollErrorCode.INVALID_INPUT,
      'Invalid TIN ciphertext'
    );
  }
  const iv = buf.subarray(0, IV_LEN);
  const tag = buf.subarray(IV_LEN, IV_LEN + TAG_LEN);
  const data = buf.subarray(IV_LEN + TAG_LEN);
  const decipher = createDecipheriv(ALGO, deriveKey(masterSecret()), iv);
  decipher.setAuthTag(tag);
  const plain = Buffer.concat([decipher.update(data), decipher.final()]);
  return plain.toString('utf8');
}
