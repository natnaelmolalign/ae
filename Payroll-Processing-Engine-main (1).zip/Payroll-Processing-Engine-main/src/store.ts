/**
 * @deprecated Phase 2 — use `getAppDependencies()` from `./deps` instead.
 * Retained only for backward compatibility during migration.
 */
export { getAppDependencies, createAppDependencies } from './deps';
