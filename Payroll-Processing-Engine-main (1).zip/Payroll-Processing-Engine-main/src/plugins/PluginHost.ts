export interface DeductionPluginContext {
  companyId: string;
  employeeId: string;
  grossPay: string;
  payPeriodId: string;
}

export interface DeductionPluginResult {
  code: string;
  amount: string;
  description?: string;
}

export interface DeductionPlugin {
  id: string;
  name: string;
  /** Must only use data scoped to context.companyId */
  calculate(
    context: DeductionPluginContext
  ): Promise<DeductionPluginResult | null>;
}

export class PluginHost {
  private readonly plugins = new Map<string, DeductionPlugin>();

  register(plugin: DeductionPlugin): void {
    this.plugins.set(plugin.id, plugin);
  }

  unregister(pluginId: string): void {
    this.plugins.delete(pluginId);
  }

  list(): DeductionPlugin[] {
    return [...this.plugins.values()];
  }

  async execute(
    pluginId: string,
    context: DeductionPluginContext,
    timeoutMs = Number(process.env.PLUGIN_TIMEOUT_MS ?? 500)
  ): Promise<DeductionPluginResult | null> {
    const plugin = this.plugins.get(pluginId);
    if (!plugin) return null;

    const tenantScoped: DeductionPluginContext = {
      companyId: context.companyId,
      employeeId: context.employeeId,
      grossPay: context.grossPay,
      payPeriodId: context.payPeriodId,
    };

    const work = plugin.calculate(tenantScoped);
    const result = await Promise.race([
      work,
      new Promise<never>((_, reject) =>
        setTimeout(
          () => reject(new Error('Plugin execution timed out')),
          timeoutMs
        )
      ),
    ]);
    return result;
  }
}
