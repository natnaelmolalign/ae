export enum PayrollErrorCode {
  INVALID_INPUT = 'INVALID_INPUT',
  NOT_FOUND = 'NOT_FOUND',
  INVALID_GROSS = 'INVALID_GROSS',
  UNKNOWN_PAY_FREQUENCY = 'UNKNOWN_PAY_FREQUENCY',
  PAY_PERIOD_OVERLAP = 'PAY_PERIOD_OVERLAP',
  PAY_STUB_RECONCILIATION_FAILED = 'PAY_STUB_RECONCILIATION_FAILED',
  RETRO_AFTER_TERMINATION = 'RETRO_AFTER_TERMINATION',
  TAX_YEAR_UNSUPPORTED = 'TAX_YEAR_UNSUPPORTED',
  DUPLICATE_PAYROLL_RUN = 'DUPLICATE_PAYROLL_RUN',
  GARNISHMENT_AFTER_TERMINATION = 'GARNISHMENT_AFTER_TERMINATION',
  RETRO_INVALID_STATE = 'RETRO_INVALID_STATE',
  UNAUTHORIZED = 'UNAUTHORIZED',
  FORBIDDEN = 'FORBIDDEN',
  SERVICE_UNAVAILABLE = 'SERVICE_UNAVAILABLE',
  YTD_RESET_BLOCKED = 'YTD_RESET_BLOCKED',
  PAY_POLICY_VIOLATION = 'PAY_POLICY_VIOLATION',
  INSUFFICIENT_LEAVE_BALANCE = 'INSUFFICIENT_LEAVE_BALANCE',
  TIME_NOT_APPROVED = 'TIME_NOT_APPROVED',
  TIME_APPROVAL_TOLERANCE_EXCEEDED = 'TIME_APPROVAL_TOLERANCE_EXCEEDED',
  ENROLLMENT_WINDOW_CLOSED = 'ENROLLMENT_WINDOW_CLOSED',
  LIFE_EVENT_REQUIRED = 'LIFE_EVENT_REQUIRED',
  LIFE_EVENT_NOT_APPROVED = 'LIFE_EVENT_NOT_APPROVED',
  RETROACTIVE_PRETAX_NOT_ALLOWED = 'RETROACTIVE_PRETAX_NOT_ALLOWED',
  INELIGIBLE_FOR_BENEFIT = 'INELIGIBLE_FOR_BENEFIT',
  DISBURSEMENT_SPLIT_MISMATCH = 'DISBURSEMENT_SPLIT_MISMATCH',
  NO_DISBURSEMENT_INSTRUCTIONS = 'NO_DISBURSEMENT_INSTRUCTIONS',
  PAYMENT_BATCH_INVALID_STATE = 'PAYMENT_BATCH_INVALID_STATE',
  GL_MAPPING_NOT_FOUND = 'GL_MAPPING_NOT_FOUND',
  CONNECTOR_EXPORT_FAILED = 'CONNECTOR_EXPORT_FAILED',
  ESS_EMPLOYEE_CONTEXT_REQUIRED = 'ESS_EMPLOYEE_CONTEXT_REQUIRED',
  W4_CHANGE_INVALID_STATE = 'W4_CHANGE_INVALID_STATE',
  PAYROLL_HOLD_ACTIVE = 'PAYROLL_HOLD_ACTIVE',
  ANOMALY_APPROVAL_REQUIRED = 'ANOMALY_APPROVAL_REQUIRED',
}

const HTTP_STATUS: Record<PayrollErrorCode, number> = {
  [PayrollErrorCode.INVALID_INPUT]: 400,
  [PayrollErrorCode.NOT_FOUND]: 404,
  [PayrollErrorCode.INVALID_GROSS]: 400,
  [PayrollErrorCode.UNKNOWN_PAY_FREQUENCY]: 400,
  [PayrollErrorCode.PAY_PERIOD_OVERLAP]: 409,
  [PayrollErrorCode.PAY_STUB_RECONCILIATION_FAILED]: 500,
  [PayrollErrorCode.RETRO_AFTER_TERMINATION]: 400,
  [PayrollErrorCode.TAX_YEAR_UNSUPPORTED]: 400,
  [PayrollErrorCode.DUPLICATE_PAYROLL_RUN]: 409,
  [PayrollErrorCode.GARNISHMENT_AFTER_TERMINATION]: 400,
  [PayrollErrorCode.RETRO_INVALID_STATE]: 409,
  [PayrollErrorCode.UNAUTHORIZED]: 401,
  [PayrollErrorCode.FORBIDDEN]: 403,
  [PayrollErrorCode.SERVICE_UNAVAILABLE]: 503,
  [PayrollErrorCode.YTD_RESET_BLOCKED]: 409,
  [PayrollErrorCode.PAY_POLICY_VIOLATION]: 400,
  [PayrollErrorCode.INSUFFICIENT_LEAVE_BALANCE]: 400,
  [PayrollErrorCode.TIME_NOT_APPROVED]: 409,
  [PayrollErrorCode.TIME_APPROVAL_TOLERANCE_EXCEEDED]: 400,
  [PayrollErrorCode.ENROLLMENT_WINDOW_CLOSED]: 409,
  [PayrollErrorCode.LIFE_EVENT_REQUIRED]: 400,
  [PayrollErrorCode.LIFE_EVENT_NOT_APPROVED]: 400,
  [PayrollErrorCode.RETROACTIVE_PRETAX_NOT_ALLOWED]: 400,
  [PayrollErrorCode.INELIGIBLE_FOR_BENEFIT]: 400,
  [PayrollErrorCode.DISBURSEMENT_SPLIT_MISMATCH]: 400,
  [PayrollErrorCode.NO_DISBURSEMENT_INSTRUCTIONS]: 400,
  [PayrollErrorCode.PAYMENT_BATCH_INVALID_STATE]: 409,
  [PayrollErrorCode.GL_MAPPING_NOT_FOUND]: 400,
  [PayrollErrorCode.CONNECTOR_EXPORT_FAILED]: 502,
  [PayrollErrorCode.ESS_EMPLOYEE_CONTEXT_REQUIRED]: 403,
  [PayrollErrorCode.W4_CHANGE_INVALID_STATE]: 409,
  [PayrollErrorCode.PAYROLL_HOLD_ACTIVE]: 409,
  [PayrollErrorCode.ANOMALY_APPROVAL_REQUIRED]: 409,
};

export class PayrollDomainError extends Error {
  readonly code: PayrollErrorCode;
  readonly httpStatus: number;
  readonly details?: Record<string, unknown>;

  constructor(
    code: PayrollErrorCode,
    message: string,
    details?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'PayrollDomainError';
    this.code = code;
    this.httpStatus = HTTP_STATUS[code];
    this.details = details;
  }

  static notFound(resource: string, id?: string): PayrollDomainError {
    const msg = id ? `${resource} not found: ${id}` : `${resource} not found`;
    return new PayrollDomainError(PayrollErrorCode.NOT_FOUND, msg, {
      resource,
      id,
    });
  }

  static invalidGross(): PayrollDomainError {
    return new PayrollDomainError(
      PayrollErrorCode.INVALID_GROSS,
      'Gross earnings must be positive for payroll run'
    );
  }

  static unknownPayFrequency(frequency: string): PayrollDomainError {
    return new PayrollDomainError(
      PayrollErrorCode.UNKNOWN_PAY_FREQUENCY,
      `Unknown pay frequency: ${frequency}`,
      { frequency }
    );
  }

  static payPeriodOverlap(idA: string, idB: string): PayrollDomainError {
    return new PayrollDomainError(
      PayrollErrorCode.PAY_PERIOD_OVERLAP,
      `Overlapping pay periods detected: ${idA} and ${idB}`,
      { idA, idB }
    );
  }

  static payStubReconciliation(
    gross: string,
    net: string,
    taxes: string,
    deductions: string
  ): PayrollDomainError {
    return new PayrollDomainError(
      PayrollErrorCode.PAY_STUB_RECONCILIATION_FAILED,
      `Pay stub reconciliation failed: gross ${gross} - taxes ${taxes} - deductions ${deductions} != net ${net}`,
      { gross, net, taxes, deductions }
    );
  }

  static retroAfterTermination(): PayrollDomainError {
    return new PayrollDomainError(
      PayrollErrorCode.RETRO_AFTER_TERMINATION,
      'Cannot apply retroactive adjustment after employee termination payment date'
    );
  }

  static duplicatePayrollRun(
    employeeId: string,
    payPeriodId: string
  ): PayrollDomainError {
    return new PayrollDomainError(
      PayrollErrorCode.DUPLICATE_PAYROLL_RUN,
      `Payroll already run for employee ${employeeId} in period ${payPeriodId}`,
      { employeeId, payPeriodId }
    );
  }

  static retroInvalidState(
    adjustmentId: string,
    status: string,
    expected: string
  ): PayrollDomainError {
    return new PayrollDomainError(
      PayrollErrorCode.RETRO_INVALID_STATE,
      `Retro adjustment ${adjustmentId} is ${status}; expected ${expected}`,
      { adjustmentId, status, expected }
    );
  }

  static payPolicyViolation(
    violations: Array<{
      policyId: string;
      policyCode: string;
      ruleType: string;
      message: string;
    }>
  ): PayrollDomainError {
    return new PayrollDomainError(
      PayrollErrorCode.PAY_POLICY_VIOLATION,
      `Pay policy violation: ${violations[0]?.message ?? 'rules failed'}`,
      { violations }
    );
  }
}
