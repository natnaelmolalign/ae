import { createServer } from 'http';
import { createApp } from './app';
import { closeDb } from './config/database';
import { rootLogger } from './logging/logger';
import { registerGracefulShutdown } from './shutdown';
import { initPrometheusMetrics } from './metrics/prometheus';

const port = Number(process.env.PORT || 3000);

export async function startServer(): Promise<void> {
  initPrometheusMetrics();
  const { getAppDependencies } = await import('./deps');
  const deps = await getAppDependencies();
  const app = createApp(deps);
  const server = createServer(app);

  registerGracefulShutdown(server, async () => {
    await closeDb();
  });

  server.listen(port, () => {
    rootLogger.info('server.start', { port });
  });
}

if (require.main === module) {
  void startServer();
}
