import winston from 'winston';

const logLevel = process.env.LOG_LEVEL || 'info';

export const rootLogger = winston.createLogger({
  level: logLevel,
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: { service: 'payroll-processing-engine' },
  transports: [new winston.transports.Console()],
});

export interface LogContext {
  correlationId?: string;
  traceParent?: string;
  employeeId?: string;
  payPeriodId?: string;
  phase?: string;
}

export function childLogger(context: LogContext): winston.Logger {
  return rootLogger.child(context);
}
