import helmet from 'helmet';
import type { Express } from 'express';
import rateLimit from 'express-rate-limit';

export function applySecurityMiddleware(app: Express): void {
  app.use(helmet());

  app.use(
    rateLimit({
      windowMs: 60_000,
      max: Number(process.env.RATE_LIMIT_MAX || 300),
      standardHeaders: true,
      legacyHeaders: false,
      skip: (req) => req.path === '/health' || req.path === '/ready',
    })
  );
}
