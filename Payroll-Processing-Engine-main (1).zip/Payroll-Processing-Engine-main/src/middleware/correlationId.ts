import type { NextFunction, Request, Response } from 'express';
import { childLogger } from '../logging/logger';
import { recordHttpRequest } from '../metrics/prometheus';
import {
  correlationIdFromTrace,
  newTraceIds,
  parseTraceParent,
  traceParentFromCorrelationId,
} from '../observability/tracing';

const CORRELATION_HEADER = 'x-correlation-id';
const TRACE_HEADER = 'traceparent';

export function correlationIdMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const incomingCorrelation = req.header(CORRELATION_HEADER);
  const incomingTrace = req.header(TRACE_HEADER);
  const parsedTrace = parseTraceParent(incomingTrace);

  let correlationId: string;
  let traceParent: string;

  if (typeof incomingCorrelation === 'string' && incomingCorrelation.trim()) {
    correlationId = incomingCorrelation.trim();
    traceParent =
      parsedTrace?.traceId != null
        ? incomingTrace!.trim()
        : traceParentFromCorrelationId(correlationId);
  } else if (parsedTrace) {
    correlationId = correlationIdFromTrace(parsedTrace.traceId);
    traceParent = incomingTrace!.trim();
  } else {
    const ids = newTraceIds();
    correlationId = ids.correlationId;
    traceParent = ids.traceParent;
  }

  req.correlationId = correlationId;
  req.traceParent = traceParent;
  req.log = childLogger({ correlationId, traceParent });

  res.setHeader(CORRELATION_HEADER, correlationId);
  res.setHeader(TRACE_HEADER, traceParent);

  const start = Date.now();
  const routeTemplate = `${req.baseUrl || ''}${req.route?.path || req.path}`;
  req.log.info('request.start', {
    method: req.method,
    path: req.path,
  });

  res.on('finish', () => {
    const durationMs = Date.now() - start;
    req.log?.info('request.finish', {
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      durationMs,
    });
    recordHttpRequest(req.method, routeTemplate, res.statusCode, durationMs);
  });

  next();
}
