import type { NextFunction, Request, Response, RequestHandler } from 'express';

type RouteHandler = (
  req: Request,
  res: Response,
  next: NextFunction
) => void | Promise<void>;

/** Forwards thrown errors and rejected promises to Express error middleware */
export function asyncHandler(handler: RouteHandler): RequestHandler {
  return (req, res, next) => {
    Promise.resolve(handler(req, res, next)).catch(next);
  };
}
