import type { NextFunction, Request, Response } from 'express';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';
import type { PayrollRole } from '../config/auth';

const MUTATION_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

function hasAnyRole(req: Request, roles: PayrollRole[]): boolean {
  return req.auth.roles.some((r) => roles.includes(r));
}

export function rbac(req: Request, _res: Response, next: NextFunction): void {
  const path = req.path;
  if (path === '/health' || path === '/ready') {
    next();
    return;
  }

  const isEss = path.startsWith('/api/ess');
  const isEmployeeSelf = hasAnyRole(req, ['employee_self']);

  if (isEmployeeSelf) {
    if (!req.auth.employeeId) {
      next(
        new PayrollDomainError(
          PayrollErrorCode.ESS_EMPLOYEE_CONTEXT_REQUIRED,
          'employee_self role requires employeeId in token or x-employee-id header'
        )
      );
      return;
    }
    if (!isEss) {
      next(
        new PayrollDomainError(
          PayrollErrorCode.FORBIDDEN,
          'employee_self may only access /api/ess routes'
        )
      );
      return;
    }
    next();
    return;
  }

  if (path.startsWith('/api/admin/webhooks')) {
    if (!hasAnyRole(req, ['payroll_admin'])) {
      next(
        new PayrollDomainError(
          PayrollErrorCode.FORBIDDEN,
          'Webhook subscription management requires payroll_admin'
        )
      );
      return;
    }
    next();
    return;
  }

  if (!MUTATION_METHODS.has(req.method)) {
    next();
    return;
  }

  const adminOnlyRetro =
    path.includes('/adjustments/') &&
    (path.endsWith('/approve') || path.endsWith('/apply'));

  if (adminOnlyRetro && !hasAnyRole(req, ['payroll_admin'])) {
    next(
      new PayrollDomainError(
        PayrollErrorCode.FORBIDDEN,
        'Retro adjustment approve/apply requires payroll_admin'
      )
    );
    return;
  }

  if (hasAnyRole(req, ['payroll_admin', 'payroll_clerk'])) {
    next();
    return;
  }

  next(
    new PayrollDomainError(
      PayrollErrorCode.FORBIDDEN,
      'Insufficient role for this operation'
    )
  );
}
