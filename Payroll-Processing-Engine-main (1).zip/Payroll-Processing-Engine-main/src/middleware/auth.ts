import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import {
  authEnforced,
  defaultCompanyId,
  parseApiKeys,
  type AuthContext,
  type PayrollRole,
  isPayrollRole,
} from '../config/auth';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../errors/PayrollDomainError';

function extractBearer(req: Request): string | null {
  const header = req.header('authorization');
  if (!header?.toLowerCase().startsWith('bearer ')) return null;
  return header.slice(7).trim() || null;
}

function extractApiKey(req: Request): string | null {
  return req.header('x-api-key')?.trim() || extractBearer(req);
}

function testDefaultAuth(req: Request): AuthContext {
  const actor =
    req.header('x-actor-id')?.trim() ||
    req.header('x-user-id')?.trim() ||
    'test-runner';
  const employeeId = req.header('x-employee-id')?.trim();
  if (employeeId) {
    return {
      actor,
      roles: ['employee_self'],
      companyId: req.header('x-company-id')?.trim() || defaultCompanyId(),
      employeeId,
    };
  }
  return {
    actor,
    roles: ['payroll_admin'],
    companyId: req.header('x-company-id')?.trim() || defaultCompanyId(),
  };
}

function resolveApiKeyAuth(req: Request, token: string): AuthContext | null {
  const map = parseApiKeys(process.env.API_KEYS);
  const roles = map.get(token);
  if (!roles) return null;
  const actor =
    req.header('x-actor-id')?.trim() ||
    req.header('x-user-id')?.trim() ||
    `api-key:${token.slice(0, 8)}`;
  return {
    actor,
    roles,
    companyId: req.header('x-company-id')?.trim() || defaultCompanyId(),
  };
}

function resolveJwtAuth(req: Request, token: string): AuthContext | null {
  const secret = process.env.JWT_SECRET?.trim();
  if (!secret) return null;
  try {
    const payload = jwt.verify(token, secret) as {
      sub?: string;
      roles?: string[];
      companyId?: string;
      employeeId?: string;
    };
    const roles = (payload.roles ?? []).filter(isPayrollRole) as PayrollRole[];
    if (roles.length === 0) return null;
    const actor =
      req.header('x-actor-id')?.trim() ||
      req.header('x-user-id')?.trim() ||
      (payload.sub ?? 'jwt-user');
    return {
      actor,
      roles,
      companyId:
        req.header('x-company-id')?.trim() ||
        payload.companyId?.trim() ||
        defaultCompanyId(),
      employeeId: payload.employeeId?.trim(),
    };
  } catch {
    return null;
  }
}

export function auth(req: Request, _res: Response, next: NextFunction): void {
  if (req.path === '/health' || req.path === '/ready') {
    next();
    return;
  }

  if (!authEnforced()) {
    req.auth = testDefaultAuth(req);
    req.actor = req.auth.actor;
    next();
    return;
  }

  const token = extractApiKey(req);
  if (!token) {
    next(
      new PayrollDomainError(
        PayrollErrorCode.UNAUTHORIZED,
        'Missing API key or bearer token'
      )
    );
    return;
  }

  const ctx = resolveApiKeyAuth(req, token) ?? resolveJwtAuth(req, token);

  if (!ctx) {
    next(
      new PayrollDomainError(
        PayrollErrorCode.UNAUTHORIZED,
        'Invalid or expired credentials'
      )
    );
    return;
  }

  req.auth = ctx;
  req.actor = ctx.actor;
  next();
}
