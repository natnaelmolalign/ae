import type { NextFunction, Request, Response } from 'express';
import { PayrollDomainError } from '../errors/PayrollDomainError';
import { rootLogger } from '../logging/logger';
import { problemTypeUri, sendProblem } from '../utils/problemDetails';

export function errorHandler(
  err: Error,
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  const log = req.log ?? rootLogger;

  if (err instanceof PayrollDomainError) {
    log.warn('domain.error', {
      code: err.code,
      message: err.message,
      details: err.details,
    });
    sendProblem(res, err.httpStatus, {
      type: problemTypeUri(err.code.toLowerCase()),
      title: err.code,
      detail: err.message,
      code: err.code,
      correlationId: req.correlationId,
      ...(err.details ?? {}),
    });
    return;
  }

  log.error('unhandled.error', { message: err.message, stack: err.stack });
  sendProblem(res, 500, {
    type: problemTypeUri('internal-error'),
    title: 'Internal Server Error',
    detail: 'An unexpected error occurred',
    correlationId: req.correlationId,
  });
}
