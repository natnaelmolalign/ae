import type { Knex } from 'knex';
import { getDb, runMigrations } from './config/database';
import { getDatabaseRouter, type DatabaseRouter } from './db/DatabaseRouter';
import { KnexEmployeeRepository } from './repositories/knex/KnexEmployeeRepository';
import { KnexPayPeriodRepository } from './repositories/knex/KnexPayPeriodRepository';
import { KnexPayStubRepository } from './repositories/knex/KnexPayStubRepository';
import { KnexPayrollRunRepository } from './repositories/knex/KnexPayrollRunRepository';
import { KnexYtdRepository } from './repositories/knex/KnexYtdRepository';
import { KnexTimeEntryRepository } from './repositories/knex/KnexTimeEntryRepository';
import { KnexBenefitEnrollmentRepository } from './repositories/knex/KnexBenefitEnrollmentRepository';
import { KnexGarnishmentOrderRepository } from './repositories/knex/KnexGarnishmentOrderRepository';
import { KnexRetroAdjustmentRepository } from './repositories/knex/KnexRetroAdjustmentRepository';
import { KnexPayrollBatchRepository } from './repositories/knex/KnexPayrollBatchRepository';
import { KnexPayrollRunFailureRepository } from './repositories/knex/KnexPayrollRunFailureRepository';
import { KnexEmployeePayrollReadinessRepository } from './repositories/knex/KnexEmployeePayrollReadinessRepository';
import { KnexEmployeeWorkLocationRepository } from './repositories/knex/KnexEmployeeWorkLocationRepository';
import { KnexDeductionScheduleRepository } from './repositories/knex/KnexDeductionScheduleRepository';
import { KnexAuditEventRepository } from './repositories/knex/KnexAuditEventRepository';
import type {
  AuditEventRepository,
  BenefitEnrollmentRepository,
  GarnishmentOrderRepository,
  EmployeeRepository,
  EmployeeWorkLocationRepository,
  EmployeePayrollReadinessRepository,
  PayPeriodRepository,
  PayStubRepository,
  PayrollBatchRepository,
  PayrollRunFailureRepository,
  PayrollRunRepository,
  RetroAdjustmentRepository,
  TimeEntryRepository,
  YtdRepository,
  DeductionScheduleRepository,
  DepartmentRepository,
  JobRepository,
  PayrollRunAllocationRepository,
  PayPolicyRepository,
  LeavePolicyRepository,
  LeaveBalanceRepository,
  LeaveTransactionRepository,
  ShiftRepository,
  ShiftAssignmentRepository,
  TimeExceptionRepository,
  WebhookSubscriptionRepository,
  WebhookOutboxRepository,
  WebhookDeliveryRepository,
} from './repositories/interfaces';
import { AuditService } from './services/AuditService';
import { PayrollBatchService } from './services/PayrollBatchService';
import { ReportingService } from './services/ReportingService';
import { PayStubHtmlRenderer } from './services/PayStubHtmlRenderer';
import { BenefitEnrollmentService } from './services/BenefitEnrollmentService';
import { GarnishmentOrderService } from './services/GarnishmentOrderService';
import { DeductionPreviewService } from './services/DeductionPreviewService';
import { DeductionScheduleService } from './services/DeductionScheduleService';
import { KnexWebhookSubscriptionRepository } from './repositories/knex/KnexWebhookSubscriptionRepository';
import { KnexWebhookOutboxRepository } from './repositories/knex/KnexWebhookOutboxRepository';
import { KnexWebhookDeliveryRepository } from './repositories/knex/KnexWebhookDeliveryRepository';
import { WebhookOutboxService } from './services/webhooks/WebhookOutboxService';
import { WebhookDeliveryWorker } from './services/webhooks/WebhookDeliveryWorker';
import { WebhookSubscriptionService } from './services/webhooks/WebhookSubscriptionService';
import { EarningsPreviewService } from './services/EarningsPreviewService';
import { EmployeeService } from './services/EmployeeService';
import { EmployeeWorkLocationService } from './services/EmployeeWorkLocationService';
import { PayPeriodService } from './services/PayPeriodService';
import { PayrollRunService } from './services/PayrollRunService';
import { RetroAdjustmentService } from './services/RetroAdjustmentService';
import { TimeEntryService } from './services/TimeEntryService';
import { defaultTaxYearService } from './services/tax/TaxYearService';
import { KnexDepartmentRepository } from './repositories/knex/KnexDepartmentRepository';
import { KnexJobRepository } from './repositories/knex/KnexJobRepository';
import { KnexPayrollRunAllocationRepository } from './repositories/knex/KnexPayrollRunAllocationRepository';
import { DepartmentService } from './services/costing/DepartmentService';
import { JobService } from './services/costing/JobService';
import { LaborCostAllocationService } from './services/costing/LaborCostAllocationService';
import { ComplianceReportingService } from './services/compliance/ComplianceReportingService';
import { KnexPayPolicyRepository } from './repositories/knex/KnexPayPolicyRepository';
import { PayPolicyService } from './services/policies/PayPolicyService';
import { KnexLeavePolicyRepository } from './repositories/knex/KnexLeavePolicyRepository';
import { KnexLeaveBalanceRepository } from './repositories/knex/KnexLeaveBalanceRepository';
import { KnexLeaveTransactionRepository } from './repositories/knex/KnexLeaveTransactionRepository';
import { LeavePolicyService } from './services/leave/LeavePolicyService';
import { LeaveAccrualService } from './services/leave/LeaveAccrualService';
import { LeaveUsageService } from './services/leave/LeaveUsageService';
import { KnexShiftRepository } from './repositories/knex/KnexShiftRepository';
import { KnexShiftAssignmentRepository } from './repositories/knex/KnexShiftAssignmentRepository';
import { KnexTimeExceptionRepository } from './repositories/knex/KnexTimeExceptionRepository';
import { SchedulingService } from './services/workforce/SchedulingService';
import { TimeApprovalService } from './services/workforce/TimeApprovalService';
import { KnexEnrollmentWindowRepository } from './repositories/knex/KnexEnrollmentWindowRepository';
import { KnexEligibilityRuleRepository } from './repositories/knex/KnexEligibilityRuleRepository';
import { KnexLifeEventRepository } from './repositories/knex/KnexLifeEventRepository';
import { OpenEnrollmentService } from './services/benefits/OpenEnrollmentService';
import type {
  EnrollmentWindowRepository,
  EligibilityRuleRepository,
  LifeEventRepository,
  DisbursementInstructionRepository,
  DisbursementBatchRepository,
  W4ChangeRequestRepository,
} from './repositories/interfaces';
import { KnexDisbursementInstructionRepository } from './repositories/knex/KnexDisbursementInstructionRepository';
import { KnexDisbursementBatchRepository } from './repositories/knex/KnexDisbursementBatchRepository';
import { DisbursementInstructionService } from './services/disbursements/DisbursementInstructionService';
import { PaymentBatchService } from './services/disbursements/PaymentBatchService';
import { KnexErpConnectorRepository } from './repositories/knex/KnexErpConnectorRepository';
import { ErpExportService } from './services/erp/ErpExportService';
import { createDefaultConnectorRegistry } from './services/erp/ConnectorStubs';
import type { ErpConnectorRepository } from './repositories/interfaces';
import { KnexW4ChangeRequestRepository } from './repositories/knex/KnexW4ChangeRequestRepository';
import { EssService } from './services/ess/EssService';
import { W4ChangeRequestService } from './services/ess/W4ChangeRequestService';
import { createJobQueue } from './config/jobQueue';
import type { JobQueue } from './queue/JobQueue';
import { QueuedBatchService } from './services/queue/QueuedBatchService';
import { JobWorkerService } from './services/queue/JobWorkerService';
import { KnexPayrollControlRepository } from './repositories/knex/KnexPayrollControlRepository';
import { ControlService } from './services/controls/ControlService';
import type { PayrollControlRepository } from './repositories/interfaces';
import { FilingExportService } from './services/filing/FilingExportService';
import { PluginHost } from './plugins/PluginHost';
import type { DeductionPlugin } from './plugins/PluginHost';

export interface AppDependencies {
  db: Knex;
  databaseRouter: DatabaseRouter;
  benefitEnrollmentRepository: BenefitEnrollmentRepository;
  garnishmentOrderRepository: GarnishmentOrderRepository;
  employeeRepository: EmployeeRepository;
  employeeWorkLocationRepository: EmployeeWorkLocationRepository;
  employeeWorkLocationService: EmployeeWorkLocationService;
  payPeriodRepository: PayPeriodRepository;
  payStubRepository: PayStubRepository;
  ytdRepository: YtdRepository;
  payrollRunRepository: PayrollRunRepository;
  timeEntryRepository: TimeEntryRepository;
  benefitEnrollmentService: BenefitEnrollmentService;
  garnishmentOrderService: GarnishmentOrderService;
  deductionPreviewService: DeductionPreviewService;
  deductionScheduleRepository: DeductionScheduleRepository;
  deductionScheduleService: DeductionScheduleService;
  employeeService: EmployeeService;
  payPeriodService: PayPeriodService;
  payrollRunService: PayrollRunService;
  timeEntryService: TimeEntryService;
  earningsPreviewService: EarningsPreviewService;
  retroAdjustmentService: RetroAdjustmentService;
  retroAdjustmentRepository: RetroAdjustmentRepository;
  payrollBatchRepository: PayrollBatchRepository;
  payrollRunFailureRepository: PayrollRunFailureRepository;
  employeePayrollReadinessRepository: EmployeePayrollReadinessRepository;
  payrollBatchService: PayrollBatchService;
  auditEventRepository: AuditEventRepository;
  auditService: AuditService;
  reportingService: ReportingService;
  payStubHtmlRenderer: PayStubHtmlRenderer;
  webhookSubscriptionRepository: WebhookSubscriptionRepository;
  webhookOutboxRepository: WebhookOutboxRepository;
  webhookDeliveryRepository: WebhookDeliveryRepository;
  webhookOutboxService: WebhookOutboxService;
  webhookDeliveryWorker: WebhookDeliveryWorker;
  webhookSubscriptionService: WebhookSubscriptionService;
  departmentRepository: DepartmentRepository;
  jobRepository: JobRepository;
  payrollRunAllocationRepository: PayrollRunAllocationRepository;
  departmentService: DepartmentService;
  jobService: JobService;
  laborCostAllocationService: LaborCostAllocationService;
  complianceReportingService: ComplianceReportingService;
  payPolicyRepository: PayPolicyRepository;
  payPolicyService: PayPolicyService;
  leavePolicyRepository: LeavePolicyRepository;
  leaveBalanceRepository: LeaveBalanceRepository;
  leaveTransactionRepository: LeaveTransactionRepository;
  leavePolicyService: LeavePolicyService;
  leaveAccrualService: LeaveAccrualService;
  leaveUsageService: LeaveUsageService;
  shiftRepository: ShiftRepository;
  shiftAssignmentRepository: ShiftAssignmentRepository;
  timeExceptionRepository: TimeExceptionRepository;
  schedulingService: SchedulingService;
  timeApprovalService: TimeApprovalService;
  enrollmentWindowRepository: EnrollmentWindowRepository;
  eligibilityRuleRepository: EligibilityRuleRepository;
  lifeEventRepository: LifeEventRepository;
  openEnrollmentService: OpenEnrollmentService;
  disbursementInstructionRepository: DisbursementInstructionRepository;
  disbursementBatchRepository: DisbursementBatchRepository;
  disbursementInstructionService: DisbursementInstructionService;
  paymentBatchService: PaymentBatchService;
  erpConnectorRepository: ErpConnectorRepository;
  erpExportService: ErpExportService;
  w4ChangeRequestRepository: W4ChangeRequestRepository;
  essService: EssService;
  w4ChangeRequestService: W4ChangeRequestService;
  jobQueue: JobQueue;
  queuedBatchService: QueuedBatchService;
  jobWorkerService: JobWorkerService;
  payrollControlRepository: PayrollControlRepository;
  controlService: ControlService;
  filingExportService: FilingExportService;
  pluginHost: PluginHost;
}

export function createAppDependencies(
  dbOverride?: Knex,
  routerOverride?: DatabaseRouter
): AppDependencies {
  const databaseRouter = routerOverride ?? getDatabaseRouter();
  const db = dbOverride ?? databaseRouter.writer;
  const readDb = databaseRouter.reader;
  const benefitEnrollmentRepository = new KnexBenefitEnrollmentRepository(db);
  const deductionScheduleRepository = new KnexDeductionScheduleRepository(db);
  const webhookSubscriptionRepository = new KnexWebhookSubscriptionRepository(
    db
  );
  const webhookOutboxRepository = new KnexWebhookOutboxRepository(db);
  const webhookDeliveryRepository = new KnexWebhookDeliveryRepository(db);
  const webhookOutboxService = new WebhookOutboxService(
    db,
    webhookSubscriptionRepository,
    webhookOutboxRepository
  );
  const webhookDeliveryWorker = new WebhookDeliveryWorker(
    db,
    webhookSubscriptionRepository,
    webhookOutboxRepository,
    webhookDeliveryRepository
  );
  const webhookSubscriptionService = new WebhookSubscriptionService(
    webhookSubscriptionRepository
  );
  const departmentRepository = new KnexDepartmentRepository(db);
  const jobRepository = new KnexJobRepository(db);
  const payrollRunAllocationRepository = new KnexPayrollRunAllocationRepository(
    db
  );
  const laborCostAllocationService = new LaborCostAllocationService(
    departmentRepository,
    jobRepository
  );
  const departmentService = new DepartmentService(departmentRepository);
  const jobService = new JobService(jobRepository, departmentRepository);
  const payPolicyRepository = new KnexPayPolicyRepository(db);
  const payPolicyService = new PayPolicyService(payPolicyRepository);
  const leavePolicyRepository = new KnexLeavePolicyRepository(db);
  const leaveBalanceRepository = new KnexLeaveBalanceRepository(db);
  const leaveTransactionRepository = new KnexLeaveTransactionRepository(db);
  const leavePolicyService = new LeavePolicyService(leavePolicyRepository);
  const garnishmentOrderRepository = new KnexGarnishmentOrderRepository(db);
  const employeeRepository = new KnexEmployeeRepository(db);
  const leaveAccrualService = new LeaveAccrualService(
    db,
    leavePolicyRepository,
    leaveBalanceRepository,
    leaveTransactionRepository,
    employeeRepository
  );
  const leaveUsageService = new LeaveUsageService(
    leavePolicyRepository,
    leaveBalanceRepository,
    leaveTransactionRepository
  );
  const employeeWorkLocationRepository = new KnexEmployeeWorkLocationRepository(
    db
  );
  const payPeriodRepository = new KnexPayPeriodRepository(db);
  const payStubRepository = new KnexPayStubRepository(db);
  const ytdRepository = new KnexYtdRepository(db);
  const payrollRunRepository = new KnexPayrollRunRepository(db);
  const timeEntryRepository = new KnexTimeEntryRepository(db);
  const shiftRepository = new KnexShiftRepository(db);
  const shiftAssignmentRepository = new KnexShiftAssignmentRepository(db);
  const timeExceptionRepository = new KnexTimeExceptionRepository(db);
  const schedulingService = new SchedulingService(
    shiftRepository,
    shiftAssignmentRepository
  );
  const timeApprovalService = new TimeApprovalService(
    shiftAssignmentRepository,
    shiftRepository,
    timeEntryRepository,
    timeExceptionRepository
  );

  const benefitEnrollmentService = new BenefitEnrollmentService(
    benefitEnrollmentRepository
  );
  const deductionPreviewService = new DeductionPreviewService(
    ytdRepository,
    undefined,
    undefined,
    benefitEnrollmentService,
    deductionScheduleRepository
  );
  const deductionScheduleService = new DeductionScheduleService(
    deductionScheduleRepository
  );
  const enrollmentWindowRepository = new KnexEnrollmentWindowRepository(db);
  const eligibilityRuleRepository = new KnexEligibilityRuleRepository(db);
  const lifeEventRepository = new KnexLifeEventRepository(db);
  const openEnrollmentService = new OpenEnrollmentService(
    enrollmentWindowRepository,
    eligibilityRuleRepository,
    lifeEventRepository,
    benefitEnrollmentService,
    deductionScheduleService
  );
  const disbursementInstructionRepository =
    new KnexDisbursementInstructionRepository(db);
  const disbursementBatchRepository = new KnexDisbursementBatchRepository(db);
  const disbursementInstructionService = new DisbursementInstructionService(
    disbursementInstructionRepository
  );
  const paymentBatchService = new PaymentBatchService(
    disbursementBatchRepository,
    disbursementInstructionRepository,
    webhookOutboxService
  );
  const employeeService = new EmployeeService(employeeRepository);
  const employeeWorkLocationService = new EmployeeWorkLocationService(
    employeeWorkLocationRepository
  );
  const payPeriodService = new PayPeriodService();
  const garnishmentOrderService = new GarnishmentOrderService(
    garnishmentOrderRepository
  );
  const payrollRunService = new PayrollRunService(
    db,
    ytdRepository,
    payStubRepository,
    payrollRunRepository,
    garnishmentOrderRepository,
    deductionScheduleRepository,
    webhookOutboxService,
    laborCostAllocationService,
    payrollRunAllocationRepository,
    payPolicyService,
    leaveUsageService,
    timeApprovalService
  );
  const timeEntryService = new TimeEntryService(timeEntryRepository);
  const earningsPreviewService = new EarningsPreviewService(
    payrollRunService,
    timeEntryService,
    timeApprovalService
  );
  const retroAdjustmentRepository = new KnexRetroAdjustmentRepository(db);
  const retroAdjustmentService = new RetroAdjustmentService(
    payrollRunService,
    payStubRepository,
    retroAdjustmentRepository,
    ytdRepository
  );
  const payrollBatchRepository = new KnexPayrollBatchRepository(db);
  const payrollRunFailureRepository = new KnexPayrollRunFailureRepository(db);
  const employeePayrollReadinessRepository =
    new KnexEmployeePayrollReadinessRepository(db);
  const auditEventRepository = new KnexAuditEventRepository(db);
  const auditService = new AuditService(auditEventRepository);
  const payrollControlRepository = new KnexPayrollControlRepository(db);
  const controlService = new ControlService(
    payrollControlRepository,
    payStubRepository,
    auditService
  );
  const payrollBatchService = new PayrollBatchService(
    payrollBatchRepository,
    payrollRunFailureRepository,
    employeePayrollReadinessRepository,
    employeeRepository,
    payrollRunService,
    webhookOutboxService,
    controlService
  );
  const reportingService = new ReportingService(
    readDb,
    payrollRunAllocationRepository
  );
  const complianceReportingService = new ComplianceReportingService(readDb);
  const payStubHtmlRenderer = new PayStubHtmlRenderer();
  const erpConnectorRepository = new KnexErpConnectorRepository(db);
  const erpExportService = new ErpExportService(
    erpConnectorRepository,
    reportingService,
    createDefaultConnectorRegistry()
  );
  const w4ChangeRequestRepository = new KnexW4ChangeRequestRepository(db);
  const essService = new EssService(
    employeeService,
    payStubRepository,
    ytdRepository,
    complianceReportingService
  );
  const w4ChangeRequestService = new W4ChangeRequestService(
    w4ChangeRequestRepository,
    employeeRepository,
    auditService
  );
  const jobQueue = createJobQueue(db);
  const queuedBatchService = new QueuedBatchService(
    payrollBatchRepository,
    employeePayrollReadinessRepository,
    jobQueue
  );
  const jobWorkerService = new JobWorkerService(
    jobQueue,
    payrollBatchRepository,
    payrollRunFailureRepository,
    employeePayrollReadinessRepository,
    employeeRepository,
    payPeriodRepository,
    payrollRunService,
    webhookOutboxService,
    webhookDeliveryWorker,
    controlService
  );
  const filingExportService = new FilingExportService(db);
  const pluginHost = new PluginHost();
  const demoPlugin: DeductionPlugin = {
    id: 'demo-flat-deduction',
    name: 'Demo flat deduction',
    async calculate(ctx) {
      if (ctx.companyId !== ctx.companyId) return null;
      return {
        code: 'demo_deduction',
        amount: '25.00',
        description: 'Sandbox plugin deduction',
      };
    },
  };
  pluginHost.register(demoPlugin);

  return {
    db,
    databaseRouter,
    benefitEnrollmentRepository,
    garnishmentOrderRepository,
    employeeRepository,
    employeeWorkLocationRepository,
    employeeWorkLocationService,
    payPeriodRepository,
    payStubRepository,
    ytdRepository,
    payrollRunRepository,
    timeEntryRepository,
    benefitEnrollmentService,
    garnishmentOrderService,
    deductionPreviewService,
    deductionScheduleRepository,
    deductionScheduleService,
    employeeService,
    payPeriodService,
    payrollRunService,
    timeEntryService,
    earningsPreviewService,
    retroAdjustmentService,
    retroAdjustmentRepository,
    payrollBatchRepository,
    payrollRunFailureRepository,
    employeePayrollReadinessRepository,
    payrollBatchService,
    auditEventRepository,
    auditService,
    reportingService,
    payStubHtmlRenderer,
    webhookSubscriptionRepository,
    webhookOutboxRepository,
    webhookDeliveryRepository,
    webhookOutboxService,
    webhookDeliveryWorker,
    webhookSubscriptionService,
    departmentRepository,
    jobRepository,
    payrollRunAllocationRepository,
    departmentService,
    jobService,
    laborCostAllocationService,
    complianceReportingService,
    payPolicyRepository,
    payPolicyService,
    leavePolicyRepository,
    leaveBalanceRepository,
    leaveTransactionRepository,
    leavePolicyService,
    leaveAccrualService,
    leaveUsageService,
    shiftRepository,
    shiftAssignmentRepository,
    timeExceptionRepository,
    schedulingService,
    timeApprovalService,
    enrollmentWindowRepository,
    eligibilityRuleRepository,
    lifeEventRepository,
    openEnrollmentService,
    disbursementInstructionRepository,
    disbursementBatchRepository,
    disbursementInstructionService,
    paymentBatchService,
    erpConnectorRepository,
    erpExportService,
    w4ChangeRequestRepository,
    essService,
    w4ChangeRequestService,
    jobQueue,
    queuedBatchService,
    jobWorkerService,
    payrollControlRepository,
    controlService,
    filingExportService,
    pluginHost,
  };
}

let cachedDeps: AppDependencies | null = null;

export async function getAppDependencies(): Promise<AppDependencies> {
  if (!cachedDeps) {
    defaultTaxYearService.validateAll();
    const db = getDb();
    await runMigrations(db);
    cachedDeps = createAppDependencies(db, getDatabaseRouter());
  }
  return cachedDeps;
}

export function resetCachedDependencies(): void {
  cachedDeps = null;
}
