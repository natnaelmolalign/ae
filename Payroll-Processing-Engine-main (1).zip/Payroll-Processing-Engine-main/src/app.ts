import 'dotenv/config';
import express, { type Express } from 'express';
import type { AppDependencies } from './deps';
import { errorHandler } from './middleware/errorHandler';
import { auth } from './middleware/auth';
import { rbac } from './middleware/rbac';
import { applySecurityMiddleware } from './middleware/security';
import { correlationIdMiddleware } from './middleware/correlationId';
import { rootLogger } from './logging/logger';
import { createEmployeesRouter } from './routes/employees';
import { createPayPeriodsRouter } from './routes/payperiods';
import { createPayrollRouter } from './routes/payroll';
import { createBenefitEnrollmentsRouter } from './routes/benefitEnrollments';
import { createGarnishmentOrdersRouter } from './routes/garnishmentOrders';
import { createDeductionsRouter } from './routes/deductions';
import { createDeductionSchedulesRouter } from './routes/deductionSchedules';
import { createAdjustmentsRouter } from './routes/adjustments';
import { createTimeEntriesRouter } from './routes/timeEntries';
import { createEarningsRouter } from './routes/earnings';
import { createReportsRouter } from './routes/reports';
import { createAdminRouter } from './routes/admin';
import { createAdminWebhooksRouter } from './routes/adminWebhooks';
import { createDepartmentsRouter } from './routes/departments';
import { createJobsRouter } from './routes/jobs';
import { createPayPoliciesRouter } from './routes/payPolicies';
import { createLeavePoliciesRouter } from './routes/leavePolicies';
import { createLeaveBalancesRouter } from './routes/leaveBalances';
import { createShiftsRouter } from './routes/shifts';
import { createEnrollmentWindowsRouter } from './routes/enrollmentWindows';
import { createEligibilityRulesRouter } from './routes/eligibilityRules';
import { createLifeEventsRouter } from './routes/lifeEvents';
import { createDisbursementInstructionsRouter } from './routes/disbursementInstructions';
import { createPaymentBatchesRouter } from './routes/paymentBatches';
import {
  createErpConnectionsRouter,
  createGlAccountMappingsRouter,
  createErpExportsRouter,
} from './routes/erpConnectors';
import { createEssRouter } from './routes/ess';
import { createW4ChangeRequestsRouter } from './routes/w4ChangeRequests';
import { createQueueAdminRouter } from './routes/queueAdmin';
import { createPayrollControlsRouter } from './routes/payrollControls';
import { createFilingRouter } from './routes/filing';
import { createMetricsRouter } from './routes/metrics';
import { checkPoolHealth } from './db/poolHealth';
import { features } from './config/features';

export function createApp(deps: AppDependencies): Express {
  const app = express();
  applySecurityMiddleware(app);
  app.use(express.json({ limit: process.env.JSON_BODY_LIMIT || '1mb' }));

  app.use(correlationIdMiddleware);

  app.get('/health', (_req, res) => {
    res.json({ status: 'ok', service: 'payroll-processing-engine' });
  });

  if (features.prometheusMetricsEnabled) {
    app.use('/metrics', createMetricsRouter());
  }

  app.use(auth);
  app.use(rbac);

  app.get('/ready', async (_req, res) => {
    try {
      await deps.db.raw('SELECT 1');
      const pool = checkPoolHealth(deps.db);
      if (!pool.healthy) {
        res.status(503).json({
          status: 'not_ready',
          database: 'pool_saturated',
          pool,
        });
        return;
      }
      res.json({
        status: 'ready',
        database: 'connected',
        readReplica: deps.databaseRouter.readReplicaConfigured,
        pool,
      });
    } catch (err) {
      rootLogger.error('ready.check.failed', {
        message: err instanceof Error ? err.message : String(err),
      });
      res.status(503).json({ status: 'not_ready', database: 'disconnected' });
    }
  });

  app.use('/api/employees', createEmployeesRouter(deps));
  app.use('/api/payperiods', createPayPeriodsRouter(deps));
  app.use('/api/payroll', createPayrollRouter(deps));
  app.use('/api/benefit-enrollments', createBenefitEnrollmentsRouter(deps));
  app.use('/api/garnishment-orders', createGarnishmentOrdersRouter(deps));
  app.use('/api/deductions', createDeductionsRouter(deps));
  app.use('/api/deduction-schedules', createDeductionSchedulesRouter(deps));
  app.use('/api/adjustments', createAdjustmentsRouter(deps));
  app.use('/api/time-entries', createTimeEntriesRouter(deps));
  app.use('/api/earnings', createEarningsRouter(deps));
  app.use('/api/reports', createReportsRouter(deps));
  app.use('/api/admin', createAdminRouter());
  app.use('/api/admin/webhooks', createAdminWebhooksRouter(deps));
  app.use('/api/departments', createDepartmentsRouter(deps));
  app.use('/api/jobs', createJobsRouter(deps));
  if (features.payPolicyEngineEnabled) {
    app.use('/api/pay-policies', createPayPoliciesRouter(deps));
  }
  if (features.leaveAccrualsEnabled) {
    app.use('/api/leave-policies', createLeavePoliciesRouter(deps));
    app.use('/api/leave-balances', createLeaveBalancesRouter(deps));
  }
  if (features.workforceSchedulingEnabled) {
    app.use('/api/shifts', createShiftsRouter(deps));
  }
  if (features.benefitsLifecycleEnabled) {
    app.use('/api/enrollment-windows', createEnrollmentWindowsRouter(deps));
    app.use('/api/eligibility-rules', createEligibilityRulesRouter(deps));
    app.use('/api/life-events', createLifeEventsRouter(deps));
  }
  if (features.disbursementsEnabled) {
    app.use(
      '/api/disbursement-instructions',
      createDisbursementInstructionsRouter(deps)
    );
    app.use('/api/payment-batches', createPaymentBatchesRouter(deps));
  }
  if (features.erpConnectorsEnabled) {
    app.use('/api/integration-connections', createErpConnectionsRouter(deps));
    app.use('/api/gl-account-mappings', createGlAccountMappingsRouter(deps));
    app.use('/api/erp-exports', createErpExportsRouter(deps));
  }
  if (features.employeeEssEnabled) {
    app.use('/api/ess', createEssRouter(deps));
    app.use('/api/w4-change-requests', createW4ChangeRequestsRouter(deps));
  }
  if (features.jobQueueEnabled) {
    app.use('/api/admin/queue', createQueueAdminRouter(deps));
  }
  if (features.payrollControlsEnabled) {
    app.use('/api/payroll-controls', createPayrollControlsRouter(deps));
  }
  if (features.filingPlatformEnabled) {
    app.use('/api/filing', createFilingRouter(deps));
  }

  app.use(errorHandler);
  return app;
}
