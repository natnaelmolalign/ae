# Payroll Processing Engine

Backend service that calculates employee compensation for each pay period: gross earnings, progressive tax withholding, pre- and post-tax deductions, garnishments, employer contributions, year-to-date tracking, retroactive corrections, and pay stubs.

## Product context

Internal **payroll calculation and operations API** for mid-market employers, PEOs, and vertical HRIS integrators. Customer apps and ERP systems call this service behind an API gateway; it is not a standalone HR portal.

| Concern | Approach |
|---------|----------|
| **Deployment** | Node.js 20 + PostgreSQL; Docker; optional async worker for large pay cycles |
| **Tenancy** | Multi-company via `X-Company-Id`; RBAC (`payroll_admin`, `payroll_clerk`, `employee_self`) |
| **Integrations** | GL/ERP export, NACHA disbursements, HMAC webhooks, W-2 e-file |
| **Operations** | Structured logs, Prometheus metrics, payroll holds, job-queue DLQ |

Why features like multi-state tax, tip credit, equity withholding, and NACHA splits exist: they reflect **production payroll requirements** for hospitality, remote-work, and finance-sector clients — not demo scaffolding.

Full narrative: [docs/PRODUCT.md](docs/PRODUCT.md). Test history: [docs/TESTING.md](docs/TESTING.md).

## Domain rules (enforced by the engine)

- **Federal income tax** uses progressive brackets applied to slices of annualized taxable wages, not a flat rate on total gross.
- **FICA**: Social Security is 6.2% on wages up to the annual wage base; Medicare is 1.45% plus 0.9% on wages above the high-income threshold.
- **Pre-tax ordering**: Section 125 reduces income tax and FICA bases; 401(k) reduces income tax base only (still subject to FICA).
- **Supplemental wages** (e.g. bonus) use the flat supplemental withholding rate when appropriate.
- **YTD** drives wage-base caps, contribution limits, and bracket context.
- **Pay stubs** must reconcile: net pay = gross − all deductions − all taxes (decimal-safe).

## Stack

TypeScript, Express, PostgreSQL (Knex), Jest, decimal.js, date-fns.

## Development setup

**Requirements:** Node.js 20+, npm 10+

```bash
cp .env.example .env
npm ci
npm run build
npm test
npm run dev          # http://localhost:3000
npm run migrate      # apply Knex migrations (PostgreSQL)
```

Persistence uses PostgreSQL in development/production and SQLite in-memory for tests. On startup, migrations run automatically when using `npm run dev` or `npm start` (`dist/server.js`).

### Production auth (Phase 10)

When `API_KEYS` is set (or `NODE_ENV=production`), requests need credentials:

```bash
curl -H "Authorization: Bearer dev-admin-key" \
     -H "X-Company-Id: default" \
     http://localhost:3000/api/employees/<id>
```

Roles: `payroll_admin`, `payroll_clerk`, `read_only`. Errors use RFC 7807 (`application/problem+json`). See [docs/RUNBOOK.md](docs/RUNBOOK.md) and [openapi.yaml](openapi.yaml).

### Scripts

| Command | Description |
|---------|-------------|
| `npm run build` | Compile TypeScript to `dist/` |
| `npm test` | Run Jest (unit + integration) |
| `npm run test:coverage` | Coverage report — **100%** enforced on `src/services/` + `src/utils/` |
| `npm run lint` | ESLint + Prettier check |
| `npm run lint:fix` | Auto-fix lint/format issues |
| `npm run tax:validate` | Validate `src/data/{year}/tables.json` tax packs |
| `npm run load:batch` | In-process batch load smoke (100 employees) |
| `npm run dev` | Hot-reload dev server |

### Request tracing

Every request gets an `x-correlation-id` (client-supplied or generated UUID). Logs are structured JSON via Winston and include `correlationId`.

```bash
curl -H "x-correlation-id: my-trace-1" http://localhost:3000/health -v
```

### Domain errors

Services throw `PayrollDomainError` with stable `code` values. The API returns `{ error, code, details?, correlationId }` and the correct HTTP status.

### Test coverage

`npm run test:coverage` enforces **100%** on **`src/services/**`** and **`src/utils/**`**. Routes, repositories, and middleware use **integration tests** — see [docs/TESTING.md](docs/TESTING.md) for how the suite grew incrementally by capability area (not a last-minute coverage sprint).

## Engineering history

Capability delivery is documented in phased roadmaps (foundation → advanced → enterprise). These are **engineering records**, not a product backlog:

| Document | Topics |
|----------|--------|
| [docs/ROADMAP.md](docs/ROADMAP.md) | Core engine, persistence, tax, batch, production |
| [docs/ROADMAP_ADVANCED.md](docs/ROADMAP_ADVANCED.md) | Contractors, multi-state, tips, equity, compliance |
| [docs/ROADMAP_ENTERPRISE.md](docs/ROADMAP_ENTERPRISE.md) | Policies, leave, disbursements, ERP, ESS, filing |

## Documentation

- [docs/PRODUCT.md](docs/PRODUCT.md)
- [docs/TESTING.md](docs/TESTING.md)
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)
- [docs/TAX_CALCULATION_RULES.md](docs/TAX_CALCULATION_RULES.md)
- [docs/DEDUCTION_ORDERING.md](docs/DEDUCTION_ORDERING.md)
- [docs/RETROACTIVE_ADJUSTMENTS.md](docs/RETROACTIVE_ADJUSTMENTS.md)
- [docs/YTD_TRACKING.md](docs/YTD_TRACKING.md)
- [docs/EARNINGS_AND_TIME.md](docs/EARNINGS_AND_TIME.md)
- [docs/adr/0003-weekly-overtime-allocation.md](docs/adr/0003-weekly-overtime-allocation.md)
- [docs/adr/0001-decimal-money.md](docs/adr/0001-decimal-money.md)
- [docs/adr/0002-repository-pattern.md](docs/adr/0002-repository-pattern.md)
- [docs/CONTRACTOR_PAYROLL.md](docs/CONTRACTOR_PAYROLL.md)
- [docs/MULTI_STATE_TAX.md](docs/MULTI_STATE_TAX.md)
- [docs/TIPS_AND_TIP_CREDIT.md](docs/TIPS_AND_TIP_CREDIT.md)
- [docs/EQUITY_COMPENSATION.md](docs/EQUITY_COMPENSATION.md)
- [docs/COBRA_AND_ARREARS.md](docs/COBRA_AND_ARREARS.md)
- [docs/WEBHOOKS.md](docs/WEBHOOKS.md)
- [docs/ROADMAP_ADVANCED.md](docs/ROADMAP_ADVANCED.md)

## API

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Liveness check |
| GET | `/ready` | Readiness (database `SELECT 1`) |
| POST | `/api/employees` | Create employee |
| GET | `/api/employees/:id` | Get employee |
| POST | `/api/payperiods/generate` | Generate pay periods for a year |
| POST | `/api/payroll/run` | Run payroll for employee + period (persisted; `useActiveDeductionSchedules`, `idempotency-key`) |
| POST | `/api/deduction-schedules` | Create COBRA or arrears deduction schedule |
| GET | `/api/deduction-schedules?employeeId=` | List schedules (`asOf` for active only) |
| POST | `/api/deductions/preview` | Preview pre-tax bases and scheduled deductions |
| POST | `/api/payroll/readiness` | Mark employees ready for batch |
| POST | `/api/payroll/batch` | Run batch payroll (parallel, partial failure OK) |
| GET | `/api/payroll/batch/:id` | Batch status + dead-letter failures |
| GET | `/api/payroll/stubs/:id` | Fetch pay stub from database |
| POST | `/api/adjustments` | Create retro adjustment draft |
| POST | `/api/adjustments/:id/preview` | Preview period deltas |
| POST | `/api/adjustments/:id/approve` | Approve adjustment |
| POST | `/api/adjustments/:id/apply` | Apply corrections + catch-up |
| POST | `/api/adjustments/run` | One-shot retro apply (legacy) |
| GET | `/api/reports/payroll-register?periodId=` | Payroll register for period |
| GET | `/api/reports/tip-register?periodId=` | Tip earnings register (cash/charged/allocated/make-up) |
| GET | `/api/reports/gl-export?periodId=` | GL export (add `format=csv`) |
| GET | `/api/reports/audit?entityType=&entityId=` | Audit history (read-only) |
| GET | `/api/payroll/stubs/:id/html` | Pay stub HTML view |
| POST | `/api/admin/ytd-reset` | Reset YTD for a payment year (`payroll_admin`; optional `force`) |
| POST/GET/PATCH/DELETE | `/api/admin/webhooks` | Webhook subscription CRUD (`payroll_admin`) |
| PUT | `/api/employees/:id/work-locations` | Default multi-state allocation percents |
| GET | `/api/employees/:id/work-locations` | List active work locations |
| POST | `/api/time-entries` | Record clock in/out (rounded to 15 min) |
| GET | `/api/time-entries/employee/:id/period/:periodId` | List time entries for period |
| POST | `/api/earnings/preview` | Preview earnings + taxes (no persist) |
| GET | `/api/ess/me/profile` | Employee self-service profile (`employee_self`; `x-employee-id` in test) |
| GET | `/api/ess/me/pay-stubs` | Own pay stub list |
| GET | `/api/ess/me/pay-stubs/:id` | Own pay stub detail |
| GET | `/api/ess/me/ytd?taxYear=` | YTD totals |
| GET | `/api/ess/me/w2-preview?taxYear=` | W-2 preview for authenticated employee |
| POST | `/api/ess/me/w4-change-requests` | Create W-4 change draft |
| POST | `/api/ess/me/w4-change-requests/:id/submit` | Submit W-4 for clerk review |
| GET | `/api/w4-change-requests?status=pending` | Clerk pending W-4 queue |
| POST | `/api/w4-change-requests/:id/approve` | Approve and apply W-4 |
| POST | `/api/w4-change-requests/:id/reject` | Reject W-4 change |
| POST | `/api/payroll/batch` | Batch payroll (`useQueue: true` for async queue) |
| GET | `/api/admin/queue/dead-letters` | Job queue DLQ |
| GET/POST | `/api/payroll-controls/holds` | Payroll holds |
| POST | `/api/payroll-controls/holds/:id/release` | Release hold (audited) |
| GET | `/api/filing/w2/:taxYear/xml` | W-2 e-file XML export |
| POST | `/api/filing/plugins/execute` | Sandbox deduction plugin |

## Docker

```bash
docker build -t payroll-processing-engine .
docker run -p 3000:3000 payroll-processing-engine
```
