# Batch Payroll

Run payroll for many employees with bounded parallelism, per-employee idempotency, and isolated failures.

## Flow

1. Mark employees **ready** for a pay period: `POST /api/payroll/readiness`
2. Start batch: `POST /api/payroll/batch` (uses ready employees unless `employeeIds` is provided)
3. Poll status: `GET /api/payroll/batch/:id`

## Batch status

| Status | Meaning |
|--------|---------|
| `pending` | Created, not started |
| `running` | Workers processing employees |
| `completed` | Finished (may include partial failures) |
| `failed` | No successful runs |

## Concurrency & YTD

- Workers use `runWithConcurrencyLimit` (default 4).
- Each payroll run locks its own `ytd_totals` row with `FOR UPDATE` inside a transaction (PostgreSQL).
- Different employees do not share YTD rows, so parallel runs do not drift.

## Idempotency

Each batch employee run uses `idempotency-key` = `batch-{batchId}-{employeeId}`. Re-running the same batch item returns the original stub without duplicating YTD.

## Dead-letter queue

Failed employees are stored in `payroll_run_failures` with `retryable` and error details. Successful employees remain committed.

## Scheduler

`runScheduledPayroll({ year, payPeriodId, frequency })` in `src/jobs/payrollRunJob.ts` processes only `employee_payroll_readiness.status = ready`.

## Metrics

`getPayrollMetrics().recordBatchComplete(durationMs, success, failure, labels)` — use `InMemoryPayrollMetrics` in tests.

## Load test

```bash
npm run build
npm run load:batch
```

See `scripts/load-batch.ts` (100 employees, wall-clock under 30s locally).
