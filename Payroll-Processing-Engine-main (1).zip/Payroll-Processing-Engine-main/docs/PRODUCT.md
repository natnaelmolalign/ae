# Product context

## What this is

The Payroll Processing Engine is an **internal calculation and operations API** for running US payroll: gross-to-net for W-2 employees and 1099 contractors, tax withholding, benefits and garnishments, pay stubs, compliance exports, and disbursement files.

It is **not** a full HRIS or time-clock product. It sits behind customer-facing apps and ERP integrations, focused on **correct money math**, **auditability**, and **batch scale**.

## Who uses it

| Consumer | How they interact |
|----------|-------------------|
| **Payroll operations** (`payroll_admin`, `payroll_clerk`) | Run and review pay cycles, holds, W-4 approvals, compliance exports |
| **Employee self-service** (`employee_self`) | View stubs, YTD, W-2 preview; submit W-4 changes |
| **Integrations** (ERP, GL, banking) | Pull GL journals, NACHA batches, webhook events |
| **Platform engineering** | Operate workers, queues, metrics, and filing plugins |

Typical deployment customers: **mid-market employers**, **professional employer organizations (PEOs)**, and **vertical SaaS** vendors (hospitality, healthcare, logistics) that need payroll depth without building tax engines in-house.

## Deployment model

```
[HR / ESS apps] ──► [API gateway + auth] ──► [Payroll API :3000]
                                              │
                    ┌─────────────────────────┼─────────────────────────┐
                    ▼                         ▼                         ▼
              PostgreSQL                 Job worker                 Webhook delivery
           (employees, stubs,          (async batch runs)          (HMAC outbox)
            YTD, audit)
```

- **Runtime:** Node.js 20, Docker image from repo `Dockerfile`
- **Data:** PostgreSQL in production; SQLite in-memory for automated tests
- **Auth:** API keys or JWT; every request scoped by `X-Company-Id` (multi-tenant)
- **Async:** Optional Knex-backed job queue + `worker` process for large pay cycles
- **Observability:** Structured JSON logs (`correlationId`), Prometheus `/metrics`

See [RUNBOOK.md](./RUNBOOK.md) for environment variables, rotation, and incident response.

## Why the capability areas exist

Features map to **real payroll operations**, not a generic CRUD checklist:

| Area | Business driver |
|------|-----------------|
| **Multi-state tax** | Remote workers with earnings in multiple jurisdictions |
| **Tips & tip credit** | Hospitality employers subject to FLSA make-up rules |
| **Equity (RSU/NQSO)** | Tech and finance clients with supplemental withholding elections |
| **COBRA & arrears** | Post-termination premium billing and deduction recovery |
| **Batch + queue** | 500–5,000 employee pay cycles without blocking HTTP |
| **Pay policies** | Customer-specific rules (max gross, required earnings types) before calculation |
| **Leave accruals** | PTO/sick balances deducted on paid time-off earnings |
| **Workforce scheduling** | Approved shift time gates what flows into hourly earnings |
| **Benefits lifecycle** | Open enrollment windows and qualifying life events |
| **Disbursements / NACHA** | Split net pay across direct-deposit accounts |
| **ERP connectors** | GL journal export to NetSuite / QuickBooks-style systems |
| **ESS + W-4 workflow** | Employees change withholding; clerks approve before next run |
| **Payroll controls** | Holds and anomaly gates before pay is released |
| **Filing platform** | W-2 XML and sandboxed deduction plugins for jurisdiction packs |

Roadmaps in [ROADMAP.md](./ROADMAP.md), [ROADMAP_ADVANCED.md](./ROADMAP_ADVANCED.md), and [ROADMAP_ENTERPRISE.md](./ROADMAP_ENTERPRISE.md) record **how** each area was delivered (migrations, services, APIs, exit gates). They are engineering history, not a product marketing checklist.

## Compliance posture

- Money: `decimal.js` throughout; ADR [0001](./adr/0001-decimal-money.md)
- Audit: immutable event log on pay-affecting mutations — [AUDIT.md](./AUDIT.md)
- Security: production auth enforced; TIN vault; checklist in [SECURITY_CHECKLIST.md](./SECURITY_CHECKLIST.md)
- Tax data: versioned annual packs validated in CI (`npm run tax:validate`)
