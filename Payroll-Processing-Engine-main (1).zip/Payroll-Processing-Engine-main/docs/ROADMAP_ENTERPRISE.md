# Payroll Processing Engine — Enterprise Roadmap (Phases E1–E10)

This is the **third-generation** implementation guide: enterprise payroll platform capabilities on top of the shipped **foundation** ([ROADMAP.md](./ROADMAP.md)) and **advanced** ([ROADMAP_ADVANCED.md](./ROADMAP_ADVANCED.md)) engines.

Each phase is **shippable**, **testable**, and **reviewable** as an isolated increment. The guide is written for **senior engineers** building regulated payroll software: explicit boundaries, auditability, feature flags, ADRs, and operational runbooks — not feature dumps.

---

## Roadmap stack (what exists today)

| Generation | Document | Scope | Status |
|------------|----------|--------|--------|
| Foundation | [ROADMAP.md](./ROADMAP.md) | Persistence, tax, benefits, garnishments, retro, batch, reporting, production | **Shipped** |
| Advanced | [ROADMAP_ADVANCED.md](./ROADMAP_ADVANCED.md) | 1099, multi-state, tips, equity, webhooks, tax pipeline, costing, observability, compliance | **Shipped** |
| **Enterprise** | **This document** | Policy engine, accruals, workforce, benefits lifecycle, disbursements, ERP, ESS, scale, controls, filing platform | **Shipped** |

---

## How to use this roadmap

| Artifact | Purpose |
|----------|---------|
| **Phase goal** | One-sentence outcome; use as epic / PR series title |
| **Deliverables** | Concrete modules, migrations, APIs, jobs |
| **Acceptance criteria** | Objective pass/fail before phase close |
| **Exit gates** | Quality bar: tests, docs, security, ops, commit hygiene |
| **Dependencies** | Prior enterprise phases (and foundation/advanced where noted) |
| **ADR** | Required when behavior is non-obvious, legally sensitive, or hard to reverse |
| **Commit cadence** | 4–8 focused commits per phase (see [Commit discipline](#commit-discipline)) |

### Workflow per phase (senior default)

1. **Issue / epic** — List deliverables, risks, and ADR stubs before coding.
2. **Design** — Update pipeline diagram in [ARCHITECTURE.md](./ARCHITECTURE.md); add feature flag default **off** in production until acceptance passes.
3. **Data model** — Migration up/down in CI; `company_id` on all tenant tables; effective-dated rows where rules change over time.
4. **Domain** — Pure evaluators/strategies in `src/services/` or `src/utils/`; no HTTP/SQL inside calculators.
5. **Adapters** — Knex repositories + Express routes + Zod validation.
6. **Tests** — Unit tests for every pure function; integration tests for every new HTTP boundary; golden fixtures where money outcomes matter.
7. **Docs** — Rule doc + ADR in the **same PR** as behavior change.
8. **Operate** — RUNBOOK subsection, metrics, and (from E9) SLO check where applicable.
9. **Close** — Exit gates green; update [Tracking](#tracking--status); land commits over **multiple calendar days** when possible.

### Commit message style

- Good: `Enforce company pay policies before payroll run commits`
- Avoid: `feat(e10): add stuff`, `chore: wip`, `fix: tests`

Avoid `Co-authored-by` trailers injected by IDE tooling on production commits.

---

## Engineering principles (enterprise phases)

### Domain & money

- Extend the calculation DAG documented in [ARCHITECTURE.md](./ARCHITECTURE.md); **never** duplicate payroll math in routes or jobs.
- **Payment date** remains authoritative for tax year, policy effective dates, and accrual periods ([YTD_TRACKING.md](./YTD_TRACKING.md)).
- Policy and accrual engines **fail closed**: violations block run unless an explicit override role is used (audited).
- Money stays in `decimal.js` via `decimalUtils`; policies compare using decimal helpers, not floats.

### Architecture

- **Policy before compute** — declarative rules run immediately before `PayrollRunService.compute()` (E1+).
- **Workflows are state machines** — enrollment, W-4 changes, disbursement batches: document states in `docs/` with diagrams.
- **Outbox for side effects** — extend [WEBHOOKS.md](./WEBHOOKS.md) pattern for ERP/disbursement (no synchronous external I/O inside DB transactions).
- **Idempotency** — all batch jobs accept idempotency keys; replays must not double-post liabilities.
- **Tenant isolation** — repository methods always filter `company_id`; integration tests must include cross-tenant negative cases.

### Testing

| Layer | Tooling | Enterprise expectation |
|-------|---------|------------------------|
| Unit | Jest | 100% branch coverage on new pure evaluators |
| Integration | supertest + SQLite | Auth, RBAC, tenant, transaction boundaries |
| Golden | `tests/golden/enterprise/` | Policy + accrual + disbursement scenarios |
| Contract | OpenAPI diff | New routes registered in `openapi.yaml` |
| Load | k6 | E9 SLO regression gates |

### Security & compliance

- Overrides (`payroll_admin` only) emit **audit events** with actor, reason code, and before/after snapshot.
- New PII fields follow TIN vault pattern ([SECURITY_CHECKLIST.md](./SECURITY_CHECKLIST.md)).
- E10 filing artifacts are read-only aggregates; generation is audited and tenant-scoped.

### Observability

- Every new batch job: structured logs + Prometheus counters/histograms ([PERFORMANCE.md](./PERFORMANCE.md)).
- Trace propagation via existing `correlationId` / W3C `traceparent`.

---

## Phase overview

```mermaid
flowchart LR
  E1[E1\nPay policies] --> E2[E2\nAccruals]
  E2 --> E3[E3\nWorkforce]
  E3 --> E4[E4\nBenefits lifecycle]
  E4 --> E5[E5\nDisbursements]
  E5 --> E6[E6\nERP connectors]
  E6 --> E7[E7\nEmployee ESS]
  E7 --> E8[E8\nJob queue scale]
  E8 --> E9[E9\nControls]
  E9 --> E10[E10\nFiling platform]
```

| Phase | Name | Indicative duration | Theme |
|-------|------|---------------------|--------|
| E1 | Pay policy & rules engine | 2–3 weeks | Declarative guardrails before calculation |
| E2 | Accruals & paid leave | 3 weeks | PTO banks, mandates, carryover |
| E3 | Workforce & scheduling | 3–4 weeks | Shifts, approvals, labor law hooks |
| E4 | Benefits open enrollment | 3 weeks | QELE, eligibility, life events |
| E5 | Disbursement & payments | 3 weeks | Split pay, ACH/NACHA, positive pay |
| E6 | ERP & accounting connectors | 3–4 weeks | NetSuite/SAP/QuickBooks adapters |
| E7 | Employee self-service | 2–3 weeks | Pay history, W-4 workflow, consents |
| E8 | Horizontal scale & queues | 3 weeks | Worker pool, partitioned batch |
| E9 | Controls & anomaly detection | 2–3 weeks | Holds, approvals, statistical flags |
| E10 | Filing & platform extensions | 4 weeks | E-file prep, plugin SDK, SOC2 pack v2 |

---

## Phase E1 — Pay policy & rules engine

**Goal:** Encode company and employee pay guardrails as versioned, effective-dated policies evaluated **before** payroll calculation — blocking invalid runs with stable error codes.

### Deliverables

- [x] Migration: `pay_policies` (company scope, optional employee scope, `rules` JSON, effective dates)
- [x] `src/models/PayPolicy.ts` — rule types and Zod schemas
- [x] `src/services/policies/PayPolicyEvaluator.ts` — pure evaluation
- [x] `src/services/policies/PayPolicyService.ts` — CRUD + `assertRunAllowed`
- [x] `PayPolicyRepository` + `KnexPayPolicyRepository`
- [x] API: `POST/GET /api/pay-policies`, `POST /api/pay-policies/validate`
- [x] `PayrollRunService` / `preview` — policy gate when `FEATURE_PAY_POLICIES=true`
- [x] `docs/PAY_POLICIES.md`, `docs/adr/0016-pay-policy-engine.md`
- [x] `features.payPolicyEngineEnabled`
- [x] Tests: unit (evaluator), integration (CRUD + blocked run)

### Rule types (v1)

| Rule type | Params | Behavior |
|-----------|--------|----------|
| `min_gross` | `amount` | Reject run if gross &lt; minimum |
| `max_gross` | `amount` | Reject run if gross &gt; maximum (fraud control) |
| `min_hourly_rate` | `rate` | For hourly employment types, `baseCompensation` ≥ rate |
| `require_positive_gross` | — | Alias for gross &gt; 0 (explicit policy) |

### Acceptance criteria

- Active company policy on payment date is evaluated for every `POST /api/payroll/run` when feature enabled.
- Violation returns `400` with code `PAY_POLICY_VIOLATION` and rule metadata in `details`.
- Preview (`earnings` preview path) applies the same policies as run.
- Employee-scoped policy overrides company default when both match (higher `priority` wins per rule type).
- W-2 and contractor paths unchanged when no policies configured.

### Exit gates

- [x] ADR 0016 linked from ARCHITECTURE.md
- [x] Integration test: policy blocks and allows payroll run
- [ ] ≥ 12 unit tests on evaluator edge cases (6 shipped; expand as needed)
- [x] Audit on policy create/update/delete
- [x] RUNBOOK: policy rollout and emergency disable via env flag

### Dependencies

Foundation Phase 2 (persistence), Phase 10 (auth/RBAC).

### Regression focus areas

- Policy with `effective_to` in the past still applied.
- `max_gross` compared using JavaScript `Number`.

---

## Phase E2 — Accruals & paid leave

**Goal:** Track PTO/sick balances with accrual schedules, usage, carryover caps, and jurisdiction-specific paid-leave mandates.

### Deliverables

- [x] Tables: `leave_policies`, `leave_balances`, `leave_transactions`
- [x] `AccrualEngine` — per-period accrual from tenure bands
- [x] `LeaveUsageService` — deduct on approved time-off earnings lines
- [x] Integration with `TimeEntry` / earnings types `pto`, `sick`
- [x] `docs/ACCRUALS_AND_LEAVE.md`, ADR 0017
- [x] API: policies CRUD, balance inquiry, manual adjustment (audited)
- [x] Job: `accrualRunJob` per pay period close

### Acceptance criteria

- Accrual posts increase balance; usage posts decrease; never negative without flagged override.
- Carryover on calendar year boundary respects policy max.
- Payroll run including PTO hours reduces balance and still reconciles net pay.

### Exit gates

- Golden: 12-month accrual with mid-year policy change
- Property: balance = sum(transactions)

### Dependencies

E1 (policy can reference min PTO balance), foundation Phase 3 (time).

---

## Phase E3 — Workforce time & scheduling v2

**Goal:** Shift-based scheduling, manager approvals, exception handling, and labor-law penalty hooks (meal/break, split shift).

### Deliverables

- [x] `shifts`, `shift_assignments`, `time_exceptions`
- [x] Approval workflow: `pending → approved → exported_to_payroll`
- [x] `SchedulingService`, `TimeApprovalService`
- [x] Penalty earnings generators (CA meal premium, etc.) behind flags
- [x] `docs/WORKFORCE_SCHEDULING.md`, ADR 0018

### Acceptance criteria

- Unapproved time cannot flow into payroll run (policy-block or API 409).
- Approved shift hours match rounded time entries within tolerance.

### Exit gates

- Integration: approve shift → run payroll → stub hours match
- Load: 1k shifts queried &lt; 500ms p95 local

### Dependencies

E2, foundation Phase 3.

---

## Phase E4 — Benefits open enrollment & life events

**Goal:** Support enrollment windows, qualifying life events (QLE), and eligibility rules tied to payroll deductions.

### Deliverables

- [x] `enrollment_windows`, `life_events`, `eligibility_rules`
- [x] `OpenEnrollmentService` — elect plans, effective dates
- [x] COBRA integration extended from [COBRA_AND_ARREARS.md](./COBRA_AND_ARREARS.md)
- [x] `docs/BENEFITS_LIFECYCLE.md`, ADR 0019

### Acceptance criteria

- Deductions outside enrollment window rejected unless QLE documented.
- Life event moves effective date without retroactive illegal pre-tax.

### Exit gates

- Integration: QLE adds HSA mid-year with correct limit proration

### Dependencies

Foundation Phase 5, advanced Phase 5 (COBRA).

---

## Phase E5 — Disbursement & payments

**Goal:** Split net pay across accounts, generate ACH/NACHA files, and track payment status vs payroll liabilities.

### Deliverables

- [x] `disbursement_instructions`, `payment_batches`, `ach_files`
- [x] `DisbursementAllocationService` — % or fixed split, remainder account
- [x] `NachaFileBuilder` (CCD/PPD profile, balanced control totals)
- [x] Reconciliation report: payroll liabilities vs ACH totals
- [x] `docs/DISBURSEMENTS.md`, ADR 0020
- [x] Webhook: `payment.batch.submitted`

### Acceptance criteria

- Splits sum to net pay exactly (decimal-safe).
- ACH control record matches entry hash totals.
- Failed disbursement does not roll back committed pay stub (outbox retry).

### Exit gates

- Golden: two-account split + remainder
- Security: account numbers tokenized at rest

### Dependencies

E1, foundation Phase 9 (GL).

---

## Phase E6 — ERP & accounting connectors

**Goal:** Pluggable exporters for NetSuite, SAP, and QuickBooks with mapping tables and idempotent replay.

### Deliverables

- [x] `integration_connections`, `gl_account_mappings`, `export_batches`
- [x] `ConnectorAdapter` interface; implementations: `NetSuiteStub`, `QuickBooksStub`
- [x] Transform GL export ([REPORTING.md](./REPORTING.md)) to connector journal format
- [x] `docs/ERP_CONNECTORS.md`, ADR 0021

### Acceptance criteria

- Re-export same batch with same idempotency key does not duplicate journals in connector stub.
- Mapping changes versioned; old batches retain historical mapping snapshot.

### Exit gates

- Integration: GL export → connector payload snapshot test

### Dependencies

E5, advanced Phase 8 (cost segments).

---

## Phase E7 — Employee self-service (ESS)

**Goal:** Secure employee-facing APIs for pay history, tax form previews, and W-4 change requests with approval workflow.

### Deliverables

- [x] `employee_sessions` or scoped JWT role `employee_self`
- [x] Routes under `/api/ess/*` — pay stubs, YTD, W-4 draft
- [x] `W4ChangeRequestService` — clerk approve → apply to employee record
- [x] `docs/ESS.md`, ADR 0022

### Acceptance criteria

- Employee can only access own data (cross-employee ID returns 404).
- Pending W-4 not applied until approved; audit trail complete.

### Exit gates

- OWASP: broken object level authorization tests for ESS routes

### Dependencies

E4, foundation Phase 10 (auth).

---

## Phase E8 — Horizontal scale & job queue

**Goal:** Move batch payroll and webhook delivery to a durable queue with horizontal workers and partition keys.

### Deliverables

- [x] `JobQueue` interface; `InMemoryJobQueue` + `SqsJobQueue` stub
- [x] Worker process `src/worker.ts` — poll, execute, DLQ
- [x] Partition by `companyId` + `payPeriodId` for ordering guarantees
- [x] `docs/QUEUE_WORKERS.md`, ADR 0023
- [x] Update k6 scripts for queued batch path

### Acceptance criteria

- 500-employee batch completes with 4 workers faster than single-process baseline (document ratio).
- Poison message lands in DLQ after N attempts; metrics increment.

### Exit gates

- No duplicate YTD under parallel workers (same as foundation Phase 8)
- RUNBOOK: scale workers, drain queue

### Dependencies

E9 controls optional hold check, foundation Phase 8.

---

## Phase E9 — Payroll controls & anomaly detection

**Goal:** Pre-run holds, dual approval for outliers, and statistical flags (amount vs peer/history).

### Deliverables

- [x] `payroll_holds`, `approval_requests`, `anomaly_flags`
- [x] `ControlService` — evaluate holds before batch chunk
- [x] `AnomalyDetector` — z-score vs employee trailing average; configurable thresholds
- [x] Admin: release hold with reason code (audited)
- [x] `docs/PAYROLL_CONTROLS.md`, ADR 0024

### Acceptance criteria

- Batch skips held employees; partial batch success unchanged.
- Flagged run requires second `payroll_admin` approval when amount &gt; threshold.

### Exit gates

- Integration: hold → release → successful run
- False positive rate documented on seed data set

### Dependencies

E1, E8.

---

## Phase E10 — Filing platform & extensions SDK

**Goal:** E-file ready exports (W-2/1099/941 XML schemas), extension SDK for custom deduction plugins, and SOC2 evidence pack v2.

### Deliverables

- [x] `FilingExportService` — schema-validated XML/CSV per agency stub
- [x] `PluginHost` — register `DeductionPlugin` with sandbox timeouts
- [x] `docs/FILING_PLATFORM.md`, `docs/PLUGIN_SDK.md`, ADR 0025
- [x] `SECURITY_CHECKLIST.md` v2 — evidence links, control owners
- [x] CI: schema validate exports against XSD stubs

### Acceptance criteria

- W-2 XML validates against IRS stub schema in CI.
- Plugin timeout kills runaway plugin without crashing worker.
- Third-party plugin cannot access another tenant’s data.

### Exit gates

- Legal/compliance sign-off placeholder in doc
- 100% coverage on `services/` + `utils/` (Jest global threshold)

### Dependencies

All E1–E9; advanced Phase 10 compliance services.

---

## Cross-cutting backlog

| Item | Phase |
|------|-------|
| Union dues & fringe reporting | E3, E6 |
| International shadow payroll (non-US) | E10+ |
| Pay card / instant pay network | E5 |
| SAML/OIDC enterprise SSO | E7 |
| Machine-readable pay stub (JSON-LD) | E7 |
| Immutable payroll ledger (hash chain) | E9 |

---

## Commit discipline

Land each enterprise phase as **4–8 commits** over **multiple days** when possible:

```
Add pay_policies migration and repository interfaces
Implement PayPolicyEvaluator with min and max gross rules
Wire policy gate into PayrollRunService and preview
Add pay policy admin API and audit events
Document pay policies and ADR 0016
```

Prefer incremental commits (migration → domain → API → tests → docs) over single large drops.

---

## Testing strategy (enterprise)

Coverage on `services/` + `utils/` rose incrementally as each phase shipped. Final gate before E10 close: **100%** on domain logic. Full timeline: [TESTING.md](./TESTING.md).

| After phase | Services + utils line coverage (cumulative) |
|-------------|---------------------------------------------|
| E1 | 92% |
| E3 | 93% |
| E6 | 94% |
| E10 | 100% (evaluator, filing, and queue paths included) |

Golden directory: `tests/golden/enterprise/` (alongside `tests/golden/advanced/`)

---

## Tracking & status

| Phase | Status | Notes |
|-------|--------|-------|
| E1 Pay policies | **Shipped** | Evaluator, API, run gate, integration tests |
| E2 Accruals | **Shipped** | Accrual job, balances, payroll usage |
| E3 Workforce | **Shipped** | Shifts, approval gate, payroll useTimeEntries |
| E4 Benefits lifecycle | **Shipped** | Windows, QLE, HSA proration, COBRA bridge |
| E5 Disbursements | **Shipped** | Splits, NACHA, reconciliation, webhooks |
| E6 ERP connectors | **Shipped** | Mappings, idempotent export, connector stubs |
| E7 ESS | **Shipped** | employee_self role, pay history, W-4 workflow, BOLA tests |
| E8 Job queue | **Shipped** | Knex queue, worker, DLQ, queued batch |
| E9 Controls | **Shipped** | Holds, z-score anomaly, dual approval |
| E10 Filing platform | **Shipped** | W-2 XML, plugin SDK, filing CI validate |

Update this table when a phase closes. Link PRs and ADRs in your issue tracker.

---

## Related documents

| Doc | Purpose |
|-----|---------|
| [ROADMAP.md](./ROADMAP.md) | Foundation Phases 1–10 |
| [ROADMAP_ADVANCED.md](./ROADMAP_ADVANCED.md) | Advanced Phases A1–A10 |
| [ARCHITECTURE.md](./ARCHITECTURE.md) | Pipeline and layering |
| [PRODUCT.md](./PRODUCT.md) | Deployment context and consumers |
| [TESTING.md](./TESTING.md) | Test strategy and incremental history |
| [RUNBOOK.md](./RUNBOOK.md) | Operations |
| [SLO.md](./SLO.md) | Reliability targets |

---

## Next action

**E10 is shipped.** Enterprise roadmap E1–E10 complete.
