# Service level objectives

| Objective | Target | Measurement |
|-----------|--------|-------------|
| Availability | 99.9% monthly | `/health` success rate excluding planned maintenance |
| Single-employee payroll run latency | p99 < 2s | Prometheus `payroll_run_duration_ms{source="api",status="success"}` or `payroll.run.complete` logs |
| Batch payroll | No data loss on deploy | Graceful shutdown drains in-flight batches or marks failures |
| API errors | < 0.1% 5xx | Problem Details `internal-error` rate; k6 `http_req_failed < 0.1%` |

## Measured baselines (local, Advanced Phase 9)

| Scenario | Result | Command |
|----------|--------|---------|
| 100-employee batch (SQLite test env) | ~30s wall, p95 run &lt; 2s per employee | `npm run load:batch` |
| k6 smoke (health + metrics) | 5 VUs × 30s, error rate &lt; 0.1% | `k6 run scripts/load/k6-batch-payroll.js` |
| Unit test suite | Target &lt; 120s total | `npm test` |

Re-measure on PostgreSQL before production SLO sign-off. See [PERFORMANCE.md](./PERFORMANCE.md).

## Error budget

- 99.9% allows ~43 minutes downtime per month.
- Breach triggers freeze on non-critical releases until root cause is documented in the runbook.

## Alerting (recommended)

- `ready` probe failing > 2 minutes
- 5xx rate > 1% over 5 minutes
- Batch `failure_count / total_count` > 10% for any period
