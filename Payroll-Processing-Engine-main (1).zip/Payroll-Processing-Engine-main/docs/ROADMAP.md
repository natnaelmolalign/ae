# Payroll Processing Engine — Foundation Roadmap (Phases 1–10)

This document is the authoritative implementation guide for the **core** engine through production-grade payroll operations. **All foundation phases are shipped.**

For advanced capabilities (1099, multi-state, tips, equity, webhooks, compliance), see **[ROADMAP_ADVANCED.md](./ROADMAP_ADVANCED.md)** (shipped). For enterprise platform work (pay policies, accruals, disbursements, ERP, ESS, scale), see **[ROADMAP_ENTERPRISE.md](./ROADMAP_ENTERPRISE.md)**. Each phase is designed to be **shippable**, **testable**, and **reviewable** as an isolated increment — the same delivery discipline used for regulated payroll products.

---

## How to use this roadmap

| Artifact | Purpose |
|----------|---------|
| **Phase goal** | One sentence outcome; use as PR/epic title |
| **Deliverables** | Concrete files, modules, or behaviors that must exist |
| **Acceptance criteria** | Objective pass/fail checks before phase close |
| **Exit gates** | Non-negotiable quality bar (tests, docs, ops) |
| **Dependencies** | Prior phases that must be complete |
| **Regression focus areas** | Edge cases and cross-layer risks to cover in tests after the phase ships |

**Workflow per phase**

1. Open a tracking issue (or ADR stub) listing deliverables.
2. Implement behind interfaces; keep calculation logic pure where possible.
3. Add unit tests for every new pure function; integration tests for every new HTTP boundary.
4. Update domain docs (`docs/*.md`) when rules change.
5. Merge only when exit gates pass.
6. Tag commit(s) with phase identifier in message, e.g. `phase-3: hourly earnings engine`.

---

## Current baseline (pre–Phase 1)

| Area | Status |
|------|--------|
| Calculation core | Federal progressive tax, FICA wage base, pre-tax ordering, garnishment caps, YTD, pay stub reconciliation |
| API | Express routes; **in-memory** `store.ts` (not production persistence) |
| Database | Knex migrations exist; routes do not use `getDb()` yet |
| Tests | 19 Jest tests; behavioral focus |
| Ops | Dockerfile (`node:20`), no CI, no structured auth |
| Legacy | Residual Vite/React files may still exist in `src/` — remove in Phase 1 |

Treat Phases 1–2 as **hardening what exists**. Phases 3–7 deepen payroll domain correctness. Phases 8–10 scale, observe, and operate.

---

## Engineering principles (all phases)

These apply to every PR; they are not optional “nice-to-haves.”

### Domain & money

- **Never use `number` for money** in business logic — `decimal.js` via `decimalUtils` only.
- **Tax rules are data, not code** where possible — versioned tables under `src/data/{year}/`.
- **Calculation pipeline is a directed acyclic graph** — document stage inputs/outputs in `docs/ARCHITECTURE.md` when adding stages.
- **Idempotent payroll runs** — same `(employeeId, payPeriodId, runVersion)` must not double-apply YTD.

### Architecture

- **Ports and adapters**: `Repository` interfaces in `src/repositories/`; Knex implementations in `src/repositories/knex/`.
- **Services orchestrate; utils compute** — no HTTP in services; no SQL in utils.
- **Explicit errors** — domain errors (`PayrollDomainError` with codes), mapped to HTTP in `errorHandler`.
- **Feature flags** for incomplete tax years or states — `src/config/features.ts`.

### Testing

- **Test pyramid**: many unit (pure), fewer integration (API + DB), minimal e2e.
- **Golden files** for tax scenarios — `tests/golden/{scenario}.json` with expected withholdings.
- **Property-style checks** where cheap: net pay = gross − taxes − deductions ± $0.01 never violated.
- **Regression tests** for every production bug fix before merge.

### Observability & operations

- **Structured logs** (Winston JSON) with `correlationId`, `employeeId`, `payPeriodId`, `phase`.
- **Metrics hooks** (interface now, Prometheus later): `payroll_run_duration_ms`, `payroll_run_errors_total`.
- **Health**: `/health` liveness; `/ready` checks DB connectivity in Phase 2+.

### Security & compliance

- **AuthN/Z** before external exposure (Phase 10); design hooks in Phase 2.
- **PII minimization** in logs — mask SSN/TIN fields when added.
- **Audit trail** for every mutation affecting pay or YTD (Phase 9).

### Documentation

- **ADR** for non-obvious choices: `docs/adr/NNNN-title.md`.
- **Rule docs stay in sync** — if code diverges from `TAX_CALCULATION_RULES.md`, the doc wins or the code wins in the same PR.

---

## Phase overview

```mermaid
flowchart LR
  P1[Phase 1\nFoundation] --> P2[Phase 2\nPersistence]
  P2 --> P3[Phase 3\nEarnings]
  P3 --> P4[Phase 4\nTax Engine v2]
  P4 --> P5[Phase 5\nBenefits]
  P5 --> P6[Phase 6\nGarnishments]
  P6 --> P7[Phase 7\nRetro]
  P7 --> P8[Phase 8\nBatch Payroll]
  P8 --> P9[Phase 9\nReporting]
  P9 --> P10[Phase 10\nProduction]
```

| Phase | Name | Duration (indicative) | Theme |
|-------|------|------------------------|--------|
| 1 | Foundation & hygiene | 1–2 weeks | Repo health, CI, errors, remove legacy |
| 2 | Persistence & repositories | 2–3 weeks | PostgreSQL truth, transactions |
| 3 | Earnings & time | 2–3 weeks | Hourly, OT, shifts, imputed |
| 4 | Tax engine v2 | 3–4 weeks | W-4, supplemental methods, versioning |
| 5 | Benefits & deductions | 2–3 weeks | Limits, catch-up, cafeteria depth |
| 6 | Garnishments & compliance | 2 weeks | Multi-order, federal/state rules |
| 7 | Retroactive & corrections | 2–3 weeks | Full recompute, delta postings |
| 8 | Batch payroll & concurrency | 2–3 weeks | Runs, locking, replay |
| 9 | Reporting & audit | 2–3 weeks | GL, exports, immutable audit |
| 10 | Production & platform | 2–4 weeks | Auth, multi-tenant, SLOs, DR |

---

## Phase 1 — Foundation & engineering hygiene

**Goal:** Establish a clean, CI-gated codebase with consistent errors, logging, and project structure — no new payroll features.

### Deliverables

- [x] Remove legacy frontend artifacts (`App.jsx`, `geminiai.js`, `component/`, etc.)
- [x] `src/errors/PayrollDomainError.ts` + error code enum
- [x] `src/config/features.ts`, `src/config/taxYear.ts`
- [x] `src/logging/logger.ts` — wrapper with correlation ID middleware
- [x] `.github/workflows/ci.yml` — `npm ci`, `build`, `test`, optional `docker build`
- [x] `eslint` + `prettier` (pinned versions) + `lint` script
- [x] `docs/adr/0001-decimal-money.md`, `docs/adr/0002-repository-pattern.md`
- [x] Expand `README.md` with dev setup, test commands, link to this roadmap

### Acceptance criteria

- `npm run build && npm test` pass on CI
- No imports from deleted legacy paths
- All services throw `PayrollDomainError` for domain failures (not generic `Error`)
- Request logs include `x-correlation-id` or generated UUID

### Exit gates

- Test coverage report baseline (Jest `--coverage`; target ≥70% on `utils/` and `services/`)
- Dockerfile still builds on CI

### Regression focus areas

- Misconfigured correlation ID middleware dropping IDs under load
- Error handler mapping wrong HTTP status for specific domain codes

### Dependencies

None.

---

## Phase 2 — Persistence & repository layer

**Goal:** PostgreSQL becomes the system of record; in-memory `store.ts` retired from production paths.

### Deliverables

- [x] Repository interfaces: `EmployeeRepository`, `PayPeriodRepository`, `PayStubRepository`, `YtdRepository`, `PayrollRunRepository`
- [x] Knex implementations under `src/repositories/knex/`
- [x] Migrations: `deduction_enrollments`, `earnings_lines`, `payroll_runs`, `audit_events` (stub)
- [x] `src/services/*` refactored to accept repositories via constructor injection
- [x] `src/app.ts` wiring factory `createApp(deps)`
- [x] `/ready` endpoint — `SELECT 1` against DB
- [x] Integration tests with test DB (SQLite in-memory or PG test container)
- [x] Transaction boundary: `runPayroll` wraps stub insert + YTD update in one transaction

### Acceptance criteria

- Restarting the server does not lose employees or pay periods
- Concurrent payroll runs for **different** employees succeed; same employee+period rejected (unique constraint)
- Integration test: create employee → generate periods → run payroll → fetch stub from DB

### Exit gates

- Migration up/down tested in CI
- No direct `Map` usage in route handlers

### Regression focus areas

- Pay period overlap allowed due to missing DB unique index
- YTD update committed but pay stub rolled back (transaction boundary bug)
- Repository returns stale YTD without `FOR UPDATE` lock

### Dependencies

Phase 1.

---

## Phase 3 — Earnings, time & attendance

**Goal:** Support hourly and complex earnings types with correct gross classification for tax.

### Deliverables

- [x] `TimeEntry` model: clock in/out, rounded minutes, pay period allocation
- [x] `EarningsService` extensions:
  - Regular vs overtime (1.5× / 2× configurable by `jurisdiction` table)
  - Holiday pay multipliers
  - Commission as supplemental candidate
- [x] `HourlyPayCalculator` — rate × hours with rounding rules (half-up to cent)
- [x] `ImputedIncomeService` — e.g. group life above $50k
- [x] API: `POST /api/time-entries`, `POST /api/earnings/preview`
- [x] `docs/EARNINGS_AND_TIME.md`
- [x] Golden tests: hourly + OT + holiday same period

### Acceptance criteria

- OT hours > 40/week (configurable) computed separately from regular
- Expense reimbursement still excluded from taxable wages
- Preview endpoint matches run endpoint totals for same inputs

### Exit gates

- ≥15 new unit tests on earnings classification
- ADR: overtime allocation method (daily vs weekly)

### Regression focus areas

- OT calculated on calendar week vs work week mismatch
- Holiday pay incorrectly included in SS base when exempt under state rule (feature-flagged)

### Dependencies

Phase 2.

---

## Phase 4 — Tax engine v2 (federal, state, local)

**Goal:** Production-faithful withholding with versioned tax data and multiple withholding methods.

### Deliverables

- [x] `src/data/{taxYear}/federal/` — brackets, standard deduction, supplemental rates
- [x] `W4Params` model: filing status, multiple jobs, dependents, deductions, extra withholding
- [x] `FederalWithholdingStrategy` interface:
  - `PercentageMethodAnnualized`
  - `SupplementalFlat`
  - `SupplementalAggregate` (bonus + regular same check)
- [x] `StateWithholdingStrategy` per state — flat, bracket table, no tax
- [x] `LocalTaxService` (optional municipalities: OH cities, PA PSD)
- [x] `TaxYearService` — select tables by payment date, not period end
- [x] `docs/TAX_CALCULATION_RULES.md` major update + IRS publication references
- [x] Golden suite: 30+ scenarios in `tests/golden/federal/`

### Acceptance criteria

- W-4 Step 3 credits reduce withholding correctly
- Supplemental-only check uses flat rate; mixed check uses aggregate when configured
- State annualization matches federal pattern for biweekly
- Medicare additional 0.9% only on wages above threshold **in period allocation**

### Exit gates

- Tax table loader validated by schema (Zod) at startup
- Wrong `taxYear` for payment date fails fast with `TAX_YEAR_UNSUPPORTED`

### Regression focus areas

- Flat rate applied to entire gross (bracket bug variant)
- State tax without annualization for monthly pay
- Medicare surtax on first dollar

### Dependencies

Phase 3 (earnings classification feeds taxable wages).

---

## Phase 5 — Benefits, deductions & limits

**Goal:** Enforce IRS and plan limits with correct base reductions and year-to-date tracking.

### Deliverables

- [x] `BenefitEnrollment` persisted model with effective dates
- [x] `DeductionLimitTracker` — 401(k) §402(g), catch-up age 50+, HSA family/individual, FSA $3,200 (2024)
- [x] Section 125 vs 401(k) ordering documented and tested
- [x] Roth 401(k) post-tax routing
- [x] `SafeHarborMatchCalculator` for employer match formulas
- [x] API: enrollments CRUD, deduction preview on payroll
- [x] `docs/DEDUCTION_ORDERING.md` — limit enforcement section

### Acceptance criteria

- Contribution rejected when YTD + current would exceed limit (including catch-up eligibility)
- 401(k) reduces federal taxable only; Section 125 reduces FICA bases
- Mid-year enrollment prorates limit (optional v1: full year limit)

### Exit gates

- Limit tables versioned by tax year
- Property test: deductible amounts never exceed gross

### Regression focus areas

- Limit check uses YTD before current period (off-by-one)
- HSA marked pre-tax for FICA incorrectly

### Dependencies

Phase 4 (taxable bases).

---

## Phase 6 — Garnishments & legal compliance

**Goal:** Multiple concurrent garnishments with correct priority, caps, and remittance tracking.

### Deliverables

- [x] `GarnishmentOrder` persisted: type, case ID, priority, max %, fixed amount, effective/end dates
- [x] `DisposableEarningsCalculator` — aligned with CCPA definitions (support, taxes, mandatory deductions)
- [x] Support vs creditor vs student loan priority tables
- [x] `GarnishmentAllocationService` — waterfill algorithm across orders
- [x] Remittance ledger stub (amount withheld per order per run)
- [x] `docs/GARNISHMENTS.md`

### Acceptance criteria

- Child support always satisfied before creditor garnishments at same priority tier
- Total garnishments never exceed CCPA cap on disposable earnings
- Terminated employee: no new garnishment applied after termination payment date

### Exit gates

- Table-driven tests for 5+ multi-garnishment scenarios
- Legal references cited in doc (CCPA, state variants behind flags)

### Regression focus areas

- Gross used instead of disposable for cap
- Creditor takes full amount before child support

### Dependencies

Phase 5 (disposable depends on finalized tax/deduction amounts).

---

## Phase 7 — Retroactive adjustments & corrections

**Goal:** Correct prior periods with full recomputation, delta posting, and YTD integrity.

### Deliverables

- [x] `RetroAdjustmentService` v2:
  - Identify affected periods by effective date range
  - Re-run pipeline per period with frozen tax tables (payment-date tables)
  - Compute delta vs stored stubs
  - Post correction line items on current open period
- [x] `CorrectionPayStub` linked to original stub IDs
- [x] Negative net handling (recovery on next check)
- [x] API workflow: draft adjustment → preview deltas → approve → apply
- [x] `docs/RETROACTIVE_ADJUSTMENTS.md` — state machine diagram

### Acceptance criteria

- Salary increase effective 3 periods ago updates all intermediate YTD and issues one net correction
- Correction does not double-count gross in YTD
- Terminated employee: adjustment blocked if payment date after termination
- Tax tables for past periods use historical payment dates

### Exit gates

- [x] Integration test: 3-period backdated raise with matching cumulative YTD
- [x] ADR: correction accounting vs replacement stub

### Regression focus areas

- Only latest period recalculated
- Correction applied after termination
- YTD double-count when correction in same period as original

### Dependencies

Phase 6, Phase 4 (historical tax tables).

---

## Phase 8 — Batch payroll, scheduling & concurrency

**Goal:** Run payroll for many employees safely with observability and failure isolation.

### Deliverables

- [x] `PayrollBatch` entity: status (`pending|running|completed|failed`), startedAt, counts
- [x] `payrollRunJob.ts` v2 — chunk employees, parallel workers with limit
- [x] Row-level lock on `ytd_totals` during run (`FOR UPDATE`)
- [x] Idempotency key header on `POST /api/payroll/run`
- [x] Dead-letter queue pattern for failed employees (in-memory table or `payroll_run_failures`)
- [x] `POST /api/payroll/batch` + `GET /api/payroll/batch/:id`
- [x] Metrics: batch duration, success/failure counts

### Acceptance criteria

- Re-submitting same idempotency key returns original stub, no duplicate YTD
- Partial batch failure leaves successful employees committed, failed retryable
- Scheduler job processes only employees in `ready` status for period

### Exit gates

- [x] Load test script (k6 or Artillery) — 100 employees, p95 < 30s local
- [x] No race-induced YTD drift under parallel runs (different employees)

### Regression focus areas

- Idempotency key ignored under concurrency
- Batch commits YTD before all stubs written

### Dependencies

Phase 7.

---

## Phase 9 — Reporting, GL export & audit

**Goal:** Finance-ready outputs and immutable audit for compliance.

### Deliverables

- [x] `GeneralLedgerExporter` — debit/credit lines per earnings, tax, deduction, employer liability
- [x] `PayStubPdfRenderer` (or HTML template) — line items + YTD
- [x] `AuditEvent` append-only: who, what, entity, before/after snapshot (JSON diff)
- [x] API: `GET /api/reports/payroll-register?periodId=`, `GET /api/reports/gl-export`
- [x] `docs/REPORTING.md`, `docs/AUDIT.md`
- [x] Retention policy config (days to keep audit)

### Acceptance criteria

- GL export balances (debits = credits) for sample payroll run
- Every API mutation on employee/enrollment/run creates audit row
- Payroll register matches sum of pay stubs for period

### Exit gates

- [x] Snapshot test on GL CSV format
- [x] Audit cannot be updated or deleted via API

### Regression focus areas

- GL missing employer SS liability line
- Audit written after failed transaction (should not exist)

### Dependencies

Phase 8.

---

## Phase 10 — Production platform, security & SLOs

**Goal:** Operate as a secure, multi-tenant internal service with defined reliability targets.

### Deliverables

- [x] Authentication: JWT or API keys via `middleware/auth.ts`
- [x] Authorization: RBAC roles (`payroll_admin`, `payroll_clerk`, `read_only`)
- [x] Multi-tenant: `companyId` on all tenant-scoped tables + repository filters
- [x] Rate limiting, request size caps, helmet security headers
- [x] OpenAPI 3 spec `openapi.yaml` generated from Zod schemas
- [x] Kubernetes-ready health probes; graceful shutdown
- [x] Structured error responses (RFC 7807 Problem Details)
- [x] CI: lint, test, build image, scan (npm audit threshold)
- [x] `docs/RUNBOOK.md` — deploy, rollback, YTD reset procedure
- [x] SLO definitions: 99.9% availability, p99 payroll run < 2s single employee

### Acceptance criteria

- Cross-tenant data access returns 404 (not 403 leak)
- Unauthorized payroll run rejected
- Graceful shutdown completes in-flight batch or marks failed cleanly
- OpenAPI validates against running server (schemathesis or manual)

### Exit gates

- Penetration checklist (OWASP top 10 relevant items)
- Disaster recovery: DB backup restore doc + drill once

### Regression focus areas

- Missing `companyId` filter in one repository method
- JWT not validated on adjustments route

### Dependencies

Phase 9.

---

## Cross-cutting backlog (pull into phases as needed)

| Item | Suggested phase |
|------|-----------------|
| Tax year rollover job (`ytdResetJob` v2, payment-date aware) | 7–8 |
| Contractor vs employee (1099 path, no withholding) | 3–4 |
| COBRA / arrears deductions | 5 |
| Tips & allocated tips (Form 8027) | 3–4 |
| Stock compensation (RSU supplemental) | 4 |
| Multi-state allocation (work in two states) | 4 |
| Pay stub delivery webhooks | 9 |
| Terraform / IaC for RDS + ECS | 10 |

---

## Testing strategy by phase

| Layer | Tooling | Responsibility |
|-------|---------|----------------|
| Unit | Jest | Utils, strategies, pure services |
| Integration | Jest + supertest + DB | Routes, repositories, transactions |
| Golden | JSON fixtures | Tax scenarios, regression |
| Contract | OpenAPI (Phase 10) | API stability |
| Load | k6 (Phase 8) | Batch throughput |

**Coverage targets (cumulative)**

| Milestone | Line coverage (services + utils) |
|-----------|----------------------------------|
| After Phase 2 | 75% |
| After Phase 4 | 82% |
| After Phase 7 | 88% |
| After Phase 10 | 90%+ (domain logic later reached 100% at enterprise ship — see [TESTING.md](./TESTING.md)) |

---

## Cross-phase regression map

High-risk themes that span multiple modules — prioritize golden fixtures and integration tests here:

| Theme | Primary phases |
|-------|----------------|
| Federal brackets, SS wage base | 4 |
| Pay period generation / overlap | 2, 3 |
| 401(k) / Section 125 bases | 5 |
| Supplemental withholding | 4 |
| Retro / YTD | 7, 8 |
| Garnishments | 6 |
| Pay stub reconciliation | 1, 9 |
| State annualization | 4 |
| 401(k) limit | 5 |
| Employer SS | 4, 5 |
| Reimbursements | 3 |
| Medicare surtax | 4 |

Tests are **behavioral only** — amounts in, withholdings out; avoid assertion style that only checks variable names.

---

## Commit discipline

Land each capability as focused commits (migrations, services, tests, docs) — not single squashed dumps. Example cadence:

```
feat repository interfaces and knex adapters
feat wire payroll routes to postgres
test integration payroll persistence
```

Incremental history demonstrates sustained engineering on a regulated domain.

---

## Definition of done (entire roadmap)

- [x] All Phase 1–10 exit gates passed
- [x] `docs/ROADMAP.md` checkboxes updated to reflect reality
- [x] OpenAPI published; RUNBOOK validated in staging
- [x] Repository is **private**, zip includes `.git/`, Dockerfile with pinned deps

---

## Status

**Foundation Phases 1–10, Advanced A1–A10, and Enterprise E1–E10 are complete.** See [PRODUCT.md](./PRODUCT.md) for deployment context and [TESTING.md](./TESTING.md) for how the test suite grew over time.
