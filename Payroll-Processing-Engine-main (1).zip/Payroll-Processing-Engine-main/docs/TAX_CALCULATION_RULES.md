# Tax Calculation Rules

References: [IRS Publication 15](https://www.irs.gov/publications/p15), [Publication 15-T](https://www.irs.gov/publications/p15t) (federal income tax withholding), [Publication 15-A](https://www.irs.gov/publications/p15a) (supplemental wages).

## Tax year selection

- Tables live under `src/data/{taxYear}/` (federal, state, FICA, local).
- `TaxYearService` loads tables by **payment date** (not pay period end).
- Tables are validated with Zod at application startup.
- Unsupported payment years raise `TAX_YEAR_UNSUPPORTED`.

## Federal income tax

### Percentage method (annualized)

Used for regular wages (no supplemental, or supplemental not mixed on the check).

1. Annualize period taxable wages using pay frequency (52 weekly, 26 biweekly, 24 semimonthly, 12 monthly).
2. Subtract **standard deduction** for filing status (2024 amounts in `src/data/2024/federal/standardDeduction.ts`).
3. Subtract W-4 Step 4(b) other deductions; add Step 4(a) other income.
4. Apply progressive brackets for filing status.
5. Subtract W-4 Step 3 dependents/credits (annual).
6. Optional Step 2 multiple jobs: +10% on computed annual tax (simplified).
7. De-annualize to per-period withholding; add Step 4(c) extra withholding per period.

### Supplemental wages

| Situation | Method |
|-----------|--------|
| Supplemental-only check (bonus/commission/severance only) | **Flat rate** 22% on federal taxable supplemental wages (2024) |
| Mixed regular + supplemental on same check | **Aggregate** — withhold as if total were one regular payment (percentage method on combined taxable wages) |

Implementation: `FederalWithholdingEngine` selects `SupplementalFlat`, `SupplementalAggregate`, or `PercentageMethodAnnualized`.

## FICA

- **Social Security**: 6.2% on SS-taxable wages until YTD SS taxable reaches wage base (`src/data/2024/fica.ts`).
- **Medicare**: 1.45% on all Medicare-taxable wages in the period.
- **Medicare additional**: 0.9% only on Medicare-taxable wages **above** the $200,000 YTD threshold allocated to the current period (not on the first dollar of pay).

## State tax

Per-state configuration in `src/data/2024/state/`:

| Strategy | States (2024 v1) |
|----------|------------------|
| No tax | TX, FL, WA, NV |
| Flat + annualization | CA, IL |
| Bracket + annualization | NY (simplified single table) |

State withholding annualizes period wages the same way as federal, then applies flat rate or progressive brackets.

## Local tax (optional)

- Gated by `FEATURE_LOCAL_TAX=true`.
- Employee `localMunicipalityCode` + `stateCode` map to rates in `src/data/2024/local/`.
- Stub municipalities: OH `COL`, PA `PHL`.

## Taxable base reductions

| Deduction type | Federal/state income | SS | Medicare |
|----------------|---------------------|-----|----------|
| Section 125    | Yes                 | Yes | Yes      |
| 401(k) pre-tax | Yes                 | No  | No       |
| HSA/FSA        | Yes (limits apply)  | No  | No       |

## Golden tests

Federal withholding regression suite: `tests/golden/federal/scenarios.json` (30+ cases). Regenerate with:

```bash
npx ts-node tests/helpers/generateFederalGolden.ts
```
