# ADR 0015: Compliance suite and TIN vault

## Status

Accepted (Advanced Phase 10)

## Context

Year-end W-2, 1099-NEC, and quarterly Form 941 preparation require read-only aggregates aligned with pay stubs. Tax identification numbers must not appear in logs or cross-tenant API responses.

## Decision

1. Add `W2ExportService`, `Form1099NecExportService`, and `Form941ReconciliationService` under `src/services/compliance/`, sharing `loadCompliancePayrollRows` keyed by `payment_date` and `company_id`.
2. Expose previews at `GET /api/reports/w2-preview`, `1099-nec-preview`, and `941-reconciliation`.
3. Store TINs as AES-256-GCM ciphertext (`tin_encrypted`, `tin_key_id`, `tin_last_four`) with `TIN_MASTER_KEY`; KMS envelope is a future swap without API changes.
4. Never return full TIN in JSON; previews use masked last four only.
5. Document OWASP mapping in `SECURITY_CHECKLIST.md` and legal sign-off placeholder in `COMPLIANCE_EXPORTS.md`.

## Consequences

- Preview totals are only as accurate as classified `employmentType` and payment dates.
- Production must set `TIN_MASTER_KEY` before accepting `tin` on employee create.
- 90% Jest coverage remains a roadmap exit target; global threshold stays at 65% until broader test expansion.
