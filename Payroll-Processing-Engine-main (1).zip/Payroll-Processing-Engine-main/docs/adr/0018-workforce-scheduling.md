# ADR 0018: Workforce scheduling and time approval

## Status

Accepted (Enterprise Phase E3)

## Context

Hourly payroll from raw clock punches needs manager review. Unapproved time must not affect gross pay.

## Decision

1. Model **shifts** and **shift_assignments** with status workflow.
2. Link `time_entries.shift_assignment_id` to assignments.
3. Block payroll when any assignment in the pay period is `pending` or `rejected`.
4. Only `approved` / `exported_to_payroll` assignment entries are included in `useTimeEntries` builds.
5. Optional CA meal premium behind `FEATURE_CA_MEAL_PENALTY`.

## Consequences

- Extra tables and approval APIs.
- Payroll and preview paths share `TimeApprovalService` gates.
- Legacy time entries without `shift_assignment_id` still work when scheduling is enabled.
