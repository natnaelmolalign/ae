# ADR 0022: Employee self-service and W-4 change workflow

## Status

Accepted (Enterprise Phase E7)

## Context

Employees need read-only access to pay history and tax previews without exposing admin APIs. W-4 updates must be reviewed before affecting withholding calculations, with a complete audit trail.

## Decision

1. Add `employee_self` role scoped by `employeeId` in JWT or `x-employee-id` (test mode).
2. Restrict `employee_self` to `/api/ess/*` in RBAC middleware.
3. Persist `w4_change_requests` with states: draft → pending → applied | rejected.
4. `W4ChangeRequestService.approve` updates employee W-4 fields and records audit events; pending drafts never touch the employee row.
5. BOLA: cross-employee resource access returns 404.

## Consequences

- Clerk queue is separate from ESS routes (`/api/w4-change-requests`).
- Full SAML/OIDC employee SSO is deferred; JWT with `employeeId` is sufficient for API integration tests and service-to-service flows.
- Machine-readable pay stub (JSON-LD) remains a future enhancement.
