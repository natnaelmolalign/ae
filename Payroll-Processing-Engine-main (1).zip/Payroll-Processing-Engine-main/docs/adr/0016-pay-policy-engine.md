# ADR 0016: Pay policy engine before calculation

## Status

Accepted (Enterprise Phase E1)

## Context

Payroll runs need company-specific guardrails (minimum wage floors, gross caps, fraud limits) without hard-coding rules in `PayrollRunService`. Rules change by effective date and may differ per employee.

## Decision

1. Store policies in `pay_policies` with JSON `rules` validated by Zod at write time.
2. Evaluate policies in a **pure** `PayPolicyEvaluator` before any tax or deduction math.
3. Block runs on violation with `PAY_POLICY_VIOLATION`; no silent clamping of amounts.
4. Gate behind `FEATURE_PAY_POLICIES` (default enabled).

## Consequences

- New migrations and admin API surface.
- Preview and run paths share the same evaluator (no preview/run drift).
- Future phases (accruals, controls) can add rule types without changing the pipeline order.

## Alternatives considered

- **Inline checks in PayrollRunService** — rejected; does not version or audit policy changes.
- **Soft warnings only** — rejected for v1; regulated payroll requires explicit override workflow (E9).
