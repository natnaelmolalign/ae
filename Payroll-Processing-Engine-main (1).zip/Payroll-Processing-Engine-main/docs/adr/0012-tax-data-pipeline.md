# ADR 0012: JSON tax table packs and validation pipeline

## Status

Accepted (Advanced Phase 7)

## Context

Phase 4 introduced versioned TypeScript tax modules and Zod validation at startup. Operations need to ship bracket-only updates without application redeploys, and CI must reject malformed table files before they reach production.

## Decision

1. Canonical tax parameters live in `src/data/{taxYear}/tables.json`, described by `src/data/schema/taxTables.schema.json`.
2. `TaxTableLoader` validates packs with Ajv + Zod, caches in production, and skips cache in development for hot reload.
3. `TaxYearService` resolves tables through the loader; payment-date year selection is unchanged.
4. Forward years (2025, 2026) ship as provisional JSON stubs; `FEATURE_TAX_YEAR_2025` gates runtime use.
5. `npm run tax:validate` and CI enforce schema compliance for all discovered packs.

## Consequences

- Bracket edits are data PRs validated in CI, not TypeScript-only changes.
- TypeScript modules under `src/data/2024/` remain as reference/export sources until fully migrated.
- ADR 0004 remains valid for payment-date selection and strategy pattern; loader rules supersede “Zod-only at startup” for pack format.

## Supersedes

Partially amends ADR 0004 (storage and validation mechanics only).
