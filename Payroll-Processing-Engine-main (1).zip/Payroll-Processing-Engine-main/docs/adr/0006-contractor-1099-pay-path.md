# ADR 0006: Contractor (1099) pay path

## Status

Accepted — Advanced Phase 1

## Context

Employees may be stored with `employmentType: contractor`. The W-2 calculation pipeline (withholding, FICA, garnishments, pre-tax cafeteria) must not apply to bona fide 1099-NEC pay.

## Decision

1. Gate contractor behavior on `isContractor1099(employee)` and `features.contractorPayrollEnabled`.
2. `ContractorTaxService.zeroContractorWithholding()` returns all-zero tax result; `TaxCalculationService.calculateAll` short-circuits before federal/state/FICA engines.
3. `assertContractorDeductionsAllowed` rejects W-2-only pre-tax deduction types before `DeductionService.applyPreTax`.
4. Skip garnishment processing and employer FICA/match in `PayrollRunService.compute`.
5. YTD still records gross; tax buckets unchanged on contractor runs.

## Consequences

- Phase 10 1099-NEC export (Advanced Phase 10) can filter `employmentType === 'contractor'`.
- Re-classifying contractor → W-2 requires new runs; no automatic retro in this ADR.
- Contractors with court-ordered withholding need a future garnishment ADR amendment.

## Alternatives considered

- Separate `/api/contractor-pay` endpoint — rejected to avoid duplicated orchestration.
- Tax as sole proprietor with schedule C — out of scope.
