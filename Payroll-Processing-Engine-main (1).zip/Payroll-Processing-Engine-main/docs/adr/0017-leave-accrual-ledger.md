# ADR 0017: Leave accrual ledger

## Status

Accepted (Enterprise Phase E2)

## Context

PTO and sick time require balances that accrue over time, decrease on paid leave runs, and roll over at year-end with caps. Balances must reconcile to an auditable transaction history.

## Decision

1. Store balances in `leave_balances` but treat `leave_transactions` as the source of truth for history.
2. Accrual runs via `POST /api/admin/accrual-run` per pay period (idempotent).
3. Payroll usage deducts hours when earnings lines include `type: pto|sick` and `hours`.
4. Carryover/forfeit applied on first accrual of a new calendar year.

## Consequences

- Payroll runs and accrual job must coordinate; usage without prior accrual fails closed.
- Time entry types `pto` and `sick` reserved for future scheduling integration.
