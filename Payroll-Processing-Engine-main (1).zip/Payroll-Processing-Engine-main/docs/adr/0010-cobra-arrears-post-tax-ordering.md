# ADR 0010: COBRA and arrears post-tax ordering

## Status

Accepted — Advanced Phase 5

## Context

Post-employment COBRA premiums and wage arrears must be recovered through payroll without breaking net-pay reconciliation or reducing pre-tax wages incorrectly.

## Decision

1. Store schedules in `deduction_schedules` with type `cobra_premium` or `arrears`.
2. Apply scheduled amounts **after** income tax and enrollment post-tax deductions, **before** garnishments.
3. Cap scheduled deductions to `gross − taxes − other deductions` for the period.
4. COBRA may run after termination; arrears are suppressed when `paymentDate > terminationDate`.
5. Decrement `remaining_balance` on arrears schedules inside the payroll run transaction.
6. Reject `cobra_premium` / `arrears_recovery` if passed as benefit enrollments (schedules only).

## Consequences

- Pre-tax bases unchanged by COBRA (acceptance criterion).
- Garnishment disposable earnings calculation unchanged (scheduled amounts are not mandatory for CCPA base in v1).
- Audit trail on schedule CRUD via `AuditService`.
