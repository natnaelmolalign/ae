# ADR 0009: Equity supplemental withholding elections

## Status

Accepted — Advanced Phase 4

## Context

RSU vests and NQSO exercises are supplemental wages. Employers may withhold using the IRS flat rate (22% in 2024) or treat the payment under the employee’s Form W-4 (percentage / annualized method) when no regular wages are paid in the same period.

## Decision

1. Add `rsu_vest` and `nqso_exercise` earnings types; classify as supplemental.
2. Store `equity_withholding_method` on `employees` (`supplemental_flat` | `w4_annualized`).
3. `EquityCompensationService` overrides federal strategy flags when equity lines are present:
   - Supplemental-only + `supplemental_flat` → flat rate strategy.
   - Supplemental-only + `w4_annualized` → percentage method on full federal taxable wages.
   - Mixed regular + supplemental → aggregate strategy (unchanged from bonus path).
4. Reject `iso_exercise` earnings with `400 INVALID_INPUT`.
5. Track `supplemental_taxable_wages` on YTD when equity runs occur.

## Consequences

- Bonus-only supplemental pay unchanged when no equity lines (no election override).
- Pay stub shows separate RSU / NQSO lines when amounts are non-zero.
- Corrections update supplemental YTD via the same `mergeYtdDelta` path as other wage buckets.
