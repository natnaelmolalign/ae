# ADR 0011: Webhook outbox and signed delivery

## Status

Accepted — Advanced Phase 6

## Context

External systems need reliable notification of payroll events without coupling HTTP delivery to in-process fire-and-forget calls that can race transaction commit.

## Decision

1. `webhook_subscriptions` store URL, secret, and subscribed events per company.
2. On domain events, insert one `webhook_outbox` row per matching subscription **inside the payroll DB transaction** when applicable.
3. `WebhookDeliveryWorker` posts JSON payloads with HMAC-SHA256 (`timestamp.body`) headers.
4. `webhook_deliveries` logs each attempt; retries use exponential backoff; subscriptions disable after repeated failures.
5. Admin CRUD at `/api/admin/webhooks` with audit trail; `payroll_admin` only.

## Consequences

- At-least-once delivery; consumers must be idempotent.
- Batch completion enqueues in its own transaction after all employee runs finish.
- No employee PII in webhook JSON beyond ids and pay amounts.
