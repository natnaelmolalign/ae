# ADR 0007: Multi-state wage allocation

## Status

Accepted — Advanced Phase 2

## Context

Employees may perform work in multiple states in one pay period. The engine must split state-taxable wages and apply the correct jurisdiction tables without taxing the same wages twice.

## Decision

1. Accept `stateAllocations[]` on `PayrollRunInput` (percents summing to 100).
2. `MultiStateAllocationService` validates and computes per-slice tax via `StateWithholdingEngine.calculateForState`.
3. `employee_work_locations` stores default allocations; payroll run uses them when the body omits `stateAllocations`.
4. Persist `payroll_run_state_allocations` for audit and reporting.
5. Reciprocity table documents NY↔CT; per-slice model avoids resident tax on out-of-state slices without a second pass.

## Consequences

- Federal and FICA remain unchanged (still use full-period bases).
- Local tax still uses employee residence config — extend in a future ADR if local work cities matter.
- State tables must exist for every allocated `stateCode` or slice returns `0.00`.

## Alternatives considered

- Resident taxes full amount then credits work state — rejected as harder to reconcile on pay stub.
- Single blended rate — rejected; not compliant with jurisdiction tables.
