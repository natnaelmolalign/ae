# ADR 0004: Versioned tax tables and payment-date selection

## Status

Accepted (Phase 4)

## Context

Federal, state, FICA, and local rules change by calendar year. Withholding must use tables that match the **check payment date**, especially for retro runs and year-boundary pay periods.

## Decision

1. Store tax parameters under `src/data/{taxYear}/` with shared TypeScript types in `src/data/tax/types.ts`.
2. `TaxYearService` registers supported years and validates payloads with Zod at startup.
3. Services accept `paymentDate` and resolve `taxYear` via `taxYearFromPaymentDate()`.
4. Withholding algorithms are strategy objects (`FederalWithholdingStrategy`, `StateWithholdingStrategy`) fed by year tables, not hard-coded in services.

## Consequences

- Adding a new tax year is a data + registry change, not a rewrite of calculation services.
- Unsupported years fail fast with `TAX_YEAR_UNSUPPORTED`.
- Legacy import paths (`federalTaxBrackets2024.ts`, etc.) re-export from `2024/` until callers migrate.

## Amendment (Advanced Phase 7)

Tax packs are loaded from `src/data/{year}/tables.json` via `TaxTableLoader` (JSON Schema + Zod). See [ADR 0012](./0012-tax-data-pipeline.md) and [TAX_DATA_PIPELINE.md](../TAX_DATA_PIPELINE.md).
