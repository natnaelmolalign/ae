# ADR 0019: Benefits open enrollment lifecycle

## Status

Accepted (Enterprise Phase E4)

## Context

Benefit elections must respect open enrollment windows, qualifying life events, and eligibility rules. Mid-year HSA elections require prorated IRS limits. COBRA continuation ties to documented loss-of-coverage events.

## Decision

1. Persist `enrollment_windows`, `eligibility_rules`, and `life_events` with approval workflow.
2. Route all benefit elections through `OpenEnrollmentService.electBenefit` when `FEATURE_BENEFITS_LIFECYCLE` is enabled.
3. Reject elections outside windows unless `lifeEventId` references an approved QLE.
4. Block retroactive pre-tax effective dates; QLE `coverageEffectiveDate` must match enrollment `effectiveDate`.
5. Set prorated `annualLimit` on mid-year HSA QLE enrollments; `DeductionService` honors enrollment-level HSA caps.
6. On approved `loss_of_coverage`, create COBRA premium via existing deduction schedules.

## Consequences

- Benefit enrollment API requires open window or approved QLE in production configuration.
- Tests must seed enrollment windows or life events when lifecycle feature is on.
- COBRA remains post-tax only; life events bridge HR workflow to schedule creation.
