# ADR 0008: Tip credit vs cash wage ordering

## Status

Accepted — Advanced Phase 3

## Context

Tipped employees receive direct cash wages (often at $2.13/hr), reported tips, and sometimes employer-allocated tips. FLSA requires minimum wage make-up when tips + cash wages fall short.

## Decision

1. Process earnings in order: validate tips → compute tip credit shortfall → append `tip_credit_makeup` → classify all earnings.
2. Reported tips for minimum wage = `cash_tips` + `charged_tips` only (allocated tips excluded from FLSA shortfall test).
3. Shortfall increases employee gross (taxable); shown on pay stub as earnings, not as a deduction.
4. `flsaTipCreditMakeup` on employer contributions is informational (employer wage cost), not an extra net pay deduction.
5. Tip credit rejected for salaried employment types.

## Consequences

- Gross reconciles: net = gross − taxes − deductions.
- Allocated tips taxable but do not reduce shortfall obligation incorrectly.
- Register report aggregates tip lines from `earnings_lines`.

## Alternatives considered

- Employer-only expense without wage increase — rejected (FLSA requires wage payment to employee).
