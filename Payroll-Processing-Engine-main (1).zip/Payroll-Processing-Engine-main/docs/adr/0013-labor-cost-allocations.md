# ADR 0013: Payroll run labor cost allocations

## Status

Accepted (Advanced Phase 8)

## Context

Finance needs departmental labor costing and GL segments without maintaining a separate allocation spreadsheet after each payroll run.

## Decision

1. Store `departments`, `jobs`, and `payroll_run_allocations` scoped by `company_id`.
2. `LaborCostAllocationService` validates percents sum to 100% and resolves segments at run time.
3. Missing allocations default to an explicit `UNASSIGNED` department (100%), not silent omission.
4. `GeneralLedgerExporter` splits each line by allocation percent with dimension columns.
5. `GET /api/reports/labor-cost` aggregates gross, taxes, and employer costs by department for a pay period.

## Consequences

- Payroll runs with splits require department setup per tenant.
- GL CSV column layout changes (additive dimension fields).
- Employer FICA is allocated proportionally; totals across departments equal the run-level employer liability.
