# ADR 0025: Filing exports and deduction plugin host

## Status

Accepted (Enterprise Phase E10)

## Context

Compliance previews (Advanced Phase 10) are JSON-only. Enterprise customers need e-file ready artifacts and extensibility for custom deductions.

## Decision

1. `FilingExportService` transforms compliance previews into W-2/1099 XML and 941 CSV with IRS stub namespaces.
2. `PluginHost` registers `DeductionPlugin` implementations with sandbox timeouts.
3. CI validates sample W-2 XML via `scripts/filing-validate.ts`.
4. `SECURITY_CHECKLIST.md` v2 documents control owners and evidence links.

## Consequences

- Production e-file requires agency-final XSD replacement and legal sign-off.
- Plugins run in-process; untrusted third-party code should use a separate sandbox service in future.
