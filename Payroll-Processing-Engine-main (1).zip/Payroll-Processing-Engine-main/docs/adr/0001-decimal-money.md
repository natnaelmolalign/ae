# ADR 0001: Decimal-safe money arithmetic

## Status

Accepted (Phase 1)

## Context

JavaScript `number` uses IEEE 754 binary floats. Payroll calculations involve repeated multiply/add/subtract on currency values; float drift produces incorrect net pay and breaks pay stub reconciliation (gross − taxes − deductions ≠ net).

## Decision

- All money in domain logic is represented as **decimal strings** (`Money` type alias).
- All arithmetic goes through `src/utils/decimalUtils.ts` wrapping **decimal.js** (pinned version in `package.json`).
- Rounding mode: `ROUND_HALF_UP` to 2 decimal places at operation boundaries unless a specific IRS rule requires otherwise.

## Consequences

- Slightly more verbose code than native numbers.
- Tests assert string amounts (`'62.00'`) not floats.
- APIs accept and return monetary fields as strings, never JSON numbers for currency.

## Alternatives considered

- **Integer cents**: viable but ergonomics worse for tax rate multiplication.
- **big.js / currency.js**: rejected; decimal.js already integrated and sufficient.
