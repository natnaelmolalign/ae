# ADR 0023: Durable job queue for batch payroll

## Status

Accepted (Enterprise Phase E8)

## Context

In-process batch parallelism does not scale across API instances. Webhook delivery shares the same limitation.

## Decision

1. Introduce `JobQueue` with `KnexJobQueue` (SQLite/PostgreSQL) and `InMemoryJobQueue` for tests.
2. Partition key `{companyId}:{payPeriodId}` preserves ordering per pay run.
3. Separate `src/worker.ts` process polls and executes jobs; API enqueues with `useQueue: true`.
4. Failed jobs retry until `maxAttempts`, then land in `queue_dead_letters` with Prometheus counter.

## Consequences

- Idempotency keys on payroll runs prevent duplicate YTD under parallel workers.
- SQS adapter remains a stub; production can swap `JOB_QUEUE_BACKEND=sqs` when implemented.
