# ADR 0014: Observability v2 (metrics, traces, read routing)

## Status

Accepted (Advanced Phase 9)

## Context

Production operations need scrapeable SLO metrics, distributed trace correlation, and isolation between heavy report queries and payroll write transactions.

## Decision

1. Expose Prometheus metrics at `GET /metrics` via `prom-client`; payroll hooks record low-cardinality histograms.
2. Propagate W3C `traceparent` alongside `x-correlation-id` in middleware.
3. Introduce `DatabaseRouter` with `writer` and `reader`; reports use `reader` (stub equals writer until replica URL is wired).
4. Document k6 and in-process load scripts; manual CI workflow for k6 smoke.
5. Enrich `/ready` with pool saturation checks.

## Consequences

- Metrics disabled in tests via `FEATURE_PROMETHEUS_METRICS=false` or noop hooks in unit tests.
- GL CSV and metric labels must not include high-cardinality ids.
- Read replica requires future migration to a second Knex instance when `DB_READ_REPLICA_URL` is production-ready.
