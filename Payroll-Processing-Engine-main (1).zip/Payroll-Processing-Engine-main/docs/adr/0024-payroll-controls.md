# ADR 0024: Payroll holds and anomaly approval

## Status

Accepted (Enterprise Phase E9)

## Context

Enterprise payroll requires pre-run holds and outlier detection before money is committed.

## Decision

1. Persist `payroll_holds`, `approval_requests`, `anomaly_flags`.
2. `ControlService.assertRunAllowed` runs before each batch employee (sync and queued).
3. Z-score anomaly on gross pay vs trailing history; flagged amounts require admin approval for the pay period.
4. Hold release emits audit events with reason code.

## Consequences

- Partial batch success semantics unchanged from foundation Phase 8.
- False positive rate depends on threshold; tune `ANOMALY_Z_SCORE_THRESHOLD` per tenant.
