# ADR 0002: Repository pattern for persistence

## Status

Accepted (Phase 1 — planned implementation Phase 2)

## Context

Phase 1 routes use an in-memory `store.ts` for speed of initial development. Production payroll requires durable storage, transactional payroll runs, and test doubles that do not require PostgreSQL for unit tests.

## Decision

- Introduce **repository interfaces** in `src/repositories/` (Phase 2).
- Knex-based implementations live in `src/repositories/knex/`.
- Services receive repositories via **constructor injection**; `createApp(deps)` wires concrete implementations.
- In-memory implementations may remain for fast unit tests of services.

## Consequences

- Clear boundary between domain orchestration and SQL.
- Migrations remain the schema source of truth; repositories map rows ↔ domain types.
- Phase 1 keeps `store.ts` but no new features may depend on it without a Phase 2 migration path.

## Alternatives considered

- **ORM (Prisma/TypeORM)**: rejected for explicit SQL on YTD locking and payroll batch queries.
- **Active Record on models**: rejected; models stay plain TypeScript types.
