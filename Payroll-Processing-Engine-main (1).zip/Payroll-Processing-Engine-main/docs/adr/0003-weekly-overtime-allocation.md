# ADR 0003: Weekly overtime allocation

## Status

Accepted (Phase 3)

## Context

Overtime rules vary by US state. California has daily OT/DT rules; federal FLSA emphasizes weekly hours over 40. The engine must pick one primary method for v1.

## Decision

Use **weekly overtime** on a configurable **work week** (default Monday–Sunday):

1. Sum `roundedMinutes` for non-holiday entries per work week.
2. Allocate up to `weeklyOtThresholdHours` (default 40) at regular rate.
3. Remaining minutes in that week at `otMultiplier` (default 1.5).

Holiday minutes are excluded from the weekly OT pool and paid separately with `holidayMultiplier`.

Daily double-time thresholds are deferred to a later phase.

## Consequences

- OT aligns with federal FLSA baseline used by many employers.
- California daily OT requires a future `DailyOvertimeAllocator` or state-specific strategy.
- Work-week boundary bugs (calendar week vs employer work week) are a common regression area.

## Alternatives considered

- **Daily OT only** — rejected as default; insufficient for multi-state baseline.
- **Calendar week (Sunday start)** — rejected; Monday work week is more common in payroll systems.
