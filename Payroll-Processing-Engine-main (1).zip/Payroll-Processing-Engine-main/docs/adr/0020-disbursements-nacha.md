# ADR 0020: Disbursements and NACHA payment batches

## Status

Accepted (Enterprise Phase E5)

## Context

Employees may split net pay across multiple accounts. Payroll must generate balanced ACH/NACHA files, reconcile totals against liabilities, and never undo committed pay stubs when payment delivery fails.

## Decision

1. Persist `disbursement_instructions`, `payment_batches`, `payment_batch_items`, and `ach_files`.
2. `DisbursementAllocationService` applies fixed → percent → remainder splits with exact decimal reconciliation.
3. Tokenize bank account numbers at rest; store routing numbers and last-four only for ACH building.
4. `PaymentBatchService.submitBatch` generates NACHA after payroll is committed; webhook `payment.batch.submitted` uses the outbox pattern.
5. Failed webhook enqueue marks batch `failed` but leaves pay stubs and ACH file intact for operator retry.

## Consequences

- Employees require at least one active instruction before batch creation.
- Payment batch submission is idempotent via `idempotencyKey`.
- NACHA builder is a simplified profile suitable for tests; production may extend field layouts per ODFI.
