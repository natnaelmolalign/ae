# ADR 0021: ERP GL export connectors

## Status

Accepted (Enterprise Phase E6)

## Context

Payroll GL exports must post to external ERP systems with stable account mappings, idempotent replay, and immutable historical snapshots when mappings change.

## Decision

1. Persist `integration_connections`, versioned `gl_account_mappings`, and `export_batches`.
2. Define `ConnectorAdapter` with `NetSuiteStub` and `QuickBooksStub` implementations.
3. `GlJournalTransformer` maps `GeneralLedgerExporter` output through active mappings before connector submission.
4. `export_batches` store `mapping_version`, `mapping_snapshot`, and `connector_payload` at export time.
5. Idempotency via unique `(connection_id, idempotency_key)` — replays return the existing batch and stub journal IDs.

## Consequences

- Mapping updates create new versions; old export batches remain auditable with their snapshot.
- Connector stubs are suitable for tests and integration; production ODFI credentials belong in `integration_connections.config` (future).
- Unmapped GL account codes fail closed with `GL_MAPPING_NOT_FOUND`.
