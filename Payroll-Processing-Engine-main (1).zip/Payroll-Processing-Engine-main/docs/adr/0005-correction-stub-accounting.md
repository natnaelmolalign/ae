# ADR 0005: Correction stub accounting

## Status

Accepted (Phase 7)

## Context

Retroactive pay changes require updating YTD without double-counting amounts already posted on original (non-correction) pay stubs.

## Decision

1. **Per-period corrections** — For each affected past period that already has an original payroll run, post a new payroll run with `is_correction: true`, `correction_original_gross` set to the original stub gross, and `corrects_pay_stub_id` pointing at the original stub.
2. **YTD gross** — `mergeYtdDelta` adds only `(newGross − originalGross)` when `isCorrection` is true.
3. **Current-period catch-up** — A single net-only correction stub on the current open period (`gross_pay = 0`) pays the employee the sum of net deltas from past periods; it does not change YTD again.
4. **Replacement vs delta** — We do not replace or delete original stubs; corrections are additive records for audit.

## Consequences

- Tax and deduction YTD on correction runs still add full recomputed withholding deltas (future work may baseline all YTD fields).
- Negative net catch-up sets `negative_net_recovery` for recovery on a subsequent check.
