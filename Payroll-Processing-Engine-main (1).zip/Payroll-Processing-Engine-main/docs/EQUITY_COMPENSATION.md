# Equity compensation (RSU & NQSO)

Advanced Phase 4 support for taxable equity events in payroll runs.

## Earnings types

| Type | Description |
|------|-------------|
| `rsu_vest` | Restricted stock unit vest (ordinary income) |
| `nqso_exercise` | Non-qualified stock option exercise spread |

Both are **supplemental wages** for federal withholding (included in FICA and income tax bases).

`iso_exercise` is **not supported** — use NQSO or handle ISO outside this engine.

## Withholding elections

Per-employee `equityWithholdingMethod` (default `supplemental_flat`):

| Election | Supplemental-only equity pay | Mixed regular + equity |
|----------|------------------------------|-------------------------|
| `supplemental_flat` | IRS flat rate (22% for 2024) | Aggregate (W-4 percentage on combined taxable) |
| `w4_annualized` | W-4 percentage method on full payment | Aggregate |

Set on create:

```json
{
  "equityWithholdingMethod": "w4_annualized"
}
```

## Pay run example (RSU flat)

```json
POST /api/payroll/run
{
  "earnings": [{ "type": "rsu_vest", "amount": "10000.00" }],
  "deductions": []
}
```

Federal income tax on $10,000 RSU-only (TX, single, default election): **$2,200.00** (22%).

## YTD

`supplementalTaxableWages` on `ytd_totals` accumulates supplemental earnings (bonus, equity, severance, etc.) when equity is present in the run.

## Feature flag

`FEATURE_EQUITY=false` disables equity validation and withholding election overrides.
