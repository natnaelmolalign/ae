# Webhooks

Advanced Phase 6 delivers payroll events to external systems with at-least-once semantics via an outbox table.

## Events

| Event | When enqueued |
|-------|----------------|
| `payroll.run.completed` | After pay stub + payroll run persist (same DB transaction) |
| `pay_stub.created` | Same transaction as payroll run |
| `batch.completed` | After batch run finishes |

Payloads include only `employeeId`, pay period/stub ids, and pay amounts — no names, SSN, or full compensation profile.

## Subscriptions (admin)

```
POST /api/admin/webhooks
{
  "url": "https://example.com/hooks/payroll",
  "secret": "minimum-16-char-secret",
  "events": ["payroll.run.completed", "pay_stub.created"]
}
```

Requires `payroll_admin`. Responses omit the signing secret.

## Signature verification

Headers on each `POST`:

| Header | Value |
|--------|--------|
| `X-Webhook-Signature` | `sha256=<hex>` |
| `X-Webhook-Timestamp` | Unix seconds |
| `X-Webhook-Id` | Outbox entry id |
| `X-Webhook-Event` | Event type |

Compute HMAC-SHA256 over `${timestamp}.${rawBody}` with the subscription secret. Compare to `X-Webhook-Signature` (constant-time).

```javascript
const crypto = require('crypto');
function verify(secret, rawBody, timestamp, header) {
  const expected =
    'sha256=' +
    crypto.createHmac('sha256', secret).update(`${timestamp}.${rawBody}`).digest('hex');
  return expected === header;
}
```

## Delivery & retries

- Worker: `runWebhookDelivery()` (see `src/jobs/webhookDeliveryJob.ts`)
- Retries on network errors and HTTP 5xx/429 with exponential backoff
- After 5 failed attempts per outbox row → status `failed`
- After 10 consecutive failures → subscription disabled

## Feature flag

`FEATURE_WEBHOOKS=false` disables enqueue and delivery.
