# Tips and FLSA tip credit

## Earnings types

| Type | Description |
|------|-------------|
| `cash_tips` | Tips received in cash |
| `charged_tips` | Tips from credit card charges |
| `allocated_tips` | Form 8027 employer allocations (taxable wages) |
| `tip_credit_makeup` | System-added FLSA minimum wage shortfall (hourly only) |

All tip types are included in **gross**, federal/state taxable wages, and **FICA** bases.

## FLSA tip credit

Hourly employees (`full_time_hourly`, `part_time`) may be paid a direct cash wage below minimum wage when reported tips cover the gap.

```json
"tipCredit": {
  "hours": 40,
  "directCashWages": "85.20",
  "minimumWage": "7.25"
}
```

Shortfall = `max(0, minimumWage × hours − directCashWages − reportedTips)` where reported tips = cash + charged (not allocated).

Shortfall is added as `tip_credit_makeup` earnings (increases gross and net). It is **not** deducted from net as an employer-only fee. `employerContributions.flsaTipCreditMakeup` mirrors the amount for reporting.

Salaried employees cannot use tip credit (`400 INVALID_INPUT`).

## Payroll run example

```json
"earnings": [
  { "type": "regular", "amount": "85.20", "hours": 40 },
  { "type": "cash_tips", "amount": "100.00" }
],
"tipCredit": { "hours": 40, "directCashWages": "85.20" }
```

Required minimum for 40h @ $7.25 = $290.00; tips + cash = $185.20 → make-up **$104.80**.

## Reporting

`GET /api/reports/tip-register?periodId=` lists tip earning lines for the period.

## Feature flag

`FEATURE_TIPS=false` disables tip validation and tip credit processing.
