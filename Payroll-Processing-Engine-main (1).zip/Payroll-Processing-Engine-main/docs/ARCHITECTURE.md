# Architecture

## Layers

1. **Models** — TypeScript types for domain entities (no ORM magic; explicit shapes).
2. **Data** — Versioned tax packs (`src/data/{year}/tables.json`, validated by `TaxTableLoader`; see [TAX_DATA_PIPELINE.md](./TAX_DATA_PIPELINE.md)).
3. **Utils** — Pure functions: decimals, brackets, pay period calendars, garnishment caps.
4. **Services** — Business logic orchestration; all money math goes through `decimal.js`.
5. **Routes** — Express HTTP adapters; validation via Zod in middleware.
6. **Jobs** — Scheduled payroll runs and year-end YTD reset.

## Calculation pipeline (single pay run)

```
[pay policies?] evaluate effective-dated rules; block on violation (ADR 0016)
         → [leave?] assert PTO/sick hours ≤ balance (ADR 0017); post usage after stub commit
         → [workforce?] block unapproved shift assignments (ADR 0018); approved time entries only
         → [benefits lifecycle?] enrollments require open window or approved QLE (ADR 0019); HSA proration on mid-year QLE
         → post-tax + net pay → [disbursements?] split net across accounts; NACHA batch after stub commit (ADR 0020)
         → Earnings → [tips?] validate tip lines; FLSA tip-credit make-up → classify taxable / supplemental (ADR 0008)
         → [equity?] validate RSU/NQSO; apply withholding election (ADR 0009)
         → [contractor?] skip W-2 pre-tax / tax / FICA / garnishments (ADR 0006)
         → [multi-state?] split state taxable wages by allocation % (ADR 0007)
         → apply pre-tax deductions (ordered) → taxable bases
         → federal + state income tax
         → FICA (SS + Medicare on correct bases)
         → post-tax enrollments + scheduled COBRA/arrears (capped; ADR 0010)
         → garnishments (priority, CCPA cap)
         → [webhooks?] enqueue outbox rows (same transaction as pay stub; ADR 0011)
         → [cost accounting?] persist payroll_run_allocations (ADR 0013)
         → employer contributions
         → update YTD
         → emit PayStub
```

Advanced capabilities are documented in [ROADMAP_ADVANCED.md](./ROADMAP_ADVANCED.md) (Phases A1–A10, shipped). Enterprise work continues in [ROADMAP_ENTERPRISE.md](./ROADMAP_ENTERPRISE.md) (Phases E1–E10). E7 adds employee self-service under `/api/ess/*` with `employee_self` RBAC — see [ESS.md](./ESS.md).

## Persistence

Knex migrations define employees, pay periods, earnings lines, deduction enrollments, YTD rows, pay stubs, and retro adjustment records. Tests use in-memory SQLite; production uses PostgreSQL.

Phase 2+: routes use Knex repository adapters via `createApp(deps)` (see ADR 0002). Payroll runs execute in a DB transaction (pay stub + YTD + payroll_run + earnings_lines).

## Errors & observability (Phase 1)

- Domain failures: `PayrollDomainError` with `PayrollErrorCode` → HTTP status via `errorHandler`.
- Logging: `src/logging/logger.ts` (Winston JSON); `correlationIdMiddleware` sets `x-correlation-id` on every request.
- Feature flags: `src/config/features.ts`; supported tax years: `src/config/taxYear.ts`.
- Metrics: `GET /metrics` (Prometheus); traces via `traceparent` + `x-correlation-id` ([PERFORMANCE.md](./PERFORMANCE.md)).
- Metrics: `src/metrics/hooks.ts` + `InMemoryPayrollMetrics`; batch duration via `recordBatchComplete`.
