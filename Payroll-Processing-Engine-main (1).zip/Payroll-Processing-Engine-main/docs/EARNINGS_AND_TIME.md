# Earnings & Time

## Time entries

Employees clock in/out; the engine rounds to the nearest **15 minutes** and associates entries with a pay period by `payPeriodId` or `workDate` within the period range.

| Field | Description |
|-------|-------------|
| `clockIn` / `clockOut` | ISO timestamps |
| `roundedMinutes` | Stored after rounding |
| `entryType` | `regular`, `holiday`, or `overtime_manual` |

## Hourly pay

`HourlyPayCalculator` computes `rate × hours` with **half-up** rounding to cents via `decimal.js`.

## Weekly overtime

`OvertimeAllocator` uses a **work week** starting on the jurisdiction’s `workWeekStartDay` (default **Monday**). Minutes beyond **40 hours per week** (configurable per jurisdiction) are paid at the OT multiplier (default **1.5×**).

Regular and OT earnings are emitted as separate `EarningsLine` rows (`regular`, `overtime`).

## Holiday pay

Holiday entries use the jurisdiction `holidayMultiplier` (e.g. 1.5×). Optional `FEATURE_HOLIDAY_FICA_EXEMPT=true` excludes holiday amounts from FICA taxable wages only.

## Imputed income

Group-term life coverage above **$50,000** produces imputed taxable income (simplified IRS Table I factor).

## APIs

- `POST /api/time-entries` — record time
- `POST /api/earnings/preview` — compute earnings + full payroll preview without persisting
- `POST /api/payroll/run` — persist payroll (must match preview for same inputs)

## Preview vs run

Both paths call `PayrollRunService.preview()` vs `run()` which share the same `compute()` core. Preview reads YTD without locking; run uses a transaction.
