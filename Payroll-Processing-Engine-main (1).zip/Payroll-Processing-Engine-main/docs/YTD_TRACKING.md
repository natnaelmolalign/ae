# Year-to-Date Tracking

Per employee, per calendar year:

- `gross_earnings`
- `federal_taxable_wages`, `state_taxable_wages`
- `ss_taxable_wages`, `medicare_taxable_wages`
- Each tax withheld (federal, state, SS, Medicare, Medicare additional)
- Each deduction type YTD
- Employer contribution YTD

YTD resets on January 1 for payment-year attribution: paychecks with **payment date** in the new year belong to the new YTD bucket even if the period ended in December.

Social Security withholding stops when `ss_taxable_wages` YTD reaches the wage base.

401(k) contributions reject amounts that would exceed the annual limit when YTD + current period is computed **including** the current period deduction.
