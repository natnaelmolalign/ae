# Reporting

Finance-facing exports built from persisted pay stubs and payroll runs.

## Payroll register

`GET /api/reports/payroll-register?periodId={id}`

Returns one row per payroll run in the period, plus totals. The `reconciliation` block compares register sums to direct aggregates from `pay_stubs` (must match).

## General ledger export

`GET /api/reports/gl-export?periodId={id}`

JSON body includes per-run GL lines with account codes. Append `&format=csv` for CSV download.

Each run produces balanced debit/credit lines:

- Salaries expense (gross)
- Tax and deduction payables (credits)
- Net pay payable
- Employer FICA expense and payables (including employer Social Security)

## Pay stub HTML

`GET /api/payroll/stubs/{id}/html`

Printable HTML earnings statement with current and YTD columns.
