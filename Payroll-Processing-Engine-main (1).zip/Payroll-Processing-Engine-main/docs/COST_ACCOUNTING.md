# Cost accounting & labor dimensions

Advanced Phase 8 attaches department and job dimensions to payroll runs for labor-cost reporting and segmented general ledger export.

## Data model

| Table | Purpose |
|-------|---------|
| `departments` | Company-scoped cost centers (`code`, `name`, optional `location_code`) |
| `jobs` | Optional sub-dimension under a department |
| `payroll_run_allocations` | Percent (and optional hours) per run |

System department `UNASSIGNED` is created automatically when a run has no explicit allocations (100% to unassigned bucket).

## API

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/departments` | Create department (tenant via `X-Company-Id`) |
| `GET` | `/api/departments` | List departments for company |
| `POST` | `/api/jobs` | Create job under a department |
| `GET` | `/api/jobs?departmentId=` | List jobs |
| `POST` | `/api/payroll/run` | Optional `costAllocations[]` on body |
| `GET` | `/api/reports/labor-cost?periodId=` | Department labor cost summary |
| `GET` | `/api/reports/payroll-register?periodId=` | Includes `costAllocations` per row |
| `GET` | `/api/reports/gl-export?periodId=` | CSV/JSON with `department_code`, `job_code`, `location_code` |

### Payroll run allocation

```json
"costAllocations": [
  { "departmentId": "<uuid>", "percent": "50" },
  { "departmentId": "<uuid>", "jobId": "<uuid>", "percent": "50" }
]
```

Percents must sum to **100** (±0.01 tolerance). Duplicate departments in one run are rejected.

## GL export

Each GL line is split by allocation percent. Employer FICA expense and payables are split proportionally (no double-count on the consolidated run). Each split preserves the run-level debit/credit balance.

## Feature flag

`FEATURE_COST_ACCOUNTING` — default **on** (`!== 'false'`). Set to `false` to disable allocation persistence and dimension columns.

## Related

- [REPORTING.md](./REPORTING.md)
- [ADR 0013](./adr/0013-labor-cost-allocations.md)
