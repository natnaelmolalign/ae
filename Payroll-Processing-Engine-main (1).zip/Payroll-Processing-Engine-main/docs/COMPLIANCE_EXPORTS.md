# Compliance exports (W-2, 1099-NEC, Form 941)

Advanced Phase 10 provides **read-only preview** endpoints for year-end and quarterly reconciliation. These are not IRS file submissions; they aggregate pay stubs and payroll runs for review before external filing.

## Endpoints

| Route | Query | Description |
|-------|-------|-------------|
| `GET /api/reports/w2-preview` | `taxYear` | W-2 box totals per employee (W-2 employment types only) |
| `GET /api/reports/1099-nec-preview` | `taxYear` | Nonemployee compensation per contractor; `meets600Threshold` when gross ≥ $600 |
| `GET /api/reports/941-reconciliation` | `taxYear`, `quarter` (1–4) | Federal withheld + employee/employer FICA for the quarter |

All routes require the same auth as other reports and are scoped by `X-Company-Id` / JWT `companyId`.

Feature flag: `FEATURE_COMPLIANCE_EXPORTS` (default enabled unless set to `false`).

## Classification rules

- **W-2 preview:** `employmentType` is not `contractor`. Contractors are excluded even if misclassified pay exists.
- **1099-NEC preview:** `employmentType: contractor` only. W-2 employees never appear.
- **941 reconciliation:** W-2 payroll only (federal income tax withheld + FICA). Contractors excluded.

Payment attribution uses `pay_periods.payment_date` within the tax year or calendar quarter.

## TIN handling

- Optional `tin` on `POST /api/employees` (9 digits, SSN or EIN format).
- Stored as `employees.tin_encrypted` (AES-256-GCM envelope, key id `local-v1`).
- API responses expose `tinLastFour` only; previews use `tinMasked` (`***-**-####`).
- Set `TIN_MASTER_KEY` in production; rotate per [SECURITY_CHECKLIST.md](./SECURITY_CHECKLIST.md).

## Reconciliation

W-2 preview includes `reconciliation.matches` when sum of stub gross for W-2 employees equals preview wages total.

941 preview documents that totals are derived from payroll runs joined to pay stubs in the quarter.

## Legal sign-off

> **Placeholder:** Payroll and tax leadership must sign off on preview totals before transmitting W-2/1099 data to a filing vendor. Record approval date and approver in your change ticket.

## Related

- [CONTRACTOR_PAYROLL.md](./CONTRACTOR_PAYROLL.md)
- [RUNBOOK.md](./RUNBOOK.md) — DR drill template
- ADR [0015-compliance-suite.md](./adr/0015-compliance-suite.md)
