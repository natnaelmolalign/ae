# Payroll controls & anomaly detection

Enterprise Phase E9 adds pre-run holds, statistical anomaly flags, and dual approval for outlier gross pay.

## Holds

Active holds block payroll for an employee (batch partial success unchanged — held employees fail individually).

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/payroll-controls/holds` | List active holds |
| POST | `/api/payroll-controls/holds` | Create hold |
| POST | `/api/payroll-controls/holds/:id/release` | Release with reason (audited) |

## Anomaly detection

`AnomalyDetector` compares gross pay to trailing stub history using z-score (default threshold: 3, env `ANOMALY_Z_SCORE_THRESHOLD`).

When flagged:

1. Record `anomaly_flags` row
2. Create `approval_requests` (pending)
3. Block payroll until `payroll_admin` approves

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/payroll-controls/approvals/:id/approve` | Second admin approval |
| POST | `/api/payroll-controls/approvals/:id/reject` | Reject outlier run |

## Integration points

- `PayrollBatchService.runOneEmployee` — hold + anomaly gate
- `JobWorkerService` — same gate for queued batch path

## Feature flag

`FEATURE_PAYROLL_CONTROLS=false` disables control routes and gates.
