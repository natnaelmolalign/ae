# Payroll Processing Engine — Runbook

## Deploy

1. Set required environment variables (see `.env.example` if present, or README):
   - `DATABASE_URL` — PostgreSQL connection string
   - `API_KEYS` — comma-separated `key:role` pairs for service accounts
   - `JWT_SECRET` — optional, for bearer JWT auth
   - `DEFAULT_COMPANY_ID` — default tenant when `X-Company-Id` is omitted
2. Run migrations: `npm run migrate`
3. Start the API: `npm start` (listens on `PORT`, default 3000)
4. Verify probes:
   - `GET /health` → `{ "status": "ok" }`
   - `GET /ready` → database connected

## Rollback

1. Stop traffic to the new revision (load balancer / k8s scale to zero).
2. Roll back the container image or Node deployment to the previous tag.
3. If a migration must be reversed: `npm run migrate:rollback` (only when the release notes say it is safe).
4. Confirm `/ready` and a smoke payroll run in staging before re-enabling traffic.

## Scale workers (E8)

1. Set `FEATURE_JOB_QUEUE=true` and `JOB_QUEUE_BACKEND=knex`.
2. Run worker processes: `npm run worker` (separate from API).
3. Enqueue: `POST /api/payroll/batch` with `"useQueue": true` (202 Accepted).
4. Poll `GET /api/payroll/batch/:id` until complete.
5. DLQ: `GET /api/admin/queue/dead-letters`.

## Payroll controls (E9)

- Disable: `FEATURE_PAYROLL_CONTROLS=false`
- Release holds: `POST /api/payroll-controls/holds/:id/release` (audited)

## Graceful shutdown

On `SIGTERM` / `SIGINT` the server:

1. Stops accepting new HTTP connections.
2. Waits up to 30s for in-flight payroll batch work started in this process.
3. Closes the database pool.

New batch requests during shutdown receive **503** with `SERVICE_UNAVAILABLE`.

## YTD reset procedure

1. Identify the **payment year** (not only calendar run date) — see `docs/YTD_TRACKING.md`.
2. Export current `ytd_totals` for audit.
3. Call `POST /api/admin/ytd-reset` with `{ "taxYear": 2024 }` as `payroll_admin`.
   - Returns **409** if payroll runs still exist for that payment year (safe default).
   - Use `{ "taxYear": 2024, "force": true }` only after archival and ops sign-off.
4. Prefer retro adjustments (Phase 7) for mid-year corrections instead of blanket reset.
5. Reconcile register (`GET /api/reports/payroll-register`) and GL export.

## Disaster recovery

- **RPO:** 24h (nightly DB backup assumed).
- **RTO:** 4h for API + DB restore.
- Quarterly: restore backup to staging and run migration + smoke tests documented in this runbook.

### DR drill template (quarterly)

Use this checklist in staging; record date, owner, and pass/fail in your ops ticket.

1. Restore latest production-consistent backup to staging DB.
2. Run `npm run migrate` (or start API to auto-migrate) against the restored DB.
3. Smoke: `GET /health`, `GET /ready`.
4. Smoke payroll: create employee, generate periods, `POST /api/payroll/run` for one W-2 employee.
5. Reports: `GET /api/reports/payroll-register?periodId=...`, `GET /api/reports/w2-preview?taxYear=...` (if compliance enabled).
6. Verify webhook outbox is not replaying duplicate deliveries (optional: drain worker in isolated env).
7. Document actual RTO/RPO observed vs targets above; file remediation items for gaps.

## Tax year cutover

1. Obtain final IRS/state tables for the new calendar year.
2. Update `src/data/{year}/tables.json` (or run `scripts/seed-forward-tax-years.ts` for provisional stubs, then edit).
3. Run `npm run tax:validate -- {year}` locally; ensure CI `tax:validate` passes on the PR.
4. Deploy application build (loader code) if changed; data-only PRs can ship after validation.
5. In staging, set `FEATURE_TAX_YEAR_2025=true` (or future flag) and run a smoke payroll with `paymentDate` in the new year.
6. Confirm FICA wage base and bracket spot-checks against IRS publications.
7. Enable the feature flag in production after sign-off; monitor `TAX_YEAR_UNSUPPORTED` errors in logs.
8. Do not reset YTD for a new year — YTD is keyed by payment year ([YTD_TRACKING.md](./YTD_TRACKING.md)).

See [TAX_DATA_PIPELINE.md](./TAX_DATA_PIPELINE.md).

## Contractor (1099) pay

See [CONTRACTOR_PAYROLL.md](./CONTRACTOR_PAYROLL.md). Verify `FEATURE_CONTRACTOR_PAY` is not disabled in production. Contractor runs should show zero tax on pay stubs; misclassified W-2 employees must not use `employmentType: contractor`.

## Security incidents

- Rotate `API_KEYS` and `JWT_SECRET` immediately if leaked.
- Review `GET /api/reports/audit` for suspicious `actor` / entity changes.
