# Audit trail

All mutating API calls on employees, benefit enrollments, garnishment orders, and payroll runs append an immutable row to `audit_events`.

## Fields

| Column | Description |
|--------|-------------|
| `actor` | From `X-Actor-Id` or `X-User-Id` header (default `system`) |
| `entity_type` | e.g. `employee`, `benefit_enrollment`, `pay_stub` |
| `entity_id` | Primary key of affected record |
| `action` | `create`, `update`, or `delete` |
| `before_snapshot` / `after_snapshot` | JSON state; `payload.diff` lists changed fields |

Rows are **append-only**. There is no API to update or delete audit events.

## Query

`GET /api/reports/audit?entityType=employee&entityId={uuid}`

## Retention

`AUDIT_RETENTION_DAYS` (default `2555` ≈ 7 years). Run `purgeExpiredAuditEvents()` from `src/jobs/auditRetentionJob.ts` on a schedule to prune older rows.

## Transaction boundary

Audit writes occur **after** successful HTTP handlers, not inside rolled-back DB transactions. Failed mutations do not create audit rows.
