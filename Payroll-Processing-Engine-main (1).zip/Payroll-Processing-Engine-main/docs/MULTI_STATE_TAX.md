# Multi-state wage allocation

Employees with `stateCode` set to their **residence** may earn wages in other states. Advanced Phase 2 splits **state-taxable wages** by allocation percent and withholds per jurisdiction.

## Allocation rules

- Percents are whole numbers summing to **100** (±0.01 tolerance).
- Each slice uses that state's tax table (`StateWithholdingEngine.calculateForState`).
- **No double withholding on the same dollar**: each slice is taxed only under its allocated state.

## Reciprocity (NY ↔ CT)

`src/data/2024/reciprocity.ts` documents reciprocal agreements. Because tax is computed **per slice**, a NY resident with **100% CT** allocation is taxed only at CT rates on the full check — NY does not also tax those wages on the same run.

## API

### Store default allocations

```http
PUT /api/employees/:id/work-locations
{
  "locations": [
    { "stateCode": "CT", "allocationPercent": "100", "effectiveDate": "2024-01-01" }
  ]
}
```

### Payroll run

Pass explicit allocations or omit to use stored work locations:

```http
POST /api/payroll/run
{
  "stateAllocations": [
    { "stateCode": "NY", "percent": "60" },
    { "stateCode": "TX", "percent": "40" }
  ],
  ...
}
```

Snapshots persist to `payroll_run_state_allocations` (wages + tax per state).

## Feature flag

`FEATURE_MULTI_STATE_TAX=false` disables multi-state splitting (falls back to residence `stateCode` only).
