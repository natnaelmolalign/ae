# Filing platform

Enterprise Phase E10 provides schema-oriented e-file exports built on compliance preview data.

## Exports

| Method | Path | Format |
|--------|------|--------|
| GET | `/api/filing/w2/:taxYear/xml` | W-2 XML (IRS stub namespace) |
| GET | `/api/filing/1099-nec/:taxYear/xml` | 1099-NEC XML stub |
| GET | `/api/filing/941/:taxYear/:quarter/csv` | Form 941 reconciliation CSV |

Exports are read-only aggregates; generation is tenant-scoped via `companyId`.

## Validation

CI runs `npm run filing:validate` against the W-2 stub XSD and structural checks.

## Feature flag

`FEATURE_FILING_PLATFORM=false` disables filing routes.

## Compliance sign-off

Legal/compliance review placeholder: replace stub XSD with agency-final schemas before production e-file submission.
