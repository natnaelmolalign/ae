# COBRA premiums and arrears schedules

Advanced Phase 5 adds persisted **deduction schedules** for post-employment COBRA billing and employee arrears recovery.

## Schedule types

| Type | `schedule_type` | Balance | After termination |
|------|-----------------|---------|-------------------|
| COBRA premium | `cobra_premium` | N/A (fixed per period) | Allowed (typical use case) |
| Arrears | `arrears` | `remaining_balance` decrements each run | **Skipped** when `paymentDate > terminationDate` |

## API

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/deduction-schedules` | Create schedule (audited) |
| GET | `/api/deduction-schedules?employeeId=` | List all for employee |
| GET | `/api/deduction-schedules?employeeId=&asOf=` | Active on date |
| GET | `/api/deduction-schedules/:id` | Get one |
| PATCH | `/api/deduction-schedules/:id` | Update (audited) |
| DELETE | `/api/deduction-schedules/:id` | Delete (audited) |

Payroll run with schedules:

```json
POST /api/payroll/run
{
  "useActiveDeductionSchedules": true,
  "earnings": [{ "type": "regular", "amount": "2000.00" }],
  "deductions": []
}
```

Preview scheduled amounts (with net cap):

```json
POST /api/deductions/preview
{
  "useActiveDeductionSchedules": true,
  "earnings": [{ "type": "regular", "amount": "2000.00" }]
}
```

## Arrears example

```json
POST /api/deduction-schedules
{
  "employeeId": "...",
  "scheduleType": "arrears",
  "amountPerPeriod": "100.00",
  "remainingBalance": "300.00",
  "startDate": "2024-01-01"
}
```

Three payroll runs with `useActiveDeductionSchedules: true` deduct $100, $100, $100; the fourth deducts $0.

## Ordering

Lower `priority` runs first (default: COBRA 50, arrears 100). Scheduled totals are capped so net pay does not go negative before garnishments.

## Life events (Enterprise E4)

Approving a `loss_of_coverage` qualifying life event via `POST /api/life-events/:id/approve` can create a `cobra_premium` schedule automatically. See [BENEFITS_LIFECYCLE.md](./BENEFITS_LIFECYCLE.md).

## Feature flag

`FEATURE_COBRA_ARREARS=false` disables schedule loading and payroll integration.
