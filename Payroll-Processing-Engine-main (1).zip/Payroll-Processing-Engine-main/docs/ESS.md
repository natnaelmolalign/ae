# Employee self-service (ESS)

Enterprise Phase E7 provides scoped employee-facing APIs for pay history, YTD totals, W-2 preview, and W-4 change requests with clerk approval before updates apply to the employee record.

## Auth

| Role | Scope |
|------|-------|
| `employee_self` | `/api/ess/*` only; JWT or test header must include `employeeId` |
| `payroll_clerk` / `payroll_admin` | Approve or reject pending W-4 change requests |

In test mode (auth not enforced), send `x-employee-id: <uuid>` to act as `employee_self` for that employee. Without the header, requests default to `payroll_admin`.

## W-4 change workflow

```mermaid
stateDiagram-v2
  [*] --> draft
  draft --> pending: employee submits
  pending --> applied: clerk approves
  pending --> rejected: clerk rejects
  applied --> [*]
  rejected --> [*]
```

Pending requests do **not** update employee W-4 fields until a clerk approves. Approval applies fields and records an audit event.

## API

| Method | Path | Role | Description |
|--------|------|------|-------------|
| GET | `/api/ess/me/profile` | employee_self | Current W-4 profile fields |
| GET | `/api/ess/me/pay-stubs` | employee_self | Own pay stub list |
| GET | `/api/ess/me/pay-stubs/:id` | employee_self | Single pay stub (404 if not owned) |
| GET | `/api/ess/me/ytd?taxYear=` | employee_self | YTD totals |
| GET | `/api/ess/me/w2-preview?taxYear=` | employee_self | W-2 box preview for self |
| GET | `/api/ess/me/w4-change-requests` | employee_self | List own W-4 requests |
| POST | `/api/ess/me/w4-change-requests` | employee_self | Create draft |
| GET | `/api/ess/me/w4-change-requests/:id` | employee_self | Get own request (404 if not owned) |
| POST | `/api/ess/me/w4-change-requests/:id/submit` | employee_self | Submit for review |
| GET | `/api/w4-change-requests?status=pending` | clerk/admin | Pending queue |
| POST | `/api/w4-change-requests/:id/approve` | clerk/admin | Apply W-4 to employee |
| POST | `/api/w4-change-requests/:id/reject` | clerk/admin | Reject with optional notes |

### Example

```json
POST /api/ess/me/w4-change-requests
Header: x-employee-id: <employee-uuid>
{
  "filingStatus": "married_filing_jointly",
  "w4ExtraWithholding": "50.00",
  "w4DependentsCredit": "2000.00"
}

POST /api/ess/me/w4-change-requests/<id>/submit
Header: x-employee-id: <employee-uuid>

POST /api/w4-change-requests/<id>/approve
```

## Security (BOLA)

ESS routes resolve resources by the authenticated `employeeId`. Accessing another employee's pay stub or W-4 request by ID returns **404**, not 403, to avoid leaking object existence.

## Feature flag

`FEATURE_EMPLOYEE_ESS=false` disables ESS and W-4 clerk routes.
