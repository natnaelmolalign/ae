# Workforce scheduling (Enterprise Phase E3)

Shift-based scheduling with manager approval before time flows into payroll.

## Workflow

```
pending → approved → exported_to_payroll
         ↘ rejected
```

1. Create a **shift** (`POST /api/shifts`).
2. **Assign** an employee (`POST /api/shifts/:id/assignments`).
3. Employee **clocks** via `POST /api/time-entries` with `shiftAssignmentId`.
4. Manager **approves** (`POST /api/shifts/assignments/:id/approve`) — worked minutes must be within ±15 min of scheduled.
5. **Payroll** with `useTimeEntries: true` — unapproved assignments return `TIME_NOT_APPROVED` (409).

## API

Flag: `FEATURE_WORKFORCE_SCHEDULING` (default on).

```
POST   /api/shifts
GET    /api/shifts?workDate=
POST   /api/shifts/:shiftId/assignments
GET    /api/shifts/assignments?employeeId=
POST   /api/shifts/assignments/:id/approve
POST   /api/shifts/assignments/:id/reject
```

Payroll and earnings preview accept `useTimeEntries` + `hourlyRate` (same as `/api/earnings/preview`).

## Meal break premium (California)

When `FEATURE_CA_MEAL_PENALTY=true`, shifts over 5 hours without a 30-minute break add a one-hour premium earning for CA employees.

## Time exceptions

Rejections and anomalies are stored in `time_exceptions` for audit.

## ADR

[adr/0018-workforce-scheduling.md](./adr/0018-workforce-scheduling.md)
