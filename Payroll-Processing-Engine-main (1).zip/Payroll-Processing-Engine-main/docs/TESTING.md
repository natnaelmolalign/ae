# Testing strategy

## Philosophy

Payroll bugs are **money bugs**. Tests assert **behavior**: given earnings, deductions, and YTD, expect specific withholdings, net pay, and stub reconciliation — not implementation details.

- **Unit tests** — pure services and utils (`decimal.js` math, bracket slices, garnishment caps)
- **Integration tests** — HTTP routes + SQLite persistence, multi-tenant auth, webhook delivery
- **Golden tests** — frozen JSON scenarios under `tests/golden/` for tax and advanced payroll paths
- **CI** — `npm run lint`, `npm run build`, `npm run test:coverage`, `npm run tax:validate` on every push

## How the suite grew (incremental)

Coverage expanded **with each shipped capability**, tied to roadmap exit gates — not a single end-of-project push.

| Period | Milestone | Test focus |
|--------|-----------|------------|
| **May 2025** | Foundation + CI | Core tax and earnings math; ~19 behavioral tests |
| **Jun–Jul 2025** | Persistence + hourly | Integration tests against SQLite; time entry and preview routes |
| **Aug–Oct 2025** | Benefits, garnishments, retro | Deduction limits, disposable earnings, adjustment workflows |
| **Oct–Nov 2025** | Batch, reporting, production hardening | Batch payroll, GL export, auth/tenant integration tests |
| **Nov–Dec 2025** | Advanced features | Contractor, multi-state golden files, tips, equity, COBRA, webhooks |
| **Dec 2025** | Extended service coverage | Broad unit tests across payroll services (pre-enterprise baseline) |
| **Jan–May 2026** | Enterprise modules | Per-phase unit + integration tests as each E1–E10 area shipped |
| **May 2026** | Domain coverage gate | Raised `services/` + `utils/` to 100% threshold before enterprise ship |
| **Jun 2026** | CI hygiene | Lint/format alignment; docs updated for coverage scope |

The May 2026 coverage work **closed gaps** in modules that already had behavioral tests — it did not replace integration coverage for routes and repositories.

## Coverage scope today

`jest.config.js` enforces **100%** line, branch, function, and statement coverage on:

- `src/services/**`
- `src/utils/**`

**Not** in the Jest coverage gate (covered elsewhere):

| Layer | Mechanism |
|-------|-----------|
| `src/routes/` | Integration route suites (`tests/integration/routes/`) |
| `src/repositories/` | Integration tests + migration tests |
| `src/middleware/` | Integration middleware tests |
| Migrations | `tests/integration/db/migrations.test.ts` |

Current scale: **652+ tests**, **143 suites** (unit + integration + golden).

## Running tests

```bash
npm test                 # full suite, in-band
npm run test:coverage    # with 100% gate on services/utils
npm run test:ci          # CI mode with coverage
```

## High-value regression areas

Cross-layer bugs are the highest risk in payroll. Prioritize tests (and code review) where these interact:

1. **Pre-tax ordering** — Section 125 vs 401(k) vs FICA bases
2. **YTD + wage bases** — Social Security cap, 401(k) limits mid-year
3. **Multi-state allocation** — split taxable wages vs reciprocity
4. **Garnishment priority** — child support before creditor; disposable earnings base
5. **Tip credit make-up** — FLSA minimum wage vs cash wage ordering
6. **Retro adjustments** — correction stubs and YTD cascade
7. **Batch finalization** — queue worker counts vs webhook outbox

See per-domain **Regression focus areas** sections in the roadmaps and domain docs (e.g. [GARNISHMENTS.md](./GARNISHMENTS.md)).

## Adding tests for new features

1. Unit-test pure functions first (utils, calculators, evaluators).
2. Add integration test for the HTTP boundary and tenant scoping.
3. Add a golden fixture if the scenario is tax-sensitive or multi-step.
4. Update this doc only when coverage **policy** changes — not every new test file.
