# Disbursements & payments

Enterprise Phase E5 splits net pay across employee accounts, generates NACHA ACH files, and reconciles payment batches against payroll liabilities.

## Concepts

| Entity | Purpose |
|--------|---------|
| `disbursement_instructions` | Per-employee split rules (% / fixed / remainder) |
| `payment_batches` | Group of payroll runs ready for ACH submission |
| `payment_batch_items` | Individual credit lines per account |
| `ach_files` | Generated NACHA file with control totals |

Account numbers are **tokenized at rest** (`tok_acct_*`); only `accountLastFour` is stored for display.

## Split rules

| `splitType` | Behavior |
|-------------|----------|
| `percent` | `percent` of net pay (e.g. `0.60` = 60%) |
| `fixed` | Fixed amount per period, capped at remaining net |
| `remainder` | Receives leftover balance (at most one per employee) |

Splits must sum to net pay exactly (decimal-safe). Lower `priority` runs first.

## API

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/disbursement-instructions` | Create split instruction |
| GET | `/api/disbursement-instructions?employeeId=` | List instructions |
| PATCH | `/api/disbursement-instructions/:id` | Update instruction |
| DELETE | `/api/disbursement-instructions/:id` | Remove instruction |
| POST | `/api/payment-batches` | Build batch from pay period or run IDs |
| GET | `/api/payment-batches/:id` | Get batch |
| POST | `/api/payment-batches/:id/submit` | Generate NACHA + submit |
| GET | `/api/payment-batches/:id/reconciliation` | Liabilities vs ACH totals |
| GET | `/api/payment-batches/:id/ach-file` | Retrieve generated file |

### Example: two-account split + remainder

```json
POST /api/disbursement-instructions
{ "splitType": "percent", "percent": "0.60", "priority": 1, ... }

POST /api/disbursement-instructions
{ "splitType": "fixed", "fixedAmount": "200.00", "priority": 2, ... }

POST /api/disbursement-instructions
{ "splitType": "remainder", "priority": 3, ... }

POST /api/payment-batches
{ "payPeriodId": "2024-semimonthly-1" }

POST /api/payment-batches/{id}/submit
{
  "companyRouting": "021000021",
  "companyAccount": "9999888877776666",
  "companyName": "ACME PAYROLL",
  "effectiveDate": "2024-01-15"
}
```

Net pay `$1000.00` → `$600.00` + `$200.00` + `$200.00`.

## NACHA

`NachaFileBuilder` produces balanced PPD/CCD files. Batch control **entry hash** equals the sum of receiving DFI identifiers modulo 10¹⁰.

## Webhooks

`payment.batch.submitted` fires after successful batch submission (via outbox retry on delivery failure). Pay stubs are **never rolled back** if disbursement submission fails afterward.

## Feature flag

`FEATURE_DISBURSEMENTS=false` disables disbursement routes.
