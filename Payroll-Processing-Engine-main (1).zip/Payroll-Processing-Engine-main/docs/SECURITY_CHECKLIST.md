# Security checklist v2 (Enterprise E10)

Advanced Phase 10 baseline plus enterprise filing and plugin controls.

| # | Risk | Control in this codebase | Status |
|---|------|--------------------------|--------|
| API1 | Broken object level authorization | `companyId` on `req.auth`; `employeeForTenant` and report queries filter by tenant | Done |
| API2 | Broken authentication | API keys + JWT; `authEnforced` in production | Done |
| API3 | Broken object property level authorization | No mass assignment on employees; Zod schemas on routes | Done |
| API4 | Unrestricted resource consumption | Batch size limits; k6 SLOs (Phase 9) | Done |
| API5 | Broken function level authorization | RBAC roles (`payroll_admin`, `payroll_clerk`); admin routes gated | Done |
| API6 | Unrestricted access to sensitive business flows | Payroll run idempotency; audit on mutations | Done |
| API7 | Server side request forgery | Webhooks validate URLs in subscription service | Done |
| API8 | Security misconfiguration | Helmet, CORS, production env validation | Done |
| API9 | Improper inventory management | OpenAPI / route docs per phase | Done |
| API10 | Unsafe consumption of APIs | HMAC webhook signatures; constant-time compare | Done |

## PII and secrets

| Item | Status | Notes |
|------|--------|-------|
| TIN encrypted at rest (`tin_encrypted`) | Done | `TIN_MASTER_KEY`; KMS envelope planned for production |
| TIN never logged | Done | Previews use masked values only |
| Plugin sandbox timeout | Done | `PluginHost` default 500ms; E10 |
| Filing export tenant scope | Done | `companyId` on all filing routes |
| Queue DLQ monitoring | Done | `queue_dlq_total` Prometheus metric |
| API_KEYS / JWT_SECRET rotation | Done | Documented in RUNBOOK |

## Penetration test backlog

| Severity | Count | Notes |
|----------|-------|-------|
| Critical | 0 | Phase 10 baseline — no open Critical |
| High | 0 | Phase 10 baseline — no open High |
| Medium | — | Track in issue tracker per release |

## Coverage gate

Jest enforces **100%** line, branch, function, and statement coverage on **`src/services/**`** and **`src/utils/**`** (see `collectCoverageFrom` in `jest.config.js`). The suite grew incrementally with each shipped capability; see [TESTING.md](./TESTING.md). Routes, repositories, middleware, and migrations are exercised by **integration tests**, not the unit coverage metric.

| Layer | Coverage mechanism |
|-------|-------------------|
| `src/services/`, `src/utils/` | Unit tests — 100% threshold (652+ tests) |
| `src/routes/`, `src/repositories/` | Integration tests (~25 route suites) |
| Migrations | `tests/integration/db/migrations.test.ts` |

## Waivers

None for Phase 10 ship. Future KMS-backed TIN keys: waive local `local-v1` key only after KMS ADR is accepted.
