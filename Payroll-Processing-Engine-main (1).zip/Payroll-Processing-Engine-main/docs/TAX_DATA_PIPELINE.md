# Tax data pipeline

Advanced Phase 7 loads versioned tax parameters from JSON packs under `src/data/{taxYear}/tables.json`, validates them at startup and in CI, and activates forward years behind feature flags.

## Layout

```
src/data/
  schema/taxTables.schema.json   # JSON Schema (draft-07)
  2024/tables.json               # production year
  2025/tables.json               # provisional stub (IRS not final)
  2026/tables.json               # provisional stub
  2024/*.ts                      # legacy TS sources (export reference)
```

## Validation

- **Runtime:** `TaxTableLoader` validates each pack with JSON Schema (Ajv) and Zod (`TaxTableSchema.ts`).
- **CLI:** `npm run tax:validate` — all discovered years; `npm run tax:validate -- 2025` — single year.
- **CI:** `npm run tax:validate` runs on every push/PR.

Invalid packs fail with path + message per issue (no silent fallback).

## Payment date → tax year

`TaxYearService.getYearTablesForPaymentDate(paymentDate)` uses the **calendar year of the payment date** only (`paymentDate.slice(0, 4)`). Retro runs with a 2024 check date always use 2024 tables, even if processed later.

## Feature flags

| Variable | Default | Effect |
|----------|---------|--------|
| `FEATURE_TAX_YEAR_2025` | `false` | When `true`, enables 2025 and 2026 packs for payroll |

Production should enable forward years only after ops sign-off and final IRS tables are loaded.

## Hot reload (development)

In `NODE_ENV=development`, `TaxTableLoader` skips caching so edits to `tables.json` apply on the next payroll run. Call `defaultTaxYearService.reloadTables()` after bulk edits, or set `TAX_TABLE_HOT_RELOAD=true` in any environment to disable caching.

## Adding or updating a year

1. Copy prior `tables.json` or run `npx ts-node --transpile-only scripts/seed-forward-tax-years.ts` after updating `2024/tables.json`.
2. Edit brackets, wage bases, and state rows; keep `taxYear` equal to the directory name.
3. Run `npm run tax:validate -- {year}`.
4. Enable `FEATURE_TAX_YEAR_2025` (or extend flags) in staging, smoke a payroll run on a payment date in that year.
5. Follow [RUNBOOK.md](./RUNBOOK.md#tax-year-cutover).

## Export from TypeScript (legacy)

To regenerate `2024/tables.json` from TS modules:

```bash
npx ts-node --transpile-only scripts/export-tax-tables-json.ts 2024
```

## Related

- [ADR 0004](./adr/0004-tax-year-versioning.md) (amended)
- [ADR 0012](./adr/0012-tax-data-pipeline.md)
- [TAX_CALCULATION_RULES.md](./TAX_CALCULATION_RULES.md)
