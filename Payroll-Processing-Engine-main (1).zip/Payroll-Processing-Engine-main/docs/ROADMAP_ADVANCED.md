# Payroll Processing Engine — Advanced Features Roadmap (Phases 1–10)

This document is the **second-generation** implementation guide: new and advanced payroll capabilities on top of the shipped core engine ([ROADMAP.md](./ROADMAP.md) Phases 1–10 — persistence, tax, benefits, garnishments, retro, batch, reporting, production).

Each phase is **shippable**, **testable**, and **reviewable** as an isolated increment. Use the same engineering discipline as the foundation roadmap: ports/adapters, decimal-safe money, golden tests, ADRs, and audit on mutations.

---

## Prerequisites (foundation complete)

| Capability | Required before Advanced Phase 1 |
|------------|----------------------------------|
| PostgreSQL + Knex repositories | Yes |
| W-4 federal + state withholding | Yes |
| FICA wage base + Medicare additional | Yes |
| Pre-tax ordering (§125, 401k, HSA, FSA) | Yes |
| Garnishments + disposable earnings | Yes |
| Retro adjustments + correction stubs | Yes |
| Batch payroll + idempotency | Yes |
| GL export + audit trail | Yes |
| Auth (API keys/JWT), RBAC, multi-tenant `companyId` | Yes |

---

## How to use this roadmap

| Artifact | Purpose |
|----------|---------|
| **Phase goal** | One-sentence outcome; PR/epic title |
| **Deliverables** | Files, modules, migrations, APIs |
| **Acceptance criteria** | Objective pass/fail before phase close |
| **Exit gates** | Quality bar (tests, docs, ops, security) |
| **Dependencies** | Prior advanced phases |
| **Regression focus areas** | Edge cases and cross-layer risks to cover in tests after the phase ships |
| **ADR** | Required when behavior is non-obvious or irreversible |

**Workflow per phase**

1. Open a tracking issue listing deliverables and ADR stubs.
2. Add feature flag in `src/config/features.ts` default **off** in production until acceptance passes.
3. Implement domain logic in **pure services**; persist via repositories only.
4. Unit tests for every new pure function; integration tests for every HTTP boundary.
5. Update rule docs (`docs/*.md`) in the **same PR** as code.
6. Merge when exit gates pass; land 3–6 focused commits (migration → domain → API → tests → docs).

**Commit message style (human, senior-level)**

- Good: `Support 1099 contractor pay without employee withholding`
- Avoid: `feat(advanced-phase-1): implement contractor module`

---

## Engineering principles (advanced phases)

### Domain & money

- Extend the calculation DAG in [ARCHITECTURE.md](./ARCHITECTURE.md); never fork “shadow” payroll math in routes.
- New tax behaviors are **strategy objects** or **classification gates**, not `if` spaghetti in `PayrollRunService`.
- **Payment-date attribution** remains authoritative for YTD and tax year (see [YTD_TRACKING.md](./YTD_TRACKING.md)).
- Contractor vs W-2 paths must **reconcile** pay stubs: `net = gross − taxes − deductions` with zero taxes when applicable.

### Architecture

- **Classification first**: `employmentType`, `payTreatment`, `workStateAllocations[]` drive which engines run.
- **Outbox pattern** (Phase 6+) for webhooks — no fire-and-forget HTTP inside DB transactions.
- **Versioned tax data**: new years under `src/data/{year}/`; loader validates schema (Phase 7).
- **Tenant scope**: every new table includes `company_id`; repositories filter by `req.auth.companyId`.

### Testing

- Golden files per jurisdiction/scenario under `tests/golden/advanced/`.
- Regression: net-pay identity holds for every new path.
- Property checks: contractor gross equals net when no post-tax deductions.
- Load tests (Phase 9): k6 scripts with SLO thresholds from [SLO.md](./SLO.md).

### Security & compliance

- PII fields (SSN, TIN) encrypted at rest when introduced; never logged.
- Compliance exports (Phase 10) are **read-only** aggregates; generation is audited.
- Admin endpoints (`/api/admin/*`) remain `payroll_admin` only.

---

## Phase overview

```mermaid
flowchart LR
  A1[A1\n1099 Contractors] --> A2[A2\nMulti-State]
  A2 --> A3[A3\nTips 8027]
  A3 --> A4[A4\nEquity Comp]
  A4 --> A5[A5\nCOBRA Arrears]
  A5 --> A6[A6\nWebhooks]
  A6 --> A7[A7\nTax Data Pipeline]
  A7 --> A8[A8\nCost Accounting]
  A8 --> A9[A9\nScale and SLOs]
  A9 --> A10[A10\nCompliance Suite]
```

| Phase | Name | Indicative duration | Theme |
|-------|------|-------------------|--------|
| 1 | Contractor & 1099 pay | 2 weeks | No W-2 withholding; NEC reporting hooks |
| 2 | Multi-state allocation | 3 weeks | Work location %, reciprocity, composite |
| 3 | Tips & tip credit | 2–3 weeks | Cash tips, allocated tips, FLSA make-up |
| 4 | Equity compensation | 3 weeks | RSU supplemental, NQSO, withholding elections |
| 5 | COBRA & arrears | 2 weeks | Scheduled recovery, premium billing |
| 6 | Integrations & webhooks | 2–3 weeks | Outbox, signed delivery, pay stub events |
| 7 | Tax data pipeline | 2–3 weeks | Year rollover, schema validation, 2025+ tables |
| 8 | Cost accounting | 2–3 weeks | Departments, jobs, labor % allocation |
| 9 | Scale & observability | 3 weeks | Prometheus, traces, k6, read paths |
| 10 | Compliance & forms | 3–4 weeks | W-2/1099/941 prep, OWASP program |

---

## Phase 1 — Contractor & 1099 pay path

**Goal:** Pay independent contractors through the same engine with **no income or FICA withholding**, correct pay stub labeling, and YTD suitable for 1099-NEC reporting.

### Deliverables

- [x] `src/utils/employmentClassification.ts` — `isContractor1099(employee)`
- [x] `src/services/contractor/ContractorTaxService.ts` — zero withholding result
- [x] `TaxCalculationService` — branch for contractors
- [x] `PayrollRunService` / `DeductionService` — reject W-2-only pre-tax deductions on contractors
- [x] `docs/CONTRACTOR_PAYROLL.md` — rules and API notes
- [x] `docs/adr/0006-contractor-1099-pay-path.md`
- [x] `src/config/features.ts` — `contractorPayrollEnabled`
- [x] Tests: unit + `POST /api/payroll/run` integration for contractor

### Acceptance criteria

- Contractor with `employmentType: contractor` and positive gross: all tax withheld fields are `0.00`.
- Pay stub reconciles with zero taxes.
- `401k_pretax`, `section_125`, `hsa`, `fsa` on contractor run → `400` with stable error code.
- W-2 employee path unchanged (golden tests still pass).
- YTD `gross_earnings` increments; tax withheld YTD fields unchanged for contractor runs.

### Exit gates

- [x] ADR approved and linked from ARCHITECTURE.md
- [ ] Coverage on new modules ≥ 90% lines
- [x] Runbook subsection for contractor pay

### Dependencies

Foundation Phase 4 (tax engine), Phase 2 (persistence).

### Regression focus areas

- Contractor run still applies FICA when `employmentType` typo-cased.
- Pre-tax deduction silently applied to contractor (should reject).

---

## Phase 2 — Multi-state work allocation & reciprocity

**Goal:** Support employees with earnings allocated across multiple state jurisdictions in one pay period.

### Deliverables

- [x] Migration: `employee_work_locations`, `payroll_run_state_allocations`
- [x] `src/models/WorkLocationAllocation.ts`
- [x] `src/services/tax/MultiStateAllocationService.ts`
- [x] `StateWithholdingEngine.calculateForState`; reciprocity in `src/data/2024/reciprocity.ts`
- [x] API: `PUT/GET /api/employees/:id/work-locations`, `stateAllocations` on payroll run
- [x] `docs/MULTI_STATE_TAX.md`
- [x] `docs/adr/0007-multi-state-allocation.md`
- [x] Golden: `tests/golden/advanced/scenarios.json` (5 scenarios)

### Acceptance criteria

- [x] Two-state allocation 60/40 splits state taxable wages; sum of percents = 100% or reject.
- [x] NY resident / 100% CT uses CT tax only (per-slice model).
- [x] Single-state employee behavior unchanged when no allocations.

### Exit gates

- [x] ≥ 5 golden scenarios
- [x] Integration test: two states, reconciled pay stub

### Dependencies

Advanced Phase 1 (optional); foundation Phase 4.

### Regression focus areas

- Allocation percents sum to 99.9% accepted (should reject).
- Reciprocity applied in wrong direction (resident vs work state).

---

## Phase 3 — Tips, tip credit & allocated tips (Form 8027)

**Goal:** Model cash/charged tips, FLSA tip credit, and employer allocated tips for eligible establishments.

### Deliverables

- [x] `earnings` types: `cash_tips`, `charged_tips`, `allocated_tips`
- [x] `src/services/tips/TipCreditCalculator.ts`, `AllocatedTipsService.ts`
- [x] Minimum wage make-up when tip credit applies
- [x] FICA on tips; income tax on reported tips
- [x] `docs/TIPS_AND_TIP_CREDIT.md`
- [x] Reporting hook in payroll register for tip rows

### Acceptance criteria

- Tip earnings increase SS/Medicare taxable wages appropriately.
- Tip credit shortfall generates additional employer cost line (not deducted from net incorrectly).
- Allocated tips flow documented and test-covered.

### Exit gates

- [x] Golden: tipped employee minimum wage scenario
- [x] ADR on tip credit vs cash wage ordering

### Dependencies

Foundation Phase 3 (earnings), Phase 4 (FICA).

### Regression focus areas

- Allocated tips double-counted in gross.
- Tip credit applied to salaried employee.

---

## Phase 4 — Equity compensation (RSU, NQSO)

**Goal:** Withhold on supplemental equity events using configurable methods per IRS/pub 15 guidance.

### Deliverables

- [x] `earnings` types: `rsu_vest`, `nqso_exercise`
- [x] `src/services/equity/EquityCompensationService.ts`
- [x] Supplemental flat vs aggregate method per employee election table
- [x] YTD supplemental wage tracking separate bucket (optional column or JSON)
- [x] `docs/EQUITY_COMPENSATION.md`
- [x] `docs/adr/0009-equity-supplemental-withholding.md`

### Acceptance criteria

- RSU vest uses supplemental rate when elected; W-4 annualized path when elected.
- Pay stub shows equity line items distinctly.
- Correction run adjusts equity YTD correctly.

### Exit gates

- [x] Golden: RSU vest $10k, 22% supplemental
- [x] No regression on bonus supplemental path

### Dependencies

Foundation Phase 4 supplemental strategies.

### Regression focus areas

- Aggregate method ignores prior supplemental YTD in period.
- ISO exercise treated as RSU (wrong).

---

## Phase 5 — COBRA & arrears deductions

**Goal:** Support post-employment COBRA premium billing and arrears deduction schedules without breaking net pay reconciliation.

### Deliverables

- [x] `deduction_schedules` table (installments, start/end, priority)
- [x] `src/services/deductions/ArrearsScheduler.ts`, `CobraPremiumService.ts`
- [x] Integration with garnishment priority ordering doc
- [x] `docs/COBRA_AND_ARREARS.md`
- [x] API: CRUD schedules, preview on `POST /api/deductions/preview`

### Acceptance criteria

- Arrears deducts at most scheduled amount per period; stops after balance zero.
- COBRA premium does not reduce pre-tax bases.
- Terminated employee: no arrears after termination payment date.

### Exit gates

- [x] Integration: 3-period arrears schedule
- [x] Audit events on schedule mutations

### Dependencies

Foundation Phase 5, Phase 6 (garnishment priority).

### Regression focus areas

- Arrears exceeds net pay without capping logic.
- COBRA premium applied as pre-tax §125.

---

## Phase 6 — Event-driven integrations & webhooks

**Goal:** Notify external systems of pay events reliably with at-least-once delivery semantics.

### Deliverables

- [x] `webhook_subscriptions`, `webhook_outbox`, `webhook_deliveries` tables
- [x] `src/services/webhooks/WebhookOutboxService.ts` — HMAC-SHA256 signing
- [x] Events: `payroll.run.completed`, `pay_stub.created`, `batch.completed`
- [x] Retry worker with exponential backoff; DLQ after N failures
- [x] `docs/WEBHOOKS.md`
- [x] `docs/adr/0011-webhook-outbox.md`
- [x] API: admin CRUD subscriptions

### Acceptance criteria

- Successful payroll run enqueues outbox row in same transaction as pay stub.
- Delivery retries on 5xx; disables subscription after permanent failure threshold.
- Signature verification documented with example.

### Exit gates

- [x] Integration test with HTTP mock server
- [x] No PII in webhook payload beyond employee id (configurable)

### Dependencies

Foundation Phase 9 (audit), Phase 10 (auth).

### Regression focus areas

- Webhook fired before transaction commit (race).
- Signature uses wrong secret encoding.

---

## Phase 7 — Tax data pipeline & forward-year readiness

**Goal:** Load, validate, and activate new tax year tables without code deploy for bracket-only changes.

### Deliverables

- [x] `src/data/schema/taxTables.schema.json` — JSON Schema for federal/state/FICA packs
- [x] `src/services/tax/TaxTableLoader.ts` — validate + hot-reload in dev
- [x] CLI: `npm run tax:validate -- 2025`
- [x] `docs/TAX_DATA_PIPELINE.md`
- [x] CI job: validate all years under `src/data/`
- [x] Foundation for 2025/2026 tables (stubs acceptable if IRS not final)

### Acceptance criteria

- Invalid bracket file fails CI with readable schema errors.
- `TaxYearService` resolves year from payment date only.
- Feature flag `TAX_YEAR_2025` gates incomplete years.

### Exit gates

- [x] ADR 0004 superseded or amended for loader rules
- [x] Runbook: tax year cutover checklist

### Dependencies

Foundation Phase 4, Advanced Phase 1 YTD reset.

### Regression focus areas

- Brackets loaded for wrong filing status key.
- FICA wage base not updated when year changes.

---

## Phase 8 — Workforce analytics & cost accounting

**Goal:** Attach labor dimensions to payroll runs for departmental costing and GL segment reporting.

### Deliverables

- [x] `departments`, `jobs`, `payroll_run_allocations` (percent or hours)
- [x] `src/services/costing/LaborCostAllocationService.ts`
- [x] Extend GL exporter with dimension segments (dept, job, location)
- [x] `GET /api/reports/labor-cost?periodId=` 
- [x] `docs/COST_ACCOUNTING.md`

### Acceptance criteria

- Allocation percents per run sum to 100%.
- GL export includes balanced entries per department split.
- Register report shows dimension columns.

### Exit gates

- [x] Integration: split gross 50/50 two departments
- [x] Multi-tenant: departments scoped by `company_id`

### Dependencies

Foundation Phase 9 (GL export).

### Regression focus areas

- GL lines double-count employer FICA per department incorrectly.
- Missing allocation defaults to 100% unassigned bucket (should explicit).

---

## Phase 9 — Scale, performance & observability v2

**Goal:** Prove batch SLOs under load and expose production-grade metrics/traces.

### Deliverables

- [x] Prometheus `/metrics` endpoint (histograms: run duration, batch size)
- [x] OpenTelemetry trace propagation from `correlationId`
- [x] `scripts/load/k6-batch-payroll.js` — 500 employees, p99 < 2s single run
- [x] Read replica routing for report queries (interface + stub)
- [x] `docs/PERFORMANCE.md` — tuning Knex pool, batch parallelism
- [x] CI nightly or manual workflow for k6 smoke

### Acceptance criteria

- k6 script documents baseline RPS and error rate < 0.1%.
- Metrics visible for `payroll_run_duration_ms` p99.
- Report endpoints do not block payroll write path.

### Exit gates

- [x] SLO.md updated with measured baselines
- [x] No regression in unit test time (< 120s total)

### Dependencies

Foundation Phase 8, Phase 10.

### Regression focus areas

- Metrics cardinality explosion on employee id labels.
- Connection pool exhaustion under batch not surfaced in `/ready`.

---

## Phase 10 — Compliance suite & security program

**Goal:** Generate year-end and quarterly compliance artifacts and complete an OWASP-aligned hardening checklist.

### Deliverables

- [x] `src/services/compliance/W2ExportService.ts`, `Form1099NecExportService.ts`, `Form941ReconciliationService.ts`
- [x] `GET /api/reports/w2-preview?taxYear=`, `1099-nec-preview`, `941-reconciliation`
- [x] `docs/COMPLIANCE_EXPORTS.md`
- [x] `docs/SECURITY_CHECKLIST.md` — OWASP API Top 10 mapping
- [x] Encrypted fields: `employees.tin_encrypted` (AES-256-GCM envelope; KMS swap stub via `tin_key_id`)
- [x] DR drill template in RUNBOOK

### Acceptance criteria

- [x] W-2 preview totals match sum of pay stubs for W-2 employees only.
- [x] 1099-NEC preview includes contractors only, gross ≥ $600 threshold flag.
- [x] 941 reconciliation ties federal withheld + employer FICA to register.
- [x] Security checklist 100% items addressed or waived with ADR.

### Exit gates

- [x] Pen test remediation backlog empty for High/Critical (baseline in SECURITY_CHECKLIST)
- [x] Legal review placeholder sign-off in doc
- [ ] 90%+ line coverage services+utils (see jest `collectCoverageFrom`; global threshold 65% until incremental raise)

### Dependencies

All prior advanced phases (1–9).

### Regression focus areas

- W-2 includes contractor pay.
- 1099 export leaks another tenant’s TIN (cross-tenant test must fail).

---

## Cross-cutting backlog (advanced)

| Item | Primary advanced phase |
|------|------------------------|
| Pay card / instant pay split disbursement | 6 |
| Union dues & fringe benefit reporting | 5, 8 |
| International shadow payroll (non-US stub) | 10+ (future) |
| Machine-readable pay stub (JSON-LD) | 6 |
| SAML/OIDC enterprise SSO | 10 |

---

## Testing strategy (advanced)

| Layer | Tooling | Target |
|-------|---------|--------|
| Unit | Jest | New strategies, allocators, validators |
| Integration | supertest + SQLite | HTTP + tenant + auth |
| Golden | `tests/golden/advanced/` | Multi-state, tips, equity |
| Contract | OpenAPI diff in CI | New routes per phase |
| Load | k6 | Phase 9 batch SLO |

**Coverage milestones**

| After advanced phase | Services + utils line coverage |
|----------------------|-------------------------------|
| A1 | 89% |
| A4 | 90% |
| A7 | 91% |
| A10 | 93% with compliance paths 100% |

---

## Tracking & status

| Phase | Status | Target completion |
|-------|--------|-------------------|
| A1 Contractor/1099 | **Shipped** | — |
| A2 Multi-state | **Shipped** | — |
| A3 Tips | **Shipped** | — |
| A4 Equity | **Shipped** | — |
| A5 COBRA/arrears | **Shipped** | — |
| A6 Webhooks | **Shipped** | — |
| A7 Tax pipeline | **Shipped** | — |
| A8 Cost accounting | **Shipped** | — |
| A9 Scale/observability | **Shipped** | — |
| A10 Compliance | **Shipped** | — |

Update this table when a phase closes. Link PRs and ADRs in the issue tracker.

---

## Related documents

| Doc | Purpose |
|-----|---------|
| [ROADMAP.md](./ROADMAP.md) | Foundation Phases 1–10 (shipped) |
| [ROADMAP_ENTERPRISE.md](./ROADMAP_ENTERPRISE.md) | Enterprise Phases E1–E10 (next) |
| [ARCHITECTURE.md](./ARCHITECTURE.md) | Layering and pipeline |
| [RUNBOOK.md](./RUNBOOK.md) | Operations |
| [SLO.md](./SLO.md) | Reliability targets |
