# Performance & observability

Advanced Phase 9 adds Prometheus metrics, W3C trace propagation, read-replica routing for reports, and load-test tooling.

## Metrics (`GET /metrics`)

Enabled when `FEATURE_PROMETHEUS_METRICS` is not `false` (default on). Scraped without auth on the internal network.

| Metric                      | Type      | Labels                           | Notes                     |
| --------------------------- | --------- | -------------------------------- | ------------------------- |
| `payroll_run_duration_ms`   | histogram | `source` (api\|batch), `status`  | SLO: p99 < 2000ms         |
| `payroll_run_errors_total`  | counter   | `code`                           | Domain error codes only   |
| `payroll_batch_duration_ms` | histogram | `status`                         | Wall time for full batch  |
| `payroll_batch_size`        | histogram | —                                | Employee count per batch  |
| `http_request_duration_ms`  | histogram | `method`, `route`, `status_code` | UUIDs normalized to `:id` |

**Cardinality:** never label metrics with `employee_id` or `batch_id`.

## Tracing

`correlationIdMiddleware` sets:

- `x-correlation-id` — request id (client may supply)
- `traceparent` — W3C format derived from correlation id or upstream trace

Logs include both fields for correlation with OpenTelemetry collectors. Wire an OTEL SDK exporter in the deployment layer using the same `traceparent` header.

## Read replica (reports)

- `FEATURE_READ_REPLICA=true` and `DB_READ_REPLICA_URL` — reserved for a dedicated read pool
- **Current stub:** `DatabaseRouter.reader` uses the writer until replica Knex config is added
- `ReportingService` (register, GL, labor-cost) uses `reader` so report traffic can be isolated later

Payroll writes always use `deps.db` (writer).

## Knex pool tuning

Default PostgreSQL pool: `min: 1`, `max: 10` in `src/config/database.ts`.

| Workload            | Suggested `max` | `parallelLimit` (batch) |
| ------------------- | --------------- | ----------------------- |
| Dev                 | 10              | 4                       |
| Batch 500 employees | 20–30           | 8–16                    |
| API-only            | 10              | —                       |

`/ready` returns **503** when the pool is saturated (`free === 0` and pending acquires > 0).

## Load tests

### In-process batch (100 employees)

```bash
npm run load:batch
```

### k6 HTTP smoke

```bash
# Install k6: https://k6.io/docs/get-started/installation/
k6 run scripts/load/k6-batch-payroll.js

# With payroll run latency (after seeding one employee + period):
k6 run \
  -e EMPLOYEE_ID=<uuid> \
  -e PAY_PERIOD_ID=2024-monthly-1 \
  scripts/load/k6-batch-payroll.js
```

GitHub Actions: `.github/workflows/k6-smoke.yml` (manual `workflow_dispatch`).

## Related

- [SLO.md](./SLO.md)
- [RUNBOOK.md](./RUNBOOK.md)
- [ADR 0014](./adr/0014-observability-v2.md)
