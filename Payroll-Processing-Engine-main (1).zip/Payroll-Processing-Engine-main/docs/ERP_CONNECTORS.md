# ERP & accounting connectors

Enterprise Phase E6 exports balanced GL journals to NetSuite and QuickBooks via pluggable connector adapters with versioned account mappings and idempotent replay.

## Concepts

| Entity | Purpose |
|--------|---------|
| `integration_connections` | Registered ERP connector (NetSuite, QuickBooks, SAP) |
| `gl_account_mappings` | Versioned internal → external account map |
| `export_batches` | Immutable snapshot of mapping + connector payload per export |

## Flow

1. Create an integration connection.
2. Publish GL account mappings (creates a new version; prior versions are retained).
3. Run payroll and verify GL export balances (`GET /api/reports/gl-export`).
4. POST `/api/erp-exports` with an `idempotencyKey` — transforms GL lines through mappings and submits to the connector stub.
5. Re-post with the same key returns the existing batch without duplicating connector journals.

## API

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/integration-connections` | Register connector |
| GET | `/api/integration-connections` | List connections |
| POST | `/api/gl-account-mappings` | Publish mapping version |
| GET | `/api/gl-account-mappings?connectionId=` | Active mappings |
| GET | `/api/gl-account-mappings?connectionId=&version=` | Historical version |
| POST | `/api/erp-exports` | Export pay period to connector |
| GET | `/api/erp-exports/:id` | Get export batch snapshot |

### Example

```json
POST /api/integration-connections
{ "connectorType": "netsuite", "name": "NetSuite Prod" }

POST /api/gl-account-mappings
{
  "connectionId": "...",
  "mappings": [
    {
      "internalAccountCode": "5100",
      "externalAccountId": "NS-5100",
      "externalAccountName": "Salaries Expense"
    }
  ]
}

POST /api/erp-exports
{
  "connectionId": "...",
  "payPeriodId": "2024-monthly-1",
  "idempotencyKey": "2024-monthly-1-export"
}
```

## Connectors

| Adapter | Status |
|---------|--------|
| `NetSuiteStub` | Journal entry format with department/class segments |
| `QuickBooksStub` | JournalEntry with AccountRef lines |
| SAP | Planned |

Mapping snapshots on `export_batches` preserve historical exports when mappings change.

## Feature flag

`FEATURE_ERP_CONNECTORS=false` disables ERP connector routes.
