# Retroactive Adjustments

When a change is effective in a past period, the engine recomputes affected periods, updates YTD with net deltas, and posts a single catch-up on the current open period.

## State machine

```mermaid
stateDiagram-v2
  [*] --> draft: POST /api/adjustments
  draft --> previewed: POST /:id/preview
  previewed --> approved: POST /:id/approve
  approved --> applied: POST /:id/apply
  applied --> [*]
```

| Status | Meaning |
|--------|---------|
| `draft` | Adjustment recorded; no payroll changes |
| `previewed` | Deltas computed and stored on the record |
| `approved` | Human/system approval to apply |
| `applied` | Past-period corrections and catch-up stub posted |

## Processing steps

1. **Identify periods** — From `effectiveDate` through `currentPayPeriodId`, excluding periods after termination payment date.
2. **Preview** — Walk periods in order with simulated YTD; for each period compare recomputed amounts to the original stub (`is_correction = false`).
3. **Apply past periods** — For each past period with an original stub, run payroll with `is_correction: true` and `correction_original_gross` from the original.
4. **Catch-up** — On the current period, post one net-only correction stub linked via `corrects_pay_stub_id`.
5. **Negative net** — If total catch-up is negative, `negative_net_recovery` is set for recovery on the next check.

## API

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/adjustments` | Create draft |
| POST | `/api/adjustments/:id/preview` | Body: `{ year, frequency }` |
| POST | `/api/adjustments/:id/approve` | Approve |
| POST | `/api/adjustments/:id/apply` | Body: `{ year, frequency }` |
| POST | `/api/adjustments/run` | Legacy one-shot (draft → apply) |
| GET | `/api/adjustments/:id` | Fetch record |

## Rules

- Correction entries reference original pay stubs and use `is_correction: true`.
- Gross YTD uses delta accounting only; catch-up stubs do not add gross again.
- Adjustments are blocked when the current period payment date is after termination.

See [ADR 0005](./adr/0005-correction-stub-accounting.md).
