# Benefits open enrollment & life events

Enterprise Phase E4 adds enrollment windows, qualifying life events (QLE), and eligibility rules that gate benefit elections before payroll deductions apply.

## Concepts

| Entity | Purpose |
|--------|---------|
| `enrollment_windows` | Annual open enrollment periods per benefit type |
| `eligibility_rules` | Tenure and employment-type requirements |
| `life_events` | Documented QLEs that open a special enrollment period |

Elections outside an open window are rejected unless tied to an **approved** life event (`ENROLLMENT_WINDOW_CLOSED`, 409).

Pre-tax effective dates cannot be in the past (`RETROACTIVE_PRETAX_NOT_ALLOWED`, 400).

## API

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/enrollment-windows` | Create window |
| GET | `/api/enrollment-windows` | List windows |
| POST | `/api/enrollment-windows/:id/close` | Close window |
| POST | `/api/eligibility-rules` | Create eligibility rule |
| GET | `/api/eligibility-rules` | List rules |
| POST | `/api/life-events` | Record life event (pending) |
| GET | `/api/life-events?employeeId=` | List employee events |
| POST | `/api/life-events/:id/approve` | Approve QLE |
| POST | `/api/life-events/:id/reject` | Reject QLE |
| POST | `/api/benefit-enrollments` | Elect benefit (window or QLE) |

### Elect via open enrollment

```json
POST /api/benefit-enrollments
{
  "employeeId": "...",
  "type": "401k_pretax",
  "amountPerPeriod": "300.00",
  "effectiveDate": "2026-11-01"
}
```

Requires an open enrollment window covering `effectiveDate` and the benefit type.

### Elect via approved QLE (mid-year HSA)

```json
POST /api/life-events
{
  "employeeId": "...",
  "eventType": "marriage",
  "eventDate": "2026-07-01",
  "coverageEffectiveDate": "2026-07-01"
}

POST /api/life-events/{id}/approve

POST /api/benefit-enrollments
{
  "employeeId": "...",
  "type": "hsa",
  "hsaCoverage": "individual",
  "amountPerPeriod": "200.00",
  "effectiveDate": "2026-07-01",
  "lifeEventId": "..."
}
```

HSA enrollments via QLE set `annualLimit` to the IRS limit prorated by months remaining in the calendar year.

### COBRA from loss of coverage

Approving a `loss_of_coverage` event with COBRA details creates a `cobra_premium` deduction schedule (see [COBRA_AND_ARREARS.md](./COBRA_AND_ARREARS.md)):

```json
POST /api/life-events/{id}/approve
{
  "cobraPremiumPerPeriod": "450.00",
  "cobraStartDate": "2026-08-01"
}
```

## Payroll integration

Active enrollments load unchanged via `useActiveEnrollments` on payroll run and `/api/deductions/preview`. Prorated `annualLimit` on HSA enrollments caps deductions through `DeductionLimitTracker`.

## Feature flag

`FEATURE_BENEFITS_LIFECYCLE=false` disables lifecycle routes and restores direct benefit enrollment creation without window/QLE checks.
