# Contractor (1099-NEC) payroll

Independent contractors are paid through the same payroll run API with `employmentType: contractor`.

## Withholding

- **Federal, state, local income tax:** `0.00` (payer does not withhold on NEC compensation).
- **FICA (employee and employer):** `0.00` — contractors are not subject to employee FICA via this W-2-style pipeline.
- **Garnishments:** not applied on contractor runs (use separate legal workflows if required).

## Deductions

W-2-only pre-tax deductions are **rejected** with `INVALID_INPUT`:

- `section_125`, `hsa`, `fsa`, `401k_pretax`

Post-tax deductions (`401k_roth`, `life_insurance`, `charitable`) may still be passed for rare payroll-adjacent flows; prefer paying contractors net of invoice without enrollment rows.

## YTD

`gross_earnings` increments for 1099 reporting. Tax-withheld YTD buckets remain unchanged for contractor runs.

## Feature flag

`FEATURE_CONTRACTOR_PAY=false` disables the contractor branch (contractors would be taxed like W-2 — do not use in production).

## API example

```bash
POST /api/payroll/run
{
  "employeeId": "<contractor-uuid>",
  "payPeriodId": "2024-monthly-1",
  "year": 2024,
  "frequency": "monthly",
  "earnings": [{ "type": "regular", "amount": "3500.00" }],
  "deductions": []
}
```

Expect `taxes.*` all zero and `payStub.netPay` equal to gross minus any allowed post-tax deductions.

## Compliance note

This engine models **1099-NEC-style** non-employee compensation. Misclassified employees must not use the contractor path; legal classification is out of scope for the calculator.
