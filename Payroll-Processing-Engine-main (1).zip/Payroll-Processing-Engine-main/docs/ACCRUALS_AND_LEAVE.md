# Accruals and paid leave (Enterprise Phase E2)

Tracks PTO and sick balances with per-period accrual, payroll usage deductions, carryover caps, and an append-only transaction ledger.

## Data model

| Table | Purpose |
|-------|---------|
| `leave_policies` | Accrual rules by `leave_type` (`pto`, `sick`) |
| `leave_balances` | Current hours per employee, type, calendar year |
| `leave_transactions` | Accrual, usage, adjustment, carryover, forfeit rows |

Balance identity: `balance = sum(transaction.hours)` for a calendar year (property tested in unit suite).

## Accrual methods

| Method | Config |
|--------|--------|
| `fixed_per_period` | `{ hoursPerPeriod: "4.00" }` |
| `tenure_bands` | `{ bands: [{ minTenureMonths, hoursPerPeriod }] }` |

## Payroll integration

- Earnings types `pto` and `sick` are regular taxable wages.
- Each line may include `hours` — deducted from the matching leave balance on successful run.
- Insufficient balance → `INSUFFICIENT_LEAVE_BALANCE` (400).

## API

Flag: `FEATURE_LEAVE_ACCRUALS` (default on).

```
POST   /api/leave-policies
GET    /api/leave-policies
PATCH  /api/leave-policies/:id
GET    /api/leave-balances?employeeId=&calendarYear=
POST   /api/leave-balances/adjust
POST   /api/admin/accrual-run   { payPeriodId, companyId? }
```

## Accrual job

`POST /api/admin/accrual-run` posts accruals for all active employees and policies for the pay period. Idempotent per `(employee, policy, pay period)`.

On the first accrual of a new calendar year, carryover from the prior year is applied and amounts above `carryoverMaxHours` are forfeited.

## ADR

[adr/0017-leave-accrual-ledger.md](./adr/0017-leave-accrual-ledger.md)
