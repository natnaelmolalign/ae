# Pay policies (Enterprise Phase E1)

Declarative guardrails evaluated **before** `PayrollRunService.compute()`. Policies fail closed: violations return `PAY_POLICY_VIOLATION` (HTTP 400) and block the run.

## Model

| Field | Description |
|-------|-------------|
| `scope` | `company` (all employees) or `employee` (one employee) |
| `priority` | Higher runs first when multiple policies match |
| `rules` | JSON array of typed rules (see below) |
| `effective_from` / `effective_to` | Active window by **payment date** |

## Rule types (v1)

| Type | Params | Effect |
|------|--------|--------|
| `min_gross` | `amount` | Reject if gross &lt; amount |
| `max_gross` | `amount` | Reject if gross &gt; amount |
| `min_hourly_rate` | `rate` | For `full_time_hourly` / `part_time`, `baseCompensation` ≥ rate |
| `require_positive_gross` | — | Reject if gross ≤ 0 |

## API

Requires `FEATURE_PAY_POLICIES` (default on). Role: `payroll_admin` for mutations; `payroll_clerk` may validate.

```
POST   /api/pay-policies
GET    /api/pay-policies
GET    /api/pay-policies/:id
PATCH  /api/pay-policies/:id
POST   /api/pay-policies/validate
```

### Example company policy

```json
{
  "code": "DEFAULT_GUARDRAILS",
  "name": "Default pay guardrails",
  "scope": "company",
  "priority": 10,
  "effectiveFrom": "2025-01-01",
  "rules": [
    { "type": "require_positive_gross" },
    { "type": "max_gross", "params": { "amount": "500000.00" } },
    { "type": "min_hourly_rate", "params": { "rate": "7.25" } }
  ]
}
```

### Validate before run

```bash
curl -X POST http://localhost:3000/api/pay-policies/validate \
  -H "Authorization: Bearer dev-admin-key" \
  -H "X-Company-Id: default" \
  -H "Content-Type: application/json" \
  -d '{"employeeId":"<uuid>","payPeriodId":"<uuid>","grossEarnings":"2500.00"}'
```

## Operations

- **Disable globally:** `FEATURE_PAY_POLICIES=false` and restart (skips evaluation; routes return 503).
- **Rollout:** create policies with `is_active: false`, test via `/validate`, then activate.
- Mutations are audited as entity `pay_policy`.

## Pipeline

See [ARCHITECTURE.md](./ARCHITECTURE.md) — policy gate is the first step before earnings classification.

## ADR

[adr/0016-pay-policy-engine.md](./adr/0016-pay-policy-engine.md)
