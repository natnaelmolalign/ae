# Garnishments

Legal references: [CCPA — 15 U.S.C. § 1673](https://www.dol.gov/agencies/whd/ccpa), federal student loan garnishment (EDG), state child support agencies (varies by state; state rules behind feature flags in future phases).

## Disposable earnings

Computed by `DisposableEarningsCalculator`:

```
disposable = gross
  − federal income tax
  − state income tax
  − local income tax
  − Social Security
  − Medicare (+ additional Medicare)
  − mandatory Section 125 (health cafeteria)
```

Voluntary deductions (401(k), HSA, Roth) do **not** reduce disposable earnings in v1.

## Priority (waterfill)

`GarnishmentAllocationService` sorts orders by:

1. **Type rank:** child support → student loan → creditor
2. **Numeric priority** within the same type (lower first)

Each order receives up to its requested amount, capped by:

| Type | Max % of remaining disposable |
|------|------------------------------|
| child_support | 50% |
| student_loan | 15% |
| creditor | 25% (CCPA) |

Remaining disposable is reduced after each order; later orders cannot exceed what is left.

## Termination

If `paymentDate` is **after** `employee.terminationDate`, garnishments are rejected with `GARNISHMENT_AFTER_TERMINATION`.

## Persistence

| Table | Purpose |
|-------|---------|
| `garnishment_orders` | Case ID, type, amounts, effective/end dates |
| `garnishment_remittances` | Amount withheld per order per `payroll_run` |

## API

| Endpoint | Description |
|----------|-------------|
| `POST /api/garnishment-orders` | Create order |
| `GET /api/garnishment-orders?employeeId=` | List |
| `GET ?active=true&asOf=` | Active for payment date |
| `POST /api/payroll/run` with `useActiveGarnishmentOrders: true` | Apply persisted orders |

Inline `garnishments[]` on payroll run still works for tests and one-off runs without persistence.

## Common regression areas

- Using **gross** instead of disposable for caps
- Creditor paid before child support (priority bug)
- Garnishment applied after termination
