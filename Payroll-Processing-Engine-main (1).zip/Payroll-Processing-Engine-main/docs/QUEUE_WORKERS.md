# Job queue & workers

Enterprise Phase E8 moves batch payroll and webhook delivery to a durable queue processed by horizontal workers.

## Architecture

| Component | Purpose |
|-----------|---------|
| `JobQueue` | Enqueue, poll, ack, fail → DLQ |
| `KnexJobQueue` | Persistent queue (`queue_jobs`, `queue_dead_letters`) |
| `InMemoryJobQueue` | Tests and local dev (`JOB_QUEUE_BACKEND=memory`) |
| `SqsJobQueue` | Stub — use `knex` backend until SQS is configured |
| `src/worker.ts` | Poll loop separate from API process |

## Partition keys

Jobs are ordered by `partitionKey = {companyId}:{payPeriodId}` so employees in the same pay run stay FIFO per tenant/period.

## API

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/payroll/batch` | Add `"useQueue": true` for async enqueue (202) |
| GET | `/api/payroll/batch/:id` | Poll batch status after workers process jobs |
| GET | `/api/admin/queue/dead-letters` | Inspect DLQ (`payroll_admin`) |

## Worker

```bash
npm run build
JOB_QUEUE_BACKEND=knex npm run worker
```

Env: `WORKER_ID`, `WORKER_POLL_MS`, `FEATURE_JOB_QUEUE`.

## Metrics

- `queue_dlq_total{job_type}` — poison messages after max attempts (default 3)

## k6

```bash
k6 run -e QUEUED_BATCH=1 -e PAY_PERIOD_ID=2024-monthly-1 scripts/load/k6-batch-payroll.js
```

## Feature flag

`FEATURE_JOB_QUEUE=false` disables queued batch path and admin DLQ routes.
