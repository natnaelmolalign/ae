# Deduction Ordering

## Pre-tax (applied before income tax)

Order (cafeteria plan rules):

1. **Section 125** cafeteria (health) — reduces federal, state, SS, and Medicare bases.
2. **HSA / FSA** — federal and state income tax only (not FICA). Subject to IRS annual limits in `src/data/{taxYear}/deductionLimits.ts`.
3. **Traditional 401(k)** — federal and state income tax only. Subject to combined §402(g) elective deferral limit (pre-tax + Roth).

Limits are enforced by `DeductionLimitTracker` using YTD + current period before accepting each deduction. Excess requested amounts are **capped** (not applied); preview responses include `limitAdjustments`.

### §402(g) elective deferrals (2024)

| Component | Amount |
|-----------|--------|
| Base limit | $23,000 |
| Age 50+ catch-up (`catchUpEligible`) | +$7,500 |
| **Combined pool** | Pre-tax 401(k) + Roth 401(k) share one annual ceiling |

## Post-tax (after all taxes)

1. **Roth 401(k)** — reduces net pay only; counts toward §402(g) pool.
2. Voluntary post-tax (e.g. charitable, life insurance).
3. **Scheduled deductions** (Advanced Phase 5) — COBRA premium and arrears recovery from `deduction_schedules`; post-tax only (never reduce pre-tax bases). Capped to available net before garnishments. See [COBRA_AND_ARREARS.md](./COBRA_AND_ARREARS.md).
4. **Garnishments** — child support first, then creditors (Phase 6 expands multi-order rules).

## Employer match

| Mode | Behavior |
|------|----------|
| `employerMatch401kPercent` | Flat percent of employee pre-tax 401(k) deferral |
| `safeHarborMatch: true` | IRS basic safe harbor: 100% of deferrals up to 3% of compensation + 50% of deferrals from 3%–5% (`SafeHarborMatchCalculator`) |

## Mid-year enrollment

v1 uses **full calendar-year limits** (no proration by months remaining). Enrollments are filtered by `effectiveDate` / `endDate` when `useActiveEnrollments` is true on preview or payroll input.

## API

| Endpoint | Purpose |
|----------|---------|
| `POST /api/benefit-enrollments` | Create persisted enrollment |
| `GET /api/benefit-enrollments?employeeId=` | List enrollments |
| `GET /api/benefit-enrollments?employeeId=&active=true&asOf=` | Active enrollments for payment date |
| `POST /api/deductions/preview` | Preview bases, caps, and `limitAdjustments` |

## Disposable earnings (garnishments)

Gross − required taxes (federal, state, SS, Medicare) − mandatory deductions = disposable earnings base for CCPA percentage limits.

## Property invariant

Total pre-tax federal reductions for a period must not exceed period gross (enforced by per-line caps and ordering).
