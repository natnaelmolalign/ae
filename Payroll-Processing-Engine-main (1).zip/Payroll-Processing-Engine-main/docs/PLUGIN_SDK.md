# Deduction plugin SDK

Enterprise Phase E10 exposes an in-process plugin host for custom deduction calculations.

## Interface

```typescript
interface DeductionPlugin {
  id: string;
  name: string;
  calculate(context: {
    companyId: string;
    employeeId: string;
    grossPay: string;
    payPeriodId: string;
  }): Promise<{ code: string; amount: string; description?: string } | null>;
}
```

## Registration

Plugins register on `PluginHost` at startup (see `deps.ts` demo plugin `demo-flat-deduction`).

## Execution

```http
POST /api/filing/plugins/execute
{
  "pluginId": "demo-flat-deduction",
  "employeeId": "...",
  "payPeriodId": "2024-monthly-1",
  "grossPay": "5000.00"
}
```

## Sandbox rules

- Default timeout: 500ms (`PLUGIN_TIMEOUT_MS`)
- Runaway plugins are rejected without crashing the worker
- Plugins receive only the authenticated tenant's `companyId`; cross-tenant data access is forbidden by host contract

## Tenant isolation

Integration tests must verify a plugin cannot read another company's employees via repository injection — plugins should use only the provided context.
