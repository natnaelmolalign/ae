import type { Employee } from '../../src/models/types';

export const testEmployee: Employee = {
  id: '11111111-1111-4111-8111-111111111111',
  companyId: 'default',
  firstName: 'Jane',
  lastName: 'Doe',
  employmentType: 'full_time_salaried',
  payFrequency: 'biweekly',
  baseCompensation: '5000.00',
  hireDate: '2024-01-15',
  terminationDate: null,
  filingStatus: 'single',
  stateCode: 'CA',
  w4ExtraWithholding: '0.00',
  w4DependentsCredit: '0.00',
  w4OtherDeductions: '0.00',
  w4OtherIncome: '0.00',
  w4MultipleJobs: false,
  localMunicipalityCode: null,
  equityWithholdingMethod: 'supplemental_flat',
  tinLastFour: null,
  createdAt: '2024-01-01T00:00:00.000Z',
};
