/**
 * Run: npx ts-node tests/helpers/generateFederalGolden.ts
 * Regenerates expected federal withholding in golden scenarios.
 */
import * as fs from 'fs';
import * as path from 'path';
import { FEDERAL_2024 } from '../../src/data/2024/federal';
import type { W4Params } from '../../src/models/W4Params';
import type { PayFrequency } from '../../src/models/types';
import { FederalWithholdingEngine } from '../../src/services/tax/federal/FederalWithholdingEngine';

interface ScenarioInput {
  id: string;
  payFrequency: PayFrequency;
  periodFederalTaxable: string;
  regularFederalTaxable: string;
  supplementalFederalTaxable: string;
  supplementalOnly: boolean;
  mixedSupplemental: boolean;
  w4: Partial<W4Params>;
}

const baseW4: W4Params = {
  filingStatus: 'single',
  extraWithholdingPerPeriod: '0.00',
  dependentsCreditAnnual: '0.00',
  otherDeductionsAnnual: '0.00',
  otherIncomeAnnual: '0.00',
  multipleJobs: false,
};

const inputs: ScenarioInput[] = [];
const frequencies: PayFrequency[] = [
  'weekly',
  'biweekly',
  'semimonthly',
  'monthly',
];
const wages = ['1000', '2500', '4000', '6000', '10000'];

let n = 0;
for (const payFrequency of frequencies) {
  for (const w of wages) {
    const amount = `${w}.00`;
    inputs.push({
      id: `reg-${payFrequency}-${w}`,
      payFrequency,
      periodFederalTaxable: amount,
      regularFederalTaxable: amount,
      supplementalFederalTaxable: '0.00',
      supplementalOnly: false,
      mixedSupplemental: false,
      w4: {},
    });
    n++;
    if (n >= 20) break;
  }
  if (n >= 20) break;
}

for (const w of ['1000', '3000', '5000', '8000', '10000']) {
  const amount = `${w}.00`;
  inputs.push({
    id: `supp-only-${w}`,
    payFrequency: 'biweekly',
    periodFederalTaxable: amount,
    regularFederalTaxable: '0.00',
    supplementalFederalTaxable: amount,
    supplementalOnly: true,
    mixedSupplemental: false,
    w4: {},
  });
}

inputs.push({
  id: 'mixed-bonus-4k-2k',
  payFrequency: 'biweekly',
  periodFederalTaxable: '6000.00',
  regularFederalTaxable: '4000.00',
  supplementalFederalTaxable: '2000.00',
  supplementalOnly: false,
  mixedSupplemental: true,
  w4: {},
});

for (const credit of ['0', '2000', '5000', '10000']) {
  inputs.push({
    id: `w4-credit-${credit}`,
    payFrequency: 'biweekly',
    periodFederalTaxable: '4500.00',
    regularFederalTaxable: '4500.00',
    supplementalFederalTaxable: '0.00',
    supplementalOnly: false,
    mixedSupplemental: false,
    w4: { dependentsCreditAnnual: `${credit}.00` },
  });
}

const scenarios = inputs.map((s) => {
  const w4: W4Params = { ...baseW4, ...s.w4 };
  const expectedFederal = FederalWithholdingEngine.calculate(
    FEDERAL_2024,
    w4,
    s.payFrequency,
    s.periodFederalTaxable,
    s.regularFederalTaxable,
    s.supplementalFederalTaxable,
    s.supplementalOnly,
    s.mixedSupplemental
  );
  return { ...s, w4, expectedFederal };
});

const outPath = path.join(__dirname, '../golden/federal/scenarios.json');
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, JSON.stringify({ scenarios }, null, 2));
console.log(`Wrote ${scenarios.length} scenarios to ${outPath}`);
