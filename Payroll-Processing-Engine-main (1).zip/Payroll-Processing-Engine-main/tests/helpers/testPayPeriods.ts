import type { PayPeriod } from '../../src/models/types';

export const biweeklyPeriod: PayPeriod = {
  id: '2024-biweekly-1',
  companyId: 'default',
  startDate: '2024-01-01',
  endDate: '2024-01-14',
  paymentDate: '2024-01-16',
  frequency: 'biweekly',
  year: 2024,
  periodIndex: 1,
};
