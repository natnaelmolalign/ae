import type { Express } from 'express';
import {
  closeDb,
  getDb,
  runMigrations,
  truncateAllTables,
} from '../../src/config/database';
import { createApp } from '../../src/app';
import {
  createAppDependencies,
  resetCachedDependencies,
  type AppDependencies,
} from '../../src/deps';

export interface TestContext {
  app: Express;
  deps: AppDependencies;
}

export async function initTestContext(): Promise<TestContext> {
  process.env.NODE_ENV = 'test';
  await closeDb();
  resetCachedDependencies();
  const db = getDb();
  await runMigrations(db);
  await truncateAllTables(db);
  const deps = createAppDependencies(db);
  return { app: createApp(deps), deps };
}

export async function resetTestData(deps: AppDependencies): Promise<void> {
  await truncateAllTables(deps.db);
}
