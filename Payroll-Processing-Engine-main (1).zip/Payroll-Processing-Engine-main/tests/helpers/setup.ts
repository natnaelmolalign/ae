/** Global setup for unit tests (no database). Integration tests use tests/helpers/db.ts */
export {};
