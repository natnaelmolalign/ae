import { closeDb } from '../../src/config/database';
import { resetCachedDependencies } from '../../src/deps';

export default async function globalTeardown(): Promise<void> {
  await closeDb();
  resetCachedDependencies();
}
