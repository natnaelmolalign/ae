import http from 'http';
import request from 'supertest';
import type { AddressInfo } from 'net';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';
import { verifyWebhookSignature } from '../../../src/utils/webhookSignature';
import { runWebhookDelivery } from '../../../src/jobs/webhookDeliveryJob';

describe('Webhook delivery (Advanced Phase 6)', () => {
  let ctx: TestContext;
  const received: {
    body: string;
    signature: string;
    timestamp: string;
    event: string;
  }[] = [];

  let server: http.Server;
  let webhookUrl: string;
  const secret = 'integration-webhook-secret';

  beforeAll(async () => {
    ctx = await initTestContext();
    server = http.createServer((req, res) => {
      let body = '';
      req.on('data', (chunk) => {
        body += chunk;
      });
      req.on('end', () => {
        received.push({
          body,
          signature: String(req.headers['x-webhook-signature'] ?? ''),
          timestamp: String(req.headers['x-webhook-timestamp'] ?? ''),
          event: String(req.headers['x-webhook-event'] ?? ''),
        });
        res.writeHead(200);
        res.end('ok');
      });
    });
    await new Promise<void>((resolve) => {
      server.listen(0, '127.0.0.1', () => resolve());
    });
    const addr = server.address() as AddressInfo;
    webhookUrl = `http://127.0.0.1:${addr.port}/hook`;
  });

  afterAll(async () => {
    await new Promise<void>((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  beforeEach(async () => {
    received.length = 0;
    await resetTestData(ctx.deps);
  });

  it('enqueues outbox on payroll run and delivers signed payload', async () => {
    await request(ctx.app)
      .post('/api/admin/webhooks')
      .send({
        url: webhookUrl,
        secret,
        events: ['payroll.run.completed', 'pay_stub.created'],
      });

    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Hook',
      lastName: 'Test',
      employmentType: 'full_time_salaried',
      payFrequency: 'biweekly',
      baseCompensation: '5000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'biweekly' });

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId: employeeRes.body.id,
        payPeriodId: '2024-biweekly-1',
        year: 2024,
        frequency: 'biweekly',
        earnings: [{ type: 'regular', amount: '2000.00' }],
        deductions: [],
      });

    expect(runRes.status).toBe(200);

    const outboxCount = await ctx.deps.db('webhook_outbox').count('* as c');
    expect(Number(outboxCount[0].c)).toBe(2);

    const result = await runWebhookDelivery(10);
    expect(result.delivered).toBe(2);
    expect(received).toHaveLength(2);

    const payrollHook = received.find(
      (r) => r.event === 'payroll.run.completed'
    )!;
    const parsed = JSON.parse(payrollHook.body);
    expect(parsed.event).toBe('payroll.run.completed');
    expect(parsed.data.employeeId).toBe(employeeRes.body.id);
    expect(parsed.data.firstName).toBeUndefined();
    expect(parsed.data.payStubId).toBe(runRes.body.payStub.id);

    expect(
      verifyWebhookSignature(
        secret,
        payrollHook.body,
        payrollHook.timestamp,
        payrollHook.signature
      )
    ).toBe(true);

    const delivered = await ctx.deps
      .db('webhook_outbox')
      .where({ status: 'delivered' })
      .count('* as c');
    expect(Number(delivered[0].c)).toBe(2);
  });
});
