import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('Payroll controls (Enterprise E9)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('skips held employee in batch then succeeds after release', async () => {
    const emp = await request(ctx.app).post('/api/employees').send({
      firstName: 'Held',
      lastName: 'Worker',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '5000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = emp.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const holdRes = await request(ctx.app)
      .post('/api/payroll-controls/holds')
      .send({
        employeeId,
        reasonCode: 'audit_review',
      });
    expect(holdRes.status).toBe(201);

    await request(ctx.app)
      .post('/api/payroll/readiness')
      .send({
        payPeriodId: '2024-monthly-1',
        employeeIds: [employeeId],
      });

    const batchRes = await request(ctx.app).post('/api/payroll/batch').send({
      payPeriodId: '2024-monthly-1',
      year: 2024,
      frequency: 'monthly',
    });
    expect(batchRes.status).toBe(201);
    expect(batchRes.body.batch.failureCount).toBe(1);
    expect(batchRes.body.batch.successCount).toBe(0);

    const release = await request(ctx.app)
      .post(`/api/payroll-controls/holds/${holdRes.body.id}/release`)
      .send({ releaseReason: 'review_complete' });
    expect(release.status).toBe(200);

    const retry = await request(ctx.app)
      .post('/api/payroll/batch')
      .send({
        payPeriodId: '2024-monthly-1',
        year: 2024,
        frequency: 'monthly',
        employeeIds: [employeeId],
      });
    expect(retry.status).toBe(201);
    expect(retry.body.batch.successCount).toBe(1);
  });
});
