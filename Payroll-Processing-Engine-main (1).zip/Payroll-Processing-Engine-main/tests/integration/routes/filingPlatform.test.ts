import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('Filing platform (Enterprise E10)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('exports W-2 XML with stub schema namespace', async () => {
    const res = await request(ctx.app).get('/api/filing/w2/2024/xml');
    expect(res.status).toBe(200);
    expect(res.text).toContain('W2Submission');
    expect(res.text).toContain('urn:irs:gov:treasury:efile:w2:stub');
  });

  it('executes sandbox deduction plugin scoped to tenant', async () => {
    const emp = await request(ctx.app).post('/api/employees').send({
      firstName: 'Plugin',
      lastName: 'User',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '4000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    const res = await request(ctx.app)
      .post('/api/filing/plugins/execute')
      .send({
        pluginId: 'demo-flat-deduction',
        employeeId: emp.body.id,
        payPeriodId: '2024-monthly-1',
        grossPay: '4000.00',
      });
    expect(res.status).toBe(200);
    expect(res.body.result.amount).toBe('25.00');
  });
});
