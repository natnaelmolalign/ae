import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

function asEmployee(employeeId: string) {
  return { 'x-employee-id': employeeId };
}

async function createEmployee(ctx: TestContext, suffix: string) {
  const res = await request(ctx.app).post('/api/employees').send({
    firstName: suffix,
    lastName: 'ESS',
    employmentType: 'full_time_salaried',
    payFrequency: 'semimonthly',
    baseCompensation: '6000.00',
    hireDate: '2024-01-01',
    filingStatus: 'single',
    stateCode: 'TX',
  });
  expect(res.status).toBe(201);
  return res.body.id as string;
}

async function runPayroll(
  ctx: TestContext,
  employeeId: string
): Promise<string> {
  await request(ctx.app)
    .post('/api/payperiods/generate')
    .send({ year: 2024, frequency: 'semimonthly' });
  const periodId = '2024-semimonthly-1';
  const runRes = await request(ctx.app)
    .post('/api/payroll/run')
    .send({
      employeeId,
      payPeriodId: periodId,
      year: 2024,
      frequency: 'semimonthly',
      earnings: [{ type: 'regular', amount: '6000.00' }],
      deductions: [],
      garnishments: [],
    });
  expect(runRes.status).toBe(200);
  return runRes.body.payStub.id as string;
}

describe('Employee self-service (Enterprise E7)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('returns own profile and pay stubs for employee_self', async () => {
    const employeeId = await createEmployee(ctx, 'Self');
    const stubId = await runPayroll(ctx, employeeId);

    const profile = await request(ctx.app)
      .get('/api/ess/me/profile')
      .set(asEmployee(employeeId));
    expect(profile.status).toBe(200);
    expect(profile.body.id).toBe(employeeId);
    expect(profile.body.filingStatus).toBe('single');

    const stubs = await request(ctx.app)
      .get('/api/ess/me/pay-stubs')
      .set(asEmployee(employeeId));
    expect(stubs.status).toBe(200);
    expect(stubs.body.payStubs).toHaveLength(1);
    expect(stubs.body.payStubs[0].id).toBe(stubId);

    const stub = await request(ctx.app)
      .get(`/api/ess/me/pay-stubs/${stubId}`)
      .set(asEmployee(employeeId));
    expect(stub.status).toBe(200);
    expect(stub.body.netPay).toBeTruthy();
  });

  it('returns 404 when accessing another employee pay stub (BOLA)', async () => {
    const employeeA = await createEmployee(ctx, 'Alice');
    const employeeB = await createEmployee(ctx, 'Bob');
    const stubA = await runPayroll(ctx, employeeA);

    const res = await request(ctx.app)
      .get(`/api/ess/me/pay-stubs/${stubA}`)
      .set(asEmployee(employeeB));
    expect(res.status).toBe(404);
    expect(res.body.code).toBe('NOT_FOUND');
  });

  it('blocks employee_self from admin routes', async () => {
    const employeeId = await createEmployee(ctx, 'Blocked');

    const res = await request(ctx.app)
      .get(`/api/employees/${employeeId}`)
      .set(asEmployee(employeeId));
    expect(res.status).toBe(403);
    expect(res.body.code).toBe('FORBIDDEN');
  });

  it('does not apply W-4 until clerk approves pending request', async () => {
    const employeeId = await createEmployee(ctx, 'W4');

    const draft = await request(ctx.app)
      .post('/api/ess/me/w4-change-requests')
      .set(asEmployee(employeeId))
      .send({
        filingStatus: 'married_filing_jointly',
        w4ExtraWithholding: '75.00',
        w4DependentsCredit: '1500.00',
      });
    expect(draft.status).toBe(201);
    expect(draft.body.status).toBe('draft');

    const submitted = await request(ctx.app)
      .post(`/api/ess/me/w4-change-requests/${draft.body.id}/submit`)
      .set(asEmployee(employeeId));
    expect(submitted.status).toBe(200);
    expect(submitted.body.status).toBe('pending');

    const beforeApprove = await request(ctx.app).get(
      `/api/employees/${employeeId}`
    );
    expect(beforeApprove.body.filingStatus).toBe('single');
    expect(beforeApprove.body.w4ExtraWithholding).toBe('0.00');

    const approve = await request(ctx.app).post(
      `/api/w4-change-requests/${draft.body.id}/approve`
    );
    expect(approve.status).toBe(200);
    expect(approve.body.status).toBe('applied');

    const afterApprove = await request(ctx.app).get(
      `/api/employees/${employeeId}`
    );
    expect(afterApprove.body.filingStatus).toBe('married_filing_jointly');
    expect(afterApprove.body.w4ExtraWithholding).toBe('75.00');

    const essProfile = await request(ctx.app)
      .get('/api/ess/me/profile')
      .set(asEmployee(employeeId));
    expect(essProfile.body.filingStatus).toBe('married_filing_jointly');
  });

  it('returns 404 for another employee W-4 request (BOLA)', async () => {
    const employeeA = await createEmployee(ctx, 'W4A');
    const employeeB = await createEmployee(ctx, 'W4B');

    const draft = await request(ctx.app)
      .post('/api/ess/me/w4-change-requests')
      .set(asEmployee(employeeA))
      .send({ filingStatus: 'head_of_household' });
    expect(draft.status).toBe(201);

    const res = await request(ctx.app)
      .get(`/api/ess/me/w4-change-requests/${draft.body.id}`)
      .set(asEmployee(employeeB));
    expect(res.status).toBe(404);
  });
});
