import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('POST /api/payroll/run (persisted)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('runs payroll and returns reconciled pay stub', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Test',
      lastName: 'Worker',
      employmentType: 'full_time_salaried',
      payFrequency: 'semimonthly',
      baseCompensation: '6000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    expect(employeeRes.status).toBe(201);
    const employeeId = employeeRes.body.id;

    const periodsRes = await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'semimonthly' });
    expect(periodsRes.status).toBe(200);

    const periodId = periodsRes.body.periods[0].id;

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId,
        payPeriodId: periodId,
        year: 2024,
        frequency: 'semimonthly',
        earnings: [{ type: 'regular', amount: '6000.00' }],
        deductions: [],
        garnishments: [],
      });

    expect(runRes.status).toBe(200);
    expect(runRes.body.payStub.grossPay).toBe('6000.00');
    expect(parseFloat(runRes.body.payStub.netPay)).toBeLessThan(6000);

    const stubRes = await request(ctx.app).get(
      `/api/payroll/stubs/${runRes.body.payStub.id}`
    );
    expect(stubRes.status).toBe(200);
    expect(stubRes.body.id).toBe(runRes.body.payStub.id);
  });

  it('rejects duplicate payroll run for same employee and period', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Dup',
      lastName: 'Test',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '5000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = employeeRes.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodId = '2024-monthly-1';
    const payload = {
      employeeId,
      payPeriodId: periodId,
      year: 2024,
      frequency: 'monthly',
      earnings: [{ type: 'regular', amount: '5000.00' }],
      deductions: [],
      garnishments: [],
    };

    expect(
      (await request(ctx.app).post('/api/payroll/run').send(payload)).status
    ).toBe(200);
    const second = await request(ctx.app)
      .post('/api/payroll/run')
      .send(payload);
    expect(second.status).toBe(409);
    expect(second.body.code).toBe('DUPLICATE_PAYROLL_RUN');
  });

  it('returns same result for duplicate idempotency key', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Idem',
      lastName: 'Potent',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '4000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = employeeRes.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const payload = {
      employeeId,
      payPeriodId: '2024-monthly-1',
      year: 2024,
      frequency: 'monthly',
      earnings: [{ type: 'regular', amount: '4000.00' }],
      deductions: [],
      garnishments: [],
    };

    const first = await request(ctx.app)
      .post('/api/payroll/run')
      .set('idempotency-key', 'run-key-abc')
      .send(payload);
    const second = await request(ctx.app)
      .post('/api/payroll/run')
      .set('idempotency-key', 'run-key-abc')
      .send(payload);

    expect(first.status).toBe(200);
    expect(second.status).toBe(200);
    expect(second.body.payStub.id).toBe(first.body.payStub.id);
  });
});

describe('persistence across reload', () => {
  it('employee survives new app instance on same database', async () => {
    const ctx1 = await initTestContext();
    const createRes = await request(ctx1.app).post('/api/employees').send({
      firstName: 'Persist',
      lastName: 'Me',
      employmentType: 'full_time_salaried',
      payFrequency: 'weekly',
      baseCompensation: '3000.00',
      hireDate: '2024-03-01',
      filingStatus: 'single',
      stateCode: 'CA',
    });
    const id = createRes.body.id;

    const row = await ctx1.deps.db('employees').where({ id }).first();
    expect(row).toBeDefined();
    expect(row.first_name).toBe('Persist');
  });
});
