import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('compliance exports (Advanced Phase 10)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    process.env.TIN_MASTER_KEY = 'integration-test-tin-key';
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  async function runPayroll(
    employeeId: string,
    periodId: string,
    amount: string,
    companyId?: string
  ) {
    const req = request(ctx.app)
      .post('/api/payroll/run')
      .set('x-actor-id', 'payroll-clerk-1');
    if (companyId) req.set('X-Company-Id', companyId);
    return req.send({
      employeeId,
      payPeriodId: periodId,
      year: 2024,
      frequency: 'monthly',
      earnings: [{ type: 'regular', amount }],
      deductions: [],
      garnishments: [],
    });
  }

  it('W-2 preview totals match pay stubs and excludes contractors', async () => {
    const w2 = await request(ctx.app).post('/api/employees').send({
      firstName: 'W2',
      lastName: 'Worker',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '5000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const contractor = await request(ctx.app).post('/api/employees').send({
      firstName: 'Ten',
      lastName: 'NinetyNine',
      employmentType: 'contractor',
      payFrequency: 'monthly',
      baseCompensation: '8000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodId = '2024-monthly-1';
    expect((await runPayroll(w2.body.id, periodId, '5000.00')).status).toBe(
      200
    );
    expect(
      (await runPayroll(contractor.body.id, periodId, '8000.00')).status
    ).toBe(200);

    const res = await request(ctx.app).get(
      '/api/reports/w2-preview?taxYear=2024'
    );
    expect(res.status).toBe(200);
    expect(res.body.reconciliation.matches).toBe(true);
    expect(res.body.totals.wages).toBe('5000.00');
    expect(res.body.employees).toHaveLength(1);
    expect(res.body.employees[0].employeeName).toContain('W2');
  });

  it('1099-NEC preview includes contractors with $600 threshold flag', async () => {
    const big = await request(ctx.app).post('/api/employees').send({
      firstName: 'Big',
      lastName: 'Contractor',
      employmentType: 'contractor',
      payFrequency: 'monthly',
      baseCompensation: '7000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const small = await request(ctx.app).post('/api/employees').send({
      firstName: 'Small',
      lastName: 'Contractor',
      employmentType: 'contractor',
      payFrequency: 'monthly',
      baseCompensation: '200.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodId = '2024-monthly-1';
    await runPayroll(big.body.id, periodId, '7000.00');
    await runPayroll(small.body.id, periodId, '200.00');

    const res = await request(ctx.app).get(
      '/api/reports/1099-nec-preview?taxYear=2024'
    );
    expect(res.status).toBe(200);
    const bigRow = res.body.recipients.find(
      (r: { employeeId: string }) => r.employeeId === big.body.id
    );
    const smallRow = res.body.recipients.find(
      (r: { employeeId: string }) => r.employeeId === small.body.id
    );
    expect(bigRow.meets600Threshold).toBe(true);
    expect(smallRow.meets600Threshold).toBe(false);
  });

  it('does not leak another tenant TIN on 1099 preview', async () => {
    const contractor = await request(ctx.app)
      .post('/api/employees')
      .set('X-Company-Id', 'tenant-a')
      .send({
        firstName: 'Secret',
        lastName: 'Contractor',
        employmentType: 'contractor',
        payFrequency: 'monthly',
        baseCompensation: '7000.00',
        hireDate: '2024-01-01',
        filingStatus: 'single',
        stateCode: 'TX',
        tin: '123456789',
      });
    expect(contractor.status).toBe(201);
    expect(contractor.body.tinLastFour).toBe('6789');

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .set('X-Company-Id', 'tenant-a')
      .send({ year: 2024, frequency: 'monthly' });

    await runPayroll(
      contractor.body.id,
      '2024-monthly-1',
      '7000.00',
      'tenant-a'
    );

    const tenantA = await request(ctx.app)
      .get('/api/reports/1099-nec-preview?taxYear=2024')
      .set('X-Company-Id', 'tenant-a');
    expect(tenantA.status).toBe(200);
    expect(tenantA.body.recipients).toHaveLength(1);
    expect(tenantA.body.recipients[0].tinMasked).toBe('***-**-6789');

    const tenantB = await request(ctx.app)
      .get('/api/reports/1099-nec-preview?taxYear=2024')
      .set('X-Company-Id', 'tenant-b');
    expect(tenantB.status).toBe(200);
    expect(tenantB.body.recipients).toHaveLength(0);
    const leaked = JSON.stringify(tenantB.body).includes('6789');
    expect(leaked).toBe(false);
  });

  it('941 reconciliation sums federal and FICA for W-2 runs in quarter', async () => {
    const emp = await request(ctx.app).post('/api/employees').send({
      firstName: 'FICA',
      lastName: 'Employee',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '6000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    await runPayroll(emp.body.id, '2024-monthly-1', '6000.00');

    const res = await request(ctx.app).get(
      '/api/reports/941-reconciliation?taxYear=2024&quarter=1'
    );
    expect(res.status).toBe(200);
    expect(res.body.payrollRegisterGross).toBe('6000.00');
    expect(parseFloat(res.body.federalIncomeTaxWithheld)).toBeGreaterThan(0);
    expect(parseFloat(res.body.totalLiability)).toBeGreaterThan(0);
  });
});
