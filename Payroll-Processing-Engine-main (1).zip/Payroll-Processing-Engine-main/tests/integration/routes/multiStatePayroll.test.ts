import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('Multi-state payroll (Advanced Phase 2)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('applies split state tax for 60% NY / 40% TX', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Multi',
      lastName: 'State',
      employmentType: 'full_time_salaried',
      payFrequency: 'biweekly',
      baseCompensation: '10000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'NY',
    });
    const employeeId = employeeRes.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'biweekly' });

    const singleState = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId,
        payPeriodId: '2024-biweekly-1',
        year: 2024,
        frequency: 'biweekly',
        earnings: [{ type: 'regular', amount: '10000.00' }],
        deductions: [],
      });

    const multiState = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId,
        payPeriodId: '2024-biweekly-2',
        year: 2024,
        frequency: 'biweekly',
        earnings: [{ type: 'regular', amount: '10000.00' }],
        deductions: [],
        stateAllocations: [
          { stateCode: 'NY', percent: '60' },
          { stateCode: 'TX', percent: '40' },
        ],
      });

    expect(multiState.status).toBe(200);
    expect(Number(multiState.body.taxes.stateIncome)).toBeLessThan(
      Number(singleState.body.taxes.stateIncome)
    );
    expect(multiState.body.payStub.netPay).not.toBe(
      singleState.body.payStub.netPay
    );

    const rows = await ctx.deps.db('payroll_run_state_allocations').where({
      payroll_run_id: (
        await ctx.deps
          .db('payroll_runs')
          .where({ pay_stub_id: multiState.body.payStub.id })
          .first()
      ).id,
    });
    expect(rows).toHaveLength(2);
  });

  it('stores work locations and uses them on payroll run', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Remote',
      lastName: 'Worker',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '8000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'NY',
    });
    const employeeId = employeeRes.body.id;

    await request(ctx.app)
      .put(`/api/employees/${employeeId}/work-locations`)
      .send({
        locations: [
          {
            stateCode: 'CT',
            allocationPercent: '100',
            effectiveDate: '2024-01-01',
          },
        ],
      });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId,
        payPeriodId: '2024-monthly-1',
        year: 2024,
        frequency: 'monthly',
        earnings: [{ type: 'regular', amount: '8000.00' }],
        deductions: [],
      });

    expect(runRes.status).toBe(200);
    expect(runRes.body.taxes.stateIncome).toBe('400.00');
  });
});
