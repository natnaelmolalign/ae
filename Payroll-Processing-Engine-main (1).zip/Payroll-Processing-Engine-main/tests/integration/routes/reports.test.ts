import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('reports and audit (Phase 9)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  async function runPayroll(
    employeeId: string,
    periodId: string,
    amount: string
  ) {
    return request(ctx.app)
      .post('/api/payroll/run')
      .set('x-actor-id', 'payroll-clerk-1')
      .send({
        employeeId,
        payPeriodId: periodId,
        year: 2024,
        frequency: 'monthly',
        earnings: [{ type: 'regular', amount }],
        deductions: [],
        garnishments: [],
      });
  }

  it('payroll register totals match pay stub table', async () => {
    const emp = await request(ctx.app).post('/api/employees').send({
      firstName: 'Reg',
      lastName: 'Report',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '5000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = emp.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodId = '2024-monthly-1';
    expect((await runPayroll(employeeId, periodId, '5000.00')).status).toBe(
      200
    );

    const res = await request(ctx.app).get(
      `/api/reports/payroll-register?periodId=${periodId}`
    );
    expect(res.status).toBe(200);
    expect(res.body.reconciliation.matches).toBe(true);
    expect(res.body.register.totals.grossPay).toBe('5000.00');
  });

  it('GL export is balanced for the period', async () => {
    const emp = await request(ctx.app).post('/api/employees').send({
      firstName: 'GL',
      lastName: 'Export',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '4000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = emp.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodId = '2024-monthly-1';
    await runPayroll(employeeId, periodId, '4000.00');

    const res = await request(ctx.app).get(
      `/api/reports/gl-export?periodId=${periodId}`
    );
    expect(res.status).toBe(200);
    expect(res.body.allBalanced).toBe(true);
  });

  it('records audit on employee create and payroll run', async () => {
    const emp = await request(ctx.app)
      .post('/api/employees')
      .set('x-actor-id', 'hr-admin')
      .send({
        firstName: 'Audit',
        lastName: 'Trail',
        employmentType: 'full_time_salaried',
        payFrequency: 'monthly',
        baseCompensation: '3000.00',
        hireDate: '2024-01-01',
        filingStatus: 'single',
        stateCode: 'TX',
      });
    const employeeId = emp.body.id;

    const empAudit = await request(ctx.app).get(
      `/api/reports/audit?entityType=employee&entityId=${employeeId}`
    );
    expect(empAudit.body.events).toHaveLength(1);
    expect(empAudit.body.events[0].actor).toBe('hr-admin');

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const run = await runPayroll(employeeId, '2024-monthly-1', '3000.00');
    const stubId = run.body.payStub.id;

    const stubAudit = await request(ctx.app).get(
      `/api/reports/audit?entityType=pay_stub&entityId=${stubId}`
    );
    expect(stubAudit.body.events).toHaveLength(1);
  });

  it('returns HTML pay stub', async () => {
    const emp = await request(ctx.app).post('/api/employees').send({
      firstName: 'Html',
      lastName: 'Stub',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '3500.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const run = await runPayroll(emp.body.id, '2024-monthly-1', '3500.00');
    const html = await request(ctx.app).get(
      `/api/payroll/stubs/${run.body.payStub.id}/html`
    );
    expect(html.status).toBe(200);
    expect(html.text).toContain('Earnings Statement');
    expect(html.text).toContain('Net pay:');
  });
});
