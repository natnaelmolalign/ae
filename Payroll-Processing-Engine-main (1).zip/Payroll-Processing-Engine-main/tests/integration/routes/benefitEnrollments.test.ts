import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('benefit enrollments API', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('creates and lists enrollments for an employee', async () => {
    const emp = await request(ctx.app)
      .post('/api/employees')
      .send({
        firstName: 'Ben',
        lastName: 'Efits',
        employmentType: 'full_time_salaried',
        payFrequency: 'biweekly',
        baseCompensation: '6000.00',
        hireDate: '2024-01-01',
        filingStatus: 'single',
        stateCode: 'CA',
      })
      .expect(201);

    const year = new Date().getFullYear();
    const today = new Date().toISOString().slice(0, 10);

    await request(ctx.app)
      .post('/api/enrollment-windows')
      .send({
        code: `test-oe-${year}`,
        name: 'Test open enrollment',
        planYear: year,
        startDate: `${year}-01-01`,
        endDate: `${year}-12-31`,
        allowedBenefitTypes: ['401k_pretax'],
      })
      .expect(201);

    const created = await request(ctx.app)
      .post('/api/benefit-enrollments')
      .send({
        employeeId: emp.body.id,
        type: '401k_pretax',
        amountPerPeriod: '400.00',
        effectiveDate: today,
      })
      .expect(201);

    expect(created.body.type).toBe('401k_pretax');

    const list = await request(ctx.app)
      .get(`/api/benefit-enrollments?employeeId=${emp.body.id}`)
      .expect(200);

    expect(list.body.enrollments.length).toBeGreaterThanOrEqual(1);
  });
});
