import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('Pay policies (Enterprise E1)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  async function createEmployeeAndPeriod(): Promise<{
    employeeId: string;
    periodId: string;
  }> {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Policy',
      lastName: 'Worker',
      employmentType: 'full_time_salaried',
      payFrequency: 'semimonthly',
      baseCompensation: '6000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    expect(employeeRes.status).toBe(201);

    const periodsRes = await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'semimonthly' });
    expect(periodsRes.status).toBe(200);

    return {
      employeeId: employeeRes.body.id,
      periodId: periodsRes.body.periods[0].id,
    };
  }

  it('blocks payroll run when gross exceeds max_gross policy', async () => {
    const { employeeId, periodId } = await createEmployeeAndPeriod();

    const policyRes = await request(ctx.app)
      .post('/api/pay-policies')
      .send({
        code: 'CAP_GROSS',
        name: 'Gross cap',
        scope: 'company',
        priority: 10,
        effectiveFrom: '2024-01-01',
        rules: [{ type: 'max_gross', params: { amount: '1000.00' } }],
      });
    expect(policyRes.status).toBe(201);

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId,
        payPeriodId: periodId,
        year: 2024,
        frequency: 'semimonthly',
        earnings: [{ type: 'regular', amount: '6000.00' }],
        deductions: [],
        garnishments: [],
      });

    expect(runRes.status).toBe(400);
    expect(runRes.body.code).toBe('PAY_POLICY_VIOLATION');
    expect(runRes.body.violations?.[0]?.ruleType).toBe('max_gross');
  });

  it('allows payroll run when gross is within policy limits', async () => {
    const { employeeId, periodId } = await createEmployeeAndPeriod();

    await request(ctx.app)
      .post('/api/pay-policies')
      .send({
        code: 'CAP_HIGH',
        name: 'High gross cap',
        scope: 'company',
        priority: 10,
        effectiveFrom: '2024-01-01',
        rules: [{ type: 'max_gross', params: { amount: '10000.00' } }],
      });

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId,
        payPeriodId: periodId,
        year: 2024,
        frequency: 'semimonthly',
        earnings: [{ type: 'regular', amount: '6000.00' }],
        deductions: [],
        garnishments: [],
      });

    expect(runRes.status).toBe(200);
    expect(runRes.body.payStub.grossPay).toBe('6000.00');
  });

  it('validate endpoint reports violations without running payroll', async () => {
    const { employeeId, periodId } = await createEmployeeAndPeriod();

    await request(ctx.app)
      .post('/api/pay-policies')
      .send({
        code: 'MIN_GROSS',
        name: 'Minimum gross',
        scope: 'company',
        effectiveFrom: '2024-01-01',
        rules: [{ type: 'min_gross', params: { amount: '5000.00' } }],
      });

    const validateRes = await request(ctx.app)
      .post('/api/pay-policies/validate')
      .send({
        employeeId,
        payPeriodId: periodId,
        earnings: [{ type: 'regular', amount: '100.00' }],
        deductions: [],
        garnishments: [],
      });

    expect(validateRes.status).toBe(200);
    expect(validateRes.body.allowed).toBe(false);
    expect(validateRes.body.violations.length).toBeGreaterThan(0);
  });
});
