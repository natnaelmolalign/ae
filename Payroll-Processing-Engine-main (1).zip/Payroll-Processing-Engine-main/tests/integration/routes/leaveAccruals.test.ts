import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('Leave accruals (Enterprise E2)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('accrues balance and deducts PTO hours on payroll run', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Leave',
      lastName: 'Worker',
      employmentType: 'full_time_salaried',
      payFrequency: 'semimonthly',
      baseCompensation: '5000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = employeeRes.body.id;

    const policyRes = await request(ctx.app)
      .post('/api/leave-policies')
      .send({
        code: 'PTO_STD',
        name: 'Standard PTO',
        leaveType: 'pto',
        accrualMethod: 'fixed_per_period',
        accrualConfig: { hoursPerPeriod: '10.00' },
        effectiveFrom: '2024-01-01',
      });
    expect(policyRes.status).toBe(201);

    const periodsRes = await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'semimonthly' });
    const periodId = periodsRes.body.periods[0].id;

    const accrualRes = await request(ctx.app)
      .post('/api/admin/accrual-run')
      .send({ payPeriodId: periodId });
    expect(accrualRes.status).toBe(200);
    expect(accrualRes.body.accrualsPosted).toBeGreaterThan(0);

    const balanceRes = await request(ctx.app)
      .get(`/api/leave-balances?employeeId=${employeeId}&calendarYear=2024`)
      .send();
    expect(balanceRes.status).toBe(200);
    expect(balanceRes.body.balances[0].balanceHours).toBe('10.00');

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId,
        payPeriodId: periodId,
        year: 2024,
        frequency: 'semimonthly',
        earnings: [
          { type: 'regular', amount: '2500.00' },
          { type: 'pto', amount: '500.00', hours: 4 },
        ],
        deductions: [],
        garnishments: [],
      });
    expect(runRes.status).toBe(200);

    const afterRes = await request(ctx.app)
      .get(`/api/leave-balances?employeeId=${employeeId}&calendarYear=2024`)
      .send();
    expect(afterRes.body.balances[0].balanceHours).toBe('6.00');
  });

  it('rejects payroll when PTO hours exceed balance', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Low',
      lastName: 'Balance',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '4000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = employeeRes.body.id;

    await request(ctx.app)
      .post('/api/leave-policies')
      .send({
        code: 'PTO_SMALL',
        name: 'Small PTO',
        leaveType: 'pto',
        accrualMethod: 'fixed_per_period',
        accrualConfig: { hoursPerPeriod: '2.00' },
        effectiveFrom: '2024-01-01',
      });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodId = '2024-monthly-1';
    await request(ctx.app)
      .post('/api/admin/accrual-run')
      .send({ payPeriodId: periodId });

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId,
        payPeriodId: periodId,
        year: 2024,
        frequency: 'monthly',
        earnings: [{ type: 'pto', amount: '400.00', hours: 8 }],
        deductions: [],
        garnishments: [],
      });
    expect(runRes.status).toBe(400);
    expect(runRes.body.code).toBe('INSUFFICIENT_LEAVE_BALANCE');
  });
});
