import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';
import { BaseConnectorStub } from '../../../src/services/erp/ConnectorStubs';

const STANDARD_GL_MAPPINGS = [
  {
    internalAccountCode: '5100',
    externalAccountId: 'NS-5100',
    externalAccountName: 'Salaries Expense',
  },
  {
    internalAccountCode: '5200',
    externalAccountId: 'NS-5200',
    externalAccountName: 'Employer Tax Expense',
  },
  {
    internalAccountCode: '5180',
    externalAccountId: 'NS-5180',
    externalAccountName: '401k Match Expense',
  },
  {
    internalAccountCode: '2100',
    externalAccountId: 'NS-2100',
    externalAccountName: 'Federal WH Payable',
  },
  {
    internalAccountCode: '2110',
    externalAccountId: 'NS-2110',
    externalAccountName: 'State WH Payable',
  },
  {
    internalAccountCode: '2115',
    externalAccountId: 'NS-2115',
    externalAccountName: 'Local WH Payable',
  },
  {
    internalAccountCode: '2120',
    externalAccountId: 'NS-2120',
    externalAccountName: 'FICA Payable',
  },
  {
    internalAccountCode: '2130',
    externalAccountId: 'NS-2130',
    externalAccountName: 'Medicare Payable',
  },
  {
    internalAccountCode: '2140',
    externalAccountId: 'NS-2140',
    externalAccountName: 'Deductions Payable',
  },
  {
    internalAccountCode: '2150',
    externalAccountId: 'NS-2150',
    externalAccountName: 'Garnishment Payable',
  },
  {
    internalAccountCode: '2160',
    externalAccountId: 'NS-2160',
    externalAccountName: 'Net Pay Payable',
  },
];

describe('ERP connectors (Enterprise E6)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    BaseConnectorStub.clearRegistry();
    await resetTestData(ctx.deps);
  });

  it('exports GL to connector with idempotent replay', async () => {
    const emp = await request(ctx.app).post('/api/employees').send({
      firstName: 'ERP',
      lastName: 'Export',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '5000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodId = '2024-monthly-1';
    expect(
      (
        await request(ctx.app)
          .post('/api/payroll/run')
          .send({
            employeeId: emp.body.id,
            payPeriodId: periodId,
            year: 2024,
            frequency: 'monthly',
            earnings: [{ type: 'regular', amount: '5000.00' }],
            deductions: [],
            garnishments: [],
          })
      ).status
    ).toBe(200);

    const conn = await request(ctx.app)
      .post('/api/integration-connections')
      .send({ connectorType: 'netsuite', name: 'NetSuite Prod' });
    expect(conn.status).toBe(201);

    await request(ctx.app).post('/api/gl-account-mappings').send({
      connectionId: conn.body.id,
      mappings: STANDARD_GL_MAPPINGS,
    });

    const first = await request(ctx.app).post('/api/erp-exports').send({
      connectionId: conn.body.id,
      payPeriodId: periodId,
      idempotencyKey: 'period-export-v1',
    });
    expect(first.status).toBe(201);
    expect(first.body.mappingVersion).toBe(1);
    expect(first.body.externalJournalIds).toHaveLength(1);
    expect(first.body.connectorPayload.lines.length).toBeGreaterThan(0);
    expect(first.body.connectorPayload.totalDebits).toBe(
      first.body.connectorPayload.totalCredits
    );

    const replay = await request(ctx.app).post('/api/erp-exports').send({
      connectionId: conn.body.id,
      payPeriodId: periodId,
      idempotencyKey: 'period-export-v1',
    });
    expect(replay.status).toBe(201);
    expect(replay.body.id).toBe(first.body.id);
    expect(replay.body.externalJournalIds).toEqual(
      first.body.externalJournalIds
    );
  });

  it('retains historical mapping snapshot when mappings are versioned', async () => {
    const conn = await request(ctx.app)
      .post('/api/integration-connections')
      .send({ connectorType: 'quickbooks', name: 'QBO' });
    const connectionId = conn.body.id;

    await request(ctx.app)
      .post('/api/gl-account-mappings')
      .send({
        connectionId,
        mappings: [
          {
            internalAccountCode: '5100',
            externalAccountId: 'QB-v1-5100',
            externalAccountName: 'Salaries v1',
          },
          {
            internalAccountCode: '2160',
            externalAccountId: 'QB-v1-2160',
            externalAccountName: 'Net Pay v1',
          },
        ],
      });

    await request(ctx.app)
      .post('/api/gl-account-mappings')
      .send({
        connectionId,
        mappings: [
          {
            internalAccountCode: '5100',
            externalAccountId: 'QB-v2-5100',
            externalAccountName: 'Salaries v2',
          },
          {
            internalAccountCode: '2160',
            externalAccountId: 'QB-v2-2160',
            externalAccountName: 'Net Pay v2',
          },
        ],
      });

    const active = await request(ctx.app).get(
      `/api/gl-account-mappings?connectionId=${connectionId}`
    );
    expect(active.body.version).toBe(2);
    const active5100 = active.body.mappings.find(
      (m: { internalAccountCode: string }) => m.internalAccountCode === '5100'
    );
    expect(active5100.externalAccountId).toBe('QB-v2-5100');

    const v1 = await request(ctx.app).get(
      `/api/gl-account-mappings?connectionId=${connectionId}&version=1`
    );
    const v1_5100 = v1.body.mappings.find(
      (m: { internalAccountCode: string }) => m.internalAccountCode === '5100'
    );
    expect(v1_5100.externalAccountId).toBe('QB-v1-5100');
  });
});
