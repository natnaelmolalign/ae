import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('Equity compensation payroll (Advanced Phase 4)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('withholds 22% federal on RSU-only vest with default election', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Equity',
      lastName: 'Holder',
      employmentType: 'full_time_salaried',
      payFrequency: 'biweekly',
      baseCompensation: '8000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'biweekly' });

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId: employeeRes.body.id,
        payPeriodId: '2024-biweekly-1',
        year: 2024,
        frequency: 'biweekly',
        earnings: [{ type: 'rsu_vest', amount: '10000.00' }],
        deductions: [],
      });

    expect(runRes.status).toBe(200);
    expect(runRes.body.taxes.federalIncome).toBe('2200.00');
    expect(runRes.body.equitySummary.totalEquity).toBe('10000.00');
    expect(runRes.body.equitySummary.withholdingMethod).toBe(
      'supplemental_flat'
    );

    const rsuLine = runRes.body.payStub.lines.find(
      (l: { label: string }) => l.label === 'RSU Vest'
    );
    expect(rsuLine?.current).toBe('10000.00');
  });

  it('does not regress bonus supplemental flat withholding', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Bonus',
      lastName: 'Only',
      employmentType: 'full_time_salaried',
      payFrequency: 'biweekly',
      baseCompensation: '5000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'biweekly' });

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId: employeeRes.body.id,
        payPeriodId: '2024-biweekly-1',
        year: 2024,
        frequency: 'biweekly',
        earnings: [{ type: 'bonus', amount: '5000.00' }],
        deductions: [],
      });

    expect(runRes.status).toBe(200);
    expect(runRes.body.taxes.federalIncome).toBe('1100.00');
    expect(runRes.body.equitySummary).toBeUndefined();
  });

  it('applies W-4 annualized withholding when elected', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'W4',
      lastName: 'Equity',
      employmentType: 'full_time_salaried',
      payFrequency: 'biweekly',
      baseCompensation: '8000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
      equityWithholdingMethod: 'w4_annualized',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'biweekly' });

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId: employeeRes.body.id,
        payPeriodId: '2024-biweekly-1',
        year: 2024,
        frequency: 'biweekly',
        earnings: [{ type: 'rsu_vest', amount: '10000.00' }],
        deductions: [],
      });

    expect(runRes.status).toBe(200);
    expect(runRes.body.taxes.federalIncome).not.toBe('2200.00');
    expect(runRes.body.equitySummary.withholdingMethod).toBe('w4_annualized');
  });
});
