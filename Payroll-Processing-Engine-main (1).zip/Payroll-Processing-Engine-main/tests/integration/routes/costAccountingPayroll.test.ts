import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('Cost accounting payroll (Advanced Phase 8)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('splits gross 50/50 across two departments in labor-cost and GL', async () => {
    const eng = await request(ctx.app).post('/api/departments').send({
      code: 'ENG',
      name: 'Engineering',
      locationCode: 'NYC',
    });
    const sls = await request(ctx.app).post('/api/departments').send({
      code: 'SLS',
      name: 'Sales',
      locationCode: 'BOS',
    });
    expect(eng.status).toBe(201);
    expect(sls.status).toBe(201);

    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Cost',
      lastName: 'Split',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '10000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = employeeRes.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodId = '2024-monthly-1';
    const run = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId,
        payPeriodId: periodId,
        year: 2024,
        frequency: 'monthly',
        earnings: [{ type: 'regular', amount: '10000.00' }],
        deductions: [],
        costAllocations: [
          { departmentId: eng.body.id, percent: '50' },
          { departmentId: sls.body.id, percent: '50' },
        ],
      });
    expect(run.status).toBe(200);

    const labor = await request(ctx.app).get(
      `/api/reports/labor-cost?periodId=${periodId}`
    );
    expect(labor.status).toBe(200);
    const engRow = labor.body.departments.find(
      (d: { departmentCode: string }) => d.departmentCode === 'ENG'
    );
    const slsRow = labor.body.departments.find(
      (d: { departmentCode: string }) => d.departmentCode === 'SLS'
    );
    expect(engRow.grossPay).toBe('5000.00');
    expect(slsRow.grossPay).toBe('5000.00');
    expect(labor.body.totals.grossPay).toBe('10000.00');

    const register = await request(ctx.app).get(
      `/api/reports/payroll-register?periodId=${periodId}`
    );
    expect(register.status).toBe(200);
    expect(register.body.register.rows[0].costAllocations).toHaveLength(2);

    const gl = await request(ctx.app).get(
      `/api/reports/gl-export?periodId=${periodId}`
    );
    expect(gl.status).toBe(200);
    expect(gl.body.allBalanced).toBe(true);
    const engGl = gl.body.exports[0].lines.filter(
      (l: { departmentCode?: string }) => l.departmentCode === 'ENG'
    );
    expect(engGl.length).toBeGreaterThan(0);
  });

  it('scopes departments by company tenant', async () => {
    const created = await request(ctx.app)
      .post('/api/departments')
      .set('X-Company-Id', 'tenant-a')
      .send({ code: 'HR', name: 'Human Resources' });
    expect(created.status).toBe(201);

    const listA = await request(ctx.app)
      .get('/api/departments')
      .set('X-Company-Id', 'tenant-a');
    expect(
      listA.body.departments.some((d: { code: string }) => d.code === 'HR')
    ).toBe(true);

    const listB = await request(ctx.app)
      .get('/api/departments')
      .set('X-Company-Id', 'tenant-b');
    expect(
      listB.body.departments.some((d: { code: string }) => d.code === 'HR')
    ).toBe(false);
  });
});
