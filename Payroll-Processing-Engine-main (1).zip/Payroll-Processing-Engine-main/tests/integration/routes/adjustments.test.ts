import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('retro adjustments (Phase 7)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  async function setupEmployeeWithThreeRuns() {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Retro',
      lastName: 'Raise',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '12000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    expect(employeeRes.status).toBe(201);
    const employeeId = employeeRes.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodIds = ['2024-monthly-1', '2024-monthly-2', '2024-monthly-3'];
    for (const payPeriodId of periodIds) {
      const run = await request(ctx.app)
        .post('/api/payroll/run')
        .send({
          employeeId,
          payPeriodId,
          year: 2024,
          frequency: 'monthly',
          earnings: [{ type: 'regular', amount: '1000.00' }],
          deductions: [],
          garnishments: [],
        });
      expect(run.status).toBe(200);
    }

    return { employeeId, currentPeriodId: '2024-monthly-4' };
  }

  it('3-period backdated raise updates YTD and posts catch-up on current period', async () => {
    const { employeeId, currentPeriodId } = await setupEmployeeWithThreeRuns();

    const draftRes = await request(ctx.app)
      .post('/api/adjustments')
      .send({
        employeeId,
        effectiveDate: '2024-01-01',
        currentPayPeriodId: currentPeriodId,
        year: 2024,
        frequency: 'monthly',
        reason: 'Salary increase',
        earningsPerPeriod: [{ type: 'regular', amount: '1200.00' }],
      });
    expect(draftRes.status).toBe(201);
    const adjustmentId = draftRes.body.id;

    const previewRes = await request(ctx.app)
      .post(`/api/adjustments/${adjustmentId}/preview`)
      .send({ year: 2024, frequency: 'monthly' });
    expect(previewRes.status).toBe(200);
    expect(previewRes.body.preview.projectedYtdGross).toBe('3600.00');
    expect(parseFloat(previewRes.body.preview.totalNetCatchUp)).toBeGreaterThan(
      0
    );

    await request(ctx.app)
      .post(`/api/adjustments/${adjustmentId}/approve`)
      .expect(200);

    const applyRes = await request(ctx.app)
      .post(`/api/adjustments/${adjustmentId}/apply`)
      .send({ year: 2024, frequency: 'monthly' });
    expect(applyRes.status).toBe(200);
    expect(applyRes.body.catchUpPayStubId).toBeTruthy();

    const ytd = await ctx.deps.ytdRepository.get(employeeId, 2024);
    expect(ytd.grossEarnings).toBe('3600.00');

    const catchUp = await ctx.deps.payStubRepository.findById(
      applyRes.body.catchUpPayStubId
    );
    expect(catchUp?.isCorrection).toBe(true);
    expect(catchUp?.correctsPayStubId).toBeTruthy();
  });

  it('blocks adjustment when current payment is after termination', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Term',
      lastName: 'Retro',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '5000.00',
      hireDate: '2024-01-01',
      terminationDate: '2024-02-15',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = employeeRes.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const draftRes = await request(ctx.app)
      .post('/api/adjustments')
      .send({
        employeeId,
        effectiveDate: '2024-01-01',
        currentPayPeriodId: '2024-monthly-4',
        year: 2024,
        frequency: 'monthly',
        reason: 'Late raise',
        earningsPerPeriod: [{ type: 'regular', amount: '1200.00' }],
      });
    expect(draftRes.status).toBe(201);

    const previewRes = await request(ctx.app)
      .post(`/api/adjustments/${draftRes.body.id}/preview`)
      .send({ year: 2024, frequency: 'monthly' });
    expect(previewRes.status).toBe(400);
    expect(previewRes.body.code).toBe('RETRO_AFTER_TERMINATION');
  });

  it('rejects apply before approve', async () => {
    const { employeeId, currentPeriodId } = await setupEmployeeWithThreeRuns();

    const draftRes = await request(ctx.app)
      .post('/api/adjustments')
      .send({
        employeeId,
        effectiveDate: '2024-01-01',
        currentPayPeriodId: currentPeriodId,
        year: 2024,
        frequency: 'monthly',
        reason: 'Skip approve',
        earningsPerPeriod: [{ type: 'regular', amount: '1200.00' }],
      });

    const applyRes = await request(ctx.app)
      .post(`/api/adjustments/${draftRes.body.id}/apply`)
      .send({ year: 2024, frequency: 'monthly' });
    expect(applyRes.status).toBe(409);
    expect(applyRes.body.code).toBe('RETRO_INVALID_STATE');
  });
});
