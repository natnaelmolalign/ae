import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('deduction preview API', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('returns capped deductions and limit adjustments', async () => {
    const emp = await request(ctx.app)
      .post('/api/employees')
      .send({
        firstName: 'Ded',
        lastName: 'Preview',
        employmentType: 'full_time_salaried',
        payFrequency: 'biweekly',
        baseCompensation: '5000.00',
        hireDate: '2024-01-01',
        filingStatus: 'single',
        stateCode: 'TX',
      })
      .expect(201);

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'biweekly' })
      .expect(200);

    const res = await request(ctx.app)
      .post('/api/deductions/preview')
      .send({
        employeeId: emp.body.id,
        payPeriodId: '2024-biweekly-1',
        year: 2024,
        frequency: 'biweekly',
        earnings: [{ type: 'regular', amount: '5000.00' }],
        deductions: [
          { type: '401k_pretax', amountPerPeriod: '1000.00' },
          { type: 'section_125', amountPerPeriod: '200.00' },
        ],
      })
      .expect(200);

    expect(res.body.bases.pretax401kAmount).toBe('1000.00');
    expect(res.body.withinGross).toBe(true);
  });
});
