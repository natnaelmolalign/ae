import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('Workforce scheduling (Enterprise E3)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('approves shift time and runs payroll from approved entries', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Shift',
      lastName: 'Worker',
      employmentType: 'full_time_hourly',
      payFrequency: 'semimonthly',
      baseCompensation: '25.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = employeeRes.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'semimonthly' });
    const periodId = '2024-semimonthly-1';

    const shiftRes = await request(ctx.app).post('/api/shifts').send({
      workDate: '2024-01-08',
      startTime: '2024-01-08T08:00:00.000Z',
      endTime: '2024-01-08T16:00:00.000Z',
      breakMinutes: 30,
    });
    expect(shiftRes.status).toBe(201);

    const assignRes = await request(ctx.app)
      .post(`/api/shifts/${shiftRes.body.id}/assignments`)
      .send({ employeeId });
    expect(assignRes.status).toBe(201);
    const assignmentId = assignRes.body.id;

    const entryRes = await request(ctx.app).post('/api/time-entries').send({
      employeeId,
      payPeriodId: periodId,
      shiftAssignmentId: assignmentId,
      workDate: '2024-01-08',
      clockIn: '2024-01-08T08:00:00.000Z',
      clockOut: '2024-01-08T16:00:00.000Z',
    });
    expect(entryRes.status).toBe(201);

    const approveRes = await request(ctx.app).post(
      `/api/shifts/assignments/${assignmentId}/approve`
    );
    expect(approveRes.status).toBe(200);
    expect(approveRes.body.status).toBe('approved');
    expect(approveRes.body.approvedMinutes).toBe(480);

    const runRes = await request(ctx.app).post('/api/payroll/run').send({
      employeeId,
      payPeriodId: periodId,
      year: 2024,
      frequency: 'semimonthly',
      useTimeEntries: true,
      hourlyRate: '25.00',
      earnings: [],
      deductions: [],
      garnishments: [],
    });
    expect(runRes.status).toBe(200);
    expect(parseFloat(runRes.body.payStub.grossPay)).toBeGreaterThan(0);
  });

  it('blocks payroll when shift assignments are pending', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Pending',
      lastName: 'Shift',
      employmentType: 'full_time_hourly',
      payFrequency: 'semimonthly',
      baseCompensation: '20.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = employeeRes.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'semimonthly' });

    const shiftRes = await request(ctx.app).post('/api/shifts').send({
      workDate: '2024-01-09',
      startTime: '2024-01-09T09:00:00.000Z',
      endTime: '2024-01-09T17:00:00.000Z',
    });
    const assignRes = await request(ctx.app)
      .post(`/api/shifts/${shiftRes.body.id}/assignments`)
      .send({ employeeId });

    await request(ctx.app).post('/api/time-entries').send({
      employeeId,
      payPeriodId: '2024-semimonthly-1',
      shiftAssignmentId: assignRes.body.id,
      workDate: '2024-01-09',
      clockIn: '2024-01-09T09:00:00.000Z',
      clockOut: '2024-01-09T17:00:00.000Z',
    });

    const previewRes = await request(ctx.app)
      .post('/api/earnings/preview')
      .send({
        employeeId,
        payPeriodId: '2024-semimonthly-1',
        year: 2024,
        frequency: 'semimonthly',
        useTimeEntries: true,
        hourlyRate: '20.00',
      });
    expect(previewRes.status).toBe(409);
    expect(previewRes.body.code).toBe('TIME_NOT_APPROVED');
  });
});
