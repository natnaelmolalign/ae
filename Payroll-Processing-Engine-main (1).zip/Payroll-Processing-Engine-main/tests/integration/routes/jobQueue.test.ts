import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('Job queue (Enterprise E8)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('accepts queued batch and worker processes employees', async () => {
    const emp = await request(ctx.app).post('/api/employees').send({
      firstName: 'Queue',
      lastName: 'Worker',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '5000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    expect(emp.status).toBe(201);

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    await request(ctx.app)
      .post('/api/payroll/readiness')
      .send({
        payPeriodId: '2024-monthly-1',
        employeeIds: [emp.body.id],
      });

    const batchRes = await request(ctx.app).post('/api/payroll/batch').send({
      payPeriodId: '2024-monthly-1',
      year: 2024,
      frequency: 'monthly',
      useQueue: true,
    });
    expect(batchRes.status).toBe(202);
    expect(batchRes.body.mode).toBe('queued');
    expect(batchRes.body.enqueued).toBe(1);

    const processed = await ctx.deps.jobWorkerService.runLoop('test-worker', {
      maxIterations: 5,
      idleMs: 0,
    });
    expect(processed).toBeGreaterThanOrEqual(1);

    const status = await request(ctx.app).get(
      `/api/payroll/batch/${batchRes.body.batch.id}`
    );
    expect(status.status).toBe(200);
    expect(status.body.batch.successCount).toBe(1);
  });
});
