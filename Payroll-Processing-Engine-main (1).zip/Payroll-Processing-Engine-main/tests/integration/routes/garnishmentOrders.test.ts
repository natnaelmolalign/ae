import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('garnishment orders API', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('creates order and applies on payroll with remittance', async () => {
    const emp = await request(ctx.app)
      .post('/api/employees')
      .send({
        firstName: 'Garn',
        lastName: 'Ished',
        employmentType: 'full_time_salaried',
        payFrequency: 'monthly',
        baseCompensation: '5000.00',
        hireDate: '2024-01-01',
        filingStatus: 'single',
        stateCode: 'TX',
      })
      .expect(201);

    await request(ctx.app)
      .post('/api/garnishment-orders')
      .send({
        employeeId: emp.body.id,
        type: 'child_support',
        caseId: 'CS-100',
        fixedAmount: '200.00',
        effectiveDate: '2024-01-01',
      })
      .expect(201);

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' })
      .expect(200);

    const run = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId: emp.body.id,
        payPeriodId: '2024-monthly-1',
        year: 2024,
        frequency: 'monthly',
        earnings: [{ type: 'regular', amount: '5000.00' }],
        deductions: [],
        garnishments: [],
        useActiveGarnishmentOrders: true,
      })
      .expect(200);

    expect(run.body.garnishmentRemittances?.length).toBeGreaterThanOrEqual(1);
    expect(run.body.garnishmentRemittances[0].amount).toBe('200.00');
  });
});
