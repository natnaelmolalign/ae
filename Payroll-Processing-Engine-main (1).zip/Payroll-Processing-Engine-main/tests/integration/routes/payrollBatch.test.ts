import request from 'supertest';
import { randomUUID } from 'crypto';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';
import { setPayrollMetrics } from '../../../src/metrics/hooks';
import { InMemoryPayrollMetrics } from '../../../src/metrics/InMemoryPayrollMetrics';

describe('POST /api/payroll/batch', () => {
  let ctx: TestContext;
  const metrics = new InMemoryPayrollMetrics();

  beforeAll(async () => {
    ctx = await initTestContext();
    setPayrollMetrics(metrics);
  });

  beforeEach(async () => {
    metrics.reset();
    await resetTestData(ctx.deps);
  });

  async function createEmployee(name: string) {
    const res = await request(ctx.app).post('/api/employees').send({
      firstName: name,
      lastName: 'Batch',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '4000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    expect(res.status).toBe(201);
    return res.body.id as string;
  }

  it('runs batch for ready employees and records metrics', async () => {
    const e1 = await createEmployee('A');
    const e2 = await createEmployee('B');

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodId = '2024-monthly-1';

    await request(ctx.app)
      .post('/api/payroll/readiness')
      .send({
        payPeriodId: periodId,
        employeeIds: [e1, e2],
      });

    const batchRes = await request(ctx.app).post('/api/payroll/batch').send({
      payPeriodId: periodId,
      year: 2024,
      frequency: 'monthly',
      parallelLimit: 2,
    });

    expect(batchRes.status).toBe(201);
    expect(batchRes.body.batch.successCount).toBe(2);
    expect(batchRes.body.batch.failureCount).toBe(0);
    expect(batchRes.body.batch.status).toBe('completed');
    expect(metrics.lastBatch?.successCount).toBe(2);

    const getRes = await request(ctx.app).get(
      `/api/payroll/batch/${batchRes.body.batch.id}`
    );
    expect(getRes.status).toBe(200);
    expect(getRes.body.batch.id).toBe(batchRes.body.batch.id);
  });

  it('commits successes when one employee already has a run (partial failure)', async () => {
    const e1 = await createEmployee('Ok');
    const e2 = await createEmployee('Dup');

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodId = '2024-monthly-1';

    await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId: e2,
        payPeriodId: periodId,
        year: 2024,
        frequency: 'monthly',
        earnings: [{ type: 'regular', amount: '4000.00' }],
        deductions: [],
        garnishments: [],
      });

    await request(ctx.app)
      .post('/api/payroll/readiness')
      .send({
        payPeriodId: periodId,
        employeeIds: [e1, e2],
      });

    const batchRes = await request(ctx.app).post('/api/payroll/batch').send({
      payPeriodId: periodId,
      year: 2024,
      frequency: 'monthly',
    });

    expect(batchRes.status).toBe(201);
    expect(batchRes.body.batch.successCount).toBe(1);
    expect(batchRes.body.batch.failureCount).toBe(1);
    expect(batchRes.body.failures).toHaveLength(1);
    expect(batchRes.body.failures[0].errorCode).toBe('DUPLICATE_PAYROLL_RUN');

    const ytdOk = await ctx.deps.ytdRepository.get(e1, 2024);
    expect(parseFloat(ytdOk.grossEarnings)).toBeGreaterThan(0);
  });

  it('batch idempotency key returns original stub on retry', async () => {
    const employeeId = await createEmployee('Idem');

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodId = '2024-monthly-1';
    const batchId = randomUUID();
    const key = `batch-${batchId}-${employeeId}`;

    const first = await request(ctx.app)
      .post('/api/payroll/run')
      .set('idempotency-key', key)
      .send({
        employeeId,
        payPeriodId: periodId,
        year: 2024,
        frequency: 'monthly',
        earnings: [{ type: 'regular', amount: '4000.00' }],
        deductions: [],
        garnishments: [],
      });

    const second = await request(ctx.app)
      .post('/api/payroll/run')
      .set('idempotency-key', key)
      .send({
        employeeId,
        payPeriodId: periodId,
        year: 2024,
        frequency: 'monthly',
        earnings: [{ type: 'regular', amount: '4000.00' }],
        deductions: [],
        garnishments: [],
      });

    expect(first.status).toBe(200);
    expect(second.status).toBe(200);
    expect(second.body.payStub.id).toBe(first.body.payStub.id);

    const ytd = await ctx.deps.ytdRepository.get(employeeId, 2024);
    expect(ytd.grossEarnings).toBe('4000.00');
  });

  it('parallel batch keeps separate YTD per employee', async () => {
    const ids = await Promise.all([
      createEmployee('P1'),
      createEmployee('P2'),
      createEmployee('P3'),
    ]);

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodId = '2024-monthly-1';
    await request(ctx.app).post('/api/payroll/readiness').send({
      payPeriodId: periodId,
      employeeIds: ids,
    });

    const batchRes = await request(ctx.app).post('/api/payroll/batch').send({
      payPeriodId: periodId,
      year: 2024,
      frequency: 'monthly',
      parallelLimit: 3,
    });

    expect(batchRes.body.batch.successCount).toBe(3);

    for (const id of ids) {
      const ytd = await ctx.deps.ytdRepository.get(id, 2024);
      expect(ytd.grossEarnings).toBe('4000.00');
    }
  });
});
