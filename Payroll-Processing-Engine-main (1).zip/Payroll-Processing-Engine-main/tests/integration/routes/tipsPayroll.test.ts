import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('Tips and tip credit payroll (Advanced Phase 3)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('runs tipped hourly pay with FICA on tips and tip credit make-up', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Tipped',
      lastName: 'Server',
      employmentType: 'full_time_hourly',
      payFrequency: 'biweekly',
      baseCompensation: '2.13',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = employeeRes.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'biweekly' });

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId,
        payPeriodId: '2024-biweekly-1',
        year: 2024,
        frequency: 'biweekly',
        earnings: [
          { type: 'regular', amount: '85.20', hours: 40 },
          { type: 'cash_tips', amount: '100.00' },
        ],
        deductions: [],
        tipCredit: { hours: 40, directCashWages: '85.20' },
      });

    expect(runRes.status).toBe(200);
    expect(runRes.body.tipSummary.tipCreditMakeup).toBe('104.80');
    expect(Number(runRes.body.taxes.socialSecurity)).toBeGreaterThan(0);
    expect(Number(runRes.body.payStub.grossPay)).toBeGreaterThan(285);
    expect(runRes.body.employerContributions.flsaTipCreditMakeup).toBe(
      '104.80'
    );

    const tipReg = await request(ctx.app).get(
      '/api/reports/tip-register?periodId=2024-biweekly-1'
    );
    expect(tipReg.status).toBe(200);
    expect(Number(tipReg.body.totals.cashTips)).toBe(100);
  });

  it('includes allocated tips in gross without double-count error', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Alloc',
      lastName: 'Tips',
      employmentType: 'full_time_hourly',
      payFrequency: 'monthly',
      baseCompensation: '3000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId: employeeRes.body.id,
        payPeriodId: '2024-monthly-1',
        year: 2024,
        frequency: 'monthly',
        earnings: [
          { type: 'regular', amount: '2000.00' },
          { type: 'allocated_tips', amount: '150.00' },
        ],
        deductions: [],
      });

    expect(runRes.status).toBe(200);
    expect(runRes.body.payStub.grossPay).toBe('2150.00');
  });
});
