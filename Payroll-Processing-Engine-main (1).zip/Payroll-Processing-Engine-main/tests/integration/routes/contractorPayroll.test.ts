import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('Contractor 1099 payroll (Advanced Phase 1)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('runs contractor pay with zero withholding and reconciled net', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Indie',
      lastName: 'Contractor',
      employmentType: 'contractor',
      payFrequency: 'monthly',
      baseCompensation: '4000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    expect(employeeRes.status).toBe(201);
    const employeeId = employeeRes.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId,
        payPeriodId: '2024-monthly-1',
        year: 2024,
        frequency: 'monthly',
        earnings: [{ type: 'regular', amount: '4000.00' }],
        deductions: [],
      });

    expect(runRes.status).toBe(200);
    expect(runRes.body.taxes.federalIncome).toBe('0.00');
    expect(runRes.body.taxes.socialSecurity).toBe('0.00');
    expect(runRes.body.taxes.medicare).toBe('0.00');
    expect(runRes.body.payStub.grossPay).toBe('4000.00');
    expect(runRes.body.payStub.netPay).toBe('4000.00');
    expect(runRes.body.employerContributions.ss).toBe('0.00');
  });

  it('rejects pre-tax 401k on contractor', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Bad',
      lastName: 'Deduction',
      employmentType: 'contractor',
      payFrequency: 'monthly',
      baseCompensation: '1000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId: employeeRes.body.id,
        payPeriodId: '2024-monthly-1',
        year: 2024,
        frequency: 'monthly',
        earnings: [{ type: 'regular', amount: '1000.00' }],
        deductions: [{ type: '401k_pretax', amountPerPeriod: '50.00' }],
      });

    expect(runRes.status).toBe(400);
    expect(runRes.body.code).toBe('INVALID_INPUT');
  });
});
