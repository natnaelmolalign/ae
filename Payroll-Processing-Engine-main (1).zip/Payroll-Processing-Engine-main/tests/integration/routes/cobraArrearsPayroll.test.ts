import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('COBRA and arrears payroll (Advanced Phase 5)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('deducts arrears over three periods until balance is zero', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Arrears',
      lastName: 'Worker',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '4000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = employeeRes.body.id;

    await request(ctx.app).post('/api/deduction-schedules').send({
      employeeId,
      scheduleType: 'arrears',
      amountPerPeriod: '100.00',
      remainingBalance: '300.00',
      startDate: '2024-01-01',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const periodIds = ['2024-monthly-1', '2024-monthly-2', '2024-monthly-3'];

    for (let i = 0; i < 3; i++) {
      const runRes = await request(ctx.app)
        .post('/api/payroll/run')
        .send({
          employeeId,
          payPeriodId: periodIds[i],
          year: 2024,
          frequency: 'monthly',
          earnings: [{ type: 'regular', amount: '2000.00' }],
          deductions: [],
          useActiveDeductionSchedules: true,
        });
      expect(runRes.status).toBe(200);
      expect(runRes.body.scheduledDeductions.arrearsRecovery).toBe('100.00');
    }

    const run4 = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId,
        payPeriodId: '2024-monthly-4',
        year: 2024,
        frequency: 'monthly',
        earnings: [{ type: 'regular', amount: '2000.00' }],
        deductions: [],
        useActiveDeductionSchedules: true,
      });
    expect(run4.body.scheduledDeductions?.arrearsRecovery ?? '0.00').toBe(
      '0.00'
    );

    const schedules = await request(ctx.app).get(
      `/api/deduction-schedules?employeeId=${employeeId}`
    );
    const arrears = schedules.body.schedules.find(
      (s: { scheduleType: string }) => s.scheduleType === 'arrears'
    );
    expect(arrears.remainingBalance).toBe('0.00');
  });

  it('does not reduce pre-tax bases for COBRA in preview', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Cobra',
      lastName: 'Member',
      employmentType: 'full_time_salaried',
      payFrequency: 'biweekly',
      baseCompensation: '5000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    await request(ctx.app).post('/api/deduction-schedules').send({
      employeeId: employeeRes.body.id,
      scheduleType: 'cobra_premium',
      amountPerPeriod: '650.00',
      startDate: '2024-01-01',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'biweekly' });

    const preview = await request(ctx.app)
      .post('/api/deductions/preview')
      .send({
        employeeId: employeeRes.body.id,
        payPeriodId: '2024-biweekly-1',
        year: 2024,
        frequency: 'biweekly',
        earnings: [{ type: 'regular', amount: '3000.00' }],
        useActiveDeductionSchedules: true,
      });

    expect(preview.status).toBe(200);
    expect(preview.body.bases.federalTaxableReduction).toBe('0.00');
    expect(preview.body.federalTaxableAfterPretax).toBe('3000.00');
    expect(preview.body.scheduledDeductions.total).toBe('650.00');
  });

  it('skips arrears when payment is after termination', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'Term',
      lastName: 'Arrears',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '4000.00',
      hireDate: '2024-01-01',
      terminationDate: '2024-02-15',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    await request(ctx.app).post('/api/deduction-schedules').send({
      employeeId: employeeRes.body.id,
      scheduleType: 'arrears',
      amountPerPeriod: '100.00',
      remainingBalance: '200.00',
      startDate: '2024-01-01',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'monthly' });

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId: employeeRes.body.id,
        payPeriodId: '2024-monthly-3',
        year: 2024,
        frequency: 'monthly',
        earnings: [{ type: 'regular', amount: '2000.00' }],
        deductions: [],
        useActiveDeductionSchedules: true,
      });

    expect(runRes.status).toBe(200);
    expect(runRes.body.scheduledDeductions?.total ?? '0.00').toBe('0.00');
  });
});
