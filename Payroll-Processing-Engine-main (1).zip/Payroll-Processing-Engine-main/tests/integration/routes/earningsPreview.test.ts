import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('POST /api/earnings/preview vs payroll run', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('preview net pay matches payroll run for time-entry hourly employee', async () => {
    const emp = await request(ctx.app).post('/api/employees').send({
      firstName: 'Hourly',
      lastName: 'Worker',
      employmentType: 'full_time_hourly',
      payFrequency: 'weekly',
      baseCompensation: '20.00',
      hireDate: '2024-06-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = emp.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'weekly', biweeklyAnchor: '2024-06-03' });

    const periodId = '2024-weekly-1';

    await request(ctx.app).post('/api/time-entries').send({
      employeeId,
      payPeriodId: periodId,
      workDate: '2024-06-03',
      clockIn: '2024-06-03T08:00:00Z',
      clockOut: '2024-06-07T23:00:00Z',
      entryType: 'regular',
    });

    const previewBody = {
      employeeId,
      payPeriodId: periodId,
      year: 2024,
      frequency: 'weekly',
      useTimeEntries: true,
      hourlyRate: '20.00',
      deductions: [],
      garnishments: [],
    };

    const preview = await request(ctx.app)
      .post('/api/earnings/preview')
      .send(previewBody);
    expect(preview.status).toBe(200);

    const run = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        ...previewBody,
        earnings: preview.body.earningsLines,
        useTimeEntries: undefined,
      });
    expect(run.status).toBe(200);

    expect(run.body.payStub.netPay).toBe(preview.body.payStub.netPay);
    expect(run.body.payStub.grossPay).toBe(preview.body.payStub.grossPay);
  });
});
