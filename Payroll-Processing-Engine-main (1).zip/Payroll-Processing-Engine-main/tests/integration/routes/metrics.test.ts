import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';
import { initPrometheusMetrics } from '../../../src/metrics/prometheus';

describe('GET /metrics (Advanced Phase 9)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    initPrometheusMetrics();
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('exposes payroll histograms without auth', async () => {
    const res = await request(ctx.app).get('/metrics');
    expect(res.status).toBe(200);
    expect(res.text).toContain('payroll_run_duration_ms');
    expect(res.text).toContain('payroll_batch_size');
  });

  it('returns traceparent on API responses', async () => {
    const res = await request(ctx.app)
      .get('/health')
      .set('X-Correlation-Id', 'test-corr-123');
    const traceHeader =
      res.headers['traceparent'] ?? res.headers['Traceparent'];
    expect(String(traceHeader)).toMatch(/^00-/);
    expect(res.headers['x-correlation-id']).toBe('test-corr-123');
  });
});
