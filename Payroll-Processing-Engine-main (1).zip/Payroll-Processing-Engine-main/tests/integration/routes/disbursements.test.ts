import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('Disbursements (Enterprise E5)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('creates payment batch with balanced splits and NACHA file', async () => {
    const emp = await request(ctx.app).post('/api/employees').send({
      firstName: 'Pay',
      lastName: 'Split',
      employmentType: 'full_time_salaried',
      payFrequency: 'semimonthly',
      baseCompensation: '5000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'semimonthly' });

    const run = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId: emp.body.id,
        payPeriodId: '2024-semimonthly-1',
        year: 2024,
        frequency: 'semimonthly',
        earnings: [{ type: 'regular', amount: '5000.00' }],
        deductions: [],
        garnishments: [],
      });
    expect(run.status).toBe(200);
    const netPay = run.body.payStub.netPay;

    await request(ctx.app).post('/api/disbursement-instructions').send({
      employeeId: emp.body.id,
      splitType: 'percent',
      percent: '0.60',
      priority: 1,
      routingNumber: '021000021',
      accountNumber: '111122223333',
    });
    await request(ctx.app).post('/api/disbursement-instructions').send({
      employeeId: emp.body.id,
      splitType: 'fixed',
      fixedAmount: '200.00',
      priority: 2,
      routingNumber: '021000021',
      accountNumber: '444455556666',
    });
    await request(ctx.app).post('/api/disbursement-instructions').send({
      employeeId: emp.body.id,
      splitType: 'remainder',
      priority: 3,
      routingNumber: '021000021',
      accountNumber: '777788889999',
    });

    const batchRes = await request(ctx.app).post('/api/payment-batches').send({
      payPeriodId: '2024-semimonthly-1',
    });
    expect(batchRes.status).toBe(201);
    expect(batchRes.body.totalNetPay).toBe(netPay);
    expect(batchRes.body.totalAchCredit).toBe(netPay);

    const submitRes = await request(ctx.app)
      .post(`/api/payment-batches/${batchRes.body.id}/submit`)
      .send({
        companyRouting: '021000021',
        companyAccount: '9999888877776666',
        companyName: 'ACME PAYROLL',
        effectiveDate: '2024-01-15',
      });
    expect(submitRes.status).toBe(200);
    expect(submitRes.body.achFile.entryCount).toBeGreaterThan(0);

    const recon = await request(ctx.app).get(
      `/api/payment-batches/${batchRes.body.id}/reconciliation`
    );
    expect(recon.status).toBe(200);
    expect(recon.body.balanced).toBe(true);
    expect(recon.body.totalNetPay).toBe(recon.body.totalAchCredit);
  });

  it('stores tokenized account numbers, not raw values', async () => {
    const emp = await request(ctx.app).post('/api/employees').send({
      firstName: 'Token',
      lastName: 'Test',
      employmentType: 'full_time_salaried',
      payFrequency: 'monthly',
      baseCompensation: '4000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });

    const created = await request(ctx.app)
      .post('/api/disbursement-instructions')
      .send({
        employeeId: emp.body.id,
        splitType: 'remainder',
        priority: 1,
        routingNumber: '021000021',
        accountNumber: '1234567890',
      });
    expect(created.status).toBe(201);
    expect(created.body.accountNumberToken).toMatch(/^tok_acct_/);
    expect(created.body.accountLastFour).toBe('7890');
    expect(created.body.accountNumberToken).not.toContain('1234567890');
  });
});
