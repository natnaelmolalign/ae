import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';
import { prorateHsaAnnualLimit } from '../../../src/services/benefits/HsaLimitProration';

function futureDate(daysAhead = 14): string {
  const d = new Date();
  d.setDate(d.getDate() + daysAhead);
  return d.toISOString().slice(0, 10);
}

function planYear(): number {
  return new Date().getFullYear();
}

describe('Benefits lifecycle (Enterprise E4)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('rejects enrollment outside window without approved life event', async () => {
    const year = planYear();
    const emp = await request(ctx.app)
      .post('/api/employees')
      .send({
        firstName: 'Window',
        lastName: 'Closed',
        employmentType: 'full_time_salaried',
        payFrequency: 'biweekly',
        baseCompensation: '5000.00',
        hireDate: `${year - 1}-01-01`,
        filingStatus: 'single',
        stateCode: 'TX',
      });

    await request(ctx.app)
      .post('/api/enrollment-windows')
      .send({
        code: `closed-${year}`,
        name: 'Closed window',
        planYear: year,
        startDate: `${year}-01-01`,
        endDate: `${year}-03-31`,
        status: 'closed',
        allowedBenefitTypes: ['401k_pretax'],
      });

    const res = await request(ctx.app).post('/api/benefit-enrollments').send({
      employeeId: emp.body.id,
      type: '401k_pretax',
      amountPerPeriod: '200.00',
      effectiveDate: futureDate(),
    });

    expect(res.status).toBe(409);
    expect(res.body.code).toBe('ENROLLMENT_WINDOW_CLOSED');
  });

  it('QLE adds HSA mid-year with prorated annual limit', async () => {
    const year = planYear();
    const effectiveDate = futureDate(21);
    const expectedLimit = prorateHsaAnnualLimit(
      year,
      'individual',
      effectiveDate
    );

    const emp = await request(ctx.app)
      .post('/api/employees')
      .send({
        firstName: 'QLE',
        lastName: 'HSA',
        employmentType: 'full_time_salaried',
        payFrequency: 'semimonthly',
        baseCompensation: '6000.00',
        hireDate: `${year - 2}-01-01`,
        filingStatus: 'single',
        stateCode: 'TX',
      });

    await request(ctx.app).post('/api/eligibility-rules').send({
      benefitType: 'hsa',
      requiresEnrollmentWindow: true,
    });

    const eventRes = await request(ctx.app).post('/api/life-events').send({
      employeeId: emp.body.id,
      eventType: 'marriage',
      eventDate: effectiveDate,
      coverageEffectiveDate: effectiveDate,
    });
    expect(eventRes.status).toBe(201);

    const approveRes = await request(ctx.app).post(
      `/api/life-events/${eventRes.body.id}/approve`
    );
    expect(approveRes.status).toBe(200);
    expect(approveRes.body.status).toBe('approved');

    const enrollRes = await request(ctx.app)
      .post('/api/benefit-enrollments')
      .send({
        employeeId: emp.body.id,
        type: 'hsa',
        amountPerPeriod: '500.00',
        hsaCoverage: 'individual',
        effectiveDate,
        lifeEventId: eventRes.body.id,
      });
    expect(enrollRes.status).toBe(201);
    expect(enrollRes.body.annualLimit).toBe(expectedLimit);
    expect(enrollRes.body.lifeEventId).toBe(eventRes.body.id);
  });

  it('approving loss_of_coverage creates COBRA deduction schedule', async () => {
    const year = planYear();
    const startDate = futureDate(7);
    const emp = await request(ctx.app)
      .post('/api/employees')
      .send({
        firstName: 'COBRA',
        lastName: 'Member',
        employmentType: 'full_time_salaried',
        payFrequency: 'monthly',
        baseCompensation: '4000.00',
        hireDate: `${year - 1}-06-01`,
        filingStatus: 'single',
        stateCode: 'CA',
      });

    const eventRes = await request(ctx.app).post('/api/life-events').send({
      employeeId: emp.body.id,
      eventType: 'loss_of_coverage',
      eventDate: startDate,
      coverageEffectiveDate: startDate,
    });

    const approveRes = await request(ctx.app)
      .post(`/api/life-events/${eventRes.body.id}/approve`)
      .send({
        cobraPremiumPerPeriod: '450.00',
        cobraStartDate: startDate,
      });
    expect(approveRes.status).toBe(200);
    expect(approveRes.body.cobraScheduleId).toBeTruthy();

    const schedules = await request(ctx.app).get(
      `/api/deduction-schedules?employeeId=${emp.body.id}`
    );
    expect(schedules.body.schedules.length).toBeGreaterThanOrEqual(1);
    expect(schedules.body.schedules[0].scheduleType).toBe('cobra_premium');
  });
});
