import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext } from '../../helpers/db';

describe('correlation ID middleware', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  it('returns generated x-correlation-id when header omitted', async () => {
    const res = await request(ctx.app).get('/health');
    expect(res.status).toBe(200);
    expect(res.headers['x-correlation-id']).toBeDefined();
    expect(String(res.headers['x-correlation-id']).length).toBeGreaterThan(0);
  });

  it('echoes client-provided x-correlation-id', async () => {
    const id = 'test-correlation-12345';
    const res = await request(ctx.app)
      .get('/health')
      .set('x-correlation-id', id);
    expect(res.headers['x-correlation-id']).toBe(id);
  });
});

describe('PayrollDomainError via API', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  it('returns structured error with code and correlationId', async () => {
    const res = await request(ctx.app).get(
      '/api/employees/00000000-0000-4000-8000-000000000099'
    );
    expect(res.status).toBe(404);
    expect(res.body.code).toBe('NOT_FOUND');
    expect(res.body.correlationId).toBeDefined();
  });
});

describe('GET /ready', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  it('reports database connected', async () => {
    const res = await request(ctx.app).get('/ready');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ready');
  });
});
