import request from 'supertest';
import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';

describe('Phase 10 production security', () => {
  let ctx: TestContext;
  const prevStrict = process.env.STRICT_AUTH;
  const prevKeys = process.env.API_KEYS;

  beforeAll(async () => {
    process.env.STRICT_AUTH = '1';
    process.env.API_KEYS =
      'admin-key:payroll_admin,clerk-key:payroll_clerk,reader-key:read_only';
    ctx = await initTestContext();
  });

  afterAll(() => {
    process.env.STRICT_AUTH = prevStrict;
    process.env.API_KEYS = prevKeys;
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('rejects payroll run without credentials', async () => {
    const res = await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId: '00000000-0000-4000-8000-000000000001',
        payPeriodId: '2024-semimonthly-1',
        year: 2024,
        frequency: 'semimonthly',
        earnings: [{ type: 'regular', amount: '1000.00' }],
      });
    expect(res.status).toBe(401);
    expect(res.headers['content-type']).toMatch(/problem\+json/);
  });

  it('rejects payroll run for read_only role', async () => {
    const employeeRes = await request(ctx.app)
      .post('/api/employees')
      .set('Authorization', 'Bearer admin-key')
      .set('X-Company-Id', 'default')
      .send({
        firstName: 'Read',
        lastName: 'Only',
        employmentType: 'full_time_salaried',
        payFrequency: 'semimonthly',
        baseCompensation: '5000.00',
        hireDate: '2024-01-01',
        filingStatus: 'single',
        stateCode: 'TX',
      });
    expect(employeeRes.status).toBe(201);

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .set('Authorization', 'Bearer admin-key')
      .set('X-Company-Id', 'default')
      .send({ year: 2024, frequency: 'semimonthly' });

    const runRes = await request(ctx.app)
      .post('/api/payroll/run')
      .set('Authorization', 'Bearer reader-key')
      .set('X-Company-Id', 'default')
      .send({
        employeeId: employeeRes.body.id,
        payPeriodId: '2024-semimonthly-1',
        year: 2024,
        frequency: 'semimonthly',
        earnings: [{ type: 'regular', amount: '5000.00' }],
      });
    expect(runRes.status).toBe(403);
  });

  it('returns 404 for cross-tenant employee lookup', async () => {
    const created = await request(ctx.app)
      .post('/api/employees')
      .set('Authorization', 'Bearer admin-key')
      .set('X-Company-Id', 'tenant-a')
      .send({
        firstName: 'Tenant',
        lastName: 'A',
        employmentType: 'full_time_salaried',
        payFrequency: 'semimonthly',
        baseCompensation: '5000.00',
        hireDate: '2024-01-01',
        filingStatus: 'single',
        stateCode: 'TX',
      });
    expect(created.status).toBe(201);

    const cross = await request(ctx.app)
      .get(`/api/employees/${created.body.id}`)
      .set('Authorization', 'Bearer admin-key')
      .set('X-Company-Id', 'tenant-b');
    expect(cross.status).toBe(404);
  });
});
