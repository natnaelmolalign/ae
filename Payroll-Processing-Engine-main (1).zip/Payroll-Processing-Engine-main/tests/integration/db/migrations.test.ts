import knex from 'knex';
import path from 'path';

describe('database migrations', () => {
  it('migrates up, rolls back, and migrates up again', async () => {
    const migrationsDir = path.join(__dirname, '../../../src/migrations');
    const db = knex({
      client: 'better-sqlite3',
      connection: { filename: ':memory:' },
      useNullAsDefault: true,
      migrations: { directory: migrationsDir, extension: 'ts' },
    });

    await db.migrate.latest();
    await expect(db.schema.hasTable('payroll_runs')).resolves.toBe(true);
    await expect(db.schema.hasTable('audit_events')).resolves.toBe(true);
    await expect(db.schema.hasTable('time_entries')).resolves.toBe(true);

    await db.migrate.rollback(undefined, true);
    await expect(db.schema.hasTable('payroll_runs')).resolves.toBe(false);

    await db.migrate.latest();
    await expect(db.schema.hasTable('employees')).resolves.toBe(true);

    await db.destroy();
  });
});
