import {
  correlationIdFromTrace,
  parseTraceParent,
  traceParentFromCorrelationId,
} from '../../../src/observability/tracing';

describe('tracing', () => {
  it('builds stable traceparent from correlation id', () => {
    const tp = traceParentFromCorrelationId(
      '550e8400-e29b-41d4-a716-446655440000'
    );
    expect(tp).toMatch(/^00-[0-9a-f]{32}-[0-9a-f]{16}-01$/);
    expect(
      traceParentFromCorrelationId('550e8400-e29b-41d4-a716-446655440000')
    ).toBe(tp);
  });

  it('parses inbound traceparent', () => {
    const parsed = parseTraceParent(
      '00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01'
    );
    expect(parsed?.traceId).toBe('4bf92f3577b34da6a3ce929d0e0e4736');
    expect(parsed?.spanId).toBe('00f067aa0ba902b7');
  });

  it('derives correlation id from trace id', () => {
    const cid = correlationIdFromTrace('4bf92f3577b34da6a3ce929d0e0e4736');
    expect(cid).toMatch(
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/
    );
  });
});
