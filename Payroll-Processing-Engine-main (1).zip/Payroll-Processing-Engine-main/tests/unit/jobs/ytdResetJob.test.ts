import type { TestContext } from '../../helpers/db';
import { initTestContext, resetTestData } from '../../helpers/db';
import { runYtdReset } from '../../../src/jobs/ytdResetJob';
import { PayrollDomainError } from '../../../src/errors/PayrollDomainError';
import request from 'supertest';

describe('ytdResetJob v2 (payment-date aware)', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await initTestContext();
  });

  beforeEach(async () => {
    await resetTestData(ctx.deps);
  });

  it('allows reset when no payroll runs exist for the tax year', async () => {
    const result = await runYtdReset(2099);
    expect(result.deletedRows).toBeGreaterThanOrEqual(0);
    expect(result.payrollRunsInYear).toBe(0);
  });

  it('blocks reset when payroll runs exist for payment year', async () => {
    const employeeRes = await request(ctx.app).post('/api/employees').send({
      firstName: 'YTD',
      lastName: 'Test',
      employmentType: 'full_time_salaried',
      payFrequency: 'semimonthly',
      baseCompensation: '5000.00',
      hireDate: '2024-01-01',
      filingStatus: 'single',
      stateCode: 'TX',
    });
    const employeeId = employeeRes.body.id;

    await request(ctx.app)
      .post('/api/payperiods/generate')
      .send({ year: 2024, frequency: 'semimonthly' });

    await request(ctx.app)
      .post('/api/payroll/run')
      .send({
        employeeId,
        payPeriodId: '2024-semimonthly-1',
        year: 2024,
        frequency: 'semimonthly',
        earnings: [{ type: 'regular', amount: '5000.00' }],
      });

    await expect(runYtdReset(2024)).rejects.toBeInstanceOf(PayrollDomainError);

    const forced = await runYtdReset(2024, { force: true });
    expect(forced.payrollRunsInYear).toBeGreaterThan(0);
    expect(forced.deletedRows).toBeGreaterThanOrEqual(0);
  });
});
