import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import { TaxTableLoader } from '../../../../src/services/tax/TaxTableLoader';
import { defaultTaxTableLoader } from '../../../../src/services/tax/TaxTableLoader';

describe('TaxTableLoader', () => {
  it('discovers years with tables.json under src/data', () => {
    const years = defaultTaxTableLoader.discoverYears();
    expect(years).toContain(2024);
    expect(years).toContain(2025);
  });

  it('loads and validates 2024 pack', () => {
    const tables = defaultTaxTableLoader.loadYear(2024);
    expect(tables.taxYear).toBe(2024);
    expect(tables.federal.brackets.single.length).toBeGreaterThan(0);
  });

  it('returns readable schema errors for invalid pack', () => {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'tax-tables-'));
    const yearDir = path.join(tmp, '2099');
    fs.mkdirSync(yearDir);
    fs.writeFileSync(
      path.join(yearDir, 'tables.json'),
      JSON.stringify({
        taxYear: 2099,
        federal: { brackets: {} },
        fica: {},
        states: {},
        local: {},
      })
    );
    const loader = new TaxTableLoader(tmp);
    const result = loader.validateYear(2099);
    expect(result.valid).toBe(false);
    expect(result.issues.length).toBeGreaterThan(0);
    expect(result.issues[0].message).toBeTruthy();
  });

  it('reload clears cache and loadYear uses cache in production mode', () => {
    const loader = new TaxTableLoader();
    const first = loader.loadYear(2024);
    loader.reload();
    const second = loader.loadYear(2024);
    expect(second).toEqual(first);
  });

  it('validateYear returns not found for missing pack', () => {
    const loader = new TaxTableLoader('/nonexistent-tax-data-root');
    const result = loader.validateYear(2099);
    expect(result.valid).toBe(false);
    expect(result.issues[0].message).toContain('not found');
  });

  it('validateRaw flags taxYear mismatch', () => {
    const loader = new TaxTableLoader();
    const result = loader.validateRaw(2024, { taxYear: 2025 });
    expect(result.valid).toBe(false);
  });

  it('validateRaw accepts a valid in-memory pack', () => {
    const loader = new TaxTableLoader();
    const tables = loader.loadYear(2024);
    const result = loader.validateRaw(2024, tables);
    expect(result.valid).toBe(true);
    expect(result.issues).toEqual([]);
  });

  it('validateRaw reports zod issues for malformed packs', () => {
    const loader = new TaxTableLoader();
    const result = loader.validateRaw(2024, { taxYear: 2024, federal: {} });
    expect(result.valid).toBe(false);
    expect(result.issues.length).toBeGreaterThan(0);
  });

  it('validateRaw handles null payloads and missing taxYear fields', () => {
    const loader = new TaxTableLoader();
    expect(loader.validateRaw(2024, null).taxYear).toBe(2024);
    expect(loader.validateRaw(2024, { federal: {} }).valid).toBe(false);
  });

  it('uses fallback ajv error text when schema message is missing', () => {
    const loader = new TaxTableLoader();
    const mockValidate = jest.fn().mockReturnValue(false) as jest.Mock & {
      errors: Array<{ instancePath: string; message?: string }>;
    };
    mockValidate.errors = [{ instancePath: '/federal' }];
    (loader as unknown as { validateJson: typeof mockValidate }).validateJson =
      mockValidate;
    const result = loader.validateRaw(2024, { taxYear: 2024 });
    expect(result.issues).toContainEqual({
      path: '/federal',
      message: 'schema validation failed',
    });
  });

  it('discoverYears returns empty for missing data root', () => {
    const loader = new TaxTableLoader('/nonexistent-tax-data-root');
    expect(loader.discoverYears()).toEqual([]);
  });

  it('validateAllDiscovered and validateEnabledYears', () => {
    const loader = new TaxTableLoader();
    const all = loader.validateAllDiscovered();
    expect(all.some((r) => r.taxYear === 2024 && r.valid)).toBe(true);
    const enabled = loader.validateEnabledYears();
    expect(enabled.length).toBeGreaterThan(0);
  });

  it('loadYear throws when validation fails', () => {
    const loader = new TaxTableLoader('/nonexistent-tax-data-root');
    expect(() => loader.loadYear(2099)).toThrow();
  });

  it('loads without cache in development hot-reload mode', () => {
    const prevEnv = process.env.NODE_ENV;
    const prevHot = process.env.TAX_TABLE_HOT_RELOAD;
    process.env.NODE_ENV = 'development';
    process.env.TAX_TABLE_HOT_RELOAD = 'true';
    const loader = new TaxTableLoader();
    loader.reload();
    const tables = loader.loadYear(2024);
    expect(tables.taxYear).toBe(2024);
    process.env.NODE_ENV = prevEnv;
    process.env.TAX_TABLE_HOT_RELOAD = prevHot;
  });

  it('validateEnabledYears reports missing enabled packs', () => {
    const prev = process.env.FEATURE_TAX_YEAR_2025;
    process.env.FEATURE_TAX_YEAR_2025 = 'true';
    jest.resetModules();
    const {
      TaxTableLoader: Loader,
    } = require('../../../../src/services/tax/TaxTableLoader');
    const loader = new Loader('/nonexistent-tax-data-root');
    const results = loader.validateEnabledYears();
    expect(results.some((r: { valid: boolean }) => !r.valid)).toBe(true);
    process.env.FEATURE_TAX_YEAR_2025 = prev;
    jest.resetModules();
  });
});
