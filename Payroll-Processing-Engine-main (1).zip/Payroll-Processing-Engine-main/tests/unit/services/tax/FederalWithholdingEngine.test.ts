import { FEDERAL_2024 } from '../../../../src/data/2024/federal';
import { w4ParamsFromEmployee } from '../../../../src/models/W4Params';
import type { Employee } from '../../../../src/models/types';
import { FederalWithholdingEngine } from '../../../../src/services/tax/federal/FederalWithholdingEngine';
import { testEmployee } from '../../../helpers/testEmployees';

function employee(overrides: Partial<Employee> = {}): Employee {
  return { ...testEmployee, ...overrides };
}

describe('FederalWithholdingEngine', () => {
  const w4 = w4ParamsFromEmployee(testEmployee);

  it('uses flat 22% for supplemental-only pay', () => {
    const tax = FederalWithholdingEngine.calculate(
      FEDERAL_2024,
      w4,
      'biweekly',
      '5000.00',
      '0.00',
      '5000.00',
      true,
      false
    );
    expect(tax).toBe('1100.00');
  });

  it('reduces withholding when W-4 Step 3 credit is large', () => {
    const emp = employee({ w4DependentsCredit: '12000.00' });
    const w4WithCredit = w4ParamsFromEmployee(emp);
    const without = FederalWithholdingEngine.calculate(
      FEDERAL_2024,
      w4,
      'biweekly',
      '4000.00',
      '4000.00',
      '0.00',
      false,
      false
    );
    const withCredit = FederalWithholdingEngine.calculate(
      FEDERAL_2024,
      w4WithCredit,
      'biweekly',
      '4000.00',
      '4000.00',
      '0.00',
      false,
      false
    );
    expect(parseFloat(withCredit)).toBeLessThan(parseFloat(without));
  });

  it('uses aggregate (percentage on combined) for mixed regular + bonus', () => {
    const mixed = FederalWithholdingEngine.calculate(
      FEDERAL_2024,
      w4,
      'biweekly',
      '6000.00',
      '4000.00',
      '2000.00',
      false,
      true
    );
    const flatOnBonusOnly = FederalWithholdingEngine.calculate(
      FEDERAL_2024,
      w4,
      'biweekly',
      '2000.00',
      '0.00',
      '2000.00',
      true,
      false
    );
    expect(parseFloat(mixed)).not.toBe(parseFloat(flatOnBonusOnly));
  });
});
