import { testEmployee } from '../../../helpers/testEmployees';
import type { TaxYearTables } from '../../../../src/data/tax/types';

describe('LocalTaxService', () => {
  const tables = {
    local: {
      PA: [{ municipalityCode: 'PHL', rate: '0.03' }],
    },
  } as unknown as TaxYearTables;

  const loadSvc = (enabled: boolean) => {
    jest.resetModules();
    if (enabled) {
      process.env.FEATURE_LOCAL_TAX = 'true';
    } else {
      delete process.env.FEATURE_LOCAL_TAX;
    }
    const {
      LocalTaxService,
    } = require('../../../../src/services/tax/LocalTaxService');
    return new LocalTaxService() as InstanceType<typeof LocalTaxService>;
  };

  afterEach(() => {
    delete process.env.FEATURE_LOCAL_TAX;
    jest.resetModules();
  });

  it('returns zero when feature off or no municipality', () => {
    const svc = loadSvc(false);
    expect(svc.calculate(tables, testEmployee, '1000.00')).toBe('0.00');
    const enabled = loadSvc(true);
    expect(enabled.calculate(tables, testEmployee, '1000.00')).toBe('0.00');
  });

  it('applies municipal rate when configured', () => {
    const svc = loadSvc(true);
    const emp = {
      ...testEmployee,
      stateCode: 'PA',
      localMunicipalityCode: 'PHL',
    };
    expect(svc.calculate(tables, emp, '1000.00')).toBe('30.00');
    expect(
      svc.calculate(
        tables,
        { ...emp, localMunicipalityCode: 'OTHER' },
        '1000.00'
      )
    ).toBe('0.00');
    expect(
      svc.calculate({ local: {} } as unknown as TaxYearTables, emp, '1000.00')
    ).toBe('0.00');
  });
});
