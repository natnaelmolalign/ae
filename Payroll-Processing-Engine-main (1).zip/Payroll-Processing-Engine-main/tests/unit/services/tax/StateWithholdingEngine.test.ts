import { TAX_YEAR_2024 } from '../../../../src/data/2024';
import { StateWithholdingEngine } from '../../../../src/services/tax/state/StateWithholdingEngine';
import { testEmployee } from '../../../helpers/testEmployees';

describe('StateWithholdingEngine', () => {
  it('returns zero for no-income-tax states', () => {
    const emp = { ...testEmployee, stateCode: 'TX' };
    expect(
      StateWithholdingEngine.calculate(TAX_YEAR_2024, emp, '5000.00')
    ).toBe('0.00');
  });

  it('annualizes flat CA rate for biweekly wages', () => {
    const tax = StateWithholdingEngine.calculate(
      TAX_YEAR_2024,
      testEmployee,
      '5000.00'
    );
    expect(parseFloat(tax)).toBeCloseTo(250, 1);
  });

  it('uses bracket table for NY', () => {
    const emp = { ...testEmployee, stateCode: 'NY' };
    const tax = StateWithholdingEngine.calculate(TAX_YEAR_2024, emp, '8000.00');
    expect(parseFloat(tax)).toBeGreaterThan(0);
  });

  it('returns zero for unknown state or unsupported config', () => {
    expect(
      StateWithholdingEngine.calculateForState(
        TAX_YEAR_2024,
        'ZZ',
        'biweekly',
        '1000.00'
      )
    ).toBe('0.00');
    const tables = {
      ...TAX_YEAR_2024,
      states: {
        ...TAX_YEAR_2024.states,
        ZZ: { type: 'unsupported' } as (typeof TAX_YEAR_2024.states)[string],
      },
    } as typeof TAX_YEAR_2024;
    expect(
      StateWithholdingEngine.calculateForState(
        tables,
        'ZZ',
        'biweekly',
        '1000.00'
      )
    ).toBe('0.00');
  });
});
