import { FICA_2024 } from '../../../../src/data/2024/fica';
import { FicaTaxService } from '../../../../src/services/tax/FicaTaxService';
import { emptyYtd } from '../../../../src/utils/ytdUtils';
import { testEmployee } from '../../../helpers/testEmployees';

describe('FicaTaxService', () => {
  const service = new FicaTaxService();

  it('applies Medicare additional only on wages above YTD threshold in period', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    ytd.medicareTaxableWages = '198500.00';

    const result = service.calculate(FICA_2024, '2000.00', '2000.00', ytd);
    expect(result.medicareAdditional).toBe('4.50');
    expect(result.medicare).toBe('29.00');
  });

  it('applies full additional rate when already over threshold', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    ytd.medicareTaxableWages = '210000.00';

    const result = service.calculate(FICA_2024, '1000.00', '1000.00', ytd);
    expect(result.medicareAdditional).toBe('9.00');
  });
});
