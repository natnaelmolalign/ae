import { MultiStateAllocationService } from '../../../../src/services/tax/MultiStateAllocationService';
import { PayrollDomainError } from '../../../../src/errors/PayrollDomainError';
import { TAX_YEAR_2024 } from '../../../../src/data/2024';
import { testEmployee } from '../../../helpers/testEmployees';

describe('MultiStateAllocationService', () => {
  const service = new MultiStateAllocationService();

  it('rejects invalid allocations', () => {
    expect(() => service.validateAllocations([])).toThrow(PayrollDomainError);
    expect(() =>
      service.validateAllocations([
        { stateCode: 'NY', percent: '60' },
        { stateCode: 'ny', percent: '40' },
      ])
    ).toThrow(PayrollDomainError);
    expect(() =>
      service.validateAllocations([{ stateCode: 'NY', percent: '-1' }])
    ).toThrow(PayrollDomainError);
    expect(() =>
      service.validateAllocations([
        { stateCode: 'NY', percent: '60' },
        { stateCode: 'TX', percent: '39' },
      ])
    ).toThrow(PayrollDomainError);
    expect(() =>
      service.validateAllocations([
        { stateCode: 'NY', percent: '60' },
        { stateCode: 'TX', percent: '50' },
      ])
    ).toThrow(PayrollDomainError);
  });

  it('splits 60/40 NY and TX', () => {
    const { total, slices } = service.calculateTotalStateTax(
      TAX_YEAR_2024,
      { ...testEmployee, stateCode: 'NY', payFrequency: 'biweekly' },
      '10000.00',
      [
        { stateCode: 'NY', percent: '60' },
        { stateCode: 'TX', percent: '40' },
      ]
    );
    expect(slices).toHaveLength(2);
    expect(slices[0]!.allocatedWages).toBe('6000.00');
    expect(slices[1]!.allocatedWages).toBe('4000.00');
    expect(slices[1]!.stateTaxWithheld).toBe('0.00');
    expect(comparePositive(total)).toBe(true);
  });

  it('NY resident with 100% CT wages taxes CT only', () => {
    const nyOnly = service.calculateTotalStateTax(
      TAX_YEAR_2024,
      { ...testEmployee, stateCode: 'NY', payFrequency: 'biweekly' },
      '5000.00',
      [{ stateCode: 'NY', percent: '100' }]
    ).total;

    const ctWork = service.calculateTotalStateTax(
      TAX_YEAR_2024,
      { ...testEmployee, stateCode: 'NY', payFrequency: 'biweekly' },
      '5000.00',
      [{ stateCode: 'CT', percent: '100' }]
    ).total;

    expect(ctWork).not.toBe(nyOnly);
    expect(ctWork).toBe('250.00');
  });
});

function comparePositive(money: string): boolean {
  return Number(money) > 0;
}
