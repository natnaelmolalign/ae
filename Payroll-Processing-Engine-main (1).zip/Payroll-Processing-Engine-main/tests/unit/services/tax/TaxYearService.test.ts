import { TaxYearService } from '../../../../src/services/tax/TaxYearService';
import { defaultTaxTableLoader } from '../../../../src/services/tax/TaxTableLoader';
import { PayrollDomainError } from '../../../../src/errors/PayrollDomainError';

describe('TaxYearService', () => {
  const service = new TaxYearService();

  it('validates registered tax years at startup', () => {
    expect(() => service.validateAll()).not.toThrow();
  });

  it('returns 2024 tables for payment date in 2024', () => {
    const tables = service.getYearTablesForPaymentDate('2024-08-01');
    expect(tables.taxYear).toBe(2024);
    expect(tables.federal.brackets.single.length).toBeGreaterThan(0);
  });

  it('throws TAX_YEAR_UNSUPPORTED for unsupported payment year', () => {
    expect(() => service.getYearTablesForPaymentDate('2023-01-01')).toThrow(
      PayrollDomainError
    );
  });

  it('loads 2025 pack from JSON when requested via loader', () => {
    const tables = defaultTaxTableLoader.loadYear(2025);
    expect(tables.taxYear).toBe(2025);
    expect(tables.fica.socialSecurityWageBase).toBe('176100');
  });

  it('reloadTables clears validation cache', () => {
    const loader = {
      validateEnabledYears: jest.fn().mockReturnValue([]),
      reload: jest.fn(),
      loadYear: jest.fn(),
    };
    const svc = new TaxYearService(loader as never);
    svc.validateAll();
    svc.reloadTables();
    expect(loader.reload).toHaveBeenCalled();
  });

  it('throws when enabled year pack fails validation', () => {
    const loader = {
      validateEnabledYears: jest.fn().mockReturnValue([
        {
          taxYear: 2024,
          valid: false,
          issues: [{ path: '/', message: 'bad' }],
        },
      ]),
      reload: jest.fn(),
      loadYear: jest.fn(),
    };
    const svc = new TaxYearService(loader as never);
    expect(() => svc.validateAll()).toThrow(PayrollDomainError);
  });

  it('throws when tax year is not enabled after validation', () => {
    const loader = {
      validateEnabledYears: jest.fn().mockReturnValue([]),
      reload: jest.fn(),
      loadYear: jest.fn(),
    };
    const svc = new TaxYearService(loader as never);
    svc.validateAll();
    expect(() => svc.getYearTables(2023 as never)).toThrow(PayrollDomainError);
  });
});
