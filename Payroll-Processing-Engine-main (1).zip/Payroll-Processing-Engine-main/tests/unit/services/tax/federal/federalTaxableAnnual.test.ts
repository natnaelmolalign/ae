import {
  annualIncomeTaxFromTaxable,
  annualTaxableAfterW4Adjustments,
  periodWithholdingFromAnnualTax,
} from '../../../../../src/services/tax/federal/federalTaxableAnnual';
import { FEDERAL_BRACKETS_2024 } from '../../../../../src/data/federalTaxBrackets2024';

const federal = {
  standardDeduction: {
    single: '14600.00',
    married_filing_jointly: '29200.00',
    married_filing_separately: '14600.00',
    head_of_household: '21900.00',
  },
  supplementalFlatRate: '0.22',
  brackets: FEDERAL_BRACKETS_2024,
} as never;

describe('federalTaxableAnnual', () => {
  it('clamps negative taxable to zero', () => {
    const taxable = annualTaxableAfterW4Adjustments(
      '10000.00',
      {
        filingStatus: 'single',
        otherDeductionsAnnual: '50000.00',
        otherIncomeAnnual: '0.00',
        dependentsCreditAnnual: '0.00',
        extraWithholdingPerPeriod: '0.00',
        multipleJobs: false,
      },
      federal
    );
    expect(taxable).toBe('0.00');
  });

  it('applies multiple jobs factor and period deannualization', () => {
    const tax = annualIncomeTaxFromTaxable(
      '80000.00',
      'single',
      FEDERAL_BRACKETS_2024,
      '0.00',
      true
    );
    expect(parseFloat(tax)).toBeGreaterThan(0);
    const period = periodWithholdingFromAnnualTax(tax, 12, '25.00');
    expect(parseFloat(period)).toBeGreaterThan(25);
  });
});
