import { SupplementalFlatStrategy } from '../../../../../src/services/tax/federal/SupplementalFlatStrategy';

describe('SupplementalFlatStrategy', () => {
  const strategy = new SupplementalFlatStrategy();
  const baseCtx = {
    federal: { supplementalFlatRate: '0.22' },
    w4: { extraWithholdingPerPeriod: '10.00' },
    periodFederalTaxable: '1000.00',
    supplementalFederalTaxable: '500.00',
  };

  it('uses period taxable for supplemental-only pay', () => {
    const tax = strategy.calculate({
      ...baseCtx,
      supplementalOnly: true,
      mixedSupplemental: false,
    } as never);
    expect(tax).toBe('230.00');
  });

  it('uses supplemental slice when mixed or not supplemental-only', () => {
    const mixed = strategy.calculate({
      ...baseCtx,
      supplementalOnly: false,
      mixedSupplemental: true,
    } as never);
    expect(mixed).toBe('120.00');
  });
});
