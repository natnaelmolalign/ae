import { StateTaxService } from '../../../src/services/StateTaxService';
import { TaxYearService } from '../../../src/services/tax/TaxYearService';
import { testEmployee } from '../../helpers/testEmployees';

describe('StateTaxService', () => {
  const taxYearService = new TaxYearService();

  afterEach(() => {
    delete process.env.FEATURE_MULTI_STATE_TAX;
    jest.resetModules();
  });

  it('uses single-state engine when allocations omitted', () => {
    const svc = new StateTaxService(taxYearService);
    const tax = svc.calculate(testEmployee, '5000.00', '2024-06-15');
    expect(parseFloat(tax)).toBeGreaterThanOrEqual(0);
  });

  it('uses default tax year service when none is injected', () => {
    const {
      StateTaxService: Svc,
    } = require('../../../src/services/StateTaxService');
    const svc = new Svc();
    expect(
      parseFloat(svc.calculate(testEmployee, '5000.00', '2024-06-15'))
    ).toBeGreaterThanOrEqual(0);
  });

  it('uses multi-state allocation when feature enabled and slices provided', () => {
    process.env.FEATURE_MULTI_STATE_TAX = 'true';
    jest.resetModules();
    const {
      StateTaxService: Svc,
    } = require('../../../src/services/StateTaxService');
    const {
      TaxYearService: Ty,
    } = require('../../../src/services/tax/TaxYearService');
    const svc = new Svc(new Ty());
    const tax = svc.calculate(testEmployee, '5000.00', '2024-06-15', [
      { stateCode: 'CA', percent: '100' },
    ]);
    expect(parseFloat(tax)).toBeGreaterThanOrEqual(0);
    const slices = svc.calculateWithSlices(
      testEmployee,
      '5000.00',
      '2024-06-15',
      [{ stateCode: 'CA', percent: '100' }]
    );
    expect(slices.total).toBeDefined();
  });
});
