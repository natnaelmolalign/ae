import { EquityCompensationService } from '../../../../src/services/equity/EquityCompensationService';
import { PayrollDomainError } from '../../../../src/errors/PayrollDomainError';
import { testEmployee } from '../../../helpers/testEmployees';

describe('EquityCompensationService', () => {
  const service = new EquityCompensationService();

  afterEach(() => {
    delete process.env.FEATURE_EQUITY;
    jest.resetModules();
  });

  it('rejects ISO exercise earnings', () => {
    expect(() =>
      service.validateAndSummarize([
        { type: 'iso_exercise' as unknown as 'rsu_vest', amount: '1000.00' },
      ])
    ).toThrow(PayrollDomainError);
  });

  it('uses flat supplemental flags by default for RSU-only pay', () => {
    const flags = service.resolveWithholdingFlags(testEmployee, [
      { type: 'rsu_vest', amount: '10000.00' },
    ]);
    expect(flags).toEqual({
      supplementalOnly: true,
      mixedSupplemental: false,
    });
  });

  it('uses W-4 annualized path when elected for supplemental-only equity', () => {
    const flags = service.resolveWithholdingFlags(
      { ...testEmployee, equityWithholdingMethod: 'w4_annualized' },
      [{ type: 'rsu_vest', amount: '10000.00' }]
    );
    expect(flags).toEqual({
      supplementalOnly: false,
      mixedSupplemental: false,
    });
  });

  it('uses aggregate method when regular and RSU are mixed', () => {
    const flags = service.resolveWithholdingFlags(testEmployee, [
      { type: 'regular', amount: '3000.00' },
      { type: 'rsu_vest', amount: '10000.00' },
    ]);
    expect(flags).toEqual({
      supplementalOnly: false,
      mixedSupplemental: true,
    });
  });

  it('returns null when feature off or no equity lines', () => {
    process.env.FEATURE_EQUITY = 'false';
    jest.resetModules();
    const {
      EquityCompensationService: Svc,
    } = require('../../../../src/services/equity/EquityCompensationService');
    const off = new Svc();
    expect(
      off.validateAndSummarize([{ type: 'rsu_vest', amount: '1' }])
    ).toBeNull();
    expect(
      service.validateAndSummarize([{ type: 'regular', amount: '1' }])
    ).toBeNull();
    expect(service.resolveWithholdingFlags(testEmployee, [])).toBeNull();
  });

  it('supplementalTaxableForYtd sums equity and bonus lines', () => {
    const summary = {
      rsuVest: '1000.00',
      nqsoExercise: '0.00',
      totalEquity: '1000.00',
    };
    expect(
      service.supplementalTaxableForYtd(
        [
          { type: 'rsu_vest', amount: '1000.00' },
          { type: 'bonus', amount: '500.00' },
        ],
        summary
      )
    ).toBe('1500.00');
    expect(service.supplementalTaxableForYtd([], null)).toBe('0.00');
  });

  it('flat supplemental when not supplemental-only mix', () => {
    const flags = service.resolveWithholdingFlags(testEmployee, [
      { type: 'rsu_vest', amount: '1000.00' },
      { type: 'bonus', amount: '500.00' },
    ]);
    expect(flags).toEqual({ supplementalOnly: true, mixedSupplemental: false });
  });

  it('returns null withholding flags when equity feature disabled', () => {
    process.env.FEATURE_EQUITY = 'false';
    jest.resetModules();
    const {
      EquityCompensationService: Svc,
    } = require('../../../../src/services/equity/EquityCompensationService');
    const off = new Svc();
    expect(
      off.resolveWithholdingFlags(testEmployee, [
        { type: 'rsu_vest', amount: '1' },
      ])
    ).toBeNull();
  });

  it('returns flat supplemental false when equity is present but not supplemental-only', () => {
    jest
      .spyOn(service['earnings'], 'hasMixedSupplemental')
      .mockReturnValue(false);
    jest
      .spyOn(service['earnings'], 'hasSupplementalOnly')
      .mockReturnValue(false);
    const flags = service.resolveWithholdingFlags(testEmployee, [
      { type: 'rsu_vest', amount: '1000.00' },
    ]);
    expect(flags).toEqual({
      supplementalOnly: false,
      mixedSupplemental: false,
    });
  });
});
