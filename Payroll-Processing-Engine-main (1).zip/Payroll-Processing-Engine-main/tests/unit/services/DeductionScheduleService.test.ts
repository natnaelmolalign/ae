import { DeductionScheduleService } from '../../../src/services/DeductionScheduleService';
import { PayrollDomainError } from '../../../src/errors/PayrollDomainError';
import type { DeductionScheduleRepository } from '../../../src/repositories/interfaces';

describe('DeductionScheduleService', () => {
  const schedule = {
    id: 's1',
    companyId: 'co',
    employeeId: 'e1',
    scheduleType: 'cobra_premium' as const,
    amountPerPeriod: '500.00',
    remainingBalance: null,
    priority: 50,
    startDate: '2024-01-01',
    endDate: null,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  function repo(overrides: Partial<DeductionScheduleRepository> = {}) {
    return {
      create: jest.fn().mockResolvedValue(schedule),
      findById: jest.fn().mockResolvedValue(schedule),
      findByEmployee: jest.fn().mockResolvedValue([schedule]),
      findActiveForEmployee: jest.fn().mockResolvedValue([schedule]),
      update: jest.fn().mockResolvedValue(schedule),
      delete: jest.fn().mockResolvedValue(true),
      ...overrides,
    } as unknown as DeductionScheduleRepository;
  }

  const base = {
    employeeId: 'e1',
    scheduleType: 'cobra_premium' as const,
    amountPerPeriod: '100.00',
    priority: 1,
    startDate: '2024-01-01',
  };

  it('validates create input', async () => {
    const svc = new DeductionScheduleService(repo());
    expect(() =>
      svc.create({ ...base, amountPerPeriod: '0.00' }, 'co')
    ).toThrow(PayrollDomainError);
    expect(() =>
      svc.create(
        {
          ...base,
          scheduleType: 'arrears',
          amountPerPeriod: '50.00',
          remainingBalance: '0.00',
        },
        'co'
      )
    ).toThrow(PayrollDomainError);
    await svc.create(base, 'co');
    await svc.create(
      {
        ...base,
        scheduleType: 'arrears',
        amountPerPeriod: '50.00',
        remainingBalance: undefined,
      },
      'co'
    );
  });

  it('update returns schedule when found', async () => {
    const svc = new DeductionScheduleService(repo());
    const updated = await svc.update('s1', { amountPerPeriod: '120.00' });
    expect(updated.amountPerPeriod).toBe('500.00');
  });

  it('update/delete not found', async () => {
    const svc = new DeductionScheduleService(
      repo({
        update: jest.fn().mockResolvedValue(null),
        delete: jest.fn().mockResolvedValue(false),
      })
    );
    await expect(svc.update('x', {})).rejects.toBeInstanceOf(
      PayrollDomainError
    );
    await expect(svc.delete('x')).rejects.toBeInstanceOf(PayrollDomainError);
    expect(await svc.get('s1')).toEqual(schedule);
    expect(await svc.listByEmployee('e1')).toHaveLength(1);
    expect(await svc.listActive('e1', '2024-06-01')).toHaveLength(1);
  });
});
