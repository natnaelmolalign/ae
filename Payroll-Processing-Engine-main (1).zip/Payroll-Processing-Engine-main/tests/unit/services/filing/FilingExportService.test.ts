jest.mock('../../../../src/services/compliance/ComplianceReportingService');

import { ComplianceReportingService } from '../../../../src/services/compliance/ComplianceReportingService';
import { FilingExportService } from '../../../../src/services/filing/FilingExportService';

const mockW2Preview = jest.fn();
const mockNec1099Preview = jest.fn();
const mockForm941Reconciliation = jest.fn();

(ComplianceReportingService as jest.Mock).mockImplementation(() => ({
  w2Preview: mockW2Preview,
  nec1099Preview: mockNec1099Preview,
  form941Reconciliation: mockForm941Reconciliation,
}));

describe('FilingExportService', () => {
  const db = {} as never;
  const svc = new FilingExportService(db);

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('exports W-2 XML with escaped special characters', async () => {
    mockW2Preview.mockResolvedValue({
      taxYear: 2024,
      employees: [
        {
          employeeId: 'e&1',
          employeeName: 'Jane <Doe> "Smith"',
          boxes: {
            wages: '50000.00',
            federalIncomeTaxWithheld: '8000.00',
          },
        },
      ],
    });

    const result = await svc.exportW2Xml('co&1', 2024);

    expect(mockW2Preview).toHaveBeenCalledWith('co&1', 2024);
    expect(result).toEqual({
      format: 'w2-xml',
      taxYear: 2024,
      contentType: 'application/xml',
      validated: true,
      body: expect.stringContaining('<?xml version="1.0" encoding="UTF-8"?>'),
    });
    expect(result.body).toContain('employeeId="e&amp;1"');
    expect(result.body).toContain(
      '<EmployeeName>Jane &lt;Doe&gt; &quot;Smith&quot;</EmployeeName>'
    );
    expect(result.body).toContain('<Wages>50000.00</Wages>');
    expect(result.body).toContain(
      '<FederalIncomeTaxWithheld>8000.00</FederalIncomeTaxWithheld>'
    );
  });

  it('exports 1099-NEC XML', async () => {
    mockNec1099Preview.mockResolvedValue({
      taxYear: 2024,
      recipients: [
        {
          employeeId: 'c1',
          recipientName: 'Contractor A',
          nonemployeeCompensation: '1200.00',
        },
      ],
    });

    const result = await svc.export1099NecXml('co-1', 2024);

    expect(mockNec1099Preview).toHaveBeenCalledWith('co-1', 2024);
    expect(result).toEqual({
      format: '1099-nec-xml',
      taxYear: 2024,
      contentType: 'application/xml',
      validated: true,
      body: expect.stringContaining('<Form1099NECSubmission'),
    });
    expect(result.body).toContain(
      '<NonemployeeCompensation>1200.00</NonemployeeCompensation>'
    );
  });

  it('exports Form 941 CSV', async () => {
    mockForm941Reconciliation.mockResolvedValue({
      taxYear: 2024,
      quarter: 2,
      totalLiability: '15000.00',
      payrollRegisterGross: '100000.00',
    });

    const result = await svc.export941Csv('co-1', 2024, 2);

    expect(mockForm941Reconciliation).toHaveBeenCalledWith('co-1', 2024, 2);
    expect(result).toEqual({
      format: '941-csv',
      taxYear: 2024,
      contentType: 'text/csv',
      validated: true,
      body: 'taxYear,quarter,totalLiability,payrollRegisterGross\n2024,2,15000.00,100000.00\n',
    });
  });
});
