import { ImputedIncomeService } from '../../../src/services/ImputedIncomeService';

describe('ImputedIncomeService', () => {
  const service = new ImputedIncomeService();

  it('returns zero imputed at or below 50k coverage', () => {
    expect(
      service.calculateGroupLifeImputed({
        type: 'group_life',
        coverageAmount: '50000.00',
        employerPaidPremium: '10.00',
      })
    ).toBe('0.00');
  });

  it('returns positive imputed above 50k', () => {
    const imputed = service.calculateGroupLifeImputed({
      type: 'group_life',
      coverageAmount: '60000.00',
      employerPaidPremium: '10.00',
    });
    expect(parseFloat(imputed)).toBeGreaterThan(0);
  });

  it('toEarningsLines and holiday FICA flag', () => {
    expect(
      service.toEarningsLines([
        {
          type: 'group_life',
          coverageAmount: '60000.00',
          employerPaidPremium: '10.00',
        },
      ])
    ).toEqual([{ type: 'regular', amount: expect.any(String) }]);
    expect(
      service.toEarningsLines([
        {
          type: 'other' as 'group_life',
          coverageAmount: '1',
          employerPaidPremium: '1',
        },
      ])
    ).toEqual([{ type: 'regular', amount: '0.00' }]);
    expect(service.isHolidayFicaExempt('TX')).toBe(false);
  });
});
