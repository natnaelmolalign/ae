import { FederalTaxService } from '../../../src/services/FederalTaxService';
import { testEmployee } from '../../helpers/testEmployees';

describe('FederalTaxService', () => {
  it('calculates federal withholding via tax year tables', () => {
    const svc = new FederalTaxService();
    const tax = svc.calculate(
      testEmployee,
      '5000.00',
      [{ type: 'regular', amount: '5000.00' }],
      false,
      false,
      {
        paymentDate: '2024-06-15',
        regularFederalTaxable: '5000.00',
        supplementalFederalTaxable: '0.00',
      }
    );
    expect(parseFloat(tax)).toBeGreaterThan(0);
  });
});
