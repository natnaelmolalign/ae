import { EarningsService } from '../../../src/services/EarningsService';

describe('EarningsService', () => {
  const service = new EarningsService();

  it('excludes accountable plan reimbursements from taxable wages', () => {
    const c = service.classify([
      { type: 'regular', amount: '3000.00' },
      { type: 'expense_reimbursement', amount: '150.00' },
    ]);
    expect(c.gross).toBe('3150.00');
    expect(c.federalTaxable).toBe('3000.00');
    expect(c.nonTaxableReimbursement).toBe('150.00');
  });

  it('detects supplemental-only and mixed supplemental earnings', () => {
    expect(
      service.hasSupplementalOnly([{ type: 'bonus', amount: '500.00' }])
    ).toBe(true);
    expect(service.hasSupplementalOnly([])).toBe(false);
    expect(
      service.hasMixedSupplemental([
        { type: 'regular', amount: '1000.00' },
        { type: 'bonus', amount: '200.00' },
      ])
    ).toBe(true);
    expect(service.totalGross([{ type: 'regular', amount: '10.00' }])).toBe(
      '10.00'
    );
  });

  it('classifies tip earnings as regular wages', () => {
    const c = service.classify([{ type: 'cash_tips', amount: '250.00' }]);
    expect(c.regularAmount).toBe('250.00');
    expect(c.supplementalAmount).toBe('0.00');
  });

  it('classifies overtime and leave as regular wages', () => {
    const c = service.classify([
      { type: 'overtime', amount: '300.00' },
      { type: 'pto', amount: '200.00' },
    ]);
    expect(c.regularAmount).toBe('500.00');
  });

  it('classifies sick and holiday as regular wages', () => {
    const c = service.classify([
      { type: 'sick', amount: '100.00' },
      { type: 'holiday', amount: '150.00' },
    ]);
    expect(c.regularAmount).toBe('250.00');
  });
});

describe('assertPositiveGross', () => {
  it('throws on zero gross', () => {
    const {
      assertPositiveGross,
    } = require('../../../src/services/EarningsService');
    expect(() => assertPositiveGross('0.00')).toThrow();
  });
});
