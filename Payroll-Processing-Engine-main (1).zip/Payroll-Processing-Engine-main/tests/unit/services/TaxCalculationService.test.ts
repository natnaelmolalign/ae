import { TaxCalculationService } from '../../../src/services/TaxCalculationService';
import { emptyYtd } from '../../../src/utils/ytdUtils';
import { SOCIAL_SECURITY_WAGE_BASE_2024 } from '../../../src/data/socialSecurityWageBase';
import { testEmployee } from '../../helpers/testEmployees';

describe('TaxCalculationService', () => {
  const service = new TaxCalculationService();

  it('stops Social Security when YTD SS taxable reaches wage base', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    ytd.ssTaxableWages = SOCIAL_SECURITY_WAGE_BASE_2024;

    const fica = service.calculateFica('5000.00', '5000.00', ytd, '2024-06-15');
    expect(fica.socialSecurity).toBe('0.00');
    expect(fica.medicare).toBe('72.50');
  });

  it('withholds SS only on remaining wage base', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    ytd.ssTaxableWages = '168000.00';

    const fica = service.calculateFica('1000.00', '1000.00', ytd, '2024-06-15');
    expect(fica.socialSecurity).toBe('37.20');
  });
});
