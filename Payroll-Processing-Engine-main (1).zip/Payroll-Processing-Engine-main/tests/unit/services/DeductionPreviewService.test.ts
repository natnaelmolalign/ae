import { DeductionPreviewService } from '../../../src/services/DeductionPreviewService';
import { BenefitEnrollmentService } from '../../../src/services/BenefitEnrollmentService';
import { testEmployee } from '../../helpers/testEmployees';
import { emptyYtd } from '../../../src/utils/ytdUtils';
import type { DeductionScheduleRepository } from '../../../src/repositories/interfaces';

describe('DeductionPreviewService', () => {
  const ytdRepo = {
    get: jest.fn().mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
  };

  const enrollmentRepo = {
    findActiveForEmployee: jest.fn().mockResolvedValue([
      {
        id: 'b1',
        employeeId: testEmployee.id,
        type: '401k_pretax',
        amountPerPeriod: '100.00',
        percentOfGross: null,
        annualLimit: null,
        effectiveDate: '2024-01-01',
        endDate: null,
        hsaCoverage: null,
        catchUpEligible: false,
        priority: 100,
        createdAt: '2024-01-01T00:00:00.000Z',
        updatedAt: '2024-01-01T00:00:00.000Z',
      },
    ]),
    create: jest.fn(),
    findById: jest.fn(),
    findByEmployee: jest.fn(),
    update: jest.fn(),
    delete: jest.fn(),
  };

  const scheduleRepo = {
    findActiveForEmployee: jest.fn().mockResolvedValue([
      {
        id: 'sched-1',
        companyId: 'default',
        employeeId: testEmployee.id,
        scheduleType: 'cobra_premium',
        amountPerPeriod: '50.00',
        remainingBalance: null,
        priority: 1,
        startDate: '2024-01-01',
        endDate: null,
        createdAt: '2024-01-01',
        updatedAt: '2024-01-01',
      },
    ]),
    create: jest.fn(),
    findById: jest.fn(),
    findByEmployee: jest.fn(),
    update: jest.fn(),
    delete: jest.fn(),
    updateRemainingBalance: jest.fn(),
  } as unknown as DeductionScheduleRepository;

  function service(schedule?: DeductionScheduleRepository) {
    return new DeductionPreviewService(
      ytdRepo as never,
      undefined,
      undefined,
      new BenefitEnrollmentService(enrollmentRepo as never),
      schedule
    );
  }

  afterEach(() => {
    delete process.env.FEATURE_COBRA_ARREARS;
    jest.resetModules();
  });

  it('loads active enrollments when useActiveEnrollments is true', async () => {
    const svc = service();
    const result = await svc.preview({
      employee: testEmployee,
      paymentDate: '2024-06-15',
      taxYear: 2024,
      earnings: [{ type: 'regular', amount: '5000.00' }],
      useActiveEnrollments: true,
    });
    expect(enrollmentRepo.findActiveForEmployee).toHaveBeenCalled();
    expect(result.bases.pretax401kAmount).toBe('100.00');
  });

  it('loads ytd from repository when preview omits ytd', async () => {
    const get = jest.fn().mockResolvedValue(emptyYtd(testEmployee.id, 2024));
    const svc = new DeductionPreviewService(
      { get } as never,
      undefined,
      undefined,
      new BenefitEnrollmentService(enrollmentRepo as never)
    );
    await svc.preview({
      employee: testEmployee,
      paymentDate: '2024-06-15',
      taxYear: 2024,
      earnings: [{ type: 'regular', amount: '5000.00' }],
      deductions: [{ type: '401k_pretax', amountPerPeriod: '100.00' }],
    });
    expect(get).toHaveBeenCalledWith(testEmployee.id, 2024);
  });

  it('uses provided ytd without hitting repository', async () => {
    const get = jest.fn();
    const svc = new DeductionPreviewService(
      { get } as never,
      undefined,
      undefined,
      new BenefitEnrollmentService(enrollmentRepo as never)
    );
    await svc.preview({
      employee: testEmployee,
      paymentDate: '2024-06-15',
      taxYear: 2024,
      earnings: [{ type: 'regular', amount: '5000.00' }],
      deductions: [{ type: '401k_pretax', amountPerPeriod: '100.00' }],
      ytd: emptyYtd(testEmployee.id, 2024),
    });
    expect(get).not.toHaveBeenCalled();
  });

  it('falls back to empty ytd when repository returns null', async () => {
    const get = jest.fn().mockResolvedValue(null);
    const svc = new DeductionPreviewService(
      { get } as never,
      undefined,
      undefined,
      new BenefitEnrollmentService(enrollmentRepo as never)
    );
    const result = await svc.preview({
      employee: testEmployee,
      paymentDate: '2024-06-15',
      taxYear: 2024,
      earnings: [{ type: 'regular', amount: '5000.00' }],
      deductions: [{ type: '401k_pretax', amountPerPeriod: '100.00' }],
    });
    expect(result.bases.pretax401kAmount).toBe('100.00');
  });

  it('includes scheduled deductions when schedules enabled', async () => {
    process.env.FEATURE_COBRA_ARREARS = 'true';
    jest.resetModules();
    const {
      DeductionPreviewService: Svc,
    } = require('../../../src/services/DeductionPreviewService');
    const {
      BenefitEnrollmentService: Bes,
    } = require('../../../src/services/BenefitEnrollmentService');
    const svc = new Svc(
      ytdRepo as never,
      undefined,
      undefined,
      new Bes(enrollmentRepo as never),
      scheduleRepo
    );
    const result = await svc.preview({
      employee: testEmployee,
      paymentDate: '2024-06-15',
      taxYear: 2024,
      earnings: [{ type: 'regular', amount: '5000.00' }],
      useActiveDeductionSchedules: true,
      ytd: emptyYtd(testEmployee.id, 2024),
    });
    expect(result.scheduledDeductions?.lines.length).toBeGreaterThan(0);
  });

  it('skips schedule load when feature off or repo missing', async () => {
    const svc = service();
    const withoutRepo = await svc.preview({
      employee: testEmployee,
      paymentDate: '2024-06-15',
      taxYear: 2024,
      earnings: [{ type: 'regular', amount: '5000.00' }],
      useActiveDeductionSchedules: true,
    });
    expect(withoutRepo.scheduledDeductions).toBeUndefined();

    process.env.FEATURE_COBRA_ARREARS = 'false';
    jest.resetModules();
    const {
      DeductionPreviewService: Svc,
    } = require('../../../src/services/DeductionPreviewService');
    const {
      BenefitEnrollmentService: Bes,
    } = require('../../../src/services/BenefitEnrollmentService');
    const off = new Svc(
      ytdRepo as never,
      undefined,
      undefined,
      new Bes(enrollmentRepo as never),
      scheduleRepo
    );
    const offResult = await off.preview({
      employee: testEmployee,
      paymentDate: '2024-06-15',
      taxYear: 2024,
      earnings: [{ type: 'regular', amount: '5000.00' }],
      useActiveDeductionSchedules: true,
    });
    expect(offResult.scheduledDeductions?.lines).toEqual([]);
    expect(offResult.scheduledDeductions?.total).toBe('0.00');
  });
});
