import type { DisbursementInstruction } from '../../../../src/models/Disbursement';
import { PayrollErrorCode } from '../../../../src/errors/PayrollDomainError';
import { DisbursementAllocationService } from '../../../../src/services/disbursements/DisbursementAllocationService';

function instruction(
  overrides: Partial<DisbursementInstruction> & {
    id: string;
    splitType: DisbursementInstruction['splitType'];
  }
): DisbursementInstruction {
  return {
    companyId: 'default',
    employeeId: 'emp-1',
    percent: null,
    fixedAmount: null,
    priority: 0,
    routingNumber: '021000021',
    accountNumberToken: 'tok_acct_1',
    accountLastFour: '1234',
    accountType: 'checking',
    isActive: true,
    createdAt: '',
    updatedAt: '',
    ...overrides,
  };
}

describe('DisbursementAllocationService', () => {
  const service = new DisbursementAllocationService();

  it('splits net pay across percent, fixed, and remainder accounts', () => {
    const result = service.allocate('1000.00', [
      instruction({
        id: 'a1',
        splitType: 'percent',
        percent: '0.60',
        priority: 1,
      }),
      instruction({
        id: 'a2',
        splitType: 'fixed',
        fixedAmount: '200.00',
        priority: 2,
      }),
      instruction({
        id: 'a3',
        splitType: 'remainder',
        priority: 3,
      }),
    ]);

    expect(result.totalAllocated).toBe('1000.00');
    const byId = Object.fromEntries(
      result.allocations.map((a) => [a.instructionId, a.amount])
    );
    expect(byId.a1).toBe('600.00');
    expect(byId.a2).toBe('200.00');
    expect(byId.a3).toBe('200.00');
  });

  it('throws when no active instructions exist', () => {
    expect(() =>
      service.allocate('1000.00', [
        instruction({ id: 'a1', splitType: 'remainder', isActive: false }),
      ])
    ).toThrowError(
      expect.objectContaining({
        code: PayrollErrorCode.NO_DISBURSEMENT_INSTRUCTIONS,
      })
    );
  });

  it('throws when multiple remainder instructions are present', () => {
    expect(() =>
      service.allocate('1000.00', [
        instruction({ id: 'a1', splitType: 'remainder', priority: 1 }),
        instruction({ id: 'a2', splitType: 'remainder', priority: 2 }),
      ])
    ).toThrowError(
      expect.objectContaining({ code: PayrollErrorCode.INVALID_INPUT })
    );
  });

  it('throws when fixed or percent instructions are missing amounts', () => {
    expect(() =>
      service.allocate('1000.00', [
        instruction({ id: 'a1', splitType: 'fixed', priority: 1 }),
      ])
    ).toThrowError(
      expect.objectContaining({ code: PayrollErrorCode.INVALID_INPUT })
    );

    expect(() =>
      service.allocate('1000.00', [
        instruction({ id: 'a1', splitType: 'percent', priority: 1 }),
      ])
    ).toThrowError(
      expect.objectContaining({ code: PayrollErrorCode.INVALID_INPUT })
    );
  });

  it('throws when splits do not sum to net pay', () => {
    expect(() =>
      service.allocate('1000.00', [
        instruction({
          id: 'a1',
          splitType: 'percent',
          percent: '0.50',
          priority: 1,
        }),
      ])
    ).toThrowError(
      expect.objectContaining({
        code: PayrollErrorCode.DISBURSEMENT_SPLIT_MISMATCH,
      })
    );
  });

  it('ignores unknown split types during allocation', () => {
    const unknown = instruction({
      id: 'unknown',
      splitType: 'percent',
      priority: 0,
    });
    (unknown as { splitType: string }).splitType = 'other';

    const result = service.allocate('1000.00', [
      instruction({
        id: 'half',
        splitType: 'percent',
        percent: '0.50',
        priority: 1,
      }),
      unknown,
      instruction({ id: 'rest', splitType: 'remainder', priority: 2 }),
    ]);
    expect(result.totalAllocated).toBe('1000.00');
    expect(result.allocations.map((a) => a.instructionId)).not.toContain(
      'unknown'
    );
  });

  it('ignores inactive instructions and skips zero allocations', () => {
    const result = service.allocate('1000.00', [
      instruction({
        id: 'inactive',
        splitType: 'fixed',
        fixedAmount: '500.00',
        isActive: false,
        priority: 0,
      }),
      instruction({
        id: 'zero',
        splitType: 'fixed',
        fixedAmount: '0.00',
        priority: 1,
      }),
      instruction({ id: 'rest', splitType: 'remainder', priority: 2 }),
    ]);
    expect(result.totalAllocated).toBe('1000.00');
    expect(result.allocations).toEqual([
      { instructionId: 'rest', amount: '1000.00' },
    ]);
  });
});
