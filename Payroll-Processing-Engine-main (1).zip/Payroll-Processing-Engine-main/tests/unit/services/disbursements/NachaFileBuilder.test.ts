import { NachaFileBuilder } from '../../../../src/services/disbursements/NachaFileBuilder';
import type { NachaBuildInput } from '../../../../src/services/disbursements/NachaFileBuilder';

describe('NachaFileBuilder', () => {
  const builder = new NachaFileBuilder();

  const baseInput = (): NachaBuildInput => ({
    profile: 'PPD',
    companyName: 'Acme Corp',
    companyId: 'co-1',
    companyRouting: '021000021',
    companyAccount: '987654321',
    effectiveDate: '2024-06-15',
    employeeNames: { 'emp-1': 'Jane Doe' },
    items: [
      {
        id: 'item-1',
        paymentBatchId: 'batch-1',
        payrollRunId: 'run-1',
        payStubId: 'stub-1',
        employeeId: 'emp-1',
        disbursementInstructionId: 'inst-1',
        amount: '1000.00',
        status: 'pending',
        accountNumberToken: 'tok_acct_1',
        routingNumber: '021000021',
        accountLastFour: '1234',
        createdAt: '',
        updatedAt: '',
      },
    ],
  });

  it('builds a balanced NACHA file for standard ACH credits', () => {
    const result = builder.build(baseInput());
    expect(result.entryCount).toBe(2);
    expect(result.controlTotal).toBe('1000.00');
    expect(result.fileContent.length).toBeGreaterThan(0);
  });

  it('uses savings credit code for 3xx routing numbers', () => {
    const input = baseInput();
    input.items[0]!.routingNumber = '311000011';
    const result = builder.build(input);
    expect(result.fileContent).toContain('32');
  });

  it('falls back to EMPLOYEE label when name is missing', () => {
    const input = baseInput();
    input.employeeNames = {};
    const result = builder.build(input);
    expect(result.fileContent).toContain('EMPLOYEE');
  });

  it('recomputes entry hash from batch items', () => {
    const input = baseInput();
    const built = builder.build(input);
    expect(builder.verifyHash(input.items, input.companyRouting)).toBe(
      built.entryHashTotal
    );
  });
});
