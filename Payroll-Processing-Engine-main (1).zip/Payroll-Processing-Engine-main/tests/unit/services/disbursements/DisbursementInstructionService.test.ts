import { DisbursementInstructionService } from '../../../../src/services/disbursements/DisbursementInstructionService';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../../../src/errors/PayrollDomainError';
import type { DisbursementInstruction } from '../../../../src/models/Disbursement';
import type { DisbursementInstructionRepository } from '../../../../src/repositories/interfaces';

describe('DisbursementInstructionService', () => {
  const instruction: DisbursementInstruction = {
    id: 'di-1',
    companyId: 'co-1',
    employeeId: 'emp-1',
    splitType: 'percent',
    percent: '0.50',
    fixedAmount: null,
    priority: 1,
    routingNumber: '021000021',
    accountNumberToken: 'tok_acct_1',
    accountLastFour: '1234',
    accountType: 'checking',
    isActive: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  function repo(overrides: Partial<DisbursementInstructionRepository> = {}) {
    return {
      create: jest.fn().mockResolvedValue(instruction),
      findById: jest.fn().mockResolvedValue(instruction),
      listByEmployee: jest.fn().mockResolvedValue([instruction]),
      update: jest.fn().mockResolvedValue(instruction),
      delete: jest.fn().mockResolvedValue(true),
      ...overrides,
    } as unknown as DisbursementInstructionRepository;
  }

  it('delegates create, get, and list to repository', async () => {
    const r = repo();
    const svc = new DisbursementInstructionService(r);
    await svc.create({
      companyId: 'co-1',
      employeeId: 'emp-1',
      splitType: 'remainder',
      routingNumber: '021000021',
      accountNumber: '1234567890',
    });
    expect(r.create).toHaveBeenCalled();
    expect(await svc.get('di-1', 'co-1')).toEqual(instruction);
    expect(await svc.listByEmployee('emp-1', 'co-1')).toHaveLength(1);
  });

  it('rejects percent split without percent on create', () => {
    const svc = new DisbursementInstructionService(repo());
    expect(() =>
      svc.create({
        companyId: 'co-1',
        employeeId: 'emp-1',
        splitType: 'percent',
        routingNumber: '021000021',
        accountNumber: '1234567890',
      })
    ).toThrow(
      expect.objectContaining({
        code: PayrollErrorCode.INVALID_INPUT,
        message: 'percent split requires percent',
      })
    );
  });

  it('rejects fixed split without fixedAmount on create', () => {
    const svc = new DisbursementInstructionService(repo());
    expect(() =>
      svc.create({
        companyId: 'co-1',
        employeeId: 'emp-1',
        splitType: 'fixed',
        routingNumber: '021000021',
        accountNumber: '1234567890',
      })
    ).toThrow(
      expect.objectContaining({
        code: PayrollErrorCode.INVALID_INPUT,
        message: 'fixed split requires fixedAmount',
      })
    );
  });

  it('updates using existing split fields when patch omits them', async () => {
    const r = repo();
    const svc = new DisbursementInstructionService(r);
    await svc.update('di-1', 'co-1', { priority: 2 });
    expect(r.update).toHaveBeenCalledWith('di-1', 'co-1', { priority: 2 });
  });

  it('validates split fields from patch on update', async () => {
    const svc = new DisbursementInstructionService(
      repo({
        findById: jest.fn().mockResolvedValue({
          ...instruction,
          splitType: 'remainder',
          percent: null,
          fixedAmount: null,
        }),
      })
    );
    await expect(
      svc.update('di-1', 'co-1', { splitType: 'percent' })
    ).rejects.toMatchObject({
      code: PayrollErrorCode.INVALID_INPUT,
      message: 'percent split requires percent',
    });
  });

  it('throws when update target is missing', async () => {
    const svc = new DisbursementInstructionService(
      repo({
        findById: jest.fn().mockResolvedValue(null),
      })
    );
    await expect(svc.update('missing', 'co-1', {})).rejects.toBeInstanceOf(
      PayrollDomainError
    );
  });

  it('throws when update returns null', async () => {
    const svc = new DisbursementInstructionService(
      repo({
        update: jest.fn().mockResolvedValue(null),
      })
    );
    await expect(
      svc.update('di-1', 'co-1', { priority: 2 })
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('throws when remove misses', async () => {
    const svc = new DisbursementInstructionService(
      repo({
        delete: jest.fn().mockResolvedValue(false),
      })
    );
    await expect(svc.remove('di-1', 'co-1')).rejects.toBeInstanceOf(
      PayrollDomainError
    );
  });

  it('removes when delete succeeds', async () => {
    const r = repo();
    const svc = new DisbursementInstructionService(r);
    await svc.remove('di-1', 'co-1');
    expect(r.delete).toHaveBeenCalledWith('di-1', 'co-1');
  });
});
