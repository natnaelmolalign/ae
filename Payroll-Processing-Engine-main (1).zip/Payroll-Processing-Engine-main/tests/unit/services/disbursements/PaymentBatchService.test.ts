import { PaymentBatchService } from '../../../../src/services/disbursements/PaymentBatchService';
import { DisbursementAllocationService } from '../../../../src/services/disbursements/DisbursementAllocationService';
import { NachaFileBuilder } from '../../../../src/services/disbursements/NachaFileBuilder';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../../../src/errors/PayrollDomainError';
import type {
  AchFile,
  DisbursementInstruction,
  PaymentBatch,
  PaymentBatchItem,
} from '../../../../src/models/Disbursement';
import type {
  DisbursementBatchRepository,
  DisbursementInstructionRepository,
} from '../../../../src/repositories/interfaces';
import type { WebhookOutboxService } from '../../../../src/services/webhooks/WebhookOutboxService';

describe('PaymentBatchService', () => {
  const companyId = 'co-1';
  const batchId = 'batch-1';

  const payrollRun = {
    payrollRunId: 'run-1',
    payStubId: 'stub-1',
    employeeId: 'emp-1',
    netPay: '1000.00',
    firstName: 'Jane',
    lastName: 'Doe',
  };

  const instruction: DisbursementInstruction = {
    id: 'inst-1',
    companyId,
    employeeId: payrollRun.employeeId,
    splitType: 'remainder',
    percent: null,
    fixedAmount: null,
    priority: 1,
    routingNumber: '021000021',
    accountNumberToken: 'tok_acct_1',
    accountLastFour: '1234',
    accountType: 'checking',
    isActive: true,
    createdAt: '',
    updatedAt: '',
  };

  const batch: PaymentBatch = {
    id: batchId,
    companyId,
    payPeriodId: '2024-monthly-1',
    status: 'draft',
    nachaProfile: 'PPD',
    totalNetPay: '1000.00',
    totalAchCredit: '1000.00',
    payrollRunCount: 1,
    idempotencyKey: null,
    submittedAt: null,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  const batchItem: PaymentBatchItem = {
    id: 'item-1',
    paymentBatchId: batchId,
    payrollRunId: payrollRun.payrollRunId,
    payStubId: payrollRun.payStubId,
    employeeId: payrollRun.employeeId,
    disbursementInstructionId: instruction.id,
    amount: '1000.00',
    status: 'pending',
    accountNumberToken: instruction.accountNumberToken,
    routingNumber: instruction.routingNumber,
    accountLastFour: instruction.accountLastFour,
    createdAt: '',
    updatedAt: '',
  };

  const achFile: AchFile = {
    id: 'ach-1',
    paymentBatchId: batchId,
    fileFormat: 'nacha',
    nachaProfile: 'PPD',
    fileContent: 'NACHA',
    entryHashTotal: '1234567890',
    controlTotal: '1000.00',
    entryCount: 1,
    createdAt: '2024-01-01T00:00:00.000Z',
  };

  function batchRepo(
    overrides: Partial<DisbursementBatchRepository> = {}
  ): DisbursementBatchRepository {
    return {
      createBatch: jest.fn().mockResolvedValue(batch),
      findBatchById: jest.fn().mockResolvedValue(batch),
      findBatchByIdempotencyKey: jest.fn().mockResolvedValue(null),
      updateBatchStatus: jest
        .fn()
        .mockResolvedValue({ ...batch, status: 'submitted' }),
      insertItems: jest.fn().mockResolvedValue(undefined),
      listItemsByBatch: jest.fn().mockResolvedValue([batchItem]),
      updateItemStatuses: jest.fn().mockResolvedValue(undefined),
      saveAchFile: jest.fn().mockResolvedValue(achFile),
      findAchFileByBatch: jest.fn().mockResolvedValue(achFile),
      listPayrollRunsForPeriod: jest.fn().mockResolvedValue([payrollRun]),
      listPayrollRunsByIds: jest.fn().mockResolvedValue([payrollRun]),
      ...overrides,
    } as unknown as DisbursementBatchRepository;
  }

  function instructionRepo(
    overrides: Partial<DisbursementInstructionRepository> = {}
  ): DisbursementInstructionRepository {
    return {
      create: jest.fn(),
      findById: jest.fn(),
      findActiveByEmployee: jest.fn().mockResolvedValue([instruction]),
      update: jest.fn(),
      delete: jest.fn(),
      ...overrides,
    } as unknown as DisbursementInstructionRepository;
  }

  function webhookOutbox(
    overrides: Partial<WebhookOutboxService> = {}
  ): WebhookOutboxService {
    return {
      enqueuePaymentBatchSubmitted: jest.fn().mockResolvedValue(undefined),
      enqueuePayrollRunCompleted: jest.fn(),
      ...overrides,
    } as unknown as WebhookOutboxService;
  }

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('returns existing batch for idempotency key', async () => {
    const existing = { ...batch, id: 'existing' };
    const repo = batchRepo({
      findBatchByIdempotencyKey: jest.fn().mockResolvedValue(existing),
    });
    const svc = new PaymentBatchService(repo, instructionRepo());
    const result = await svc.createBatch({
      companyId,
      idempotencyKey: 'idem-1',
      payrollRunIds: ['run-1'],
    });
    expect(result).toEqual(existing);
    expect(repo.listPayrollRunsByIds).not.toHaveBeenCalled();
  });

  it('creates batch from payroll run ids or pay period', async () => {
    const repo = batchRepo();
    const inst = instructionRepo();
    const svc = new PaymentBatchService(repo, inst);

    await svc.createBatch({
      companyId,
      payrollRunIds: ['run-1'],
    });
    expect(repo.listPayrollRunsByIds).toHaveBeenCalled();
    expect(repo.createBatch).toHaveBeenCalled();
    expect(repo.insertItems).toHaveBeenCalled();
    expect(inst.findActiveByEmployee).toHaveBeenCalled();

    const repoPeriod = batchRepo();
    await new PaymentBatchService(repoPeriod, inst).createBatch({
      companyId,
      payPeriodId: '2024-monthly-1',
    });
    expect(repoPeriod.listPayrollRunsForPeriod).toHaveBeenCalled();
  });

  it('throws when no payroll runs are found', async () => {
    const svc = new PaymentBatchService(
      batchRepo({
        listPayrollRunsByIds: jest.fn().mockResolvedValue([]),
        listPayrollRunsForPeriod: jest.fn().mockResolvedValue([]),
      }),
      instructionRepo()
    );
    await expect(
      svc.createBatch({ companyId, payrollRunIds: ['missing'] })
    ).rejects.toMatchObject({ code: PayrollErrorCode.INVALID_INPUT });
    await expect(svc.createBatch({ companyId })).rejects.toMatchObject({
      code: PayrollErrorCode.INVALID_INPUT,
    });
  });

  it('throws when allocation totals do not match net pay', async () => {
    jest
      .spyOn(DisbursementAllocationService.prototype, 'allocate')
      .mockReturnValue({
        allocations: [{ instructionId: 'inst-1', amount: '900.00' }],
        totalAllocated: '900.00',
      });
    const svc = new PaymentBatchService(batchRepo(), instructionRepo());
    await expect(
      svc.createBatch({ companyId, payrollRunIds: ['run-1'] })
    ).rejects.toMatchObject({
      code: PayrollErrorCode.DISBURSEMENT_SPLIT_MISMATCH,
    });
  });

  it('gets batch or throws not found', async () => {
    const svc = new PaymentBatchService(
      batchRepo({ findBatchById: jest.fn().mockResolvedValue(null) }),
      instructionRepo()
    );
    await expect(svc.getBatch('missing', companyId)).rejects.toBeInstanceOf(
      PayrollDomainError
    );
    expect(
      await new PaymentBatchService(batchRepo(), instructionRepo()).getBatch(
        batchId,
        companyId
      )
    ).toEqual(batch);
  });

  it('submits draft batch and enqueues webhook', async () => {
    const repo = batchRepo();
    const outbox = webhookOutbox();
    const svc = new PaymentBatchService(repo, instructionRepo(), outbox);
    const result = await svc.submitBatch(batchId, companyId, {
      companyRouting: '021000021',
      companyAccount: '987654321',
      companyName: 'Acme Corp',
      effectiveDate: '2024-06-15',
    });
    expect(repo.saveAchFile).toHaveBeenCalled();
    expect(repo.updateBatchStatus).toHaveBeenCalledWith(
      batchId,
      companyId,
      'submitted',
      expect.any(String)
    );
    expect(repo.updateItemStatuses).toHaveBeenCalledWith(batchId, 'submitted');
    expect(outbox.enqueuePaymentBatchSubmitted).toHaveBeenCalled();
    expect(result.achFile).toEqual(achFile);
  });

  it('rejects submit when batch is not draft or hash mismatches', async () => {
    await expect(
      new PaymentBatchService(
        batchRepo({
          findBatchById: jest
            .fn()
            .mockResolvedValue({ ...batch, status: 'submitted' }),
        }),
        instructionRepo()
      ).submitBatch(batchId, companyId, {
        companyRouting: '021000021',
        companyAccount: '987654321',
        companyName: 'Acme Corp',
        effectiveDate: '2024-06-15',
      })
    ).rejects.toMatchObject({
      code: PayrollErrorCode.PAYMENT_BATCH_INVALID_STATE,
    });

    jest
      .spyOn(NachaFileBuilder.prototype, 'verifyHash')
      .mockReturnValue('0000000000');
    await expect(
      new PaymentBatchService(batchRepo(), instructionRepo()).submitBatch(
        batchId,
        companyId,
        {
          companyRouting: '021000021',
          companyAccount: '987654321',
          companyName: 'Acme Corp',
          effectiveDate: '2024-06-15',
        }
      )
    ).rejects.toMatchObject({
      code: PayrollErrorCode.PAY_STUB_RECONCILIATION_FAILED,
    });
  });

  it('marks batch failed when webhook enqueue fails', async () => {
    const repo = batchRepo();
    const outbox = webhookOutbox({
      enqueuePaymentBatchSubmitted: jest
        .fn()
        .mockRejectedValue(new Error('webhook down')),
    });
    const svc = new PaymentBatchService(repo, instructionRepo(), outbox);
    await expect(
      svc.submitBatch(batchId, companyId, {
        companyRouting: '021000021',
        companyAccount: '987654321',
        companyName: 'Acme Corp',
        effectiveDate: '2024-06-15',
      })
    ).rejects.toMatchObject({ code: PayrollErrorCode.SERVICE_UNAVAILABLE });
    expect(repo.updateBatchStatus).toHaveBeenCalledWith(
      batchId,
      companyId,
      'failed'
    );
  });

  it('reconciles balanced submitted batches and reports status', async () => {
    const repo = batchRepo({
      findBatchById: jest
        .fn()
        .mockResolvedValue({ ...batch, status: 'submitted' }),
    });
    const svc = new PaymentBatchService(repo, instructionRepo());
    const report = await svc.reconcile(batchId, companyId);
    expect(report.balanced).toBe(true);
    expect(repo.updateBatchStatus).toHaveBeenCalledWith(
      batchId,
      companyId,
      'reconciled'
    );

    const unbalanced = await new PaymentBatchService(
      batchRepo({
        findBatchById: jest.fn().mockResolvedValue({
          ...batch,
          status: 'draft',
          totalAchCredit: '900.00',
        }),
        findAchFileByBatch: jest.fn().mockResolvedValue(null),
      }),
      instructionRepo()
    ).reconcile(batchId, companyId);
    expect(unbalanced.balanced).toBe(false);
    expect(unbalanced.entryHashTotal).toBe('0000000000');
    expect(unbalanced.entryCount).toBe(1);
  });

  it('gets ACH file or throws when missing', async () => {
    await expect(
      new PaymentBatchService(
        batchRepo({ findAchFileByBatch: jest.fn().mockResolvedValue(null) }),
        instructionRepo()
      ).getAchFile(batchId, companyId)
    ).rejects.toBeInstanceOf(PayrollDomainError);

    const file = await new PaymentBatchService(
      batchRepo(),
      instructionRepo()
    ).getAchFile(batchId, companyId);
    expect(file).toEqual(achFile);
  });
});
