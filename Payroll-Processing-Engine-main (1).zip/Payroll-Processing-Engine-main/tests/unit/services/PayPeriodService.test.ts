import { PayPeriodService } from '../../../src/services/PayPeriodService';
import { PayrollDomainError } from '../../../src/errors/PayrollDomainError';

describe('PayPeriodService', () => {
  const svc = new PayPeriodService();

  it('generates weekly and monthly periods', () => {
    expect(svc.generate(2024, 'weekly').length).toBeGreaterThan(50);
    expect(svc.generate(2024, 'monthly')).toHaveLength(12);
  });

  it('throws on unknown frequency', () => {
    expect(() => svc.generate(2024, 'daily' as never)).toThrow(
      PayrollDomainError
    );
  });

  it('validateNoOverlap throws when periods overlap', () => {
    const periods = svc.generate(2024, 'monthly');
    const overlapping = [
      { ...periods[0]!, endDate: '2024-02-29', startDate: '2024-01-01' },
      { ...periods[1]!, endDate: '2024-02-29', startDate: '2024-02-01' },
    ];
    expect(() => svc.validateNoOverlap(overlapping)).toThrow(
      PayrollDomainError
    );
  });
});
