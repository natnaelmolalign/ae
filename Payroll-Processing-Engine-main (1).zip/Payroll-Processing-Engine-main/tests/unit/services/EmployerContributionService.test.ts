import { EmployerContributionService } from '../../../src/services/EmployerContributionService';
import { emptyYtd } from '../../../src/utils/ytdUtils';
import { testEmployee } from '../../helpers/testEmployees';

describe('EmployerContributionService', () => {
  const svc = new EmployerContributionService();

  it('uses safe harbor match when enabled', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const result = svc.calculate('5000.00', '5000.00', ytd, {
      matchPercent: 0.5,
      safeHarborMatch: true,
      compensation: '5000.00',
      employeeDeferral: '500.00',
    });
    expect(parseFloat(result.match401k)).toBeGreaterThan(0);
  });

  it('zeros SS when wage base exhausted', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    ytd.ssTaxableWages = '200000.00';
    const result = svc.calculate('5000.00', '5000.00', ytd, {
      matchPercent: 0,
      safeHarborMatch: false,
      compensation: '5000.00',
      employeeDeferral: '0.00',
    });
    expect(result.ss).toBe('0.00');
  });

  it('uses percent match when safe harbor is disabled', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const result = svc.calculate('5000.00', '5000.00', ytd, {
      matchPercent: 0.5,
      safeHarborMatch: false,
      compensation: '5000.00',
      employeeDeferral: '1000.00',
    });
    expect(result.match401k).toBe('500.00');
  });

  it('defaults match percent to zero when omitted', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const result = svc.calculate('5000.00', '5000.00', ytd, {
      safeHarborMatch: false,
      compensation: '5000.00',
      employeeDeferral: '1000.00',
      matchPercent: undefined as unknown as number,
    });
    expect(result.match401k).toBe('0.00');
  });
});
