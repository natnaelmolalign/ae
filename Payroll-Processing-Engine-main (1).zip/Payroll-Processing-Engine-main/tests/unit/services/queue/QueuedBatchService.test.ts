import { QueuedBatchService } from '../../../../src/services/queue/QueuedBatchService';
import type { PayPeriod } from '../../../../src/models/types';

const payPeriod: PayPeriod = {
  id: '2024-biweekly-1',
  startDate: '2024-01-01',
  endDate: '2024-01-14',
  paymentDate: '2024-01-16',
  frequency: 'biweekly',
  year: 2024,
  periodIndex: 1,
};

describe('QueuedBatchService', () => {
  it('creates a completed batch when no employees are ready', async () => {
    const batchRepo = {
      create: jest.fn().mockImplementation(async (input) => input),
    };
    const readinessRepo = {
      findReadyEmployeeIds: jest.fn().mockResolvedValue([]),
    };
    const jobQueue = { enqueue: jest.fn() };
    const svc = new QueuedBatchService(
      batchRepo as never,
      readinessRepo as never,
      jobQueue as never
    );

    const result = await svc.enqueueBatch({
      companyId: 'default',
      payPeriod,
      year: 2024,
      frequency: 'biweekly',
    });

    expect(result.enqueued).toBe(0);
    expect(result.batch.status).toBe('completed');
    expect(result.batch.completedAt).toBeTruthy();
    expect(result.batch.durationMs).toBe(0);
    expect(jobQueue.enqueue).not.toHaveBeenCalled();
  });

  it('enqueues jobs for each ready employee', async () => {
    const batchRepo = {
      create: jest.fn().mockImplementation(async (input) => input),
    };
    const readinessRepo = {
      findReadyEmployeeIds: jest.fn().mockResolvedValue(['e1', 'e2']),
    };
    const jobQueue = { enqueue: jest.fn() };
    const svc = new QueuedBatchService(
      batchRepo as never,
      readinessRepo as never,
      jobQueue as never
    );

    const result = await svc.enqueueBatch({
      companyId: 'default',
      payPeriod,
      year: 2024,
      frequency: 'biweekly',
      employeeIds: ['e1', 'e2'],
    });

    expect(result.enqueued).toBe(2);
    expect(result.batch.status).toBe('running');
    expect(result.batch.completedAt).toBeNull();
    expect(result.batch.durationMs).toBeNull();
    expect(jobQueue.enqueue).toHaveBeenCalledTimes(2);
  });
});
