import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../../../src/errors/PayrollDomainError';
import type { PayPeriod } from '../../../../src/models/types';
import type { PayrollBatch } from '../../../../src/models/PayrollBatch';
import type { QueueJob } from '../../../../src/models/QueueJob';
import { JobWorkerService } from '../../../../src/services/queue/JobWorkerService';
import { testEmployee } from '../../../helpers/testEmployees';

jest.mock('../../../../src/metrics/prometheus', () => ({
  incrementQueueDlqTotal: jest.fn(),
}));

jest.mock('../../../../src/metrics/hooks', () => ({
  getPayrollMetrics: jest.fn(() => ({
    recordBatchComplete: jest.fn(),
  })),
}));

import { incrementQueueDlqTotal } from '../../../../src/metrics/prometheus';
import { getPayrollMetrics } from '../../../../src/metrics/hooks';

const payPeriod: PayPeriod = {
  id: '2024-monthly-1',
  startDate: '2024-01-01',
  endDate: '2024-01-31',
  paymentDate: '2024-01-31',
  frequency: 'monthly',
  year: 2024,
  periodIndex: 1,
};

const baseBatch: PayrollBatch = {
  id: 'batch-1',
  companyId: 'default',
  payPeriodId: payPeriod.id,
  year: 2024,
  frequency: 'monthly',
  status: 'running',
  startedAt: '2024-01-01T00:00:00.000Z',
  completedAt: null,
  successCount: 0,
  failureCount: 0,
  totalCount: 1,
  durationMs: null,
  createdAt: '2024-01-01T00:00:00.000Z',
  updatedAt: '2024-01-01T00:00:00.000Z',
};

const batchEmployeeJob: QueueJob = {
  id: 'job-1',
  jobType: 'payroll_batch_employee',
  partitionKey: 'batch-1',
  payload: {
    batchId: baseBatch.id,
    employeeId: testEmployee.id,
    companyId: 'default',
    payPeriodId: payPeriod.id,
  },
  status: 'processing',
  attempts: 1,
  maxAttempts: 3,
  lastError: null,
  lockedBy: 'worker-1',
  lockedAt: '2024-01-01T00:00:00.000Z',
  createdAt: '2024-01-01T00:00:00.000Z',
  updatedAt: '2024-01-01T00:00:00.000Z',
};

function buildService(
  overrides: {
    jobQueue?: Record<string, jest.Mock>;
    batchRepo?: Record<string, jest.Mock>;
    failureRepo?: Record<string, jest.Mock>;
    readinessRepo?: Record<string, jest.Mock>;
    employeeRepo?: Record<string, jest.Mock>;
    payPeriodRepo?: Record<string, jest.Mock>;
    payrollRunService?: Record<string, jest.Mock>;
    webhookOutbox?: Record<string, jest.Mock>;
    webhookWorker?: Record<string, jest.Mock>;
    controlService?: Record<string, jest.Mock>;
  } = {}
) {
  const jobQueue = {
    poll: jest.fn().mockResolvedValue(null),
    complete: jest.fn().mockResolvedValue(undefined),
    fail: jest.fn().mockResolvedValue('retry'),
    ...overrides.jobQueue,
  };
  const batchRepo = {
    findById: jest.fn().mockResolvedValue(baseBatch),
    update: jest
      .fn()
      .mockImplementation((_id, patch) =>
        Promise.resolve({ ...baseBatch, ...patch })
      ),
    ...overrides.batchRepo,
  };
  const failureRepo = {
    insert: jest.fn().mockResolvedValue(undefined),
    ...overrides.failureRepo,
  };
  const readinessRepo = {
    markProcessed: jest.fn().mockResolvedValue(undefined),
    ...overrides.readinessRepo,
  };
  const employeeRepo = {
    findById: jest.fn().mockResolvedValue(testEmployee),
    ...overrides.employeeRepo,
  };
  const payPeriodRepo = {
    findById: jest.fn().mockResolvedValue(payPeriod),
    ...overrides.payPeriodRepo,
  };
  const payrollRunService = {
    run: jest.fn().mockResolvedValue(undefined),
    ...overrides.payrollRunService,
  };
  const webhookOutbox = overrides.webhookOutbox ?? {
    enqueueBatchCompleted: jest.fn().mockResolvedValue(undefined),
  };
  const webhookWorker = overrides.webhookWorker ?? {
    processPending: jest.fn().mockResolvedValue(undefined),
  };
  const controlService = overrides.controlService;

  const svc = new JobWorkerService(
    jobQueue as never,
    batchRepo as never,
    failureRepo as never,
    readinessRepo as never,
    employeeRepo as never,
    payPeriodRepo as never,
    payrollRunService as never,
    webhookOutbox as never,
    webhookWorker as never,
    controlService as never
  );

  return {
    svc,
    jobQueue,
    batchRepo,
    failureRepo,
    readinessRepo,
    employeeRepo,
    payPeriodRepo,
    payrollRunService,
    webhookOutbox,
    webhookWorker,
    controlService,
  };
}

describe('JobWorkerService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('processOne', () => {
    it('returns false when queue is empty', async () => {
      const { svc } = buildService();
      await expect(svc.processOne('worker-1')).resolves.toBe(false);
    });

    it('completes job on successful dispatch', async () => {
      const { svc, jobQueue } = buildService({
        jobQueue: {
          poll: jest.fn().mockResolvedValue({
            ...batchEmployeeJob,
            jobType: 'webhook_delivery',
          }),
        },
      });
      await expect(svc.processOne('worker-1')).resolves.toBe(true);
      expect(jobQueue.complete).toHaveBeenCalledWith(batchEmployeeJob.id);
    });

    it('fails job and increments DLQ metric on terminal failure', async () => {
      const { svc, jobQueue } = buildService({
        jobQueue: {
          poll: jest.fn().mockResolvedValue({
            id: 'job-bad',
            jobType: 'unknown_type',
            payload: {},
          }),
          fail: jest.fn().mockResolvedValue('dlq'),
        },
      });
      await svc.processOne('worker-1');
      expect(jobQueue.fail).toHaveBeenCalled();
      expect(incrementQueueDlqTotal).toHaveBeenCalledWith('unknown_type');
    });

    it('fails job without DLQ increment on retry outcome', async () => {
      const { svc } = buildService({
        jobQueue: {
          poll: jest.fn().mockResolvedValue({
            id: 'job-bad',
            jobType: 'bad',
            payload: {},
          }),
          fail: jest.fn().mockResolvedValue('retry'),
        },
      });
      await svc.processOne('worker-1');
      expect(incrementQueueDlqTotal).not.toHaveBeenCalled();
    });

    it('wraps non-Error throws when failing job', async () => {
      const { svc, jobQueue } = buildService({
        jobQueue: {
          poll: jest.fn().mockResolvedValue({
            id: 'wh-err',
            jobType: 'webhook_delivery',
            payload: {},
          }),
        },
        webhookWorker: {
          processPending: jest.fn().mockRejectedValue('plain failure'),
        },
      });
      await svc.processOne('worker-1');
      expect(jobQueue.fail).toHaveBeenCalledWith('wh-err', 'plain failure');
    });
  });

  describe('runLoop', () => {
    it('counts processed jobs and stops on idle when idleMs is zero', async () => {
      const { svc, jobQueue } = buildService({
        jobQueue: {
          poll: jest
            .fn()
            .mockResolvedValueOnce(batchEmployeeJob)
            .mockResolvedValueOnce(null),
        },
      });
      const processed = await svc.runLoop('worker-1', {
        maxIterations: 5,
        idleMs: 0,
      });
      expect(processed).toBe(1);
      expect(jobQueue.complete).toHaveBeenCalledTimes(1);
    });

    it('uses default empty options when second argument omitted', async () => {
      jest.useFakeTimers();
      const { svc } = buildService({
        jobQueue: {
          poll: jest
            .fn()
            .mockResolvedValueOnce(null)
            .mockRejectedValue(new Error('stop loop')),
        },
      });
      const assertion = expect(svc.runLoop('worker-1')).rejects.toThrow(
        'stop loop'
      );
      await jest.advanceTimersByTimeAsync(100);
      await assertion;
      jest.useRealTimers();
    });

    it('uses default maxIterations when not specified', async () => {
      const { svc } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(null) },
      });
      const processed = await svc.runLoop('worker-1', { idleMs: 0 });
      expect(processed).toBe(0);
    });

    it('uses default idleMs when only maxIterations provided', async () => {
      jest.useFakeTimers();
      const { svc } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(null) },
      });
      const promise = svc.runLoop('worker-1', { maxIterations: 1 });
      await jest.advanceTimersByTimeAsync(100);
      await expect(promise).resolves.toBe(0);
      jest.useRealTimers();
    });
  });

  describe('handleBatchEmployee', () => {
    it('throws when batch is missing', async () => {
      const { svc, jobQueue } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        batchRepo: { findById: jest.fn().mockResolvedValue(null) },
      });
      await svc.processOne('worker-1');
      expect(jobQueue.fail).toHaveBeenCalled();
    });

    it('throws when pay period is missing', async () => {
      const { svc, jobQueue } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        payPeriodRepo: { findById: jest.fn().mockResolvedValue(null) },
      });
      await svc.processOne('worker-1');
      expect(jobQueue.fail).toHaveBeenCalled();
    });

    it('records failure when employee is not in tenant', async () => {
      const { svc, failureRepo, payrollRunService } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        employeeRepo: {
          findById: jest
            .fn()
            .mockResolvedValue({ ...testEmployee, companyId: 'other' }),
        },
      });
      await svc.processOne('worker-1');
      expect(failureRepo.insert).toHaveBeenCalled();
      expect(payrollRunService.run).not.toHaveBeenCalled();
    });

    it('records control service PayrollDomainError and skips run', async () => {
      const controlService = {
        assertRunAllowed: jest
          .fn()
          .mockRejectedValue(
            new PayrollDomainError(
              PayrollErrorCode.PAYROLL_HOLD_ACTIVE,
              'On hold'
            )
          ),
      };
      const { svc, failureRepo, payrollRunService } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        controlService,
      });
      await svc.processOne('worker-1');
      expect(failureRepo.insert).toHaveBeenCalledWith(
        expect.objectContaining({
          errorCode: PayrollErrorCode.PAYROLL_HOLD_ACTIVE,
        })
      );
      expect(payrollRunService.run).not.toHaveBeenCalled();
    });

    it('rethrows non-domain errors from control service', async () => {
      const controlService = {
        assertRunAllowed: jest.fn().mockRejectedValue(new Error('boom')),
      };
      const { svc, jobQueue } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        controlService,
      });
      await svc.processOne('worker-1');
      expect(jobQueue.fail).toHaveBeenCalledWith('job-1', 'boom');
    });

    it('runs payroll and marks readiness on success', async () => {
      const { svc, payrollRunService, readinessRepo, jobQueue } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
      });
      await svc.processOne('worker-1');
      expect(payrollRunService.run).toHaveBeenCalled();
      expect(readinessRepo.markProcessed).toHaveBeenCalledWith(
        testEmployee.id,
        payPeriod.id
      );
      expect(jobQueue.complete).toHaveBeenCalled();
    });

    it('records PayrollDomainError from payroll run', async () => {
      const { svc, failureRepo } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        payrollRunService: {
          run: jest
            .fn()
            .mockRejectedValue(
              new PayrollDomainError(
                PayrollErrorCode.DUPLICATE_PAYROLL_RUN,
                'Duplicate'
              )
            ),
        },
      });
      await svc.processOne('worker-1');
      expect(failureRepo.insert).toHaveBeenCalledWith(
        expect.objectContaining({
          errorCode: PayrollErrorCode.DUPLICATE_PAYROLL_RUN,
          retryable: false,
        })
      );
    });

    it('wraps generic Error payroll run failures with message', async () => {
      const { svc, failureRepo } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        payrollRunService: {
          run: jest.fn().mockRejectedValue(new Error('runtime boom')),
        },
      });
      await svc.processOne('worker-1');
      expect(failureRepo.insert).toHaveBeenCalledWith(
        expect.objectContaining({ errorMessage: 'runtime boom' })
      );
    });

    it('wraps non-Error payroll run failures', async () => {
      const { svc, failureRepo } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        payrollRunService: {
          run: jest.fn().mockRejectedValue('plain failure'),
        },
      });
      await svc.processOne('worker-1');
      expect(failureRepo.insert).toHaveBeenCalledWith(
        expect.objectContaining({
          errorCode: PayrollErrorCode.INVALID_INPUT,
          errorMessage: 'plain failure',
        })
      );
    });

    it('finalizes batch using completedAt when startedAt is null', async () => {
      const { svc, batchRepo } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        batchRepo: {
          findById: jest.fn().mockResolvedValue({
            ...baseBatch,
            startedAt: null,
          }),
          update: jest
            .fn()
            .mockImplementation((_id, patch) =>
              Promise.resolve({ ...baseBatch, startedAt: null, ...patch })
            ),
        },
      });
      await svc.processOne('worker-1');
      expect(batchRepo.update).toHaveBeenCalledWith(
        baseBatch.id,
        expect.objectContaining({ durationMs: expect.any(Number) })
      );
    });

    it('skips finalize when batch status is already failed', async () => {
      const { svc, webhookOutbox } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        batchRepo: {
          findById: jest.fn().mockResolvedValue({
            ...baseBatch,
            status: 'failed',
            failureCount: 0,
            successCount: 0,
            totalCount: 1,
          }),
          update: jest.fn().mockImplementation((_id, patch) =>
            Promise.resolve({
              ...baseBatch,
              status: 'failed',
              failureCount: 1,
              ...patch,
            })
          ),
        },
      });
      await svc.processOne('worker-1');
      expect(webhookOutbox.enqueueBatchCompleted).not.toHaveBeenCalled();
    });

    it('skips batch counter update when repository update returns null', async () => {
      const { svc, webhookOutbox, batchRepo } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        batchRepo: {
          findById: jest.fn().mockResolvedValue(baseBatch),
          update: jest.fn().mockResolvedValue(null),
        },
      });
      await svc.processOne('worker-1');
      expect(webhookOutbox.enqueueBatchCompleted).not.toHaveBeenCalled();
      expect(batchRepo.update).toHaveBeenCalledWith(baseBatch.id, {
        successCount: 1,
      });
    });

    it('finalizes without webhook outbox when not configured', async () => {
      const recordBatchComplete = jest.fn();
      (getPayrollMetrics as jest.Mock).mockReturnValue({ recordBatchComplete });
      const jobQueue = {
        poll: jest.fn().mockResolvedValue(batchEmployeeJob),
        complete: jest.fn(),
        fail: jest.fn(),
      };
      const batchRepo = {
        findById: jest.fn().mockResolvedValue(baseBatch),
        update: jest
          .fn()
          .mockImplementation((_id, patch) =>
            Promise.resolve({ ...baseBatch, ...patch })
          ),
      };
      const svc = new JobWorkerService(
        jobQueue as never,
        batchRepo as never,
        { insert: jest.fn() } as never,
        { markProcessed: jest.fn() } as never,
        { findById: jest.fn().mockResolvedValue(testEmployee) } as never,
        { findById: jest.fn().mockResolvedValue(payPeriod) } as never,
        { run: jest.fn().mockResolvedValue(undefined) } as never
      );
      await svc.processOne('worker-1');
      expect(recordBatchComplete).toHaveBeenCalled();
    });

    it('finalizes batch as completed and enqueues webhook', async () => {
      const recordBatchComplete = jest.fn();
      (getPayrollMetrics as jest.Mock).mockReturnValue({ recordBatchComplete });
      const { svc, webhookOutbox, batchRepo } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        batchRepo: {
          findById: jest.fn().mockResolvedValue(baseBatch),
          update: jest
            .fn()
            .mockImplementation((_id, patch) =>
              Promise.resolve({ ...baseBatch, ...patch })
            ),
        },
      });
      await svc.processOne('worker-1');
      expect(batchRepo.update).toHaveBeenCalledWith(
        baseBatch.id,
        expect.objectContaining({ status: 'completed' })
      );
      expect(recordBatchComplete).toHaveBeenCalled();
      expect(webhookOutbox.enqueueBatchCompleted).toHaveBeenCalled();
    });

    it('finalizes batch as failed when all jobs fail', async () => {
      const { svc, batchRepo } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        employeeRepo: { findById: jest.fn().mockResolvedValue(null) },
        batchRepo: {
          findById: jest.fn().mockResolvedValue(baseBatch),
          update: jest
            .fn()
            .mockImplementation((_id, patch) =>
              Promise.resolve({ ...baseBatch, ...patch })
            ),
        },
      });
      await svc.processOne('worker-1');
      expect(batchRepo.update).toHaveBeenCalledWith(
        baseBatch.id,
        expect.objectContaining({ status: 'failed' })
      );
    });

    it('does not finalize when batch counts are incomplete', async () => {
      const { svc, webhookOutbox, batchRepo } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        batchRepo: {
          findById: jest
            .fn()
            .mockResolvedValue({ ...baseBatch, totalCount: 5 }),
          update: jest
            .fn()
            .mockImplementation((_id, patch) =>
              Promise.resolve({ ...baseBatch, totalCount: 5, ...patch })
            ),
        },
      });
      await svc.processOne('worker-1');
      expect(batchRepo.update).not.toHaveBeenCalledWith(
        baseBatch.id,
        expect.objectContaining({ status: 'completed' })
      );
      expect(webhookOutbox.enqueueBatchCompleted).not.toHaveBeenCalled();
    });

    it('skips finalize when batch already completed', async () => {
      const { svc, webhookOutbox } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        batchRepo: {
          findById: jest.fn().mockResolvedValue({
            ...baseBatch,
            status: 'completed',
            successCount: 0,
            failureCount: 0,
            totalCount: 1,
          }),
          update: jest.fn().mockImplementation((_id, patch) =>
            Promise.resolve({
              ...baseBatch,
              status: 'completed',
              successCount: 1,
              ...patch,
            })
          ),
        },
      });
      await svc.processOne('worker-1');
      expect(webhookOutbox.enqueueBatchCompleted).not.toHaveBeenCalled();
    });

    it('does not enqueue webhook when finalize update returns null', async () => {
      const { svc, webhookOutbox } = buildService({
        jobQueue: { poll: jest.fn().mockResolvedValue(batchEmployeeJob) },
        batchRepo: {
          findById: jest.fn().mockResolvedValue(baseBatch),
          update: jest
            .fn()
            .mockResolvedValueOnce({ ...baseBatch, successCount: 1 })
            .mockResolvedValueOnce(null),
        },
      });
      await svc.processOne('worker-1');
      expect(webhookOutbox.enqueueBatchCompleted).not.toHaveBeenCalled();
    });
  });

  describe('handleWebhook', () => {
    it('processes pending webhooks when worker is configured', async () => {
      const { svc, webhookWorker, jobQueue } = buildService({
        jobQueue: {
          poll: jest.fn().mockResolvedValue({
            id: 'wh-1',
            jobType: 'webhook_delivery',
            payload: {},
          }),
        },
      });
      await svc.processOne('worker-1');
      expect(webhookWorker.processPending).toHaveBeenCalledWith(1);
      expect(jobQueue.complete).toHaveBeenCalledWith('wh-1');
    });

    it('no-ops webhook dispatch when worker is absent', async () => {
      const jobQueue = {
        poll: jest.fn().mockResolvedValue({
          id: 'wh-1',
          jobType: 'webhook_delivery',
          payload: {},
        }),
        complete: jest.fn(),
        fail: jest.fn(),
      };
      const svc = new JobWorkerService(
        jobQueue as never,
        {} as never,
        {} as never,
        {} as never,
        {} as never,
        {} as never,
        {} as never
      );
      await svc.processOne('worker-1');
      expect(jobQueue.complete).toHaveBeenCalled();
    });
  });
});
