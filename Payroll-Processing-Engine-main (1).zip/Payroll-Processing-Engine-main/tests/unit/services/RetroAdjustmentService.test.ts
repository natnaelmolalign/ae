import { parseISO } from 'date-fns';
import type { PayPeriod } from '../../../src/models/types';
import { RetroAdjustmentService } from '../../../src/services/RetroAdjustmentService';

describe('RetroAdjustmentService.findAffectedPeriods', () => {
  const service = new RetroAdjustmentService(
    {} as never,
    {} as never,
    {} as never,
    {} as never
  );

  const periods: PayPeriod[] = [
    {
      id: '2024-monthly-1',
      startDate: '2024-01-01',
      endDate: '2024-01-31',
      paymentDate: '2024-01-31',
      frequency: 'monthly',
      year: 2024,
      periodIndex: 1,
    },
    {
      id: '2024-monthly-2',
      startDate: '2024-02-01',
      endDate: '2024-02-29',
      paymentDate: '2024-02-29',
      frequency: 'monthly',
      year: 2024,
      periodIndex: 2,
    },
    {
      id: '2024-monthly-3',
      startDate: '2024-03-01',
      endDate: '2024-03-31',
      paymentDate: '2024-03-31',
      frequency: 'monthly',
      year: 2024,
      periodIndex: 3,
    },
    {
      id: '2024-monthly-4',
      startDate: '2024-04-01',
      endDate: '2024-04-30',
      paymentDate: '2024-04-30',
      frequency: 'monthly',
      year: 2024,
      periodIndex: 4,
    },
  ];

  const current = periods[3]!;

  it('includes periods from effective date through current', () => {
    const affected = service.findAffectedPeriods(
      periods,
      '2024-01-01',
      current,
      null
    );
    expect(affected.map((p) => p.id)).toEqual([
      '2024-monthly-1',
      '2024-monthly-2',
      '2024-monthly-3',
      '2024-monthly-4',
    ]);
  });

  it('excludes periods after termination payment date', () => {
    const affected = service.findAffectedPeriods(
      periods,
      '2024-01-01',
      current,
      '2024-02-15'
    );
    expect(affected.map((p) => p.id)).toEqual(['2024-monthly-1']);
  });

  it('excludes periods ending before effective date', () => {
    const affected = service.findAffectedPeriods(
      periods,
      '2024-03-01',
      current,
      null
    );
    expect(affected.map((p) => p.id)).toEqual([
      '2024-monthly-3',
      '2024-monthly-4',
    ]);
    expect(affected.every((p) => !parseISO(p.endDate).getTime() || true)).toBe(
      true
    );
  });
});

describe('RetroAdjustmentService workflows', () => {
  const employee = {
    id: 'e1',
    companyId: 'default',
    terminationDate: null,
  } as never;

  const periods: PayPeriod[] = [
    {
      id: '2024-monthly-1',
      startDate: '2024-01-01',
      endDate: '2024-01-31',
      paymentDate: '2024-01-31',
      frequency: 'monthly',
      year: 2024,
      periodIndex: 1,
    },
    {
      id: '2024-monthly-2',
      startDate: '2024-02-01',
      endDate: '2024-02-29',
      paymentDate: '2024-02-29',
      frequency: 'monthly',
      year: 2024,
      periodIndex: 2,
    },
    {
      id: '2024-monthly-3',
      startDate: '2024-03-01',
      endDate: '2024-03-31',
      paymentDate: '2024-03-31',
      frequency: 'monthly',
      year: 2024,
      periodIndex: 3,
    },
  ];

  const current = periods[2]!;

  const runInputFor = (period: PayPeriod) => ({
    employeeId: 'e1',
    payPeriodId: period.id,
    earnings: [{ type: 'regular' as const, amount: '5000.00' }],
    deductions: [],
    garnishments: [],
  });

  it('computePreview handles periods with and without original pay stubs', async () => {
    const payrollRun = {
      previewWithYtd: jest
        .fn()
        .mockResolvedValueOnce({
          result: {
            payStub: { grossPay: '5200.00', netPay: '3800.00' },
          },
          updatedYtd: { grossEarnings: '5200.00' },
        })
        .mockResolvedValueOnce({
          result: {
            payStub: { grossPay: '5000.00', netPay: '3600.00' },
          },
          updatedYtd: { grossEarnings: '10200.00' },
        }),
    };
    const payStubRepo = {
      findOriginalByEmployeeAndPeriod: jest
        .fn()
        .mockResolvedValueOnce({
          id: 'stub-1',
          grossPay: '5000.00',
          netPay: '3500.00',
        })
        .mockResolvedValueOnce(null),
    };
    const svc = new RetroAdjustmentService(
      payrollRun as never,
      payStubRepo as never,
      {} as never,
      {
        get: jest.fn().mockResolvedValue({ grossEarnings: '0.00' }),
      } as never
    );

    const preview = await svc.computePreview(
      employee,
      periods,
      '2024-01-01',
      current,
      (period) => runInputFor(period)
    );

    expect(preview.periodDeltas).toHaveLength(2);
    expect(preview.periodDeltas[0]?.originalPayStubId).toBe('stub-1');
    expect(preview.periodDeltas[1]?.originalPayStubId).toBeNull();
  });

  it('apply skips past periods without an original pay stub', async () => {
    const payrollRun = {
      run: jest.fn(),
      runCatchUpCorrection: jest.fn(),
    };
    const payStubRepo = {
      findOriginalByEmployeeAndPeriod: jest
        .fn()
        .mockResolvedValueOnce(null)
        .mockResolvedValueOnce({
          id: 'stub-2',
          grossPay: '5000.00',
          netPay: '3500.00',
        })
        .mockResolvedValue(null),
    };
    const retroRepo = {
      findById: jest.fn().mockResolvedValue({
        id: 'retro-1',
        status: 'approved',
        effectiveDate: '2024-01-01',
        preview: { totalNetCatchUp: '0.00' },
      }),
      update: jest.fn().mockImplementation(async (_id, patch) => ({
        id: 'retro-1',
        status: patch.status,
      })),
    };
    const svc = new RetroAdjustmentService(
      payrollRun as never,
      payStubRepo as never,
      retroRepo as never,
      {} as never
    );

    await svc.apply('retro-1', employee, periods, current, (period) =>
      runInputFor(period)
    );

    expect(payrollRun.run).toHaveBeenCalledTimes(1);
  });
});
