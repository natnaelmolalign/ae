import { TimeEntryService } from '../../../src/services/TimeEntryService';
import type { PayPeriod, TimeEntry } from '../../../src/models/types';

const payPeriod: PayPeriod = {
  id: '2024-monthly-1',
  startDate: '2024-01-01',
  endDate: '2024-01-31',
  paymentDate: '2024-01-31',
  frequency: 'monthly',
  year: 2024,
  periodIndex: 1,
};

describe('TimeEntryService', () => {
  it('creates entry with rounded minutes', async () => {
    const repo = { insert: jest.fn(), findByEmployee: jest.fn() };
    const svc = new TimeEntryService(repo as never);
    const entry = await svc.create({
      employeeId: 'e1',
      workDate: '2024-01-15',
      clockIn: '2024-01-15T08:00:00Z',
      clockOut: '2024-01-15T17:00:00Z',
    });
    expect(entry.roundedMinutes).toBeGreaterThan(0);
    expect(repo.insert).toHaveBeenCalled();
  });

  it('lists entries by pay period id or work date range', async () => {
    const entries: TimeEntry[] = [
      {
        id: 't1',
        employeeId: 'e1',
        payPeriodId: '2024-monthly-1',
        workDate: '2024-01-10',
        clockIn: '08:00',
        clockOut: '17:00',
        roundedMinutes: 480,
        entryType: 'regular',
        shiftAssignmentId: null,
        createdAt: '2024-01-01',
      },
      {
        id: 't2',
        employeeId: 'e1',
        payPeriodId: null,
        workDate: '2024-01-20',
        clockIn: '08:00',
        clockOut: '12:00',
        roundedMinutes: 240,
        entryType: 'regular',
        shiftAssignmentId: null,
        createdAt: '2024-01-01',
      },
    ];
    const repo = {
      insert: jest.fn(),
      findByEmployee: jest.fn().mockResolvedValue(entries),
    };
    const svc = new TimeEntryService(repo as never);
    const listed = await svc.listForPayPeriod('e1', payPeriod);
    expect(listed).toHaveLength(2);
  });
});
