import { CobraPremiumService } from '../../../../src/services/deductions/CobraPremiumService';
import { PayrollErrorCode } from '../../../../src/errors/PayrollDomainError';
import type { DeductionSchedule } from '../../../../src/models/DeductionSchedule';

describe('CobraPremiumService', () => {
  const svc = new CobraPremiumService();
  const schedule: DeductionSchedule = {
    id: 's1',
    companyId: 'co',
    employeeId: 'e1',
    scheduleType: 'cobra_premium',
    amountPerPeriod: '400.00',
    remainingBalance: null,
    priority: 1,
    startDate: '2024-01-01',
    endDate: '2024-12-31',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  it('rejects COBRA in pre-tax enrollments', () => {
    expect(() =>
      svc.assertNotPreTaxEnrollment([
        { type: 'cobra_premium', amount: '10.00' } as never,
      ])
    ).toThrow(
      expect.objectContaining({ code: PayrollErrorCode.INVALID_INPUT })
    );
  });

  it('isActive respects type, dates, and amount', () => {
    expect(svc.isActive(schedule, '2024-06-01')).toBe(true);
    expect(
      svc.isActive({ ...schedule, scheduleType: 'arrears' }, '2024-06-01')
    ).toBe(false);
    expect(svc.isActive(schedule, '2023-12-31')).toBe(false);
    expect(svc.isActive(schedule, '2025-01-01')).toBe(false);
    expect(
      svc.isActive({ ...schedule, amountPerPeriod: '0.00' }, '2024-06-01')
    ).toBe(false);
    expect(svc.computeDue(schedule)).toBe('400.00');
  });
});
