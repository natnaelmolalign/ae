import { ScheduledDeductionService } from '../../../../src/services/deductions/ScheduledDeductionService';
import type { DeductionSchedule } from '../../../../src/models/DeductionSchedule';
import { testEmployee } from '../../../helpers/testEmployees';

const schedule = (
  type: DeductionSchedule['scheduleType'],
  overrides: Partial<DeductionSchedule> = {}
): DeductionSchedule => ({
  id: 's1',
  companyId: 'co',
  employeeId: testEmployee.id,
  scheduleType: type,
  amountPerPeriod: '50.00',
  remainingBalance: '200.00',
  priority: 1,
  startDate: '2024-01-01',
  endDate: null,
  createdAt: '2024-01-01',
  updatedAt: '2024-01-01',
  ...overrides,
});

describe('ScheduledDeductionService', () => {
  const svc = new ScheduledDeductionService();

  it('returns empty when cobra/arrears feature disabled', () => {
    const prev = process.env.FEATURE_COBRA_ARREARS;
    process.env.FEATURE_COBRA_ARREARS = 'false';
    jest.resetModules();
    const {
      ScheduledDeductionService: S,
    } = require('../../../../src/services/deductions/ScheduledDeductionService');
    const disabled = new S();
    const result = disabled.resolve(testEmployee, '2024-06-15', [
      schedule('arrears'),
    ]);
    expect(result.lines).toHaveLength(0);
    process.env.FEATURE_COBRA_ARREARS = prev;
    jest.resetModules();
  });

  it('resolves arrears and cobra with net cap', () => {
    const result = svc.resolve(
      testEmployee,
      '2024-06-15',
      [schedule('cobra_premium'), schedule('arrears', { priority: 2 })],
      {
        gross: '1000.00',
        taxes: {
          federalIncome: '100.00',
          stateIncome: '50.00',
          localIncome: '0.00',
          socialSecurity: '62.00',
          medicare: '14.50',
          medicareAdditional: '0.00',
        },
        pretax: {
          federalTaxableReduction: '0.00',
          stateTaxableReduction: '0.00',
          ssTaxableReduction: '0.00',
          medicareTaxableReduction: '0.00',
          pretax401kAmount: '0.00',
          roth401kAmount: '0.00',
          hsaAmount: '0.00',
          fsaAmount: '0.00',
          section125Amount: '0.00',
          postTaxTotal: '0.00',
          postTaxLines: [],
          limitAdjustments: [],
        },
      }
    );
    expect(result.lines.length).toBeGreaterThan(0);
    expect(result.balanceUpdates.length).toBeGreaterThan(0);
  });

  it('skips inactive schedules', () => {
    const inactive = schedule('arrears', {
      startDate: '2025-01-01',
      remainingBalance: '0.00',
    });
    const result = svc.resolve(testEmployee, '2024-06-15', [inactive]);
    expect(result.total).toBe('0.00');
  });

  it('skips arrears when employee is ineligible after termination', () => {
    const terminated = {
      ...testEmployee,
      terminationDate: '2024-05-01',
    };
    const result = svc.resolve(terminated, '2024-06-15', [
      schedule('arrears', { remainingBalance: '100.00' }),
    ]);
    expect(result.lines).toHaveLength(0);
  });

  it('skips zero due amounts and caps when net is exhausted', () => {
    const terminated = {
      ...testEmployee,
      terminationDate: '2024-05-01',
    };
    const zeroDue = schedule('arrears', { remainingBalance: '100.00' });
    const empty = svc.resolve(terminated, '2024-06-15', [zeroDue]);
    expect(empty.lines).toHaveLength(0);

    const capped = svc.resolve(
      testEmployee,
      '2024-06-15',
      [schedule('cobra_premium', { amountPerPeriod: '500.00' })],
      {
        gross: '200.00',
        taxes: {
          federalIncome: '50.00',
          stateIncome: '25.00',
          localIncome: '0.00',
          socialSecurity: '12.00',
          medicare: '3.00',
          medicareAdditional: '0.00',
        },
        pretax: {
          federalTaxableReduction: '0.00',
          stateTaxableReduction: '0.00',
          ssTaxableReduction: '0.00',
          medicareTaxableReduction: '0.00',
          pretax401kAmount: '0.00',
          roth401kAmount: '0.00',
          hsaAmount: '0.00',
          fsaAmount: '0.00',
          section125Amount: '0.00',
          postTaxTotal: '150.00',
          postTaxLines: [],
          limitAdjustments: [],
        },
      }
    );
    expect(capped.lines[0]!.amount).toBe('0.00');
  });

  it('caps partial amount when available net is limited', () => {
    const result = svc.resolve(
      testEmployee,
      '2024-06-15',
      [schedule('cobra_premium', { amountPerPeriod: '200.00' })],
      {
        gross: '150.00',
        taxes: {
          federalIncome: '40.00',
          stateIncome: '20.00',
          localIncome: '0.00',
          socialSecurity: '10.00',
          medicare: '5.00',
          medicareAdditional: '0.00',
        },
        pretax: {
          federalTaxableReduction: '0.00',
          stateTaxableReduction: '0.00',
          ssTaxableReduction: '0.00',
          medicareTaxableReduction: '0.00',
          pretax401kAmount: '0.00',
          roth401kAmount: '0.00',
          hsaAmount: '0.00',
          fsaAmount: '0.00',
          section125Amount: '0.00',
          postTaxTotal: '50.00',
          postTaxLines: [],
          limitAdjustments: [],
        },
      }
    );
    expect(result.lines[0]!.amount).toBe('25.00');
  });

  it('skips active schedules with zero due amount', () => {
    const zeroInstallment = schedule('arrears', {
      amountPerPeriod: '0.00',
      remainingBalance: '100.00',
    });
    const result = svc.resolve(testEmployee, '2024-06-15', [zeroInstallment]);
    expect(result.lines).toHaveLength(0);
    expect(result.total).toBe('0.00');
  });

  it('returns zero due for ineligible arrears in dueAmount helper', () => {
    const terminated = {
      ...testEmployee,
      terminationDate: '2024-05-01',
    };
    const amount = (
      svc as unknown as {
        dueAmount: (
          employee: typeof testEmployee,
          schedule: DeductionSchedule,
          paymentDate: string
        ) => string;
      }
    ).dueAmount(
      terminated,
      schedule('arrears', { remainingBalance: '100.00' }),
      '2024-06-15'
    );
    expect(amount).toBe('0.00');
  });

  it('clamps negative available net and zeroes later lines', () => {
    const result = svc.resolve(
      testEmployee,
      '2024-06-15',
      [
        schedule('cobra_premium', { amountPerPeriod: '40.00', priority: 1 }),
        schedule('arrears', { amountPerPeriod: '40.00', priority: 2 }),
      ],
      {
        gross: '100.00',
        taxes: {
          federalIncome: '50.00',
          stateIncome: '20.00',
          localIncome: '0.00',
          socialSecurity: '10.00',
          medicare: '5.00',
          medicareAdditional: '0.00',
        },
        pretax: {
          federalTaxableReduction: '0.00',
          stateTaxableReduction: '0.00',
          ssTaxableReduction: '0.00',
          medicareTaxableReduction: '0.00',
          pretax401kAmount: '0.00',
          roth401kAmount: '0.00',
          hsaAmount: '0.00',
          fsaAmount: '0.00',
          section125Amount: '0.00',
          postTaxTotal: '50.00',
          postTaxLines: [],
          limitAdjustments: [],
        },
      }
    );
    expect(result.lines.every((l) => l.amount === '0.00')).toBe(true);
  });
});
