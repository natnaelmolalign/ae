import { ArrearsScheduler } from '../../../../src/services/deductions/ArrearsScheduler';
import type { DeductionSchedule } from '../../../../src/models/DeductionSchedule';
import { testEmployee } from '../../../helpers/testEmployees';

describe('ArrearsScheduler', () => {
  const scheduler = new ArrearsScheduler();

  const arrearsSchedule = (
    balance: string,
    installment = '100.00',
    extra: Partial<DeductionSchedule> = {}
  ): DeductionSchedule => ({
    id: 'sched-1',
    companyId: 'default',
    employeeId: testEmployee.id,
    scheduleType: 'arrears',
    amountPerPeriod: installment,
    remainingBalance: balance,
    priority: 100,
    startDate: '2024-01-01',
    endDate: null,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
    ...extra,
  });

  it('computes min of installment and balance', () => {
    expect(scheduler.computeDue(arrearsSchedule('250.00'))).toBe('100.00');
    expect(scheduler.computeDue(arrearsSchedule('75.00'))).toBe('75.00');
    expect(scheduler.computeDue(arrearsSchedule('0.00'))).toBe('0.00');
  });

  it('skips arrears after termination payment date', () => {
    const terminated = {
      ...testEmployee,
      terminationDate: '2024-06-15',
    };
    expect(scheduler.isEligible(terminated, '2024-06-15')).toBe(true);
    expect(scheduler.isEligible(terminated, '2024-06-16')).toBe(false);
  });

  it('isActive respects schedule type and dates', () => {
    expect(
      scheduler.isActive(
        { ...arrearsSchedule('100'), scheduleType: 'cobra_premium' },
        '2024-06-15'
      )
    ).toBe(false);
    expect(scheduler.isActive(arrearsSchedule('100', '50'), '2023-12-31')).toBe(
      false
    );
    expect(
      scheduler.isActive(
        arrearsSchedule('100', '50', { endDate: '2024-06-01' }),
        '2024-06-15'
      )
    ).toBe(false);
    expect(scheduler.balanceAfterPayment(arrearsSchedule('100'), '25')).toBe(
      '75.00'
    );
    expect(
      scheduler.isActive(
        { ...arrearsSchedule('100'), remainingBalance: null },
        '2024-06-15'
      )
    ).toBe(false);
    expect(
      scheduler.computeDue({
        ...arrearsSchedule('100'),
        remainingBalance: null,
      })
    ).toBe('0.00');
    expect(
      scheduler.balanceAfterPayment(
        { ...arrearsSchedule('100'), remainingBalance: null },
        '25'
      )
    ).toBe('-25.00');
  });
});
