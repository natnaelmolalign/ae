import { HourlyEarningsBuilder } from '../../../src/services/HourlyEarningsBuilder';
import { testEmployee } from '../../helpers/testEmployees';
import type { TimeEntry } from '../../../src/models/types';

describe('HourlyEarningsBuilder', () => {
  const builder = new HourlyEarningsBuilder();

  it('builds regular and OT lines for 45 hour week', () => {
    const entries: TimeEntry[] = [
      {
        id: '1',
        employeeId: testEmployee.id,
        payPeriodId: 'p1',
        workDate: '2024-06-03',
        clockIn: '2024-06-03T08:00:00Z',
        clockOut: '2024-06-07T23:00:00Z',
        roundedMinutes: 45 * 60,
        entryType: 'regular',
        shiftAssignmentId: null,
        createdAt: '2024-01-01T00:00:00Z',
      },
    ];
    const hourly = testEmployee;
    const lines = builder.buildFromTimeEntries(hourly, entries, '20.00');
    const regular = lines.find((l) => l.type === 'regular');
    const ot = lines.find((l) => l.type === 'overtime');
    expect(regular).toBeDefined();
    expect(ot).toBeDefined();
    expect(regular!.amount).toBe('800.00');
    expect(ot!.amount).toBe('150.00');
  });

  it('adds holiday line with multiplier', () => {
    const entries: TimeEntry[] = [
      {
        id: '2',
        employeeId: testEmployee.id,
        payPeriodId: 'p1',
        workDate: '2024-07-04',
        clockIn: '2024-07-04T08:00:00Z',
        clockOut: '2024-07-04T16:00:00Z',
        roundedMinutes: 8 * 60,
        entryType: 'holiday',
        shiftAssignmentId: null,
        createdAt: '2024-01-01T00:00:00Z',
      },
    ];
    const lines = builder.buildFromTimeEntries(testEmployee, entries, '25.00');
    const holiday = lines.find((l) => l.type === 'holiday');
    expect(holiday?.amount).toBe('300.00');
  });

  it('throws when hourly earnings feature is disabled', () => {
    const prev = process.env.FEATURE_HOURLY_EARNINGS;
    process.env.FEATURE_HOURLY_EARNINGS = 'false';
    jest.resetModules();
    const {
      HourlyEarningsBuilder: Builder,
    } = require('../../../src/services/HourlyEarningsBuilder');
    const disabled = new Builder();
    expect(() =>
      disabled.buildFromTimeEntries(testEmployee, [], '20.00')
    ).toThrow('Hourly earnings feature is disabled');
    process.env.FEATURE_HOURLY_EARNINGS = prev;
    jest.resetModules();
  });
});
