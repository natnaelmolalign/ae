import { PayPolicyService } from '../../../../src/services/policies/PayPolicyService';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../../../src/errors/PayrollDomainError';
import { testEmployee } from '../../../helpers/testEmployees';
import type { PayPolicy } from '../../../../src/models/PayPolicy';
import type { PayPeriod, PayrollRunInput } from '../../../../src/models/types';
import type { PayPolicyRepository } from '../../../../src/repositories/interfaces';

describe('PayPolicyService', () => {
  const policy: PayPolicy = {
    id: 'pp-1',
    companyId: 'default',
    code: 'MIN_GROSS',
    name: 'Minimum gross',
    scope: 'company',
    employeeId: null,
    priority: 1,
    rules: [{ type: 'min_gross', params: { amount: '1000.00' } }],
    effectiveFrom: '2024-01-01',
    effectiveTo: null,
    isActive: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  const payPeriod: PayPeriod = {
    id: 'period-1',
    startDate: '2024-01-01',
    endDate: '2024-01-15',
    paymentDate: '2024-01-15',
    frequency: 'biweekly',
    year: 2024,
    periodIndex: 1,
    companyId: 'default',
  };

  const runInput: PayrollRunInput = {
    employeeId: testEmployee.id,
    payPeriodId: payPeriod.id,
    earnings: [{ type: 'regular', amount: '100.00' }],
    deductions: [],
    garnishments: [],
  };

  function repo(overrides: Partial<PayPolicyRepository> = {}) {
    return {
      create: jest.fn().mockResolvedValue(policy),
      update: jest.fn().mockResolvedValue(policy),
      findById: jest.fn().mockResolvedValue(policy),
      listByCompany: jest.fn().mockResolvedValue([policy]),
      findActiveForRun: jest.fn().mockResolvedValue([policy]),
      ...overrides,
    } as unknown as PayPolicyRepository;
  }

  it('rejects employee-scoped policy without employeeId', async () => {
    const svc = new PayPolicyService(repo());
    await expect(
      svc.create({
        companyId: 'default',
        code: 'EMP',
        name: 'Employee policy',
        scope: 'employee',
        employeeId: null,
        priority: 1,
        rules: [{ type: 'min_gross', params: { amount: '100.00' } }],
        effectiveFrom: '2024-01-01',
        effectiveTo: null,
        isActive: true,
      })
    ).rejects.toMatchObject({
      code: PayrollErrorCode.INVALID_INPUT,
      message: 'Employee-scoped policies require employeeId',
    });
  });

  it('rejects company-scoped policy with employeeId', async () => {
    const svc = new PayPolicyService(repo());
    await expect(
      svc.create({
        companyId: 'default',
        code: 'CO',
        name: 'Company policy',
        scope: 'company',
        employeeId: testEmployee.id,
        priority: 1,
        rules: [{ type: 'min_gross', params: { amount: '100.00' } }],
        effectiveFrom: '2024-01-01',
        effectiveTo: null,
        isActive: true,
      })
    ).rejects.toMatchObject({
      code: PayrollErrorCode.INVALID_INPUT,
      message: 'Company-scoped policies cannot set employeeId',
    });
  });

  it('delegates create, get, list, and update', async () => {
    const r = repo();
    const svc = new PayPolicyService(r);
    await svc.create({
      companyId: 'default',
      code: 'MIN_GROSS',
      name: 'Minimum gross',
      scope: 'company',
      employeeId: null,
      priority: 1,
      rules: [{ type: 'min_gross', params: { amount: '1000.00' } }],
      effectiveFrom: '2024-01-01',
      effectiveTo: null,
      isActive: true,
    });
    expect(r.create).toHaveBeenCalled();
    expect(await svc.get('pp-1', 'default')).toEqual(policy);
    expect(await svc.list('default')).toHaveLength(1);
    expect(await svc.update('pp-1', 'default', { name: 'Updated' })).toEqual(
      policy
    );
  });

  it('throws when update misses', async () => {
    const svc = new PayPolicyService(
      repo({
        update: jest.fn().mockResolvedValue(null),
      })
    );
    await expect(
      svc.update('missing', 'default', { name: 'X' })
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('returns no violations when no active policies exist', async () => {
    const svc = new PayPolicyService(
      repo({
        findActiveForRun: jest.fn().mockResolvedValue([]),
      })
    );
    const violations = await svc.evaluateRun(testEmployee, payPeriod, runInput);
    expect(violations).toEqual([]);
  });

  it('evaluates active policies against run context', async () => {
    const svc = new PayPolicyService(repo());
    const violations = await svc.evaluateRun(testEmployee, payPeriod, runInput);
    expect(violations).toHaveLength(1);
    expect(violations[0].ruleType).toBe('min_gross');
  });

  it('assertRunAllowed passes when policies pass', async () => {
    const svc = new PayPolicyService(
      repo({
        findActiveForRun: jest.fn().mockResolvedValue([]),
      })
    );
    await expect(
      svc.assertRunAllowed(testEmployee, payPeriod, runInput)
    ).resolves.toBeUndefined();
  });

  it('assertRunAllowed throws pay policy violation', async () => {
    const svc = new PayPolicyService(repo());
    await expect(
      svc.assertRunAllowed(testEmployee, payPeriod, runInput)
    ).rejects.toMatchObject({ code: PayrollErrorCode.PAY_POLICY_VIOLATION });
  });

  it('treats missing earnings as empty when resolving gross', async () => {
    const svc = new PayPolicyService(
      repo({
        findActiveForRun: jest.fn().mockResolvedValue([
          {
            ...policy,
            rules: [{ type: 'require_positive_gross', params: {} }],
          },
        ]),
      })
    );
    const inputWithoutEarnings = {
      employeeId: testEmployee.id,
      payPeriodId: payPeriod.id,
      deductions: [],
      garnishments: [],
    } as unknown as PayrollRunInput;
    const violations = await svc.evaluateRun(
      testEmployee,
      payPeriod,
      inputWithoutEarnings
    );
    expect(violations).toHaveLength(1);
    expect(violations[0].ruleType).toBe('require_positive_gross');
  });
});
