import { evaluatePayPolicies } from '../../../../src/services/policies/PayPolicyEvaluator';
import type {
  PayPolicy,
  PayPolicyRunContext,
} from '../../../../src/models/PayPolicy';

function policy(
  overrides: Partial<PayPolicy> & Pick<PayPolicy, 'rules'>
): PayPolicy {
  return {
    id: 'p1',
    companyId: 'default',
    code: 'TEST',
    name: 'Test',
    scope: 'company',
    employeeId: null,
    priority: 0,
    effectiveFrom: '2025-01-01',
    effectiveTo: null,
    isActive: true,
    createdAt: '2025-01-01T00:00:00Z',
    updatedAt: '2025-01-01T00:00:00Z',
    ...overrides,
  };
}

const baseContext: PayPolicyRunContext = {
  companyId: 'default',
  employeeId: 'e1',
  employmentType: 'full_time_salaried',
  baseCompensation: '52000.00',
  paymentDate: '2025-06-15',
  grossEarnings: '2000.00',
};

describe('PayPolicyEvaluator', () => {
  it('returns no violations when rules pass', () => {
    const violations = evaluatePayPolicies(
      [
        policy({
          rules: [
            { type: 'min_gross', params: { amount: '100.00' } },
            { type: 'max_gross', params: { amount: '10000.00' } },
          ],
        }),
      ],
      baseContext
    );
    expect(violations).toHaveLength(0);
  });

  it('flags min_gross violation', () => {
    const violations = evaluatePayPolicies(
      [
        policy({
          rules: [{ type: 'min_gross', params: { amount: '5000.00' } }],
        }),
      ],
      { ...baseContext, grossEarnings: '100.00' }
    );
    expect(violations).toHaveLength(1);
    expect(violations[0].ruleType).toBe('min_gross');
  });

  it('flags max_gross violation', () => {
    const violations = evaluatePayPolicies(
      [
        policy({
          rules: [{ type: 'max_gross', params: { amount: '1000.00' } }],
        }),
      ],
      baseContext
    );
    expect(violations[0].ruleType).toBe('max_gross');
  });

  it('enforces min_hourly_rate only for hourly types', () => {
    const hourlyCtx: PayPolicyRunContext = {
      ...baseContext,
      employmentType: 'full_time_hourly',
      baseCompensation: '10.00',
    };
    const salariedCtx: PayPolicyRunContext = {
      ...baseContext,
      employmentType: 'full_time_salaried',
      baseCompensation: '10.00',
    };
    const rules = [
      policy({
        rules: [{ type: 'min_hourly_rate', params: { rate: '15.00' } }],
      }),
    ];
    expect(evaluatePayPolicies(rules, hourlyCtx)).toHaveLength(1);
    expect(evaluatePayPolicies(rules, salariedCtx)).toHaveLength(0);
  });

  it('flags non-positive gross for require_positive_gross', () => {
    const violations = evaluatePayPolicies(
      [policy({ rules: [{ type: 'require_positive_gross', params: {} }] })],
      { ...baseContext, grossEarnings: '0.00' }
    );
    expect(violations[0].ruleType).toBe('require_positive_gross');
  });

  it('passes require_positive_gross when gross is positive', () => {
    const violations = evaluatePayPolicies(
      [policy({ rules: [{ type: 'require_positive_gross', params: {} }] })],
      baseContext
    );
    expect(violations).toHaveLength(0);
  });

  it('passes min_hourly_rate when rate meets minimum', () => {
    const violations = evaluatePayPolicies(
      [
        policy({
          rules: [{ type: 'min_hourly_rate', params: { rate: '15.00' } }],
        }),
      ],
      {
        ...baseContext,
        employmentType: 'part_time',
        baseCompensation: '20.00',
      }
    );
    expect(violations).toHaveLength(0);
  });

  it('ignores unknown rule types', () => {
    const violations = evaluatePayPolicies(
      [
        policy({
          rules: [
            { type: 'unknown_rule' as 'min_gross', params: { amount: '0' } },
          ],
        }),
      ],
      baseContext
    );
    expect(violations).toHaveLength(0);
  });

  it('evaluates higher priority policy first but collects all violations', () => {
    const violations = evaluatePayPolicies(
      [
        policy({
          priority: 1,
          code: 'LOW',
          rules: [{ type: 'min_gross', params: { amount: '5000.00' } }],
        }),
        policy({
          priority: 10,
          code: 'HIGH',
          rules: [{ type: 'max_gross', params: { amount: '100.00' } }],
        }),
      ],
      baseContext
    );
    expect(violations).toHaveLength(2);
    expect(violations.map((v) => v.policyCode).sort()).toEqual(['HIGH', 'LOW']);
  });
});
