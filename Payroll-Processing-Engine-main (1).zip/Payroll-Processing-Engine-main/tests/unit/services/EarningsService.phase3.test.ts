import { EarningsService } from '../../../src/services/EarningsService';
import { ImputedIncomeService } from '../../../src/services/ImputedIncomeService';
import { testEmployee } from '../../helpers/testEmployees';

describe('EarningsService Phase 3 classification', () => {
  const service = new EarningsService();

  it('still excludes expense reimbursements', () => {
    const c = service.classify(
      [
        { type: 'regular', amount: '1000.00' },
        { type: 'expense_reimbursement', amount: '50.00' },
      ],
      { employee: testEmployee }
    );
    expect(c.gross).toBe('1050.00');
    expect(c.federalTaxable).toBe('1000.00');
  });

  it('treats commission as supplemental', () => {
    const c = service.classify([{ type: 'commission', amount: '500.00' }], {
      employee: testEmployee,
    });
    expect(c.supplementalAmount).toBe('500.00');
  });

  it('includes holiday in FICA by default', () => {
    const imputed = new ImputedIncomeService();
    expect(imputed.isHolidayFicaExempt('TX')).toBe(false);
    const c = service.classify([{ type: 'holiday', amount: '200.00' }], {
      employee: testEmployee,
    });
    expect(c.ssTaxable).toBe('200.00');
  });
});
