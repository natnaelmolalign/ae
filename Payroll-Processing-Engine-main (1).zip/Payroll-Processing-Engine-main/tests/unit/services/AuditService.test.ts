import { AuditService } from '../../../src/services/AuditService';
import type { AuditEventRepository } from '../../../src/repositories/interfaces';

describe('AuditService', () => {
  const event = {
    id: 'a1',
    entityType: 'employee',
    entityId: 'e1',
    action: 'create' as const,
    actor: 'hr',
    beforeSnapshot: null,
    afterSnapshot: { name: 'Jane' },
    createdAt: '2024-01-01T00:00:00.000Z',
  };

  it('records create, update, delete and lists', async () => {
    const repo = {
      append: jest.fn().mockResolvedValue(event),
      findByEntity: jest.fn().mockResolvedValue([event]),
    } as unknown as AuditEventRepository;
    const svc = new AuditService(repo);
    await svc.recordCreate('hr', 'employee', 'e1', { name: 'Jane' });
    await svc.recordUpdate(
      'hr',
      'employee',
      'e1',
      { name: 'Jane' },
      {
        name: 'Janet',
      }
    );
    await svc.recordDelete('hr', 'employee', 'e1', { name: 'Jane' });
    expect(repo.append).toHaveBeenCalledTimes(3);
    expect(await svc.listForEntity('employee', 'e1')).toHaveLength(1);
  });

  it('buildDiff delegates to jsonDiff', () => {
    const svc = new AuditService({} as AuditEventRepository);
    const diff = svc.buildDiff({ a: 1 }, { a: 2, b: 3 });
    expect(diff.a).toEqual({ from: 1, to: 2 });
    expect(diff.b).toEqual({ from: null, to: 3 });
  });
});
