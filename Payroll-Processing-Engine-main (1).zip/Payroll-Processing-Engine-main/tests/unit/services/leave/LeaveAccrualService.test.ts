import type { LeavePolicy } from '../../../../src/models/LeavePolicy';
import type { PayPeriod } from '../../../../src/models/types';
import { LeaveAccrualService } from '../../../../src/services/leave/LeaveAccrualService';
import { testEmployee } from '../../../helpers/testEmployees';

const payPeriod: PayPeriod = {
  id: '2024-monthly-1',
  startDate: '2024-01-01',
  endDate: '2024-01-31',
  paymentDate: '2024-01-31',
  frequency: 'monthly',
  year: 2024,
  periodIndex: 1,
};

const basePolicy: LeavePolicy = {
  id: 'pol-1',
  companyId: 'default',
  code: 'PTO',
  name: 'PTO',
  leaveType: 'pto',
  accrualMethod: 'fixed_per_period',
  accrualConfig: { hoursPerPeriod: '3.08' },
  carryoverMaxHours: '40.00',
  effectiveFrom: '2024-01-01',
  effectiveTo: null,
  isActive: true,
  createdAt: '2024-01-01T00:00:00.000Z',
  updatedAt: '2024-01-01T00:00:00.000Z',
};

function makeBalance(hours: string, year = 2024) {
  return {
    id: 'bal-1',
    companyId: 'default',
    employeeId: testEmployee.id,
    leaveType: 'pto' as const,
    policyId: basePolicy.id,
    calendarYear: year,
    balanceHours: hours,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };
}

function buildService(
  overrides: {
    policyRepo?: Record<string, jest.Mock>;
    balanceRepo?: Record<string, jest.Mock>;
    transactionRepo?: Record<string, jest.Mock>;
    employeeRepo?: Record<string, jest.Mock>;
  } = {}
) {
  const trx = {};
  const db = {
    transaction: jest.fn(async (cb: (t: unknown) => Promise<unknown>) =>
      cb(trx)
    ),
  };
  const policyRepo = {
    listActiveForAccrual: jest.fn().mockResolvedValue([basePolicy]),
    ...overrides.policyRepo,
  };
  const balanceRepo = {
    getOrCreate: jest.fn().mockResolvedValue(makeBalance('0.00')),
    getForUpdate: jest.fn().mockResolvedValue(null),
    save: jest.fn().mockResolvedValue(undefined),
    ...overrides.balanceRepo,
  };
  const transactionRepo = {
    findAccrualForPeriod: jest.fn().mockResolvedValue(null),
    insert: jest.fn().mockResolvedValue(undefined),
    ...overrides.transactionRepo,
  };
  const employeeRepo = {
    listByCompany: jest.fn().mockResolvedValue([testEmployee]),
    ...overrides.employeeRepo,
  };
  const svc = new LeaveAccrualService(
    db as never,
    policyRepo as never,
    balanceRepo as never,
    transactionRepo as never,
    employeeRepo as never
  );
  return {
    svc,
    db,
    trx,
    policyRepo,
    balanceRepo,
    transactionRepo,
    employeeRepo,
  };
}

describe('LeaveAccrualService', () => {
  afterEach(() => {
    delete process.env.FEATURE_LEAVE_ACCRUALS;
    jest.resetModules();
  });

  it('returns zeros when leave accruals feature is disabled', async () => {
    process.env.FEATURE_LEAVE_ACCRUALS = 'false';
    jest.resetModules();
    const {
      LeaveAccrualService: Svc,
    } = require('../../../../src/services/leave/LeaveAccrualService');
    const { svc } = buildService();
    const result = await new Svc(
      {} as never,
      {} as never,
      {} as never,
      {} as never,
      {} as never
    ).runForPayPeriod('default', payPeriod);
    expect(result).toEqual({
      payPeriodId: payPeriod.id,
      employeesProcessed: 0,
      accrualsPosted: 0,
      carryoversApplied: 0,
      skippedDuplicate: 0,
    });
    void svc;
  });

  it('returns zeros when no active policies', async () => {
    const { svc } = buildService({
      policyRepo: { listActiveForAccrual: jest.fn().mockResolvedValue([]) },
    });
    const result = await svc.runForPayPeriod('default', payPeriod);
    expect(result.accrualsPosted).toBe(0);
    expect(result.employeesProcessed).toBe(0);
  });

  it('skips terminated employees before payment date', async () => {
    const terminated = {
      ...testEmployee,
      terminationDate: '2024-01-15',
    };
    const { svc, transactionRepo } = buildService({
      employeeRepo: {
        listByCompany: jest.fn().mockResolvedValue([terminated]),
      },
    });
    const result = await svc.runForPayPeriod('default', payPeriod);
    expect(result.accrualsPosted).toBe(0);
    expect(transactionRepo.findAccrualForPeriod).not.toHaveBeenCalled();
  });

  it('posts accrual and updates balance', async () => {
    const { svc, balanceRepo, transactionRepo } = buildService();
    const result = await svc.runForPayPeriod('default', payPeriod);
    expect(result.accrualsPosted).toBe(1);
    expect(result.employeesProcessed).toBe(1);
    expect(balanceRepo.save).toHaveBeenCalled();
    expect(transactionRepo.insert).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({
        transactionType: 'accrual',
        actor: 'accrual-run',
      })
    );
  });

  it('skips duplicate accruals for same employee policy and period', async () => {
    const { svc, transactionRepo } = buildService({
      transactionRepo: {
        findAccrualForPeriod: jest.fn().mockResolvedValue({ id: 'dup' }),
      },
    });
    const result = await svc.runForPayPeriod('default', payPeriod);
    expect(result.skippedDuplicate).toBe(1);
    expect(result.accrualsPosted).toBe(0);
    expect(transactionRepo.insert).not.toHaveBeenCalled();
  });

  it('applies carryover with cap and forfeit transactions', async () => {
    const { svc, balanceRepo, transactionRepo } = buildService({
      balanceRepo: {
        getOrCreate: jest.fn().mockResolvedValue(makeBalance('0.00')),
        getForUpdate: jest
          .fn()
          .mockResolvedValueOnce(makeBalance('50.00', 2023))
          .mockResolvedValueOnce(null),
        save: jest.fn().mockResolvedValue(undefined),
      },
    });
    const result = await svc.runForPayPeriod('default', payPeriod);
    expect(result.carryoversApplied).toBe(1);
    expect(transactionRepo.insert).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ transactionType: 'carryover', hours: '40.00' })
    );
    expect(transactionRepo.insert).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ transactionType: 'forfeit', hours: '-10.00' })
    );
    expect(balanceRepo.save).toHaveBeenCalled();
  });

  it('skips carryover when prior balance is zero', async () => {
    const { svc, transactionRepo } = buildService({
      balanceRepo: {
        getOrCreate: jest.fn().mockResolvedValue(makeBalance('0.00')),
        getForUpdate: jest.fn().mockResolvedValue(makeBalance('0.00', 2023)),
        save: jest.fn(),
      },
    });
    const result = await svc.runForPayPeriod('default', payPeriod);
    expect(result.carryoversApplied).toBe(0);
    expect(transactionRepo.insert).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ transactionType: 'accrual' })
    );
  });

  it('skips carryover when current year balance already exists', async () => {
    const { svc, transactionRepo } = buildService({
      balanceRepo: {
        getOrCreate: jest.fn().mockResolvedValue(makeBalance('5.00')),
        getForUpdate: jest
          .fn()
          .mockResolvedValueOnce(makeBalance('20.00', 2023))
          .mockResolvedValueOnce(makeBalance('5.00', 2024)),
        save: jest.fn(),
      },
    });
    const result = await svc.runForPayPeriod('default', payPeriod);
    expect(result.carryoversApplied).toBe(0);
    expect(transactionRepo.insert).not.toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ transactionType: 'carryover' })
    );
  });

  it('carryover without cap posts full prior balance', async () => {
    const policyNoCap = { ...basePolicy, carryoverMaxHours: null };
    const { svc, transactionRepo } = buildService({
      policyRepo: {
        listActiveForAccrual: jest.fn().mockResolvedValue([policyNoCap]),
      },
      balanceRepo: {
        getOrCreate: jest.fn().mockResolvedValue(makeBalance('0.00')),
        getForUpdate: jest
          .fn()
          .mockResolvedValueOnce(makeBalance('15.00', 2023))
          .mockResolvedValueOnce(null),
        save: jest.fn(),
      },
    });
    const result = await svc.runForPayPeriod('default', payPeriod);
    expect(result.carryoversApplied).toBe(1);
    expect(transactionRepo.insert).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ transactionType: 'carryover', hours: '15.00' })
    );
    expect(transactionRepo.insert).not.toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ transactionType: 'forfeit' })
    );
  });

  it('adjustBalance creates adjustment transaction', async () => {
    const trx = {};
    const balanceRepo = {
      getOrCreate: jest.fn().mockResolvedValue(makeBalance('10.00')),
      save: jest.fn(),
    };
    const transactionRepo = { insert: jest.fn() };
    const { svc } = buildService({ balanceRepo, transactionRepo });
    const result = await svc.adjustBalance(trx as never, {
      companyId: 'default',
      employeeId: testEmployee.id,
      leaveType: 'pto',
      policyId: basePolicy.id,
      calendarYear: 2024,
      hoursDelta: '2.00',
      actor: 'admin',
      notes: 'Manual correction',
    });
    expect(result.balanceHours).toBe('12.00');
    expect(transactionRepo.insert).toHaveBeenCalledWith(
      trx,
      expect.objectContaining({
        transactionType: 'adjustment',
        hours: '2.00',
        actor: 'admin',
      })
    );
  });
});
