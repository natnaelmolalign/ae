import {
  accrualHoursForPeriod,
  applyCarryoverCap,
  calendarYearFromDate,
  sumTransactionHours,
  tenureMonths,
} from '../../../../src/services/leave/AccrualEngine';
import type { LeavePolicy } from '../../../../src/models/LeavePolicy';

function policy(
  overrides: Partial<LeavePolicy> &
    Pick<LeavePolicy, 'accrualMethod' | 'accrualConfig'>
): LeavePolicy {
  return {
    id: 'p1',
    companyId: 'default',
    code: 'PTO',
    name: 'PTO',
    leaveType: 'pto',
    carryoverMaxHours: null,
    effectiveFrom: '2024-01-01',
    effectiveTo: null,
    isActive: true,
    createdAt: '2024-01-01',
    updatedAt: '2024-01-01',
    ...overrides,
  };
}

describe('AccrualEngine', () => {
  it('computes fixed accrual per period', () => {
    const hours = accrualHoursForPeriod(
      policy({
        accrualMethod: 'fixed_per_period',
        accrualConfig: { hoursPerPeriod: '4.00' },
      }),
      '2020-01-01',
      '2024-06-15'
    );
    expect(hours).toBe('4.00');
  });

  it('selects tenure band by hire date', () => {
    const hours = accrualHoursForPeriod(
      policy({
        accrualMethod: 'tenure_bands',
        accrualConfig: {
          bands: [
            { minTenureMonths: 0, hoursPerPeriod: '3.33' },
            { minTenureMonths: 60, hoursPerPeriod: '5.00' },
          ],
        },
      }),
      '2019-01-01',
      '2024-06-15'
    );
    expect(hours).toBe('5.00');
  });

  it('falls back to lowest band when tenure is below all thresholds', () => {
    const hours = accrualHoursForPeriod(
      policy({
        accrualMethod: 'tenure_bands',
        accrualConfig: {
          bands: [{ minTenureMonths: 60, hoursPerPeriod: '5.00' }],
        },
      }),
      '2024-01-01',
      '2024-06-15'
    );
    expect(hours).toBe('5.00');
  });

  it('caps carryover and computes forfeiture', () => {
    const result = applyCarryoverCap('120.00', '40.00');
    expect(result.carried).toBe('40.00');
    expect(result.forfeited).toBe('80.00');
  });

  it('carries full balance when closing balance is within cap', () => {
    const result = applyCarryoverCap('30.00', '40.00');
    expect(result).toEqual({ carried: '30.00', forfeited: '0.00' });
  });

  it('carries full balance when no cap is configured', () => {
    expect(applyCarryoverCap('25.00', null)).toEqual({
      carried: '25.00',
      forfeited: '0.00',
    });
  });

  it('sums signed transaction hours', () => {
    const total = sumTransactionHours([
      { hours: '10.00' },
      { hours: '-3.50' },
      { hours: '2.00' },
    ]);
    expect(total).toBe('8.50');
  });

  it('derives calendar year from payment date', () => {
    expect(calendarYearFromDate('2024-12-31')).toBe(2024);
  });

  it('computes tenure months', () => {
    expect(tenureMonths('2024-01-15', '2024-06-15')).toBe(5);
  });
});
