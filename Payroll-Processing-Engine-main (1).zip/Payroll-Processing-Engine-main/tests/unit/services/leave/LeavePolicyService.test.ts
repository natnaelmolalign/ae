import { LeavePolicyService } from '../../../../src/services/leave/LeavePolicyService';
import { PayrollDomainError } from '../../../../src/errors/PayrollDomainError';
import type { LeavePolicy } from '../../../../src/models/LeavePolicy';
import type { LeavePolicyRepository } from '../../../../src/repositories/interfaces';

describe('LeavePolicyService', () => {
  const policy: LeavePolicy = {
    id: 'lp-1',
    companyId: 'co-1',
    code: 'PTO',
    name: 'Paid Time Off',
    leaveType: 'pto',
    accrualMethod: 'fixed_per_period',
    accrualConfig: { hoursPerPeriod: '8.00' },
    carryoverMaxHours: '40.00',
    effectiveFrom: '2024-01-01',
    effectiveTo: null,
    isActive: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  function repo(overrides: Partial<LeavePolicyRepository> = {}) {
    return {
      create: jest.fn().mockResolvedValue(policy),
      update: jest.fn().mockResolvedValue(policy),
      findById: jest.fn().mockResolvedValue(policy),
      listByCompany: jest.fn().mockResolvedValue([policy]),
      ...overrides,
    } as unknown as LeavePolicyRepository;
  }

  it('delegates create, get, and list to repository', async () => {
    const r = repo();
    const svc = new LeavePolicyService(r);
    await svc.create({
      companyId: 'co-1',
      code: 'PTO',
      name: 'Paid Time Off',
      leaveType: 'pto',
      accrualMethod: 'fixed_per_period',
      accrualConfig: { hoursPerPeriod: '8.00' },
      carryoverMaxHours: '40.00',
      effectiveFrom: '2024-01-01',
      effectiveTo: null,
      isActive: true,
    });
    expect(r.create).toHaveBeenCalled();
    expect(await svc.get('lp-1', 'co-1')).toEqual(policy);
    expect(await svc.list('co-1')).toHaveLength(1);
  });

  it('returns updated policy on successful update', async () => {
    const r = repo();
    const svc = new LeavePolicyService(r);
    const updated = await svc.update('lp-1', 'co-1', { name: 'Updated PTO' });
    expect(r.update).toHaveBeenCalledWith('lp-1', 'co-1', {
      name: 'Updated PTO',
    });
    expect(updated).toEqual(policy);
  });

  it('throws when update misses', async () => {
    const svc = new LeavePolicyService(
      repo({
        update: jest.fn().mockResolvedValue(null),
      })
    );
    await expect(
      svc.update('missing', 'co-1', { name: 'X' })
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });
});
