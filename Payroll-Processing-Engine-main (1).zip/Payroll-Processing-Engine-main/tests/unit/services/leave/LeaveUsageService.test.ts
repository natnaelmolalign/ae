import { extractLeaveUsage } from '../../../../src/services/leave/LeaveUsageService';
import { PayrollErrorCode } from '../../../../src/errors/PayrollDomainError';
import { testEmployee } from '../../../helpers/testEmployees';
import type { PayPeriod } from '../../../../src/models/types';

const payPeriod: PayPeriod = {
  id: '2024-biweekly-1',
  startDate: '2024-01-01',
  endDate: '2024-01-14',
  paymentDate: '2024-01-16',
  frequency: 'biweekly',
  year: 2024,
  periodIndex: 1,
};

describe('extractLeaveUsage', () => {
  it('aggregates pto and sick hours from earnings', () => {
    const usages = extractLeaveUsage([
      { type: 'pto', amount: '0', hours: 8 },
      { type: 'pto', amount: '0', hours: 4 },
      { type: 'sick', amount: '0', hours: 2 },
      { type: 'regular', amount: '1000.00' },
    ]);
    expect(usages).toEqual([
      { leaveType: 'pto', hours: '12.00' },
      { leaveType: 'sick', hours: '2.00' },
    ]);
  });

  it('treats missing hours as zero', () => {
    expect(extractLeaveUsage([{ type: 'pto', amount: '0' }])).toEqual([]);
  });

  it('ignores non-leave and zero-hour lines', () => {
    expect(extractLeaveUsage([{ type: 'pto', amount: '0', hours: 0 }])).toEqual(
      []
    );
  });
});

describe('LeaveUsageService', () => {
  const policyRepo = {
    findActiveByType: jest.fn(),
  };
  const balanceRepo = {
    listByEmployee: jest.fn(),
    getForUpdate: jest.fn(),
    save: jest.fn(),
  };
  const transactionRepo = {
    insert: jest.fn(),
  };

  afterEach(() => {
    delete process.env.FEATURE_LEAVE_ACCRUALS;
    jest.resetModules();
    jest.clearAllMocks();
  });

  it('throws when no active policy exists for leave type', async () => {
    process.env.FEATURE_LEAVE_ACCRUALS = 'true';
    jest.resetModules();
    const {
      LeaveUsageService: Svc,
    } = require('../../../../src/services/leave/LeaveUsageService');
    const service = new Svc(
      { findActiveByType: jest.fn().mockResolvedValue(null) } as never,
      balanceRepo as never,
      transactionRepo as never
    );
    await expect(
      service.assertSufficientBalance(testEmployee, payPeriod, [
        { type: 'pto', amount: '0', hours: 8 },
      ])
    ).rejects.toMatchObject({ code: PayrollErrorCode.INVALID_INPUT });
  });

  it('throws when balance is insufficient', async () => {
    process.env.FEATURE_LEAVE_ACCRUALS = 'true';
    jest.resetModules();
    const {
      LeaveUsageService: Svc,
    } = require('../../../../src/services/leave/LeaveUsageService');
    const service = new Svc(
      {
        findActiveByType: jest.fn().mockResolvedValue({ id: 'pol-1' }),
      } as never,
      {
        listByEmployee: jest
          .fn()
          .mockResolvedValue([{ leaveType: 'pto', balanceHours: '4.00' }]),
      } as never,
      transactionRepo as never
    );
    await expect(
      service.assertSufficientBalance(testEmployee, payPeriod, [
        { type: 'pto', amount: '0', hours: 8 },
      ])
    ).rejects.toMatchObject({
      code: PayrollErrorCode.INSUFFICIENT_LEAVE_BALANCE,
    });
  });

  it('skips validation when feature disabled or no leave earnings', async () => {
    process.env.FEATURE_LEAVE_ACCRUALS = 'false';
    jest.resetModules();
    const {
      LeaveUsageService: Svc,
    } = require('../../../../src/services/leave/LeaveUsageService');
    const service = new Svc(
      policyRepo as never,
      balanceRepo as never,
      transactionRepo as never
    );
    await service.assertSufficientBalance(testEmployee, payPeriod, [
      { type: 'pto', amount: '0', hours: 8 },
    ]);
    await service.assertSufficientBalance(testEmployee, payPeriod, [
      { type: 'regular', amount: '1000.00' },
    ]);
    expect(policyRepo.findActiveByType).not.toHaveBeenCalled();
  });

  it('records usage transactions during payroll', async () => {
    process.env.FEATURE_LEAVE_ACCRUALS = 'true';
    jest.resetModules();
    const {
      LeaveUsageService: Svc,
    } = require('../../../../src/services/leave/LeaveUsageService');
    const trx = {};
    const balance = {
      leaveType: 'pto',
      balanceHours: '16.00',
    };
    const service = new Svc(
      {
        findActiveByType: jest.fn().mockResolvedValue({ id: 'pol-1' }),
      } as never,
      {
        getForUpdate: jest.fn().mockResolvedValue(balance),
        save: jest.fn(),
      } as never,
      { insert: jest.fn() } as never
    );
    await service.recordUsageFromPayroll(
      trx as never,
      testEmployee,
      payPeriod,
      'run-1',
      [{ type: 'pto', amount: '0', hours: 8 }]
    );
    expect(balance.balanceHours).toBe('8.00');
  });

  it('passes when balance is sufficient', async () => {
    process.env.FEATURE_LEAVE_ACCRUALS = 'true';
    jest.resetModules();
    const {
      LeaveUsageService: Svc,
    } = require('../../../../src/services/leave/LeaveUsageService');
    const service = new Svc(
      {
        findActiveByType: jest.fn().mockResolvedValue({ id: 'pol-1' }),
      } as never,
      {
        listByEmployee: jest
          .fn()
          .mockResolvedValue([{ leaveType: 'pto', balanceHours: '16.00' }]),
      } as never,
      transactionRepo as never
    );
    await expect(
      service.assertSufficientBalance(testEmployee, payPeriod, [
        { type: 'pto', amount: '0', hours: 8 },
      ])
    ).resolves.toBeUndefined();
  });

  it('uses zero balance when no balance row exists', async () => {
    process.env.FEATURE_LEAVE_ACCRUALS = 'true';
    jest.resetModules();
    const {
      LeaveUsageService: Svc,
    } = require('../../../../src/services/leave/LeaveUsageService');
    const service = new Svc(
      {
        findActiveByType: jest.fn().mockResolvedValue({ id: 'pol-1' }),
      } as never,
      {
        listByEmployee: jest.fn().mockResolvedValue([]),
      } as never,
      transactionRepo as never
    );
    await expect(
      service.assertSufficientBalance(testEmployee, payPeriod, [
        { type: 'pto', amount: '0', hours: 8 },
      ])
    ).rejects.toMatchObject({
      code: PayrollErrorCode.INSUFFICIENT_LEAVE_BALANCE,
    });
  });

  it('skips recording when policy or balance row is missing', async () => {
    process.env.FEATURE_LEAVE_ACCRUALS = 'true';
    jest.resetModules();
    const {
      LeaveUsageService: Svc,
    } = require('../../../../src/services/leave/LeaveUsageService');
    const insert = jest.fn();
    const service = new Svc(
      {
        findActiveByType: jest.fn().mockResolvedValue(null),
      } as never,
      {
        getForUpdate: jest.fn().mockResolvedValue(null),
        save: jest.fn(),
      } as never,
      { insert } as never
    );
    await service.recordUsageFromPayroll(
      {} as never,
      testEmployee,
      payPeriod,
      'run-1',
      [{ type: 'pto', amount: '0', hours: 8 }]
    );
    expect(insert).not.toHaveBeenCalled();
  });

  it('skips recordUsage when feature disabled', async () => {
    process.env.FEATURE_LEAVE_ACCRUALS = 'false';
    jest.resetModules();
    const insert = jest.fn();
    const {
      LeaveUsageService: Svc,
    } = require('../../../../src/services/leave/LeaveUsageService');
    const service = new Svc(
      policyRepo as never,
      balanceRepo as never,
      { insert } as never
    );
    await service.recordUsageFromPayroll(
      {} as never,
      testEmployee,
      payPeriod,
      'run-1',
      [{ type: 'pto', amount: '0', hours: 8 }]
    );
    expect(insert).not.toHaveBeenCalled();
  });

  it('skips recordUsage when balance row is missing', async () => {
    process.env.FEATURE_LEAVE_ACCRUALS = 'true';
    jest.resetModules();
    const insert = jest.fn();
    const {
      LeaveUsageService: Svc,
    } = require('../../../../src/services/leave/LeaveUsageService');
    const service = new Svc(
      {
        findActiveByType: jest.fn().mockResolvedValue({ id: 'pol-1' }),
      } as never,
      {
        getForUpdate: jest.fn().mockResolvedValue(null),
        save: jest.fn(),
      } as never,
      { insert } as never
    );
    await service.recordUsageFromPayroll(
      {} as never,
      testEmployee,
      payPeriod,
      'run-1',
      [{ type: 'pto', amount: '0', hours: 8 }]
    );
    expect(insert).not.toHaveBeenCalled();
  });
});
