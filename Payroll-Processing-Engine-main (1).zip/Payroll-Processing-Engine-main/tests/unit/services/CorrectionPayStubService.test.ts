import { CorrectionPayStubService } from '../../../src/services/CorrectionPayStubService';
import { emptyYtd } from '../../../src/utils/ytdUtils';

describe('CorrectionPayStubService', () => {
  const svc = new CorrectionPayStubService();
  const ytd = emptyYtd('emp-1', 2024);

  it('builds catch-up stub with positive net', () => {
    const stub = svc.buildCatchUp('emp-1', 'p1', '150.00', 'orig-1', ytd);
    expect(stub.netPay).toBe('150.00');
    expect(stub.negativeNetRecovery).toBe(false);
    expect(stub.lines[0]!.label).toBe('Retroactive Adjustment');
  });

  it('labels recovery when net is negative', () => {
    const stub = svc.buildCatchUp('emp-1', 'p1', '-75.00', null, ytd);
    expect(stub.negativeNetRecovery).toBe(true);
    expect(stub.lines[0]!.label).toContain('recovery');
  });
});
