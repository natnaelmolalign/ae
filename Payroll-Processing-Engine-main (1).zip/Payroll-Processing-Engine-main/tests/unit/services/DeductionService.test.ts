import { DeductionService } from '../../../src/services/DeductionService';
import { emptyYtd } from '../../../src/utils/ytdUtils';
import { getDeductionLimits } from '../../../src/data/2024/deductionLimits';
import { testEmployee } from '../../helpers/testEmployees';

const opts = (gross: string) => ({ taxYear: 2024, gross });

describe('DeductionService', () => {
  const service = new DeductionService();

  it('401k reduces federal taxable but not SS taxable base', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const result = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [{ type: '401k_pretax', amountPerPeriod: '500.00' }],
      ytd,
      opts('5000.00')
    );
    expect(result.federalTaxableReduction).toBe('500.00');
    expect(result.ssTaxableReduction).toBe('0.00');
    expect(result.medicareTaxableReduction).toBe('0.00');
  });

  it('section 125 reduces all tax bases', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const result = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [{ type: 'section_125', amountPerPeriod: '200.00' }],
      ytd,
      opts('5000.00')
    );
    expect(result.federalTaxableReduction).toBe('200.00');
    expect(result.ssTaxableReduction).toBe('200.00');
  });

  it('enforces §402(g) limit including current period', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const limits = getDeductionLimits(2024);
    ytd.pretax401k = '22900.00';
    const result = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [{ type: '401k_pretax', amountPerPeriod: '500.00' }],
      ytd,
      opts('5000.00')
    );
    expect(result.pretax401kAmount).toBe('100.00');
    const atLimit = service.enforce401kLimit(
      '500.00',
      limits.deferral402g,
      2024
    );
    expect(atLimit).toBe('0.00');
  });

  it('Roth 401k is post-tax and shares §402(g) pool with pre-tax', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    ytd.pretax401k = '22900.00';
    const result = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [{ type: '401k_roth', amountPerPeriod: '300.00' }],
      ytd,
      opts('5000.00')
    );
    expect(result.roth401kAmount).toBe('100.00');
    expect(result.federalTaxableReduction).toBe('0.00');
    expect(result.postTaxTotal).toBe('100.00');
  });

  it('caps HSA at annual limit and does not reduce FICA bases', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    ytd.hsa = '4100.00';
    const result = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [
        {
          type: 'hsa',
          amountPerPeriod: '200.00',
          hsaCoverage: 'individual',
        },
      ],
      ytd,
      opts('5000.00')
    );
    expect(result.hsaAmount).toBe('50.00');
    expect(result.ssTaxableReduction).toBe('0.00');
    expect(result.limitAdjustments.length).toBe(1);
  });

  it('pretax reductions never exceed gross', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const result = service.applyPreTax(
      '3000.00',
      '3000.00',
      '3000.00',
      '3000.00',
      [
        { type: 'section_125', amountPerPeriod: '1000.00' },
        { type: '401k_pretax', amountPerPeriod: '1500.00' },
        { type: 'hsa', amountPerPeriod: '500.00', hsaCoverage: 'individual' },
      ],
      ytd,
      opts('3000.00')
    );
    expect(parseFloat(result.federalTaxableReduction)).toBeLessThanOrEqual(
      3000
    );
  });

  it('applies FSA and percent-of-gross deductions', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    ytd.fsa = '3000.00';
    const result = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [
        { type: 'fsa', amountPerPeriod: '200.00' },
        {
          type: 'section_125',
          amountPerPeriod: '100.00',
          percentOfGross: '0.02',
        },
      ],
      ytd,
      opts('5000.00')
    );
    expect(parseFloat(result.fsaAmount)).toBeGreaterThan(0);
    expect(service.enforce401kLimit('500.00', '23000.00', 2024)).toBe('0.00');
    expect(service.totalDeductionsFromGross(result)).toBeTruthy();
  });

  it('applies FSA reductions and uncapped post-tax deductions', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const withFsa = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [{ type: 'fsa', amountPerPeriod: '100.00' }],
      ytd,
      opts('5000.00')
    );
    expect(withFsa.fsaAmount).toBe('100.00');
    const postTaxOnly = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [{ type: 'life_insurance', amountPerPeriod: '25.00' }],
      ytd,
      opts('5000.00')
    );
    expect(postTaxOnly.postTaxTotal).toBe('25.00');
    expect(postTaxOnly.limitAdjustments).toHaveLength(0);
  });

  it('records limit adjustment when deferral is capped', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    ytd.pretax401k = '22950.00';
    const result = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [{ type: '401k_pretax', amountPerPeriod: '500.00' }],
      ytd,
      opts('5000.00')
    );
    expect(result.pretax401kAmount).toBe('50.00');
    expect(result.limitAdjustments[0]?.requested).toBe('500.00');
    expect(service.enforce401kLimit('100.00', '22900.00', 2024)).toBe('100.00');
    expect(service.enforce401kLimit('100.00', '0.00')).toBe('100.00');
  });

  it('applies FSA-only pretax reductions', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const result = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [{ type: 'fsa', amountPerPeriod: '75.00' }],
      ytd,
      opts('5000.00')
    );
    expect(result.fsaAmount).toBe('75.00');
    expect(result.federalTaxableReduction).toBe('75.00');
  });

  it('caps HSA using explicit annualLimit when provided', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    ytd.hsa = '3800.00';
    const result = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [
        {
          type: 'hsa',
          amountPerPeriod: '500.00',
          annualLimit: '4000.00',
          hsaCoverage: 'individual',
        },
      ],
      ytd,
      opts('5000.00')
    );
    expect(result.hsaAmount).toBe('200.00');
  });

  it('caps generic pretax enrollment types via annual limit fallback', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const result = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [
        {
          type: 'garnishment_creditor',
          amountPerPeriod: '500.00',
          annualLimit: '100.00',
        },
      ],
      ytd,
      opts('5000.00')
    );
    expect(result.federalTaxableReduction).toBe('0.00');
  });

  it('caps unknown pretax type against annual limit', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const result = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [
        {
          type: 'section_125',
          amountPerPeriod: '6000.00',
          annualLimit: '1000.00',
        },
      ],
      ytd,
      opts('5000.00')
    );
    expect(parseFloat(result.section125Amount)).toBeLessThanOrEqual(1000);
  });

  it('caps HSA using default individual coverage when omitted', () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const result = service.applyPreTax(
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [{ type: 'hsa', amountPerPeriod: '500.00' }],
      ytd,
      opts('5000.00')
    );
    expect(parseFloat(result.hsaAmount)).toBeGreaterThan(0);
  });
});
