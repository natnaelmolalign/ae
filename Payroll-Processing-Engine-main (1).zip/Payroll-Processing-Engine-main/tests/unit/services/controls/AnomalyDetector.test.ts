import { AnomalyDetector } from '../../../../src/services/controls/ControlService';

describe('AnomalyDetector', () => {
  const detector = new AnomalyDetector();

  it('does not flag when history is empty', () => {
    const result = detector.evaluate({ amount: '5000.00', history: [] });
    expect(result.flagged).toBe(false);
  });

  it('flags large deviation from trailing average', () => {
    const result = detector.evaluate({
      amount: '20000.00',
      history: ['5000.00', '5100.00', '4900.00', '5050.00'],
      thresholds: { zScoreThreshold: 2 },
    });
    expect(result.flagged).toBe(true);
    expect(parseFloat(result.zScore)).toBeGreaterThan(2);
  });

  it('does not flag stable amounts near mean', () => {
    const result = detector.evaluate({
      amount: '5050.00',
      history: ['5000.00', '5100.00', '4900.00', '5050.00'],
      thresholds: { zScoreThreshold: 3 },
    });
    expect(result.flagged).toBe(false);
  });

  it('flags identical history when amount deviates beyond threshold', () => {
    const result = detector.evaluate({
      amount: '6000.00',
      history: ['5000.00', '5000.00', '5000.00'],
      thresholds: { zScoreThreshold: 500 },
    });
    expect(result.flagged).toBe(true);
    expect(result.trailingAverage).toBe('5000.00');
  });

  it('does not flag identical history when amount matches mean', () => {
    const result = detector.evaluate({
      amount: '5000.00',
      history: ['5000.00', '5000.00', '5000.00'],
      thresholds: { zScoreThreshold: 500 },
    });
    expect(result.flagged).toBe(false);
    expect(result.zScore).toBe('0');
  });
});
