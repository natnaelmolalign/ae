jest.mock('../../../../src/config/features', () => ({
  features: {
    payrollControlsEnabled: true,
  },
}));

import { ControlService } from '../../../../src/services/controls/ControlService';
import { PayrollErrorCode } from '../../../../src/errors/PayrollDomainError';
import type { PayrollHold } from '../../../../src/models/PayrollControl';
import type {
  PayStubRepository,
  PayrollControlRepository,
} from '../../../../src/repositories/interfaces';
import type { AuditService } from '../../../../src/services/AuditService';
import { features } from '../../../../src/config/features';

describe('ControlService', () => {
  const hold: PayrollHold = {
    id: 'hold-1',
    companyId: 'co-1',
    employeeId: 'emp-1',
    reasonCode: 'MANUAL_REVIEW',
    notes: null,
    status: 'active',
    createdBy: 'hr',
    releasedBy: null,
    releasedAt: null,
    releaseReason: null,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  const releasedHold: PayrollHold = {
    ...hold,
    status: 'released',
    releasedBy: 'hr',
    releasedAt: '2024-01-02T00:00:00.000Z',
    releaseReason: 'cleared',
  };

  function deps(
    overrides: {
      repo?: Partial<PayrollControlRepository>;
      payStubRepo?: Partial<PayStubRepository>;
      auditService?: Partial<AuditService>;
    } = {}
  ) {
    return {
      repo: {
        findActiveHoldForEmployee: jest.fn().mockResolvedValue(null),
        createHold: jest.fn().mockResolvedValue(hold),
        findHoldById: jest.fn().mockResolvedValue(hold),
        releaseHold: jest.fn().mockResolvedValue(releasedHold),
        listActiveHolds: jest.fn().mockResolvedValue([hold]),
        findPendingApprovalForEmployeePeriod: jest.fn().mockResolvedValue(null),
        findApprovedApprovalForEmployeePeriod: jest
          .fn()
          .mockResolvedValue(null),
        saveAnomalyFlag: jest.fn().mockResolvedValue(undefined),
        createApprovalRequest: jest.fn().mockResolvedValue(undefined),
        ...overrides.repo,
      } as unknown as PayrollControlRepository,
      payStubRepo: {
        listByEmployee: jest
          .fn()
          .mockResolvedValue([
            { grossPay: '5000.00' },
            { grossPay: '5100.00' },
            { grossPay: '4900.00' },
          ]),
        ...overrides.payStubRepo,
      } as unknown as PayStubRepository,
      auditService: {
        recordUpdate: jest.fn().mockResolvedValue(undefined),
        ...overrides.auditService,
      } as unknown as AuditService,
    };
  }

  it('delegates hold evaluation, creation, and listing', async () => {
    const d = deps({
      repo: { findActiveHoldForEmployee: jest.fn().mockResolvedValue(hold) },
    });
    const svc = new ControlService(d.repo, d.payStubRepo, d.auditService);
    expect(await svc.evaluateEmployeeHold('emp-1', 'co-1')).toEqual(hold);
    await svc.createHold({
      companyId: 'co-1',
      employeeId: 'emp-1',
      reasonCode: 'MANUAL_REVIEW',
      createdBy: 'hr',
    });
    expect(d.repo.createHold).toHaveBeenCalled();
    expect(await svc.listActiveHolds('co-1')).toHaveLength(1);
  });

  it('records audit when releasing an existing hold', async () => {
    const d = deps();
    const svc = new ControlService(d.repo, d.payStubRepo, d.auditService);
    const result = await svc.releaseHold('hold-1', 'co-1', 'hr', 'cleared');
    expect(result).toEqual(releasedHold);
    expect(d.auditService.recordUpdate).toHaveBeenCalled();
  });

  it('skips audit when release or prior hold snapshot is missing', async () => {
    const noHold = deps({
      repo: { releaseHold: jest.fn().mockResolvedValue(null) },
    });
    const svcNoHold = new ControlService(
      noHold.repo,
      noHold.payStubRepo,
      noHold.auditService
    );
    await svcNoHold.releaseHold('hold-1', 'co-1', 'hr', 'cleared');
    expect(noHold.auditService.recordUpdate).not.toHaveBeenCalled();

    const noBefore = deps({
      repo: { findHoldById: jest.fn().mockResolvedValue(null) },
    });
    const svcNoBefore = new ControlService(
      noBefore.repo,
      noBefore.payStubRepo,
      noBefore.auditService
    );
    await svcNoBefore.releaseHold('hold-1', 'co-1', 'hr', 'cleared');
    expect(noBefore.auditService.recordUpdate).not.toHaveBeenCalled();
  });

  it('returns early when payroll controls are disabled', async () => {
    (features as { payrollControlsEnabled: boolean }).payrollControlsEnabled =
      false;
    const d = deps({
      repo: { findActiveHoldForEmployee: jest.fn().mockResolvedValue(hold) },
    });
    const svc = new ControlService(d.repo, d.payStubRepo, d.auditService);
    await expect(
      svc.assertRunAllowed({
        employeeId: 'emp-1',
        companyId: 'co-1',
        payPeriodId: 'pp-1',
        grossAmount: '5000.00',
        actor: 'payroll',
      })
    ).resolves.toBeUndefined();
    expect(d.repo.findActiveHoldForEmployee).not.toHaveBeenCalled();
    (features as { payrollControlsEnabled: boolean }).payrollControlsEnabled =
      true;
  });

  it('blocks run when employee has active hold', async () => {
    const d = deps({
      repo: { findActiveHoldForEmployee: jest.fn().mockResolvedValue(hold) },
    });
    const svc = new ControlService(d.repo, d.payStubRepo, d.auditService);
    await expect(
      svc.assertRunAllowed({
        employeeId: 'emp-1',
        companyId: 'co-1',
        payPeriodId: 'pp-1',
        grossAmount: '5000.00',
        actor: 'payroll',
      })
    ).rejects.toMatchObject({ code: PayrollErrorCode.PAYROLL_HOLD_ACTIVE });
  });

  it('blocks run when pending anomaly approval exists', async () => {
    const d = deps({
      repo: {
        findPendingApprovalForEmployeePeriod: jest
          .fn()
          .mockResolvedValue({ id: 'ap-1' }),
      },
    });
    const svc = new ControlService(d.repo, d.payStubRepo, d.auditService);
    await expect(
      svc.assertRunAllowed({
        employeeId: 'emp-1',
        companyId: 'co-1',
        payPeriodId: 'pp-1',
        grossAmount: '5000.00',
        actor: 'payroll',
      })
    ).rejects.toMatchObject({
      code: PayrollErrorCode.ANOMALY_APPROVAL_REQUIRED,
      message: 'Pending anomaly approval required before payroll run',
    });
  });

  it('allows run when period already has approved anomaly', async () => {
    const d = deps({
      repo: {
        findApprovedApprovalForEmployeePeriod: jest
          .fn()
          .mockResolvedValue({ id: 'ap-approved' }),
      },
    });
    const svc = new ControlService(d.repo, d.payStubRepo, d.auditService);
    await expect(
      svc.assertRunAllowed({
        employeeId: 'emp-1',
        companyId: 'co-1',
        payPeriodId: 'pp-1',
        grossAmount: '5000.00',
        actor: 'payroll',
      })
    ).resolves.toBeUndefined();
    expect(d.payStubRepo.listByEmployee).not.toHaveBeenCalled();
  });

  it('allows run when gross pay is within normal range', async () => {
    const d = deps();
    const svc = new ControlService(d.repo, d.payStubRepo, d.auditService);
    await expect(
      svc.assertRunAllowed({
        employeeId: 'emp-1',
        companyId: 'co-1',
        payPeriodId: 'pp-1',
        grossAmount: '5050.00',
        actor: 'payroll',
      })
    ).resolves.toBeUndefined();
    expect(d.repo.saveAnomalyFlag).not.toHaveBeenCalled();
  });

  it('flags anomaly and requires approval for large gross deviation', async () => {
    const d = deps({
      payStubRepo: {
        listByEmployee: jest
          .fn()
          .mockResolvedValue([
            { grossPay: '5000.00' },
            { grossPay: '5100.00' },
            { grossPay: '4900.00' },
            { grossPay: '5050.00' },
          ]),
      },
    });
    const svc = new ControlService(d.repo, d.payStubRepo, d.auditService);
    await expect(
      svc.assertRunAllowed({
        employeeId: 'emp-1',
        companyId: 'co-1',
        payPeriodId: 'pp-1',
        grossAmount: '20000.00',
        actor: 'payroll',
      })
    ).rejects.toMatchObject({
      code: PayrollErrorCode.ANOMALY_APPROVAL_REQUIRED,
    });
    expect(d.repo.saveAnomalyFlag).toHaveBeenCalled();
    expect(d.repo.createApprovalRequest).toHaveBeenCalled();
  });
});
