import { YTDService } from '../../../src/services/YTDService';
import { emptyYtd } from '../../../src/utils/ytdUtils';

describe('YTDService', () => {
  const service = new YTDService();

  it('does not double-count gross on correction when original already counted', () => {
    const ytd = emptyYtd('emp-1', 2024);
    ytd.grossEarnings = '5000.00';

    const updated = service.applyPayrollRun(
      ytd,
      '5000.00',
      '4500.00',
      '4500.00',
      '5000.00',
      '5000.00',
      {
        federalIncome: '500.00',
        stateIncome: '200.00',
        localIncome: '0.00',
        socialSecurity: '310.00',
        medicare: '72.50',
        medicareAdditional: '0.00',
      },
      '0.00',
      '0.00',
      '0.00',
      '0.00',
      '0.00',
      '0.00',
      true,
      '5000.00'
    );

    expect(updated.grossEarnings).toBe('5000.00');
  });

  it('getOrCreate seeds empty YTD by payment year', () => {
    const store = new Map();
    const ytd = service.getOrCreate(store, 'emp-1', '2024-06-15');
    expect(ytd.taxYear).toBe(2024);
    expect(store.size).toBe(1);
    expect(service.getOrCreate(store, 'emp-1', '2024-07-01')).toBe(ytd);
  });

  it('resetForYear clears matching tax years only', () => {
    const store = new Map();
    service.getOrCreate(store, 'e1', '2024-01-01');
    service.getOrCreate(store, 'e1', '2025-01-01');
    store.get('e1:2024')!.grossEarnings = '999.00';
    service.resetForYear(store, 2024);
    expect(store.get('e1:2024')!.grossEarnings).toBe('0.00');
    expect(store.get('e1:2025')!.grossEarnings).toBe('0.00');
  });
});
