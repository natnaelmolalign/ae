import { BenefitEnrollmentService } from '../../../src/services/BenefitEnrollmentService';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../../src/errors/PayrollDomainError';
import type { BenefitEnrollment } from '../../../src/models/BenefitEnrollment';
import type { BenefitEnrollmentRepository } from '../../../src/repositories/interfaces';

describe('BenefitEnrollmentService', () => {
  const enrollment: BenefitEnrollment = {
    id: 'b1',
    employeeId: 'e1',
    type: '401k_pretax',
    amountPerPeriod: '200.00',
    percentOfGross: null,
    annualLimit: null,
    effectiveDate: '2024-01-01',
    endDate: null,
    hsaCoverage: null,
    catchUpEligible: false,
    priority: 100,
    lifeEventId: null,
    enrollmentWindowId: null,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  function repo(overrides: Partial<BenefitEnrollmentRepository> = {}) {
    return {
      create: jest.fn().mockResolvedValue(enrollment),
      findById: jest.fn().mockResolvedValue(enrollment),
      findByEmployee: jest.fn().mockResolvedValue([enrollment]),
      findActiveForEmployee: jest.fn().mockResolvedValue([enrollment]),
      update: jest.fn().mockResolvedValue(enrollment),
      delete: jest.fn().mockResolvedValue(true),
      ...overrides,
    } as unknown as BenefitEnrollmentRepository;
  }

  it('rejects HSA without coverage on create', async () => {
    const svc = new BenefitEnrollmentService(repo());
    await expect(
      svc.create({
        employeeId: 'e1',
        type: 'hsa',
        amountPerPeriod: '50.00',
        effectiveDate: '2024-01-01',
      })
    ).rejects.toMatchObject({ code: PayrollErrorCode.INVALID_INPUT });
  });

  it('updates with HSA validation and not-found paths', async () => {
    const hsa: BenefitEnrollment = {
      ...enrollment,
      type: 'hsa',
      hsaCoverage: 'individual',
    };
    await new BenefitEnrollmentService(
      repo({ findById: jest.fn().mockResolvedValue(hsa) })
    ).update('b1', { hsaCoverage: 'family' });
    await new BenefitEnrollmentService(
      repo({ findById: jest.fn().mockResolvedValue(hsa) })
    ).update('b1', { hsaCoverage: null });
    await new BenefitEnrollmentService(
      repo({ findById: jest.fn().mockResolvedValue(enrollment) })
    ).update('b1', { amountPerPeriod: '250.00' });
    await expect(
      new BenefitEnrollmentService(
        repo({ findById: jest.fn().mockResolvedValue(null) })
      ).update('missing', {})
    ).rejects.toBeInstanceOf(PayrollDomainError);
    await expect(
      new BenefitEnrollmentService(
        repo({
          findById: jest.fn().mockResolvedValue(hsa),
          update: jest.fn().mockResolvedValue(null),
        })
      ).update('b1', {})
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('lists and removes enrollments', async () => {
    const r = repo({ delete: jest.fn().mockResolvedValue(false) });
    const svc = new BenefitEnrollmentService(r);
    expect(await svc.get('b1')).toEqual(enrollment);
    expect(await svc.listByEmployee('e1')).toHaveLength(1);
    expect(await svc.listActive('e1', '2024-06-01')).toHaveLength(1);
    await expect(svc.remove('x')).rejects.toBeInstanceOf(PayrollDomainError);
  });
});
