import { W2ExportService } from '../../../../src/services/compliance/W2ExportService';

function payrollRow(
  id: string,
  firstName: string,
  lastName: string,
  gross: string,
  tinLastFour: string | null = null
) {
  return {
    pay_stub_id: id,
    employee_id: id,
    pay_period_id: 'p1',
    gross_pay: gross,
    payment_date: '2024-06-01',
    taxes: JSON.stringify({
      federalIncome: '100.00',
      stateIncome: '0.00',
      socialSecurity: '50.00',
      medicare: '10.00',
      medicareAdditional: '0.00',
    }),
    employer_contributions: JSON.stringify({
      ss: '50.00',
      medicare: '10.00',
      match401k: '0.00',
    }),
    id,
    company_id: 'co',
    first_name: firstName,
    last_name: lastName,
    employment_type: 'full_time_salaried',
    pay_frequency: 'monthly',
    base_compensation: '5000.00',
    hire_date: '2024-01-01',
    termination_date: null,
    filing_status: 'single',
    state_code: 'TX',
    w4_extra_withholding: '0.00',
    w4_dependents_credit: '0.00',
    w4_other_deductions: '0.00',
    w4_other_income: '0.00',
    w4_multiple_jobs: 0,
    local_municipality_code: null,
    equity_withholding_method: 'supplemental_flat',
    tin_last_four: tinLastFour,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
}

describe('W2ExportService', () => {
  it('sorts employees by name in preview', async () => {
    const rows = [
      payrollRow('e2', 'Zoe', 'Zulu', '2000.00'),
      payrollRow('e1', 'Amy', 'Alpha', '1000.00'),
    ];
    const chain = {
      join: jest.fn().mockReturnThis(),
      where: jest.fn().mockReturnThis(),
      whereBetween: jest.fn().mockReturnThis(),
      select: jest.fn().mockResolvedValue(rows),
    };
    const db = jest.fn(() => chain);
    const report = await new W2ExportService(db as never).build('co', 2024);
    expect(report.employees[0].employeeName).toContain('Amy');
    expect(report.totals.wages).toBe('3000.00');
  });

  it('masks TIN when last four digits are present', async () => {
    const row = payrollRow('e1', 'Amy', 'Alpha', '1000.00', '4321');
    const chain = {
      join: jest.fn().mockReturnThis(),
      where: jest.fn().mockReturnThis(),
      whereBetween: jest.fn().mockReturnThis(),
      select: jest.fn().mockResolvedValue([row]),
    };
    const db = jest.fn(() => chain);
    const report = await new W2ExportService(db as never).build('co', 2024);
    expect(report.employees[0].tinMasked).toBe('***-**-4321');
  });
});
