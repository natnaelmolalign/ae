import {
  filterByEmployment,
  isW2Employment,
  sumGross,
} from '../../../../src/services/compliance/compliancePayrollData';
import { testEmployee } from '../../../helpers/testEmployees';

describe('compliancePayrollData', () => {
  const w2Row = {
    employee: testEmployee,
    payStubId: 'stub-1',
    payPeriodId: 'p1',
    paymentDate: '2024-06-15',
    grossPay: '1000.00',
    taxes: {
      federalIncome: '100.00',
      stateIncome: '50.00',
      socialSecurity: '62.00',
      medicare: '14.50',
      medicareAdditional: '0.00',
    },
    employerContributions: {
      ss: '62.00',
      medicare: '14.50',
      match401k: '0.00',
    },
  };
  const contractorRow = {
    ...w2Row,
    employee: { ...testEmployee, employmentType: 'contractor' as const },
  };

  it('filters W-2 vs contractor rows', () => {
    expect(filterByEmployment([w2Row, contractorRow], 'w2')).toHaveLength(1);
    expect(
      filterByEmployment([w2Row, contractorRow], 'contractor')
    ).toHaveLength(1);
  });

  it('sums gross and classifies employment', () => {
    expect(sumGross([w2Row, contractorRow])).toBe('2000.00');
    expect(isW2Employment('full_time_salaried')).toBe(true);
    expect(isW2Employment('contractor')).toBe(false);
  });
});
