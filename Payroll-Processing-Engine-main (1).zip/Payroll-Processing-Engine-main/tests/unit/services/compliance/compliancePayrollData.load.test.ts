import { loadCompliancePayrollRows } from '../../../../src/services/compliance/compliancePayrollData';

describe('loadCompliancePayrollRows', () => {
  it('maps DB rows with JSON string taxes', async () => {
    const db = jest.fn(() => ({
      join: jest.fn().mockReturnThis(),
      where: jest.fn().mockReturnThis(),
      whereBetween: jest.fn().mockReturnThis(),
      select: jest.fn().mockResolvedValue([
        {
          pay_stub_id: 'stub-1',
          employee_id: 'e1',
          pay_period_id: 'p1',
          gross_pay: '1000.00',
          payment_date: '2024-06-15',
          taxes: JSON.stringify({
            federalIncome: '100.00',
            stateIncome: '50.00',
            socialSecurity: '62.00',
            medicare: '14.50',
            medicareAdditional: '0.00',
          }),
          employer_contributions: JSON.stringify({
            ss: '62.00',
            medicare: '14.50',
            match401k: '0.00',
          }),
          id: 'e1',
          company_id: 'co',
          first_name: 'Jane',
          last_name: 'Doe',
          employment_type: 'full_time_salaried',
          pay_frequency: 'biweekly',
          base_compensation: '5000',
          hire_date: '2024-01-01',
          termination_date: null,
          filing_status: 'single',
          state_code: 'CA',
          w4_extra_withholding: '0',
          w4_dependents_credit: '0',
          w4_other_deductions: '0',
          w4_other_income: '0',
          w4_multiple_jobs: false,
          local_municipality_code: null,
          equity_withholding_method: 'supplemental_flat',
          tin_last_four: null,
          created_at: '2024-01-01',
        },
      ]),
    }));
    const rows = await loadCompliancePayrollRows(
      db as never,
      'co',
      '2024-01-01',
      '2024-12-31'
    );
    expect(rows).toHaveLength(1);
    expect(rows[0]!.taxes.federalIncome).toBe('100.00');
  });

  it('maps object taxes and null employer fields', async () => {
    const db = jest.fn(() => ({
      join: jest.fn().mockReturnThis(),
      where: jest.fn().mockReturnThis(),
      whereBetween: jest.fn().mockReturnThis(),
      select: jest.fn().mockResolvedValue([
        {
          pay_stub_id: 'stub-2',
          employee_id: 'e2',
          pay_period_id: 'p2',
          gross_pay: '500.00',
          payment_date: '2024-07-01T12:00:00.000Z',
          taxes: { federalIncome: '10.00' },
          employer_contributions: {},
          id: 'e2',
          company_id: 'co',
          first_name: 'John',
          last_name: 'Smith',
          employment_type: 'contractor',
          pay_frequency: 'monthly',
          base_compensation: '0',
          hire_date: '2024-01-01',
          termination_date: null,
          filing_status: 'single',
          state_code: 'TX',
          w4_extra_withholding: '0',
          w4_dependents_credit: '0',
          w4_other_deductions: '0',
          w4_other_income: '0',
          w4_multiple_jobs: false,
          local_municipality_code: null,
          equity_withholding_method: 'supplemental_flat',
          tin_last_four: null,
          created_at: '2024-01-01',
        },
      ]),
    }));
    const rows = await loadCompliancePayrollRows(
      db as never,
      'co',
      '2024-01-01',
      '2024-12-31'
    );
    expect(rows[0]!.taxes.stateIncome).toBe('0.00');
    expect(rows[0]!.employerContributions.match401k).toBe('0.00');
    expect(rows[0]!.paymentDate).toBe('2024-07-01');
  });

  it('defaults missing tax and employer snapshot fields', async () => {
    const db = jest.fn(() => ({
      join: jest.fn().mockReturnThis(),
      where: jest.fn().mockReturnThis(),
      whereBetween: jest.fn().mockReturnThis(),
      select: jest.fn().mockResolvedValue([
        {
          pay_stub_id: 'stub-3',
          employee_id: 'e3',
          pay_period_id: 'p3',
          gross_pay: '100.00',
          payment_date: '2024-08-01',
          taxes: {},
          employer_contributions: {},
          id: 'e3',
          company_id: 'co',
          first_name: 'A',
          last_name: 'B',
          employment_type: 'full_time_salaried',
          pay_frequency: 'monthly',
          base_compensation: '0',
          hire_date: '2024-01-01',
          termination_date: null,
          filing_status: 'single',
          state_code: 'CA',
          w4_extra_withholding: '0',
          w4_dependents_credit: '0',
          w4_other_deductions: '0',
          w4_other_income: '0',
          w4_multiple_jobs: false,
          local_municipality_code: null,
          equity_withholding_method: 'supplemental_flat',
          tin_last_four: null,
          created_at: '2024-01-01',
        },
      ]),
    }));
    const rows = await loadCompliancePayrollRows(
      db as never,
      'co',
      '2024-01-01',
      '2024-12-31'
    );
    expect(rows[0]!.taxes.medicareAdditional).toBe('0.00');
    expect(rows[0]!.employerContributions.ss).toBe('0.00');
  });
});
