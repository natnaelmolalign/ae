import { JobService } from '../../../../src/services/costing/JobService';
import { PayrollDomainError } from '../../../../src/errors/PayrollDomainError';
import type {
  DepartmentRepository,
  JobRepository,
} from '../../../../src/repositories/interfaces';

describe('JobService', () => {
  const dept = {
    id: 'd1',
    companyId: 'co',
    code: 'ENG',
    name: 'Engineering',
    locationCode: null,
    isSystem: false,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };
  const job = {
    id: 'j1',
    companyId: 'co',
    departmentId: 'd1',
    code: 'PAY',
    name: 'Payroll',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  it('creates job when department exists', async () => {
    const jobRepo = {
      create: jest.fn().mockResolvedValue(job),
      findById: jest.fn(),
      listByDepartment: jest.fn(),
    } as unknown as JobRepository;
    const departmentRepo = {
      findById: jest.fn().mockResolvedValue(dept),
    } as unknown as DepartmentRepository;
    const svc = new JobService(jobRepo, departmentRepo);
    const created = await svc.create(
      { departmentId: 'd1', code: ' pay ', name: ' Payroll ' },
      'co'
    );
    expect(created).toEqual(job);
    expect(jobRepo.create).toHaveBeenCalledWith(
      expect.objectContaining({ code: 'PAY', name: 'Payroll' })
    );
  });

  it('rejects missing department', async () => {
    const svc = new JobService(
      {} as JobRepository,
      {
        findById: jest.fn().mockResolvedValue(null),
      } as unknown as DepartmentRepository
    );
    await expect(
      svc.create({ departmentId: 'x', code: 'A', name: 'B' }, 'co')
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('gets and lists jobs', async () => {
    const jobRepo = {
      findById: jest.fn().mockResolvedValue(job),
      listByDepartment: jest.fn().mockResolvedValue([job]),
    } as unknown as JobRepository;
    const svc = new JobService(jobRepo, {} as DepartmentRepository);
    expect(await svc.get('j1', 'co')).toEqual(job);
    expect(await svc.listByDepartment('d1', 'co')).toHaveLength(1);
  });
});
