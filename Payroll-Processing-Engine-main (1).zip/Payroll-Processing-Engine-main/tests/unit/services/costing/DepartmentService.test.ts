import { DepartmentService } from '../../../../src/services/costing/DepartmentService';
import { PayrollErrorCode } from '../../../../src/errors/PayrollDomainError';
import { UNASSIGNED_DEPARTMENT_CODE } from '../../../../src/services/costing/LaborCostAllocationService';
import type { DepartmentRepository } from '../../../../src/repositories/interfaces';

describe('DepartmentService', () => {
  const dept = {
    id: 'd1',
    companyId: 'co',
    code: 'ENG',
    name: 'Engineering',
    locationCode: 'HQ',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  function repo(overrides: Partial<DepartmentRepository> = {}) {
    return {
      create: jest.fn().mockResolvedValue(dept),
      findById: jest.fn().mockResolvedValue(dept),
      findByCode: jest.fn().mockResolvedValue(null),
      listByCompany: jest.fn().mockResolvedValue([dept]),
      ...overrides,
    } as unknown as DepartmentRepository;
  }

  it('creates department with trimmed code', async () => {
    const r = repo();
    const svc = new DepartmentService(r);
    await svc.create(
      { code: ' eng ', name: ' Eng ', locationCode: 'HQ' },
      'co'
    );
    expect(r.create).toHaveBeenCalledWith(
      expect.objectContaining({ code: 'ENG', name: 'Eng' })
    );
  });

  it('rejects reserved and duplicate codes', async () => {
    const svc = new DepartmentService(repo());
    await expect(
      svc.create({ code: UNASSIGNED_DEPARTMENT_CODE, name: 'X' }, 'co')
    ).rejects.toMatchObject({ code: PayrollErrorCode.INVALID_INPUT });
    const dup = new DepartmentService(
      repo({ findByCode: jest.fn().mockResolvedValue(dept) })
    );
    await expect(
      dup.create({ code: 'ENG', name: 'X' }, 'co')
    ).rejects.toMatchObject({ code: PayrollErrorCode.INVALID_INPUT });
  });

  it('gets and lists', async () => {
    const svc = new DepartmentService(repo());
    expect(await svc.get('d1', 'co')).toEqual(dept);
    expect(await svc.list('co')).toHaveLength(1);
  });
});
