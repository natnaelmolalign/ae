import {
  LaborCostAllocationService,
  UNASSIGNED_DEPARTMENT_CODE,
} from '../../../../src/services/costing/LaborCostAllocationService';
import { PayrollDomainError } from '../../../../src/errors/PayrollDomainError';
import type {
  DepartmentRepository,
  JobRepository,
} from '../../../../src/repositories/interfaces';

describe('LaborCostAllocationService', () => {
  const dept = {
    id: 'd1',
    companyId: 'co',
    code: 'ENG',
    name: 'Engineering',
    locationCode: null,
    isSystem: false,
  };
  const unassigned = {
    id: 'd-un',
    companyId: 'co',
    code: UNASSIGNED_DEPARTMENT_CODE,
    name: 'Unassigned',
    locationCode: null,
    isSystem: true,
  };

  function service(
    departmentRepo: Partial<DepartmentRepository> = {},
    jobRepo: Partial<JobRepository> = {}
  ) {
    return new LaborCostAllocationService(
      {
        create: jest.fn().mockResolvedValue(unassigned),
        findById: jest.fn().mockResolvedValue(dept),
        findByCode: jest.fn().mockResolvedValue(null),
        listByCompany: jest.fn(),
        ...departmentRepo,
      } as DepartmentRepository,
      {
        create: jest.fn(),
        findById: jest.fn().mockResolvedValue({
          id: 'j1',
          departmentId: 'd1',
          code: 'JOB1',
        }),
        listByDepartment: jest.fn(),
        ...jobRepo,
      } as JobRepository
    );
  }

  it('returns empty allocations when cost accounting disabled', async () => {
    const prev = process.env.FEATURE_COST_ACCOUNTING;
    process.env.FEATURE_COST_ACCOUNTING = 'false';
    jest.resetModules();
    const {
      LaborCostAllocationService: S,
    } = require('../../../../src/services/costing/LaborCostAllocationService');
    const disabled = new S(
      {
        findByCode: jest.fn(),
        create: jest.fn(),
        findById: jest.fn(),
        listByCompany: jest.fn(),
      } as never,
      {
        findById: jest.fn(),
        create: jest.fn(),
        listByDepartment: jest.fn(),
      } as never
    );
    await expect(
      disabled.resolveForRun('co', [{ departmentId: 'd1', percent: '100' }])
    ).resolves.toEqual([]);
    process.env.FEATURE_COST_ACCOUNTING = prev;
    jest.resetModules();
  });

  it('rejects empty, duplicate, negative, and over-100 allocations', () => {
    const svc = service();
    expect(() => svc.validatePercents([])).toThrow(PayrollDomainError);
    expect(() =>
      svc.validatePercents([{ departmentId: 'a', percent: '50' }])
    ).toThrow(PayrollDomainError);
    expect(() =>
      svc.validatePercents([
        { departmentId: 'a', percent: '50' },
        { departmentId: 'a', percent: '50' },
      ])
    ).toThrow(PayrollDomainError);
    expect(() =>
      svc.validatePercents([{ departmentId: 'a', percent: '-1' }])
    ).toThrow(PayrollDomainError);
    expect(() =>
      svc.validatePercents([
        { departmentId: 'a', percent: '60' },
        { departmentId: 'b', percent: '50' },
      ])
    ).toThrow(PayrollDomainError);
  });

  it('ensureUnassignedDepartment returns existing or creates', async () => {
    const svc = service({
      findByCode: jest
        .fn()
        .mockResolvedValueOnce(unassigned)
        .mockResolvedValue(unassigned),
    });
    expect(await svc.ensureUnassignedDepartment('co')).toBe(unassigned);
    const svc2 = service({
      findByCode: jest
        .fn()
        .mockResolvedValueOnce(null)
        .mockResolvedValueOnce(unassigned),
      create: jest.fn().mockResolvedValue(unassigned),
    });
    expect(await svc2.ensureUnassignedDepartment('co')).toBe(unassigned);
  });

  it('provision race throws when still missing', async () => {
    const svc = service({
      findByCode: jest.fn().mockResolvedValue(null),
      create: jest.fn().mockRejectedValue(new Error('unique')),
    });
    await expect(svc.ensureUnassignedDepartment('co')).rejects.toBeInstanceOf(
      PayrollDomainError
    );
  });

  it('resolveForRun validates department and job', async () => {
    const svc = service();
    const resolved = await svc.resolveForRun('co', [
      { departmentId: 'd1', percent: '100', jobId: 'j1' },
    ]);
    expect(resolved[0]!.segment.jobCode).toBe('JOB1');
    const missingDept = service({
      findById: jest.fn().mockResolvedValue(null),
    });
    await expect(
      missingDept.resolveForRun('co', [{ departmentId: 'x', percent: '100' }])
    ).rejects.toBeInstanceOf(PayrollDomainError);
    const badJob = service({
      findById: jest
        .fn()
        .mockResolvedValue({ id: 'j2', departmentId: 'other' }),
    });
    await expect(
      badJob.resolveForRun('co', [
        { departmentId: 'd1', percent: '100', jobId: 'j2' },
      ])
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('splitAmount returns single amount when no segments', () => {
    const svc = service();
    expect(svc.splitAmount('100.00', [])).toEqual(['100.00']);
    expect(
      svc.splitAmount('100.00', [
        {
          departmentId: 'd1',
          departmentCode: 'ENG',
          departmentName: 'Eng',
          locationCode: null,
          jobId: null,
          jobCode: null,
          percent: '60',
        },
        {
          departmentId: 'd2',
          departmentCode: 'OPS',
          departmentName: 'Ops',
          locationCode: null,
          jobId: null,
          jobCode: null,
          percent: '40',
        },
      ])
    ).toEqual(['60.00', '40.00']);
  });
});
