import { LaborCostReportingService } from '../../../../src/services/costing/LaborCostReportingService';
import { PayrollDomainError } from '../../../../src/errors/PayrollDomainError';

describe('LaborCostReportingService', () => {
  const allocationRepo = {
    findSegmentsForRuns: jest.fn(),
    insertMany: jest.fn(),
    findByPayrollRun: jest.fn(),
  };

  function mockDb(
    period: Record<string, unknown> | null,
    runs: Record<string, unknown>[]
  ) {
    return jest.fn((table: string) => {
      if (table === 'pay_periods') {
        return {
          where: jest.fn().mockReturnThis(),
          first: jest.fn().mockResolvedValue(period),
        };
      }
      if (table === 'payroll_runs as pr') {
        return {
          join: jest.fn().mockReturnThis(),
          where: jest.fn().mockReturnThis(),
          select: jest.fn().mockResolvedValue(runs),
        };
      }
      return {};
    });
  }

  it('throws when pay period is missing', async () => {
    const svc = new LaborCostReportingService(
      mockDb(null, []) as never,
      allocationRepo as never
    );
    await expect(svc.build('p1', 'co')).rejects.toBeInstanceOf(
      PayrollDomainError
    );
  });

  it('aggregates runs with JSON taxes and default unassigned segment', async () => {
    const runs = [
      {
        payroll_run_id: 'run-1',
        gross_pay: '1000.00',
        net_pay: '800.00',
        taxes: JSON.stringify({
          federalIncome: '100.00',
          stateIncome: '50.00',
        }),
        employer_contributions: JSON.stringify({
          ss: '62.00',
          medicare: '14.50',
          match401k: '25.00',
        }),
      },
    ];
    allocationRepo.findSegmentsForRuns.mockResolvedValue(new Map());
    const svc = new LaborCostReportingService(
      mockDb({ id: 'p1', company_id: 'co' }, runs) as never,
      allocationRepo as never
    );
    const report = await svc.build('p1', 'co');
    expect(report.departments).toHaveLength(1);
    expect(report.departments[0]!.departmentCode).toBe('UNASSIGNED');
    expect(report.totals.grossPay).toBe('1000.00');
  });

  it('splits financials across allocation segments', async () => {
    const runs = [
      {
        payroll_run_id: 'run-2',
        gross_pay: '2000.00',
        net_pay: '1500.00',
        taxes: {
          federalIncome: '200.00',
          stateIncome: '100.00',
        },
        employer_contributions: {
          ss: '124.00',
          medicare: '29.00',
          match401k: '0.00',
        },
      },
    ];
    allocationRepo.findSegmentsForRuns.mockResolvedValue(
      new Map([
        [
          'run-2',
          [
            {
              departmentId: 'd1',
              departmentCode: 'ENG',
              departmentName: 'Engineering',
              locationCode: null,
              jobId: null,
              jobCode: null,
              percent: '60',
            },
            {
              departmentId: 'd2',
              departmentCode: 'OPS',
              departmentName: 'Operations',
              locationCode: 'NYC',
              jobId: 'j1',
              jobCode: 'JOB1',
              percent: '40',
            },
          ],
        ],
      ])
    );
    const svc = new LaborCostReportingService(
      mockDb({ id: 'p1', company_id: 'co' }, runs) as never,
      allocationRepo as never
    );
    const report = await svc.build('p1', 'co');
    expect(report.departments).toHaveLength(2);
    expect(report.departments[0]!.grossPay).toBe('1200.00');
    expect(report.departments[1]!.grossPay).toBe('800.00');
  });

  it('defaults missing tax and employer fields on runs', async () => {
    const runs = [
      {
        payroll_run_id: 'run-3',
        gross_pay: '500.00',
        net_pay: '400.00',
        taxes: {},
        employer_contributions: {},
      },
    ];
    allocationRepo.findSegmentsForRuns.mockResolvedValue(new Map());
    const svc = new LaborCostReportingService(
      mockDb({ id: 'p1', company_id: 'co' }, runs) as never,
      allocationRepo as never
    );
    const report = await svc.build('p1', 'co');
    expect(report.totals.federalWithholding).toBe('0.00');
    expect(report.totals.employerFica).toBe('0.00');
  });
});
