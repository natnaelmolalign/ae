import { zeroContractorWithholding } from '../../../../src/services/contractor/ContractorTaxService';
import { assertContractorDeductionsAllowed } from '../../../../src/utils/contractorDeductions';
import { PayrollDomainError } from '../../../../src/errors/PayrollDomainError';
import { TaxCalculationService } from '../../../../src/services/TaxCalculationService';
import { testEmployee } from '../../../helpers/testEmployees';
import { emptyYtd } from '../../../../src/utils/ytdUtils';

describe('ContractorTaxService', () => {
  it('returns all-zero withholding', () => {
    const taxes = zeroContractorWithholding();
    expect(taxes).toEqual({
      federalIncome: '0.00',
      stateIncome: '0.00',
      localIncome: '0.00',
      socialSecurity: '0.00',
      medicare: '0.00',
      medicareAdditional: '0.00',
    });
  });

  it('rejects W-2 pre-tax deductions for contractors', () => {
    expect(() =>
      assertContractorDeductionsAllowed([
        { type: '401k_pretax', amountPerPeriod: '100.00' },
      ])
    ).toThrow(PayrollDomainError);
  });

  it('TaxCalculationService returns zero taxes for contractor', () => {
    const service = new TaxCalculationService();
    const contractor = {
      ...testEmployee,
      employmentType: 'contractor' as const,
    };
    const taxes = service.calculateAll(
      contractor,
      '5000.00',
      '5000.00',
      '5000.00',
      '5000.00',
      [{ type: 'regular', amount: '5000.00' }],
      emptyYtd(contractor.id, 2024),
      {
        paymentDate: '2024-06-15',
        regularFederalTaxable: '5000.00',
        supplementalFederalTaxable: '0.00',
      }
    );
    expect(taxes.federalIncome).toBe('0.00');
    expect(taxes.socialSecurity).toBe('0.00');
  });
});
