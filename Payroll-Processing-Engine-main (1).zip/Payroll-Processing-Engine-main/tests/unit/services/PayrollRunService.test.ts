import { PayrollRunService } from '../../../src/services/PayrollRunService';
import { PayrollDomainError } from '../../../src/errors/PayrollDomainError';
import { testEmployee } from '../../helpers/testEmployees';
import type { PayPeriod, PayrollRunInput } from '../../../src/models/types';
import { emptyYtd } from '../../../src/utils/ytdUtils';

const payPeriod: PayPeriod = {
  id: '2024-monthly-1',
  startDate: '2024-01-01',
  endDate: '2024-01-31',
  paymentDate: '2024-01-31',
  frequency: 'monthly',
  year: 2024,
  periodIndex: 1,
};

const runInput: PayrollRunInput = {
  employeeId: testEmployee.id,
  payPeriodId: payPeriod.id,
  earnings: [{ type: 'regular', amount: '5000.00' }],
  deductions: [],
  garnishments: [],
};

function mockDb() {
  const trx = jest.fn();
  return {
    transaction: jest.fn(async (cb: (t: unknown) => Promise<unknown>) =>
      cb(trx)
    ),
  };
}

describe('PayrollRunService', () => {
  it('preview returns computed result without persisting', async () => {
    const ytdRepo = {
      get: jest.fn().mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      getForUpdate: jest.fn(),
      save: jest.fn(),
    };
    const svc = new PayrollRunService(
      mockDb() as never,
      ytdRepo as never,
      {} as never,
      {} as never
    );
    const result = await svc.preview(testEmployee, payPeriod, runInput);
    expect(result.payStub.grossPay).toBe('5000.00');
    expect(ytdRepo.save).not.toHaveBeenCalled();
  });

  it('throws when useActiveGarnishmentOrders without repo', async () => {
    const svc = new PayrollRunService(
      mockDb() as never,
      { get: jest.fn() } as never,
      {} as never,
      {} as never
    );
    await expect(
      svc.preview(testEmployee, payPeriod, {
        ...runInput,
        useActiveGarnishmentOrders: true,
      })
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('runCatchUpCorrection rejects duplicate correction', async () => {
    const payrollRunRepo = {
      findByEmployeePeriodAndCorrection: jest
        .fn()
        .mockResolvedValue({ id: 'dup' }),
      findByIdempotencyKey: jest.fn(),
      insert: jest.fn(),
    };
    const ytdRepo = {
      getForUpdate: jest
        .fn()
        .mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      save: jest.fn(),
    };
    const svc = new PayrollRunService(
      mockDb() as never,
      ytdRepo as never,
      { insert: jest.fn() } as never,
      payrollRunRepo as never
    );
    await expect(
      svc.runCatchUpCorrection(testEmployee, payPeriod, '100.00', null)
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('run returns existing result on idempotency hit', async () => {
    const stub = {
      id: 'stub-1',
      employeeId: testEmployee.id,
      payPeriodId: payPeriod.id,
      grossPay: '5000.00',
      netPay: '4000.00',
      lines: [],
      isCorrection: false,
      createdAt: '2024-01-01T00:00:00.000Z',
    };
    const payrollRunRepo = {
      findByIdempotencyKey: jest.fn().mockResolvedValue({
        payStubId: 'stub-1',
      }),
      findByEmployeePeriodAndCorrection: jest.fn().mockResolvedValue(null),
      insert: jest.fn(),
    };
    const payStubRepo = {
      findById: jest.fn().mockResolvedValue(stub),
      insert: jest.fn(),
    };
    const trx = jest.fn((table: string) => {
      if (table === 'payroll_runs') {
        return {
          where: jest.fn().mockReturnThis(),
          first: jest.fn().mockResolvedValue({
            taxes: '{}',
            employer_contributions:
              '{"ss":"0.00","medicare":"0.00","match401k":"0.00"}',
          }),
        };
      }
      return {};
    });
    const db = {
      transaction: jest.fn(async (cb: (t: unknown) => Promise<unknown>) =>
        cb(trx)
      ),
    };
    const ytdRepo = {
      getForUpdate: jest
        .fn()
        .mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      save: jest.fn(),
    };
    const svc = new PayrollRunService(
      db as never,
      ytdRepo as never,
      payStubRepo as never,
      payrollRunRepo as never
    );
    const result = await svc.run(testEmployee, payPeriod, runInput, {
      idempotencyKey: 'idem-1',
    });
    expect(result.payStub.id).toBe('stub-1');
    expect(payrollRunRepo.insert).not.toHaveBeenCalled();
  });

  it('returns idempotent run with object taxes and employer fields', async () => {
    const stub = {
      id: 'stub-1',
      employeeId: testEmployee.id,
      payPeriodId: payPeriod.id,
      grossPay: '5000.00',
      netPay: '4000.00',
      lines: [],
      isCorrection: false,
      createdAt: '2024-01-01T00:00:00.000Z',
    };
    const taxes = {
      federalIncome: '500.00',
      stateIncome: '100.00',
      localIncome: '0.00',
      socialSecurity: '310.00',
      medicare: '72.50',
      medicareAdditional: '0.00',
    };
    const employer = { ss: '310.00', medicare: '72.50', match401k: '0.00' };
    const payrollRunRepo = {
      findByIdempotencyKey: jest
        .fn()
        .mockResolvedValue({ payStubId: 'stub-1' }),
      findByEmployeePeriodAndCorrection: jest.fn(),
      insert: jest.fn(),
    };
    const payStubRepo = {
      findById: jest.fn().mockResolvedValue(stub),
      insert: jest.fn(),
    };
    const trx = jest.fn((table: string) => {
      if (table === 'payroll_runs') {
        return {
          where: jest.fn().mockReturnThis(),
          first: jest
            .fn()
            .mockResolvedValue({ taxes, employer_contributions: employer }),
        };
      }
      return {};
    });
    const db = {
      transaction: jest.fn(async (cb: (t: unknown) => Promise<unknown>) =>
        cb(trx)
      ),
    };
    const svc = new PayrollRunService(
      db as never,
      { getForUpdate: jest.fn() } as never,
      payStubRepo as never,
      payrollRunRepo as never
    );
    const result = await svc.run(testEmployee, payPeriod, runInput, {
      idempotencyKey: 'idem-obj',
    });
    expect(result.taxes.federalIncome).toBe('500.00');
  });

  it('idempotency load fails when pay stub row missing', async () => {
    const payrollRunRepo = {
      findByIdempotencyKey: jest
        .fn()
        .mockResolvedValue({ payStubId: 'stub-x' }),
      findByEmployeePeriodAndCorrection: jest.fn(),
      insert: jest.fn(),
    };
    const payStubRepo = {
      findById: jest.fn().mockResolvedValue(null),
      insert: jest.fn(),
    };
    const trx = jest.fn();
    const db = {
      transaction: jest.fn(async (cb: (t: unknown) => Promise<unknown>) =>
        cb(trx)
      ),
    };
    const svc = new PayrollRunService(
      db as never,
      { getForUpdate: jest.fn() } as never,
      payStubRepo as never,
      payrollRunRepo as never
    );
    await expect(
      svc.run(testEmployee, payPeriod, runInput, { idempotencyKey: 'k2' })
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('idempotency load fails when payroll run row missing', async () => {
    const stub = {
      id: 'stub-1',
      employeeId: testEmployee.id,
      payPeriodId: payPeriod.id,
      grossPay: '5000.00',
      netPay: '4000.00',
      lines: [],
      isCorrection: false,
      createdAt: '2024-01-01T00:00:00.000Z',
    };
    const payrollRunRepo = {
      findByIdempotencyKey: jest
        .fn()
        .mockResolvedValue({ payStubId: 'stub-1' }),
      findByEmployeePeriodAndCorrection: jest.fn(),
      insert: jest.fn(),
    };
    const payStubRepo = {
      findById: jest.fn().mockResolvedValue(stub),
      insert: jest.fn(),
    };
    const trx = jest.fn((table: string) => {
      if (table === 'payroll_runs') {
        return {
          where: jest.fn().mockReturnThis(),
          first: jest.fn().mockResolvedValue(null),
        };
      }
      return {};
    });
    const db = {
      transaction: jest.fn(async (cb: (t: unknown) => Promise<unknown>) =>
        cb(trx)
      ),
    };
    const svc = new PayrollRunService(
      db as never,
      { getForUpdate: jest.fn() } as never,
      payStubRepo as never,
      payrollRunRepo as never
    );
    await expect(
      svc.run(testEmployee, payPeriod, runInput, { idempotencyKey: 'k3' })
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('previewWithYtd uses provided ytd and correction flags', async () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const svc = new PayrollRunService(
      mockDb() as never,
      { get: jest.fn() } as never,
      {} as never,
      {} as never
    );
    const { result, updatedYtd } = await svc.previewWithYtd(
      testEmployee,
      payPeriod,
      runInput,
      ytd,
      true,
      '4500.00'
    );
    expect(result.payStub.isCorrection).toBe(true);
    expect(updatedYtd).toBeDefined();
  });

  it('previewWithYtd loads ytd from repository when omitted', async () => {
    const ytd = emptyYtd(testEmployee.id, 2024);
    const get = jest.fn().mockResolvedValue(ytd);
    const svc = new PayrollRunService(
      mockDb() as never,
      { get } as never,
      {} as never,
      {} as never
    );
    await svc.previewWithYtd(testEmployee, payPeriod, runInput);
    expect(get).toHaveBeenCalledWith(testEmployee.id, 2024);
  });

  it('asserts leave balance when leave accruals are enabled', async () => {
    process.env.FEATURE_LEAVE_ACCRUALS = 'true';
    jest.resetModules();
    const leaveUsageService = {
      assertSufficientBalance: jest.fn().mockResolvedValue(undefined),
    };
    const {
      PayrollRunService: Svc,
    } = require('../../../src/services/PayrollRunService');
    const svc = new Svc(
      mockDb() as never,
      {
        get: jest.fn().mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      } as never,
      {} as never,
      {} as never,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      leaveUsageService
    );
    await svc.preview(testEmployee, payPeriod, {
      ...runInput,
      earnings: [
        { type: 'regular', amount: '5000.00' },
        { type: 'pto', amount: '0', hours: 8 },
      ],
    });
    expect(leaveUsageService.assertSufficientBalance).toHaveBeenCalled();
    delete process.env.FEATURE_LEAVE_ACCRUALS;
    jest.resetModules();
  });

  it('asserts leave balance with undefined earnings list', async () => {
    process.env.FEATURE_LEAVE_ACCRUALS = 'true';
    jest.resetModules();
    const leaveUsageService = {
      assertSufficientBalance: jest.fn().mockResolvedValue(undefined),
    };
    const {
      PayrollRunService: Svc,
    } = require('../../../src/services/PayrollRunService');
    const svc = new Svc(
      mockDb() as never,
      { get: jest.fn() } as never,
      {} as never,
      {} as never,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      leaveUsageService
    );
    await (
      svc as unknown as {
        assertLeaveBalance: (
          employee: typeof testEmployee,
          period: PayPeriod,
          input: { earnings?: PayrollRunInput['earnings'] }
        ) => Promise<void>;
      }
    ).assertLeaveBalance(testEmployee, payPeriod, {
      ...runInput,
      earnings: undefined,
    });
    expect(leaveUsageService.assertSufficientBalance).toHaveBeenCalledWith(
      testEmployee,
      payPeriod,
      []
    );
    delete process.env.FEATURE_LEAVE_ACCRUALS;
    jest.resetModules();
  });

  it('persists state allocation rows with zero percent when unmatched', async () => {
    process.env.FEATURE_MULTI_STATE_TAX = 'true';
    jest.resetModules();
    const stateInsert = jest.fn();
    const trx = jest.fn((table: string) => {
      if (table === 'payroll_run_state_allocations') {
        return { insert: stateInsert };
      }
      return {};
    });
    const db = {
      transaction: jest.fn(async (cb: (t: unknown) => Promise<unknown>) =>
        cb(trx)
      ),
    };
    const ytdRepo = {
      getForUpdate: jest
        .fn()
        .mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      save: jest.fn(),
    };
    const payStubRepo = { insert: jest.fn(), findById: jest.fn() };
    const payrollRunRepo = {
      findByIdempotencyKey: jest.fn().mockResolvedValue(null),
      findByEmployeePeriodAndCorrection: jest.fn().mockResolvedValue(null),
      insert: jest.fn(),
    };
    const {
      PayrollRunService: Svc,
    } = require('../../../src/services/PayrollRunService');
    const svc = new Svc(
      db as never,
      ytdRepo as never,
      payStubRepo as never,
      payrollRunRepo as never
    );
    jest.spyOn(svc['taxService'], 'stateTaxSlices').mockReturnValue({
      slices: [
        {
          stateCode: 'NY',
          allocatedWages: '5000.00',
          stateTaxWithheld: '250.00',
        },
      ],
      total: '250.00',
    });
    await svc.run(testEmployee, payPeriod, {
      ...runInput,
      stateAllocations: [{ stateCode: 'CA', percent: '100' }],
    });
    expect(stateInsert).toHaveBeenCalledWith(
      expect.objectContaining({ allocation_percent: '0.00' })
    );
    delete process.env.FEATURE_MULTI_STATE_TAX;
    jest.resetModules();
  });

  it('skips leave validation when service is not configured', async () => {
    process.env.FEATURE_LEAVE_ACCRUALS = 'true';
    jest.resetModules();
    const {
      PayrollRunService: Svc,
    } = require('../../../src/services/PayrollRunService');
    const svc = new Svc(
      mockDb() as never,
      {
        get: jest.fn().mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      } as never,
      {} as never,
      {} as never
    );
    await expect(
      svc.preview(testEmployee, payPeriod, runInput)
    ).resolves.toBeDefined();
    delete process.env.FEATURE_LEAVE_ACCRUALS;
    jest.resetModules();
  });

  it('compute uses default deduction schedule list when omitted', async () => {
    const svc = new PayrollRunService(
      mockDb() as never,
      {
        get: jest.fn().mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      } as never,
      {} as never,
      {} as never
    );
    const { result } = await (
      svc as unknown as {
        compute: (
          employee: typeof testEmployee,
          period: PayPeriod,
          input: PayrollRunInput,
          ytd: ReturnType<typeof emptyYtd>,
          garnishments: [],
          isCorrection: boolean,
          correctionOriginalGross: string,
          correctsPayStubId: null
        ) => { result: { payStub: { grossPay: string } } };
      }
    ).compute(
      testEmployee,
      payPeriod,
      runInput,
      emptyYtd(testEmployee.id, 2024),
      [],
      false,
      '0.00',
      null
    );
    expect(result.payStub.grossPay).toBe('5000.00');
  });

  it('runInternal uses default options when omitted', async () => {
    const ytdRepo = {
      getForUpdate: jest
        .fn()
        .mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      save: jest.fn(),
    };
    const payStubRepo = { insert: jest.fn(), findById: jest.fn() };
    const payrollRunRepo = {
      findByIdempotencyKey: jest.fn().mockResolvedValue(null),
      findByEmployeePeriodAndCorrection: jest.fn().mockResolvedValue(null),
      insert: jest.fn(),
    };
    const trx = jest.fn();
    const db = {
      transaction: jest.fn(async (cb: (t: unknown) => Promise<unknown>) =>
        cb(trx)
      ),
    };
    const svc = new PayrollRunService(
      db as never,
      ytdRepo as never,
      payStubRepo as never,
      payrollRunRepo as never
    );
    const result = await (
      svc as unknown as {
        runInternal: (
          employee: typeof testEmployee,
          period: PayPeriod,
          input: PayrollRunInput
        ) => Promise<{ payStub: { grossPay: string } }>;
      }
    ).runInternal(testEmployee, payPeriod, runInput);
    expect(result.payStub.grossPay).toBe('5000.00');
  });

  it('runCatchUpCorrection persists net-only correction', async () => {
    const payrollRunRepo = {
      findByEmployeePeriodAndCorrection: jest.fn().mockResolvedValue(null),
      findByIdempotencyKey: jest.fn(),
      insert: jest.fn(),
    };
    const payStubRepo = { insert: jest.fn(), findById: jest.fn() };
    const ytdRepo = {
      getForUpdate: jest
        .fn()
        .mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      save: jest.fn(),
    };
    const trx = jest.fn();
    const db = {
      transaction: jest.fn(async (cb: (t: unknown) => Promise<unknown>) =>
        cb(trx)
      ),
    };
    const svc = new PayrollRunService(
      db as never,
      ytdRepo as never,
      payStubRepo as never,
      payrollRunRepo as never
    );
    const result = await svc.runCatchUpCorrection(
      testEmployee,
      payPeriod,
      '250.00',
      'orig-stub'
    );
    expect(result.payStub.netPay).toBe('250.00');
    expect(payrollRunRepo.insert).toHaveBeenCalled();
  });

  it('resolves active garnishment orders and percent-only allocations', async () => {
    const garnishmentOrderRepo = {
      findActiveForEmployee: jest.fn().mockResolvedValue([
        {
          id: 'g1',
          employeeId: testEmployee.id,
          type: 'child_support',
          priority: 1,
          fixedAmount: '0.00',
          percentOfDisposable: '0.25',
          caseId: 'case-1',
          effectiveDate: '2024-01-01',
          endDate: null,
          createdAt: '2024-01-01',
          updatedAt: '2024-01-01',
        },
      ]),
    };
    const svc = new PayrollRunService(
      mockDb() as never,
      {
        get: jest.fn().mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      } as never,
      {} as never,
      {} as never,
      garnishmentOrderRepo as never
    );
    const result = await svc.preview(testEmployee, payPeriod, {
      ...runInput,
      useActiveGarnishmentOrders: true,
      garnishments: [],
    });
    expect(result.payStub.grossPay).toBe('5000.00');
  });

  it('preview includes equity and scheduled deduction summaries', async () => {
    process.env.FEATURE_EQUITY = 'true';
    process.env.FEATURE_COBRA_ARREARS = 'true';
    jest.resetModules();
    const {
      PayrollRunService: Svc,
    } = require('../../../src/services/PayrollRunService');
    const deductionScheduleRepo = {
      findActiveForEmployee: jest.fn().mockResolvedValue([
        {
          id: 'sched-cobra',
          companyId: 'default',
          employeeId: testEmployee.id,
          scheduleType: 'cobra_premium',
          amountPerPeriod: '50.00',
          remainingBalance: null,
          priority: 1,
          startDate: '2024-01-01',
          endDate: null,
          createdAt: '2024-01-01',
          updatedAt: '2024-01-01',
        },
        {
          id: 'sched-arr',
          companyId: 'default',
          employeeId: testEmployee.id,
          scheduleType: 'arrears',
          amountPerPeriod: '25.00',
          remainingBalance: '100.00',
          priority: 2,
          startDate: '2024-01-01',
          endDate: null,
          createdAt: '2024-01-01',
          updatedAt: '2024-01-01',
        },
      ]),
      create: jest.fn(),
      findById: jest.fn(),
      updateRemainingBalance: jest.fn(),
    };
    const svc = new Svc(
      mockDb() as never,
      {
        get: jest.fn().mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      } as never,
      {} as never,
      {} as never,
      undefined,
      deductionScheduleRepo as never
    );
    const result = await svc.preview(testEmployee, payPeriod, {
      ...runInput,
      earnings: [
        { type: 'regular', amount: '3000.00' },
        { type: 'rsu_vest', amount: '2000.00' },
      ],
      useActiveDeductionSchedules: true,
    });
    expect(result.equitySummary).toBeDefined();
    expect(result.scheduledDeductions?.cobraPremium).toBeTruthy();
    expect(result.scheduledDeductions?.arrearsRecovery).toBeTruthy();
    delete process.env.FEATURE_EQUITY;
    delete process.env.FEATURE_COBRA_ARREARS;
    jest.resetModules();
  });

  it('includes scheduled deductions when total is zero but lines have amounts', async () => {
    jest.resetModules();
    jest.doMock(
      '../../../src/services/deductions/ScheduledDeductionService',
      () => ({
        ScheduledDeductionService: jest.fn().mockImplementation(() => ({
          resolve: jest.fn().mockReturnValue({
            lines: [
              {
                scheduleId: 'sched-1',
                scheduleType: 'cobra_premium',
                label: 'COBRA Premium',
                amount: '25.00',
              },
            ],
            total: '0.00',
            balanceUpdates: [],
          }),
        })),
      })
    );
    const {
      PayrollRunService: Svc,
    } = require('../../../src/services/PayrollRunService');
    const svc = new Svc(
      mockDb() as never,
      {
        get: jest.fn().mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      } as never,
      {} as never,
      {} as never
    );
    const result = await svc.preview(testEmployee, payPeriod, runInput);
    expect(result.scheduledDeductions?.lines[0]?.amount).toBe('25.00');
    jest.dontMock('../../../src/services/deductions/ScheduledDeductionService');
    jest.resetModules();
  });

  it('run records metrics on success and domain errors', async () => {
    const payrollRunRepo = {
      findByIdempotencyKey: jest.fn().mockResolvedValue(null),
      findByEmployeePeriodAndCorrection: jest
        .fn()
        .mockResolvedValueOnce(null)
        .mockResolvedValueOnce({ id: 'dup' }),
      insert: jest.fn(),
    };
    const payStubRepo = { insert: jest.fn(), findById: jest.fn() };
    const ytdRepo = {
      getForUpdate: jest
        .fn()
        .mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      save: jest.fn(),
    };
    const trx = jest.fn((table: string) => {
      if (table === 'payroll_run_state_allocations') {
        return { insert: jest.fn() };
      }
      return {};
    });
    const db = {
      transaction: jest.fn(async (cb: (t: unknown) => Promise<unknown>) =>
        cb(trx)
      ),
    };
    const svc = new PayrollRunService(
      db as never,
      ytdRepo as never,
      payStubRepo as never,
      payrollRunRepo as never
    );
    await svc.run(testEmployee, payPeriod, runInput, {
      metricsSource: 'batch',
    });
    await expect(
      svc.run(testEmployee, payPeriod, runInput, { isCorrection: true })
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('persists state allocations, webhooks, and cost segments on run', async () => {
    const payrollRunRepo = {
      findByIdempotencyKey: jest.fn().mockResolvedValue(null),
      findByEmployeePeriodAndCorrection: jest.fn().mockResolvedValue(null),
      insert: jest.fn(),
    };
    const payStubRepo = { insert: jest.fn(), findById: jest.fn() };
    const ytdRepo = {
      getForUpdate: jest
        .fn()
        .mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      save: jest.fn(),
    };
    const stateInsert = jest.fn();
    const trx = jest.fn((table: string) => {
      if (table === 'payroll_run_state_allocations') {
        return { insert: stateInsert };
      }
      return {};
    });
    const db = {
      transaction: jest.fn(async (cb: (t: unknown) => Promise<unknown>) =>
        cb(trx)
      ),
    };
    const webhookOutbox = { enqueuePayrollRunCompleted: jest.fn() };
    const laborCostAllocation = {
      resolveForRun: jest.fn().mockResolvedValue([
        {
          departmentId: 'd1',
          jobId: null,
          allocationPercent: '100',
          allocationHours: null,
          segment: {
            departmentId: 'd1',
            departmentCode: 'ENG',
            departmentName: 'Eng',
            locationCode: null,
            jobId: null,
            jobCode: null,
            percent: '100',
          },
        },
      ]),
    };
    const payrollRunAllocationRepo = {
      insertMany: jest.fn(),
      findSegmentsForRuns: jest.fn(),
      findByPayrollRun: jest.fn(),
    };
    const svc = new PayrollRunService(
      db as never,
      ytdRepo as never,
      payStubRepo as never,
      payrollRunRepo as never,
      undefined,
      undefined,
      webhookOutbox as never,
      laborCostAllocation as never,
      payrollRunAllocationRepo as never
    );
    await svc.run(testEmployee, payPeriod, {
      ...runInput,
      stateAllocations: [{ stateCode: 'NY', percent: '100' }],
    });
    expect(stateInsert).toHaveBeenCalled();
    expect(webhookOutbox.enqueuePayrollRunCompleted).toHaveBeenCalled();
    expect(payrollRunAllocationRepo.insertMany).toHaveBeenCalled();
  });

  it('preview maps garnishment percentOfDisposable null and state slices', async () => {
    const svc = new PayrollRunService(
      mockDb() as never,
      {
        get: jest.fn().mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      } as never,
      {} as never,
      {} as never
    );
    const result = await svc.preview(testEmployee, payPeriod, {
      ...runInput,
      garnishments: [
        {
          type: 'child_support',
          fixedAmount: '100.00',
          priority: 1,
        },
      ],
      stateAllocations: [{ stateCode: 'NY', percent: '100' }],
    });
    expect(result.payStub.grossPay).toBe('5000.00');
  });

  it('idempotency returns parsed run when taxes stored as JSON strings', async () => {
    const stub = {
      id: 'stub-s',
      employeeId: testEmployee.id,
      payPeriodId: payPeriod.id,
      grossPay: '5000.00',
      netPay: '4000.00',
      lines: [],
      isCorrection: false,
      createdAt: '2024-01-01T00:00:00.000Z',
    };
    const payrollRunRepo = {
      findByIdempotencyKey: jest
        .fn()
        .mockResolvedValue({ payStubId: 'stub-s' }),
      findByEmployeePeriodAndCorrection: jest.fn().mockResolvedValue(null),
      insert: jest.fn(),
    };
    const payStubRepo = {
      findById: jest.fn().mockResolvedValue(stub),
      insert: jest.fn(),
    };
    const trx = jest.fn((table: string) => {
      if (table === 'payroll_runs') {
        return {
          where: jest.fn().mockReturnThis(),
          first: jest.fn().mockResolvedValue({
            taxes: JSON.stringify({
              federalIncome: '1.00',
              stateIncome: '2.00',
              localIncome: '0.00',
              socialSecurity: '3.00',
              medicare: '4.00',
              medicareAdditional: '0.00',
            }),
            employer_contributions: JSON.stringify({
              ss: '3.00',
              medicare: '4.00',
              match401k: '0.00',
            }),
          }),
        };
      }
      return {};
    });
    const db = {
      transaction: jest.fn(async (cb: (t: unknown) => Promise<unknown>) =>
        cb(trx)
      ),
    };
    const ytdRepo = {
      getForUpdate: jest
        .fn()
        .mockResolvedValue(emptyYtd(testEmployee.id, 2024)),
      save: jest.fn(),
    };
    const svc = new PayrollRunService(
      db as never,
      ytdRepo as never,
      payStubRepo as never,
      payrollRunRepo as never
    );
    const result = await svc.run(testEmployee, payPeriod, runInput, {
      idempotencyKey: 'idem-str',
    });
    expect(result.taxes.federalIncome).toBe('1.00');
    expect(payrollRunRepo.insert).not.toHaveBeenCalled();
  });
});
