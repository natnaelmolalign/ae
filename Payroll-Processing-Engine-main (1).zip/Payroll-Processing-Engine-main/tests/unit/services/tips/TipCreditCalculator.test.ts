import { TipCreditCalculator } from '../../../../src/services/tips/TipCreditCalculator';
import { testEmployee } from '../../../helpers/testEmployees';
import { PayrollDomainError } from '../../../../src/errors/PayrollDomainError';

describe('TipCreditCalculator', () => {
  const calc = new TipCreditCalculator();
  const hourly = {
    ...testEmployee,
    employmentType: 'full_time_hourly' as const,
  };

  it('computes FLSA shortfall when tips plus cash wage are below minimum', () => {
    const result = calc.computeShortfall(hourly, '100.00', {
      hours: 40,
      directCashWages: '85.20',
      minimumWage: '7.25',
    });
    expect(result.requiredMinimumPay).toBe('290.00');
    expect(result.shortfallMakeUp).toBe('104.80');
  });

  it('returns zero shortfall when tips cover minimum', () => {
    const result = calc.computeShortfall(hourly, '250.00', {
      hours: 40,
      directCashWages: '85.20',
      minimumWage: '7.25',
    });
    expect(result.shortfallMakeUp).toBe('0.00');
  });

  it('rejects salaried employees', () => {
    expect(() =>
      calc.computeShortfall(
        { ...testEmployee, employmentType: 'full_time_salaried' },
        '100.00',
        { hours: 40, directCashWages: '85.20' }
      )
    ).toThrow(PayrollDomainError);
  });

  it('rejects non-positive hours and computes default cash wages', () => {
    expect(() =>
      calc.computeShortfall(hourly, '0.00', {
        hours: 0,
        directCashWages: '10.00',
      })
    ).toThrow(PayrollDomainError);
    expect(calc.defaultDirectCashWages(40)).toBe('85.20');
  });
});
