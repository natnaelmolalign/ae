import { testEmployee } from '../../../helpers/testEmployees';

describe('TipPayrollHelper', () => {
  afterEach(() => {
    delete process.env.FEATURE_TIPS;
    jest.resetModules();
  });

  it('returns earnings unchanged when tips feature disabled', () => {
    jest.resetModules();
    process.env.FEATURE_TIPS = 'false';
    const {
      TipPayrollHelper: Helper,
    } = require('../../../../src/services/tips/TipPayrollHelper');
    const h = new Helper();
    const out = h.prepare(testEmployee, {
      employeeId: testEmployee.id,
      payPeriodId: 'p1',
      earnings: [{ type: 'cash_tips', amount: '50.00' }],
      deductions: [],
      garnishments: [],
    });
    expect(out.tipSummary.tipCreditMakeup).toBe('0.00');
    expect(out.earnings).toHaveLength(1);
  });

  it('adds tip credit makeup line when shortfall computed', () => {
    process.env.FEATURE_TIPS = 'true';
    jest.resetModules();
    const {
      TipPayrollHelper: Helper,
    } = require('../../../../src/services/tips/TipPayrollHelper');
    const h = new Helper();
    const hourly = {
      ...testEmployee,
      employmentType: 'full_time_hourly' as const,
    };
    const out = h.prepare(hourly, {
      employeeId: hourly.id,
      payPeriodId: 'p1',
      earnings: [{ type: 'cash_tips', amount: '85.20' }],
      deductions: [],
      garnishments: [],
      tipCredit: { hours: 40, directCashWages: '85.20', minimumWage: '7.25' },
    });
    expect(
      out.earnings.some((e: { type: string }) => e.type === 'tip_credit_makeup')
    ).toBe(true);
  });
});
