import { AllocatedTipsService } from '../../../../src/services/tips/AllocatedTipsService';
import { PayrollDomainError } from '../../../../src/errors/PayrollDomainError';

describe('AllocatedTipsService', () => {
  const svc = new AllocatedTipsService();

  it('validates tip earnings and reports for minimum wage', () => {
    const summary = svc.validateTipEarnings([
      { type: 'cash_tips', amount: '100.00' },
      { type: 'charged_tips', amount: '50.00' },
      { type: 'allocated_tips', amount: '25.00' },
    ]);
    expect(summary.totalTips).toBe('175.00');
    const reported = svc.reportedTipsForMinimumWage([
      { type: 'cash_tips', amount: '80.00' },
      { type: 'charged_tips', amount: '20.00' },
    ]);
    expect(reported).toBe('100.00');
  });

  it('rejects double-counted allocated tips', () => {
    expect(() =>
      svc.validateTipEarnings([
        { type: 'regular', amount: '175.00' },
        { type: 'cash_tips', amount: '100.00' },
        { type: 'charged_tips', amount: '50.00' },
        { type: 'allocated_tips', amount: '25.00' },
      ])
    ).toThrow(PayrollDomainError);
  });
});
