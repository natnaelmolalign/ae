import { HourlyPayCalculator } from '../../../src/services/HourlyPayCalculator';

describe('HourlyPayCalculator', () => {
  const calc = new HourlyPayCalculator();

  it('pays rate × hours with half-up cents', () => {
    expect(calc.payForHours('25.00', '8')).toBe('200.00');
    expect(calc.payForMinutes('30.00', 90)).toBe('45.00');
  });

  it('applies multiplier for overtime', () => {
    expect(calc.payForMinutes('20.00', 60, '1.5')).toBe('30.00');
  });
});
