import { GarnishmentOrderService } from '../../../src/services/GarnishmentOrderService';
import { PayrollDomainError } from '../../../src/errors/PayrollDomainError';
import type { GarnishmentOrder } from '../../../src/models/GarnishmentOrder';
import type { GarnishmentOrderRepository } from '../../../src/repositories/interfaces';

describe('GarnishmentOrderService', () => {
  const order: GarnishmentOrder = {
    id: 'g1',
    employeeId: 'e1',
    type: 'child_support',
    caseId: 'CASE-1',
    priority: 1,
    fixedAmount: '100.00',
    maxPercentOfDisposable: '50.00',
    effectiveDate: '2024-01-01',
    endDate: null,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  function repo(overrides: Partial<GarnishmentOrderRepository> = {}) {
    return {
      create: jest.fn().mockResolvedValue(order),
      findById: jest.fn().mockResolvedValue(order),
      findByEmployee: jest.fn().mockResolvedValue([order]),
      findActiveForEmployee: jest.fn().mockResolvedValue([order]),
      update: jest.fn().mockResolvedValue(order),
      delete: jest.fn().mockResolvedValue(true),
      ...overrides,
    } as unknown as GarnishmentOrderRepository;
  }

  it('delegates CRUD to repository', async () => {
    const r = repo();
    const svc = new GarnishmentOrderService(r);
    await svc.create({
      employeeId: 'e1',
      type: 'child_support',
      caseId: 'CASE-1',
      fixedAmount: '100.00',
      maxPercentOfDisposable: '50.00',
      effectiveDate: '2024-01-01',
    });
    expect(r.create).toHaveBeenCalled();
    expect(await svc.get('g1')).toEqual(order);
    expect(await svc.listByEmployee('e1')).toHaveLength(1);
    expect(await svc.listActive('e1', '2024-06-01')).toHaveLength(1);
    await svc.update('g1', { fixedAmount: '90.00' });
    await svc.remove('g1');
    expect(r.delete).toHaveBeenCalledWith('g1');
  });

  it('throws when update or remove misses', async () => {
    const svc = new GarnishmentOrderService(
      repo({
        update: jest.fn().mockResolvedValue(null),
        delete: jest.fn().mockResolvedValue(false),
      })
    );
    await expect(svc.update('x', {})).rejects.toBeInstanceOf(
      PayrollDomainError
    );
    await expect(svc.remove('x')).rejects.toBeInstanceOf(PayrollDomainError);
  });
});
