import { GarnishmentService } from '../../../src/services/GarnishmentService';
import { testEmployee } from '../../helpers/testEmployees';
import { PayrollDomainError } from '../../../src/errors/PayrollDomainError';

describe('GarnishmentService', () => {
  const service = new GarnishmentService();

  const taxes = {
    federalIncome: '300.00',
    stateIncome: '100.00',
    localIncome: '0.00',
    socialSecurity: '124.00',
    medicare: '29.00',
    medicareAdditional: '0.00',
  };

  it('blocks garnishments after termination payment date', () => {
    const terminated = {
      ...testEmployee,
      terminationDate: '2024-06-01',
    };
    expect(() =>
      service.process(
        [
          {
            type: 'child_support',
            priority: 1,
            fixedAmount: '100.00',
            percentOfDisposable: null,
          },
        ],
        {
          gross: '2000.00',
          taxes,
          mandatoryDeductions: { section125: '0.00' },
        },
        terminated,
        '2024-06-15'
      )
    ).toThrow(PayrollDomainError);
  });

  it('returns zero withholdings when disposable earnings are zero', () => {
    const result = service.process(
      [
        {
          type: 'child_support',
          priority: 1,
          fixedAmount: '100.00',
          percentOfDisposable: null,
        },
      ],
      {
        gross: '200.00',
        taxes,
        mandatoryDeductions: { section125: '200.00' },
      },
      testEmployee,
      '2024-06-15'
    );
    expect(result.total).toBe('0.00');
    expect(result.lines).toHaveLength(0);
  });

  it('builds remittances with blank case id when missing', () => {
    const result = service.process(
      [
        {
          type: 'child_support',
          priority: 1,
          fixedAmount: '100.00',
          percentOfDisposable: null,
          orderId: 'order-1',
        },
      ],
      {
        gross: '5000.00',
        taxes,
        mandatoryDeductions: { section125: '0.00' },
      },
      testEmployee,
      '2024-06-15'
    );
    expect(result.remittances[0]?.caseId).toBe('');
    expect(result.remittances[0]?.amount).toBe('100.00');
  });
});
