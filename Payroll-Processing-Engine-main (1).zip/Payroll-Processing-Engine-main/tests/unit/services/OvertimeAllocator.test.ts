import { OvertimeAllocator } from '../../../src/services/OvertimeAllocator';
import type { TimeEntry } from '../../../src/models/types';
import { JURISDICTIONS } from '../../../src/data/jurisdictions';

function entry(workDate: string, minutes: number): TimeEntry {
  return {
    id: '1',
    employeeId: 'e1',
    payPeriodId: 'p1',
    workDate,
    clockIn: `${workDate}T09:00:00Z`,
    clockOut: `${workDate}T17:00:00Z`,
    roundedMinutes: minutes,
    entryType: 'regular',
    shiftAssignmentId: null,
    createdAt: '2024-01-01T00:00:00Z',
  };
}

describe('OvertimeAllocator', () => {
  const allocator = new OvertimeAllocator();

  it('keeps 40 hours regular with no OT', () => {
    const entries = [entry('2024-06-03', 40 * 60)];
    const result = allocator.allocateWeekly(entries, '20.00', 'TX');
    expect(result.overtimeMinutes).toBe(0);
    expect(result.regularPay).toBe('800.00');
    expect(result.overtimePay).toBe('0.00');
  });

  it('allocates hours beyond 40 per week at 1.5x', () => {
    const entries = [entry('2024-06-03', 45 * 60)];
    const result = allocator.allocateWeekly(entries, '20.00', 'TX');
    expect(result.regularMinutes).toBe(40 * 60);
    expect(result.overtimeMinutes).toBe(5 * 60);
    expect(result.regularPay).toBe('800.00');
    expect(result.overtimePay).toBe('150.00');
  });

  it('sums multiple days in same work week', () => {
    const entries = [
      entry('2024-06-03', 24 * 60),
      entry('2024-06-04', 24 * 60),
    ];
    const result = allocator.allocateWeekly(entries, '10.00', 'TX');
    expect(result.overtimeMinutes).toBe(8 * 60);
  });

  it('excludes holiday entries from weekly grouping', () => {
    const holiday: TimeEntry = {
      ...entry('2024-06-03', 8 * 60),
      entryType: 'holiday',
    };
    const regular = entry('2024-06-03', 40 * 60);
    const buckets = allocator.groupMinutesByWorkWeek(
      [holiday, regular],
      JURISDICTIONS.DEFAULT
    );
    const totalRegular = [...buckets.values()].reduce(
      (sum, b) => sum + b.regularMinutes,
      0
    );
    expect(totalRegular).toBe(40 * 60);
  });
});
