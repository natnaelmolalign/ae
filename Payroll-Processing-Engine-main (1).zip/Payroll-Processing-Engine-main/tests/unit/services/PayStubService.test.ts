import { PayStubService } from '../../../src/services/PayStubService';
import { PayrollDomainError } from '../../../src/errors/PayrollDomainError';
import { emptyYtd } from '../../../src/utils/ytdUtils';

const taxes = {
  federalIncome: '500.00',
  stateIncome: '100.00',
  localIncome: '25.00',
  socialSecurity: '310.00',
  medicare: '72.50',
  medicareAdditional: '5.00',
};

describe('PayStubService', () => {
  const svc = new PayStubService();
  const ytd = emptyYtd('e1', 2024);

  it('builds stub with equity, tips, HSA, FSA, Roth, and scheduled lines', () => {
    const stub = svc.build(
      'e1',
      'p1',
      '5000.00',
      taxes,
      '200.00',
      '100.00',
      '50.00',
      '30.00',
      '75.00',
      '25.00',
      '0.00',
      ytd,
      false,
      'prior-stub',
      '15.00',
      { rsuVest: '1000.00', nqsoExercise: '500.00', totalEquity: '1500.00' },
      [
        {
          scheduleId: 's1',
          scheduleType: 'cobra_premium',
          label: 'COBRA Premium',
          amount: '40.00',
        },
      ]
    );
    expect(stub.correctsPayStubId).toBe('prior-stub');
    const labels = stub.lines.map((l) => l.label);
    expect(labels).toEqual(
      expect.arrayContaining([
        'RSU Vest',
        'NQSO Exercise',
        'FLSA Tip Credit Make-Up',
        'HSA',
        'FSA',
        'Roth 401(k)',
        'COBRA Premium',
        'Local Income Tax',
      ])
    );
  });

  it('builds minimal stub without optional lines', () => {
    const stub = svc.build(
      'e1',
      'p1',
      '1000.00',
      {
        federalIncome: '100.00',
        stateIncome: '50.00',
        localIncome: '0.00',
        socialSecurity: '62.00',
        medicare: '14.50',
        medicareAdditional: '0.00',
      },
      '0.00',
      '0.00',
      '0.00',
      '0.00',
      '0.00',
      '0.00',
      '0.00',
      ytd,
      false
    );
    expect(stub.lines.some((l) => l.label === 'HSA')).toBe(false);
    expect(stub.correctsPayStubId).toBeNull();
  });

  it('throws when reconciliation check fails', () => {
    const internal = svc as unknown as {
      assertReconciliation: (
        g: string,
        n: string,
        t: string,
        d: string
      ) => void;
    };
    expect(() =>
      internal.assertReconciliation('1000.00', '900.00', '50.00', '40.00')
    ).toThrow(PayrollDomainError);
  });
});
