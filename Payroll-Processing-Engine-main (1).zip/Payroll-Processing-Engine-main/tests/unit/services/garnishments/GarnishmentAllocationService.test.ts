import { GarnishmentAllocationService } from '../../../../src/services/garnishments/GarnishmentAllocationService';

describe('GarnishmentAllocationService', () => {
  const allocator = new GarnishmentAllocationService();
  const disposable = '1000.00';

  it('child support is satisfied before creditor at same numeric priority', () => {
    const result = allocator.allocate(
      [
        {
          type: 'creditor',
          priority: 1,
          fixedAmount: '400.00',
          percentOfDisposable: null,
        },
        {
          type: 'child_support',
          priority: 1,
          fixedAmount: '300.00',
          percentOfDisposable: null,
        },
      ],
      disposable
    );
    expect(result.lines[0].type).toBe('child_support');
    expect(result.lines[0].amount).toBe('300.00');
    expect(result.lines[1].type).toBe('creditor');
    expect(result.lines[1].amount).toBe('175.00');
    expect(result.total).toBe('475.00');
  });

  it('caps creditor at 25% of disposable', () => {
    const result = allocator.allocate(
      [
        {
          type: 'creditor',
          priority: 1,
          fixedAmount: '500.00',
          percentOfDisposable: null,
        },
      ],
      disposable
    );
    expect(result.lines[0].amount).toBe('250.00');
  });

  it('caps student loan at 15% of disposable', () => {
    const result = allocator.allocate(
      [
        {
          type: 'student_loan',
          priority: 1,
          fixedAmount: '500.00',
          percentOfDisposable: null,
        },
      ],
      disposable
    );
    expect(result.lines[0].amount).toBe('150.00');
  });

  it('waterfills: second order only gets remaining disposable', () => {
    const result = allocator.allocate(
      [
        {
          type: 'child_support',
          priority: 1,
          fixedAmount: '600.00',
          percentOfDisposable: null,
        },
        {
          type: 'creditor',
          priority: 2,
          fixedAmount: '600.00',
          percentOfDisposable: null,
        },
      ],
      disposable
    );
    expect(result.lines[0].amount).toBe('500.00');
    expect(result.lines[1].amount).toBe('125.00');
    expect(result.total).toBe('625.00');
  });

  it('total withholdings never exceed disposable earnings', () => {
    const result = allocator.allocate(
      [
        {
          type: 'child_support',
          priority: 1,
          fixedAmount: '800.00',
          percentOfDisposable: null,
        },
        {
          type: 'student_loan',
          priority: 2,
          fixedAmount: '800.00',
          percentOfDisposable: null,
        },
        {
          type: 'creditor',
          priority: 3,
          fixedAmount: '800.00',
          percentOfDisposable: null,
        },
      ],
      disposable
    );
    expect(parseFloat(result.total)).toBeLessThanOrEqual(1000);
  });

  it('allocates zero when disposable already exhausted', () => {
    const result = allocator.allocate(
      [
        {
          type: 'child_support',
          priority: 1,
          fixedAmount: '100.00',
          percentOfDisposable: null,
        },
        {
          type: 'creditor',
          priority: 2,
          fixedAmount: '100.00',
          percentOfDisposable: null,
        },
      ],
      '0.00'
    );
    expect(result.lines.every((l) => l.amount === '0.00')).toBe(true);
  });

  it('uses percent of remaining disposable when configured', () => {
    const result = allocator.allocate(
      [
        {
          type: 'child_support',
          priority: 1,
          fixedAmount: '0.00',
          percentOfDisposable: '0.25',
        },
      ],
      '1000.00'
    );
    expect(result.lines[0].amount).toBe('250.00');
  });
});
