import { DisposableEarningsCalculator } from '../../../../src/services/garnishments/DisposableEarningsCalculator';

describe('DisposableEarningsCalculator', () => {
  const calc = new DisposableEarningsCalculator();

  it('subtracts all taxes and mandatory section 125 from gross', () => {
    const disposable = calc.calculate({
      gross: '3000.00',
      taxes: {
        federalIncome: '400.00',
        stateIncome: '100.00',
        localIncome: '0.00',
        socialSecurity: '186.00',
        medicare: '43.50',
        medicareAdditional: '0.00',
      },
      mandatoryDeductions: { section125: '150.00' },
    });
    expect(disposable).toBe('2120.50');
  });
});
