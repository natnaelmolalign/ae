import { ReportingService } from '../../../src/services/ReportingService';
import { PayrollDomainError } from '../../../src/errors/PayrollDomainError';

describe('ReportingService', () => {
  function mockDb(
    period: Record<string, unknown> | null,
    runs: unknown[] = []
  ) {
    return jest.fn((table: string) => {
      if (table === 'pay_periods') {
        return {
          where: jest.fn().mockReturnThis(),
          first: jest.fn().mockResolvedValue(period),
        };
      }
      if (table === 'payroll_runs' || table === 'payroll_runs as pr') {
        return {
          join: jest.fn().mockReturnThis(),
          where: jest.fn().mockReturnThis(),
          select: jest.fn().mockResolvedValue(runs),
        };
      }
      if (table === 'pay_stubs') {
        return {
          where: jest.fn().mockReturnThis(),
          first: jest.fn().mockResolvedValue({
            id: 'stub-1',
            employee_id: 'e1',
            pay_period_id: 'p1',
            gross_pay: '5000.00',
            net_pay: '3817.50',
            lines: JSON.stringify([
              {
                category: 'earnings',
                label: 'Gross Pay',
                current: '5000.00',
                ytd: '5000.00',
              },
              {
                category: 'tax',
                label: 'Federal Income Tax',
                current: '500.00',
                ytd: '500.00',
              },
              {
                category: 'net',
                label: 'Net Pay',
                current: '3817.50',
                ytd: '3817.50',
              },
            ]),
            is_correction: false,
            created_at: new Date(),
          }),
        };
      }
      return {};
    });
  }

  it('throws when pay period not found for reports', async () => {
    const svc = new ReportingService(mockDb(null) as never);
    await expect(svc.tipRegister('p1', 'co')).rejects.toBeInstanceOf(
      PayrollDomainError
    );
    await expect(svc.payrollRegister('p1', 'co')).rejects.toBeInstanceOf(
      PayrollDomainError
    );
    await expect(svc.glExportForPeriod('p1', 'co')).rejects.toBeInstanceOf(
      PayrollDomainError
    );
  });

  it('glExportForPeriod loads runs and exports', async () => {
    const period = { id: 'p1', company_id: 'co' };
    const runs = [
      {
        id: 'run-1',
        pay_stub_id: 'stub-1',
        taxes: {
          federalIncome: '500.00',
          stateIncome: '100.00',
          localIncome: '0.00',
          socialSecurity: '310.00',
          medicare: '72.50',
          medicareAdditional: '0.00',
        },
        employer_contributions: {
          ss: '310.00',
          medicare: '72.50',
          match401k: '0.00',
        },
      },
    ];
    const allocationRepo = {
      findSegmentsForRuns: jest.fn().mockResolvedValue(new Map()),
      insertMany: jest.fn(),
      findByPayrollRun: jest.fn(),
    };
    const svc = new ReportingService(
      mockDb(period, runs) as never,
      allocationRepo as never
    );
    const out = await svc.glExportForPeriod('p1', 'co');
    expect(out.exports).toHaveLength(1);
    expect(typeof out.csv).toBe('string');
  });

  it('uses default allocation repo when omitted', async () => {
    const period = { id: 'p1', company_id: 'co' };
    const svc = new ReportingService(mockDb(period, []) as never);
    await expect(svc.laborCost('p1', 'co')).resolves.toBeDefined();
  });

  it('default allocation repo no-op methods resolve', async () => {
    const period = { id: 'p1', company_id: 'co' };
    const svc = new ReportingService(mockDb(period, []) as never);
    const internal = svc as unknown as {
      laborCostReport: {
        allocationRepo: {
          insertMany: (trx: unknown, rows: unknown[]) => Promise<void>;
          findByPayrollRun: (id: string) => Promise<unknown[]>;
        };
      };
    };
    await internal.laborCostReport.allocationRepo.insertMany({}, []);
    await expect(
      internal.laborCostReport.allocationRepo.findByPayrollRun('run-1')
    ).resolves.toEqual([]);
  });

  it('glExportForPeriod without allocation repo uses empty segment map', async () => {
    const period = { id: 'p1', company_id: 'co' };
    const runs = [
      {
        id: 'run-1',
        pay_stub_id: 'stub-1',
        taxes: {
          federalIncome: '500.00',
          stateIncome: '100.00',
          localIncome: '0.00',
          socialSecurity: '310.00',
          medicare: '72.50',
          medicareAdditional: '0.00',
        },
        employer_contributions: {
          ss: '310.00',
          medicare: '72.50',
          match401k: '0.00',
        },
      },
    ];
    const svc = new ReportingService(mockDb(period, runs) as never);
    const out = await svc.glExportForPeriod('p1', 'co');
    expect(out.exports).toHaveLength(1);
  });

  it('loadRunResult throws when pay stub missing', async () => {
    const period = { id: 'p1', company_id: 'co' };
    const db = jest.fn((table: string) => {
      if (table === 'pay_periods') {
        return {
          where: jest.fn().mockReturnThis(),
          first: jest.fn().mockResolvedValue(period),
        };
      }
      if (table === 'payroll_runs') {
        return {
          join: jest.fn().mockReturnThis(),
          where: jest.fn().mockReturnThis(),
          select: jest.fn().mockResolvedValue([
            {
              id: 'r1',
              pay_stub_id: 'missing-stub',
              taxes: '{}',
              employer_contributions: '{}',
            },
          ]),
        };
      }
      if (table === 'pay_stubs') {
        return {
          where: jest.fn().mockReturnThis(),
          first: jest.fn().mockResolvedValue(null),
        };
      }
      return {};
    });
    const svc = new ReportingService(
      db as never,
      {
        findSegmentsForRuns: jest.fn().mockResolvedValue(new Map()),
        insertMany: jest.fn(),
        findByPayrollRun: jest.fn(),
      } as never
    );
    await expect(svc.glExportForPeriod('p1', 'co')).rejects.toBeInstanceOf(
      PayrollDomainError
    );
  });

  it('parses pay stub lines when already stored as objects', async () => {
    const period = { id: 'p1', company_id: 'co' };
    const runs = [
      {
        id: 'run-1',
        pay_stub_id: 'stub-1',
        taxes: {
          federalIncome: '500.00',
          stateIncome: '100.00',
          localIncome: '0.00',
          socialSecurity: '310.00',
          medicare: '72.50',
          medicareAdditional: '0.00',
        },
        employer_contributions: {
          ss: '310.00',
          medicare: '72.50',
          match401k: '0.00',
        },
      },
    ];
    const db = jest.fn((table: string) => {
      if (table === 'pay_periods') {
        return {
          where: jest.fn().mockReturnThis(),
          first: jest.fn().mockResolvedValue(period),
        };
      }
      if (table === 'payroll_runs' || table === 'payroll_runs as pr') {
        return {
          join: jest.fn().mockReturnThis(),
          where: jest.fn().mockReturnThis(),
          select: jest.fn().mockResolvedValue(runs),
        };
      }
      if (table === 'pay_stubs') {
        return {
          where: jest.fn().mockReturnThis(),
          first: jest.fn().mockResolvedValue({
            id: 'stub-1',
            employee_id: 'e1',
            pay_period_id: 'p1',
            gross_pay: '5000.00',
            net_pay: '3817.50',
            lines: [
              {
                category: 'net',
                label: 'Net Pay',
                current: '3817.50',
                ytd: '3817.50',
              },
            ],
            is_correction: false,
            created_at: new Date(),
          }),
        };
      }
      return {};
    });
    const svc = new ReportingService(db as never);
    const out = await svc.glExportForPeriod('p1', 'co');
    expect(out.exports[0]?.lines.some((l) => l.accountCode === '2100')).toBe(
      true
    );
  });
});
