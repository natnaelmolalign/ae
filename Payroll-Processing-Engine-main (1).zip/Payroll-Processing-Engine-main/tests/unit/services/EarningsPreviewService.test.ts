import { EarningsPreviewService } from '../../../src/services/EarningsPreviewService';
import { PayrollDomainError } from '../../../src/errors/PayrollDomainError';
import { testEmployee } from '../../helpers/testEmployees';
import type { EarningsLine, PayPeriod } from '../../../src/models/types';

const payPeriod: PayPeriod = {
  id: '2024-monthly-1',
  startDate: '2024-01-01',
  endDate: '2024-01-31',
  paymentDate: '2024-01-31',
  frequency: 'monthly',
  year: 2024,
  periodIndex: 1,
};

const previewInput = {
  employeeId: testEmployee.id,
  payPeriodId: payPeriod.id,
  year: 2024,
  frequency: 'monthly' as const,
};

describe('EarningsPreviewService', () => {
  const previewResult = {
    payStub: { id: 's1', netPay: '100', grossPay: '200' },
    taxes: {},
    employerContributions: { ss: '0', medicare: '0', match401k: '0' },
  };

  const payrollRunService = {
    preview: jest.fn().mockResolvedValue(previewResult),
  };
  const timeEntryService = {
    listForPayPeriod: jest.fn().mockResolvedValue([]),
  };

  it('preview merges earnings lines from explicit earnings', async () => {
    const svc = new EarningsPreviewService(
      payrollRunService as never,
      timeEntryService as never
    );
    const result = await svc.preview(testEmployee, payPeriod, {
      ...previewInput,
      earnings: [{ type: 'regular', amount: '5000.00' }],
    });
    expect(result.earningsLines).toHaveLength(1);
    expect(payrollRunService.preview).toHaveBeenCalled();
  });

  it('resolveEarningsLines rejects empty input', async () => {
    const svc = new EarningsPreviewService(
      payrollRunService as never,
      timeEntryService as never
    );
    await expect(
      svc.resolveEarningsLines(testEmployee, payPeriod, previewInput)
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('requires hourlyRate when useTimeEntries', async () => {
    const svc = new EarningsPreviewService(
      payrollRunService as never,
      timeEntryService as never
    );
    await expect(
      svc.resolveEarningsLines(testEmployee, payPeriod, {
        ...previewInput,
        useTimeEntries: true,
      })
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('throws when hourly feature disabled', async () => {
    const prev = process.env.FEATURE_HOURLY_EARNINGS;
    process.env.FEATURE_HOURLY_EARNINGS = 'false';
    jest.resetModules();
    const {
      EarningsPreviewService: Svc,
    } = require('../../../src/services/EarningsPreviewService');
    const svc = new Svc(payrollRunService as never, timeEntryService as never);
    await expect(
      svc.resolveEarningsLines(testEmployee, payPeriod, {
        ...previewInput,
        useTimeEntries: true,
        hourlyRate: '20.00',
      })
    ).rejects.toThrow('Hourly earnings feature is disabled');
    process.env.FEATURE_HOURLY_EARNINGS = prev;
    jest.resetModules();
  });

  it('adds positive imputed income lines', async () => {
    const svc = new EarningsPreviewService(
      payrollRunService as never,
      timeEntryService as never
    );
    const lines = await svc.resolveEarningsLines(testEmployee, payPeriod, {
      ...previewInput,
      earnings: [{ type: 'regular', amount: '1000.00' }],
      imputedIncome: [
        {
          type: 'group_life',
          coverageAmount: '60000.00',
          employerPaidPremium: '10.00',
        },
      ],
    });
    expect(lines.length).toBeGreaterThan(1);
  });

  it('skips zero or negative imputed income amounts', async () => {
    const svc = new EarningsPreviewService(
      payrollRunService as never,
      timeEntryService as never
    );
    const lines = await svc.resolveEarningsLines(testEmployee, payPeriod, {
      ...previewInput,
      earnings: [{ type: 'regular', amount: '1000.00' }],
      imputedIncome: [
        {
          type: 'group_life',
          coverageAmount: '1000.00',
          employerPaidPremium: '0.00',
        },
      ],
    });
    expect(lines).toHaveLength(1);
  });

  it('resolves hourly earnings from time entries with approval service', async () => {
    const timeApprovalService = {
      assertPayrollReady: jest.fn().mockResolvedValue(undefined),
      filterPayrollEntries: jest
        .fn()
        .mockImplementation((_e, _c, _p, entries) => Promise.resolve(entries)),
      listApprovedWithShifts: jest.fn().mockResolvedValue([]),
    };
    timeEntryService.listForPayPeriod.mockResolvedValue([
      {
        id: 'te-1',
        employeeId: testEmployee.id,
        payPeriodId: payPeriod.id,
        workDate: '2024-01-15',
        clockIn: '2024-01-15T08:00:00.000Z',
        clockOut: '2024-01-15T16:00:00.000Z',
        roundedMinutes: 480,
        shiftAssignmentId: null,
        entryType: 'regular',
        createdAt: '2024-01-15T00:00:00.000Z',
      },
    ]);
    const svc = new EarningsPreviewService(
      payrollRunService as never,
      timeEntryService as never,
      timeApprovalService as never
    );
    const lines = await svc.resolveEarningsLines(testEmployee, payPeriod, {
      ...previewInput,
      useTimeEntries: true,
      hourlyRate: '25.00',
    });
    expect(lines.length).toBeGreaterThan(0);
    expect(timeApprovalService.assertPayrollReady).toHaveBeenCalled();
    expect(timeApprovalService.filterPayrollEntries).toHaveBeenCalled();
  });

  it('adds CA meal penalty lines when feature enabled', async () => {
    const prevMeal = process.env.FEATURE_CA_MEAL_PENALTY;
    process.env.FEATURE_CA_MEAL_PENALTY = 'true';
    jest.resetModules();
    const {
      EarningsPreviewService: Svc,
    } = require('../../../src/services/EarningsPreviewService');
    const timeApprovalService = {
      assertPayrollReady: jest.fn().mockResolvedValue(undefined),
      filterPayrollEntries: jest
        .fn()
        .mockImplementation((_e, _c, _p, entries) => Promise.resolve(entries)),
      listApprovedWithShifts: jest.fn().mockResolvedValue([
        {
          assignment: {
            scheduledMinutes: 360,
          },
          shift: { breakMinutes: 0 },
        },
      ]),
    };
    timeEntryService.listForPayPeriod.mockResolvedValue([
      {
        id: 'te-1',
        employeeId: testEmployee.id,
        payPeriodId: payPeriod.id,
        workDate: '2024-01-15',
        clockIn: '2024-01-15T08:00:00.000Z',
        clockOut: '2024-01-15T14:00:00.000Z',
        roundedMinutes: 360,
        shiftAssignmentId: 'assign-1',
        entryType: 'regular',
        createdAt: '2024-01-15T00:00:00.000Z',
      },
    ]);
    const svc = new Svc(
      payrollRunService as never,
      timeEntryService as never,
      timeApprovalService as never
    );
    const lines = await svc.resolveEarningsLines(
      { ...testEmployee, stateCode: 'CA' },
      payPeriod,
      {
        ...previewInput,
        useTimeEntries: true,
        hourlyRate: '22.50',
      }
    );
    expect(
      lines.some((l: EarningsLine) => l.amount === '22.50' && l.hours === 1)
    ).toBe(true);
    process.env.FEATURE_CA_MEAL_PENALTY = prevMeal;
    jest.resetModules();
  });

  it('skips meal penalty when calculator returns null', async () => {
    const prevMeal = process.env.FEATURE_CA_MEAL_PENALTY;
    process.env.FEATURE_CA_MEAL_PENALTY = 'true';
    jest.resetModules();
    const {
      EarningsPreviewService: Svc,
    } = require('../../../src/services/EarningsPreviewService');
    const timeApprovalService = {
      assertPayrollReady: jest.fn().mockResolvedValue(undefined),
      filterPayrollEntries: jest
        .fn()
        .mockImplementation((_e, _c, _p, entries) => Promise.resolve(entries)),
      listApprovedWithShifts: jest.fn().mockResolvedValue([
        {
          assignment: { scheduledMinutes: 240 },
          shift: { breakMinutes: 30 },
        },
      ]),
    };
    timeEntryService.listForPayPeriod.mockResolvedValue([
      {
        id: 'te-1',
        employeeId: testEmployee.id,
        payPeriodId: payPeriod.id,
        workDate: '2024-01-15',
        clockIn: '2024-01-15T08:00:00.000Z',
        clockOut: '2024-01-15T12:00:00.000Z',
        roundedMinutes: 240,
        shiftAssignmentId: 'assign-1',
        entryType: 'regular',
        createdAt: '2024-01-15T00:00:00.000Z',
      },
    ]);
    const svc = new Svc(
      payrollRunService as never,
      timeEntryService as never,
      timeApprovalService as never
    );
    const lines = await svc.resolveEarningsLines(
      { ...testEmployee, stateCode: 'CA' },
      payPeriod,
      {
        ...previewInput,
        useTimeEntries: true,
        hourlyRate: '22.50',
      }
    );
    expect(lines.every((l: EarningsLine) => l.hours !== 1)).toBe(true);
    process.env.FEATURE_CA_MEAL_PENALTY = prevMeal;
    jest.resetModules();
  });

  it('mealPenaltyLines returns empty without time approval service', async () => {
    const svc = new EarningsPreviewService(
      payrollRunService as never,
      timeEntryService as never
    );
    const lines = await (
      svc as unknown as {
        mealPenaltyLines: (
          employee: typeof testEmployee,
          payPeriod: PayPeriod,
          hourlyRate: string
        ) => Promise<EarningsLine[]>;
      }
    ).mealPenaltyLines(testEmployee, payPeriod, '20.00');
    expect(lines).toEqual([]);
  });

  it('mealPenaltyLines skips penalties when feature enabled without approval service in preview', async () => {
    const prevMeal = process.env.FEATURE_CA_MEAL_PENALTY;
    process.env.FEATURE_CA_MEAL_PENALTY = 'true';
    jest.resetModules();
    const {
      EarningsPreviewService: Svc,
    } = require('../../../src/services/EarningsPreviewService');
    timeEntryService.listForPayPeriod.mockResolvedValue([
      {
        id: 'te-1',
        employeeId: testEmployee.id,
        payPeriodId: payPeriod.id,
        workDate: '2024-01-15',
        clockIn: '2024-01-15T08:00:00.000Z',
        clockOut: '2024-01-15T14:00:00.000Z',
        roundedMinutes: 360,
        shiftAssignmentId: null,
        entryType: 'regular',
        createdAt: '2024-01-15T00:00:00.000Z',
      },
    ]);
    const svc = new Svc(payrollRunService as never, timeEntryService as never);
    const lines = await svc.resolveEarningsLines(testEmployee, payPeriod, {
      ...previewInput,
      useTimeEntries: true,
      hourlyRate: '20.00',
    });
    expect(lines.every((l: EarningsLine) => l.hours !== 1)).toBe(true);
    process.env.FEATURE_CA_MEAL_PENALTY = prevMeal;
    jest.resetModules();
  });
});
