import { OpenEnrollmentService } from '../../../../src/services/benefits/OpenEnrollmentService';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../../../src/errors/PayrollDomainError';
import type { BenefitEnrollment } from '../../../../src/models/BenefitEnrollment';
import type {
  EligibilityRule,
  EnrollmentWindow,
  LifeEvent,
} from '../../../../src/models/BenefitsLifecycle';
import type { Employee } from '../../../../src/models/types';
import type {
  EligibilityRuleRepository,
  EnrollmentWindowRepository,
  LifeEventRepository,
} from '../../../../src/repositories/interfaces';
import type { BenefitEnrollmentService } from '../../../../src/services/BenefitEnrollmentService';
import type { DeductionScheduleService } from '../../../../src/services/DeductionScheduleService';

describe('OpenEnrollmentService', () => {
  const companyId = 'co-1';
  const futureDate = '2099-07-01';
  const pastDate = '2000-01-01';

  const employee: Employee = {
    id: 'e1',
    companyId,
    firstName: 'Jane',
    lastName: 'Doe',
    employmentType: 'full_time_salaried',
    payFrequency: 'monthly',
    baseCompensation: '5000.00',
    hireDate: '2020-01-01',
    terminationDate: null,
    filingStatus: 'single',
    stateCode: 'TX',
    w4ExtraWithholding: '0.00',
    w4DependentsCredit: '0.00',
    w4OtherDeductions: '0.00',
    w4OtherIncome: '0.00',
    w4MultipleJobs: false,
    localMunicipalityCode: null,
    equityWithholdingMethod: 'supplemental_flat',
    tinLastFour: null,
    createdAt: '2020-01-01T00:00:00.000Z',
  };

  const window: EnrollmentWindow = {
    id: 'win-1',
    companyId,
    code: 'OE2024',
    name: 'Open Enrollment',
    planYear: 2024,
    startDate: '2024-01-01',
    endDate: '2024-12-31',
    status: 'open',
    allowedBenefitTypes: ['401k_pretax'],
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  const rule: EligibilityRule = {
    id: 'rule-1',
    companyId,
    benefitType: '401k_pretax',
    employmentTypes: ['full_time_salaried'],
    minTenureDays: 30,
    requiresEnrollmentWindow: true,
    isActive: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  const lifeEvent: LifeEvent = {
    id: 'le-1',
    companyId,
    employeeId: employee.id,
    eventType: 'marriage',
    eventDate: '2024-06-01',
    coverageEffectiveDate: futureDate,
    status: 'approved',
    approvedAt: '2024-06-02T00:00:00.000Z',
    approvedBy: 'hr-1',
    cobraScheduleId: null,
    notes: null,
    createdAt: '2024-06-01T00:00:00.000Z',
    updatedAt: '2024-06-02T00:00:00.000Z',
  };

  const enrollment: BenefitEnrollment = {
    id: 'ben-1',
    employeeId: employee.id,
    type: '401k_pretax',
    amountPerPeriod: '200.00',
    percentOfGross: null,
    annualLimit: null,
    effectiveDate: futureDate,
    endDate: null,
    hsaCoverage: null,
    catchUpEligible: false,
    priority: 100,
    lifeEventId: null,
    enrollmentWindowId: window.id,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  function windowRepo(
    overrides: Partial<EnrollmentWindowRepository> = {}
  ): EnrollmentWindowRepository {
    return {
      create: jest.fn().mockResolvedValue(window),
      findById: jest.fn().mockResolvedValue(window),
      listByCompany: jest.fn().mockResolvedValue([window]),
      findOpenForDate: jest.fn().mockResolvedValue(window),
      updateStatus: jest.fn().mockResolvedValue(window),
      ...overrides,
    } as unknown as EnrollmentWindowRepository;
  }

  function ruleRepo(
    overrides: Partial<EligibilityRuleRepository> = {}
  ): EligibilityRuleRepository {
    return {
      create: jest.fn().mockResolvedValue(rule),
      findActiveForType: jest.fn().mockResolvedValue(rule),
      listByCompany: jest.fn().mockResolvedValue([rule]),
      ...overrides,
    } as unknown as EligibilityRuleRepository;
  }

  function lifeRepo(
    overrides: Partial<LifeEventRepository> = {}
  ): LifeEventRepository {
    return {
      create: jest.fn().mockResolvedValue(lifeEvent),
      findById: jest.fn().mockResolvedValue(lifeEvent),
      listByEmployee: jest.fn().mockResolvedValue([lifeEvent]),
      updateStatus: jest.fn().mockResolvedValue(lifeEvent),
      ...overrides,
    } as unknown as LifeEventRepository;
  }

  function enrollmentSvc(
    overrides: Partial<BenefitEnrollmentService> = {}
  ): BenefitEnrollmentService {
    return {
      create: jest.fn().mockResolvedValue(enrollment),
      get: jest.fn(),
      listByEmployee: jest.fn(),
      listActive: jest.fn(),
      update: jest.fn(),
      remove: jest.fn(),
      ...overrides,
    } as unknown as BenefitEnrollmentService;
  }

  function scheduleSvc(
    overrides: Partial<DeductionScheduleService> = {}
  ): DeductionScheduleService {
    return {
      create: jest.fn().mockResolvedValue({ id: 'sched-1' }),
      get: jest.fn(),
      listByEmployee: jest.fn(),
      update: jest.fn(),
      remove: jest.fn(),
      ...overrides,
    } as unknown as DeductionScheduleService;
  }

  it('delegates window and eligibility rule CRUD', async () => {
    const w = windowRepo();
    const r = ruleRepo();
    const svc = new OpenEnrollmentService(w, r, lifeRepo(), enrollmentSvc());

    await svc.createWindow({
      companyId,
      code: 'OE2024',
      name: 'Open Enrollment',
      planYear: 2024,
      startDate: '2024-01-01',
      endDate: '2024-12-31',
      allowedBenefitTypes: ['401k_pretax'],
    });
    expect(w.create).toHaveBeenCalled();
    expect(await svc.listWindows(companyId)).toHaveLength(1);
    await svc.createEligibilityRule({
      companyId,
      benefitType: '401k_pretax',
    });
    expect(r.create).toHaveBeenCalled();
    expect(await svc.listEligibilityRules(companyId)).toHaveLength(1);
  });

  it('closes window or throws when missing', async () => {
    const svc = new OpenEnrollmentService(
      windowRepo({ updateStatus: jest.fn().mockResolvedValue(null) }),
      ruleRepo(),
      lifeRepo(),
      enrollmentSvc()
    );
    await expect(svc.closeWindow('missing', companyId)).rejects.toBeInstanceOf(
      PayrollDomainError
    );

    const w = windowRepo();
    const closed = await new OpenEnrollmentService(
      w,
      ruleRepo(),
      lifeRepo(),
      enrollmentSvc()
    ).closeWindow(window.id, companyId);
    expect(closed).toEqual(window);
    expect(w.updateStatus).toHaveBeenCalledWith(window.id, companyId, 'closed');
  });

  it('records and lists life events with forward effective date validation', async () => {
    const l = lifeRepo();
    const svc = new OpenEnrollmentService(
      windowRepo(),
      ruleRepo(),
      l,
      enrollmentSvc()
    );

    await svc.recordLifeEvent({
      companyId,
      employeeId: employee.id,
      eventType: 'marriage',
      eventDate: '2024-06-01',
      coverageEffectiveDate: futureDate,
    });
    expect(l.create).toHaveBeenCalled();
    expect(await svc.listLifeEvents(employee.id, companyId)).toHaveLength(1);

    expect(() =>
      svc.recordLifeEvent({
        companyId,
        employeeId: employee.id,
        eventType: 'marriage',
        eventDate: '2024-06-01',
        coverageEffectiveDate: '2024-05-01',
      })
    ).toThrow(PayrollDomainError);
  });

  it('approves life events with validation and COBRA schedule creation', async () => {
    const lossEvent: LifeEvent = {
      ...lifeEvent,
      id: 'le-loss',
      eventType: 'loss_of_coverage',
      status: 'pending',
      coverageEffectiveDate: futureDate,
    };

    const svcNoSchedule = new OpenEnrollmentService(
      windowRepo(),
      ruleRepo(),
      lifeRepo({ findById: jest.fn().mockResolvedValue(lossEvent) }),
      enrollmentSvc()
    );
    await expect(
      svcNoSchedule.approveLifeEvent('le-loss', companyId, {
        approvedBy: 'hr-1',
        cobraPremiumPerPeriod: '500.00',
        cobraStartDate: futureDate,
      })
    ).rejects.toMatchObject({ code: PayrollErrorCode.INVALID_INPUT });

    const sched = scheduleSvc();
    const svcMissingCobra = new OpenEnrollmentService(
      windowRepo(),
      ruleRepo(),
      lifeRepo({ findById: jest.fn().mockResolvedValue(lossEvent) }),
      enrollmentSvc(),
      sched
    );
    await expect(
      svcMissingCobra.approveLifeEvent('le-loss', companyId, {
        approvedBy: 'hr-1',
      })
    ).rejects.toMatchObject({ code: PayrollErrorCode.INVALID_INPUT });

    const l = lifeRepo({
      findById: jest.fn().mockResolvedValue(lossEvent),
      updateStatus: jest.fn().mockResolvedValue({
        ...lossEvent,
        status: 'approved',
        cobraScheduleId: 'sched-1',
      }),
    });
    const svc = new OpenEnrollmentService(
      windowRepo(),
      ruleRepo(),
      l,
      enrollmentSvc(),
      sched
    );
    const approved = await svc.approveLifeEvent('le-loss', companyId, {
      approvedBy: 'hr-1',
      cobraPremiumPerPeriod: '500.00',
      cobraStartDate: futureDate,
    });
    expect(sched.create).toHaveBeenCalled();
    expect(approved.cobraScheduleId).toBe('sched-1');
  });

  it('rejects approve when life event is missing, not pending, or update fails', async () => {
    const pending: LifeEvent = { ...lifeEvent, status: 'pending' };

    await expect(
      new OpenEnrollmentService(
        windowRepo(),
        ruleRepo(),
        lifeRepo({ findById: jest.fn().mockResolvedValue(null) }),
        enrollmentSvc()
      ).approveLifeEvent('missing', companyId, { approvedBy: 'hr-1' })
    ).rejects.toBeInstanceOf(PayrollDomainError);

    await expect(
      new OpenEnrollmentService(
        windowRepo(),
        ruleRepo(),
        lifeRepo({ findById: jest.fn().mockResolvedValue(lifeEvent) }),
        enrollmentSvc()
      ).approveLifeEvent('le-1', companyId, { approvedBy: 'hr-1' })
    ).rejects.toMatchObject({ code: PayrollErrorCode.INVALID_INPUT });

    await expect(
      new OpenEnrollmentService(
        windowRepo(),
        ruleRepo(),
        lifeRepo({
          findById: jest.fn().mockResolvedValue(pending),
          updateStatus: jest.fn().mockResolvedValue(null),
        }),
        enrollmentSvc()
      ).approveLifeEvent('le-1', companyId, { approvedBy: 'hr-1' })
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('rejects life events and throws when update misses', async () => {
    const svc = new OpenEnrollmentService(
      windowRepo(),
      ruleRepo(),
      lifeRepo({ updateStatus: jest.fn().mockResolvedValue(null) }),
      enrollmentSvc()
    );
    await expect(
      svc.rejectLifeEvent('missing', companyId, 'hr-1')
    ).rejects.toBeInstanceOf(PayrollDomainError);

    const l = lifeRepo();
    const rejected = await new OpenEnrollmentService(
      windowRepo(),
      ruleRepo(),
      l,
      enrollmentSvc()
    ).rejectLifeEvent('le-1', companyId, 'hr-1');
    expect(rejected).toEqual(lifeEvent);
    expect(l.updateStatus).toHaveBeenCalledWith(
      'le-1',
      companyId,
      'rejected',
      expect.objectContaining({ approvedBy: 'hr-1' })
    );
  });

  it('elects benefit via prepareEnrollment and enrollment service', async () => {
    const enroll = enrollmentSvc();
    const svc = new OpenEnrollmentService(
      windowRepo(),
      ruleRepo(),
      lifeRepo(),
      enroll
    );
    const result = await svc.electBenefit(employee, {
      companyId,
      employeeId: employee.id,
      type: '401k_pretax',
      amountPerPeriod: '200.00',
      effectiveDate: futureDate,
    });
    expect(enroll.create).toHaveBeenCalled();
    expect(result).toEqual(enrollment);
  });

  it('prepareEnrollment rejects retroactive effective dates', async () => {
    const svc = new OpenEnrollmentService(
      windowRepo(),
      ruleRepo(),
      lifeRepo(),
      enrollmentSvc()
    );
    await expect(
      svc.prepareEnrollment(employee, {
        companyId,
        employeeId: employee.id,
        type: '401k_pretax',
        amountPerPeriod: '200.00',
        effectiveDate: pastDate,
      })
    ).rejects.toMatchObject({
      code: PayrollErrorCode.RETROACTIVE_PRETAX_NOT_ALLOWED,
    });
  });

  it('prepareEnrollment enforces employment type and tenure rules', async () => {
    const svc = new OpenEnrollmentService(
      windowRepo(),
      ruleRepo({
        findActiveForType: jest.fn().mockResolvedValue({
          ...rule,
          employmentTypes: ['part_time'],
        }),
      }),
      lifeRepo(),
      enrollmentSvc()
    );
    await expect(
      svc.prepareEnrollment(employee, {
        companyId,
        employeeId: employee.id,
        type: '401k_pretax',
        amountPerPeriod: '200.00',
        effectiveDate: futureDate,
      })
    ).rejects.toMatchObject({ code: PayrollErrorCode.INELIGIBLE_FOR_BENEFIT });

    const svcTenure = new OpenEnrollmentService(
      windowRepo(),
      ruleRepo({
        findActiveForType: jest.fn().mockResolvedValue({
          ...rule,
          minTenureDays: 10_000,
        }),
      }),
      lifeRepo(),
      enrollmentSvc()
    );
    await expect(
      svcTenure.prepareEnrollment(
        { ...employee, hireDate: '2099-06-01' },
        {
          companyId,
          employeeId: employee.id,
          type: '401k_pretax',
          amountPerPeriod: '200.00',
          effectiveDate: futureDate,
        }
      )
    ).rejects.toMatchObject({ code: PayrollErrorCode.INELIGIBLE_FOR_BENEFIT });
  });

  it('prepareEnrollment validates life event linkage', async () => {
    const baseInput = {
      companyId,
      employeeId: employee.id,
      type: '401k_pretax' as const,
      amountPerPeriod: '200.00',
      effectiveDate: futureDate,
      lifeEventId: 'le-1',
    };

    await expect(
      new OpenEnrollmentService(
        windowRepo(),
        ruleRepo(),
        lifeRepo({ findById: jest.fn().mockResolvedValue(null) }),
        enrollmentSvc()
      ).prepareEnrollment(employee, baseInput)
    ).rejects.toBeInstanceOf(PayrollDomainError);

    await expect(
      new OpenEnrollmentService(
        windowRepo(),
        ruleRepo(),
        lifeRepo({
          findById: jest.fn().mockResolvedValue({
            ...lifeEvent,
            employeeId: 'other',
          }),
        }),
        enrollmentSvc()
      ).prepareEnrollment(employee, baseInput)
    ).rejects.toBeInstanceOf(PayrollDomainError);

    await expect(
      new OpenEnrollmentService(
        windowRepo(),
        ruleRepo(),
        lifeRepo({
          findById: jest.fn().mockResolvedValue({
            ...lifeEvent,
            status: 'pending',
          }),
        }),
        enrollmentSvc()
      ).prepareEnrollment(employee, baseInput)
    ).rejects.toMatchObject({ code: PayrollErrorCode.LIFE_EVENT_NOT_APPROVED });

    await expect(
      new OpenEnrollmentService(
        windowRepo(),
        ruleRepo(),
        lifeRepo(),
        enrollmentSvc()
      ).prepareEnrollment(employee, {
        ...baseInput,
        effectiveDate: '2099-08-01',
      })
    ).rejects.toMatchObject({ code: PayrollErrorCode.INVALID_INPUT });
  });

  it('prepareEnrollment requires open window when no life event', async () => {
    await expect(
      new OpenEnrollmentService(
        windowRepo({ findOpenForDate: jest.fn().mockResolvedValue(null) }),
        ruleRepo(),
        lifeRepo(),
        enrollmentSvc()
      ).prepareEnrollment(employee, {
        companyId,
        employeeId: employee.id,
        type: '401k_pretax',
        amountPerPeriod: '200.00',
        effectiveDate: futureDate,
      })
    ).rejects.toMatchObject({
      code: PayrollErrorCode.ENROLLMENT_WINDOW_CLOSED,
    });

    const prepared = await new OpenEnrollmentService(
      windowRepo(),
      ruleRepo(),
      lifeRepo(),
      enrollmentSvc()
    ).prepareEnrollment(employee, {
      companyId,
      employeeId: employee.id,
      type: '401k_pretax',
      amountPerPeriod: '200.00',
      effectiveDate: futureDate,
    });
    expect(prepared.enrollmentWindowId).toBe(window.id);
  });

  it('prepareEnrollment skips window when rule disables requirement', async () => {
    const prepared = await new OpenEnrollmentService(
      windowRepo({ findOpenForDate: jest.fn().mockResolvedValue(null) }),
      ruleRepo({
        findActiveForType: jest.fn().mockResolvedValue({
          ...rule,
          requiresEnrollmentWindow: false,
        }),
      }),
      lifeRepo(),
      enrollmentSvc()
    ).prepareEnrollment(employee, {
      companyId,
      employeeId: employee.id,
      type: '401k_pretax',
      amountPerPeriod: '200.00',
      effectiveDate: futureDate,
    });
    expect(prepared.enrollmentWindowId).toBeNull();
  });

  it('prepareEnrollment skips employment type check when rule has no types', async () => {
    const prepared = await new OpenEnrollmentService(
      windowRepo(),
      ruleRepo({
        findActiveForType: jest.fn().mockResolvedValue({
          ...rule,
          employmentTypes: null,
        }),
      }),
      lifeRepo(),
      enrollmentSvc()
    ).prepareEnrollment(employee, {
      companyId,
      employeeId: employee.id,
      type: '401k_pretax',
      amountPerPeriod: '200.00',
      effectiveDate: futureDate,
    });
    expect(prepared.enrollmentWindowId).toBe(window.id);
  });

  it('prepareEnrollment prorates HSA annual limit for mid-year life events', async () => {
    jest.useFakeTimers();
    jest.setSystemTime(new Date('2026-01-15T12:00:00.000Z'));
    const hsaDate = '2026-03-15';
    const hsaEvent: LifeEvent = {
      ...lifeEvent,
      coverageEffectiveDate: hsaDate,
    };
    try {
      const prepared = await new OpenEnrollmentService(
        windowRepo(),
        ruleRepo({ findActiveForType: jest.fn().mockResolvedValue(null) }),
        lifeRepo({ findById: jest.fn().mockResolvedValue(hsaEvent) }),
        enrollmentSvc()
      ).prepareEnrollment(employee, {
        companyId,
        employeeId: employee.id,
        type: 'hsa',
        amountPerPeriod: '100.00',
        effectiveDate: hsaDate,
        hsaCoverage: 'individual',
        lifeEventId: hsaEvent.id,
        annualLimit: '4150.00',
      });
      expect(prepared.annualLimit).not.toBe('4150.00');
      expect(prepared.lifeEventId).toBe(hsaEvent.id);
    } finally {
      jest.useRealTimers();
    }
  });
});
