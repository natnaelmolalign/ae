import { prorateHsaAnnualLimit } from '../../../../src/services/benefits/HsaLimitProration';

describe('prorateHsaAnnualLimit', () => {
  it('prorates individual HSA limit from July 1 (6 months)', () => {
    expect(prorateHsaAnnualLimit(2024, 'individual', '2024-07-01')).toBe(
      '2075.00'
    );
  });

  it('prorates family HSA limit from October 1 (3 months)', () => {
    expect(prorateHsaAnnualLimit(2024, 'family', '2024-10-01')).toBe('2075.00');
  });
});
