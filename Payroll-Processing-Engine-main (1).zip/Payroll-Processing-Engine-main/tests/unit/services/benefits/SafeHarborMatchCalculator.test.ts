import { SafeHarborMatchCalculator } from '../../../../src/services/benefits/SafeHarborMatchCalculator';

describe('SafeHarborMatchCalculator', () => {
  const calc = new SafeHarborMatchCalculator();

  it('matches 100% of first 3% deferral plus 50% of next 2%', () => {
    const match = calc.calculateBasicMatch('100000.00', '5000.00');
    expect(match).toBe('4000.00');
  });

  it('returns zero when employee defers nothing', () => {
    expect(calc.calculateBasicMatch('100000.00', '0.00')).toBe('0.00');
  });

  it('returns tier-one match only when deferral stays within three percent', () => {
    expect(calc.calculateBasicMatch('100000.00', '2000.00')).toBe('2000.00');
  });
});
