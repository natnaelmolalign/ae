import { DeductionLimitTracker } from '../../../../src/services/benefits/DeductionLimitTracker';
import { emptyYtd } from '../../../../src/utils/ytdUtils';

describe('DeductionLimitTracker', () => {
  const tracker = new DeductionLimitTracker();

  it('includes catch-up in §402(g) ceiling when eligible', () => {
    expect(tracker.deferral402gLimit(2024, false)).toBe('23000.00');
    expect(tracker.deferral402gLimit(2024, true)).toBe('30500.00');
  });

  it('caps HSA family vs individual limits', () => {
    const ytd = emptyYtd('e1', 2024);
    ytd.hsa = '8200.00';
    const family = tracker.capHsa('200.00', ytd.hsa, 2024, 'family');
    expect(family.allowed).toBe('100.00');
    const individual = tracker.capHsa('200.00', '0.00', 2024, 'individual');
    expect(individual.allowed).toBe('200.00');
  });

  it('caps FSA and elective deferral', () => {
    const ytd = emptyYtd('e1', 2024);
    ytd.pretax401k = '22900.00';
    const deferral = tracker.capElectiveDeferral('500.00', ytd, 2024, false);
    expect(deferral.allowed).toBe('100.00');
    const fsa = tracker.capFsa('100.00', '3000.00', 2024);
    expect(parseFloat(fsa.allowed)).toBeGreaterThan(0);
  });

  it('capEnrollmentAnnualLimit passes through when no limit', () => {
    const open = tracker.capEnrollmentAnnualLimit('50.00', '0.00', null);
    expect(open.allowed).toBe('50.00');
    const capped = tracker.capEnrollmentAnnualLimit('100.00', '90.00', '95.00');
    expect(capped.allowed).toBe('5.00');
  });

  it('capAgainstAnnual returns zero when exhausted', () => {
    const exhausted = tracker.capAgainstAnnual(
      '100.00',
      '23000.00',
      '23000.00'
    );
    expect(exhausted.allowed).toBe('0.00');
    const partial = tracker.capAgainstAnnual('500.00', '100.00', '1000.00');
    expect(partial.allowed).toBe('500.00');
    const trimmed = tracker.capAgainstAnnual('500.00', '800.00', '1000.00');
    expect(trimmed.allowed).toBe('200.00');
  });

  it('maps ytd fields for deduction types', () => {
    expect(tracker.ytdFieldForType('401k_pretax')).toBe('pretax401k');
    expect(tracker.ytdFieldForType('401k_roth')).toBe('roth401k');
    expect(tracker.ytdFieldForType('hsa')).toBe('hsa');
    expect(tracker.ytdFieldForType('fsa')).toBe('fsa');
    expect(tracker.ytdFieldForType('section_125')).toBeNull();
  });
});
