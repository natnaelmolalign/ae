import { PayStubHtmlRenderer } from '../../../src/services/PayStubHtmlRenderer';
import { testEmployee } from '../../helpers/testEmployees';

describe('PayStubHtmlRenderer', () => {
  const renderer = new PayStubHtmlRenderer();

  it('renders standard pay stub HTML', () => {
    const html = renderer.render(
      {
        id: 'stub-1',
        employeeId: testEmployee.id,
        payPeriodId: 'p1',
        grossPay: '5000.00',
        netPay: '3817.50',
        isCorrection: false,
        lines: [
          {
            category: 'earnings',
            label: 'Gross Pay',
            current: '5000.00',
            ytd: '5000.00',
          },
        ],
        createdAt: '2024-06-01T00:00:00.000Z',
      },
      testEmployee,
      'Jan 2024'
    );
    expect(html).toContain('Earnings Statement');
    expect(html).not.toContain('Correction pay stub');
    expect(html).toContain('3817.50');
  });

  it('escapes HTML and marks correction stubs', () => {
    const html = renderer.render(
      {
        id: 'stub-2',
        employeeId: testEmployee.id,
        payPeriodId: 'p1',
        grossPay: '0.00',
        netPay: '100.00',
        isCorrection: true,
        lines: [
          {
            category: 'net',
            label: 'Net & Pay <script>',
            current: '100.00',
            ytd: '100.00',
          },
        ],
        createdAt: '2024-06-01T00:00:00.000Z',
      },
      { ...testEmployee, firstName: 'A&B', lastName: "O'Neil" },
      'Feb 2024'
    );
    expect(html).toContain('Correction pay stub');
    expect(html).toContain('&amp;');
    expect(html).not.toContain('<script>');
  });
});
