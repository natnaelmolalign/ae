import { PayrollBatchService } from '../../../src/services/PayrollBatchService';
import { PayrollDomainError } from '../../../src/errors/PayrollDomainError';
import type { PayPeriod } from '../../../src/models/types';
import { testEmployee } from '../../helpers/testEmployees';

const payPeriod: PayPeriod = {
  id: '2024-monthly-1',
  startDate: '2024-01-01',
  endDate: '2024-01-31',
  paymentDate: '2024-01-31',
  frequency: 'monthly',
  year: 2024,
  periodIndex: 1,
};

describe('PayrollBatchService', () => {
  const batch = {
    id: 'batch-1',
    companyId: 'default',
    payPeriodId: payPeriod.id,
    year: 2024,
    frequency: 'monthly',
    status: 'completed' as const,
    startedAt: null,
    completedAt: null,
    successCount: 0,
    failureCount: 0,
    totalCount: 0,
    durationMs: null,
  };

  it('getBatch throws when batch missing or wrong tenant', async () => {
    const svc = new PayrollBatchService(
      { findById: jest.fn().mockResolvedValue(null) } as never,
      {} as never,
      {} as never,
      {} as never,
      {} as never
    );
    await expect(svc.getBatch('x', 'default')).rejects.toBeInstanceOf(
      PayrollDomainError
    );
    const svc2 = new PayrollBatchService(
      {
        findById: jest.fn().mockResolvedValue({ ...batch, companyId: 'other' }),
      } as never,
      {} as never,
      {} as never,
      {} as never,
      {} as never
    );
    await expect(svc2.getBatch('batch-1', 'default')).rejects.toBeInstanceOf(
      PayrollDomainError
    );
  });

  it('completes empty batch and enqueues webhook', async () => {
    const batchRepo = {
      create: jest.fn().mockResolvedValue(batch),
      update: jest
        .fn()
        .mockImplementation((_id, patch) =>
          Promise.resolve({ ...batch, ...patch })
        ),
      findById: jest.fn(),
    };
    const webhookOutbox = { enqueueBatchCompleted: jest.fn() };
    const svc = new PayrollBatchService(
      batchRepo as never,
      { findByBatchId: jest.fn().mockResolvedValue([]) } as never,
      { findReadyEmployeeIds: jest.fn().mockResolvedValue([]) } as never,
      {} as never,
      { run: jest.fn() } as never,
      webhookOutbox as never
    );
    const result = await svc.createAndRun({
      companyId: 'default',
      payPeriod,
      year: 2024,
      frequency: 'monthly',
    });
    expect(result.batch.status).toBe('completed');
    expect(webhookOutbox.enqueueBatchCompleted).toHaveBeenCalled();
  });

  it('records failure when employee not in tenant', async () => {
    const batchRepo = {
      create: jest.fn().mockResolvedValue(batch),
      update: jest
        .fn()
        .mockImplementation((_id, patch) =>
          Promise.resolve({ ...batch, ...patch })
        ),
      findById: jest.fn(),
    };
    const failureRepo = {
      insert: jest.fn(),
      findByBatchId: jest.fn().mockResolvedValue([]),
    };
    const svc = new PayrollBatchService(
      batchRepo as never,
      failureRepo as never,
      {
        findReadyEmployeeIds: jest.fn().mockResolvedValue(['e-missing']),
      } as never,
      { findById: jest.fn().mockResolvedValue(testEmployee) } as never,
      { run: jest.fn() } as never
    );
    await svc.createAndRun({
      companyId: 'other-co',
      payPeriod,
      year: 2024,
      frequency: 'monthly',
      employeeIds: ['e-missing'],
    });
    expect(failureRepo.insert).toHaveBeenCalled();
  });

  it('rejects createAndRun while server is shutting down', async () => {
    jest.resetModules();
    jest.doMock('../../../src/shutdown', () => ({
      isShuttingDown: () => true,
      trackInFlight: (p: Promise<unknown>) => p,
    }));
    const {
      PayrollBatchService: Svc,
    } = require('../../../src/services/PayrollBatchService');
    const svc = new Svc(
      { create: jest.fn() } as never,
      {} as never,
      {} as never,
      {} as never,
      { run: jest.fn() } as never
    );
    await expect(
      svc.createAndRun({
        companyId: 'default',
        payPeriod,
        year: 2024,
        frequency: 'monthly',
      })
    ).rejects.toThrow(/shutting down/i);
    jest.dontMock('../../../src/shutdown');
    jest.resetModules();
  });

  it('wraps unexpected employee run errors as domain failures', async () => {
    const batchRepo = {
      create: jest.fn().mockResolvedValue(batch),
      update: jest
        .fn()
        .mockImplementation((_id, patch) =>
          Promise.resolve({ ...batch, ...patch })
        ),
      findById: jest.fn(),
    };
    const failureRepo = {
      insert: jest.fn(),
      findByBatchId: jest.fn().mockResolvedValue([]),
    };
    const svc = new PayrollBatchService(
      batchRepo as never,
      failureRepo as never,
      {
        findReadyEmployeeIds: jest.fn().mockResolvedValue([testEmployee.id]),
      } as never,
      { findById: jest.fn().mockResolvedValue(testEmployee) } as never,
      {
        run: jest.fn().mockRejectedValue(new Error('database unavailable')),
      } as never
    );
    await svc.createAndRun({
      companyId: 'default',
      payPeriod,
      year: 2024,
      frequency: 'monthly',
      employeeIds: [testEmployee.id],
    });
    expect(failureRepo.insert).toHaveBeenCalled();
  });

  it('wraps non-error throw values when employee run fails', async () => {
    const batchRepo = {
      create: jest.fn().mockResolvedValue(batch),
      update: jest
        .fn()
        .mockImplementation((_id, patch) =>
          Promise.resolve({ ...batch, ...patch })
        ),
      findById: jest.fn(),
    };
    const failureRepo = {
      insert: jest.fn(),
      findByBatchId: jest.fn().mockResolvedValue([]),
    };
    const svc = new PayrollBatchService(
      batchRepo as never,
      failureRepo as never,
      {
        findReadyEmployeeIds: jest.fn().mockResolvedValue([testEmployee.id]),
      } as never,
      { findById: jest.fn().mockResolvedValue(testEmployee) } as never,
      {
        run: jest.fn().mockRejectedValue('database unavailable'),
      } as never
    );
    await svc.createAndRun({
      companyId: 'default',
      payPeriod,
      year: 2024,
      frequency: 'monthly',
      employeeIds: [testEmployee.id],
    });
    expect(failureRepo.insert).toHaveBeenCalled();
  });
});
