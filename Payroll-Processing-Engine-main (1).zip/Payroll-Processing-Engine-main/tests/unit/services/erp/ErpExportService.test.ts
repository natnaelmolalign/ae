import { ErpExportService } from '../../../../src/services/erp/ErpExportService';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../../../src/errors/PayrollDomainError';
import type {
  ExportBatch,
  IntegrationConnection,
} from '../../../../src/models/ErpConnector';
import type { ErpConnectorRepository } from '../../../../src/repositories/interfaces';
import type { ReportingService } from '../../../../src/services/ReportingService';
import type { ConnectorAdapter } from '../../../../src/services/erp/ConnectorAdapter';
import type { ConnectorAdapterRegistry } from '../../../../src/services/erp/ConnectorStubs';
import type { GlExport } from '../../../../src/services/GeneralLedgerExporter';

describe('ErpExportService', () => {
  const companyId = 'co-1';
  const connectionId = 'conn-1';
  const payPeriodId = '2024-monthly-1';

  const connection: IntegrationConnection = {
    id: connectionId,
    companyId,
    connectorType: 'netsuite',
    name: 'NetSuite',
    config: null,
    isActive: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  const mappings = [
    {
      internalAccountCode: '5100',
      externalAccountId: 'NS-5100',
      externalAccountName: 'Salaries Expense',
    },
    {
      internalAccountCode: '2160',
      externalAccountId: 'NS-2160',
      externalAccountName: 'Net Pay Payable',
    },
  ];

  const glExports: GlExport[] = [
    {
      payPeriodId,
      payrollRunId: 'run-1',
      employeeId: 'emp-1',
      lines: [
        {
          accountCode: '5100',
          accountName: 'Salaries Expense',
          debit: '5000.00',
          credit: '0.00',
          memo: 'Gross wages',
        },
        {
          accountCode: '2160',
          accountName: 'Net Pay Payable',
          debit: '0.00',
          credit: '3817.50',
          memo: 'Net pay',
        },
      ],
      totalDebits: '5000.00',
      totalCredits: '5000.00',
      balanced: true,
    },
  ];

  const exportBatch: ExportBatch = {
    id: 'exp-1',
    companyId,
    connectionId,
    payPeriodId,
    connectorType: 'netsuite',
    status: 'submitted',
    idempotencyKey: 'idem-1',
    mappingVersion: 1,
    mappingSnapshot: mappings,
    connectorPayload: {
      connectorType: 'netsuite',
      payPeriodId,
      lines: [],
      totalDebits: '5000.00',
      totalCredits: '5000.00',
    },
    externalJournalIds: ['jrnl-1'],
    submittedAt: '2024-01-01T00:00:00.000Z',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  function repo(
    overrides: Partial<ErpConnectorRepository> = {}
  ): ErpConnectorRepository {
    return {
      createConnection: jest.fn().mockResolvedValue(connection),
      findConnectionById: jest.fn().mockResolvedValue(connection),
      listConnections: jest.fn().mockResolvedValue([connection]),
      getLatestMappingVersion: jest.fn().mockResolvedValue(1),
      publishMappings: jest
        .fn()
        .mockResolvedValue({ version: 1, mappings: [] }),
      getMappingsForVersion: jest.fn().mockResolvedValue(mappings),
      getActiveMappings: jest.fn().mockResolvedValue({ version: 1, mappings }),
      findExportByIdempotencyKey: jest.fn().mockResolvedValue(null),
      saveExportBatch: jest.fn().mockResolvedValue(exportBatch),
      findExportById: jest.fn().mockResolvedValue(exportBatch),
      ...overrides,
    } as unknown as ErpConnectorRepository;
  }

  function reporting(
    overrides: Partial<ReportingService> = {}
  ): ReportingService {
    return {
      glExportForPeriod: jest.fn().mockResolvedValue({
        exports: glExports,
        csv: 'csv',
        allBalanced: true,
      }),
      ...overrides,
    } as unknown as ReportingService;
  }

  function connectors(adapter?: ConnectorAdapter): ConnectorAdapterRegistry {
    const registry = {
      register: jest.fn(),
      get: jest.fn().mockReturnValue(
        adapter ?? {
          connectorType: 'netsuite',
          exportJournals: jest.fn().mockResolvedValue({
            externalJournalIds: ['jrnl-1'],
            connectorResponse: {},
          }),
        }
      ),
    };
    return registry as unknown as ConnectorAdapterRegistry;
  }

  it('delegates connection and mapping repository methods', async () => {
    const r = repo();
    const svc = new ErpExportService(r, reporting(), connectors());

    await svc.createConnection({
      companyId,
      connectorType: 'netsuite',
      name: 'NetSuite',
    });
    expect(r.createConnection).toHaveBeenCalled();
    expect(await svc.listConnections(companyId)).toHaveLength(1);
    expect(await svc.getConnection(connectionId, companyId)).toEqual(
      connection
    );
    await svc.publishMappings({
      companyId,
      connectionId,
      mappings,
    });
    expect(r.publishMappings).toHaveBeenCalled();
    expect(await svc.getActiveMappings(connectionId, companyId)).toEqual({
      version: 1,
      mappings,
    });
    expect(await svc.getMappingsForVersion(connectionId, companyId, 1)).toEqual(
      mappings
    );
  });

  it('exports GL to connector and saves batch', async () => {
    const r = repo();
    const report = reporting();
    const adapter = {
      connectorType: 'netsuite' as const,
      exportJournals: jest.fn().mockResolvedValue({
        externalJournalIds: ['jrnl-1'],
        connectorResponse: { ok: true },
      }),
    };
    const svc = new ErpExportService(r, report, connectors(adapter));

    const result = await svc.exportToConnector({
      companyId,
      connectionId,
      payPeriodId,
      idempotencyKey: 'idem-1',
    });

    expect(report.glExportForPeriod).toHaveBeenCalledWith(
      payPeriodId,
      companyId
    );
    expect(adapter.exportJournals).toHaveBeenCalled();
    expect(r.saveExportBatch).toHaveBeenCalled();
    expect(result).toEqual(exportBatch);
  });

  it('returns existing export for idempotency key', async () => {
    const existing = { ...exportBatch, id: 'existing' };
    const svc = new ErpExportService(
      repo({
        findExportByIdempotencyKey: jest.fn().mockResolvedValue(existing),
      }),
      reporting(),
      connectors()
    );
    const result = await svc.exportToConnector({
      companyId,
      connectionId,
      payPeriodId,
      idempotencyKey: 'idem-1',
    });
    expect(result).toEqual(existing);
  });

  it('rejects export when connection is missing, inactive, or unmapped', async () => {
    await expect(
      new ErpExportService(
        repo({ findConnectionById: jest.fn().mockResolvedValue(null) }),
        reporting(),
        connectors()
      ).exportToConnector({
        companyId,
        connectionId,
        payPeriodId,
        idempotencyKey: 'idem-1',
      })
    ).rejects.toBeInstanceOf(PayrollDomainError);

    await expect(
      new ErpExportService(
        repo({
          findConnectionById: jest
            .fn()
            .mockResolvedValue({ ...connection, isActive: false }),
        }),
        reporting(),
        connectors()
      ).exportToConnector({
        companyId,
        connectionId,
        payPeriodId,
        idempotencyKey: 'idem-1',
      })
    ).rejects.toBeInstanceOf(PayrollDomainError);

    await expect(
      new ErpExportService(
        repo({
          getActiveMappings: jest
            .fn()
            .mockResolvedValue({ version: 1, mappings: [] }),
        }),
        reporting(),
        connectors()
      ).exportToConnector({
        companyId,
        connectionId,
        payPeriodId,
        idempotencyKey: 'idem-1',
      })
    ).rejects.toMatchObject({ code: PayrollErrorCode.GL_MAPPING_NOT_FOUND });
  });

  it('rejects export when GL data is not balanced', async () => {
    await expect(
      new ErpExportService(
        repo(),
        reporting({
          glExportForPeriod: jest.fn().mockResolvedValue({
            exports: glExports,
            csv: 'csv',
            allBalanced: false,
          }),
        }),
        connectors()
      ).exportToConnector({
        companyId,
        connectionId,
        payPeriodId,
        idempotencyKey: 'idem-1',
      })
    ).rejects.toMatchObject({
      code: PayrollErrorCode.PAY_STUB_RECONCILIATION_FAILED,
    });
  });

  it('gets export batch or throws when missing', async () => {
    await expect(
      new ErpExportService(
        repo({ findExportById: jest.fn().mockResolvedValue(null) }),
        reporting(),
        connectors()
      ).getExport('missing', companyId)
    ).rejects.toBeInstanceOf(PayrollDomainError);

    expect(
      await new ErpExportService(repo(), reporting(), connectors()).getExport(
        'exp-1',
        companyId
      )
    ).toEqual(exportBatch);
  });
});
