import {
  BaseConnectorStub,
  ConnectorAdapterRegistry,
  NetSuiteStub,
  QuickBooksStub,
  createDefaultConnectorRegistry,
} from '../../../../src/services/erp/ConnectorStubs';
import type { ConnectorExportInput } from '../../../../src/services/erp/ConnectorAdapter';

describe('ConnectorStubs', () => {
  const payload = {
    connectorType: 'netsuite' as const,
    payPeriodId: '2024-monthly-1',
    lines: [
      {
        lineKey: 'run-1:5100:Gross:5000.00:0.00',
        payPeriodId: '2024-monthly-1',
        payrollRunId: 'run-1',
        employeeId: 'emp-1',
        internalAccountCode: '5100',
        externalAccountId: 'NS-5100',
        externalAccountName: 'Salaries Expense',
        debit: '5000.00',
        credit: '0.00',
        memo: 'Gross wages',
        departmentCode: 'ENG',
        jobCode: 'JOB-1',
      },
      {
        lineKey: 'run-1:2160:Net:0.00:3817.50',
        payPeriodId: '2024-monthly-1',
        payrollRunId: 'run-1',
        employeeId: 'emp-1',
        internalAccountCode: '2160',
        externalAccountId: 'NS-2160',
        externalAccountName: 'Net Pay Payable',
        debit: '0.00',
        credit: '3817.50',
        memo: 'Net pay',
      },
    ],
    totalDebits: '5000.00',
    totalCredits: '3817.50',
  };

  const input: ConnectorExportInput = {
    connectionId: 'conn-1',
    companyId: 'co-1',
    idempotencyKey: 'idem-1',
    payPeriodId: '2024-monthly-1',
    payload,
    mappingSnapshot: [],
  };

  beforeEach(() => {
    BaseConnectorStub.clearRegistry();
  });

  it('exports journals idempotently via NetSuite stub', async () => {
    const stub = new NetSuiteStub();
    const first = await stub.exportJournals(input);
    const second = await stub.exportJournals(input);

    expect(first.externalJournalIds).toHaveLength(1);
    expect(second.externalJournalIds).toEqual(first.externalJournalIds);
    expect(first.connectorResponse).toMatchObject({
      platform: 'NetSuite',
      journalEntry: expect.objectContaining({
        id: first.externalJournalIds[0],
        lineCount: 2,
      }),
    });
  });

  it('formats QuickBooks journal responses', async () => {
    const stub = new QuickBooksStub();
    const result = await stub.exportJournals({
      ...input,
      payload: { ...payload, connectorType: 'quickbooks' },
    });

    expect(result.connectorResponse).toMatchObject({
      platform: 'QuickBooks',
      JournalEntry: expect.objectContaining({
        Id: result.externalJournalIds[0],
        Line: expect.any(Array),
      }),
    });
    const lines = (
      result.connectorResponse as {
        JournalEntry: {
          Line: { JournalEntryLineDetail: { PostingType: string } }[];
        };
      }
    ).JournalEntry.Line;
    expect(lines[0].JournalEntryLineDetail.PostingType).toBe('Debit');
    expect(lines[1].JournalEntryLineDetail.PostingType).toBe('Credit');
  });

  it('registers adapters and throws for unknown connector types', () => {
    const registry = new ConnectorAdapterRegistry();
    const netsuite = new NetSuiteStub();
    registry.register(netsuite);
    expect(registry.get('netsuite')).toBe(netsuite);
    expect(() => registry.get('sap')).toThrow(
      'No connector adapter registered for sap'
    );
  });

  it('creates default registry with NetSuite and QuickBooks stubs', () => {
    const registry = createDefaultConnectorRegistry();
    expect(registry.get('netsuite')).toBeInstanceOf(NetSuiteStub);
    expect(registry.get('quickbooks')).toBeInstanceOf(QuickBooksStub);
  });
});
