import { GlJournalTransformer } from '../../../../src/services/erp/GlJournalTransformer';
import { PayrollErrorCode } from '../../../../src/errors/PayrollDomainError';
import type { GlExport } from '../../../../src/services/GeneralLedgerExporter';

describe('GlJournalTransformer', () => {
  const transformer = new GlJournalTransformer();

  const exports: GlExport[] = [
    {
      payPeriodId: '2024-monthly-1',
      payrollRunId: 'run-1',
      employeeId: 'emp-1',
      lines: [
        {
          accountCode: '5100',
          accountName: 'Salaries Expense',
          debit: '5000.00',
          credit: '0.00',
          memo: 'Gross wages',
          departmentCode: 'ENG',
          jobCode: 'JOB-1',
          locationCode: 'NYC',
        },
        {
          accountCode: '2160',
          accountName: 'Net Pay Payable',
          debit: '0.00',
          credit: '3817.50',
          memo: 'Net pay',
        },
      ],
      totalDebits: '5000.00',
      totalCredits: '5000.00',
      balanced: true,
    },
  ];

  const mappings = [
    {
      internalAccountCode: '5100',
      externalAccountId: 'QB-5100',
      externalAccountName: 'Payroll Expense',
    },
    {
      internalAccountCode: '2160',
      externalAccountId: 'QB-2160',
      externalAccountName: 'Net Pay Liability',
    },
  ];

  it('maps internal GL accounts to external connector accounts', () => {
    const payload = transformer.transform('quickbooks', exports, mappings);

    expect(payload.lines).toHaveLength(2);
    expect(payload.lines[0]).toMatchObject({
      externalAccountId: 'QB-5100',
      departmentCode: 'ENG',
      jobCode: 'JOB-1',
      locationCode: 'NYC',
    });
    expect(payload.totalDebits).toBe('5000.00');
    expect(payload.totalCredits).toBe('3817.50');
    expect(payload.payPeriodId).toBe('2024-monthly-1');
  });

  it('throws when a GL account mapping is missing', () => {
    expect(() =>
      transformer.transform('netsuite', exports, [
        {
          internalAccountCode: '5100',
          externalAccountId: 'NS-5100',
          externalAccountName: 'Payroll Expense',
        },
      ])
    ).toThrowError(
      expect.objectContaining({ code: PayrollErrorCode.GL_MAPPING_NOT_FOUND })
    );
  });

  it('returns empty pay period when no exports are provided', () => {
    const payload = transformer.transform('quickbooks', [], mappings);
    expect(payload.payPeriodId).toBe('');
    expect(payload.lines).toHaveLength(0);
    expect(payload.totalDebits).toBe('0.00');
    expect(payload.totalCredits).toBe('0.00');
  });
});
