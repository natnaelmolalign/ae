import { GeneralLedgerExporter } from '../../../src/services/GeneralLedgerExporter';
import type { PayrollRunResult } from '../../../src/models/types';

function sampleRun(gross: string, net: string): PayrollRunResult {
  return {
    payStub: {
      id: 'stub-1',
      employeeId: 'emp-1',
      payPeriodId: '2024-monthly-1',
      grossPay: gross,
      netPay: net,
      isCorrection: false,
      lines: [
        {
          category: 'earnings',
          label: 'Gross Pay',
          current: gross,
          ytd: gross,
        },
        {
          category: 'deduction',
          label: '401(k) Pre-Tax',
          current: '200.00',
          ytd: '200.00',
        },
        {
          category: 'tax',
          label: 'Federal Income Tax',
          current: '500.00',
          ytd: '500.00',
        },
        {
          category: 'tax',
          label: 'State Income Tax',
          current: '100.00',
          ytd: '100.00',
        },
        {
          category: 'tax',
          label: 'Social Security',
          current: '310.00',
          ytd: '310.00',
        },
        { category: 'tax', label: 'Medicare', current: '72.50', ytd: '72.50' },
        {
          category: 'tax',
          label: 'Medicare Additional',
          current: '0.00',
          ytd: '0.00',
        },
        { category: 'net', label: 'Net Pay', current: net, ytd: net },
      ],
      createdAt: new Date().toISOString(),
    },
    taxes: {
      federalIncome: '500.00',
      stateIncome: '100.00',
      localIncome: '0.00',
      socialSecurity: '310.00',
      medicare: '72.50',
      medicareAdditional: '0.00',
    },
    employerContributions: {
      ss: '310.00',
      medicare: '72.50',
      match401k: '0.00',
    },
  };
}

describe('GeneralLedgerExporter', () => {
  const exporter = new GeneralLedgerExporter();

  it('balances debits and credits for a standard run', () => {
    const gl = exporter.exportRun(
      '2024-monthly-1',
      'run-1',
      sampleRun('5000.00', '3817.50')
    );
    expect(gl.balanced).toBe(true);
    expect(gl.totalDebits).toBe(gl.totalCredits);
  });

  it('includes employer Social Security liability', () => {
    const gl = exporter.exportRun(
      '2024-monthly-1',
      'run-1',
      sampleRun('5000.00', '3817.50')
    );
    const ficaCredits = gl.lines.filter((l) => l.accountCode === '2120');
    expect(
      ficaCredits.some((l) => l.memo.includes('Employer Social Security'))
    ).toBe(true);
  });

  it('produces stable CSV header with cost dimensions', () => {
    const gl = exporter.exportRun(
      '2024-monthly-1',
      'run-1',
      sampleRun('1000.00', '800.00')
    );
    const csv = exporter.toCsv([gl]);
    expect(csv.split('\n')[0]).toBe(
      'pay_period_id,payroll_run_id,employee_id,department_code,job_code,location_code,account_code,account_name,debit,credit,memo'
    );
  });

  it('splits GL lines by department and stays balanced per segment', () => {
    const segments = [
      {
        departmentId: 'd1',
        departmentCode: 'ENG',
        departmentName: 'Engineering',
        locationCode: 'NYC',
        jobId: null,
        jobCode: null,
        percent: '50',
      },
      {
        departmentId: 'd2',
        departmentCode: 'SLS',
        departmentName: 'Sales',
        locationCode: 'BOS',
        jobId: null,
        jobCode: null,
        percent: '50',
      },
    ];
    const gl = exporter.exportRun(
      '2024-monthly-1',
      'run-1',
      sampleRun('5000.00', '3817.50'),
      segments
    );
    expect(gl.balanced).toBe(true);
    const engGross = gl.lines.find(
      (l) => l.departmentCode === 'ENG' && l.accountCode === '5100'
    );
    const slsGross = gl.lines.find(
      (l) => l.departmentCode === 'SLS' && l.accountCode === '5100'
    );
    expect(engGross?.debit).toBe('2500.00');
    expect(slsGross?.debit).toBe('2500.00');
  });

  it('includes job code in memo when segment has a job', () => {
    const segments = [
      {
        departmentId: 'd1',
        departmentCode: 'ENG',
        departmentName: 'Engineering',
        locationCode: 'NYC',
        jobId: 'j1',
        jobCode: 'PRJ-1',
        percent: '100',
      },
    ];
    const gl = exporter.exportRun(
      '2024-monthly-1',
      'run-1',
      sampleRun('5000.00', '3817.50'),
      segments
    );
    expect(gl.lines.some((l) => l.memo.includes('ENG/PRJ-1'))).toBe(true);
  });

  it('books employer match, garnishments, negative net, and catch-up net', () => {
    const withMatch = sampleRun('5000.00', '3817.50');
    withMatch.employerContributions.match401k = '200.00';
    withMatch.garnishmentRemittances = [
      {
        garnishmentOrderId: 'go-1',
        caseId: 'case-1',
        orderType: 'child_support',
        amount: '100.00',
      },
    ];
    const gl = exporter.exportRun('p1', 'r1', withMatch);
    expect(gl.lines.some((l) => l.memo.includes('401(k) match'))).toBe(true);
    expect(gl.lines.some((l) => l.memo === 'Garnishments')).toBe(true);

    const negative = sampleRun('1.00', '-100.00');
    negative.taxes = {
      federalIncome: '0.00',
      stateIncome: '0.00',
      localIncome: '0.00',
      socialSecurity: '0.00',
      medicare: '0.00',
      medicareAdditional: '0.00',
    };
    negative.employerContributions = {
      ss: '0.00',
      medicare: '0.00',
      match401k: '0.00',
    };
    negative.payStub.lines = [
      { category: 'net', label: 'Net Pay', current: '-100.00', ytd: '-100.00' },
    ];
    const negGl = exporter.exportRun('p1', 'r2', negative);
    expect(
      negGl.lines.some(
        (l) =>
          l.memo === 'Net pay' && l.debit === '100.00' && l.credit === '0.00'
      )
    ).toBe(true);

    const catchUp = sampleRun('0.00', '150.00');
    const catchGl = exporter.exportRun('p1', 'r3', catchUp);
    expect(catchGl.lines.some((l) => l.memo.includes('catch-up'))).toBe(true);
  });
});
