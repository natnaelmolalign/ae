import { W4ChangeRequestService } from '../../../../src/services/ess/W4ChangeRequestService';
import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../../../src/errors/PayrollDomainError';
import { testEmployee } from '../../../helpers/testEmployees';
import type { W4ChangeRequest } from '../../../../src/models/EmployeeEss';
import type {
  EmployeeRepository,
  W4ChangeRequestRepository,
} from '../../../../src/repositories/interfaces';
import type { AuditService } from '../../../../src/services/AuditService';

describe('W4ChangeRequestService', () => {
  const draftRequest: W4ChangeRequest = {
    id: 'w4-1',
    companyId: testEmployee.companyId,
    employeeId: testEmployee.id,
    status: 'draft',
    filingStatus: 'married_filing_jointly',
    w4ExtraWithholding: '10.00',
    w4DependentsCredit: '0.00',
    w4OtherDeductions: '0.00',
    w4OtherIncome: '0.00',
    w4MultipleJobs: false,
    submittedAt: null,
    reviewedAt: null,
    reviewedBy: null,
    appliedAt: null,
    reviewNotes: null,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };

  const pendingRequest: W4ChangeRequest = {
    ...draftRequest,
    status: 'pending',
    submittedAt: '2024-01-02T00:00:00.000Z',
  };

  const appliedRequest: W4ChangeRequest = {
    ...pendingRequest,
    status: 'applied',
    reviewedAt: '2024-01-03T00:00:00.000Z',
    reviewedBy: 'hr-admin',
    appliedAt: '2024-01-03T00:00:00.000Z',
  };

  function deps(
    overrides: {
      w4Repo?: Partial<W4ChangeRequestRepository>;
      employeeRepo?: Partial<EmployeeRepository>;
      auditService?: Partial<AuditService>;
    } = {}
  ) {
    return {
      w4Repo: {
        create: jest.fn().mockResolvedValue(draftRequest),
        listByEmployee: jest.fn().mockResolvedValue([draftRequest]),
        listByStatus: jest.fn().mockResolvedValue([pendingRequest]),
        findById: jest.fn().mockResolvedValue(draftRequest),
        updateStatus: jest.fn().mockResolvedValue(pendingRequest),
        ...overrides.w4Repo,
      } as unknown as W4ChangeRequestRepository,
      employeeRepo: {
        findById: jest.fn().mockResolvedValue(testEmployee),
        updateW4Fields: jest.fn().mockResolvedValue({
          ...testEmployee,
          filingStatus: 'married_filing_jointly',
          w4ExtraWithholding: '10.00',
        }),
        ...overrides.employeeRepo,
      } as unknown as EmployeeRepository,
      auditService: {
        recordUpdate: jest.fn().mockResolvedValue(undefined),
        ...overrides.auditService,
      } as unknown as AuditService,
    };
  }

  it('delegates draft creation and listing', async () => {
    const d = deps();
    const svc = new W4ChangeRequestService(
      d.w4Repo,
      d.employeeRepo,
      d.auditService
    );
    await svc.createDraft({
      companyId: testEmployee.companyId,
      employeeId: testEmployee.id,
      filingStatus: 'married_filing_jointly',
    });
    expect(d.w4Repo.create).toHaveBeenCalled();
    expect(
      await svc.listForEmployee(testEmployee.id, testEmployee.companyId)
    ).toHaveLength(1);
    expect(await svc.listPending(testEmployee.companyId)).toHaveLength(1);
  });

  it('returns request for employee when ownership matches', async () => {
    const d = deps();
    const svc = new W4ChangeRequestService(
      d.w4Repo,
      d.employeeRepo,
      d.auditService
    );
    expect(
      await svc.getForEmployee('w4-1', testEmployee.id, testEmployee.companyId)
    ).toEqual(draftRequest);
  });

  it('throws when request is missing or owned by another employee', async () => {
    const d = deps({
      w4Repo: {
        findById: jest
          .fn()
          .mockResolvedValueOnce(null)
          .mockResolvedValueOnce({ ...draftRequest, employeeId: 'other' }),
      },
    });
    const svc = new W4ChangeRequestService(
      d.w4Repo,
      d.employeeRepo,
      d.auditService
    );
    await expect(
      svc.getForEmployee('missing', testEmployee.id, testEmployee.companyId)
    ).rejects.toBeInstanceOf(PayrollDomainError);
    await expect(
      svc.getForEmployee('w4-1', testEmployee.id, testEmployee.companyId)
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('submits draft requests', async () => {
    const d = deps({
      w4Repo: {
        findById: jest.fn().mockResolvedValue(draftRequest),
        updateStatus: jest.fn().mockResolvedValue(pendingRequest),
      },
    });
    const svc = new W4ChangeRequestService(
      d.w4Repo,
      d.employeeRepo,
      d.auditService
    );
    const submitted = await svc.submit(
      'w4-1',
      testEmployee.id,
      testEmployee.companyId
    );
    expect(submitted.status).toBe('pending');
    expect(d.w4Repo.updateStatus).toHaveBeenCalledWith(
      'w4-1',
      testEmployee.companyId,
      'pending',
      expect.objectContaining({ submittedAt: expect.any(String) })
    );
  });

  it('rejects submit when status is not draft', async () => {
    const d = deps({
      w4Repo: { findById: jest.fn().mockResolvedValue(pendingRequest) },
    });
    const svc = new W4ChangeRequestService(
      d.w4Repo,
      d.employeeRepo,
      d.auditService
    );
    await expect(
      svc.submit('w4-1', testEmployee.id, testEmployee.companyId)
    ).rejects.toMatchObject({ code: PayrollErrorCode.W4_CHANGE_INVALID_STATE });
  });

  it('throws when submit update misses', async () => {
    const d = deps({
      w4Repo: {
        findById: jest.fn().mockResolvedValue(draftRequest),
        updateStatus: jest.fn().mockResolvedValue(null),
      },
    });
    const svc = new W4ChangeRequestService(
      d.w4Repo,
      d.employeeRepo,
      d.auditService
    );
    await expect(
      svc.submit('w4-1', testEmployee.id, testEmployee.companyId)
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('approves pending requests and records audit when prior employee exists', async () => {
    const d = deps({
      w4Repo: {
        findById: jest.fn().mockResolvedValue(pendingRequest),
        updateStatus: jest.fn().mockResolvedValue(appliedRequest),
      },
    });
    const svc = new W4ChangeRequestService(
      d.w4Repo,
      d.employeeRepo,
      d.auditService
    );
    const approved = await svc.approve(
      'w4-1',
      testEmployee.companyId,
      'hr-admin'
    );
    expect(approved.status).toBe('applied');
    expect(d.employeeRepo.updateW4Fields).toHaveBeenCalled();
    expect(d.auditService.recordUpdate).toHaveBeenCalled();
  });

  it('approves without audit when employee snapshot is missing', async () => {
    const d = deps({
      w4Repo: {
        findById: jest.fn().mockResolvedValue(pendingRequest),
        updateStatus: jest.fn().mockResolvedValue(appliedRequest),
      },
      employeeRepo: {
        findById: jest.fn().mockResolvedValue(null),
        updateW4Fields: jest.fn().mockResolvedValue({
          ...testEmployee,
          filingStatus: 'married_filing_jointly',
        }),
      },
    });
    const svc = new W4ChangeRequestService(
      d.w4Repo,
      d.employeeRepo,
      d.auditService
    );
    await svc.approve('w4-1', testEmployee.companyId, 'hr-admin');
    expect(d.auditService.recordUpdate).not.toHaveBeenCalled();
  });

  it('throws on approve when request or employee update is missing', async () => {
    const missing = deps({
      w4Repo: { findById: jest.fn().mockResolvedValue(null) },
    });
    const svcMissing = new W4ChangeRequestService(
      missing.w4Repo,
      missing.employeeRepo,
      missing.auditService
    );
    await expect(
      svcMissing.approve('w4-1', testEmployee.companyId, 'hr-admin')
    ).rejects.toBeInstanceOf(PayrollDomainError);

    const wrongStatus = deps({
      w4Repo: { findById: jest.fn().mockResolvedValue(draftRequest) },
    });
    const svcWrong = new W4ChangeRequestService(
      wrongStatus.w4Repo,
      wrongStatus.employeeRepo,
      wrongStatus.auditService
    );
    await expect(
      svcWrong.approve('w4-1', testEmployee.companyId, 'hr-admin')
    ).rejects.toMatchObject({ code: PayrollErrorCode.W4_CHANGE_INVALID_STATE });

    const employeeMiss = deps({
      w4Repo: { findById: jest.fn().mockResolvedValue(pendingRequest) },
      employeeRepo: { updateW4Fields: jest.fn().mockResolvedValue(null) },
    });
    const svcEmp = new W4ChangeRequestService(
      employeeMiss.w4Repo,
      employeeMiss.employeeRepo,
      employeeMiss.auditService
    );
    await expect(
      svcEmp.approve('w4-1', testEmployee.companyId, 'hr-admin')
    ).rejects.toBeInstanceOf(PayrollDomainError);

    const updateMiss = deps({
      w4Repo: {
        findById: jest.fn().mockResolvedValue(pendingRequest),
        updateStatus: jest.fn().mockResolvedValue(null),
      },
    });
    const svcUpdate = new W4ChangeRequestService(
      updateMiss.w4Repo,
      updateMiss.employeeRepo,
      updateMiss.auditService
    );
    await expect(
      svcUpdate.approve('w4-1', testEmployee.companyId, 'hr-admin')
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('rejects pending requests with optional notes', async () => {
    const rejected: W4ChangeRequest = {
      ...pendingRequest,
      status: 'rejected',
      reviewedAt: '2024-01-03T00:00:00.000Z',
      reviewedBy: 'hr-admin',
      reviewNotes: 'Incomplete',
    };
    const d = deps({
      w4Repo: {
        findById: jest.fn().mockResolvedValue(pendingRequest),
        updateStatus: jest.fn().mockResolvedValue(rejected),
      },
    });
    const svc = new W4ChangeRequestService(
      d.w4Repo,
      d.employeeRepo,
      d.auditService
    );
    const result = await svc.reject(
      'w4-1',
      testEmployee.companyId,
      'hr-admin',
      'Incomplete'
    );
    expect(result.status).toBe('rejected');
    expect(d.w4Repo.updateStatus).toHaveBeenCalledWith(
      'w4-1',
      testEmployee.companyId,
      'rejected',
      expect.objectContaining({ reviewNotes: 'Incomplete' })
    );
  });

  it('rejects with null notes when omitted', async () => {
    const d = deps({
      w4Repo: {
        findById: jest.fn().mockResolvedValue(pendingRequest),
        updateStatus: jest.fn().mockResolvedValue({
          ...pendingRequest,
          status: 'rejected',
        }),
      },
    });
    const svc = new W4ChangeRequestService(
      d.w4Repo,
      d.employeeRepo,
      d.auditService
    );
    await svc.reject('w4-1', testEmployee.companyId, 'hr-admin');
    expect(d.w4Repo.updateStatus).toHaveBeenCalledWith(
      'w4-1',
      testEmployee.companyId,
      'rejected',
      expect.objectContaining({ reviewNotes: null })
    );
  });

  it('throws on reject when request is missing, wrong status, or update fails', async () => {
    const missing = deps({
      w4Repo: { findById: jest.fn().mockResolvedValue(null) },
    });
    const svcMissing = new W4ChangeRequestService(
      missing.w4Repo,
      missing.employeeRepo,
      missing.auditService
    );
    await expect(
      svcMissing.reject('w4-1', testEmployee.companyId, 'hr-admin')
    ).rejects.toBeInstanceOf(PayrollDomainError);

    const wrongStatus = deps({
      w4Repo: { findById: jest.fn().mockResolvedValue(draftRequest) },
    });
    const svcWrong = new W4ChangeRequestService(
      wrongStatus.w4Repo,
      wrongStatus.employeeRepo,
      wrongStatus.auditService
    );
    await expect(
      svcWrong.reject('w4-1', testEmployee.companyId, 'hr-admin')
    ).rejects.toMatchObject({ code: PayrollErrorCode.W4_CHANGE_INVALID_STATE });

    const updateMiss = deps({
      w4Repo: {
        findById: jest.fn().mockResolvedValue(pendingRequest),
        updateStatus: jest.fn().mockResolvedValue(null),
      },
    });
    const svcUpdate = new W4ChangeRequestService(
      updateMiss.w4Repo,
      updateMiss.employeeRepo,
      updateMiss.auditService
    );
    await expect(
      svcUpdate.reject('w4-1', testEmployee.companyId, 'hr-admin')
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });
});
