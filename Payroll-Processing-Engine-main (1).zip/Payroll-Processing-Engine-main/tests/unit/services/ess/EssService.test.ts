import { EssService } from '../../../../src/services/ess/EssService';
import { PayrollDomainError } from '../../../../src/errors/PayrollDomainError';
import { testEmployee } from '../../../helpers/testEmployees';
import { emptyYtd } from '../../../../src/utils/ytdUtils';
import type { PayStub } from '../../../../src/models/types';
import type {
  PayStubRepository,
  YtdRepository,
} from '../../../../src/repositories/interfaces';
import type { EmployeeService } from '../../../../src/services/EmployeeService';
import type { ComplianceReportingService } from '../../../../src/services/compliance/ComplianceReportingService';

describe('EssService', () => {
  const payStub: PayStub = {
    id: 'ps-1',
    employeeId: testEmployee.id,
    payPeriodId: 'pp-1',
    grossPay: '5000.00',
    netPay: '3500.00',
    lines: [],
    isCorrection: false,
    createdAt: '2024-01-31T00:00:00.000Z',
  };

  const ytd = emptyYtd(testEmployee.id, 2024);
  ytd.grossEarnings = '5000.00';

  function deps(
    overrides: {
      employeeService?: Partial<EmployeeService>;
      payStubRepository?: Partial<PayStubRepository>;
      ytdRepository?: Partial<YtdRepository>;
      complianceReportingService?: Partial<ComplianceReportingService>;
    } = {}
  ) {
    return {
      employeeService: {
        get: jest.fn().mockResolvedValue(testEmployee),
        ...overrides.employeeService,
      } as unknown as EmployeeService,
      payStubRepository: {
        listByEmployee: jest.fn().mockResolvedValue([payStub]),
        findById: jest.fn().mockResolvedValue(payStub),
        ...overrides.payStubRepository,
      } as unknown as PayStubRepository,
      ytdRepository: {
        get: jest.fn().mockResolvedValue(ytd),
        ...overrides.ytdRepository,
      } as unknown as YtdRepository,
      complianceReportingService: {
        w2Preview: jest.fn().mockResolvedValue({
          taxYear: 2024,
          employees: [
            {
              employeeId: testEmployee.id,
              employeeName: 'Jane Doe',
              boxes: { wages: '5000.00', federalIncomeTaxWithheld: '800.00' },
            },
          ],
        }),
        ...overrides.complianceReportingService,
      } as unknown as ComplianceReportingService,
    };
  }

  it('returns employee profile for own employee', async () => {
    const d = deps();
    const svc = new EssService(
      d.employeeService,
      d.payStubRepository,
      d.ytdRepository,
      d.complianceReportingService
    );
    const profile = await svc.getProfile(
      testEmployee.id,
      testEmployee.companyId
    );
    expect(profile).toEqual({
      id: testEmployee.id,
      firstName: testEmployee.firstName,
      lastName: testEmployee.lastName,
      employmentType: testEmployee.employmentType,
      payFrequency: testEmployee.payFrequency,
      filingStatus: testEmployee.filingStatus,
      stateCode: testEmployee.stateCode,
      w4ExtraWithholding: testEmployee.w4ExtraWithholding,
      w4DependentsCredit: testEmployee.w4DependentsCredit,
      w4OtherDeductions: testEmployee.w4OtherDeductions,
      w4OtherIncome: testEmployee.w4OtherIncome,
      w4MultipleJobs: testEmployee.w4MultipleJobs,
    });
  });

  it('throws when employee is not found', async () => {
    const d = deps({
      employeeService: { get: jest.fn().mockResolvedValue(null) },
    });
    const svc = new EssService(
      d.employeeService,
      d.payStubRepository,
      d.ytdRepository,
      d.complianceReportingService
    );
    await expect(
      svc.getProfile(testEmployee.id, testEmployee.companyId)
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('lists pay stubs after employee check', async () => {
    const d = deps();
    const svc = new EssService(
      d.employeeService,
      d.payStubRepository,
      d.ytdRepository,
      d.complianceReportingService
    );
    const stubs = await svc.listPayStubs(
      testEmployee.id,
      testEmployee.companyId
    );
    expect(stubs).toHaveLength(1);
    expect(d.payStubRepository.listByEmployee).toHaveBeenCalledWith(
      testEmployee.id
    );
  });

  it('returns pay stub when owned by employee', async () => {
    const d = deps();
    const svc = new EssService(
      d.employeeService,
      d.payStubRepository,
      d.ytdRepository,
      d.complianceReportingService
    );
    expect(
      await svc.getPayStub(testEmployee.id, testEmployee.companyId, 'ps-1')
    ).toEqual(payStub);
  });

  it('throws when pay stub is missing or belongs to another employee', async () => {
    const d = deps({
      payStubRepository: {
        findById: jest
          .fn()
          .mockResolvedValueOnce(null)
          .mockResolvedValueOnce({ ...payStub, employeeId: 'other' }),
      },
    });
    const svc = new EssService(
      d.employeeService,
      d.payStubRepository,
      d.ytdRepository,
      d.complianceReportingService
    );
    await expect(
      svc.getPayStub(testEmployee.id, testEmployee.companyId, 'ps-missing')
    ).rejects.toBeInstanceOf(PayrollDomainError);
    await expect(
      svc.getPayStub(testEmployee.id, testEmployee.companyId, 'ps-other')
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });

  it('returns stored YTD or empty default', async () => {
    const d = deps();
    const svc = new EssService(
      d.employeeService,
      d.payStubRepository,
      d.ytdRepository,
      d.complianceReportingService
    );
    expect(
      await svc.getYtd(testEmployee.id, testEmployee.companyId, 2024)
    ).toEqual(ytd);

    const d2 = deps({
      ytdRepository: { get: jest.fn().mockResolvedValue(null) },
    });
    const svc2 = new EssService(
      d2.employeeService,
      d2.payStubRepository,
      d2.ytdRepository,
      d2.complianceReportingService
    );
    expect(
      await svc2.getYtd(testEmployee.id, testEmployee.companyId, 2025)
    ).toEqual(emptyYtd(testEmployee.id, 2025));
  });

  it('returns W-2 preview slice for employee', async () => {
    const d = deps();
    const svc = new EssService(
      d.employeeService,
      d.payStubRepository,
      d.ytdRepository,
      d.complianceReportingService
    );
    const preview = await svc.getW2Preview(
      testEmployee.id,
      testEmployee.companyId,
      2024
    );
    expect(preview).toEqual({
      taxYear: 2024,
      employee: expect.objectContaining({ employeeId: testEmployee.id }),
    });
  });

  it('throws when employee is absent from W-2 preview', async () => {
    const d = deps({
      complianceReportingService: {
        w2Preview: jest
          .fn()
          .mockResolvedValue({ taxYear: 2024, employees: [] }),
      },
    });
    const svc = new EssService(
      d.employeeService,
      d.payStubRepository,
      d.ytdRepository,
      d.complianceReportingService
    );
    await expect(
      svc.getW2Preview(testEmployee.id, testEmployee.companyId, 2024)
    ).rejects.toBeInstanceOf(PayrollDomainError);
  });
});
