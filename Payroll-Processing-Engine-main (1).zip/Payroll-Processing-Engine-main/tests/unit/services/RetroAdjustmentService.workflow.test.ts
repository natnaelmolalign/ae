import type { PayPeriod } from '../../../src/models/types';
import { RetroAdjustmentService } from '../../../src/services/RetroAdjustmentService';
import { PayrollDomainError } from '../../../src/errors/PayrollDomainError';
import { testEmployee } from '../../helpers/testEmployees';

const periods: PayPeriod[] = [
  {
    id: '2024-monthly-1',
    startDate: '2024-01-01',
    endDate: '2024-01-31',
    paymentDate: '2024-01-31',
    frequency: 'monthly',
    year: 2024,
    periodIndex: 1,
  },
  {
    id: '2024-monthly-2',
    startDate: '2024-02-01',
    endDate: '2024-02-29',
    paymentDate: '2024-02-29',
    frequency: 'monthly',
    year: 2024,
    periodIndex: 2,
  },
];

const current = periods[1]!;
const runFactory = (p: PayPeriod) => ({
  employeeId: testEmployee.id,
  payPeriodId: p.id,
  earnings: [{ type: 'regular' as const, amount: '100.00' }],
  deductions: [],
  garnishments: [],
});

describe('RetroAdjustmentService workflow', () => {
  const preview = {
    affectedPeriodIds: ['2024-monthly-1'],
    totalNetCatchUp: '50.00',
    periodDeltas: [],
    projectedYtdGross: '5000.00',
    negativeNetRecovery: false,
  };

  function build(
    overrides: {
      record?: Record<string, unknown>;
      retroRepo?: Record<string, jest.Mock>;
    } = {}
  ) {
    const record = {
      id: 'retro-1',
      employeeId: testEmployee.id,
      status: 'draft',
      effectiveDate: '2024-01-01',
      currentPayPeriodId: current.id,
      reason: 'rate fix',
      earningsPerPeriod: [{ type: 'regular', amount: '100.00' }],
      preview: null,
      catchUpPayStubId: null,
      ...overrides.record,
    };
    const retroRepo = {
      findById: jest.fn().mockResolvedValue(record),
      create: jest.fn().mockResolvedValue(record),
      update: jest.fn().mockImplementation(async (_id, patch) => ({
        ...record,
        ...patch,
      })),
      ...overrides.retroRepo,
    };
    const payStubRepo = {
      findOriginalByEmployeeAndPeriod: jest
        .fn()
        .mockResolvedValue({ id: 'orig-1', grossPay: '5000.00' }),
    };
    const payrollRun = {
      run: jest.fn().mockResolvedValue({ payStub: { id: 'corr-1' } }),
      runCatchUpCorrection: jest
        .fn()
        .mockResolvedValue({ payStub: { id: 'catch-1' } }),
    };
    const svc = new RetroAdjustmentService(
      payrollRun as never,
      payStubRepo as never,
      retroRepo as never,
      {} as never
    );
    return { svc, retroRepo, payrollRun, record };
  }

  it('preview, approve, apply, and applyDirect', async () => {
    const { svc, retroRepo, record } = build({
      record: { status: 'draft', preview: null },
    });
    const state = {
      status: 'draft' as string,
      preview: null as typeof preview | null,
    };
    retroRepo.findById.mockImplementation(async () => ({
      ...record,
      status: state.status,
      preview: state.preview,
    }));
    retroRepo.update.mockImplementation(async (_id, patch) => {
      if (patch.status) state.status = patch.status;
      if (patch.preview !== undefined) state.preview = patch.preview;
      return {
        ...record,
        status: state.status,
        preview: state.preview,
        catchUpPayStubId: patch.catchUpPayStubId ?? null,
      };
    });
    jest.spyOn(svc, 'computePreview').mockResolvedValue(preview);
    await svc.preview('retro-1', testEmployee, periods, current, runFactory);
    await svc.approve('retro-1');
    const applied = await svc.apply(
      'retro-1',
      testEmployee,
      periods,
      current,
      runFactory
    );
    expect(applied.catchUpPayStubId).toBe('catch-1');

    const { svc: svc2, retroRepo: repo2, record: record2 } = build();
    const state2 = {
      status: 'draft' as string,
      preview: null as typeof preview | null,
    };
    repo2.findById.mockImplementation(async () => ({
      ...record2,
      id: 'retro-2',
      status: state2.status,
      preview: state2.preview,
    }));
    repo2.create.mockResolvedValue({
      ...record2,
      id: 'retro-2',
      status: 'draft',
    });
    repo2.update.mockImplementation(async (_id, patch) => {
      if (patch.status) state2.status = patch.status;
      if (patch.preview !== undefined) state2.preview = patch.preview;
      return {
        ...record2,
        id: 'retro-2',
        status: state2.status,
        preview: state2.preview,
        catchUpPayStubId: patch.catchUpPayStubId ?? null,
      };
    });
    jest.spyOn(svc2, 'computePreview').mockResolvedValue(preview);
    const direct = await svc2.applyDirect(
      testEmployee,
      periods,
      '2024-01-01',
      current,
      runFactory,
      'back pay'
    );
    expect(direct.employeeId).toBe(testEmployee.id);
  });

  it('rejects invalid state transitions and missing preview', async () => {
    const { svc } = build({ record: { status: 'applied' } });
    await expect(
      svc.preview('retro-1', testEmployee, periods, current, runFactory)
    ).rejects.toBeInstanceOf(PayrollDomainError);
    const { svc: s2 } = build({ record: { status: 'draft' } });
    await expect(s2.approve('retro-1')).rejects.toBeInstanceOf(
      PayrollDomainError
    );
    const { svc: s3 } = build({
      record: { status: 'approved', preview: null },
    });
    await expect(
      s3.apply('retro-1', testEmployee, periods, current, runFactory)
    ).rejects.toBeInstanceOf(PayrollDomainError);
    const { svc: s4 } = build({
      retroRepo: { findById: jest.fn().mockResolvedValue(null) },
    });
    await expect(s4.approve('missing')).rejects.toBeInstanceOf(
      PayrollDomainError
    );
  });

  it('assertNotAfterTermination throws after term date', () => {
    const svc = new RetroAdjustmentService(
      {} as never,
      {} as never,
      {} as never,
      {} as never
    );
    expect(() =>
      svc.assertNotAfterTermination(
        { ...testEmployee, terminationDate: '2024-01-15' },
        current
      )
    ).toThrow(PayrollDomainError);
  });
});
