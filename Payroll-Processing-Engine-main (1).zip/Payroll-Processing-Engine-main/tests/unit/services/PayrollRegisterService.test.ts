import { PayrollRegisterService } from '../../../src/services/PayrollRegisterService';

describe('PayrollRegisterService', () => {
  it('builds register with and without allocation repo', async () => {
    const rows = [
      {
        payroll_run_id: 'run-1',
        employee_id: 'e1',
        pay_stub_id: 'stub-1',
        gross_pay: '5000.00',
        net_pay: '4000.00',
        is_correction: false,
        first_name: 'Jane',
        last_name: 'Doe',
      },
    ];
    const db = jest.fn((table: string) => {
      const chain = {
        join: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        orderBy: jest.fn().mockResolvedValue(rows),
        first: jest.fn(),
      };
      if (table === 'pay_stubs') {
        return {
          where: jest.fn().mockReturnThis(),
          first: jest.fn().mockResolvedValue({
            gross_pay: '5000.00',
            net_pay: '4000.00',
          }),
        };
      }
      return chain;
    });

    const withoutAlloc = new PayrollRegisterService(db as never);
    const reg = await withoutAlloc.build('2024-monthly-1');
    expect(reg.rows[0]!.costAllocations).toEqual([]);
    expect(reg.totals.stubCount).toBe(1);

    const allocationRepo = {
      findSegmentsForRuns: jest
        .fn()
        .mockResolvedValue(
          new Map([['run-1', [{ departmentCode: 'ENG', percent: '100' }]]])
        ),
      insertMany: jest.fn(),
      findByPayrollRun: jest.fn(),
    };
    const withAlloc = new PayrollRegisterService(
      db as never,
      allocationRepo as never
    );
    const reg2 = await withAlloc.build('2024-monthly-1');
    expect(reg2.rows[0]!.costAllocations).toHaveLength(1);
  });
});
