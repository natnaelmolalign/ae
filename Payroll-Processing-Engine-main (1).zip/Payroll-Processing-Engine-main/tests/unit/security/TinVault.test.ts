import {
  decryptTin,
  encryptTin,
  maskTin,
  normalizeTin,
} from '../../../src/security/TinVault';

describe('TinVault', () => {
  const prior = process.env.TIN_MASTER_KEY;

  beforeAll(() => {
    process.env.TIN_MASTER_KEY = 'test-master-key-phase10';
  });

  afterAll(() => {
    process.env.TIN_MASTER_KEY = prior;
  });

  it('round-trips TIN encryption', () => {
    const sealed = encryptTin('123-45-6789');
    expect(sealed.lastFour).toBe('6789');
    expect(decryptTin(sealed.payload, sealed.keyId)).toBe('123456789');
  });

  it('masks and normalizes TIN', () => {
    expect(normalizeTin('12-3456789')).toBe('123456789');
    expect(maskTin('123456789')).toBe('***-**-6789');
  });
});
