import { PluginHost } from '../../../src/plugins/PluginHost';

describe('PluginHost', () => {
  it('executes registered plugin within tenant scope', async () => {
    const host = new PluginHost();
    host.register({
      id: 'test-deduction',
      name: 'Test',
      async calculate(ctx) {
        return { code: 'test', amount: '10.00', description: ctx.companyId };
      },
    });

    const result = await host.execute('test-deduction', {
      companyId: 'default',
      employeeId: '00000000-0000-0000-0000-000000000001',
      grossPay: '1000.00',
      payPeriodId: '2024-monthly-1',
    });
    expect(result?.amount).toBe('10.00');
  });

  it('times out runaway plugins', async () => {
    const host = new PluginHost();
    host.register({
      id: 'slow',
      name: 'Slow',
      calculate: () =>
        new Promise((resolve) =>
          setTimeout(() => resolve({ code: 'slow', amount: '1.00' }), 2000)
        ),
    });

    await expect(
      host.execute(
        'slow',
        {
          companyId: 'default',
          employeeId: '00000000-0000-0000-0000-000000000001',
          grossPay: '1000.00',
          payPeriodId: '2024-monthly-1',
        },
        50
      )
    ).rejects.toThrow('timed out');
  });
});
