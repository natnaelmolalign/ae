describe('taxYear', () => {
  afterEach(() => {
    delete process.env.FEATURE_TAX_YEAR_2025;
    jest.resetModules();
  });

  it('resolves year from payment date for core year', async () => {
    const { taxYearFromPaymentDate } = await import(
      '../../../src/config/taxYear'
    );
    expect(taxYearFromPaymentDate('2024-06-15')).toBe(2024);
  });

  it('throws for unsupported tax year', async () => {
    const mod = await import('../../../src/config/taxYear');
    const { PayrollDomainError } = await import(
      '../../../src/errors/PayrollDomainError'
    );
    expect(() => mod.assertSupportedTaxYear(1999)).toThrow(PayrollDomainError);
  });

  it('rejects 2025 payment date when FEATURE_TAX_YEAR_2025 is off', async () => {
    delete process.env.FEATURE_TAX_YEAR_2025;
    jest.resetModules();
    const mod = await import('../../../src/config/taxYear');
    const { PayrollDomainError } = await import(
      '../../../src/errors/PayrollDomainError'
    );
    expect(() => mod.taxYearFromPaymentDate('2025-01-15')).toThrow(
      PayrollDomainError
    );
  });

  it('accepts 2025 payment date when FEATURE_TAX_YEAR_2025 is on', async () => {
    process.env.FEATURE_TAX_YEAR_2025 = 'true';
    jest.resetModules();
    const { taxYearFromPaymentDate } = await import(
      '../../../src/config/taxYear'
    );
    expect(taxYearFromPaymentDate('2025-01-15')).toBe(2025);
  });
});
