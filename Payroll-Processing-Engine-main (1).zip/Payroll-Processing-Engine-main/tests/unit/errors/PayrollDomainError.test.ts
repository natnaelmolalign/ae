import {
  PayrollDomainError,
  PayrollErrorCode,
} from '../../../src/errors/PayrollDomainError';

describe('PayrollDomainError', () => {
  it('maps NOT_FOUND to HTTP 404', () => {
    const err = PayrollDomainError.notFound('Employee', 'abc');
    expect(err.code).toBe(PayrollErrorCode.NOT_FOUND);
    expect(err.httpStatus).toBe(404);
  });

  it('maps PAY_PERIOD_OVERLAP to HTTP 409', () => {
    const err = PayrollDomainError.payPeriodOverlap('a', 'b');
    expect(err.httpStatus).toBe(409);
  });

  it('maps INVALID_GROSS to HTTP 400', () => {
    const err = PayrollDomainError.invalidGross();
    expect(err.httpStatus).toBe(400);
  });

  it('maps DUPLICATE_PAYROLL_RUN to HTTP 409', () => {
    const err = PayrollDomainError.duplicatePayrollRun('emp-1', 'period-1');
    expect(err.code).toBe(PayrollErrorCode.DUPLICATE_PAYROLL_RUN);
    expect(err.httpStatus).toBe(409);
  });
});
