import golden from '../../golden/hourly-ot-holiday.json';
import { OvertimeAllocator } from '../../../src/services/OvertimeAllocator';
import { HourlyPayCalculator } from '../../../src/services/HourlyPayCalculator';
import type { TimeEntry } from '../../../src/models/types';
import { add } from '../../../src/utils/decimalUtils';

describe('golden: hourly + OT + holiday', () => {
  it('matches expected pay breakdown', () => {
    const allocator = new OvertimeAllocator();
    const hourly = new HourlyPayCalculator();

    const regularEntry: TimeEntry = {
      id: '1',
      employeeId: 'e',
      payPeriodId: 'p',
      workDate: '2024-06-03',
      clockIn: '2024-06-03T00:00:00Z',
      clockOut: '2024-06-03T00:00:00Z',
      roundedMinutes: golden.regularMinutes,
      entryType: 'regular',
      shiftAssignmentId: null,
      createdAt: '2024-01-01T00:00:00Z',
    };

    const ot = allocator.allocateWeekly(
      [regularEntry],
      golden.hourlyRate,
      golden.stateCode
    );
    const holidayPay = hourly.payForMinutes(
      golden.hourlyRate,
      golden.holidayMinutes,
      '1.5'
    );
    const gross = add(add(ot.regularPay, ot.overtimePay), holidayPay);

    expect(ot.regularPay).toBe(golden.expected.regularPay);
    expect(ot.overtimePay).toBe(golden.expected.overtimePay);
    expect(holidayPay).toBe(golden.expected.holidayPay);
    expect(gross).toBe(golden.expected.gross);
  });
});
