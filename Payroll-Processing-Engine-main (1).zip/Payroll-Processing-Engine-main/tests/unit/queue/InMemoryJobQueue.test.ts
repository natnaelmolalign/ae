import { InMemoryJobQueue } from '../../../src/queue/InMemoryJobQueue';
import { buildPartitionKey } from '../../../src/queue/JobQueue';

describe('InMemoryJobQueue', () => {
  it('enqueues and polls jobs in partition order', async () => {
    const queue = new InMemoryJobQueue();
    const partition = buildPartitionKey('default', '2024-monthly-1');

    await queue.enqueue({
      jobType: 'payroll_batch_employee',
      partitionKey: partition,
      payload: { employeeId: 'a' },
    });
    await queue.enqueue({
      jobType: 'payroll_batch_employee',
      partitionKey: partition,
      payload: { employeeId: 'b' },
    });

    const first = await queue.poll('worker-1');
    expect(first?.payload.employeeId).toBe('a');
    await queue.complete(first!.id);

    const second = await queue.poll('worker-2');
    expect(second?.payload.employeeId).toBe('b');
  });

  it('moves poison messages to DLQ after max attempts', async () => {
    const queue = new InMemoryJobQueue();
    const id = await queue.enqueue({
      jobType: 'webhook_delivery',
      partitionKey: 'default:webhooks',
      payload: { outboxId: 'x' },
      maxAttempts: 2,
    });

    await queue.poll('w');
    let outcome = await queue.fail(id, 'boom');
    expect(outcome).toBe('retry');

    await queue.poll('w');
    outcome = await queue.fail(id, 'boom again');
    expect(outcome).toBe('dlq');

    const dlq = await queue.listDeadLetters();
    expect(dlq).toHaveLength(1);
    expect(dlq[0].lastError).toBe('boom again');
  });
});
