import * as fs from 'fs';
import * as path from 'path';
import { FEDERAL_2024 } from '../../src/data/2024/federal';
import type { W4Params } from '../../src/models/W4Params';
import type { PayFrequency } from '../../src/models/types';
import { FederalWithholdingEngine } from '../../src/services/tax/federal/FederalWithholdingEngine';

interface GoldenScenario {
  id: string;
  payFrequency: PayFrequency;
  periodFederalTaxable: string;
  regularFederalTaxable: string;
  supplementalFederalTaxable: string;
  supplementalOnly: boolean;
  mixedSupplemental: boolean;
  w4: W4Params;
  expectedFederal: string;
}

const scenariosPath = path.join(__dirname, 'federal/scenarios.json');

describe('federal golden scenarios', () => {
  const data = JSON.parse(fs.readFileSync(scenariosPath, 'utf8')) as {
    scenarios: GoldenScenario[];
  };

  it('has at least 30 scenarios', () => {
    expect(data.scenarios.length).toBeGreaterThanOrEqual(30);
  });

  it.each(data.scenarios.map((s) => [s.id, s] as const))(
    '%s matches locked federal withholding',
    (_id, scenario) => {
      const actual = FederalWithholdingEngine.calculate(
        FEDERAL_2024,
        scenario.w4,
        scenario.payFrequency,
        scenario.periodFederalTaxable,
        scenario.regularFederalTaxable,
        scenario.supplementalFederalTaxable,
        scenario.supplementalOnly,
        scenario.mixedSupplemental
      );
      expect(actual).toBe(scenario.expectedFederal);
    }
  );
});
