import * as fs from 'fs';
import * as path from 'path';
import { TAX_YEAR_2024 } from '../../../src/data/2024';
import type { Employee, PayFrequency } from '../../../src/models/types';
import { MultiStateAllocationService } from '../../../src/services/tax/MultiStateAllocationService';
import { StateWithholdingEngine } from '../../../src/services/tax/state/StateWithholdingEngine';

interface Scenario {
  id: string;
  payFrequency: PayFrequency;
  residentState: string;
  stateTaxable: string;
  allocations: { stateCode: string; percent: string }[];
  expectedTotal: string;
}

const scenariosPath = path.join(__dirname, 'scenarios.json');

describe('multi-state golden scenarios', () => {
  const data = JSON.parse(fs.readFileSync(scenariosPath, 'utf8')) as {
    scenarios: Scenario[];
  };
  const service = new MultiStateAllocationService();

  it('has at least 5 scenarios', () => {
    expect(data.scenarios.length).toBeGreaterThanOrEqual(5);
  });

  it.each(data.scenarios.map((s) => [s.id, s] as const))(
    '%s matches locked multi-state withholding',
    (_id, scenario) => {
      const employee = {
        stateCode: scenario.residentState,
        payFrequency: scenario.payFrequency,
      } as Employee;
      const actual = service.calculateTotalStateTax(
        TAX_YEAR_2024,
        employee,
        scenario.stateTaxable,
        scenario.allocations
      ).total;
      expect(actual).toBe(scenario.expectedTotal);
    }
  );

  it('locks NY-only baseline for biweekly 5000', () => {
    const ny = StateWithholdingEngine.calculateForState(
      TAX_YEAR_2024,
      'NY',
      'biweekly',
      '5000.00'
    );
    expect(ny).toBe('305.67');
  });
});
