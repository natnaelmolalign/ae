import { FEDERAL_2024 } from '../../../src/data/2024/federal';
import { w4ParamsFromEmployee } from '../../../src/models/W4Params';
import { FederalWithholdingEngine } from '../../../src/services/tax/federal/FederalWithholdingEngine';
import { testEmployee } from '../../helpers/testEmployees';

describe('equity golden — RSU vest supplemental flat', () => {
  it('locks $10,000 RSU-only at 22% supplemental rate', () => {
    const w4 = w4ParamsFromEmployee(testEmployee);
    const tax = FederalWithholdingEngine.calculate(
      FEDERAL_2024,
      w4,
      'biweekly',
      '10000.00',
      '0.00',
      '10000.00',
      true,
      false
    );
    expect(tax).toBe('2200.00');
  });
});
