import { TipCreditCalculator } from '../../../src/services/tips/TipCreditCalculator';

describe('tips golden — minimum wage shortfall', () => {
  const calc = new TipCreditCalculator();

  it('locks 40h @ 7.25 with 85.20 cash and 100 tips', () => {
    const result = calc.computeShortfall(
      {
        id: 'x',
        companyId: 'default',
        firstName: 'T',
        lastName: 'W',
        employmentType: 'full_time_hourly',
        payFrequency: 'biweekly',
        baseCompensation: '2.13',
        hireDate: '2024-01-01',
        terminationDate: null,
        filingStatus: 'single',
        stateCode: 'TX',
        w4ExtraWithholding: '0.00',
        w4DependentsCredit: '0.00',
        w4OtherDeductions: '0.00',
        w4OtherIncome: '0.00',
        w4MultipleJobs: false,
        localMunicipalityCode: null,
        equityWithholdingMethod: 'supplemental_flat',
        tinLastFour: null,
        createdAt: '2024-01-01T00:00:00.000Z',
      },
      '100.00',
      { hours: 40, directCashWages: '85.20', minimumWage: '7.25' }
    );
    expect(result.shortfallMakeUp).toBe('104.80');
    expect(result.requiredMinimumPay).toBe('290.00');
  });
});
