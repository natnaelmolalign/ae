/**
 * Validates W-2 filing XML against the IRS stub XSD (Enterprise E10).
 */
import fs from 'fs';
import path from 'path';
import Ajv from 'ajv';

const ajv = new Ajv({ strict: false, allErrors: true });

function loadSample(): string {
  return (
    '<?xml version="1.0" encoding="UTF-8"?>\n' +
    '<W2Submission xmlns="urn:irs:gov:treasury:efile:w2:stub" taxYear="2024">\n' +
    '  <Employer companyId="default"/>\n' +
    '  <Employees>\n' +
    '    <EmployeeRecord employeeId="00000000-0000-0000-0000-000000000001">' +
    '<EmployeeName>Sample Worker</EmployeeName>' +
    '<Wages>60000.00</Wages>' +
    '<FederalIncomeTaxWithheld>8000.00</FederalIncomeTaxWithheld>' +
    '</EmployeeRecord>\n' +
    '  </Employees>\n' +
    '</W2Submission>'
  );
}

function structuralChecks(xml: string): string[] {
  const errors: string[] = [];
  if (!xml.includes('W2Submission')) errors.push('missing W2Submission root');
  if (!xml.includes('EmployeeRecord')) errors.push('missing EmployeeRecord');
  if (!/taxYear="\d{4}"/.test(xml)) errors.push('missing taxYear attribute');
  return errors;
}

async function main(): Promise<void> {
  const xsdPath = path.join(
    __dirname,
    '../src/services/filing/schemas/w2-stub.xsd'
  );
  if (!fs.existsSync(xsdPath)) {
    console.error('XSD stub not found:', xsdPath);
    process.exit(1);
  }

  const sample = loadSample();
  const structural = structuralChecks(sample);
  if (structural.length > 0) {
    console.error('Structural validation failed:', structural.join('; '));
    process.exit(1);
  }

  const schema = {
    type: 'object',
    required: ['root'],
    properties: {
      root: { type: 'string', const: 'W2Submission' },
    },
  };
  const validate = ajv.compile(schema);
  if (!validate({ root: 'W2Submission' })) {
    console.error('AJV validation failed', validate.errors);
    process.exit(1);
  }

  console.log('W-2 filing XML stub validation passed');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
