/**
 * Build provisional 2025/2026 tables.json from 2024 pack (stub until IRS publishes finals).
 */
import * as fs from 'fs';
import * as path from 'path';
import type { TaxYearTables } from '../src/data/tax/types';

const SOURCE = path.join(__dirname, '../src/data/2024/tables.json');

const STUB_FICA: Record<number, Partial<TaxYearTables['fica']>> = {
  2025: { socialSecurityWageBase: '176100' },
  2026: { socialSecurityWageBase: '180000' },
};

function main(): void {
  const base = JSON.parse(fs.readFileSync(SOURCE, 'utf8')) as TaxYearTables;
  for (const year of [2025, 2026]) {
    const pack: TaxYearTables = {
      ...base,
      taxYear: year,
      fica: { ...base.fica, ...STUB_FICA[year] },
    };
    const outDir = path.join(__dirname, '../src/data', String(year));
    fs.mkdirSync(outDir, { recursive: true });
    const outFile = path.join(outDir, 'tables.json');
    fs.writeFileSync(outFile, `${JSON.stringify(pack, null, 2)}\n`, 'utf8');
    console.log(`Wrote ${outFile} (provisional stub)`);
  }
}

main();
