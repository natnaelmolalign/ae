/**
 * Local load smoke test: 100 employees via in-process batch.
 * Run: npm run load:batch
 */
import { randomUUID } from 'crypto';
import { closeDb, getDb, runMigrations, truncateAllTables } from '../src/config/database';
import { createAppDependencies, resetCachedDependencies } from '../src/deps';

const EMPLOYEE_COUNT = 100;
const PARALLEL = 8;

async function main(): Promise<void> {
  process.env.NODE_ENV = 'test';
  await closeDb();
  resetCachedDependencies();

  const db = getDb();
  await runMigrations(db);
  await truncateAllTables(db);
  const deps = createAppDependencies(db);

  await db('pay_periods').insert({
    id: '2024-monthly-load',
    start_date: '2024-06-01',
    end_date: '2024-06-30',
    payment_date: '2024-06-30',
    frequency: 'monthly',
    year: 2024,
    period_index: 6,
  });

  const employeeIds: string[] = [];
  for (let i = 0; i < EMPLOYEE_COUNT; i++) {
    const id = randomUUID();
    employeeIds.push(id);
    await db('employees').insert({
      id,
      first_name: 'Load',
      last_name: `User${i}`,
      employment_type: 'full_time_salaried',
      pay_frequency: 'monthly',
      base_compensation: '3000.00',
      hire_date: '2024-01-01',
      termination_date: null,
      filing_status: 'single',
      state_code: 'TX',
      w4_extra_withholding: '0.00',
      w4_dependents_credit: '0.00',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    });
    await deps.employeePayrollReadinessRepository.upsertReady(
      id,
      '2024-monthly-load'
    );
  }

  const payPeriod = {
    id: '2024-monthly-load',
    startDate: '2024-06-01',
    endDate: '2024-06-30',
    paymentDate: '2024-06-30',
    frequency: 'monthly' as const,
    year: 2024,
    periodIndex: 6,
  };

  const wallStart = Date.now();
  const result = await deps.payrollBatchService.createAndRun({
    payPeriod,
    year: 2024,
    frequency: 'monthly',
    parallelLimit: PARALLEL,
    employeeIds,
  });
  const wallMs = Date.now() - wallStart;

  const summary = {
    employees: EMPLOYEE_COUNT,
    parallel: PARALLEL,
    batchDurationMs: result.batch.durationMs,
    wallMs,
    success: result.batch.successCount,
    failed: result.batch.failureCount,
    p95TargetMs: 30000,
    passed: wallMs < 30000 && result.batch.failureCount === 0,
  };

  console.log(JSON.stringify(summary, null, 2));

  await closeDb();
  process.exit(summary.passed ? 0 : 1);
}

void main().catch((err) => {
  console.error(err);
  process.exit(1);
});
