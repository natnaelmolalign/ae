/**
 * k6 HTTP load smoke for payroll API (Advanced Phase 9).
 *
 * Prerequisites:
 *   - Server running with API_KEYS (e.g. dev-admin-key:payroll_admin)
 *   - Optional: pre-seeded employee + pay period for run latency checks
 *
 * Run:
 *   k6 run scripts/load/k6-batch-payroll.js
 *   k6 run -e BASE_URL=http://localhost:3000 -e API_KEY=dev-admin-key scripts/load/k6-batch-payroll.js
 *
 * Targets (documented baseline):
 *   - http_req_failed < 0.1%
 *   - http_req_duration p(99) < 2000ms for /health and single-run path
 */
import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = __ENV.BASE_URL || 'http://127.0.0.1:3000';
const API_KEY = __ENV.API_KEY || 'dev-admin-key';
const COMPANY_ID = __ENV.COMPANY_ID || 'default';

export const options = {
  scenarios: {
    smoke: {
      executor: 'constant-vus',
      vus: Number(__ENV.VUS || 5),
      duration: __ENV.DURATION || '30s',
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.001'],
    http_req_duration: ['p(99)<2000'],
  },
};

function headers() {
  return {
    Authorization: `Bearer ${API_KEY}`,
    'X-Company-Id': COMPANY_ID,
    'Content-Type': 'application/json',
  };
}

export default function () {
  const health = http.get(`${BASE_URL}/health`);
  check(health, {
    'health 200': (r) => r.status === 200,
  });

  const ready = http.get(`${BASE_URL}/ready`);
  check(ready, {
    'ready 200': (r) => r.status === 200,
  });

  const metrics = http.get(`${BASE_URL}/metrics`);
  check(metrics, {
    'metrics 200': (r) => r.status === 200,
    'metrics has payroll_run_duration_ms': (r) =>
      r.body && String(r.body).includes('payroll_run_duration_ms'),
  });

  if (__ENV.EMPLOYEE_ID && __ENV.PAY_PERIOD_ID) {
    const runBody = JSON.stringify({
      employeeId: __ENV.EMPLOYEE_ID,
      payPeriodId: __ENV.PAY_PERIOD_ID,
      year: Number(__ENV.YEAR || 2024),
      frequency: __ENV.FREQUENCY || 'monthly',
      earnings: [{ type: 'regular', amount: '5000.00' }],
      deductions: [],
    });
    const run = http.post(`${BASE_URL}/api/payroll/run`, runBody, {
      headers: {
        ...headers(),
        'X-Correlation-Id': `k6-${__VU}-${__ITER}`,
      },
    });
    check(run, {
      'payroll run 200': (r) => r.status === 200,
      'traceparent echoed': (r) =>
        Boolean(r.headers.Traceparent || r.headers.traceparent),
    });
  }

  if (__ENV.QUEUED_BATCH === '1' && __ENV.PAY_PERIOD_ID) {
    const batchBody = JSON.stringify({
      payPeriodId: __ENV.PAY_PERIOD_ID,
      year: Number(__ENV.YEAR || 2024),
      frequency: __ENV.FREQUENCY || 'monthly',
      useQueue: true,
    });
    const batch = http.post(`${BASE_URL}/api/payroll/batch`, batchBody, {
      headers: headers(),
    });
    check(batch, {
      'queued batch 202': (r) => r.status === 202,
      'queued batch mode': (r) => {
        try {
          return JSON.parse(r.body).mode === 'queued';
        } catch {
          return false;
        }
      },
    });
  }

  sleep(0.5);
}
