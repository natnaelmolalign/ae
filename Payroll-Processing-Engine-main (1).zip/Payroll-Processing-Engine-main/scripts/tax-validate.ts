/**
 * Validate tax table JSON packs against schema + Zod.
 * Usage: npm run tax:validate -- [year]
 * Without year: validates all discovered packs under src/data/.
 */
import { TaxTableLoader } from '../src/services/tax/TaxTableLoader';

function main(): void {
  const loader = new TaxTableLoader();
  const yearArg = process.argv[2];
  const years = yearArg
    ? [parseInt(yearArg, 10)]
    : loader.discoverYears();

  if (years.some((y) => Number.isNaN(y))) {
    console.error(`Invalid tax year: ${yearArg}`);
    process.exit(1);
  }

  if (years.length === 0) {
    console.error('No tax year packs found (expected src/data/{year}/tables.json)');
    process.exit(1);
  }

  let failed = false;
  for (const year of years) {
    const result = loader.validateYear(year);
    if (result.valid) {
      console.log(`OK  ${year}`);
    } else {
      failed = true;
      console.error(`FAIL ${year}`);
      for (const issue of result.issues) {
        console.error(`  ${issue.path}: ${issue.message}`);
      }
    }
  }

  process.exit(failed ? 1 : 0);
}

main();
