/**
 * One-off helper: serialize TypeScript tax packs to tables.json for the loader pipeline.
 * Usage: npx ts-node --transpile-only scripts/export-tax-tables-json.ts [year]
 */
import * as fs from 'fs';
import * as path from 'path';
import { TAX_YEAR_2024 } from '../src/data/2024';

const yearArg = process.argv[2];
const packs: Record<string, unknown> = {
  '2024': TAX_YEAR_2024,
};

function main(): void {
  const years = yearArg ? [yearArg] : Object.keys(packs);
  for (const year of years) {
    const pack = packs[year];
    if (!pack) {
      console.error(`No TS pack registered for year ${year}`);
      process.exit(1);
    }
    const outDir = path.join(__dirname, '../src/data', year);
    const outFile = path.join(outDir, 'tables.json');
    fs.mkdirSync(outDir, { recursive: true });
    fs.writeFileSync(outFile, `${JSON.stringify(pack, null, 2)}\n`, 'utf8');
    console.log(`Wrote ${outFile}`);
  }
}

main();
