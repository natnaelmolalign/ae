import type { Knex } from 'knex';
import path from 'path';

const migrationsDir = path.join(__dirname, 'src', 'migrations');

const base: Knex.Config = {
  client: 'pg',
  connection: {
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT || 5432),
    user: process.env.DB_USER || 'payroll',
    password: process.env.DB_PASSWORD || 'payroll',
    database: process.env.DB_NAME || 'payroll',
  },
  migrations: {
    directory: migrationsDir,
    extension: 'ts',
  },
  pool: { min: 1, max: 10 },
};

const config: Record<string, Knex.Config> = {
  development: base,
  production: base,
  test: {
    client: 'better-sqlite3',
    connection: { filename: ':memory:' },
    useNullAsDefault: true,
    migrations: {
      directory: migrationsDir,
      extension: 'ts',
    },
  },
};

export default config;
